import { PublicClientApplication, RedirectRequest } from "@azure/msal-browser";

const ensureEnvVar = (envVar: string | undefined, varName: string): string => {
  if (!envVar) {
    throw new Error(`Missing environment variable: ${varName}`);
  }
  return envVar;
};

export const msalConfig = {
  auth: {
    clientId: ensureEnvVar(
      process.env.REACT_APP_CLIENT_ID,
      "REACT_APP_CLIENT_ID"
    ),
    authority: `https://login.microsoftonline.com/${ensureEnvVar(
      process.env.REACT_APP_TENANT_ID,
      "REACT_APP_TENANT_ID"
    )}`,
    redirectUri: process.env.REACT_APP_REDIRECT_URI,
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
  
};

export const loginRequest: RedirectRequest = {
  scopes: ['openid', ensureEnvVar(process.env.REACT_APP_SCOPES, "REACT_APP_SCOPES")],
};

export const msalInstance = new PublicClientApplication(msalConfig);
