import { useEffect, useState } from "react";
import { MsalProvider } from "@azure/msal-react";
import { msalInstance } from "../auth-config";
import { ReactNode } from "react";
import { LoadingIndicator } from "@/components/commons/loading_indicator/LoadingIndicator";
import { cookieSetting } from "@/utils";
import { useRouter } from "next/router";
import { toast } from "react-toastify";
// import { t } from "i18next";

interface AuthProviderProps {
  children: ReactNode;
}
export const clearMsalAccount = (error: any) => {
  msalInstance.logoutPopup().catch(() => {
    // toast.error(t(`common.error_code.${error.response?.data?.error?.code}`));
    toast.error("Account has not been verified",error);
  });
  msalInstance.setActiveAccount(null);
  cookieSetting.clear("token");
  cookieSetting.clear("ACCESS_TOKEN");
};
export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [isInitialized, setIsInitialized] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const initializeMsal = async () => {
      await msalInstance.initialize();
      setIsInitialized(true);
      const activeAccount = msalInstance.getActiveAccount();
      const allAccounts = msalInstance.getAllAccounts();

      if (activeAccount || allAccounts.length > 0) {
        if (!activeAccount) {
          msalInstance.setActiveAccount(allAccounts[0]);
        }
      } else {
        msalInstance.handleRedirectPromise().then((response) => {
          if (response) {
            const account = response.account;
            if (account) {
              msalInstance.setActiveAccount(account);
              cookieSetting.set("token", response.idToken);
              cookieSetting.set("ACCESS_TOKEN", response.accessToken);
              router.push("/"); // Redirect to homepage after successful login
            }
          }
        });
      }
    };

    if (!isInitialized) {
      initializeMsal();
    }
  }, [isInitialized]);

  if (!isInitialized) {
    return <LoadingIndicator />;
  }

  return <MsalProvider instance={msalInstance}>{children}</MsalProvider>;
};
