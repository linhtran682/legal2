interface GoogleUser {
  tokenId: string;
  profileObj: {
    name?: string;
    email?: string;
    picture?: string;
    // Add other properties as needed
  };
}

interface Window {
  googleUser?: GoogleUser;
}
