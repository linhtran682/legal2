import { authApi, ResponseWrapper } from "@/apis";
import {
  GetDepartmentHeadResponse,
  GetDepartmentParams,
  GetDepartmentResponse,
} from "@/models/department/Department";

const DEPARTMENT_PATH = "departments";

export const getDepartments = async (params: GetDepartmentParams) => {
  const response = await authApi.get<ResponseWrapper<GetDepartmentResponse>>(
    `/${DEPARTMENT_PATH}`,
    {
      params: params,
    }
  );

  return response.data.result;
};

export const getLegalDepartments = async () => {
  const response = await authApi.get<ResponseWrapper<GetDepartmentResponse>>(
    `/${DEPARTMENT_PATH}/legal`
  );

  return response.data.result;
};

export const getDepartmentHeads = async (id: string) => {
  const response = await authApi.get<GetDepartmentHeadResponse>(
    `/${DEPARTMENT_PATH}/${id}/head`
  );
  return response.data;
};
