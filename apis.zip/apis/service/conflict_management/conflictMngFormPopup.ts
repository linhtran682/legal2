import { authApi, ExtractFnReturnType, MutationConfig } from "@/apis";
import {
  CreateConfirmBody,
  CreateConfirmOptions,
  DeleteConfirmInformationOptions,
  DeleteFollowOptions,
  GetConfirmConflictDTO,
  GetConfirmConflictIdOptions,
  GetConfirmOptions,
  GetFollowOptions,
  QueryFnTypeConfirm,
} from "@/models/conflict_management/ConfirmConflict";
import { CreateEvaluateBody, CreateEvaluateOptions } from "@/models/conflict_management/EvaluateConflictManagement ";
import { CreateFeedbackConflictMngBody, CreateFeedbackConflictMngOptions, FeedbackConflictMngSchemaI } from "@/models/conflict_management/Feedback";
import { CreateFinishConflictMngBody, CreateFinishConflictMngOptions, FinishConflictMngSchemaI, GetUserDefaultForFinishPopupOptions, GetUserDefaultForFinishPopupResponse, GetUserDefaultParams, QueryFnUserType } from "@/models/conflict_management/FinishConflictMng";
import { CreateFollowConflictMngBody, CreateFollowConflictMngOptions, FollowConflictMngSchemaI,QueryFollowManagementFnType,ConflictConfirmDetail } from "@/models/conflict_management/FollowConflict";
import {
  CreateForwardConflictMngBody,
  CreateForwardConflictMngOptions,
  ForwardConflictMngSchemaI,
} from "@/models/conflict_management/ForwardConflict";
import {
  CreateRequestAddInfoConflictBody,
  CreateRequestAdditionalOptions,
  RequestAdditionalSchemaI,
} from "@/models/conflict_management/RequestAdditional";
import {
  CreateRequestApprovalBody,
  CreateRequestApprovalOptions,
} from "@/models/conflict_management/RequestApproval";
import { SendMailConflictRequest } from "@/models/conflict_management/SendMailConflict ";
import { CreateApproveBody, CreateApproveOptions, GetSignApprovalOptions, QueryFnCoflictType, ResponsesRecordSignApprovalDTO, SignApprovalParams } from "@/models/conflict_management/SignApproval";
import {
  CreateTimeExtensionBody,
  CreateTimeExtensionOptions,
  GetTimeExtensionIdOptions,
  QueryFnType,
  RequestApprovalDTO,
  TimeExtensionParams,
  UpdateTimeExtensionAcceptOptions,
  UpdateTimeExtensionBody,
} from "@/models/conflict_management/TimeExtensionConflict";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  GET_CONFIRM_INFORMATION_MANAGEMENT,
  GET_FOLLOW_MANAGEMENT,
} from "@/apis/service/conflict_management/conflictManagementForm";
import { ConflictEvaluateList } from "@/models/conflict_management/ConflictManagementDetail";

const CONFLICT_INTEREST = "conflict-interest";
const CONFLICT_MANAGEMENT = "conflict-management"; 
const GET_CONFIRM_CONFLICT = "get_confirm_conflict_popup"
const GET_EVALUATE_CONFLICT = "get_evaluate_conflict_popup"
const GET_FOLLOW_CONFLICT = "get_follow_conflict_popup"
// request improve information
export const createRequestInformationMutationFn = ({
  ciId,
  data,
}: CreateRequestAddInfoConflictBody): Promise<RequestAdditionalSchemaI> => {
  return authApi.post(
    `/${CONFLICT_INTEREST}/${ciId}/information-request`,
    data
  );
};

export const useCreateRequestInformation = ({
  config,
}: CreateRequestAdditionalOptions) => {
  return useMutation({
    ...config,
    mutationFn: createRequestInformationMutationFn,
  });
};
//forward
export const createForwardConflictMngMutationFn = ({
  lcsId,
  data,
}: CreateForwardConflictMngBody): Promise<ForwardConflictMngSchemaI> => {
  return authApi.post(`/${CONFLICT_INTEREST}/${lcsId}/forward`, data);
};

export const useCreateForwardConflictMng = ({
  config,
}: CreateForwardConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createForwardConflictMngMutationFn,
  });
};
//Request to extend time

export const GET_TIME_EXTENSION_ADVICE = "useGetTimeExtensionAdvice";

export const createTimeExtensionMutationFn = ({
  ciId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(
    `${CONFLICT_INTEREST}/${ciId}/time-extension/request`,
    data
  );
};

export const useCreateTimeExtension = ({
  config,
}: CreateTimeExtensionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionMutationFn,
  });
};

export const getTimeExtensionQueryFn = async (
  request: TimeExtensionParams
): Promise<RequestApprovalDTO> => {
  const { ciId, timeExtensionRequestId } = request;
  const response = await authApi.get(
    `${CONFLICT_INTEREST}/${ciId}/time-extension/${timeExtensionRequestId}`
  );
  return response.data.result;
};

export const useGetTimeExtension = ({
  config,
  request,
}: GetTimeExtensionIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_TIME_EXTENSION_ADVICE, request],
    queryFn: () => getTimeExtensionQueryFn(request),
  });
};

export const updateTimeExtensionMutationFn = async (
  request: UpdateTimeExtensionBody
): Promise<any> => {
  const { ciId, timeExtensionRequestId, data } = request;
  const response = await authApi.post(
    `${CONFLICT_INTEREST}/${ciId}/time-extension/${timeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtension = ({
  config,
}: UpdateTimeExtensionAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionMutationFn,
  });
};

//Confirm conflict

export const createConfirmConflictMutationFn = ({
  ciId,
  data,
}: CreateConfirmBody): Promise<any> => {
  return authApi.post(`${CONFLICT_INTEREST}/${ciId}/confirm`, data);
};

export const useCreateConfirm = ({ config }: CreateConfirmOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createConfirmConflictMutationFn,
  });
}
// Get detail confirm conflict
export const getConfirmConflictQueryFn = async (
  request: {ciId?: number, confirmId?: number}
): Promise<GetConfirmConflictDTO> => {
  const { ciId, confirmId } = request;
  const response = await authApi.get(
    `${CONFLICT_INTEREST}/${ciId}/confirm/${confirmId}`
  );
  return response.data.result;
};

export const useGetConfirmConflict = ({
  config,
  request,
}: GetConfirmConflictIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeConfirm>>({
    ...config,
    queryKey: [GET_CONFIRM_CONFLICT, request],
    queryFn: () => getConfirmConflictQueryFn(request),
  });
};

// request evaluate

export const createRequestEvaluateConflictMutationFn = ({
  ciId,
  data,
}: CreateConfirmBody): Promise<any> => {
  return authApi.post(`${CONFLICT_INTEREST}/${ciId}/evaluate/request`, data);
};

export const useCreateRequestEvaluateConflict = ({
  config,
}: CreateConfirmOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestEvaluateConflictMutationFn,
  });
};
// Evaluate_______________________________________
export const createEvaluateConflictMutationFn = ({
  ciId,
  data,
}: CreateEvaluateBody): Promise<any> => {
  return authApi.post(`${CONFLICT_INTEREST}/${ciId}/evaluate`, data);
};

export const useCreateEvaluateConflict = ({
  config,
}: CreateEvaluateOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createEvaluateConflictMutationFn,
  });
};
// Get detail evaluate
export const getEvaluateConflictQueryFn = async (
  request: {ciId?: number, evaluateId?: number}
): Promise<ConflictEvaluateList> => {
  const { ciId, evaluateId } = request;
  const response = await authApi.get(
    `${CONFLICT_INTEREST}/${ciId}/evaluate/${evaluateId}`
  );
  return response.data.result;
};

export const useGetEvaluateConflict = ({
  config,
  request,
}: any) => {
  return useQuery<ExtractFnReturnType<any>>({
    ...config,
    queryKey: [GET_EVALUATE_CONFLICT, request],
    queryFn: () => getEvaluateConflictQueryFn(request),
  });
};
// Approve request____________________________________
export const createRequestApproveConflictMutationFn = ({
  ciId,
  data,
}: CreateRequestApprovalBody): Promise<any> => {
  return authApi.post(`${CONFLICT_INTEREST}/${ciId}/approve/request`, data);
};

export const useCreateRequestApprovalConflict = ({
  config,
}: CreateRequestApprovalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestApproveConflictMutationFn,
  });
};

//  Finish Conflict
export const createFinishConflictMngMutationFn = ({
  ciId,
  data,
}: CreateFinishConflictMngBody): Promise<FinishConflictMngSchemaI> => {
  return authApi.post(`${CONFLICT_MANAGEMENT}/${ciId}/finish`, data);
};

export const useCreateFinishConflict = ({
  config,
}: CreateFinishConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFinishConflictMngMutationFn,
  });
};
//::::::get user default 
export const getUserDefaultQueryFn = async (
  params : GetUserDefaultParams
): Promise<GetUserDefaultForFinishPopupResponse> => {
  const response = await authApi.get(
    `${CONFLICT_MANAGEMENT}/${params.conflictId}/finish/default-users`
  );
  return response.data.result.users;
};

export const useGetUserDefault = ({
  config,
  request,
}: GetUserDefaultForFinishPopupOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnUserType>>({
    ...config,
    queryKey: ['SignApproval', request],
    queryFn: () => getUserDefaultQueryFn(request),
  });
};
//Sign Approval
export const getSignApprovalQueryFn = async (
  request: SignApprovalParams
): Promise<ResponsesRecordSignApprovalDTO[]> => {
  const { ciId } = request;
  const response = await authApi.get(
    `${CONFLICT_INTEREST}/${ciId}/approve/request`
  );
  return response.data.result.requestApproveResponses;
};

export const useGetRecordSignApproval = ({
  config,
  request,
}: GetSignApprovalOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnCoflictType>>({
    ...config,
    queryKey: ['SignApproval', request],
    queryFn: () => getSignApprovalQueryFn(request),
  });
};
// approve
export const createSignApproveConflictMutationFn = ({
  ciId,
  data,
}: CreateApproveBody): Promise<any> => {
  return authApi.post(`${CONFLICT_INTEREST}/${ciId}/approve`, data);
};

export const useCreateSignApproveConflictConflict = ({
  config,
}: CreateApproveOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createSignApproveConflictMutationFn,
  });
};
//Follow Theo dõi

// get list confirm information
export const getListConfirmInformationQueryFn = async (request: {
  ciId: number;
}) => {
  const { ciId } = request;
  const response = await authApi.get<any>(
    `/${CONFLICT_INTEREST}/${ciId}/confirm`
  );

  return response?.data?.result;
};

export const useGetConfirmInformation = ({
  config,
  request,
}: GetConfirmOptions) => {
  return useQuery({
    ...config,
    queryKey: [GET_CONFIRM_INFORMATION_MANAGEMENT],
    queryFn: () => getListConfirmInformationQueryFn(request),
  });
};
// delete confirm information
export const deleteConfirmInformationMutationFn = async (
  bodyRequest: {ciId: number, confirmId: number}
): Promise<any> => {
  const { ciId, confirmId } = bodyRequest;
  const response = await authApi.delete(`${CONFLICT_INTEREST}/${ciId}/confirm/${confirmId}`);

  return response.status;
};

export const useDeleteConfirmInformation = ({
  config,
}: DeleteConfirmInformationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteConfirmInformationMutationFn,
  });
};
// get list follow mng
export const getListFollowQueryFn = async (request: {
  ciId: number;
}) => {
  const { ciId } = request;
  const response = await authApi.get<any>(
    `/${CONFLICT_INTEREST}/${ciId}/follow`
  );

  return response?.data?.result;
};

export const useGetFollowMng = ({
  config,
  request,
}: GetFollowOptions) => {
  return useQuery({
    ...config,
    queryKey: [GET_FOLLOW_MANAGEMENT],
    queryFn: () => getListFollowQueryFn(request),
  });
};
// get detail follow conflict
export const getFollowConflictQueryFn = async (
  request: {ciId?: number, followId?: number}
): Promise<ConflictConfirmDetail> => {
  const { ciId, followId } = request;
  const response = await authApi.get(
    `${CONFLICT_INTEREST}/${ciId}/follow/${followId}`
  );
  return response.data.result;
};

export const useGetFollowConflict = ({
  config,
  request,
}: any) => {
  return useQuery<ExtractFnReturnType<QueryFollowManagementFnType>>({
    ...config,
    queryKey: [GET_FOLLOW_CONFLICT, request],
    queryFn: () => getFollowConflictQueryFn(request),
  });
};
// delete follow mng
export const deleteFollowMngMutationFn = async (
  bodyRequest: {ciId: number, followId: number}
): Promise<any> => {
  const { ciId, followId } = bodyRequest;
  const response = await authApi.delete(`${CONFLICT_INTEREST}/${ciId}/follow/${followId}`);

  return response.status;
};

export const useDeleteFollowMng = ({
  config,
}: DeleteFollowOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteFollowMngMutationFn,
  });
};
export const createFollowConflictMutationFn = ({
  ciId,
  data,
}: CreateFollowConflictMngBody): Promise<FollowConflictMngSchemaI> => {
  return authApi.post(`${CONFLICT_INTEREST}/${ciId}/follow`, data);
};

export const useCreateFollow = ({
  config,
}: CreateFollowConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFollowConflictMutationFn,
  });
};
//::::::get user default Follow
export const getUserDefaultFollowQueryFn = async (
  params : GetUserDefaultParams
): Promise<GetUserDefaultForFinishPopupResponse> => {
  const response = await authApi.get(
    `${CONFLICT_INTEREST}/${params.conflictId}/follow/default-users`
  );
  return response.data.result.users;
};

export const useGetUserDefaultFollow = ({
  config,
  request,
}: GetUserDefaultForFinishPopupOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnUserType>>({
    ...config,
    queryKey: ['follow_user_default', request],
    queryFn: () => getUserDefaultFollowQueryFn(request),
  });
};
//Recall 
export interface RecallConflictOptions {
  config?: MutationConfig<typeof recallConflictMutationFn>;
}

export const recallConflictMutationFn = (ciId?: number): Promise<any> => {
  return authApi.post(`${CONFLICT_MANAGEMENT}/${ciId}/recall`);
};

export const useRecallConflict = ({
  config,
}: RecallConflictOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: recallConflictMutationFn,
  });
};
//send mail
export const sendMailConflict = async (params: {
  id: number;
  request: SendMailConflictRequest;
}) => {
  const requestFormat = {
    ...params.request,
  };
  const response = await authApi.post(
    `${CONFLICT_MANAGEMENT}/${params.id}/sendmail`,
    requestFormat
  );
  return response.status;
};
// FeedBack
export const createFeedbackConflictMutationFn = ({
  ciId,
  data,
}: CreateFeedbackConflictMngBody): Promise<FeedbackConflictMngSchemaI> => {
  return authApi.post(`${CONFLICT_INTEREST}/${ciId}/feedback`, data);
};

export const useCreateFeedbackConflict = ({
  config,
}: CreateFeedbackConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackConflictMutationFn,
  });
};