import { authApi, ExtractFnReturnType, ResponseWrapper } from "@/apis";
import {
  ConflictManagementBodyReceive,
  ConflictManagementBodySend,
  ConflictManagementParams,
  CreateConflictManagementOptions,
  DeleteEvaluateIdOptions,
  GetConflictApprovalResponse,
  GetConflictEvaluateTabResponse,
  GetConflictExtensionResponse,
  GetConflictForwardResponse,
  GetConflictManagementOptions,
  GetConflictRequestFeedbackResponse,
  GetListConflictEvaluateResponse,
  QueryConflictManagementFnType,
  UpdateBookMeetingConflictManagementOptions,
  // QueryConflictManagementFnType,
  UpdateConflictManagementOptions,
  UpdateConflictManagementRequest,
} from "@/models/conflict_management/ConflictManagementDetail";
import {
  ConflictMngStatisticChartResponse,
  GetConflictManagementListParams,
  GetConflictManagementListResponse,
} from "@/models/conflict_management/ConflictManagementList";
import { GetLegalDocumentTabAttachmentsResponse } from "@/models/law_document/LegalDocumentAttachment";
import {
  GetHistoryResponse,
  GetInformationRequestsResponse,
} from "@/models/metadata/Metadata";
import { useMutation, useQuery } from "@tanstack/react-query";

export const CONFLICT_MANAGEMENT = "conflict-management";
export const CONFLICT_MANAGEMENT_INTEREST = "conflict-interest";
export const GET_INITIAL_CONFLICT_MANAGEMENT =
  "get_initial_conflict_management";
export const GET_EVALUATE_COMMENT_LIST = "get_evaluate_comment_list";
export const GET_CONFIRM_INFORMATION_MANAGEMENT =
  "get_confirm_information_management";
export const GET_FOLLOW_MANAGEMENT = "get_follow_management";
const FILE = "files";

export const getConflictManagementExcel = async (
  params: GetConflictManagementListParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${CONFLICT_MANAGEMENT}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getAllHierarchyById = async (params: { id: number | string }) => {
  const response = await authApi.get(
    `/${CONFLICT_MANAGEMENT}/${params.id}/all-hierarchy`
  );
  return response.data?.result;
};

export const getListConflictManagementQueryFn = async (
  params: GetConflictManagementListParams
): Promise<GetConflictManagementListResponse> => {
  const response = await authApi.get(CONFLICT_MANAGEMENT, { params });
  return response.data.result;
};

export const getConflictManagementQueryFn = async (
  request: ConflictManagementParams
): Promise<ConflictManagementBodyReceive> => {
  const { id } = request;
  const response = await authApi.get(`${CONFLICT_MANAGEMENT}/${id}`);
  return response.data.result;
};

export const useGetConflictManagement = ({
  config,
  request,
}: GetConflictManagementOptions) => {
  return useQuery<ExtractFnReturnType<QueryConflictManagementFnType>>({
    ...config,
    queryKey: [GET_INITIAL_CONFLICT_MANAGEMENT],
    queryFn: () => getConflictManagementQueryFn(request),
  });
};

export const createConflictManagementMutationFn = async (
  data: ConflictManagementBodySend
): Promise<any> => {
  const response = await authApi.post(CONFLICT_MANAGEMENT, data);
  return response.status;
};

export const useCreateConflictManagement = ({
  config,
}: CreateConflictManagementOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createConflictManagementMutationFn,
  });
};

export const updateConflictManagementMutationFn = async (
  bodyRequest: UpdateConflictManagementRequest
): Promise<any> => {
  const { id, request } = bodyRequest;
  const response = await authApi.put(`${CONFLICT_MANAGEMENT}/${id}`, request);

  return response.status;
};

export const useUpdateConflictManagement = ({
  config,
}: UpdateConflictManagementOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateConflictManagementMutationFn,
  });
};

export const updateBookMeetingConflictManagementMutationFn = async (params: {
  conflictId?: number;
  request: {
    isBookMeeting: boolean;
  };
}) => {
  const response = await authApi.post(
    `${CONFLICT_MANAGEMENT}/${params.conflictId}/book-meeting`,
    params.request
  );
  return response.status;
};

export const useUpdateBookMeetingConflict = ({
  config,
}: UpdateBookMeetingConflictManagementOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateBookMeetingConflictManagementMutationFn,
  });
};

export const getConflictManagementInformationRequests = async (
  ciId: number
) => {
  const response = await authApi.get<GetInformationRequestsResponse>(
    `/${CONFLICT_MANAGEMENT_INTEREST}/${ciId}/information-request`
  );

  return response.data;
};
export const getConflictManagementEvaluateTab = async (ciId: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetConflictEvaluateTabResponse>
  >(`/${CONFLICT_MANAGEMENT_INTEREST}/${ciId}/evaluate/tab`);

  return response.data;
};

export const getListConflictManagementEvaluate = async (ciId: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetListConflictEvaluateResponse>
  >(`/${CONFLICT_MANAGEMENT_INTEREST}/${ciId}/evaluate`);

  return response.data;
};
// delete evaluate
export const deleteEvaluateMngMutationFn = async (bodyRequest: {
  ciId: number;
  evaluateId: number;
}): Promise<any> => {
  const { ciId, evaluateId } = bodyRequest;
  const response = await authApi.delete(
    `${CONFLICT_MANAGEMENT_INTEREST}/${ciId}/evaluate/${evaluateId}`
  );

  return response.status;
};

export const useDeleteEvaluateMng = ({
  config,
}: DeleteEvaluateIdOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteEvaluateMngMutationFn,
  });
};

export const getConflictManagementApproval = async (ciId: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetConflictApprovalResponse>
  >(`/${CONFLICT_MANAGEMENT_INTEREST}/${ciId}/approve/request`);

  return response.data;
};

export const getConflictManagementExtensions = async (ciId: number) => {
  const response = await authApi.get<GetConflictExtensionResponse>(
    `/${CONFLICT_MANAGEMENT_INTEREST}/${ciId}/time-extension`
  );
  return response.data;
};

export const getConflictManagementRequestFeedback = async (ciId: number) => {
  const response = await authApi.get<GetConflictRequestFeedbackResponse>(
    `/${CONFLICT_MANAGEMENT_INTEREST}/${ciId}/feedback`
  );
  return response.data;
};

export const getConflictManagementAttachment = async (
  id: number,
  referenceFileTypes?: number
) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalDocumentTabAttachmentsResponse>
  >(`${FILE}/${id}/attachment-tab`, { params: { referenceFileTypes } });
  return response.data.result;
};

export const getConflictManagementForwards = async (lcsId: number) => {
  const response = await authApi.get<GetConflictForwardResponse>(
    `/${CONFLICT_MANAGEMENT_INTEREST}/${lcsId}/forward`
  );

  return response.data;
};

export const getConflictManagementHistory = async (conflictId: number) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${CONFLICT_MANAGEMENT}/${conflictId}/history`
  );
  return response.data;
};

export const shareConflictFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number;
  };
}) => {
  const response = await authApi.post(
    `/${CONFLICT_MANAGEMENT}/${params.id}/share`,
    params.data
  );

  return response.data;
};

// chart
export const getConflictMngStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<ConflictMngStatisticChartResponse>
  >(`/${CONFLICT_MANAGEMENT_INTEREST}/statistic/chart`);
  return response.data.result;
};
export const getStatisticTableFn = async (params: GetConflictManagementListParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetConflictManagementListResponse>
  >(`/${CONFLICT_MANAGEMENT_INTEREST}/statistic/table`, {
    params: params,
  });
  return response.data.result;
};
export const getStatisticTableDoneFn = async (
  params: GetConflictManagementListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<GetConflictManagementListResponse>
  >(`/${CONFLICT_MANAGEMENT_INTEREST}/statistic/table/done`, {
    params: params,
  });
  return response.data.result;
};
