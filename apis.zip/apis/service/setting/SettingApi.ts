import authApi, { ExtractFnReturnType, ResponseWrapper } from "@/apis";
import {
  GetMailListResponse,
  GetMailTemplateDetailOptions,
  GetMailTemplateOptions,
  MailDetailReceive,
  MailTemplateBodySend,
  QueryMailTemplateDetailFnType,
  QueryMailTemplateFnType,
  UpdateMailTemplateOptions,
} from "@/models/setting/Mail";
import { useMutation, useQuery } from "@tanstack/react-query";

const MAIL = "email_template";

export const getListMailTemplateQueryFn = async () => {
  const response = await authApi.get<ResponseWrapper<GetMailListResponse>>(
    MAIL
  );
  return response.data.result;
};

export const useListMailTemplate = ({ config }: GetMailTemplateOptions) => {
  return useQuery<ExtractFnReturnType<QueryMailTemplateFnType>>({
    ...config,
    queryKey: ["get_mail_template_list"],
    queryFn: () => getListMailTemplateQueryFn(),
  });
};

export const geMailTemplateDetailQueryFn = async (id: string) => {
  const response = await authApi.get<ResponseWrapper<MailDetailReceive>>(
    `${MAIL}/${id}`
  );
  return response.data.result;
};

export const useMailTemplateDetail = ({ config, params }: GetMailTemplateDetailOptions) => {
  return useQuery<ExtractFnReturnType<QueryMailTemplateDetailFnType>>({
    ...config,
    queryKey: ["get_mail_template_detail", params.id],
    queryFn: () => geMailTemplateDetailQueryFn(params.id),
  });
};

export const updateMailTemplateMutationFn = async (
  data: MailTemplateBodySend
): Promise<any> => {
  const {templateId, ... rest} = data;
  const response = await authApi.put(`${MAIL}/${templateId}`, rest);
  return response.status;
};

export const useUpdateMailTemplate = ({
  config,
}: UpdateMailTemplateOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateMailTemplateMutationFn,
  });
};
