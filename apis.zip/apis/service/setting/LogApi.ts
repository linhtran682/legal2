import authApi, { ExtractFnReturnType, ResponseWrapper } from "@/apis";
import {
  AuditLog,
  AuditLoglistRequest,
  AuditLoglistResponse,
  GetLogSettingFnType,
  GetLogSettingOptions,
  LogSettingReceive,
  SettingLogSchemaI,
  UpdateLogSettingOptions,
} from "@/models/setting/Log";
import { useMutation, useQuery } from "@tanstack/react-query";

const LOG_SETTING = "log-setting";
const API_LOG = "api_log";

export const getLogSettingQueryFn = async () => {
  const response = await authApi.get<ResponseWrapper<LogSettingReceive>>(
    LOG_SETTING
  );
  return response.data.result;
};

export const useGetLogSetting = (config?: GetLogSettingOptions) => {
  return useQuery<ExtractFnReturnType<GetLogSettingFnType>>({
    ...config,
    queryKey: ["get_log_setting"],
    queryFn: () => getLogSettingQueryFn(),
  });
};

export const updateLogSettingMutationFn = async (
  params: SettingLogSchemaI
): Promise<any> => {
  const response = await authApi.post(LOG_SETTING, params);
  return response.status;
};

export const useUpdateLogSetting = ({
  config,
}: UpdateLogSettingOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateLogSettingMutationFn,
  });
};

export const getAuditLogQueryFn = async (params: AuditLoglistRequest) => {
  const response = await authApi.get<ResponseWrapper<AuditLoglistResponse>>(
    API_LOG, {params}
  );
  return response.data.result;
};

export const getAuditLogExcel = async (
  params: AuditLoglistRequest
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${API_LOG}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getLogDetail = async (id: string) => {
  const response = await authApi.get<ResponseWrapper<AuditLog>>(
    `${API_LOG}/${id}`
  );
  return response.data;
};
