import { authApi, ResponseWrapper } from "@/apis";
import {
  DocumentTypeDTO,
  GetDocumentTypesParams,
  GetDocumentTypesResponse,
  SaveDocumentTypeDTO,
} from "@/models/document_type/DocumentType";

const DOCUMENT_TYPE_PATH = "document-type";

export const getDocumentTypes = async (params: GetDocumentTypesParams) => {
  const response = await authApi.get<ResponseWrapper<GetDocumentTypesResponse>>(
    DOCUMENT_TYPE_PATH,
    {
      params: params,
    }
  );
  return response.data.result;
};

export const getDocumentType = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<ResponseWrapper<DocumentTypeDTO>>(
    `${DOCUMENT_TYPE_PATH}/${id}`
  );
  return response.data.result;
};

export const createDocumentType = async (request: SaveDocumentTypeDTO) => {
  const response = await authApi.post(DOCUMENT_TYPE_PATH, request);

  return response.status;
};

export const updateDocumentType = async (updateProps: {
  request: SaveDocumentTypeDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${DOCUMENT_TYPE_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteDocumentTypes = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${DOCUMENT_TYPE_PATH}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};
