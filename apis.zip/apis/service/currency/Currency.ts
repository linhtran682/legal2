import { authApi, ResponseWrapper } from "@/apis";
import {
  CurrencyDTO,
  GetCurrenciesParams,
  GetCurrenciesResponse,
  SaveCurrencyDTO,
} from "@/models/currency/Currency";

const Currency_PATH = "currency";

export const getCurrencies = async (params: GetCurrenciesParams) => {
  const response = await authApi.get<ResponseWrapper<GetCurrenciesResponse>>(
    Currency_PATH,
    {
      params: params,
    }
  );
  return response.data.result;
};

export const getCurrency = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<ResponseWrapper<CurrencyDTO>>(
    `${Currency_PATH}/${id}`
  );
  return response.data.result;
};

export const createCurrency = async (request: SaveCurrencyDTO) => {
  const response = await authApi.post(Currency_PATH, request);

  return response.status;
};

export const updateCurrency = async (updateProps: {
  request: SaveCurrencyDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${Currency_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteCurrencies = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${Currency_PATH}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};
