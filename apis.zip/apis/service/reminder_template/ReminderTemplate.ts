import { authApi, ResponseWrapper } from "@/apis";
import {
  GetBasedReminderTemplatesParams,
  GetBasedReminderTemplatesResponse,
} from "@/models/reminder_template/BaseReminderTemplate";
import {
  RemindPopupResponse,
  RemindUnreadResponse,
} from "@/models/reminder_template/ReminderDTO";
import {
  GetReminderTemplateDTO,
  SaveReminderTemplateDTO,
} from "@/models/reminder_template/ReminderTemplateDTO";

const REMIND_PATH = "remind";

export const getBasedReminderTemplates = async (
  params: GetBasedReminderTemplatesParams
) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedReminderTemplatesResponse>
  >(REMIND_PATH, {
    params: params,
  });
  return response.data.result;
};

export const getReminderTemplate = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<ResponseWrapper<GetReminderTemplateDTO>>(
    `${REMIND_PATH}/${id}`
  );
  return response.data.result;
};

export const createReminderTemplate = async (
  request: SaveReminderTemplateDTO
) => {
  const response = await authApi.post(REMIND_PATH, request);

  return response.status;
};

export const updateReminderTemplate = async (updateProps: {
  request: SaveReminderTemplateDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${REMIND_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteReminderTemplates = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${REMIND_PATH}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};

export const getRemindPopup = async () => {
  const response = await authApi.get<ResponseWrapper<RemindPopupResponse>>(
    `${REMIND_PATH}/popup`
  );
  return response.data.result;
};
export const getNotificationPopup = async (params: {
  page: number;
  size: number;
  module?: number;
}) => {
  const response = await authApi.get<ResponseWrapper<RemindPopupResponse>>(
    `${REMIND_PATH}/popup/notification`,
    {
      params: params,
    }
  );
  return response.data.result;
};
export const getTotalUnread = async () => {
  const response = await authApi.get<ResponseWrapper<RemindUnreadResponse>>(
    `${REMIND_PATH}/popup/unread`
  );
  return response.data.result;
};

export const markAllAsReadFn = async () => {
  const response = await authApi.put(`${REMIND_PATH}/popup/notication/read`);
  return response.status;
};

export const markSingleAsReadFn = async (id: number) => {
  const response = await authApi.put(
    `${REMIND_PATH}/popup/notication/read/${id}`
  );
  return response.status;
};

export const getPositionFn = async (name: string) => {
  const response = await authApi.get(`position`, {
    params: {
      name: name,
    },
  });
  return response.data.result;
};
