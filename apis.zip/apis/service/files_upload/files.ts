import { authApi, ResponseWrapper } from "@/apis";
import { FileDetails } from "@/components/commons/upload/file_upload/FileUpload";
import {
  DOCUMENT_ROOT_PATH,
  LEGAL_DOCUMENT_ROOT_PATH,
} from "@/constants/paths";
import { BasedUser } from "@/models/user/User";
import { cookieSetting } from "@/utils";

export interface FileUploadResponse {
  fileId: number;
  fileName: string;
  storagePath?: string;
  filePath?: string;
  uploadDate?: string;
  uploadUser?: BasedUser;
}

export interface AttachmentTabResponse {
  data: FileUploadResponse[];
}

interface FileUploadResponses {
  fileUploadResponses: FileUploadResponse[];
}

const FILE = "files";
export const GetListIdFile = async (fileDetails?: FileDetails[]) => {
  const formData = new FormData();
  if (fileDetails) {
    fileDetails.forEach((fileDetail) => {
      fileDetail.file &&
        formData.append(`files`, fileDetail.file, fileDetail.name);
    });
    const response = await authApi.post(
      `${FILE}/multiple-documents`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return response.data.result;
  }
};

export const GetFilesId = async (request: FileUploadResponses) => {
  const response = await authApi.post(`${FILE}/documents`, request);
  return response.status;
};

export const uploadLegalDocumentTabAttachments = async (params: {
  files: File[];
  id: number;
}) => {
  const formData = new FormData();
  params.files.forEach((file) => formData.append("files", file));

  const response = await authApi.post(
    `${FILE}/${LEGAL_DOCUMENT_ROOT_PATH}/${params.id}/attachment-tab`,
    formData,
    {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    }
  );

  return response;
};

export const uploadLegalDocumentToSharepoint = async (params: {
  fileDetails?: FileDetails[];
  id: number;
}) => {
  const formData = new FormData();
  if (params.fileDetails) {
    params.fileDetails.forEach((fileDetail) => {
      fileDetail.file &&
        formData.append(`file`, fileDetail.file, fileDetail.name);
    });
    const response = await authApi.post(
      `${FILE}/${LEGAL_DOCUMENT_ROOT_PATH}/${params.id}/sharepoint`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          "access-token": cookieSetting.get("ACCESS_TOKEN"),
        },
      }
    );

    return response.data.result;
  }
};
export const UpdateLegalDocumentToSharepoint = async (params: {
  legal_document_id?: number;
  file_id: number;
}) => {
  const response = await authApi.post(
    `${FILE}/${LEGAL_DOCUMENT_ROOT_PATH}/${params.legal_document_id}/sharepoint/${params.file_id}`,
    {},
    {
      headers: {
        "Content-Type": "multipart/form-data",
        "access-token": cookieSetting.get("ACCESS_TOKEN"),
      },
    }
  );

  return response.data.result;
};
export const uploadDocumentTabAttachments = async (params: {
  files: File[];
  id: number;
  reference_file_type: number;
}) => {
  const formData = new FormData();
  params.files.forEach((file) => formData.append("files", file));
  formData.append("reference_file_type", params.reference_file_type.toString());

  const response = await authApi.post(
    `${FILE}/${DOCUMENT_ROOT_PATH}/${params.id}/attachment`,
    formData,
    {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    }
  );

  return response;
};

export const getAttachmentTab = async ({
  referenceFileTypes,
  documentId,
}: {
  // reference_file_type: ReferenceFileTypes;
  referenceFileTypes: string;
  documentId: number;
}) => {
  const response = await authApi.get<ResponseWrapper<AttachmentTabResponse>>(
    `${FILE}/${documentId}/attachment-tab`,
    {
      params: { referenceFileTypes },
    }
  );
  return response.data.result;
};

export const uploadFileToLegalCheckSheet = async (
  fileDetails?: FileDetails[]
) => {
  const formData = new FormData();
  if (fileDetails) {
    fileDetails.forEach((fileDetail) => {
      fileDetail.file &&
        formData.append(`files`, fileDetail.file, fileDetail.name);
    });
    // /v1/files/legal-check-sheet
    const response = await authApi.post(`${FILE}/legal-check-sheet`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data.result;
  }
};
