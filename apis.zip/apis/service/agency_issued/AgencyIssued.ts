import { authApi, ResponseWrapper } from "@/apis";
import {
  AgencyIssuedDTO,
  GetAgencyIssuedsParams,
  GetAgencyIssuedsResponse,
  SaveAgencyIssuedDTO,
} from "@/models/agency_issued/AgencyIssued";

const AgencyIssued_PATH = "agency-issued";

export const getAgencyIssueds = async (params: GetAgencyIssuedsParams) => {
  const response = await authApi.get<ResponseWrapper<GetAgencyIssuedsResponse>>(
    AgencyIssued_PATH,
    {
      params: params,
    }
  );
  return response.data.result;
};

export const getAgencyIssued = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<ResponseWrapper<AgencyIssuedDTO>>(
    `${AgencyIssued_PATH}/${id}`
  );
  return response.data.result;
};

export const createAgencyIssued = async (request: SaveAgencyIssuedDTO) => {
  const response = await authApi.post(AgencyIssued_PATH, request);

  return response.status;
};

export const updateAgencyIssued = async (updateProps: {
  request: SaveAgencyIssuedDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${AgencyIssued_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteAgencyIssueds = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${AgencyIssued_PATH}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};
