import { authApi, ResponseWrapper } from "@/apis";
import {
  GetHelpListParams,
  GetHelpListResponse,
  SaveHelpDTO,
  HelpDTO,
} from "@/models/help/Help";

const HELP_PATH = "help";

export const getHelpList = async (params: GetHelpListParams) => {
  const response = await authApi.get<ResponseWrapper<GetHelpListResponse>>(
    HELP_PATH,
    {
      params: {
        ...params,
        modules: params.modules ? params.modules.join(",") : undefined,
      },
    }
  );
  return response.data.result;
};

export const getHelp = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<HelpDTO>>(
    `${HELP_PATH}/${id}`
  );
  return response.data.result;
};

export const createHelp = async (request: SaveHelpDTO) => {
  const response = await authApi.post(HELP_PATH, request);

  return response.status;
};

export const updateHelp = async (updateProps: {
  request: SaveHelpDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${HELP_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteHelps = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${HELP_PATH}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};
