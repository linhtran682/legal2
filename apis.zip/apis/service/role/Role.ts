import { authApi, ResponseWrapper } from "@/apis";
import { GetRolesParams, GetRolesResponse, RoleDTO, RoleDTO1 } from "@/models/role/Role";

export const ROLE_PATH = "roles";

export const getRoles = async (params: GetRolesParams) => {
  const response = await authApi.get<ResponseWrapper<GetRolesResponse>>(
    ROLE_PATH,
    {
      params: params,
    }
  );
  return response.data.result;
};

export const getRole = async (id: string) => {
  const response = await authApi.get<ResponseWrapper<RoleDTO>>(
    `${ROLE_PATH}/${id}`
  );
  return response.data.result;
};

export const deleteRole = async (id: string) => {
  const response = await authApi.delete<any>(`${ROLE_PATH}/${id}`);
  return response.data;
};

export const getRolesDefault = async () => {
  const response = await authApi.get<ResponseWrapper<RoleDTO>>(
    `${ROLE_PATH}/default`
  );
  return response.data.result;
};

export const createRole = async (request: RoleDTO1 ) => {
  const response = await authApi.post(ROLE_PATH, request);
  return response.data;
};

export const updateRole = async (updateProps: {
  request: RoleDTO1;
  id: string;
}) => {
  const response = await authApi.put(
    `${ROLE_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.data;
};