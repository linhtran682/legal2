import { authApi, ExtractFnReturnType, MutationConfig, ResponseWrapper } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  CreateTimeExtensionBody,
  CreateTimeExtensionOptions,
  GetTimeExtensionIdOptions,
  QueryFnType,
  RequestApprovalDTO,
  TimeExtensionParams,
  UpdateTimeExtensionAcceptOptions,
  UpdateTimeExtensionBody,
} from "@/models/relationship-disclosure/TimeExtensionConflict";
import {
  CreateForwardConflictMngBody,
  CreateForwardConflictMngOptions,
  ForwardConflictMngSchemaI,
} from "@/models/relationship-disclosure/ForwardConflict";
import {
  CreateConfirmBody,
  CreateConfirmOptions,
  DeleteConfirmInformationOptions,
  DeleteFollowOptions,
  GetConfirmConflictDTO,
  GetConfirmConflictIdOptions,
  GetConfirmOptions,
  GetFollowOptions,
  QueryFnTypeConfirm,
} from "@/models/relationship-disclosure/ConfirmConflict";
import {
  CreateEvaluateBody,
  CreateEvaluateOptions,
} from "@/models/relationship-disclosure/EvaluateConflictManagement ";
import { RelationShipEvaluateList } from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import {
  CreateRequestApprovalBody,
  CreateRequestApprovalOptions,
} from "@/models/relationship-disclosure/RequestApproval";
import {
  CreateFinishConflictMngBody,
  CreateFinishConflictMngOptions,
  FinishConflictMngSchemaI,
  GetUserDefaultForFinishPopupOptions,
  GetUserDefaultForFinishPopupResponse,
  GetUserDefaultParams,
  QueryFnUserType,
} from "@/models/relationship-disclosure/FinishConflictMng";
import {
  CreateRequestAddInfoConflictBody,
  CreateRequestAdditionalOptions,
  RequestAdditionalSchemaI,
} from "@/models/relationship-disclosure/RequestAdditional";
import {
  CreateApproveBody,
  CreateApproveOptions,
  GetSignApprovalOptions,
  QueryFnCoflictType,
  ResponsesRecordSignApprovalDTO,
  SignApprovalParams,
} from "@/models/relationship-disclosure/SignApproval";
import {
  GET_CONFIRM_INFORMATION_MANAGEMENT,
  GET_FOLLOW_MANAGEMENT,
  RELATION_SHIP_DISCLOSURE,
} from "./relationshipDisclosureForm";
import {
  ConflictConfirmDetail,
  CreateFollowConflictMngBody,
  CreateFollowConflictMngOptions,
  FollowConflictMngSchemaI,
  QueryFollowManagementFnType,
} from "@/models/relationship-disclosure/FollowConflict";
import { SendMailConflictRequest } from "@/models/relationship-disclosure/SendMailConflict ";
import {
  CreateFeedbackConflictMngBody,
  CreateFeedbackConflictMngOptions,
  FeedbackConflictMngSchemaI,
} from "@/models/relationship-disclosure/Feedback";
import { ConflictMngStatisticChartResponse } from "@/models/conflict_management/ConflictManagementList";
import { GetRelationshipDisclosureListParams, GetRelationShipDisclosureListResponse } from "@/models/relationship-disclosure/RelationshipDisclosureList";
// const CONFLICT_MANAGEMENT = "declare-relationship";
const GET_CONFIRM_RELATION = "get_confirm_relation_popup";
const GET_EVALUATE_RELATION = "get_evaluate_relation_popup";
const GET_FOLLOW_RELATION = "get_follow_relation_popup";
// request improve information
export const createRequestInformationMutationFn = ({
  drId,
  data,
}: CreateRequestAddInfoConflictBody): Promise<RequestAdditionalSchemaI> => {
  return authApi.post(
    `/${RELATION_SHIP_DISCLOSURE}/${drId}/information-request`,
    data
  );
};

export const useCreateRequestInformation = ({
  config,
}: CreateRequestAdditionalOptions) => {
  return useMutation({
    ...config,
    mutationFn: createRequestInformationMutationFn,
  });
};
//forward
export const createForwardConflictMngMutationFn = ({
  lcsId,
  data,
}: CreateForwardConflictMngBody): Promise<ForwardConflictMngSchemaI> => {
  return authApi.post(`/${RELATION_SHIP_DISCLOSURE}/${lcsId}/forward`, data);
};

export const useCreateForwardRelationshipMng = ({
  config,
}: CreateForwardConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createForwardConflictMngMutationFn,
  });
};
//Request to extend time

export const GET_TIME_EXTENSION_ADVICE = "useGetTimeExtensionAdvice";

export const createTimeExtensionMutationFn = ({
  drId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/time-extension/request`,
    data
  );
};

export const useCreateTimeExtension = ({
  config,
}: CreateTimeExtensionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionMutationFn,
  });
};

export const getTimeExtensionQueryFn = async (
  request: TimeExtensionParams
): Promise<RequestApprovalDTO> => {
  const { drId, timeExtensionRequestId } = request;
  const response = await authApi.get(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/time-extension/${timeExtensionRequestId}`
  );
  return response.data.result;
};

export const useGetTimeExtension = ({
  config,
  request,
}: GetTimeExtensionIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_TIME_EXTENSION_ADVICE, request],
    queryFn: () => getTimeExtensionQueryFn(request),
  });
};

export const updateTimeExtensionMutationFn = async (
  request: UpdateTimeExtensionBody
): Promise<any> => {
  const { drId, timeExtensionRequestId, data } = request;
  const response = await authApi.post(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/time-extension/${timeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtension = ({
  config,
}: UpdateTimeExtensionAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionMutationFn,
  });
};

//Confirm conflict

export const createConfirmConflictMutationFn = ({
  drId,
  data,
}: CreateConfirmBody): Promise<any> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/confirm`, data);
};

export const useCreateConfirmRelationship = ({ config }: CreateConfirmOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createConfirmConflictMutationFn,
  });
};
// Get detail confirm conflict
export const getConfirmConflictQueryFn = async (request: {
  drId?: number;
  confirmId?: number;
}): Promise<GetConfirmConflictDTO> => {
  const { drId, confirmId } = request;
  const response = await authApi.get(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/confirm/${confirmId}`
  );
  return response.data.result;
};

export const useGetConfirmRelationship = ({
  config,
  request,
}: GetConfirmConflictIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeConfirm>>({
    ...config,
    queryKey: [GET_CONFIRM_RELATION, request],
    queryFn: () => getConfirmConflictQueryFn(request),
  });
};

// request evaluate

export const createRequestEvaluateConflictMutationFn = ({
  drId,
  data,
}: CreateConfirmBody): Promise<any> => {
  return authApi.post(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/evaluate/request`,
    data
  );
};

export const useCreateRequestEvaluateConflict = ({
  config,
}: CreateConfirmOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestEvaluateConflictMutationFn,
  });
};
// Evaluate_______________________________________
export const createEvaluateConflictMutationFn = ({
  drId,
  data,
}: CreateEvaluateBody): Promise<any> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/evaluate`, data);
};

export const useCreateEvaluateRelationship = ({
  config,
}: CreateEvaluateOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createEvaluateConflictMutationFn,
  });
};
// Get detail evaluate
export const getEvaluateConflictQueryFn = async (request: {
  drId?: number;
  evaluateId?: number;
}): Promise<RelationShipEvaluateList> => {
  const { drId, evaluateId } = request;
  const response = await authApi.get(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/evaluate/${evaluateId}`
  );
  return response.data.result;
};

export const useGetEvaluateConflict = ({ config, request }: any) => {
  return useQuery<ExtractFnReturnType<any>>({
    ...config,
    queryKey: [GET_EVALUATE_RELATION, request],
    queryFn: () => getEvaluateConflictQueryFn(request),
  });
};
// Approve request____________________________________
export const createRequestApproveConflictMutationFn = ({
  drId,
  data,
}: CreateRequestApprovalBody): Promise<any> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/approve/request`, data);
};

export const useCreateRequestApprovalRelationship = ({
  config,
}: CreateRequestApprovalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestApproveConflictMutationFn,
  });
};

//  Finish Conflict
export const createFinishConflictMngMutationFn = ({
  drId,
  data,
}: CreateFinishConflictMngBody): Promise<FinishConflictMngSchemaI> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/finish`, data);
};

export const useCreateFinishRelationship = ({
  config,
}: CreateFinishConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFinishConflictMngMutationFn,
  });
};
//::::::get user default
export const getUserDefaultQueryFn = async (
  params: GetUserDefaultParams
): Promise<GetUserDefaultForFinishPopupResponse> => {
  const response = await authApi.get(
    `${RELATION_SHIP_DISCLOSURE}/${params.conflictId}/finish/default-users`
  );
  return response.data.result.users;
};

export const useGetUserDefault = ({
  config,
  request,
}: GetUserDefaultForFinishPopupOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnUserType>>({
    ...config,
    queryKey: ["SignApproval", request],
    queryFn: () => getUserDefaultQueryFn(request),
  });
};
//Sign Approval
export const getSignApprovalQueryFn = async (
  request: SignApprovalParams
): Promise<ResponsesRecordSignApprovalDTO[]> => {
  const { drId } = request;
  const response = await authApi.get(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/approve/request`
  );
  return response.data.result.requestApproveResponses;
};

export const useGetRecordSignApproval = ({
  config,
  request,
}: GetSignApprovalOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnCoflictType>>({
    ...config,
    queryKey: ["SignApproval", request],
    queryFn: () => getSignApprovalQueryFn(request),
  });
};
// approve
export const createSignApproveConflictMutationFn = ({
  drId,
  data,
}: CreateApproveBody): Promise<any> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/approve`, data);
};

export const useCreateSignApproveRelationshipConflict = ({
  config,
}: CreateApproveOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createSignApproveConflictMutationFn,
  });
};
//Follow Theo dõi

// get list confirm information
export const getListConfirmInformationQueryFn = async (request: {
  drId: number;
}) => {
  const { drId } = request;
  const response = await authApi.get<any>(
    `/${RELATION_SHIP_DISCLOSURE}/${drId}/confirm`
  );

  return response?.data?.result;
};

export const useGetConfirmInformation = ({
  config,
  request,
}: GetConfirmOptions) => {
  return useQuery({
    ...config,
    queryKey: [GET_CONFIRM_INFORMATION_MANAGEMENT],
    queryFn: () => getListConfirmInformationQueryFn(request),
  });
};
// delete confirm information
export const deleteConfirmInformationMutationFn = async (bodyRequest: {
  drId: number;
  confirmId: number;
}): Promise<any> => {
  const { drId, confirmId } = bodyRequest;
  const response = await authApi.delete(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/confirm/${confirmId}`
  );

  return response.status;
};

export const useDeleteConfirmInformation = ({
  config,
}: DeleteConfirmInformationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteConfirmInformationMutationFn,
  });
};
// get list follow mng
export const getListFollowQueryFn = async (request: { drId: number }) => {
  const { drId } = request;
  const response = await authApi.get<any>(
    `/${RELATION_SHIP_DISCLOSURE}/${drId}/follow`
  );

  return response?.data?.result;
};

export const useGetFollowMng = ({ config, request }: GetFollowOptions) => {
  return useQuery({
    ...config,
    queryKey: [GET_FOLLOW_MANAGEMENT],
    queryFn: () => getListFollowQueryFn(request),
  });
};
// get detail follow conflict
export const getFollowConflictQueryFn = async (request: {
  drId?: number;
  followId?: number;
}): Promise<ConflictConfirmDetail> => {
  const { drId, followId } = request;
  const response = await authApi.get(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/follow/${followId}`
  );
  return response.data.result;
};

export const useGetFollowConflict = ({ config, request }: any) => {
  return useQuery<ExtractFnReturnType<QueryFollowManagementFnType>>({
    ...config,
    queryKey: [GET_FOLLOW_RELATION, request],
    queryFn: () => getFollowConflictQueryFn(request),
  });
};
// delete follow mng
export const deleteFollowMngMutationFn = async (bodyRequest: {
  drId: number;
  followId: number;
}): Promise<any> => {
  const { drId, followId } = bodyRequest;
  const response = await authApi.delete(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/follow/${followId}`
  );

  return response.status;
};

export const useDeleteFollowMng = ({ config }: DeleteFollowOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteFollowMngMutationFn,
  });
};
export const createFollowConflictMutationFn = ({
  drId,
  data,
}: CreateFollowConflictMngBody): Promise<FollowConflictMngSchemaI> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/follow`, data);
};

export const useCreateFollow = ({
  config,
}: CreateFollowConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFollowConflictMutationFn,
  });
};
//::::::get user default Follow
export const getUserDefaultFollowQueryFn = async (
  params: GetUserDefaultParams
): Promise<GetUserDefaultForFinishPopupResponse> => {
  const response = await authApi.get(
    `${RELATION_SHIP_DISCLOSURE}/${params.conflictId}/follow/default-users`
  );
  return response.data.result.users;
};

export const useGetUserDefaultFollow = ({
  config,
  request,
}: GetUserDefaultForFinishPopupOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnUserType>>({
    ...config,
    queryKey: ["follow_user_default", request],
    queryFn: () => getUserDefaultFollowQueryFn(request),
  });
};
//Recall
export interface RecallConflictOptions {
  config?: MutationConfig<typeof recallConflictMutationFn>;
}

export const recallConflictMutationFn = (drId?: number): Promise<any> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/recall`);
};

export const useRecallConflict = ({ config }: RecallConflictOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: recallConflictMutationFn,
  });
};
//send mail
export const sendMailConflict = async (params: {
  id: number;
  request: SendMailConflictRequest;
}) => {
  const requestFormat = {
    ...params.request,
  };
  const response = await authApi.post(
    `${RELATION_SHIP_DISCLOSURE}/${params.id}/sendmail`,
    requestFormat
  );
  return response.status;
};
// FeedBack
export const createFeedbackConflictMutationFn = ({
  data,
  drId,
}: CreateFeedbackConflictMngBody): Promise<FeedbackConflictMngSchemaI> => {
  return authApi.post(`${RELATION_SHIP_DISCLOSURE}/${drId}/feedback`, data);
};

export const useCreateFeedbackRelationship = ({
  config,
}: CreateFeedbackConflictMngOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackConflictMutationFn,
  });
};
// chart
export const getRelationshipMngStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<ConflictMngStatisticChartResponse>
  >(`/${RELATION_SHIP_DISCLOSURE}/statistic/chart`);
  return response.data.result;
};
export const getStatisticTableFn = async (params: GetRelationshipDisclosureListParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetRelationShipDisclosureListResponse>
  >(`/${RELATION_SHIP_DISCLOSURE}/statistic/table`, {
    params: params,
  });
  return response.data.result;
};

export const getStatisticTableDoneFn = async (
  params: GetRelationshipDisclosureListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<GetRelationShipDisclosureListResponse>
  >(`/${RELATION_SHIP_DISCLOSURE}/statistic/table/done`, {
    params: params,
  });
  return response.data.result;
};