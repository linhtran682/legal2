import { authApi, ExtractFnReturnType, ResponseWrapper } from "@/apis";
import { GetLegalDocumentTabAttachmentsResponse } from "@/models/law_document/LegalDocumentAttachment";
import {
  GetHistoryResponse,
  GetInformationRequestsResponse,
} from "@/models/metadata/Metadata";
import {
  CreateRelationShipDisclosureOptions,
  DeleteEvaluateIdOptions,
  GetListRelationShipEvaluateResponse,
  GetRelationShipApprovalResponse,
  GetRelationShipDisclosureOptions,
  GetRelationShipEvaluateTabResponse,
  GetRelationShipExtensionResponse,
  GetRelationShipForwardResponse,
  GetRelationShipRequestFeedbackResponse,
  QueryRelationShipDisclosureFnType,
  RelationshipDisclosureBodyReceive,
  RelationshipDisclosureBodySend,
  RelationShipDisclosureParams,
  UpdateBookMeetingRelationShipDisclosureOptions,
  UpdateRelationShipDisclosureOptions,
  UpdateRelationShipDisclosureRequest,
} from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import {
  GetRelationshipDisclosureListParams,
  GetRelationShipDisclosureListResponse,
} from "@/models/relationship-disclosure/RelationshipDisclosureList";
import { useMutation, useQuery } from "@tanstack/react-query";

export const RELATION_SHIP_DISCLOSURE = "declare-relationship";
export const GET_INITIAL_RELATION_SHIP = "get_initial_relation_ship_disclosure";
export const GET_EVALUATE_COMMENT_LIST = "get_evaluate_comment_list";
export const GET_CONFIRM_INFORMATION_MANAGEMENT =
  "get_confirm_information_management";
export const GET_FOLLOW_MANAGEMENT = "get_follow_management";
const FILE = "files";

export const getRelationShipDisclosureExcel = async (
  params: GetRelationshipDisclosureListParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${RELATION_SHIP_DISCLOSURE}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getAllHierarchyById = async (params: { id: number | string }) => {
  const response = await authApi.get(
    `/${RELATION_SHIP_DISCLOSURE}/${params.id}/all-hierarchy`
  );
  return response.data?.result;
};

export const getListRelationShipDisclosureQueryFn = async (
  params: GetRelationshipDisclosureListParams
): Promise<GetRelationShipDisclosureListResponse> => {
  const response = await authApi.get(RELATION_SHIP_DISCLOSURE, { params });
  return response.data.result;
};

export const getRelationShipDisclosureQueryFn = async (
  request: RelationShipDisclosureParams
): Promise<RelationshipDisclosureBodyReceive> => {
  const { id } = request;
  const response = await authApi.get(`${RELATION_SHIP_DISCLOSURE}/${id}`);
  return response.data.result;
};

export const useGetRelationShipDisclosure = ({
  config,
  request,
}: GetRelationShipDisclosureOptions) => {
  return useQuery<ExtractFnReturnType<QueryRelationShipDisclosureFnType>>({
    ...config,
    queryKey: [GET_INITIAL_RELATION_SHIP],
    queryFn: () => getRelationShipDisclosureQueryFn(request),
  });
};

export const createRelationShipDisclosureMutationFn = async (
  data: RelationshipDisclosureBodySend
): Promise<any> => {
  const response = await authApi.post(RELATION_SHIP_DISCLOSURE, data);
  return response.status;
};

export const useCreateRelationShipDisclosure = ({
  config,
}: CreateRelationShipDisclosureOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRelationShipDisclosureMutationFn,
  });
};

export const updateRelationShipDisclosureMutationFn = async (
  bodyRequest: UpdateRelationShipDisclosureRequest
): Promise<any> => {
  const { id, request } = bodyRequest;
  const response = await authApi.put(
    `${RELATION_SHIP_DISCLOSURE}/${id}`,
    request
  );

  return response.status;
};

export const useUpdateRelationShipDisclosure = ({
  config,
}: UpdateRelationShipDisclosureOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateRelationShipDisclosureMutationFn,
  });
};

export const updateBookMeetingRelationShipDisclosureMutationFn =
  async (params: {
    relationshipId?: number;
    request: {
      isBookMeeting: boolean;
    };
  }) => {
    const response = await authApi.post(
      `${RELATION_SHIP_DISCLOSURE}/${params.relationshipId}/book-meeting`,
      params.request
    );
    return response.status;
  };

export const useUpdateBookMeetingRelationshipId = ({
  config,
}: UpdateBookMeetingRelationShipDisclosureOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateBookMeetingRelationShipDisclosureMutationFn,
  });
};

export const getRelationShipDisclosureInformationRequests = async (
  drId: number
) => {
  const response = await authApi.get<GetInformationRequestsResponse>(
    `/${RELATION_SHIP_DISCLOSURE}/${drId}/information-request`
  );

  return response.data;
};
export const getRelationShipDisclosureEvaluateTab = async (drId: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetRelationShipEvaluateTabResponse>
  >(`/${RELATION_SHIP_DISCLOSURE}/${drId}/evaluate/tab`);

  return response.data;
};

export const getListRelationShipDisclosureEvaluate = async (drId: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetListRelationShipEvaluateResponse>
  >(`/${RELATION_SHIP_DISCLOSURE}/${drId}/evaluate`);

  return response.data;
};
// delete evaluate
export const deleteEvaluateMngMutationFn = async (bodyRequest: {
  drId: number;
  evaluateId: number;
}): Promise<any> => {
  const { drId, evaluateId } = bodyRequest;
  const response = await authApi.delete(
    `${RELATION_SHIP_DISCLOSURE}/${drId}/evaluate/${evaluateId}`
  );

  return response.status;
};

export const useDeleteEvaluateMng = ({
  config,
}: DeleteEvaluateIdOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteEvaluateMngMutationFn,
  });
};

export const getRelationShipDisclosureApproval = async (drId: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetRelationShipApprovalResponse>
  >(`/${RELATION_SHIP_DISCLOSURE}/${drId}/approve/request`);

  return response.data;
};

export const getRelationShipDisclosureExtensions = async (drId: number) => {
  const response = await authApi.get<GetRelationShipExtensionResponse>(
    `/${RELATION_SHIP_DISCLOSURE}/${drId}/time-extension`
  );
  return response.data;
};

export const getRelationShipDisclosureRequestFeedback = async (
  drId: number
) => {
  const response = await authApi.get<GetRelationShipRequestFeedbackResponse>(
    `/${RELATION_SHIP_DISCLOSURE}/${drId}/feedback`
  );
  return response.data;
};

export const getRelationShipDisclosureAttachment = async (
  id: number,
  referenceFileTypes?: number
) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalDocumentTabAttachmentsResponse>
  >(`${FILE}/${id}/attachment-tab`, { params: { referenceFileTypes } });
  return response.data.result;
};

export const getRelationShipDisclosureForwards = async (lcsId: number) => {
  const response = await authApi.get<GetRelationShipForwardResponse>(
    `/${RELATION_SHIP_DISCLOSURE}/${lcsId}/forward`
  );

  return response.data;
};

export const getRelationShipDisclosureHistory = async (
  relationshipId: number
) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${RELATION_SHIP_DISCLOSURE}/${relationshipId}/history`
  );
  return response.data;
};

export const shareRelationshipDisclosureFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number;
  };
}) => {
  const response = await authApi.post(
    `/${RELATION_SHIP_DISCLOSURE}/${params.id}/share`,
    params.data
  );

  return response.data;
};
