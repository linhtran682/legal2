import { authApi, ExtractFnReturnType } from "@/apis";
import {
  CreateRequestAdditionalBody,
  CreateRequestAdditionalOptions,
  GetRequestAdditionalIdOptions,
  QueryFnType,
  RequestAdditionalDTO,
  RequestAdditionalParams,
  RequestAdditionalSchemaI,
} from "@/models/document-review/RequestAdditional";
import { useMutation, useQuery } from "@tanstack/react-query";
import { LCS_URL } from "./legalCheckSheet";
import { GetInformationRequestsResponse } from "@/models/metadata/Metadata";

const URL = "request-review-document";
const GET_REQUEST_ADDITIONAL_ADVICE = "getDocumentReviewRequestInformation";

export const createRequestAdditionalMutationFn = ({
  documentReviewId,
  data,
}: CreateRequestAdditionalBody): Promise<RequestAdditionalSchemaI> => {
  return authApi.post(`${URL}/${documentReviewId}/information-request`, data);
};

export const useCreateRequestAdditional = ({
  config,
}: CreateRequestAdditionalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestAdditionalMutationFn,
  });
};

export const getRequestAdditionalQueryFn = async (
  request: RequestAdditionalParams
): Promise<RequestAdditionalDTO> => {
  const { legalAdviceId, informationRequestId } = request;
  const response = await authApi.get(
    `${URL}/${legalAdviceId}/information-request/${informationRequestId}`
  );
  return response.data.result;
};

export const useGetRequestAdditional = ({
  config,
  request,
}: GetRequestAdditionalIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_REQUEST_ADDITIONAL_ADVICE, request],
    queryFn: () => getRequestAdditionalQueryFn(request),
  });
};

/**
 * LCS
 */
export const createLcsInformationRequestFn = async (params: {
  lcsId: number;
  request: RequestAdditionalSchemaI;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/information-request`,
    params.request
  );
  return response.status;
};

export const getLcsInformationRequests = async (id: number) => {
  const response = await authApi.get<GetInformationRequestsResponse>(
    `/${LCS_URL}/${id}/information-request`
  );

  return response.data;
};
