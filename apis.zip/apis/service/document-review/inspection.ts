import { authApi, ResponseWrapper } from "@/apis";
import {
  CreateInspectionFeedbackRequest,
  CreateInspectionRequest,
  DocumentReviewInspectionItem,
  DocumentReviewInspectionListResponse,
} from "@/models/document-review/Inspection";

const URL = "request-review-document";

export const getInspectionList = async (id: number) => {
  const response = await authApi.get<DocumentReviewInspectionListResponse>(
    `/${URL}/${id}/inspection`
  );
  return response.data;
};

export const getInspectionDetailQueryFn = async (params: {
  documentReviewId: number;
  inspectionId: number;
}) => {
  const response = await authApi.get<
    ResponseWrapper<DocumentReviewInspectionItem>
  >(`/${URL}/${params.documentReviewId}/inspection/${params.inspectionId}`);
  return response.data.result;
};

export const createInspectionMutationFn = (params: {
  id: number;
  request: CreateInspectionRequest;
}) => {
  return authApi.post(`/${URL}/${params.id}/inspection`, params.request);
};
export const createInspectionFeedbackMutationFn = (params: {
  id: number;
  request: CreateInspectionFeedbackRequest;
}) => {
  return authApi.put(`/${URL}/${params.id}/inspection`, params.request);
};

export const updateInspectionMutationFn = (params: {
  documentReviewId: number;
  inspectionId: number;
  request: CreateInspectionRequest;
}) => {
  return authApi.put(
    `/${URL}/${params.documentReviewId}/inspection/${params.inspectionId}/update`,
    params.request
  );
};
