import { authApi, MutationConfig } from "@/apis";
import { useMutation } from "@tanstack/react-query";

const LEGAL_ADVICE = "legal-advice";

export interface ConfirmLegalAdviceOptions {
  config?: MutationConfig<typeof confirmAdviceMutationFn>;
}

export const confirmAdviceMutationFn = (
  legalAdviceId?: number
): Promise<any> => {
  return authApi.post(`${LEGAL_ADVICE}/${legalAdviceId}/confirm`);
};

export const useConfirmLegalAdvice = ({
  config,
}: ConfirmLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: confirmAdviceMutationFn,
  });
};
