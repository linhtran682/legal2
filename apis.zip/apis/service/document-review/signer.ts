import { authApi, ResponseWrapper } from "@/apis";
import { TabSignerResponse } from "@/models/document-review/Signer";

const LCS_URL = "legal-check-sheet";

/**
 * Tab Signer ký
 * @param lcsId
 * @returns
 */
export const getSignerTab = async (lcsId: number) => {
  const response = await authApi.get<ResponseWrapper<TabSignerResponse>>(
    `${LCS_URL}/${lcsId}/signer`
  );
  return response.data.result;
};

// Yêu cầu ký duyệt
export const createRequestSignAndApproveFn = async (params: {
  lcsId: number;
  request: any;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/signer/request`,
    params.request
  );
  return response.status;
};

// Ký duyệt
export const createSignAndApproveFn = async (params: {
  lcsId: number;
  request: any;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/signer`,
    params.request
  );
  return response.status;
};
