import { authApi } from "@/apis";
import {
  CreateEvaluateBody,
  CreateFeedbackEvaluateBody,
  CreateRequestEvaluateBody,
} from "@/models/document-review/LcsEvaluate";
import { LCS_URL } from "./legalCheckSheet";

export const getEvaluationTabFn = async (lcsId: number) => {
  const response = await authApi.get(`${LCS_URL}/${lcsId}/evaluate`);
  return response.data;
};

export const createRequestEvaluateFn = async (params: {
  lcsId: number;
  request: CreateRequestEvaluateBody;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/evaluate/request`,
    params.request
  );
  return response.status;
};

export const createEvaluateFn = async (params: {
  lcsId: number;
  request: CreateEvaluateBody;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/evaluate`,
    params.request
  );
  return response.status;
};

export const createFeedbackEvaluateFn = async (params: {
  lcsId: number;
  request: CreateFeedbackEvaluateBody;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/evaluate/feedback`,
    params.request
  );
  return response.status;
};
