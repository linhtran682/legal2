import { authApi } from "@/apis";
import {
  CreateFeedbackDocumentReviewBody,
  CreateFeedbackLcBody,
  CreateFeedbackOptions,
  FeedbackSchemaI,
} from "@/models/document-review/Feedback";
import { useMutation } from "@tanstack/react-query";
import { DOCUMENT_REVIEW_URL } from "./documentReview";
import { LCS_URL } from "./legalCheckSheet";

export const createFeedbackDocumentReviewMutationFn = ({
  documentReviewId,
  data,
}: CreateFeedbackDocumentReviewBody): Promise<FeedbackSchemaI> => {
  return authApi.post(
    `${DOCUMENT_REVIEW_URL}/${documentReviewId}/feedback`,
    data
  );
};

export const getFeedbackTabFn = async (documentReviewId: number) => {
  const response = await authApi.get(
    `${DOCUMENT_REVIEW_URL}/${documentReviewId}/feedback`
  );
  return response.data;
};

export const useCreateFeedbackDocumentReview = ({
  config,
}: CreateFeedbackOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackDocumentReviewMutationFn,
  });
};

/**
 * LCS
 */
export const createLcsFeedbackFn = async (params: {
  lcsId: number;
  request: CreateFeedbackLcBody;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/feedback`,
    params.request
  );
  return response.status;
};

export const createLcsFeedbackLcFn = async (params: {
  lcsId: number;
  request: CreateFeedbackLcBody;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/feedback/feedback-lc`,
    params.request
  );
  return response.status;
};

export const getFeedbackLcsTabFn = async (lcsId: number) => {
  const response = await authApi.get(`${LCS_URL}/${lcsId}/feedback`);
  return response.data;
};
