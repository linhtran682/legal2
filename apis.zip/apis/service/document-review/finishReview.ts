import { authApi } from "@/apis";
import { FinishReviewRequest } from "@/models/document-review/FinishReview";
import { LCS_URL } from "./legalCheckSheet";

const URL = "request-review-document";

export const finishReviewMutationFn = async ({
  documentReviewId,
  data,
}: {
  documentReviewId: number;
  data: FinishReviewRequest;
}) => {
  const requestFormat = {
    ...data,
  };
  const response = await authApi.post(
    `${URL}/${documentReviewId}/finish`,
    requestFormat
  );
  return response.status;
};

export const finishAllMutationFn = async ({
  lcsId,
  data,
}: {
  lcsId: number;
  data: FinishReviewRequest;
}) => {
  const requestFormat = {
    ...data,
  };
  const response = await authApi.put(
    `${LCS_URL}/${lcsId}/finish`,
    requestFormat
  );
  return response.status;
};
