import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  CreateTimeExtensionBody,
  CreateTimeExtensionOptions,
  GetLcsTimeExtensionIdOptions,
  GetReviewExtensionResponse,
  GetTimeExtensionIdOptions,
  LcsTimeExtensionParams,
  QueryFnType,
  RequestApprovalDTO,
  TimeExtensionParams,
  UpdateTimeExtensionAcceptOptions,
  UpdateTimeExtensionBody,
} from "@/models/document-review/TimeExtension";
import { LCS_URL } from "./legalCheckSheet";

const URL = "request-review-document";
// const URL_2 = "request_review_document";

export const GET_TIME_EXTENSION_ADVICE = "useGetTimeExtensionReview";

export const createTimeExtensionMutationFn = ({
  documentReviewId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(`${URL}/${documentReviewId}/time-extension`, data);
};

export const useCreateTimeExtension = ({
  config,
}: CreateTimeExtensionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionMutationFn,
  });
};

export const getTimeExtensionList = async (
  documentReviewId: number
): Promise<GetReviewExtensionResponse> => {
  const response = await authApi.get(
    `${URL}/${documentReviewId}/time-extension`
  );
  return response.data;
};

export const getTimeExtensionQueryFn = async (
  request: TimeExtensionParams
): Promise<RequestApprovalDTO> => {
  const { documentReviewId, timeExtensionRequestId } = request;
  const response = await authApi.get(
    `${URL}/${documentReviewId}/time-extension/${timeExtensionRequestId}`
  );
  return response.data.result;
};

export const useGetTimeExtension = ({
  config,
  request,
}: GetTimeExtensionIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_TIME_EXTENSION_ADVICE, request],
    queryFn: () => getTimeExtensionQueryFn(request),
  });
};

export const getLcsTimeExtensionQueryFn = async (
  request: LcsTimeExtensionParams
): Promise<RequestApprovalDTO> => {
  const { lcsId, lcsTimeExtensionRequestId } = request;
  const response = await authApi.get(
    `${LCS_URL}/${lcsId}/time-extension/${lcsTimeExtensionRequestId}`
  );
  return response.data.result;
};

export const useLcsGetTimeExtension = ({
  config,
  request,
}: GetLcsTimeExtensionIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [`${GET_TIME_EXTENSION_ADVICE}-lcs`, request],
    queryFn: () => getLcsTimeExtensionQueryFn(request),
  });
};

export const updateTimeExtensionMutationFn = async (
  request: UpdateTimeExtensionBody
): Promise<any> => {
  const { documentReviewId, timeExtensionRequestId, data } = request;
  const response = await authApi.put(
    `${URL}/${documentReviewId}/time-extension/${timeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtension = ({
  config,
}: UpdateTimeExtensionAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionMutationFn,
  });
};

/**
 * LCS
 */

export const createLcsTimeExtensionMutationFn = ({
  lcsId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(`${LCS_URL}/${lcsId}/time-extension`, data);
};

export const updateLcsTimeExtensionMutationFn = async (
  request: UpdateTimeExtensionBody
): Promise<any> => {
  const { lcsId, lcsTimeExtensionRequestId, data } = request;
  const response = await authApi.put(
    `${LCS_URL}/${lcsId}/time-extension/${lcsTimeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const getLcsTimeExtensionList = async (
  documentReviewId: number
): Promise<GetReviewExtensionResponse> => {
  const response = await authApi.get(
    `${LCS_URL}/${documentReviewId}/time-extension`
  );
  return response.data;
};
