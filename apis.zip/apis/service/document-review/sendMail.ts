import { authApi } from "@/apis";
import { SendMailRequest } from "@/models/document-review/SendMail";

const URL = "request-review-document";
export const sendMailDocumentReview = async (params: {
  id: number;
  request: SendMailRequest;
}) => {
  const requestFormat = {
    ...params.request,
  };
  const response = await authApi.post(
    `${URL}/${params.id}/sendMail`,
    requestFormat
  );
  return response.status;
};
