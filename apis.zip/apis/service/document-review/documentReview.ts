import { authApi, ResponseWrapper } from "@/apis";
import {
  DocumentReviewBodyReceive,
  DocumentReviewBodySend,
} from "@/models/document-review/DocumentReviewDetail";
import {
  DocumentReviewListResponse,
  GetDocumentReviewListParams,
} from "@/models/document-review/DocumentReviewList";
import { GetLegalDocumentTabAttachmentsResponse } from "@/models/law_document/LegalDocumentAttachment";
import {
  GetAdviceAssignmentResponse,
  GetAdviceExtensionResponse,
  GetAdviceRequestFeedbackResponse,
  GetAdviseFeedbackResponse,
  LegalAdviceStatisticChartResponse,
} from "@/models/legal-advice/LegalAdviceList";
import {
  GetCommentsResponse,
  GetHistoryResponse,
  GetInformationRequestsResponse,
  GetMeetingResponse,
} from "@/models/metadata/Metadata";

export const DOCUMENT_REVIEW_URL = "request-review-document";

export const getDocumentReviewRequests = async (
  params: GetDocumentReviewListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<DocumentReviewListResponse>
  >(DOCUMENT_REVIEW_URL, {
    params: params,
  });
  return response.data.result;
};

export const getDocumentReviewById = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<
    ResponseWrapper<DocumentReviewBodyReceive>
  >(`${DOCUMENT_REVIEW_URL}/${id}`);
  return response.data.result;
};

export const getAllHierarchyById = async (params: { id: number | string }) => {
  const response = await authApi.get(
    `/${DOCUMENT_REVIEW_URL}/${params.id}/all-hierarchy`
  );
  return response.data?.result;
};

export const createDocumentReview = async (request: DocumentReviewBodySend) => {
  const requestFormat = {
    ...request,
  };
  const response = await authApi.post(DOCUMENT_REVIEW_URL, requestFormat);
  return response.status;
};

export const updateDocumentReview = async (updateProps: {
  request: DocumentReviewBodySend;
  id: number;
}) => {
  const response = await authApi.put(
    `${DOCUMENT_REVIEW_URL}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const getDocumentReviewExcel = async (
  params: GetDocumentReviewListParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${DOCUMENT_REVIEW_URL}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getDocumentReviewComments = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetCommentsResponse>>(
    `/${DOCUMENT_REVIEW_URL}/${id}/comment`
  );
  return response.data;
};

export const commentDocumentReview = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${DOCUMENT_REVIEW_URL}/${params.id}/comment`,
    {
      content: params.content,
    }
  );
  return response.data;
};
export const confirmDocumentReviewMutationFn = async (id: number) => {
  const response = await authApi.post(`/${DOCUMENT_REVIEW_URL}/${id}/confirm`);
  return response.data;
};

export const getDocumentReviewInformationRequests = async (id: number) => {
  const response = await authApi.get<GetInformationRequestsResponse>(
    `/${DOCUMENT_REVIEW_URL}/${id}/information-request`
  );

  return response.data;
};

export const getDocumentReviewHistory = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${DOCUMENT_REVIEW_URL}/${id}/history`
  );
  return response.data;
};

export const getDocumentReviewAssignments = async (id: number) => {
  const response = await authApi.get<GetAdviceAssignmentResponse>(
    `/${DOCUMENT_REVIEW_URL}/${id}/assigment`
  );
  return response.data;
};

export const getDocumentReviewExtensions = async (id: number) => {
  const response = await authApi.get<GetAdviceExtensionResponse>(
    `/${DOCUMENT_REVIEW_URL}/${id}/time-extension`
  );
  return response.data;
};

export const getDocumentReviewRequestFeedback = async (id: number) => {
  const response = await authApi.get<GetAdviceRequestFeedbackResponse>(
    `/${DOCUMENT_REVIEW_URL}/${id}/feedback`
  );
  return response.data;
};

export const getAdviseFeedbacks = async (id: number) => {
  const response = await authApi.get<GetAdviseFeedbackResponse>(
    `/${DOCUMENT_REVIEW_URL}/${id}/advise/tab`
  );
  return response.data;
};

export const getDocumentReviewAttachment = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalDocumentTabAttachmentsResponse>
  >(`${DOCUMENT_REVIEW_URL}/${id}/attachment-tab`);
  return response.data.result;
};

export const updateBookMeeting = async (params: {
  documentReviewId?: number;
  request: {
    isBookMeeting: boolean;
  };
}) => {
  const response = await authApi.put(
    `${DOCUMENT_REVIEW_URL}/${params.documentReviewId}/book-meeting`,
    params.request
  );

  return response.status;
};

export const recallDocumentReviewFn = async (id: number) => {
  const response = await authApi.post(`${DOCUMENT_REVIEW_URL}/${id}/recall`);
  return response.status;
};

export const shareDocumentReviewFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number; // TODO: field name
  };
}) => {
  const response = await authApi.post(
    `/${DOCUMENT_REVIEW_URL}/${params.id}/share`,
    params.data
  );

  return response.data;
};

export const cloneDocumentReviewRequestFn = async (params: {
  id: number;
  data: {
    childStatus: number;
    status: number;
  };
}) => {
  const response = await authApi.post(
    `/${DOCUMENT_REVIEW_URL}/${params.id}/clone`,
    params.data
  );

  return response.data;
};

export const getDrrmMeeting = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetMeetingResponse>>(
    `/${DOCUMENT_REVIEW_URL}/${id}/meeting-new`
  );

  return response.data;
};

export const createDrrmMeeting = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${DOCUMENT_REVIEW_URL}/${params.id}/meeting-new`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const updateDrrmMeeting = async (params: {
  id: number;
  meetingId: number;
  content: string;
}) => {
  const response = await authApi.put(
    `/${DOCUMENT_REVIEW_URL}/${params.id}/meeting-new/${params.meetingId}`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const deleteDrrmMeeting = async (params: {
  id: number;
  meetingId: number;
}) => {
  const response = await authApi.delete(
    `/${DOCUMENT_REVIEW_URL}/${params.id}/meeting-new/${params.meetingId}`
  );
  return response.data;
};

export const getStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<LegalAdviceStatisticChartResponse>
  >(`/${DOCUMENT_REVIEW_URL}/statistic/chart`);
  return response.data.result;
};
export const getStatisticTableFn = async (
  params: GetDocumentReviewListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<DocumentReviewListResponse>
  >(`/${DOCUMENT_REVIEW_URL}/statistic/table`, {
    params: params,
  });
  return response.data.result;
};
export const getStatisticTableDoneFn = async (
  params: GetDocumentReviewListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<DocumentReviewListResponse>
  >(`/${DOCUMENT_REVIEW_URL}/statistic/table/done`, {
    params: params,
  });
  return response.data.result;
};
export const getStatisticTableBackdateFn = async (
  params: GetDocumentReviewListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<DocumentReviewListResponse>
  >(`/${DOCUMENT_REVIEW_URL}/statistic/table/backdate`, {
    params: params,
  });
  return response.data.result;
};
export const getStatisticTableRequestBackdateFn = async (
  params: GetDocumentReviewListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<DocumentReviewListResponse>
  >(`/${DOCUMENT_REVIEW_URL}/statistic/table/request-backdate`, {
    params: params,
  });
  return response.data.result;
};
