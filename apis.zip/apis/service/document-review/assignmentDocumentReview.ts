import { authApi } from "@/apis";

import {
  CreateAssignmentDocumentReviewBody,
  GetReviewAssignmentResponse,
} from "@/models/document-review/AssignmentDocumentReview";
import { LCS_URL } from "./legalCheckSheet";

const URL = "request-review-document";

export const createAssignmentDocumentReviewMutationFn = ({
  documentReviewId,
  data,
}: CreateAssignmentDocumentReviewBody) => {
  return authApi.post(`${URL}/${documentReviewId}/assigment`, data);
};

export const getDocumentReviewAssignments = async (id: number) => {
  const response = await authApi.get<GetReviewAssignmentResponse>(
    `/${URL}/${id}/assigment`
  );
  return response.data;
};

/*
 * LCS
 */
export const createAssignmentLcsMutationFn = ({
  lcsId,
  data,
}: CreateAssignmentDocumentReviewBody) => {
  return authApi.post(`${LCS_URL}/${lcsId}/assigment`, data);
};

export const getLcsAssignments = async (id: number) => {
  const response = await authApi.get<GetReviewAssignmentResponse>(
    `/${LCS_URL}/${id}/assigment`
  );
  return response.data;
};
