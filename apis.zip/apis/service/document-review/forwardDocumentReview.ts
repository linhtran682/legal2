import { authApi } from "@/apis";
import { ForwardDocumentReviewRequest } from "@/models/document-review/ForwardDocumentReview";
import { GetAdviceForwardResponse } from "@/models/legal-advice/LegalAdviceList";
import { LCS_URL } from "./legalCheckSheet";

const URL = "request-review-document";

export const forwardDocumentReviewFn = (params: {
  id: number;
  request: ForwardDocumentReviewRequest;
}) => {
  return authApi.post(`/${URL}/${params.id}/forward`, params.request);
};

export const getDocumentReviewForwards = async (id: number) => {
  const response = await authApi.get<GetAdviceForwardResponse>(
    `/${URL}/${id}/forward`
  );
  return response.data;
};

/**
 * LCS
 */

export const forwardLcsFn = (params: {
  lcsId: number;
  request: ForwardDocumentReviewRequest;
}) => {
  return authApi.post(`/${LCS_URL}/${params.lcsId}/forward`, params.request);
};

export const getLcsForwards = async (lcsId: number) => {
  const response = await authApi.get<GetAdviceForwardResponse>(
    `/${LCS_URL}/${lcsId}/forward`
  );
  return response.data;
};
