import { authApi } from "@/apis";
import {
  CreateRequestVendorBody,
  CreateRequestVendorOptions,
  RequestVendorSchemaI,
} from "@/models/document-review/RequestVendorReview";
import { useMutation } from "@tanstack/react-query";

const URL = "request-review-document";

export const createRequestVendorMutationFn = ({
  documentReviewId,
  data,
}: CreateRequestVendorBody): Promise<RequestVendorSchemaI> => {
  return authApi.post(`${URL}/${documentReviewId}/request-vendor`, data);
};

export const useCreateRequestVendor = ({
  config,
}: CreateRequestVendorOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestVendorMutationFn,
  });
};
