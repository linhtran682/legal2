import { authApi, ResponseWrapper } from "@/apis";
import { FinishReviewRequest } from "@/models/document-review/FinishReview";
import {
  LcsFileIdBody,
  LcsSignerListResponse,
  LegalCheckSheetBodyReceive,
  LegalCheckSheetBodySend,
  SpPermissionResponse,
} from "@/models/document-review/LegalCheckSheet";
import { SendMailRequest } from "@/models/document-review/SendMail";
import {
  GetCommentsResponse,
  GetHistoryResponse,
} from "@/models/metadata/Metadata";

export const LCS_URL = "legal-check-sheet";

export const createLcs = async (request: LegalCheckSheetBodySend) => {
  const response = await authApi.post(LCS_URL, request);
  return response.status;
};

export const createDraftLcs = async (request: LegalCheckSheetBodySend) => {
  const response = await authApi.post(`${LCS_URL}/draft`, request);
  return response.status;
};

export const getLcsById = async (lcsId: number) => {
  const response = await authApi.get<
    ResponseWrapper<LegalCheckSheetBodyReceive>
  >(`${LCS_URL}/${lcsId}`);
  return response.data.result;
};

export const getLcsDefaultSignerList = async (lcsId: number) => {
  const response = await authApi.get<ResponseWrapper<LcsSignerListResponse>>(
    `${LCS_URL}/${lcsId}/signers`
  );
  return response.data.result;
};

export const updateLcs = async (params: {
  lcsId: number;
  request: LegalCheckSheetBodySend;
}) => {
  const response = await authApi.put(
    `${LCS_URL}/${params.lcsId}`,
    params.request
  );
  return response.status;
};

export const callToEsign = async (params: {
  lcsId: number;
  position: number;
  data: {
    message?: string;
  };
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/call-esign/${params.position}`,
    params.data
  );
  return response.status;
};

export const recallTobeSign = async (params: {
  lcsId: number;
  tobeSignId: number;
}) => {
  const response = await authApi.put(
    `${LCS_URL}/${params.lcsId}/call-esign/${params.tobeSignId}`
  );
  return response.status;
};

export const confirmLcs = async (lcsId: number) => {
  const response = await authApi.post(`${LCS_URL}/${lcsId}/confirm`);
  return response.status;
};

export const finishLcs = async (params: {
  lcsId: number;
  request: FinishReviewRequest;
}) => {
  const response = await authApi.put(
    `${LCS_URL}/${params.lcsId}/finish`,
    params.request
  );
  return response.status;
};

export const callToMeetingLcs = async (lcsId: number) => {
  const response = await authApi.post(`${LCS_URL}/${lcsId}/meeting`);
  return response.status;
};

export const recallLcs = async (lcsId: number) => {
  const response = await authApi.post(`${LCS_URL}/${lcsId}/recall`);
  return response.status;
};

export const sendMailLcs = async (params: {
  lcsId: number;
  request: SendMailRequest;
}) => {
  const response = await authApi.post(
    `${LCS_URL}/${params.lcsId}/sendMail`,
    params.request
  );
  return response.status;
};

/*
 * Others common apis
 */

export const getLcsComments = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetCommentsResponse>>(
    `/${LCS_URL}/${id}/comment`
  );
  return response.data;
};

export const commentLcs = async (params: { id: number; content: string }) => {
  const response = await authApi.post(`/${LCS_URL}/${params.id}/comment`, {
    content: params.content,
  });
  return response.data;
};

export const getLcsHistory = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${LCS_URL}/${id}/history`
  );
  return response.data;
};
export const getLcsPdfFile = async (id: number, data: LcsFileIdBody) => {
  const response = await authApi.post<
    ResponseWrapper<{
      name: string;
      url: string;
    }>
  >(`/${LCS_URL}/${id}/pdf`, data);

  return response.data.result;
};

export const uploadCurrentFileToSharepoint = async ({
  lcsId,
  fileId,
}: {
  lcsId: number;
  fileId: number;
}) => {
  const response = await authApi.post(
    `/files/${LCS_URL}/${lcsId}/sharepoint/${fileId}`
  );
  return response.data.result;
};

export const checkSharePointPermissionFn = async () => {
  const response = await authApi.get<ResponseWrapper<SpPermissionResponse>>(
    `${LCS_URL}/check-sharepoint`
  );
  return response.data.result;
};

export const addFilesToLcsFn = async (id: number, data: LcsFileIdBody) => {
  const response = await authApi.post<ResponseWrapper<SpPermissionResponse>>(
    `/files/${LCS_URL}/${id}`,
    data
  );
  return response.data.result;
};

export const cloneLcsFn = async (id: number) => {
  const response = await authApi.post(`/${LCS_URL}/${id}/clone`);
  return response.data;
};
