import { authApi } from "@/apis";
import {
  CreateFeedbackLegalAdviceBody,
  CreateFeedbackLegalAdviceOptions,
  FeedbackLegalAdviceSchemaI,
} from "@/models/legal-advice/FeedbackLegalAdvice";
import { useMutation } from "@tanstack/react-query";

const LEGAL_ADVICE = "legal-advice";

export const createFeedbackLegalAdviceMutationFn = ({
  legalAdviceId,
  data,
}: CreateFeedbackLegalAdviceBody): Promise<FeedbackLegalAdviceSchemaI> => {
  return authApi.post(`${LEGAL_ADVICE}/${legalAdviceId}/feedback`, data);
};

export const useCreateFeedbackLegalAdvice = ({
  config,
}: CreateFeedbackLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackLegalAdviceMutationFn,
  });
};
