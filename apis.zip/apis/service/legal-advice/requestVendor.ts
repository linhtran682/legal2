import { authApi } from "@/apis";
import {
  CreateRequestVendorBody,
  CreateRequestVendorOptions,
  RequestVendorSchemaI,
} from "@/models/legal-advice/RequestVendor";
import { useMutation } from "@tanstack/react-query";

const LEGAL_ADVICE = "legal-advice";

export const createRequestVendorMutationFn = ({
  legalAdviceId,
  data,
}: CreateRequestVendorBody): Promise<RequestVendorSchemaI> => {
  return authApi.post(`${LEGAL_ADVICE}/${legalAdviceId}/request-vendor`, data);
};

export const useCreateRequestVendor = ({
  config,
}: CreateRequestVendorOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestVendorMutationFn,
  });
};
