import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  CreateTimeExtensionBody,
  CreateTimeExtensionOptions,
  GetTimeExtensionIdOptions,
  QueryFnType,
  RequestApprovalDTO,
  TimeExtensionParams,
  UpdateTimeExtensionAcceptOptions,
  UpdateTimeExtensionBody,
} from "@/models/legal-advice/TimeExtension";

const LEGAL_ADVICE = "legal-advice";
export const GET_TIME_EXTENSION_ADVICE = "useGetTimeExtensionAdvice";

export const createTimeExtensionMutationFn = ({
  legalAdviceId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(`${LEGAL_ADVICE}/${legalAdviceId}/time-extension`, data);
};

export const useCreateTimeExtension = ({
  config,
}: CreateTimeExtensionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionMutationFn,
  });
};

export const getTimeExtensionQueryFn = async (
  request: TimeExtensionParams
): Promise<RequestApprovalDTO> => {
  const { legalAdviceId, timeExtensionRequestId } = request;
  const response = await authApi.get(
    `${LEGAL_ADVICE}/${legalAdviceId}/time-extension/${timeExtensionRequestId}`
  );
  return response.data.result;
};

export const useGetTimeExtension = ({
  config,
  request,
}: GetTimeExtensionIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_TIME_EXTENSION_ADVICE, request],
    queryFn: () => getTimeExtensionQueryFn(request),
  });
};

export const updateTimeExtensionMutationFn = async (
  request: UpdateTimeExtensionBody
): Promise<any> => {
  const { legalAdviceId, timeExtensionRequestId, data } = request;
  const response = await authApi.put(
    `${LEGAL_ADVICE}/${legalAdviceId}/time-extension/${timeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtension = ({
  config,
}: UpdateTimeExtensionAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionMutationFn,
  });
};
