import { authApi, ExtractFnReturnType } from "@/apis";
import {
  CreateRequestAdditionalBody,
  CreateRequestAdditionalOptions,
  GetRequestAdditionalIdOptions,
  QueryFnType,
  RequestAdditionalDTO,
  RequestAdditionalParams,
  RequestAdditionalSchemaI,
} from "@/models/legal-advice/RequestAdditional";
import { useMutation, useQuery } from "@tanstack/react-query";

const LEGAL_ADVICE = "legal-advice";
const GET_REQUEST_ADDITIONAL_ADVICE = "getRequestAdditionalAdvice";

export const createRequestAdditionalMutationFn = ({
  legalAdviceId,
  data,
}: CreateRequestAdditionalBody): Promise<RequestAdditionalSchemaI> => {
  return authApi.post(
    `${LEGAL_ADVICE}/${legalAdviceId}/information-request`,
    data
  );
};

export const useCreateRequestAdditional = ({
  config,
}: CreateRequestAdditionalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestAdditionalMutationFn,
  });
};

export const getRequestAdditionalQueryFn = async (
  request: RequestAdditionalParams
): Promise<RequestAdditionalDTO> => {
  const { legalAdviceId, informationRequestId } = request;
  const response = await authApi.get(
    `${LEGAL_ADVICE}/${legalAdviceId}/information-request/${informationRequestId}`
  );
  return response.data.result;
};

export const useGetRequestAdditional = ({
  config,
  request,
}: GetRequestAdditionalIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_REQUEST_ADDITIONAL_ADVICE, request],
    queryFn: () => getRequestAdditionalQueryFn(request),
  });
};
