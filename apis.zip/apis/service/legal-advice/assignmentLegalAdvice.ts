import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import {
  AssignmentLegalAdviceSchemaI,
  CreateAssignmentLegalAdviceBody,
  CreateAssignmentLegalAdviceOptions,
} from "@/models/legal-advice/AssignmentLegalAdvice";

const LEGAL_ADVICE = "legal-advice";

export const createAssignmentLegalAdviceMutationFn = ({
  legalAdviceId,
  data,
}: CreateAssignmentLegalAdviceBody): Promise<AssignmentLegalAdviceSchemaI> => {
  return authApi.post(
    `${LEGAL_ADVICE}/${legalAdviceId}/assigment`,
    data
  );
};

export const useCreateAssignmentLegalAdvice = ({
  config,
}: CreateAssignmentLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAssignmentLegalAdviceMutationFn,
  });
};
