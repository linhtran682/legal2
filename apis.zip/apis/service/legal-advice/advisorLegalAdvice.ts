import { useMutation, useQuery } from "@tanstack/react-query";
import { authApi, ExtractFnReturnType } from "@/apis";
import {
  AdvisorLegalAdviceParams,
  CreateAdvisorLegalAdviceBody,
  CreateAdvisorLegalAdviceOptions,
  GetAdvisorLegalAdviceIdOptions,
  GetAdvisorLegalAdviceListOptions,
  QueryFnType,
  QueryFnTypeList,
  ResponsesAdvisorLegalAdviceDTO,
  UpdateAdvisorLegalAdviceBody,
  UpdateAdvisorLegalAdviceDetailBody,
  UpdateAdvisorLegalAdviceDetailOptions,
  UpdateAdvisorLegalAdviceOptions,
} from "@/models/legal-advice/AdvisorLegalAdvice";

const LEGAL_ADVICE = "legal-advice";
export const GET_LEGAL_ADVISOR = "useGetAdvisorLegalAdvice";
export const GET_LEGAL_ADVISOR_LIST = "useGetAdvisorLegalAdviceList";

export const createAdvisorLegalAdviceMutationFn = ({
  legalAdviceId,
  data,
}: CreateAdvisorLegalAdviceBody): Promise<any> => {
  return authApi.post(`${LEGAL_ADVICE}/${legalAdviceId}/advise`, data);
};

export const useCreateAdvisorLegalAdvice = ({
  config,
}: CreateAdvisorLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAdvisorLegalAdviceMutationFn,
  });
};

export const getAdvisorLegalAdviceQueryFn = async (
  request: AdvisorLegalAdviceParams
): Promise<ResponsesAdvisorLegalAdviceDTO> => {
  const { legalAdviceId, adviseId } = request;
  const response = await authApi.get(
    `${LEGAL_ADVICE}/${legalAdviceId}/advise/${adviseId}`
  );
  return response.data.result;
};

export const useGetAdvisorLegalAdvice = ({
  config,
  request,
}: GetAdvisorLegalAdviceIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_LEGAL_ADVISOR, request],
    queryFn: () => getAdvisorLegalAdviceQueryFn(request),
  });
};

export const updateAdvisorLegalAdviceMutationFn = async (
  request: UpdateAdvisorLegalAdviceBody
): Promise<any> => {
  const { legalAdviceId, adviseId, data } = request;
  const response = await authApi.put(
    `${LEGAL_ADVICE}/${legalAdviceId}/advise/${adviseId}`,
    data
  );
  return response.status;
};

export const updateFeedbackLegalAdviceMutationFn = async (
  request: UpdateAdvisorLegalAdviceBody
): Promise<any> => {
  const { legalAdviceId, data } = request;
  const response = await authApi.put(
    `${LEGAL_ADVICE}/${legalAdviceId}/advise/feedback`,
    data
  );
  return response.status;
};

export const useUpdateAdvisorLegalAdvice = ({
  config,
}: UpdateAdvisorLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateFeedbackLegalAdviceMutationFn,
  });
};

export const getAdvisorLegalAdviceListQueryFn = async (request: {
  legalAdviceId?: number;
}): Promise<ResponsesAdvisorLegalAdviceDTO[]> => {
  const { legalAdviceId } = request;
  const response = await authApi.get(`${LEGAL_ADVICE}/${legalAdviceId}/advise`);
  return response.data?.responses;
};

export const useGetAdvisorLegalAdviceList = ({
  config,
  request,
}: GetAdvisorLegalAdviceListOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeList>>({
    ...config,
    queryKey: [GET_LEGAL_ADVISOR_LIST, request],
    queryFn: () => getAdvisorLegalAdviceListQueryFn(request),
  });
};


export const updateAdvisorLegalAdviceDetailMutationFn = async (
  request: UpdateAdvisorLegalAdviceDetailBody
): Promise<any> => {
  const { legalAdviceId, adviseId, data } = request;
  const response = await authApi.put(
    `${LEGAL_ADVICE}/${legalAdviceId}/advise/${adviseId}/update`,
    data
  );
  return response.status;
};

export const useUpdateAdvisorLegalAdviceDetail = ({
  config,
}: UpdateAdvisorLegalAdviceDetailOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateAdvisorLegalAdviceDetailMutationFn,
  });
};