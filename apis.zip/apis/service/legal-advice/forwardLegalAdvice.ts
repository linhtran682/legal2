import { authApi } from "@/apis";
import {
  CreateForwardLegalAdviceBody,
  CreateForwardLegalAdviceOptions,
  ForwardLegalAdviceSchemaI,
} from "@/models/legal-advice/ForwardLegalAdvice";
import { useMutation } from "@tanstack/react-query";

const LEGAL_ADVICE = "legal-advice";

export const createForwardLegalAdviceMutationFn = ({
  legalAdviceId,
  data,
}: CreateForwardLegalAdviceBody): Promise<ForwardLegalAdviceSchemaI> => {
  return authApi.post(
    `${LEGAL_ADVICE}/${legalAdviceId}/forward`,
    data
  );
};

export const useCreateForwardLegalAdvice = ({
  config,
}: CreateForwardLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createForwardLegalAdviceMutationFn,
  });
};
