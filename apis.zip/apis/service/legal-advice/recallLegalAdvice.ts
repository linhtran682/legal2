import { authApi, MutationConfig } from "@/apis";
import { useMutation } from "@tanstack/react-query";

const LEGAL_ADVICE = "legal-advice";

export interface RecallLegalAdviceOptions {
  config?: MutationConfig<typeof recallAdviceMutationFn>;
}

export const recallAdviceMutationFn = (legalAdviceId?: number): Promise<any> => {
  return authApi.post(`${LEGAL_ADVICE}/${legalAdviceId}/recall`);
};

export const useRecallLegalAdvice = ({
  config,
}: RecallLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: recallAdviceMutationFn,
  });
};
