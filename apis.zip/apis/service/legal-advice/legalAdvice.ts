import { authApi, ResponseWrapper } from "@/apis";
import { GetLegalDocumentTabAttachmentsResponse } from "@/models/law_document/LegalDocumentAttachment";
import {
  LegalAdviceAdviseListResponse,
  LegalAdviceBodyReceive,
  LegalAdviceBodySend,
} from "@/models/legal-advice/LegalAdviceDetail";
import {
  GetAdviceAssignmentResponse,
  GetAdviceExtensionResponse,
  GetAdviceForwardResponse,
  GetAdviceRequestFeedbackResponse,
  GetAdviseFeedbackResponse,
  GetLegalAdviceListParams,
  GetLegalAdviceListResponse,
  LegalAdviceStatisticChartResponse,
} from "@/models/legal-advice/LegalAdviceList";
import {
  GetCommentsResponse,
  GetHistoryResponse,
  GetInformationRequestsResponse,
  GetMeetingResponse,
} from "@/models/metadata/Metadata";

const LEGAL_ADVICE_URL = "legal-advice";

export const getLegalAdviceRequests = async (
  params: GetLegalAdviceListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalAdviceListResponse>
  >(LEGAL_ADVICE_URL, {
    params: params,
  });
  return response.data.result;
};

export const getLegalAdviceById = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<ResponseWrapper<LegalAdviceBodyReceive>>(
    `${LEGAL_ADVICE_URL}/${id}`
  );
  return response.data.result;
};

export const getAllHierarchyById = async (params: { id: number | string }) => {
  const response = await authApi.get(
    `/${LEGAL_ADVICE_URL}/${params.id}/all-hierarchy`
  );
  return response.data?.result;
};

export const createLegalAdvice = async (request: LegalAdviceBodySend) => {
  const requestFormat = {
    ...request,
  };
  const response = await authApi.post(LEGAL_ADVICE_URL, requestFormat);
  return response.status;
};

export const updateLegalAdvice = async (updateProps: {
  request: LegalAdviceBodySend;
  id: number;
}) => {
  const response = await authApi.put(
    `${LEGAL_ADVICE_URL}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const getLegalAdviceAdviseList = async (id: number) => {
  const response = await authApi.get<LegalAdviceAdviseListResponse>(
    `/${LEGAL_ADVICE_URL}/${id}/advise`
  );
  return response.data;
};

export const getLegalAdviceExcel = async (params: GetLegalAdviceListParams) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${LEGAL_ADVICE_URL}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getLegalAdviceComments = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetCommentsResponse>>(
    `/${LEGAL_ADVICE_URL}/${id}/comment`
  );

  return response.data;
};

export const commentLegalAdvice = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${LEGAL_ADVICE_URL}/${params.id}/comment`,
    {
      content: params.content,
    }
  );

  return response.data;
};

export const cloneLegalAdvice = async (params: {
  id: number;
  data: {
    childStatus: number;
    status: number;
  };
}) => {
  const response = await authApi.post(
    `/${LEGAL_ADVICE_URL}/${params.id}/clone`,
    params.data
  );

  return response.data;
};
export const shareLegalAdviceFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number;
  };
}) => {
  const response = await authApi.post(
    `/${LEGAL_ADVICE_URL}/${params.id}/share`,
    params.data
  );

  return response.data;
};

export const getLegalAdviceForwards = async (id: number) => {
  const response = await authApi.get<GetAdviceForwardResponse>(
    `/${LEGAL_ADVICE_URL}/${id}/forward`
  );

  return response.data;
};

export const getLegalAdviceInformationRequests = async (id: number) => {
  const response = await authApi.get<GetInformationRequestsResponse>(
    `/${LEGAL_ADVICE_URL}/${id}/information-request`
  );

  return response.data;
};

export const getLegalAdviceHistory = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${LEGAL_ADVICE_URL}/${id}/history`
  );
  return response.data;
};

export const getLegalAdviceAssignments = async (id: number) => {
  const response = await authApi.get<GetAdviceAssignmentResponse>(
    `/${LEGAL_ADVICE_URL}/${id}/assigment`
  );
  return response.data;
};

export const getLegalAdviceExtensions = async (id: number) => {
  const response = await authApi.get<GetAdviceExtensionResponse>(
    `/${LEGAL_ADVICE_URL}/${id}/time-extension`
  );
  return response.data;
};

export const getLegalAdviceRequestFeedback = async (id: number) => {
  const response = await authApi.get<GetAdviceRequestFeedbackResponse>(
    `/${LEGAL_ADVICE_URL}/${id}/feedback`
  );
  return response.data;
};

export const getAdviseFeedbacks = async (id: number) => {
  const response = await authApi.get<GetAdviseFeedbackResponse>(
    `/${LEGAL_ADVICE_URL}/${id}/advise/tab`
  );
  return response.data;
};

export const getLegalAdviceAttachment = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalDocumentTabAttachmentsResponse>
  >(`${LEGAL_ADVICE_URL}/${id}/attachment-tab`);
  return response.data.result;
};

export const updateBookMeeting = async (params: {
  legalAdviceId?: number;
  request: {
    bookMeeting: boolean;
  };
}) => {
  const response = await authApi.put(
    `${LEGAL_ADVICE_URL}/${params.legalAdviceId}/book-meeting`,
    params.request
  );

  return response.status;
};

export const getLegalAdviceMeeting = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetMeetingResponse>>(
    `/${LEGAL_ADVICE_URL}/${id}/meeting-new`
  );

  return response.data;
};

export const createLegalAdviceMeeting = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${LEGAL_ADVICE_URL}/${params.id}/meeting-new`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const updateLegalAdviceMeeting = async (params: {
  id: number;
  meetingId: number;
  content: string;
}) => {
  const response = await authApi.put(
    `/${LEGAL_ADVICE_URL}/${params.id}/meeting-new/${params.meetingId}`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const deleteLegalAdviceMeeting = async (params: {
  id: number;
  meetingId: number;
}) => {
  const response = await authApi.delete(
    `/${LEGAL_ADVICE_URL}/${params.id}/meeting-new/${params.meetingId}`
  );
  return response.data;
};

export const getStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<LegalAdviceStatisticChartResponse>
  >(`/${LEGAL_ADVICE_URL}/statistic/chart`);
  return response.data.result;
};
export const getStatisticTableFn = async (params: GetLegalAdviceListParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalAdviceListResponse>
  >(`/${LEGAL_ADVICE_URL}/statistic/table`, {
    params: params,
  });
  return response.data.result;
};
export const getStatisticTableDoneFn = async (
  params: GetLegalAdviceListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalAdviceListResponse>
  >(`/${LEGAL_ADVICE_URL}/statistic/table/done`, {
    params: params,
  });
  return response.data.result;
};
