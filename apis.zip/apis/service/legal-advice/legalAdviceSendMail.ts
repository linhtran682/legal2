import { authApi } from "@/apis";
import { LEGAL_ADVICE_ROOT_PATH } from "@/constants/paths";
import { SendMailRequest } from "@/models/legal-advice/SendMail";

export const sendMailLegalAdvice = async (params: {
  id: number;
  request: SendMailRequest;
}) => {
  const requestFormat = {
    ...params.request,
  };
  const response = await authApi.post(
    `${LEGAL_ADVICE_ROOT_PATH}/${params.id}/sendMail`,
    requestFormat
  );
  return response.status;
};
