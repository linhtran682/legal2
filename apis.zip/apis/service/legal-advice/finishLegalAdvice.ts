import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import {
  CreateFinishLegalAdviceBody,
  CreateFinishLegalAdviceOptions,
  FinishLegalAdviceSchemaI,
} from "@/models/legal-advice/FinishLegalAdvice";

const LEGAL_ADVICE = "legal-advice";

export const createFinishLegalAdviceMutationFn = ({
  legalAdviceId,
  data,
}: CreateFinishLegalAdviceBody): Promise<FinishLegalAdviceSchemaI> => {
  return authApi.post(`${LEGAL_ADVICE}/${legalAdviceId}/finish`, data);
};

export const useCreateFinishLegalAdvice = ({
  config,
}: CreateFinishLegalAdviceOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFinishLegalAdviceMutationFn,
  });
};
