import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateTrackFollowViolationBody,
  CreateTrackFollowViolationOptions,
  TrackNextActionFvSchemaI,
} from "@/models/follow_violation/TrackNextActionFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createTrackFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateTrackFollowViolationBody): Promise<TrackNextActionFvSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/next_action/track`,
    data
  );
};

export const useCreateTrackNextActionFv = ({
  config,
}: CreateTrackFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTrackFollowViolationMutationFn,
  });
};
