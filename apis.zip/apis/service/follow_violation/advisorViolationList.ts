import { authApi, ExtractFnReturnType, QueryConfig } from "@/apis";
import { VIOLATION_TRACKING_URL } from "./followViolationAPI";
import { useQuery } from "@tanstack/react-query";
import { ResponsesAdvisorViolationTO } from "@/models/follow_violation/FormType";

export type QueryFnTypeList = typeof getAdvisorViolationListQueryFn;
export const GET_ADVISOR_VIOLATION_LIST = "useGetAdvisorViolationList";
export type GetAdvisorLegalAdviceListOptions = {
  config?: QueryConfig<QueryFnTypeList>;
  request: { violationId?: number };
};

export const getAdvisorViolationListQueryFn = async (request: {
    violationId?: number;
  }): Promise<ResponsesAdvisorViolationTO[]> => {
    const { violationId } = request;
    const response = await authApi.get(`${VIOLATION_TRACKING_URL}/${violationId}/advise`);
    return response.data?.responses;
  };
  
  export const useGetAdvisorViolationList = ({
    config,
    request,
  }: GetAdvisorLegalAdviceListOptions) => {
    return useQuery<ExtractFnReturnType<QueryFnTypeList>>({
      ...config,
      queryKey: [GET_ADVISOR_VIOLATION_LIST, request],
      queryFn: () => getAdvisorViolationListQueryFn(request),
    });
  };