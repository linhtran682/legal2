import { useMutation } from "@tanstack/react-query";
import { VIOLATION_TRACKING_URL } from "./followViolationAPI";
import { authApi, MutationConfig } from "@/apis";
import {
  CreateAdvisorViolationRequest,
  UpdateAdvisorViolationDetailRequest,
  UpdateAdvisorViolationRequest,
} from "@/models/follow_violation/FormType";

export type UpdateAdvisorViolationOptions = {
    config?: MutationConfig<typeof updateAdvisorViolationMutationFn>;
  };

  export type UpdateAdvisorViolationDetailOptions = {
    config?: MutationConfig<typeof updateAdvisorViolationDetailMutationFn>;
  };

  export interface CreateAdvisorViolationOptions {
    config?: MutationConfig<typeof createAdvisorViolationMutationFn>;
  }

export const updateAdvisorViolationMutationFn = async (
    request: UpdateAdvisorViolationRequest
  ): Promise<any> => {
    const { violationId, adviseId, data } = request;
    const response = await authApi.put(
      `${VIOLATION_TRACKING_URL}/${violationId}/advise/${adviseId}`,
      data
    );
    return response.status;
  };
  
export const useUpdateAdvisorViolation = ({
  config,
}: UpdateAdvisorViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateAdvisorViolationMutationFn,
  });
};

export const updateAdvisorViolationDetailMutationFn = async (
  request: UpdateAdvisorViolationDetailRequest
): Promise<any> => {
  const { violationId, adviseId, data } = request;
  const response = await authApi.put(
    `${VIOLATION_TRACKING_URL}/${violationId}/advise/${adviseId}/update`,
    data
  );
  return response.status;
};

export const useUpdateAdvisorViolationDetail = ({
  config,
}: UpdateAdvisorViolationDetailOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateAdvisorViolationDetailMutationFn,
  });
};

export const createAdvisorViolationMutationFn = ({
  violationId,
  data,
}: CreateAdvisorViolationRequest): Promise<any> => {
  return authApi.post(`${VIOLATION_TRACKING_URL}/${violationId}/advise`, data);
};

export const useCreateAdvisorViolation = ({
  config,
}: CreateAdvisorViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAdvisorViolationMutationFn,
  });
};