import { authApi, ExtractFnReturnType } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateRequestApprovalFvBody,
  CreateRequestApprovalFvOptions,
  GetRequestApprovalFvIdOptions,
  RequestApprovalFvDTO,
  RequestApprovalFvParams,
  RequestApprovalRequestFvSchemaI,
  UpdateRequestApprovalFvBody,
  UpdateRequestApprovalFvOptions,
  QueryFnTypeFv,
  CreateApprovalFvOptions,
  CreateApprovalFvBody,
} from "@/models/follow_violation/RequestApprovalFollowViolation";
import { useMutation, useQuery } from "@tanstack/react-query";

export const GET_REQUEST_APPROVAL_FOLLOW_VIOLATION =
  "useGetRequestApprovalFollowViolation";

export const createRequestApprovalFvMutationFn = ({
  violationId,
  data,
}: CreateRequestApprovalFvBody): Promise<RequestApprovalRequestFvSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/request_approval`,
    data
  );
};

export const useCreateRequestApprovalFv = ({
  config,
}: CreateRequestApprovalFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestApprovalFvMutationFn,
  });
};

export const createApprovalFvMutationFn = ({
  violationId,
  data,
}: CreateApprovalFvBody): Promise<RequestApprovalRequestFvSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/approval`,
    data
  );
};

export const useCreateApprovalFv = ({
  config,
}: CreateApprovalFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createApprovalFvMutationFn,
  });
};

export const getRequestApprovalFvQueryFn = async (
  request: RequestApprovalFvParams
): Promise<RequestApprovalFvDTO> => {
  const { violationId, requestApprovalId } = request;
  const response = await authApi.get(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/approval/${requestApprovalId}`
  );
  return response.data.result;
};

export const useGetRequestApprovalFollowViolation = ({
  config,
  request,
}: GetRequestApprovalFvIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeFv>>({
    ...config,
    queryKey: [GET_REQUEST_APPROVAL_FOLLOW_VIOLATION, request],
    queryFn: () => getRequestApprovalFvQueryFn(request),
  });
};

export const updateRequestApprovalFvMutationFn = async (
  request: UpdateRequestApprovalFvBody
): Promise<any> => {
  const { violationId, requestApprovalId, data } = request;
  const response = await authApi.put(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/approval/${requestApprovalId}`,
    data
  );
  return response.status;
};

export const useUpdateRequestApproval = ({
  config,
}: UpdateRequestApprovalFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateRequestApprovalFvMutationFn,
  });
};

export const updateMultipleRequestApprovalMutationFn = async (
  request: UpdateRequestApprovalFvBody
): Promise<any> => {
  const { violationId, data } = request;
  const response = await authApi.put(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/approval`,
    data
  );
  return response.status;
};

export const useUpdateMultipleRequestApprovalFv = ({
  config,
}: UpdateRequestApprovalFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateMultipleRequestApprovalMutationFn,
  });
};
