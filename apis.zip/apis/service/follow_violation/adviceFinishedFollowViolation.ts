import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateAdviceFinishedFollowViolationBody,
  CreateAdviceFinishedFvOptions,
  AdviceFinishedFollowViolationSchemaI,
} from "@/models/follow_violation/AdviceFinishedFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createAdviceFinishedFvMutationFn = ({
  violationId,
  data,
}: CreateAdviceFinishedFollowViolationBody): Promise<AdviceFinishedFollowViolationSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/advise/finish`,
    data
  );
};

export const useCreateAdviceFinishedFollowViolation = ({
  config,
}: CreateAdviceFinishedFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAdviceFinishedFvMutationFn,
  });
};
