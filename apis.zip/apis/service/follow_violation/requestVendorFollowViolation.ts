import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateRequestVendorFvBody,
  CreateRequestVendorFvOptions,
  RequestVendorFvSchemaI,
} from "@/models/follow_violation/RequestVendorFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createRequestVendorFvMutationFn = ({
  violationId,
  data,
}: CreateRequestVendorFvBody): Promise<RequestVendorFvSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/request-vendor`,
    data
  );
};

export const useCreateRequestVendorFv = ({
  config,
}: CreateRequestVendorFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestVendorFvMutationFn,
  });
};
