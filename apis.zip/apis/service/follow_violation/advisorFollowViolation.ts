import { useMutation, useQuery } from "@tanstack/react-query";
import { authApi, ExtractFnReturnType } from "@/apis";
import {
  CreateAdvisorFollowViolationBody,
  CreateAdvisorFollowViolationOptions,
  FeedbackAdviceFollowViolationBody,
  FeedbackAdviceFollowViolationOptions,
  GetAdvisorFollowViolationListOptions,
  QueryFnTypeList,
  ResponsesAdvisorFollowViolationDTO,
  UpdateAdvisorFollowViolationDetailBody,
  UpdateAdvisorFollowViolationDetailOptions,
} from "@/models/follow_violation/AdvisorFollowViolation";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";

export const GET_LEGAL_ADVISOR_FOLLOW_VIOLATION_LIST =
  "useGetAdvisorFollowViolationList";

// Create advice
export const createAdvisorFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateAdvisorFollowViolationBody): Promise<any> => {
  const newData = { ...data, isFinish: data?.finish };
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/advise`,
    newData
  );
};

export const useCreateAdvisorFollowViolation = ({
  config,
}: CreateAdvisorFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAdvisorFollowViolationMutationFn,
  });
};

// Feedback advice
export const feedbackAdviceFollowViolationMutationFn = async (
  request: FeedbackAdviceFollowViolationBody
): Promise<any> => {
  const { violationId, data } = request;
  const response = await authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/advise/feedback`,
    data
  );
  return response.status;
};

export const useFeedbackAdviceFollowViolation = ({
  config,
}: FeedbackAdviceFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: feedbackAdviceFollowViolationMutationFn,
  });
};

// Update advice
export const updateAdvisorFollowViolationDetailMutationFn = async (
  request: UpdateAdvisorFollowViolationDetailBody
): Promise<any> => {
  const { violationId, adviseId, data } = request;
  const newData = { ...data, isFinish: data?.finish };

  const response = await authApi.put(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/advise/${adviseId}`,
    newData
  );
  return response.status;
};

export const useUpdateAdvisorFollowViolationDetail = ({
  config,
}: UpdateAdvisorFollowViolationDetailOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateAdvisorFollowViolationDetailMutationFn,
  });
};

// Get advisor list
export const getAdvisorFollowViolationListQueryFn = async (request: {
  violationId?: number;
}): Promise<ResponsesAdvisorFollowViolationDTO[]> => {
  const { violationId } = request;
  const response = await authApi.get(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/advise`
  );
  return response.data;
};

export const useGetAdvisorFollowViolationList = ({
  config,
  request,
}: GetAdvisorFollowViolationListOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeList>>({
    ...config,
    queryKey: [GET_LEGAL_ADVISOR_FOLLOW_VIOLATION_LIST, request],
    queryFn: () => getAdvisorFollowViolationListQueryFn(request),
  });
};
