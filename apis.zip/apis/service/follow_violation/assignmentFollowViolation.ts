import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import {
  AssignmentFollowViolationSchemaI,
  CreateAssignmentFollowViolationBody,
  CreateAssignmentFollowViolationOptions,
} from "@/models/follow_violation/AssignmentFollowViolation";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";

export const createAssignmentFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateAssignmentFollowViolationBody): Promise<AssignmentFollowViolationSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/assignment`,
    data
  );
};

export const useCreateAssignmentFollowViolation = ({
  config,
}: CreateAssignmentFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAssignmentFollowViolationMutationFn,
  });
};
