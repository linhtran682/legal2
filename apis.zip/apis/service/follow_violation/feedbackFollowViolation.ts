import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateFeedbackFollowViolationBody,
  CreateFeedbackFollowViolationOptions,
  FeedbackFollowViolationSchemaI,
} from "@/models/follow_violation/FeedBackFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createFeedbackFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateFeedbackFollowViolationBody): Promise<FeedbackFollowViolationSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/feedback`,
    data
  );
};

export const useCreateFeedbackFollowViolation = ({
  config,
}: CreateFeedbackFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackFollowViolationMutationFn,
  });
};
