import { authApi, ExtractFnReturnType, ResponseWrapper } from "@/apis";
import {
  AdvisorViolationParams,
  FollowViolationListParams,
  FollowViolationListResponse,
  GetAdvisorViolationIdOptions,
  GetViolationStatusRequest,
  GetViolationStatusResponse,
  ViolationStatisticChartResponse,
} from "@/models/follow_violation/apiType";
import {
  ApprovalRecord,
  FollowViolationDetail,
  FollowViolationRequest,
  GetViolationAttachmentsResponse,
  GetViolationCommentsResponse,
  GetViolationExtensionResponse,
  GetViolationFeedbackResponse,
  GetViolationForwardResponse,
  GetViolationHistoryResponse,
  GetViolationRequestFeedbackResponse,
  InformationRequestType,
  ResponsesAdvisorViolationTO,
  ViolationAdvise,
  ViolationAssignmentResponse,
  ViolationNextActionRequest,
  ViolationNextActionResponse,
} from "@/models/follow_violation/FormType";
import { GetMeetingResponse } from "@/models/metadata/Metadata";
import { useQuery } from "@tanstack/react-query";

export const VIOLATION_TRACKING_URL = "violation_tracking";
export const GET_VIOLATION_ADVISOR = "useGetAdvisorViolation";
export type QueryFnType = typeof getAdvisorViolationQueryFn;

export const getFollowViolationList = async (
  params: FollowViolationListParams
) => {
  const response = await authApi.get<
    ResponseWrapper<FollowViolationListResponse>
  >(VIOLATION_TRACKING_URL, {
    params: params,
  });
  return response.data.result;
};

export const createFollowViolation = async (
  request: FollowViolationRequest
) => {
  delete request.isRequestVendorAdvice;
  const requestFormat = {
    ...request,
  };
  const response = await authApi.post(VIOLATION_TRACKING_URL, requestFormat);
  return response.status;
};

export const updateViolation = async (updateProps: {
  request: FollowViolationRequest;
  id: number;
}) => {
  const response = await authApi.put(
    `${VIOLATION_TRACKING_URL}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteViolation = async (id: number) => {
  const response = await authApi.delete(
    `${VIOLATION_TRACKING_URL}/${id}`,
  );

  return response.status;
};

export const getAdvisorViolationQueryFn = async (
  request: AdvisorViolationParams
): Promise<ResponsesAdvisorViolationTO> => {
  const { violationId, adviseId } = request;
  const response = await authApi.get(
    `${VIOLATION_TRACKING_URL}/${violationId}/advise/${adviseId}`
  );
  return response.data.result;
};

export const useGetAdvisorViolation = ({
  config,
  request,
}: GetAdvisorViolationIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_VIOLATION_ADVISOR, request],
    queryFn: () => getAdvisorViolationQueryFn(request),
  });
};

export const getViolationById = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<FollowViolationDetail>>(
    `${VIOLATION_TRACKING_URL}/${id}/detail`
  );
  return response.data.result;
};

export const getViolationExcel = async (params: FollowViolationListParams) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${VIOLATION_TRACKING_URL}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getAllHierarchyViolationById = async (params: {
  id: number | string;
}) => {
  const response = await authApi.get(
    `/${VIOLATION_TRACKING_URL}/${params.id}/all-hierarchy`
  );
  return response.data?.result;
};

export const getViolationInformationRequests = async (id: number) => {
  const response = await authApi.get<InformationRequestType[]>(
    `/${VIOLATION_TRACKING_URL}/${id}/information-request`
  );

  return response.data;
};

export const getViolationAssignments = async (id: number) => {
  const response = await authApi.get<ViolationAssignmentResponse>(
    `/${VIOLATION_TRACKING_URL}/${id}/assignment`
  );
  return response.data;
};

export const getViolationAdviseList = async (id: number) => {
  const response = await authApi.get<ViolationAdvise[]>(
    `/${VIOLATION_TRACKING_URL}/${id}/advise`
  );
  return response.data;
};

export const getViolationForwards = async (id: number) => {
  const response = await authApi.get<GetViolationForwardResponse>(
    `/${VIOLATION_TRACKING_URL}/${id}/forward`
  );

  return response.data;
};

export const getViolationExtensions = async (id: number) => {
  const response = await authApi.get<GetViolationExtensionResponse>(
    `/${VIOLATION_TRACKING_URL}/${id}/time-extension`
  );
  return response.data;
};

export const getViolationFeedbacks = async (id: number) => {
  const response = await authApi.get<GetViolationFeedbackResponse>(
    `/${VIOLATION_TRACKING_URL}/${id}/advise/tab/feedback`
  );
  return response.data;
};

export const getViolationRequestFeedback = async (id: number) => {
  const response = await authApi.get<GetViolationRequestFeedbackResponse>(
    `/${VIOLATION_TRACKING_URL}/${id}/feedback`
  );
  return response.data;
};

export const getViolationLCFeedback = async (id: number) => {
  const response = await authApi.get<GetViolationRequestFeedbackResponse>(
    `/${VIOLATION_TRACKING_URL}/${id}/next_action/tab/feedback-lc`
  );
  return response.data;
};

export const getViolationNextActionFeedback = async (id: number) => {
  const response = await authApi.get<GetViolationRequestFeedbackResponse>(
    `/${VIOLATION_TRACKING_URL}/${id}/next_action/tab/feedback`
  );
  return response.data;
};

export const getViolationComments = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetViolationCommentsResponse>
  >(`/${VIOLATION_TRACKING_URL}/${id}/comment`);

  return response.data;
};

export const commentViolation = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${VIOLATION_TRACKING_URL}/${params.id}/comment`,
    {
      content: params.content,
    }
  );

  return response.data;
};

export const getViolationAttachment = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetViolationAttachmentsResponse>
  >(`${VIOLATION_TRACKING_URL}/${id}/attachment`);
  return response.data.result;
};

export const getViolationHistory = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetViolationHistoryResponse>
  >(`/${VIOLATION_TRACKING_URL}/${id}/history`);
  return response.data.result;
};

export const getViolationApproval = async (id: number) => {
  const response = await authApi.get<ApprovalRecord[]>
  (`/${VIOLATION_TRACKING_URL}/${id}/approval/tab`);
  return response.data;
};

export const getViolationStatusList = async (params: GetViolationStatusRequest) => {
  const response = await authApi.get<ResponseWrapper<GetViolationStatusResponse>>(
    "status/violation",
    {
      params: {
        ...params,
        modules: params.modules ? params.modules.join(",") : undefined,
      },
    }
  );
  return response.data.result;
};

export const createViolationNextAction = async (
  updateProps: {
    request: ViolationNextActionRequest;
    violationId: number;
  }
) => {
  const requestFormat = {
    ...updateProps.request,
  };
  const response = await authApi.post(
    `${VIOLATION_TRACKING_URL}/${updateProps.violationId}/next_action`, requestFormat);
  return response.status;
};

export const updateViolationNextAction = async (updateProps: {
  request: ViolationNextActionRequest;
  violationId: number;
}) => {
  const response = await authApi.put(
    `${VIOLATION_TRACKING_URL}/${updateProps.violationId}/next_action`,
    updateProps.request
  );

  return response.status;
};

export const getNextActionByViolationId = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<ViolationNextActionResponse>>(
   `${VIOLATION_TRACKING_URL}/${id}/next_action`,
  );
  return response.data.result;
};

export const updateBookMeetingViolation = async (params: {
  id?: number;
  request: {
    isBooking: boolean;
  };
}) => {
  const response = await authApi.post(
    `${VIOLATION_TRACKING_URL}/${params.id}/booking_status`,
    params.request
  );

  return response.status;
};

export const recheckViolation = async (params: {
  id?: number;
}) => {
  const response = await authApi.post(
    `${VIOLATION_TRACKING_URL}/${params.id}/recheck-advice`
  );

  return response;
};

export const recheckRequestApprovalNextAction = async (params: {
  id?: number;
}) => {
  const response = await authApi.post(
    `${VIOLATION_TRACKING_URL}/${params.id}/recheck`
  );

  return response;
};

export const getViolationMeeting = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetMeetingResponse>>(
    `/${VIOLATION_TRACKING_URL}/${id}/meeting-new`
  );

  return response.data;
};

export const createViolationMeeting = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${VIOLATION_TRACKING_URL}/${params.id}/meeting-new`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const updateViolationMeeting = async (params: {
  id: number;
  meetingId: number;
  content: string;
}) => {
  const response = await authApi.put(
    `/${VIOLATION_TRACKING_URL}/${params.id}/meeting-new/${params.meetingId}`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const deleteViolationMeeting = async (params: {
  id: number;
  meetingId: number;
}) => {
  const response = await authApi.delete(
    `/${VIOLATION_TRACKING_URL}/${params.id}/meeting-new/${params.meetingId}`
  );
  return response.data;
};

export const shareFollowViolationFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number;
  };
}) => {
  const response = await authApi.post(
    `/${VIOLATION_TRACKING_URL}/${params.id}/share`,
    params.data
  );

  return response.data;
};

export const getViolationStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<ViolationStatisticChartResponse>
  >(`/${VIOLATION_TRACKING_URL}/statistic/chart`);
  return response.data.result;
};

export const getViolationStatisticTableFn = async (params: FollowViolationListParams) => {
  const response = await authApi.get<
    ResponseWrapper<FollowViolationListResponse>
  >(`/${VIOLATION_TRACKING_URL}/statistic/table`, {
    params: params,
  });
  return response.data.result;
};