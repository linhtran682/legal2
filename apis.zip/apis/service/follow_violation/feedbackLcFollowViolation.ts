import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateFeedBackLcFollowViolationBody,
  CreateFeedBackLcFollowViolationOptions,
  RequestFeedBackLcFollowViolationSchemaI,
} from "@/models/follow_violation/FeedBackLcFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createFeedBackLcFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateFeedBackLcFollowViolationBody): Promise<RequestFeedBackLcFollowViolationSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/next_action/feedback-lc`,
    data
  );
};

export const useCreateFeedBackLcFollowViolation = ({
  config,
}: CreateFeedBackLcFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedBackLcFollowViolationMutationFn,
  });
};
