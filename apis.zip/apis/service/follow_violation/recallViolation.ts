import { authApi, MutationConfig } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import { useMutation } from "@tanstack/react-query";

export interface RecallViolationOptions {
  config?: MutationConfig<typeof recallViolationMutationFn>;
}

export const recallViolationMutationFn = (violationId?: number): Promise<any> => {
  return authApi.post(`${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/recall`);
};

export const useRecallViolation = ({
  config,
}: RecallViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: recallViolationMutationFn,
  });
};
