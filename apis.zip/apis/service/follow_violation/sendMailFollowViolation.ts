import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import { SendMailFollowViolationRequest } from "@/models/follow_violation/SendMailFollowViolation";

export const sendMailFollowViolation = async (params: {
  id: number;
  request: SendMailFollowViolationRequest;
}) => {
  const requestFormat = { ...params?.request };
  const response = await authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${params?.id}/send_mail`,
    requestFormat
  );
  return response.status;
};
