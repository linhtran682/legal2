import { authApi, ResponseWrapper } from "@/apis";
import { GetStatusFollowViolationListResponse } from "@/models/follow_violation/StatusFollowViolation";

const STATUS_VIOLATION_PATH = "status/violation";

export const getStatusFollowViolationList = async () => {
  const response = await authApi.get<
    ResponseWrapper<GetStatusFollowViolationListResponse>
  >(STATUS_VIOLATION_PATH, {});
  return response.data.result;
};
