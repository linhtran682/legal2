import { authApi, MutationConfig } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import { useMutation } from "@tanstack/react-query";

export interface AdditionalInformationFvOptions {
  config?: MutationConfig<typeof additionalInformationFvMutationFn>;
}

export const additionalInformationFvMutationFn = (
  violationId?: number
): Promise<any> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/information-request/update`
  );
};

export const useAdditionalInformationFollowViolation = ({
  config,
}: AdditionalInformationFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: additionalInformationFvMutationFn,
  });
};
