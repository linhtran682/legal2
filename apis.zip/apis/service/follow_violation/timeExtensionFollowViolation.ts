import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  CreateTimeExtensionFvBody,
  CreateTimeExtensionFvOptions,
  GetTimeExtensionFvIdOptions,
  QueryFnTypeFv,
  RequestApprovalDTO,
  TimeExtensionFvParams,
  UpdateTimeExtensionFvAcceptOptions,
  UpdateTimeExtensionFvBody,
} from "@/models/follow_violation/TimeExtensionFollowViolation";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";

export const GET_TIME_EXTENSION_FOLLOW_VIOLATION =
  "useGetTimeExtensionFollowViolation";

export const createTimeExtensionFvMutationFn = ({
  violationId,
  data,
}: CreateTimeExtensionFvBody): Promise<any> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/time-extension`,
    data
  );
};

export const useCreateTimeExtensionFv = ({
  config,
}: CreateTimeExtensionFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionFvMutationFn,
  });
};

export const getTimeExtensionFvQueryFn = async (
  request: TimeExtensionFvParams
): Promise<RequestApprovalDTO> => {
  const { violationId, timeExtensionRequestId } = request;
  const response = await authApi.get(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/time-extension/${timeExtensionRequestId}`
  );
  return response.data.result;
};

export const useGetTimeExtensionFv = ({
  config,
  request,
}: GetTimeExtensionFvIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeFv>>({
    ...config,
    queryKey: [GET_TIME_EXTENSION_FOLLOW_VIOLATION, request],
    queryFn: () => getTimeExtensionFvQueryFn(request),
  });
};

export const updateTimeExtensionFvMutationFn = async (
  request: UpdateTimeExtensionFvBody
): Promise<any> => {
  const { violationId, timeExtensionRequestId, data } = request;
  const response = await authApi.put(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/time-extension/${timeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtensionFv = ({
  config,
}: UpdateTimeExtensionFvAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionFvMutationFn,
  });
};
