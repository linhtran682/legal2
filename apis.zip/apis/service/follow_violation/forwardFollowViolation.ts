import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateForwardFollowViolationBody,
  CreateForwardFollowViolationOptions,
  ForwardFollowViolationSchemaI,
} from "@/models/follow_violation/ForwardFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createForwardFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateForwardFollowViolationBody): Promise<ForwardFollowViolationSchemaI> => {
  return authApi.post(`${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/forward`, data);
};

export const useCreateForwardForwardFollow = ({
  config,
}: CreateForwardFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createForwardFollowViolationMutationFn,
  });
};
