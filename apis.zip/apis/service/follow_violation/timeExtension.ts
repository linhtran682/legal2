import { authApi, ExtractFnReturnType, MutationConfig, QueryConfig } from "@/apis";
import { CreateTimeExtensionViolation, RequestApprovalDTO, TimeExtensionParams, UpdateTimeExtensionRequest } from "@/models/follow_violation/FormType";
import { VIOLATION_TRACKING_URL } from "./followViolationAPI";
import { useMutation, useQuery } from "@tanstack/react-query";

export const GET_TIME_EXTENSION_VIOLATION = "useGetTimeExtensionViolation";

export type QueryFnType = typeof getTimeExtensionQueryFn;

export type GetTimeExtensionIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: TimeExtensionParams;
};

export interface CreateTimeExtensionOptions {
  config?: MutationConfig<typeof createTimeExtensionMutationFn>;
}

export type UpdateTimeExtensionAcceptOptions = {
  config?: MutationConfig<typeof updateTimeExtensionMutationFn>;
};

export const getTimeExtensionQueryFn = async (
    request: TimeExtensionParams
  ): Promise<RequestApprovalDTO> => {
    const { violationId, timeExtensionRequestId } = request;
    const response = await authApi.get(
      `${VIOLATION_TRACKING_URL}/${violationId}/time-extension/${timeExtensionRequestId}`
    );
    return response.data.result;
  };
  
  export const useGetTimeExtensionViolation = ({
    config,
    request,
  }: GetTimeExtensionIdOptions) => {
    return useQuery<ExtractFnReturnType<QueryFnType>>({
      ...config,
      queryKey: [GET_TIME_EXTENSION_VIOLATION, request],
      queryFn: () => getTimeExtensionQueryFn(request),
    });
  };

  export const createTimeExtensionMutationFn = ({
    violationId,
    data,
  }: CreateTimeExtensionViolation): Promise<any> => {
    return authApi.post(`${VIOLATION_TRACKING_URL}/${violationId}/time-extension`, data);
  };
  
  export const useCreateTimeExtensionViolation = ({
    config,
  }: CreateTimeExtensionOptions = {}) => {
    return useMutation({
      ...config,
      mutationFn: createTimeExtensionMutationFn,
    });
  };
  
  export const updateTimeExtensionMutationFn = async (
    request: UpdateTimeExtensionRequest
  ): Promise<any> => {
    const { violationId, timeExtensionRequestId, data } = request;
    const response = await authApi.put(
      `${VIOLATION_TRACKING_URL}/${violationId}/time-extension/${timeExtensionRequestId}`,
      data
    );
    return response.status;
  };
  
  export const useUpdateTimeExtensionViolation = ({
    config,
  }: UpdateTimeExtensionAcceptOptions = {}) => {
    return useMutation({
      ...config,
      mutationFn: updateTimeExtensionMutationFn,
    });
  };