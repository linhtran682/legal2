import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateRequestAddInfoFvBody,
  CreateRequestAddInfoFvOptions,
  RequestAddInfoFvSchemaI,
} from "@/models/follow_violation/RequestAddInfoFollowViolation";

export const createRequestAddInfoFvMutationFn = ({
  violationId,
  data,
}: CreateRequestAddInfoFvBody): Promise<RequestAddInfoFvSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/information-request`,
    data
  );
};

export const useCreateRequestAddInfoFv = ({
  config,
}: CreateRequestAddInfoFvOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestAddInfoFvMutationFn,
  });
};
