import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateFeedbackFollowViolationBody,
  CreateFeedbackFollowViolationOptions,
  FeedbackNextActionFvSchemaI,
} from "@/models/follow_violation/FeedBackNextActionFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createFeedbackFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateFeedbackFollowViolationBody): Promise<FeedbackNextActionFvSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/next_action/feedback`,
    data
  );
};

export const useCreateFeedbackNextActionFv = ({
  config,
}: CreateFeedbackFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackFollowViolationMutationFn,
  });
};
