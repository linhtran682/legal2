import { authApi } from "@/apis";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import {
  CreateFinishFollowViolationBody,
  CreateFinishFollowViolationOptions,
  FinishFollowViolationSchemaI,
} from "@/models/follow_violation/FinishFollowViolation";
import { useMutation } from "@tanstack/react-query";

export const createFinishFollowViolationMutationFn = ({
  violationId,
  data,
}: CreateFinishFollowViolationBody): Promise<FinishFollowViolationSchemaI> => {
  return authApi.post(
    `${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/finish`,
    data
  );
};

export const useCreateFinishFollowViolation = ({
  config,
}: CreateFinishFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFinishFollowViolationMutationFn,
  });
};
