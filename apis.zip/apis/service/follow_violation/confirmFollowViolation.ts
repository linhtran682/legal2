import { authApi, MutationConfig } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";

export interface ConfirmFollowViolationOptions {
  config?: MutationConfig<typeof confirmFollowViolationMutationFn>;
}

export const confirmFollowViolationMutationFn = (
  violationId?: number
): Promise<any> => {
  return authApi.post(`${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${violationId}/confirm`);
};

export const useConfirmFollowViolation = ({
  config,
}: ConfirmFollowViolationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: confirmFollowViolationMutationFn,
  });
};
