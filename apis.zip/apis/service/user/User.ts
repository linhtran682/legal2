import { authApi, ResponseWrapper } from "@/apis";
import {
  GetUsersParams,
  GetUsersResponse,
  SaveUserRequestDTO,
  UserProfileDTO,
} from "@/models/user/User";

const USER_PATH = "users";

export const getUser = async (id: string) => {
  const response = await authApi.get<ResponseWrapper<UserProfileDTO>>(
    `${USER_PATH}/profile/${id}`
  );
  return response.data.result;
};

export const getMe = async () => {
  const response = await authApi.get<ResponseWrapper<UserProfileDTO>>(
    `${USER_PATH}/me`
  );
  return response.data.result;
};

export const getUsers = async (params: GetUsersParams) => {
  const response = await authApi.get<ResponseWrapper<GetUsersResponse>>(
    USER_PATH,
    {
      params: {
        ...params,
        departmentIds: params?.departmentIds && params?.departmentIds.join(","),
      },
    }
  );
  return response.data.result;
};

export const updateUser = async (updateProps: {
  request: SaveUserRequestDTO;
  id: string;
}) => {
  const response = await authApi.put(
    `${USER_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};
export const createUser = async (request: SaveUserRequestDTO) => {
  const response = await authApi.post(`${USER_PATH}`, request);
  return response.status;
};
