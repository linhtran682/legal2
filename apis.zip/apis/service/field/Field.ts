import { authApi, ResponseWrapper } from "@/apis";
import {
  FieldDTO,
  GetFieldsParams,
  GetFieldsResponse,
  SaveFieldDTO,
} from "@/models/field/Field";

const FIELD_PATH = "field";

export const getFields = async (params: GetFieldsParams) => {
  const response = await authApi.get<ResponseWrapper<GetFieldsResponse>>(
    FIELD_PATH,
    {
      params: params,
    }
  );
  return response.data.result;
};

export const getField = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<ResponseWrapper<FieldDTO>>(
    `${FIELD_PATH}/${id}`
  );
  return response.data.result;
};

export const createField = async (request: SaveFieldDTO) => {
  const response = await authApi.post(FIELD_PATH, request);

  return response.status;
};

export const updateField = async (updateProps: {
  request: SaveFieldDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${FIELD_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteFields = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${FIELD_PATH}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};
