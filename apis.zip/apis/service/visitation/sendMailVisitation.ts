import { authApi } from "@/apis";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import { SendMailVisitationRequest } from "@/models/visitation/SendMailVisitation";

export const sendMailVisitation = async (params: {
  id: number;
  request: SendMailVisitationRequest;
}) => {
  const requestFormat = { ...params?.request };
  const response = await authApi.post(
    `${VISITATION_ROOT_PATH}/${params?.id}/send-mail`,
    requestFormat
  );
  return response.status;
};
