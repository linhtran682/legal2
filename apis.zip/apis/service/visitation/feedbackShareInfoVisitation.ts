import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateFeedbackShareInfoVisitationBody,
  CreateFeedbackShareInfoVisitationOptions,
  FeedbackShareInfoVisitationSchemaI,
  GetShareInfoRequestOptions,
  ShareInfoRequestQueryFnTypeList,
  ResponsesShareInfoRequestDTO,
  GetFeedbackShareInfoListOptions,
  FeedbackShareInfoListQueryFnTypeList,
  ResponsesFeedbackShareInfoListDTO,
  UpdateFeedbackShareInfoVisitationBody,
  UpdateFeedbackShareInfoVisitationOptions,
} from "@/models/visitation/FeedbackShareInfoVisitation";

export const USE_GET_SHARE_INFO_REQUEST = "useGetFeedbackShareInfo";
export const USE_GET_FEEDBACK_SHARE_INFO_LIST = "useGetFeedbackShareInfoList";

// Create
export const createFeedbackShareInfoVisitationMutationFn = ({
  visitationId,
  data,
}: CreateFeedbackShareInfoVisitationBody): Promise<FeedbackShareInfoVisitationSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/share-information/feedback`,
    data
  );
};

export const useCreateFeedbackShareInfoVisitation = ({
  config,
}: CreateFeedbackShareInfoVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackShareInfoVisitationMutationFn,
  });
};

// Update
export const updateFeedbackShareInfoVisitationMutationFn = ({
  visitationId,
  shareId,
  data,
}: UpdateFeedbackShareInfoVisitationBody): Promise<FeedbackShareInfoVisitationSchemaI> => {
  return authApi.put(
    `${VISITATION_ROOT_PATH}/${visitationId}/share-information/feedback/${shareId}`,
    data
  );
};

export const useUpdateFeedbackShareInfoVisitation = ({
  config,
}: UpdateFeedbackShareInfoVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateFeedbackShareInfoVisitationMutationFn,
  });
};

// Get share info request
export const getShareInfoRequestMutationFn = async (request: {
  visitationId?: number;
}): Promise<ResponsesShareInfoRequestDTO> => {
  const { visitationId } = request;
  const response = await authApi.get(
    `${VISITATION_ROOT_PATH}/${visitationId}/share-information/request`
  );
  return response?.data?.result;
};

export const useGetShareInfoRequest = ({
  config,
  request,
}: GetShareInfoRequestOptions) => {
  return useQuery<ExtractFnReturnType<ShareInfoRequestQueryFnTypeList>>({
    ...config,
    queryKey: [USE_GET_SHARE_INFO_REQUEST, request],
    queryFn: () => getShareInfoRequestMutationFn(request),
  });
};

// Get feedback share info list
export const getFeedbackShareInfoListMutationFn = async (request: {
  visitationId?: number;
}): Promise<ResponsesFeedbackShareInfoListDTO> => {
  const { visitationId } = request;
  const response = await authApi.get(
    `${VISITATION_ROOT_PATH}/${visitationId}/share-information/feedback`
  );
  return response?.data?.result;
};

export const useGetFeedbackShareInfoList = ({
  config,
  request,
}: GetFeedbackShareInfoListOptions) => {
  return useQuery<ExtractFnReturnType<FeedbackShareInfoListQueryFnTypeList>>({
    ...config,
    queryKey: [USE_GET_FEEDBACK_SHARE_INFO_LIST, request],
    queryFn: () => getFeedbackShareInfoListMutationFn(request),
  });
};
