import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateConfirmVisitationBody,
  CreateConfirmVisitationOptions,
  ConfirmVisitationSchemaI,
  ResponsesConfirmVisitationListDTO,
  GetConfirmVisitationListOptions,
  ConfirmVisitationListQueryFnTypeList,
  UpdateConfirmVisitationBody,
  UpdateConfirmVisitationOptions,
} from "@/models/visitation/ConfirmVisitation";

export const USE_GET_CONFIRM_VISITATION_LIST = "useGetConfirmVisitationList";

// Create
export const createConfirmVisitationMutationFn = ({
  visitationId,
  data,
}: CreateConfirmVisitationBody): Promise<ConfirmVisitationSchemaI> => {
  return authApi.post(`${VISITATION_ROOT_PATH}/${visitationId}/confirm`, data);
};

export const useCreateConfirmVisitation = ({
  config,
}: CreateConfirmVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createConfirmVisitationMutationFn,
  });
};

// Update
export const updateConfirmVisitationMutationFn = ({
  visitationId,
  confirmId,
  data,
}: UpdateConfirmVisitationBody): Promise<ConfirmVisitationSchemaI> => {
  return authApi.put(
    `${VISITATION_ROOT_PATH}/${visitationId}/confirm/${confirmId}`,
    data
  );
};

export const useUpdateConfirmVisitation = ({
  config,
}: UpdateConfirmVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateConfirmVisitationMutationFn,
  });
};

// Get confirm visitation list
export const getConfirmVisitationListMutationFn = async (request: {
  visitationId?: number;
}): Promise<ResponsesConfirmVisitationListDTO> => {
  const { visitationId } = request;
  const response = await authApi.get(
    `${VISITATION_ROOT_PATH}/${visitationId}/confirm`
  );
  return response?.data?.result;
};

export const useGetConfirmVisitationList = ({
  config,
  request,
}: GetConfirmVisitationListOptions) => {
  return useQuery<ExtractFnReturnType<ConfirmVisitationListQueryFnTypeList>>({
    ...config,
    queryKey: [USE_GET_CONFIRM_VISITATION_LIST, request],
    queryFn: () => getConfirmVisitationListMutationFn(request),
  });
};

// // Delete
// export const deleteConfirmVisitationMutationFn = async (bodyRequest: {
//   visitationId: number;
//   confirmId: number;
// }): Promise<any> => {
//   const { visitationId, confirmId } = bodyRequest;
//   const response = await authApi.delete(
//     `${VISITATION_ROOT_PATH}/${visitationId}/confirm/${confirmId}`
//   );

//   return response.status;
// };

// export const useDeleteConfirmVisitation = ({
//   config,
// }: DeleteConfirmVisitationOptions = {}) => {
//   return useMutation({
//     ...config,
//     mutationFn: deleteConfirmVisitationMutationFn,
//   });
// };
