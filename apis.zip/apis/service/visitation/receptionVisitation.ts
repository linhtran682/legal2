import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateReceptionVisitationBody,
  CreateReceptionVisitationOptions,
  ReceptionSchemaI,
} from "@/models/visitation/ReceptionVisitation";

export const createReceptionVisitationMutationFn = ({
  visitationId,
  data,
}: CreateReceptionVisitationBody): Promise<ReceptionSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/reception`,
    data
  );
};

export const useCreateReceptionVisitation = ({
  config,
}: CreateReceptionVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createReceptionVisitationMutationFn,
  });
};
