import { authApi, ResponseWrapper } from "@/apis";
import { GetStatusVisitationListResponse } from "@/models/visitation/StatusVisitation";

const STATUS_VIOLATION_PATH = "status/visitation";

export const getStatusVisitationList = async () => {
  const response = await authApi.get<
    ResponseWrapper<GetStatusVisitationListResponse>
  >(STATUS_VIOLATION_PATH, {});
  return response.data.result;
};
