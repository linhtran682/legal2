import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateReceptionResultVisitationBody,
  CreateReceptionResultVisitationOptions,
  ReceptionResultVisitationSchemaI,
  ResponsesReceptionResultVisitationListDTO,
  GetReceptionResultVisitationListOptions,
  ReceptionResultVisitationListQueryFnTypeList,
  UpdateReceptionResultVisitationBody,
  UpdateReceptionResultVisitationOptions,
  DeleteReceptionResultOptions,
} from "@/models/visitation/ReceptionResultVisitation";

export const USE_GET_CONFIRM_VISITATION_LIST = "useGetReceptionResultVisitationList";

// Create
export const createReceptionResultVisitationMutationFn = ({
  visitationId,
  data,
}: CreateReceptionResultVisitationBody): Promise<ReceptionResultVisitationSchemaI> => {
  return authApi.post(`${VISITATION_ROOT_PATH}/${visitationId}/reception-result`, data);
};

export const useCreateReceptionResultVisitation = ({
  config,
}: CreateReceptionResultVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createReceptionResultVisitationMutationFn,
  });
};

// Update
export const updateReceptionResultVisitationMutationFn = ({
  visitationId,
  receptionResultId,
  data,
}: UpdateReceptionResultVisitationBody): Promise<ReceptionResultVisitationSchemaI> => {
  return authApi.put(
    `${VISITATION_ROOT_PATH}/${visitationId}/reception-result/${receptionResultId}`,
    data
  );
};

export const useUpdateReceptionResultVisitation = ({
  config,
}: UpdateReceptionResultVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateReceptionResultVisitationMutationFn,
  });
};

// Get reception result visitation list
export const getReceptionResultVisitationListMutationFn = async (request: {
  visitationId?: number;
}): Promise<ResponsesReceptionResultVisitationListDTO> => {
  const { visitationId } = request;
  const response = await authApi.get(
    `${VISITATION_ROOT_PATH}/${visitationId}/reception-result/list`
  );
  return response?.data?.result;
};

export const useGetReceptionResultVisitationList = ({
  config,
  request,
}: GetReceptionResultVisitationListOptions) => {
  return useQuery<ExtractFnReturnType<ReceptionResultVisitationListQueryFnTypeList>>({
    ...config,
    queryKey: [USE_GET_CONFIRM_VISITATION_LIST, request],
    queryFn: () => getReceptionResultVisitationListMutationFn(request),
  });
};

// Delete
export const deleteReceptionResultVisitationMutationFn = async (bodyRequest: {
  visitationId: number;
  resultId: number;
}): Promise<any> => {
  const { visitationId, resultId } = bodyRequest;
  const response = await authApi.delete(
    `${VISITATION_ROOT_PATH}/${visitationId}/reception-result/${resultId}`
  );

  return response.status;
};

export const useDeleteReceptionResultVisitation = ({
  config,
}: DeleteReceptionResultOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteReceptionResultVisitationMutationFn,
  });
};
