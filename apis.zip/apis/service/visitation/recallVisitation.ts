import { authApi, MutationConfig } from "@/apis";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import { useMutation } from "@tanstack/react-query";

export interface RecallVisitationOptions {
  config?: MutationConfig<typeof recallVisitationMutationFn>;
}

export const recallVisitationMutationFn = (violationId?: number): Promise<any> => {
  return authApi.post(`${VISITATION_ROOT_PATH}/${violationId}/recall`);
};

export const useRecallVisitation = ({
  config,
}: RecallVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: recallVisitationMutationFn,
  });
};
