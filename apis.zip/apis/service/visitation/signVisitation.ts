import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateSignVisitationBody,
  CreateSignVisitationOptions,
  SignVisitationSchemaI,
} from "@/models/visitation/SignVisitation";

export const USE_GET_SHARE_INFO_REQUEST = "useGetSign";
export const USE_GET_FEEDBACK_SHARE_INFO_LIST = "useGetSignList";

// Create
export const createSignVisitationMutationFn = ({
  visitationId,
  data,
}: CreateSignVisitationBody): Promise<SignVisitationSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/sign/approval`,
    data
  );
};

export const useCreateSignVisitation = ({
  config,
}: CreateSignVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createSignVisitationMutationFn,
  });
};

// // Update
// export const updateSignVisitationMutationFn = ({
//   visitationId,
//   shareId,
//   data,
// }: UpdateSignVisitationBody): Promise<SignVisitationSchemaI> => {
//   return authApi.put(
//     `${VISITATION_ROOT_PATH}/${visitationId}/share-information/feedback/${shareId}`,
//     data
//   );
// };

// export const useUpdateSignVisitation = ({
//   config,
// }: UpdateSignVisitationOptions = {}) => {
//   return useMutation({
//     ...config,
//     mutationFn: updateSignVisitationMutationFn,
//   });
// };

// // Get share info request
// export const getShareInfoRequestMutationFn = async (request: {
//   visitationId?: number;
// }): Promise<ResponsesShareInfoRequestDTO> => {
//   const { visitationId } = request;
//   const response = await authApi.get(
//     `${VISITATION_ROOT_PATH}/${visitationId}/share-information/request`
//   );
//   return response?.data?.result;
// };

// export const useGetShareInfoRequest = ({
//   config,
//   request,
// }: GetShareInfoRequestOptions) => {
//   return useQuery<ExtractFnReturnType<ShareInfoRequestQueryFnTypeList>>({
//     ...config,
//     queryKey: [USE_GET_SHARE_INFO_REQUEST, request],
//     queryFn: () => getShareInfoRequestMutationFn(request),
//   });
// };

// // Get feedback share info list
// export const getSignListMutationFn = async (request: {
//   visitationId?: number;
// }): Promise<ResponsesSignListDTO> => {
//   const { visitationId } = request;
//   const response = await authApi.get(
//     `${VISITATION_ROOT_PATH}/${visitationId}/share-information/feedback`
//   );
//   return response?.data?.result;
// };

// export const useGetSignList = ({
//   config,
//   request,
// }: GetSignListOptions) => {
//   return useQuery<ExtractFnReturnType<SignListQueryFnTypeList>>({
//     ...config,
//     queryKey: [USE_GET_FEEDBACK_SHARE_INFO_LIST, request],
//     queryFn: () => getSignListMutationFn(request),
//   });
// };
