import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  CreateTimeExtensionVisitationBody,
  CreateTimeExtensionVisitationOptions,
  GetTimeExtensionVisitationIdOptions,
  QueryFnTypeVisitation,
  RequestApprovalDTO,
  TimeExtensionVisitationParams,
  UpdateTimeExtensionVisitationAcceptOptions,
  UpdateTimeExtensionVisitationBody,
} from "@/models/visitation/TimeExtensionVisitation";
import { VISITATION_ROOT_PATH } from "@/constants/paths";

export const GET_TIME_EXTENSION_VISITATION = "useGetTimeExtensionVisitation";

// Create
export const createTimeExtensionVisitationMutationFn = ({
  visitationId,
  data,
}: CreateTimeExtensionVisitationBody): Promise<any> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/time-extension`,
    data
  );
};

export const useCreateTimeExtensionVisitation = ({
  config,
}: CreateTimeExtensionVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionVisitationMutationFn,
  });
};

// Get
export const getTimeExtensionVisitationQueryFn = async (
  request: TimeExtensionVisitationParams
): Promise<RequestApprovalDTO> => {
  const { visitationId, timeExtensionRequestId } = request;
  const response = await authApi.get(
    `${VISITATION_ROOT_PATH}/${visitationId}/time-extension/${timeExtensionRequestId}`
  );
  return response.data.result;
};

export const useGetTimeExtensionVisitation = ({
  config,
  request,
}: GetTimeExtensionVisitationIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeVisitation>>({
    ...config,
    queryKey: [GET_TIME_EXTENSION_VISITATION, request],
    queryFn: () => getTimeExtensionVisitationQueryFn(request),
  });
};

// Update
export const updateTimeExtensionVisitationMutationFn = async (
  request: UpdateTimeExtensionVisitationBody
): Promise<any> => {
  const { visitationId, timeExtensionRequestId, data } = request;
  const response = await authApi.put(
    `${VISITATION_ROOT_PATH}/${visitationId}/time-extension/${timeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtensionVisitation = ({
  config,
}: UpdateTimeExtensionVisitationAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionVisitationMutationFn,
  });
};
