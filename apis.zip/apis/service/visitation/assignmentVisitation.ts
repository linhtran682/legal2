import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import {
  AssignmentVisitationSchemaI,
  CreateAssignmentVisitationBody,
  CreateAssignmentVisitationOptions,
} from "@/models/visitation/AssignmentVisitation";
import { VISITATION_ROOT_PATH } from "@/constants/paths";

export const createAssignmentVisitationMutationFn = ({
  visitationId,
  data,
}: CreateAssignmentVisitationBody): Promise<AssignmentVisitationSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/assignment`,
    data
  );
};

export const useCreateAssignmentVisitation = ({
  config,
}: CreateAssignmentVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAssignmentVisitationMutationFn,
  });
};
