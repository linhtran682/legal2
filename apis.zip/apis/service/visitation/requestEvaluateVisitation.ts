import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateRequestEvaluateVisitationBody,
  CreateRequestEvaluateVisitationOptions,
  RequestEvaluateSchemaI,
} from "@/models/visitation/RequestEvaluateVisitation";

export const createRequestEvaluateVisitationMutationFn = ({
  visitationId,
  data,
}: CreateRequestEvaluateVisitationBody): Promise<RequestEvaluateSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/evaluate/request`,
    data
  );
};

export const useCreateRequestEvaluateVisitation = ({
  config,
}: CreateRequestEvaluateVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestEvaluateVisitationMutationFn,
  });
};
