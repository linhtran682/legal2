import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateEvaluateVisitationBody,
  CreateEvaluateVisitationOptions,
  EvaluateVisitationSchemaI,
  ResponsesEvaluateVisitationListDTO,
  GetEvaluateVisitationListOptions,
  EvaluateVisitationListQueryFnTypeList,
  UpdateEvaluateVisitationBody,
  UpdateEvaluateVisitationOptions,
} from "@/models/visitation/EvaluateVisitation";

export const USE_GET_EVALUATE_VISITATION_LIST = "useGetEvaluateVisitationList";

// Create
export const createEvaluateVisitationMutationFn = ({
  visitationId,
  data,
}: CreateEvaluateVisitationBody): Promise<EvaluateVisitationSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/evaluate/feedback`,
    data
  );
};

export const useCreateEvaluateVisitation = ({
  config,
}: CreateEvaluateVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createEvaluateVisitationMutationFn,
  });
};

// Update
export const updateEvaluateVisitationMutationFn = ({
  visitationId,
  feedbackId,
  data,
}: UpdateEvaluateVisitationBody): Promise<EvaluateVisitationSchemaI> => {
  return authApi.put(
    `${VISITATION_ROOT_PATH}/${visitationId}/evaluate/feedback/${feedbackId}`,
    data
  );
};

export const useUpdateEvaluateVisitation = ({
  config,
}: UpdateEvaluateVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateEvaluateVisitationMutationFn,
  });
};

// // Delete
// export const deleteEvaluateVisitationMutationFn = async (bodyRequest: {
//   visitationId: number;
//   feedbackId: number;
// }): Promise<any> => {
//   const { visitationId, feedbackId } = bodyRequest;
//   const response = await authApi.delete(
//     `${VISITATION_ROOT_PATH}/${visitationId}/evaluate/feedback/${feedbackId}`
//   );

//   return response.status;
// };

// export const useDeleteEvaluateVisitation = ({
//   config,
// }: DeleteEvaluateVisitationOptions = {}) => {
//   return useMutation({
//     ...config,
//     mutationFn: deleteEvaluateVisitationMutationFn,
//   });
// };

// Get confirm visitation list
export const getEvaluateVisitationListMutationFn = async (request: {
  visitationId?: number;
}): Promise<ResponsesEvaluateVisitationListDTO> => {
  const { visitationId } = request;
  const response = await authApi.get(
    `${VISITATION_ROOT_PATH}/${visitationId}/evaluate/feedback/list`
  );
  return response?.data?.result;
};

export const useGetEvaluateVisitationList = ({
  config,
  request,
}: GetEvaluateVisitationListOptions) => {
  return useQuery<ExtractFnReturnType<EvaluateVisitationListQueryFnTypeList>>({
    ...config,
    queryKey: [USE_GET_EVALUATE_VISITATION_LIST, request],
    queryFn: () => getEvaluateVisitationListMutationFn(request),
  });
};
