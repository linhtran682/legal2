import { authApi } from "@/apis";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateFeedbackVisitationBody,
  CreateFeedbackVisitationOptions,
  FeedbackVisitationSchemaI,
} from "@/models/visitation/FeedBackVisitation";
import { useMutation } from "@tanstack/react-query";

export const createFeedbackVisitationMutationFn = ({
  visitationId,
  data,
}: CreateFeedbackVisitationBody): Promise<FeedbackVisitationSchemaI> => {
  return authApi.post(`${VISITATION_ROOT_PATH}/${visitationId}/feedback`, data);
};

export const useCreateFeedbackVisitation = ({
  config,
}: CreateFeedbackVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedbackVisitationMutationFn,
  });
};
