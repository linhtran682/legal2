import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateFinishVisitationBody,
  CreateFinishVisitationOptions,
  FinishSchemaI,
} from "@/models/visitation/FinishVisitation";

export const createFinishVisitationMutationFn = ({
  visitationId,
  data,
}: CreateFinishVisitationBody): Promise<FinishSchemaI> => {
  return authApi.post(`${VISITATION_ROOT_PATH}/${visitationId}/finish`, data);
};

export const useCreateFinishVisitation = ({
  config,
}: CreateFinishVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFinishVisitationMutationFn,
  });
};
