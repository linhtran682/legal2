import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateShareInfoVisitationBody,
  CreateShareInfoVisitationOptions,
  ShareInfoVisitationSchemaI,
} from "@/models/visitation/ShareInfoVisitation";

export const createShareInfoVisitationMutationFn = ({
  visitationId,
  data,
}: CreateShareInfoVisitationBody): Promise<ShareInfoVisitationSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/share-information/request`,
    data
  );
};

export const useCreateShareInfoVisitation = ({
  config,
}: CreateShareInfoVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createShareInfoVisitationMutationFn,
  });
};
