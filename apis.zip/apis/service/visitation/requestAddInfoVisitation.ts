import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateRequestAddInfoVisitationBody,
  CreateRequestAddInfoVisitationOptions,
  RequestAddInfoVisitationSchemaI,
} from "@/models/visitation/RequestAddInfoVisitation";

export const createRequestAddInfoVisitationMutationFn = ({
  visitationId,
  data,
}: CreateRequestAddInfoVisitationBody): Promise<RequestAddInfoVisitationSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/information-request`,
    data
  );
};

export const useCreateRequestAddInfoVisitation = ({
  config,
}: CreateRequestAddInfoVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestAddInfoVisitationMutationFn,
  });
};
