import { authApi } from "@/apis";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateForwardVisitationBody,
  CreateForwardVisitationOptions,
  ForwardVisitationSchemaI,
} from "@/models/visitation/ForwardVisitation";
import { useMutation } from "@tanstack/react-query";

export const createForwardVisitationMutationFn = ({
  visitationId,
  data,
}: CreateForwardVisitationBody): Promise<ForwardVisitationSchemaI> => {
  return authApi.post(`${VISITATION_ROOT_PATH}/${visitationId}/forward`, data);
};

export const useCreateForwardForwardFollow = ({
  config,
}: CreateForwardVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createForwardVisitationMutationFn,
  });
};
