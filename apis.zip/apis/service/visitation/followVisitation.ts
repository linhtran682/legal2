import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateFollowVisitationBody,
  CreateFollowVisitationOptions,
  FollowVisitationSchemaI,
  ResponsesFollowVisitationListDTO,
  GetFollowVisitationListOptions,
  FollowVisitationListQueryFnTypeList,
  UpdateFollowVisitationBody,
  UpdateFollowVisitationOptions,
  DeleteFollowVisitationOptions,
} from "@/models/visitation/FollowVisitation";

export const USE_GET_FOLLOW_VISITATION_LIST = "useGetFollowVisitationList";

// Create
export const createFollowVisitationMutationFn = ({
  visitationId,
  data,
}: CreateFollowVisitationBody): Promise<FollowVisitationSchemaI> => {
  return authApi.post(`${VISITATION_ROOT_PATH}/${visitationId}/follow`, data);
};

export const useCreateFollowVisitation = ({
  config,
}: CreateFollowVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFollowVisitationMutationFn,
  });
};

// Update
export const updateFollowVisitationMutationFn = ({
  visitationId,
  followId,
  data,
}: UpdateFollowVisitationBody): Promise<FollowVisitationSchemaI> => {
  return authApi.put(
    `${VISITATION_ROOT_PATH}/${visitationId}/follow/${followId}`,
    data
  );
};

export const useUpdateFollowVisitation = ({
  config,
}: UpdateFollowVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateFollowVisitationMutationFn,
  });
};

// Get reception result visitation list
export const getFollowVisitationListMutationFn = async (request: {
  visitationId?: number;
}): Promise<ResponsesFollowVisitationListDTO> => {
  const { visitationId } = request;
  const response = await authApi.get(
    `${VISITATION_ROOT_PATH}/${visitationId}/follow/list`
  );
  return response?.data?.result;
};

export const useGetFollowVisitationList = ({
  config,
  request,
}: GetFollowVisitationListOptions) => {
  return useQuery<ExtractFnReturnType<FollowVisitationListQueryFnTypeList>>({
    ...config,
    queryKey: [USE_GET_FOLLOW_VISITATION_LIST, request],
    queryFn: () => getFollowVisitationListMutationFn(request),
  });
};

// Delete
export const deleteFollowVisitationMutationFn = async (bodyRequest: {
  visitationId: number;
  resultId: number;
}): Promise<any> => {
  const { visitationId, resultId } = bodyRequest;
  const response = await authApi.delete(
    `${VISITATION_ROOT_PATH}/${visitationId}/follow/${resultId}`
  );

  return response.status;
};

export const useDeleteFollowVisitation = ({
  config,
}: DeleteFollowVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: deleteFollowVisitationMutationFn,
  });
};
