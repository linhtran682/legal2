import { authApi, ExtractFnReturnType, QueryConfig, ResponseWrapper } from "@/apis";
import { FileDetails } from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GetDepartmentHeadResponse } from "@/models/department/Department";
import {
  GetHistoryResponse,
  GetMeetingResponse,
} from "@/models/metadata/Metadata";
import { StatusDTO } from "@/models/status/Status";
import {
  CreateVisitationOptions,
  GetVisitationAssignmentResponse,
  GetVisitationAttachmentsResponse,
  GetVisitationCommentsResponse,
  GetVisitationEvaluateResponse,
  GetVisitationExtensionResponse,
  GetVisitationForwardResponse,
  GetVisitationInformationRequestsResponse,
  GetVisitationOptions,
  GetVisitationRequestFeedbackResponse,
  GetVisitationShareInformationResponse,
  GetVisitationSignTabResponse,
  GetVisitationStatusOptions,
  QueryVisitationFnType,
  QueryVisitationStatusFnType,
  SignApproveBodyReceived,
  SignApproveBodySend,
  SignDefaultResponse,
  UpdateBookMeetingVisitationOptions,
  UpdateVisitationOptions,
  UpdateVisitationRequest,
  VisitationBodyReceive,
  VisitationBodySend,
  VisitationConfirmReceived,
  VisitationEvaluatedFeedBackReceived,
  VisitationFollowReceived,
  VisitationParams,
  VisitationReceptionResultReceived,
  VisitationSpPermissionResponse
} from "@/models/visitation/VisitationDetail";
import { GetVisitationListParams, GetVisitationListResponse, VisitationStatisticChartResponse } from "@/models/visitation/VisitationList";
import { useMutation, useQuery } from "@tanstack/react-query";

export const VISITATION = "visitation";

export const getVisitationExcel = async (
  params: GetVisitationListParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${VISITATION}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getAllHierarchyById = async (params: { id: number | string }) => {
  const response = await authApi.get(
    `/${VISITATION}/${params.id}/all-hierarchy`
  );
  return response.data?.result;
};

export const getListVisitationQueryFn = async (
  params: GetVisitationListParams
) => {
  const response = await authApi.get<ResponseWrapper<GetVisitationListResponse>>(VISITATION, { params });
  return response.data.result;
};

export const getVisitationQueryFn = async (
  request: VisitationParams
): Promise<VisitationBodyReceive> => {
  const { id } = request;
  const response = await authApi.get(`${VISITATION}/${id}`);
  return response.data.result;
};


export const useGetVisitationDetail = ({
  config,
  request,
}: GetVisitationOptions) => {
  return useQuery<ExtractFnReturnType<QueryVisitationFnType>>({
    ...config,
    queryKey: ["get_initial_visitation_detail", request.id],
    queryFn: () => getVisitationQueryFn(request),
  });
};

export const getSignApproveQueryFn = async (
  request: VisitationParams
): Promise<SignApproveBodyReceived> => {
  const { id } = request;
  const response = await authApi.get(`${VISITATION}/${id}/sign`);
  return response.data.result;
};

export type QuerySignApproveFnType = typeof getSignApproveQueryFn;

export type GetSignApproveOptions = {
  config?: QueryConfig<QuerySignApproveFnType>;
  request: VisitationParams;
};

export const useGetSignApproveTab = ({
  config,
  request,
}: GetSignApproveOptions) => {
  return useQuery<ExtractFnReturnType<QuerySignApproveFnType>>({
    ...config,
    queryKey: ["get_sign_approve_tab", request.id],
    queryFn: () => getSignApproveQueryFn(request),
    enabled: !!request?.id,
  });
};

export const createVisitationMutationFn = async (
  data: VisitationBodySend
): Promise<any> => {
  const response = await authApi.post(VISITATION, data);
  return response.status;
};

export const useCreateVisitation = ({
  config,
}: CreateVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createVisitationMutationFn,
  });
};


export const updateVisitationMutationFn = async (
  bodyRequest: UpdateVisitationRequest
): Promise<any> => {
  const { id, request } = bodyRequest;
  const response = await authApi.put(`${VISITATION}/${id}`, request);

  return response.status;
};

export const useUpdateVisitation = ({
  config,
}: UpdateVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateVisitationMutationFn,
  });
};

export const updateBookMeetingVisitationMutationFn = async (params: {
  id?: number;
  request: {
    isBooking: boolean;
  };
}) => {
  const response = await authApi.post(
    `${VISITATION}/${params.id}/booking_status`,
    params.request
  );
  return response.status;
};

export const useUpdateBookMeetingVisitation = ({
  config,
}: UpdateBookMeetingVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateBookMeetingVisitationMutationFn,
  });
};

export const getVisitationInformationRequests = async (
  id: number
) => {
  const response = await authApi.get<ResponseWrapper<GetVisitationInformationRequestsResponse>>(
    `/${VISITATION}/${id}/information-request`
  );

  return response.data;
};

export const getVisitationEvaluate = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetVisitationEvaluateResponse>
  >(`/${VISITATION}/${id}/evaluate/feedback`);

  return response.data;
};

export const getVisitationSignTab = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetVisitationSignTabResponse>
  >(`/${VISITATION}/${id}/sign/tab/sign`);

  return response.data;
};

export const getVisitationShareInformationTab = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetVisitationShareInformationResponse>
  >(`/${VISITATION}/${id}/share-information/feedback`);

  return response.data;
};

export const getVisitationExtensions = async (id: number) => {
  const response = await authApi.get<GetVisitationExtensionResponse>(
    `/${VISITATION}/${id}/time-extension`
  );
  return response.data;
};

export const getVisitationAttachmentsTab = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetVisitationAttachmentsResponse>
  >(`${VISITATION}/${id}/attachment`);
  return response.data.result;
};

export const getVisitationRequestFeedback = async (id: number) => {
  const response = await authApi.get<GetVisitationRequestFeedbackResponse>(
    `/${VISITATION}/${id}/feedback`
  );
  return response.data;
};

export const getVisitationForwards = async (id: number) => {
  const response = await authApi.get<GetVisitationForwardResponse>(
    `/${VISITATION}/${id}/forward`
  );

  return response.data;
};

export const getVisitationCommentTab = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetVisitationCommentsResponse>
  >(`/${VISITATION}/${id}/comment`);

  return response.data;
};

export const commentVisitation = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${VISITATION}/${params.id}/comment`,
    {
      content: params.content,
    }
  );

  return response.data;
};

export const getVisitationHistory = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${VISITATION}/${id}/history`
  );
  return response.data;
};

export const getStatusVisitationQueryFn = async (): Promise<{statusResponses: StatusDTO[]}> => {
  const response = await authApi.get(`status/${VISITATION}`,
    // {
    //   params: {
    //     ...params,
    //     modules: params.modules ? params.modules.join(",") : undefined,
    //   },
    // }
  );
  return response.data.result;
};

export const useGetVisitationStatus = ({
  config,
  request,
}: GetVisitationStatusOptions) => {
  return useQuery<ExtractFnReturnType<QueryVisitationStatusFnType>>({
    ...config,
    queryKey: ["get_visitation_status", request],
    queryFn: () => getStatusVisitationQueryFn(),
  });
};

export const createSignApprove = async (params: {id: number, request: SignApproveBodySend}) => {
  const response = await authApi.post(`${VISITATION}/${params.id}/sign`, params.request);
  return response.status;
};


export const uploadFileToVisitationSign = async (
  fileDetails?: FileDetails[]
) => {
  const formData = new FormData();
  if (fileDetails) {
    fileDetails.forEach((fileDetail) => {
      fileDetail.file &&
        formData.append(`files`, fileDetail.file, fileDetail.name);
    });
    
    const response = await authApi.post(`files/visitation`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return response.data?.result?.fileUploadSharePointResponses ?? [];
  }
};


export const uploadCurrentFileToSharepoint = async ({
  visitationId,
  fileId,
}: {
  visitationId: number;
  fileId: number;
}) => {
  const response = await authApi.post(
    `/files/${VISITATION}/${visitationId}/sharepoint/${fileId}`
  );
  return response.data;
};

export const visitationConvertPDFServer = async (params: {
  id: number;
  type: number;
}): Promise<{fileId: number, fileName: string, storagePath: string}> => {
  const response = await authApi.post(
    `/${VISITATION}/convert-pdf`,params,
    {
      timeout: 60000*5, // Set a timeout of 5 minutes
    }
  );
  return response.data.result;
};

export const visitationCallToEsign = async (params: {
  id: number;
  position: number;
  request: any;
}) => {
  const response = await authApi.post(
    `${VISITATION}/${params.id}/sign/call-esign/${params.position}`, params.request
  );
  return response.status;
};

export const visitationRecallTobeSign = async (params: {
  id: number;
  position: number;
}) => {
  const response = await authApi.post(
    `${VISITATION}/${params.id}/sign/revoke/${params.position}`
  );
  return response?.status;
};

export const visitationRevokeTobeSign = async (params: {
  id: number;
  position: number;
}) => {
  const response = await authApi.delete(
    `${VISITATION}/${params.id}/sign/revoke-esign/${params.position}`
  );
  return response?.status;
};

// export const requestConfirmationAgain = async (params: {
//   id?: number;
// }) => {
//   const response = await authApi.post(
//     `${VISITATION}/${params.id}/recheck`
//   );

//   return response;
// };

export const requestReviewAgain = async (params: {
  id?: number;
}) => {
  const response = await authApi.post(
    `${VISITATION}/${params.id}/recheck/evaluate`
  );

  return response;
};

export const requestSignAgain = async (params: {
  id?: number;
}) => {
  const response = await authApi.post(
    `${VISITATION}/${params.id}/recheck/sign`
  );

  return response;
};

export const getVisitationMeeting = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetMeetingResponse>>(
    `/${VISITATION}/${id}/meeting-new`
  );

  return response.data;
};

export const createVisitationMeeting = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(
    `/${VISITATION}/${params.id}/meeting-new`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const updateVisitationMeeting = async (params: {
  id: number;
  meetingId: number;
  content: string;
}) => {
  const response = await authApi.put(
    `/${VISITATION}/${params.id}/meeting-new/${params.meetingId}`,
    {
      content: params.content,
    }
  );

  return response.data;
};
export const deleteVisitationMeeting = async (params: {
  id: number;
  meetingId: number;
}) => {
  const response = await authApi.delete(
    `/${VISITATION}/${params.id}/meeting-new/${params.meetingId}`
  );
  return response.data;
};

export type GetVisitationEvaluatedFeedbackOptions = {
  config?: QueryConfig<QueryVisitationEvaluatedFeedbackQueryFnType>;
  request: {id: number};
};

export type QueryVisitationEvaluatedFeedbackQueryFnType = typeof getVisitationEvaluatedFeedbackQueryFn;

export const getVisitationEvaluatedFeedbackQueryFn = async (
  request: {id: number}
): Promise<VisitationEvaluatedFeedBackReceived[]> => {
  const { id } = request;
  const response = await authApi.get(`${VISITATION}/${id}/evaluate/feedback/list`);
  return response.data.result?.data;
};

export const useGetVisitationEvaluatedFeedback = ({
  config,
  request,
}: GetVisitationEvaluatedFeedbackOptions) => {
  return useQuery<ExtractFnReturnType<QueryVisitationEvaluatedFeedbackQueryFnType>>({
    ...config,
    queryKey: ["get_visitation_evaluated_feedback", request.id],
    queryFn: () => getVisitationEvaluatedFeedbackQueryFn(request),
  });
};

export type QueryVisitationConfirmQueryFnType = typeof getVisitationConfirmQueryFn;

export const getVisitationConfirmQueryFn = async (id: number)
: Promise<VisitationConfirmReceived[]> => {
  const response = await authApi.get(`${VISITATION}/${id}/confirm`);
  return response.data.result?.data;
};

export const useGetVisitationConfirmList = (visitationId: number) => {
  return useQuery<ExtractFnReturnType<QueryVisitationConfirmQueryFnType>>({
    queryKey: ["get_visitation_confirm", visitationId],
    queryFn: () => getVisitationConfirmQueryFn(visitationId),
  });
};


export type QueryVisitationShareInfomationQueryFnType = typeof getVisitationShareInfomationQueryFn;

export const getVisitationShareInfomationQueryFn = async (id: number)
: Promise<VisitationConfirmReceived[]> => {
  const response = await authApi.get(`${VISITATION}/${id}/share-information/feedback`);
  return response.data.result?.data;
};

export const useGetVisitationShareInfomation = (visitationId: number) => {
  return useQuery<ExtractFnReturnType<QueryVisitationShareInfomationQueryFnType>>({
    queryKey: ["get_visitation_share_information", visitationId],
    queryFn: () => getVisitationShareInfomationQueryFn(visitationId),
  });
};


export type QueryVisitationFollowQueryFnType = typeof getVisitationFollowQueryFn;

export const getVisitationFollowQueryFn = async (id: number)
: Promise<VisitationFollowReceived[]> => {
  const response = await authApi.get(`${VISITATION}/${id}/follow/list`);
  return response.data.result?.data;
};

export const useGetVisitationFollowList = (visitationId: number) => {
  return useQuery<ExtractFnReturnType<QueryVisitationFollowQueryFnType>>({
    queryKey: ["get_visitation_follow", visitationId],
    queryFn: () => getVisitationFollowQueryFn(visitationId),
  });
};

export type QueryVisitationReceptionResultQueryFnType = typeof getVisitationReceptionResultQueryFn;

export const getVisitationReceptionResultQueryFn = async (id: number)
: Promise<VisitationReceptionResultReceived[]> => {
  const response = await authApi.get(`${VISITATION}/${id}/reception-result/list`);
  return response.data.result?.data;
};

export const useGetVisitationReceptionResultList = (visitationId: number) => {
  return useQuery<ExtractFnReturnType<QueryVisitationReceptionResultQueryFnType>>({
    queryKey: ["get_visitation_reception_result", visitationId],
    queryFn: () => getVisitationReceptionResultQueryFn(visitationId),
  });
};

export const shareVisitationFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number;
  };
}) => {
  const response = await authApi.post(
    `/${VISITATION}/${params.id}/share`,
    params.data
  );

  return response.data;
};

export const getDepartmentHeadsVisitation = async (id: number | string) => {
  const response = await authApi.get<GetDepartmentHeadResponse>(
    `/${VISITATION}/department-head?visitationId=${id}`
  );
  return response.data;
};

export const checkSharePointPermissionVisitationFn = async () => {
  const response = await authApi.get<ResponseWrapper<VisitationSpPermissionResponse>>(
    `${VISITATION}/check-sharepoint`
  );
  return response.data.result;
};

export const getVisitationAssignments = async (id: number) => {
  const response = await authApi.get<GetVisitationAssignmentResponse>(
    `/${VISITATION}/${id}/assignment`
  );
  return response.data;
};

export const getSignDefaultQueryFn = async (
  id: number
): Promise<SignDefaultResponse> => {
  const response = await authApi.get(`${VISITATION}/${id}/sign/default`);
  return response.data.result;
};

export type QuerySignDefaultFnType = typeof getSignDefaultQueryFn;

export type GetSignDefaultOptions = {
  config?: QueryConfig<QuerySignDefaultFnType>;
  id: number;
};

export const useGetSignDefault = ({
  config,
  id,
}: GetSignDefaultOptions) => {
  return useQuery<ExtractFnReturnType<QuerySignDefaultFnType>>({
    ...config,
    queryKey: ["get_sign_default", id],
    queryFn: () => getSignDefaultQueryFn(id),
    enabled: !!id,
  });
};

export const getVisitationStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<VisitationStatisticChartResponse>
  >(`/${VISITATION}/statistic/chart`);
  return response.data.result;
};

export const getVisitationStatisticTableFn = async (params: GetVisitationListParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetVisitationListResponse>
  >(`/${VISITATION}/statistic/table`, {
    params: params,
  });
  return response.data.result;
};
