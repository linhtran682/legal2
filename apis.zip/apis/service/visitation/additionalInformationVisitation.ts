import { authApi, MutationConfig } from "@/apis";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import { useMutation } from "@tanstack/react-query";

export interface AdditionalInformationOptions {
  config?: MutationConfig<typeof additionalInformationVisitationMutationFn>;
}

export const additionalInformationVisitationMutationFn = (
  violationId?: number
): Promise<any> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${violationId}/information-request/update`
  );
};

export const useAdditionalInformationVisitation = ({
  config,
}: AdditionalInformationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: additionalInformationVisitationMutationFn,
  });
};
