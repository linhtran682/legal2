import { authApi } from "@/apis";
import { useMutation } from "@tanstack/react-query";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import {
  CreateRequestSignVisitationBody,
  CreateRequestSignVisitationOptions,
  RequestSignSchemaI,
} from "@/models/visitation/RequestSignVisitation";

export const createRequestSignVisitationMutationFn = ({
  visitationId,
  data,
}: CreateRequestSignVisitationBody): Promise<RequestSignSchemaI> => {
  return authApi.post(
    `${VISITATION_ROOT_PATH}/${visitationId}/sign/request`,
    data
  );
};

export const useCreateRequestSignVisitation = ({
  config,
}: CreateRequestSignVisitationOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestSignVisitationMutationFn,
  });
};
