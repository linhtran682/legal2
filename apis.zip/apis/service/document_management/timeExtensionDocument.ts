import { authApi, ExtractFnReturnType } from "@/apis";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  CreateTimeExtensionBody,
  CreateTimeExtensionOptions,
  GetTimeExtensionIdOptions,
  QueryFnType,
  RequestApprovalDTO,
  TimeExtensionParams,
  UpdateTimeExtensionAcceptOptions,
  UpdateTimeExtensionBody,
} from "@/models/document_management/TimeExtensionDocument";

const DOCUMENT_MANAGEMENT = "document-management";
export const GET_TIME_EXTENSION_DOCUMENT = "useGetTimeExtensionDocument";

export const createTimeExtensionMutationFn = ({
  documentId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(`${DOCUMENT_MANAGEMENT}/${documentId}/time-extension`, data);
};

export const useCreateTimeExtension = ({
  config,
}: CreateTimeExtensionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionMutationFn,
  });
};

export const getTimeExtensionQueryFn = async (
  request: TimeExtensionParams
): Promise<RequestApprovalDTO> => {
  const { documentId, timeExtensionRequestId } = request;
  const response = await authApi.get(
    `${DOCUMENT_MANAGEMENT}/${documentId}/time-extension/${timeExtensionRequestId}`
  );
  return response.data.result;
};

export const useGetTimeExtension = ({
  config,
  request,
}: GetTimeExtensionIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_TIME_EXTENSION_DOCUMENT, request],
    queryFn: () => getTimeExtensionQueryFn(request),
  });
};

export const updateTimeExtensionMutationFn = async (
  request: UpdateTimeExtensionBody
): Promise<any> => {
  const { documentId, timeExtensionRequestId, data } = request;
  const response = await authApi.put(
    `${DOCUMENT_MANAGEMENT}/${documentId}/time-extension/${timeExtensionRequestId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtension = ({
  config,
}: UpdateTimeExtensionAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionMutationFn,
  });
};
