import { authApi, ExtractFnReturnType } from "@/apis";
import {
  CreateRequestAdditionalBody,
  CreateRequestAdditionalOptions,
  GetRequestAdditionalIdOptions,
  QueryFnType,
  RequestAdditionalDTO,
  RequestAdditionalParams,
  RequestAdditionalSchemaI,
} from "@/models/document_management/RequestAdditionalForm";
import { useMutation, useQuery } from "@tanstack/react-query";

const DOCUMENT_MANAGEMENT = "document-management";
const GET_REQUEST_ADDITIONAL_DOCUMENT = "getRequestAdditional";

export const createRequestAdditionalMutationFn = ({
  documentId,
  data,
}: CreateRequestAdditionalBody): Promise<RequestAdditionalSchemaI> => {
  return authApi.post(
    `${DOCUMENT_MANAGEMENT}/${documentId}/information-request`,
    data
  );
};

export const useCreateRequestAdditional = ({
  config,
}: CreateRequestAdditionalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestAdditionalMutationFn,
  });
};

export const getRequestAdditionalQueryFn = async (
  request: RequestAdditionalParams
): Promise<RequestAdditionalDTO> => {
  const { documentId, informationRequestId } = request;
  const response = await authApi.get(
    `${DOCUMENT_MANAGEMENT}/${documentId}/information-request/${informationRequestId}`
  );
  return response.data.result;
};

export const useGetRequestAdditional = ({
  config,
  request,
}: GetRequestAdditionalIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_REQUEST_ADDITIONAL_DOCUMENT, request],
    queryFn: () => getRequestAdditionalQueryFn(request),
  });
};
