import { authApi, ResponseWrapper } from "@/apis";
import {
  BasedDocumentManagementBodyReceive,
  BasedDocumentManagementBodySend,
  CreateStockModel,
  DepartmentStockModelDetail,
  DocumentManagementParams,
  DocumentMngResponse,
  DocumentMngStatisticChartResponse,
  DocumentMoveModel,
  FoldersModel,
  GetDocumentManagementTabAttachmentsResponse,
} from "@/models/document_management/DocumentManagement";
import { DetailInformationRequestResponses } from "@/models/document_management/DocumentManagementTab";
import { GetAdviceExtensionResponse } from "@/models/legal-advice/LegalAdviceList";
import {
  GetCommentsResponse,
  GetForwardsResponseDocumentMng,
  GetHistoryResponse,
} from "@/models/metadata/Metadata";

const DOCUMENT_MANAGEMENT_PATH = "document-management";

export const getDocumentManagements = async (
  params: DocumentManagementParams
) => {
  const response = await authApi.get<DocumentMngResponse>(
    DOCUMENT_MANAGEMENT_PATH,
    {
      params: params,
    }
  );
  return response.data;
};
export const getDocumentManagement = async (documentId: number) => {
  const response = await authApi.get<
    ResponseWrapper<BasedDocumentManagementBodyReceive>
  >(`${DOCUMENT_MANAGEMENT_PATH}/${documentId}`);
  return response.data?.result;
};
export const createDocumentManagement = async (
  bodySend: BasedDocumentManagementBodySend
) => {
  const response = await authApi.post(DOCUMENT_MANAGEMENT_PATH, bodySend);
  return response.data;
};
export const updateDocumentManagement = async (props: {
  id: number;
  request: BasedDocumentManagementBodySend;
}) => {
  const response = await authApi.put(
    `${DOCUMENT_MANAGEMENT_PATH}/${props.id}`,
    props.request
  );
  return response.data;
};
export const deleteDocumentManagement = async (props: { id: number }) => {
  const response = await authApi.delete(
    `${DOCUMENT_MANAGEMENT_PATH}/${props.id}`
  );
  return response.data;
};
export const getDocumentMngStock = async (params: { name?: string }) => {
  const response = await authApi.get<ResponseWrapper<FoldersModel>>(
    `${DOCUMENT_MANAGEMENT_PATH}/folders`,
    {
      params: params,
    }
  );
  return response.data.result;
};

export const createDocumentMngStock = async (bodySend: CreateStockModel) => {
  const response = await authApi.post(
    `${DOCUMENT_MANAGEMENT_PATH}/folders`,
    bodySend
  );
  return response.status;
};
export const updateDocumentMngStock = async (updateProps: {
  request: CreateStockModel;
  id: number;
}) => {
  const response = await authApi.put(
    `${DOCUMENT_MANAGEMENT_PATH}/folders/${updateProps.id}`,
    updateProps.request
  );
  return response.status;
};

export const deleteDocumentMngStock = async (id: number) => {
  const response = await authApi.delete(
    `${DOCUMENT_MANAGEMENT_PATH}/folders/${id}`
  );
  return response.data;
};
export const getDocumentSubStock = async (folderId: number) => {
  const response = await authApi.get<ResponseWrapper<FoldersModel>>(
    `${DOCUMENT_MANAGEMENT_PATH}/folders/${folderId}/subfolder`
  );
  return response.data.result;
};
export const getDetailDocumentStock = async (folderId: number) => {
  const response = await authApi.get<
    ResponseWrapper<DepartmentStockModelDetail>
  >(`${DOCUMENT_MANAGEMENT_PATH}/folders/${folderId}`);
  return response.data.result;
};
export const updatePositionDocumentManagement = async (
  bodySend: DocumentMoveModel
) => {
  const response = await authApi.put(
    `${DOCUMENT_MANAGEMENT_PATH}/move`,
    bodySend
  );
  return response.data;
};

export const getDocumentManagementExcel = async (
  params: DocumentManagementParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${DOCUMENT_MANAGEMENT_PATH}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};
//tab
export const getDocumentManagementTabInformation = async (
  documentId: number
) => {
  const response = await authApi.get<DetailInformationRequestResponses>(
    `${DOCUMENT_MANAGEMENT_PATH}/${documentId}/information-request`
  );
  return response.data;
};

export const getDocumentManagementTabForward = async (documentId: number) => {
  const response = await authApi.get<GetForwardsResponseDocumentMng>(
    `${DOCUMENT_MANAGEMENT_PATH}/${documentId}/forward`
  );
  return response.data;
};

export const getDocumentManagementTabComment = async (documentId: number) => {
  const response = await authApi.get<ResponseWrapper<GetCommentsResponse>>(
    `${DOCUMENT_MANAGEMENT_PATH}/${documentId}/comment`
  );
  return response.data;
};
export const createDocumentManagementComment = async (
  documentId: number,
  content: string
) => {
  const response = await authApi.post(
    `${DOCUMENT_MANAGEMENT_PATH}/${documentId}/comment`,
    {
      content: content,
    }
  );
  return response.data;
};

export const getDocumentManagementHistory = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${DOCUMENT_MANAGEMENT_PATH}/${id}/history`
  );
  return response.data;
};

export const getDocumentManagementExtensions = async (id: number) => {
  const response = await authApi.get<GetAdviceExtensionResponse>(
    `/${DOCUMENT_MANAGEMENT_PATH}/${id}/time-extension`
  );
  return response.data;
};

export const getDocumentManagementAttachment = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetDocumentManagementTabAttachmentsResponse>
  >(`${DOCUMENT_MANAGEMENT_PATH}/${id}/attachment-tab`);
  return response.data.result;
};

export const shareDocumentMgmtFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number;
  };
}) => {
  const response = await authApi.post(
    `/${DOCUMENT_MANAGEMENT_PATH}/${params.id}/share`,
    params.data
  );

  return response.data;
};
export const getDocumentMngStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<DocumentMngStatisticChartResponse>
  >(`/${DOCUMENT_MANAGEMENT_PATH}/statistic/chart`);
  return response.data.result;
};

export const getStatisticDocumentMngTableFn = async (params: DocumentManagementParams) => {
  const response = await authApi.get<DocumentMngResponse>(`/${DOCUMENT_MANAGEMENT_PATH}/statistic/table`, {
    params: params,
  });
  return response.data;
};

export const getStatisticDocumentMngTableLateFn = async (params: DocumentManagementParams) => {
  const response = await authApi.get<DocumentMngResponse>(`/${DOCUMENT_MANAGEMENT_PATH}/statistic/table/late`, {
    params: params,
  });
  return response.data;
};

export const getStatisticDocumentMngTableForgetFn = async (params: DocumentManagementParams) => {
  const response = await authApi.get<DocumentMngResponse>(`/${DOCUMENT_MANAGEMENT_PATH}/statistic/table/forgot`, {
    params: params,
  });
  return response.data;
};