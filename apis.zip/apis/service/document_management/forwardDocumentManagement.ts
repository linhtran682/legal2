import { authApi } from "@/apis";
import {
  CreateForwardDocumentManagementBody,
  CreateForwardDocumentManagementOptions,
  ForwardDocumentManagementSchemaI,
} from "@/models/document_management/ForwardDocumentManagement";
import { useMutation } from "@tanstack/react-query";

const DOCUMENT_MANAGEMENT = "document-management";

export const createForwardDocumentManagementMutationFn = ({
  documentId,
  data,
}: CreateForwardDocumentManagementBody): Promise<ForwardDocumentManagementSchemaI> => {
  return authApi.post(`${DOCUMENT_MANAGEMENT}/${documentId}/forward`, data);
};

export const useCreateForwardDocumentManagement = ({
  config,
}: CreateForwardDocumentManagementOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createForwardDocumentManagementMutationFn,
  });
};
