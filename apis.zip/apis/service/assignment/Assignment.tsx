import { authApi, ResponseWrapper } from "@/apis";
import { AssignmentDTO, GetAssignedPersonResponse, GetAssignmentsParams, GetAssignmentsResponse, SaveAssignmentDTO } from "@/models/assignment/Assignment";

const ASSIGNMENT_PATH = "assignment";

export const getAssignments = async (params: GetAssignmentsParams) => {
  const response = await authApi.get<ResponseWrapper<GetAssignmentsResponse>>(
    ASSIGNMENT_PATH,
    { params: params, }
  );
  return response.data.result;
};

export const getAssignment = async (id: number) => {
  const response = await authApi.get<AssignmentDTO>(
    `${ASSIGNMENT_PATH}/${id}`
  );
  return response.data;
};

export const createAssignment = async (request: SaveAssignmentDTO) => {
  const response = await authApi.post(ASSIGNMENT_PATH, request);
  return response.status;
};
export const createAssignmentDraft = async (request: SaveAssignmentDTO) => {
  const response = await authApi.post(`${ASSIGNMENT_PATH}/draft`, request);
  return response.status;
};

export const updateAssignment = async (updateProps: {
  request: SaveAssignmentDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${ASSIGNMENT_PATH}/${updateProps.id}`,
    updateProps.request
  );
  return response.status;
};

export const deleteAssignment = async (id: number) => {
  const response = await authApi.delete<any>(`${ASSIGNMENT_PATH}/${id}`);
  return response.data;
};

export const getAssignedPerson = async () => {
  const response = await authApi.get<ResponseWrapper<GetAssignedPersonResponse>>(`${ASSIGNMENT_PATH}/legal`);
  return response.data.result;
}

