import { authApi, ExtractFnReturnType } from "@/apis";
import {
  CreateRequestApprovalBody,
  CreateRequestApprovalOptions,
  CreateReviewApprovalBody,
  CreateReviewApprovalOptions,
  GetRequestApprovalIdOptions,
  QueryFnType,
  RequestApprovalDTO,
  RequestApprovalParams,
  RequestApprovalRequestSchemaI,
  ReviewApprovalRequestSchemaI,
  UpdateRequestApprovalBody,
  UpdateRequestApprovalOptions,
} from "@/models/law_document/RequestApproval";
import { useMutation, useQuery } from "@tanstack/react-query";

const REQUEST_APPROVAL = "legal-document";
export const GET_REQUEST_APPROVAL = "useGetRequestApproval";

export const createRequestApprovalMutationFn = ({
  legalDocumentId,
  data,
}: CreateRequestApprovalBody): Promise<RequestApprovalRequestSchemaI> => {
  return authApi.post(
    `${REQUEST_APPROVAL}/${legalDocumentId}/evaluate/request-approval`,
    data
  );
};

export const useCreateRequestApproval = ({
  config,
}: CreateRequestApprovalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestApprovalMutationFn,
  });
};

export const getRequestApprovalQueryFn = async (
  request: RequestApprovalParams
): Promise<RequestApprovalDTO> => {
  const { legalDocumentId, requestApprovalId } = request;
  const response = await authApi.get(
    `${REQUEST_APPROVAL}/${legalDocumentId}/evaluate/request-approval/${requestApprovalId}`
  );
  return response.data.result;
};

export const useGetRequestApproval = ({
  config,
  request,
}: GetRequestApprovalIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_REQUEST_APPROVAL, request],
    queryFn: () => getRequestApprovalQueryFn(request),
  });
};

export const updateRequestApprovalMutationFn = async (
  request: UpdateRequestApprovalBody
): Promise<any> => {
  const { legalDocumentId, requestApprovalId, data } = request;
  const response = await authApi.put(
    `${REQUEST_APPROVAL}/${legalDocumentId}/evaluate/request-approval/${requestApprovalId}`,
    data
  );
  return response.status;
};

export const useUpdateRequestApproval = ({
  config,
}: UpdateRequestApprovalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateRequestApprovalMutationFn,
  });
};

export const updateMultipleRequestApprovalMutationFn = async (
  request: UpdateRequestApprovalBody
): Promise<any> => {
  const { legalDocumentId, data } = request;
  const response = await authApi.post(
    `${REQUEST_APPROVAL}/${legalDocumentId}/evaluate/request-approval/multi`,
    data
  );
  return response.status;
};

export const useUpdateMultipleRequestApproval = ({
  config,
}: UpdateRequestApprovalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateMultipleRequestApprovalMutationFn,
  });
};

export const createReviewApprovalMutationFn = ({
  legalDocumentId,
  requestApprovalId,
  data,
}: CreateReviewApprovalBody): Promise<ReviewApprovalRequestSchemaI> => {
  return authApi.post(
    `${REQUEST_APPROVAL}/${legalDocumentId}/evaluate/request-approval/${requestApprovalId}`,
    data
  );
};

export const useCreateReviewApproval = ({
  config,
}: CreateReviewApprovalOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createReviewApprovalMutationFn,
  });
};