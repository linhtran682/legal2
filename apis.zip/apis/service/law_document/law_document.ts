import { authApi, ResponseWrapper } from "@/apis";
import { LEGAL_DOCUMENT_ROOT_PATH } from "@/constants/paths";
import {
  GetBasedLegalDocumentsParams,
  GetBasedLegalDocumentsResponse,
} from "@/models/law_document/BasedLegalDocument";
import { DepartmentStatusListResponse } from "@/models/law_document/DepartmentStatus";
import { EvaluateLegalDocumentRequest } from "@/models/law_document/EvaluateLegalDocument";
import { FeedbackLegalDocumentRequest } from "@/models/law_document/FeedbackLegalDocument";
import { FinishLegalDocumentFormOutput } from "@/models/law_document/FinishLegalDocument";
import { ForwardLegalDocumentRequest } from "@/models/law_document/ForwardLegalDocument";
import {
  GetLawAssignmentResponse,
  LawDocumentBodyReceive,
  LawDocumentBodySend,
  LegalDocStatisticChartResponse,
} from "@/models/law_document/LawDocument";
import { GetLegalDocumentTabAttachmentsResponse } from "@/models/law_document/LegalDocumentAttachment";
import {
  ApproveNextActionFormOutput,
  AssessmentFeedbackFormOutput,
  FinishEvaluateFormOutput,
  FollowNextActionFormOutput,
  NextActionInput,
  NextActionInputReceive,
  NextActionOutput,
  RequestNextActionApprovalFormOutput,
} from "@/models/law_document/NextActionLegalDocument";
import { RequestReviewLegalDocumentRequest } from "@/models/law_document/RequestReviewLegalDocument";
import { SendLegalDocumentRequest } from "@/models/law_document/SendLegalDocument";
import {
  GetCommentsResponse,
  GetEvaluationsResponse,
  GetExtendsResponse,
  GetFeedbacksResponse,
  GetForwardsResponse,
  GetHistoryResponse,
  GetRequestApprovalResponse,
} from "@/models/metadata/Metadata";

const LAW_DOCUMENT = "legal-document";

export const getDocuments = async (params: GetBasedLegalDocumentsParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(LAW_DOCUMENT, {
    params: params,
  });
  return response.data.result;
};

export const getLawDocument = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.get<ResponseWrapper<LawDocumentBodyReceive>>(
    `${LAW_DOCUMENT}/${id}`
  );
  return response.data.result;
};

export const createLawDocument = async (request: LawDocumentBodySend) => {
  const requestFormat = {
    ...request,
  };
  const response = await authApi.post(LAW_DOCUMENT, requestFormat);

  return response.data;
};

export const updateLawDocument = async (updateProps: {
  request: LawDocumentBodySend;
  id: number;
}) => {
  const response = await authApi.put(
    `${LAW_DOCUMENT}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteLawDocuments = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${LAW_DOCUMENT}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};

export const getSendLegalDocument = async (id: number) => {
  const response = await authApi.get(`/${LAW_DOCUMENT}/${id}/send`);

  return response.data;
};

export const sendLegalDocument = async (params: {
  id: number;
  request: SendLegalDocumentRequest;
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/${params.id}/send`,
    params.request
  );

  return response.data;
};

export const getLegalDocumentFeedbacks = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetFeedbacksResponse>>(
    `/${LAW_DOCUMENT}/${id}/feedback`
  );

  return response.data;
};

export const feedbackLegalDocument = async (params: {
  id: number;
  request: FeedbackLegalDocumentRequest;
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/${params.id}/feedback`,
    params.request
  );

  return response.data;
};

export const getLegalDocumentForwards = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetForwardsResponse>>(
    `/${LAW_DOCUMENT}/${id}/forward`
  );

  return response.data;
};

export const forwardLegalDocument = async (params: {
  id: number;
  request: ForwardLegalDocumentRequest;
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/${params.id}/forward`,
    params.request
  );

  return response.data;
};

export const getLegalDocumentEvaluation = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetEvaluationsResponse>>(
    `/${LAW_DOCUMENT}/${id}/evaluate`
  );

  return response.data;
};

export const evaluateLegalDocument = async (params: {
  id: number;
  request: EvaluateLegalDocumentRequest;
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/${params.id}/evaluate/evaluate-remind`,
    params.request
  );
  return response.data;
};

export const requestReviewLegalDocument = async (params: {
  id: number;
  request: RequestReviewLegalDocumentRequest;
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/${params.id}/evaluate`,
    params.request
  );

  return response.data;
};

export const getAllHierarchyById = async (params: { id: number | string }) => {
  const response = await authApi.get(
    `/${LAW_DOCUMENT}/${params.id}/all-hierarchy`
  );
  return response.data?.result;
};
export const createDrafLawDocument = async (request: LawDocumentBodySend) => {
  const requestFormat = {
    ...request,
  };
  const response = await authApi.post(`${LAW_DOCUMENT}/draft`, requestFormat);

  return response.data;
};

export const commentLegalDocument = async (params: {
  id: number;
  content: string;
}) => {
  const response = await authApi.post(`/${LAW_DOCUMENT}/${params.id}/comment`, {
    content: params.content,
  });

  return response.data;
};

export const getLegalDocumentComments = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<GetCommentsResponse>>(
    `/${LAW_DOCUMENT}/${id}/comment`
  );

  return response.data;
};

export const getLegalDocumentTabAttachments = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<GetLegalDocumentTabAttachmentsResponse>
  >(`${LEGAL_DOCUMENT_ROOT_PATH}/${id}/attachment-tab`);

  return response.data.result;
};

export const getLegalDocumentNextAction = async (params: {
  documentId: number;
  userId: string;
}) => {
  const response = await authApi.get<ResponseWrapper<NextActionInput>>(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.documentId}/next-action`,
    {
      params: {
        user_id: params.userId,
      },
    }
  );

  return response.data.result;
};
export const getLegalDocumentNextActionBaseId = async (params: {
  documentId: number;
  id: number;
}) => {
  const response = await authApi.get<ResponseWrapper<NextActionInputReceive>>(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.documentId}/next-action/${params.id}`
  );

  return response.data.result;
};
export const createLegalDocumentNextAction = async (params: {
  documentId: number;
  nextAction: NextActionOutput;
}) => {
  const response = await authApi.post(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.documentId}/next-action`,
    params.nextAction
  );

  return response.status;
};

export const updateLegalDocumentNextAction = async (params: {
  documentId: number;
  id: number;
  nextAction: NextActionOutput;
  fileIds?: number[];
  receivers?: string[];
  status?: number;
  name?: string;
}) => {
  const response = await authApi.put(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.documentId}/next-action/${params.id}`,
    params.nextAction
    // {
    //   params: {
    //     user_id: params.userId,
    //   },
    // }
  );

  return response.status;
};

export const requestApprovalLegalDocumentNextAction = async (params: {
  legalDocumentId: number;
  nextActionId: number;
  request: RequestNextActionApprovalFormOutput;
}) => {
  const response = await authApi.post(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.legalDocumentId}/next-action/${params.nextActionId}/request-approval`,
    params.request
  );

  return response.status;
};

export const approveLegalDocumentNextAction = async (params: {
  documentId: number;
  requestApprovalId: number;
  request: ApproveNextActionFormOutput;
}) => {
  const response = await authApi.put(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.documentId}/next-action/request-approval/${params.requestApprovalId}`,
    params.request
  );

  return response.status;
};
export const approveMultipleLegalDocumentNextAction = async (params: {
  documentId: number;
  request: ApproveNextActionFormOutput;
}) => {
  const response = await authApi.put(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.documentId}/next-action/request-approval`,
    params.request
  );

  return response.status;
};

export const getLegalDocumentExtend = async (legalDocumentId: number) => {
  const response = await authApi.get<ResponseWrapper<GetExtendsResponse>>(
    `/${LAW_DOCUMENT}/${legalDocumentId}/extend-deadline`
  );

  return response.data;
};

export const getLegalDocumentRequestApproval = async (
  legalDocumentId: number
) => {
  const response = await authApi.get<
    ResponseWrapper<GetRequestApprovalResponse>
  >(`/${LAW_DOCUMENT}/${legalDocumentId}/evaluate/request-approval`);
  return response.data;
};

export const recallLegalDocument = async (id: number) => {
  const response = await authApi.post(`/${LAW_DOCUMENT}/${id}/recall`);
  return response.data;
};
export const requestEvaluateMultiple = async (params: {
  request: RequestReviewLegalDocumentRequest;
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/evaluates`,
    params.request
  );
  return response.data;
};
export const forwardMultiple = async (params: {
  request: ForwardLegalDocumentRequest;
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/forward`,
    params.request
  );
  return response.data;
};

export const getDepartmentStatus = async (id: number) => {
  const response = await authApi.get<
    ResponseWrapper<DepartmentStatusListResponse>
  >(`/${LAW_DOCUMENT}/${id}/department`);
  return response.data?.result;
};

export const getRoleLegalDocumentNextActionBaseId = async (params: {
  documentId: number;
}) => {
  const response = await authApi.get(
    `${LEGAL_DOCUMENT_ROOT_PATH}/${params.documentId}/owner-roles`
  );

  return response.data.result;
};

export const getLegalDocumentExcel = async (
  params: GetBasedLegalDocumentsParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${LAW_DOCUMENT}/excel`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getLegalDocumentHistory = async (legalDocumentId: number) => {
  const response = await authApi.get<ResponseWrapper<GetHistoryResponse>>(
    `/${LAW_DOCUMENT}/${legalDocumentId}/history`
  );

  return response.data;
};

export const requestFollowNextAction = async (params: {
  legalDocumentId: number;
  nextActionId: number;
  request: FollowNextActionFormOutput;
}) => {
  const response = await authApi.post(
    `${LAW_DOCUMENT}/${params.legalDocumentId}/next-action/${params.nextActionId}/follow`,
    params.request
  );

  return response.status;
};

export const requestFinishEvaluate = async (params: {
  legalDocumentId?: number;
  request: FinishEvaluateFormOutput;
}) => {
  const response = await authApi.post(
    `${LAW_DOCUMENT}/${params.legalDocumentId}/evaluate/finish`,
    params.request
  );

  return response.status;
};

export const requestAssessmentFeedback = async (params: {
  legalDocumentId?: number;
  request: AssessmentFeedbackFormOutput;
}) => {
  const response = await authApi.post(
    `${LAW_DOCUMENT}/${params.legalDocumentId}/feedback/evaluate`,
    params.request
  );

  return response.status;
};

export const requestFinishLegalDocument = async (params: {
  legalDocumentId?: number;
  request: FinishLegalDocumentFormOutput;
}) => {
  const response = await authApi.post(
    `${LAW_DOCUMENT}/${params.legalDocumentId}/finish`,
    params.request
  );

  return response.status;
};

export const updateBookMeeting = async (params: {
  legalDocumentId?: number;
  request: {
    bookMeeting: boolean;
  };
}) => {
  const response = await authApi.put(
    `${LAW_DOCUMENT}/${params.legalDocumentId}/book-meeting`,
    params.request
  );

  return response.status;
};

export const cloneLegalDocumentFn = async (params: {
  id: number;
  data: {
    childStatus: number;
    status: number;
  };
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/${params.id}/clone`,
    params.data
  );

  return response.data;
};

export const shareLegalDocumentFn = async (params: {
  id: number;
  data: {
    userIds: string[];
    departmentIds: string[];
    legalAccessType: number;
  };
}) => {
  const response = await authApi.post(
    `/${LAW_DOCUMENT}/${params.id}/share`,
    params.data
  );

  return response.data;
};
export const getLegalDocumentAssignments = async (id: number) => {
  const response = await authApi.get<GetLawAssignmentResponse>(
    `/${LAW_DOCUMENT}/${id}/assignment`
  );
  return response.data;
};
export const getLegalDocumentStatisticChartFn = async () => {
  const response = await authApi.get<
    ResponseWrapper<LegalDocStatisticChartResponse>
  >(`/${LAW_DOCUMENT}/statistic/chart`);
  return response.data.result;
};
export const getLegalDocumentStatisticTableFn = async (params: GetBasedLegalDocumentsParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(`/${LAW_DOCUMENT}/statistic/table`, {
    params: params,
  });
  return response.data.result;
};

export const getLegalDocumentStatisticExport = async (
  params: GetBasedLegalDocumentsParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${LAW_DOCUMENT}/statistic/table/export`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getLegalDocumentStatisticSlowEvaluateFn = async (params: GetBasedLegalDocumentsParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(`/${LAW_DOCUMENT}/statistic/table/slow-evaluate`, {
    params: params,
  });
  return response.data.result;
};

export const getLegalDocumentStatisticSlowEvaluateExport = async (
  params: GetBasedLegalDocumentsParams
) => {
  const response = await authApi.get<ResponseWrapper<any>>(
    `${LAW_DOCUMENT}/statistic/table/slow-evaluate/export`,
    {
      params: params,
      responseType: "blob",
    }
  );
  return response;
};

export const getLegalDocumentStatisticNotEvaluateFn = async (params: GetBasedLegalDocumentsParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(`/${LAW_DOCUMENT}/statistic/table/not-evaluate`, {
    params: params,
  });
  return response.data.result;
};

export const getLegalDocumentStatisticFollowingFn = async (params: GetBasedLegalDocumentsParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(`/${LAW_DOCUMENT}/statistic/table/following`, {
    params: params,
  });
  return response.data.result;
};

export const getLegalDocumentStatisticEffectiveFn = async (params: GetBasedLegalDocumentsParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(`/${LAW_DOCUMENT}/statistic/table/effective`, {
    params: params,
  });
  return response.data.result;
};

export const getLegalDocumentStatisticDoneFn = async (params: GetBasedLegalDocumentsParams) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(`/${LAW_DOCUMENT}/statistic/table/done`, {
    params: params,
  });
  return response.data.result;
};