import { authApi, ExtractFnReturnType } from "@/apis";
import {
  CreateTimeExtensionBody,
  CreateTimeExtensionOptions,
  GetTimeExtensionIdOptions,
  QueryFnType,
  RequestApprovalDTO,
  TimeExtensionParams,
  UpdateTimeExtensionAcceptOptions,
  UpdateTimeExtensionBody,
} from "@/models/law_document/TimeExtension";
import { useMutation, useQuery } from "@tanstack/react-query";

const REQUEST_APPROVAL = "legal-document";
export const GET_REQUEST_APPROVAL = "useGetTimeExtension";

export const createTimeExtensionMutationFn = ({
  legalDocumentId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(
    `${REQUEST_APPROVAL}/${legalDocumentId}/extend-deadline`,
    data
  );
};

export const useCreateTimeExtension = ({
  config,
}: CreateTimeExtensionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionMutationFn,
  });
};

export const createTimeExtensionNextActionMutationFn = ({
  legalDocumentId,
  nextActionId,
  data,
}: CreateTimeExtensionBody): Promise<any> => {
  return authApi.post(
    `${REQUEST_APPROVAL}/${legalDocumentId}/next-action/${nextActionId}/time-extension`,
    data
  );
};

export const useCreateTimeExtensionNextAction = ({
  config,
}: CreateTimeExtensionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createTimeExtensionNextActionMutationFn,
  });
};

export const getTimeExtensionQueryFn = async (
  request: TimeExtensionParams
): Promise<RequestApprovalDTO> => {
  const { legalDocumentId, extendDeadlineId } = request;
  const response = await authApi.get(
    `${REQUEST_APPROVAL}/${legalDocumentId}/extend-deadline/${extendDeadlineId}`
  );
  return response.data.result;
};

export const useGetTimeExtension = ({
  config,
  request,
}: GetTimeExtensionIdOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [GET_REQUEST_APPROVAL, request],
    queryFn: () => getTimeExtensionQueryFn(request),
  });
};

export const updateTimeExtensionMutationFn = async (
  request: UpdateTimeExtensionBody
): Promise<any> => {
  const { legalDocumentId, extendDeadlineId, data } = request;
  const response = await authApi.put(
    `${REQUEST_APPROVAL}/${legalDocumentId}/extend-deadline/${extendDeadlineId}`,
    data
  );
  return response.status;
};

export const useUpdateTimeExtension = ({
  config,
}: UpdateTimeExtensionAcceptOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: updateTimeExtensionMutationFn,
  });
};
