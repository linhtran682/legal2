import { authApi } from "@/apis";
import {
  CreateFeedBackLcBody,
  CreateFeedBackLcOptions,
  RequestFeedBackLcSchemaI,
} from "@/models/law_document/FeedBackLc";
import { useMutation } from "@tanstack/react-query";

const FEEDBACK_LC = "legal-document";
export const createFeedBackLcMutationFn = ({
  legalDocumentId,
  data,
}: CreateFeedBackLcBody): Promise<RequestFeedBackLcSchemaI> => {
  return authApi.post(
    `${FEEDBACK_LC}/${legalDocumentId}/feedback/feedback-lc`,
    data
  );
};

export const useCreateFeedBackLc = ({
  config,
}: CreateFeedBackLcOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createFeedBackLcMutationFn,
  });
};
