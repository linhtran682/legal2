import { authApi } from "@/apis";
import {
  CreateRequestVendorBody,
  CreateRequestVendorOptions,
  RequestVendorSchemaI,
} from "@/models/law_document/RequestVendor";
import { useMutation } from "@tanstack/react-query";
const REQUEST_VENDOR = "legal-document";
export const createRequestVendorMutationFn = ({
  legalDocumentId,
  data,
}: CreateRequestVendorBody): Promise<RequestVendorSchemaI> => {
  return authApi.post(
    `${REQUEST_VENDOR}/${legalDocumentId}/request-vendor`,
    data
  );
};
export const useCreateRequestVendor = ({
  config,
}: CreateRequestVendorOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createRequestVendorMutationFn,
  });
};
