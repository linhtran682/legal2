import { authApi, ExtractFnReturnType } from "@/apis";
import {
  ApprovalNextActionParams,
  ApprovalNextActionSchemaI,
  CreateApprovalNextActionBody,
  CreateApprovalNextActionOptions,
  GetListApprovalNextActionOptions,
  QueryFnTypeApprovalNextAction,
  RequestApprovalResponses,
} from "@/models/law_document/ApprovalNextAction";
import { useMutation, useQuery } from "@tanstack/react-query";

const REQUEST_APPROVAL = "legal-document";
export const GET_LIST_APPROVAL_ACTION = "useGetListApproval";
export const createApprovalNextActionMutationFn = ({
  legalDocumentId,
  nextActionId,
  data,
}: CreateApprovalNextActionBody): Promise<ApprovalNextActionSchemaI> => {
  return authApi.post(
    `${REQUEST_APPROVAL}/${legalDocumentId}/next-action/${nextActionId}/approval`,
    data
  );
};

export const useCreateApprovalNextAction = ({
  config,
}: CreateApprovalNextActionOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createApprovalNextActionMutationFn,
  });
};

export const getListApprovalNextActionQueryFn = async (
  request: ApprovalNextActionParams
): Promise<RequestApprovalResponses[]> => {
  const { legalDocumentId, nextActionId } = request;
  const response = await authApi.get(
    `${REQUEST_APPROVAL}/${legalDocumentId}/next-action/${nextActionId}/request-approval`
  );
  return response.data.result?.nextActionRequestApprovalResponses;
};

export const useGetListApprovalNextAction = ({
  config,
  request,
}: GetListApprovalNextActionOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnTypeApprovalNextAction>>({
    ...config,
    queryKey: [GET_LIST_APPROVAL_ACTION, request],
    queryFn: () => getListApprovalNextActionQueryFn(request),
  });
};
