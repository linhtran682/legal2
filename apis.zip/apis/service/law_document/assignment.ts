import { authApi } from "@/apis";
import { AssignmentSchemaI, CreateAssignmentBody, CreateAssignmentOptions } from "@/models/law_document/Assignment";
import { useMutation } from "@tanstack/react-query";

const ASSIGNMENT = "legal-document";
export const createAssignmentMutationFn = ({
  legalDocumentId,
  data,
}: CreateAssignmentBody): Promise<AssignmentSchemaI> => {
  return authApi.post(`${ASSIGNMENT}/${legalDocumentId}/assignment`, data);
};
export const useCreateAssignment = ({
  config,
}: CreateAssignmentOptions = {}) => {
  return useMutation({
    ...config,
    mutationFn: createAssignmentMutationFn,
  });
};
