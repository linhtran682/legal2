import { useQuery } from "@tanstack/react-query";
import authApi, { ExtractFnReturnType } from "@/apis";
import { EMAIL_TEMPLATE_ROOT_PATH } from "@/constants/paths";
import {
  EmailTemplateQueryFnTypeList,
  GetEmailTemplateOptions,
  ResponsesEmailTemplateDTO,
} from "@/models/email_template/EmailTemplate";

export const USE_GET_EMAIL_TEMPLATE_LIST = "useGetEmailTemplate";

// Get email template
export const getEmailTemplateMutationFn = async (request: {
  module?: number;
  id?: number;
}): Promise<ResponsesEmailTemplateDTO> => {
  const { module, id } = request;
  const response = await authApi.get(
    `${EMAIL_TEMPLATE_ROOT_PATH}/detail?module=${module}&id=${id}`
  );
  return response?.data?.result;
};

export const useGetEmailTemplate = ({
  config,
  request,
}: GetEmailTemplateOptions) => {
  return useQuery<ExtractFnReturnType<EmailTemplateQueryFnTypeList>>({
    ...config,
    queryKey: [USE_GET_EMAIL_TEMPLATE_LIST, request],
    queryFn: () => getEmailTemplateMutationFn(request),
  });
};
