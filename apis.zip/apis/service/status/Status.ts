import { authApi, ResponseWrapper } from "@/apis";
import {
  GetStatusListNamesParams,
  GetStatusListParams,
  GetStatusListResponse,
  SaveStatusDTO,
  StatusDTO,
} from "@/models/status/Status";

const Status_PATH = "status";

export const getStatusList = async (params: GetStatusListParams) => {
  const response = await authApi.get<ResponseWrapper<GetStatusListResponse>>(
    Status_PATH,
    {
      params: {
        ...params,
        modules: params.modules ? params.modules.join(",") : undefined,
      },
    }
  );
  return response.data.result;
};

export const getStatusListNames = async (params: GetStatusListNamesParams) => {
  const response = await authApi.get<ResponseWrapper<GetStatusListResponse>>(
    `${Status_PATH}/names`,
    {
      params: {
        names: params.names ? params.names.join(",") : undefined,
        modules: params.modules ? params.modules.join(",") : undefined,
      },
    }
  );
  return response.data.result;
};

export const getStatus = async (id: number) => {
  const response = await authApi.get<ResponseWrapper<StatusDTO>>(
    `${Status_PATH}/${id}`
  );
  return response.data.result;
};

export const createStatus = async (request: SaveStatusDTO) => {
  const response = await authApi.post(Status_PATH, request);

  return response.status;
};

export const updateStatus = async (updateProps: {
  request: SaveStatusDTO;
  id: number;
}) => {
  const response = await authApi.put(
    `${Status_PATH}/${updateProps.id}`,
    updateProps.request
  );

  return response.status;
};

export const deleteStatusList = async (ids: number[]) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${Status_PATH}`, {
    params: { ids: ids.join(",") },
  });
  return response.data;
};
