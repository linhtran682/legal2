import { authApi } from ".";

type loginProps = {
  email: string;
  password: string;
};
export type loginWith365 = {
  client_id?: string;
  code?: string;
  redirect_uri?: string;
  grant_type?: string;
  code_verifier?: string;
  scope?: string; 
};
export const loginUserFn = async (user: loginProps) => {
  const response = await authApi.post("/api/auth/login", user);
  return response.data;
};

export const handleLoginWith365 = async () => {
  const response = await authApi.get("microsoft-authentication/pkce");
  return response.data;
};

export const handleGetTokenWith365 = async (body: FormData) => {
  const response = await authApi.post("https://login.microsoftonline.com/d43d5d87-666b-46b6-94f4-5130ffee20bf/oauth2/v2.0/token", body);
  return response.data;
};
