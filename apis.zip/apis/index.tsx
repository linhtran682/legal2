import { loginRequest, msalInstance } from "@/authAccess/auth-config";
import { clearMsalAccount } from "@/authAccess/hooks/auth-provider";
import { CODE_LIST } from "@/constants/constraint";
import { useError } from "@/context/ErrorContext";
import { ClearTokenCookies, cookieSetting } from "@/utils";
import { InteractionRequiredAuthError } from "@azure/msal-browser";
import { UseMutationOptions, UseQueryOptions } from "@tanstack/react-query";
import axios, {
  AxiosError,
  AxiosResponse,
  InternalAxiosRequestConfig,
} from "axios";
import Router from "next/router";
import { ReactNode, useEffect, useState } from "react";

export const authApi = axios.create({
  baseURL: process.env.SERVER_URL,
  headers: {
    "Accept-Language": "vn",
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "DELETE, POST, GET, OPTIONS",
    "Access-Control-Allow-Headers":
      "Content-Type, Authorization, X-Requested-With",
  },
});

interface AxiosInterceptorProps {
  children: ReactNode;
}

const AxiosInterceptor = ({ children }: AxiosInterceptorProps) => {
  const { showError } = useError();
  const [isRender, setIsRender] = useState(false);
  useEffect(() => {
    const resInterceptor = (response: AxiosResponse) => {
      return response;
    };
    const errResInterceptor = async (error: any) => {
      const originalRequest = error.config;

      if (
        error.response &&
        error.response.status === 401 &&
        !originalRequest._retry
      ) {
        originalRequest._retry = true;

        try {
          const accounts = msalInstance.getAllAccounts();
          if (accounts.length > 0) {
            const request = {
              ...loginRequest,
              account: accounts[0],
            };
            try {
              const response = await msalInstance.acquireTokenSilent(request);
              cookieSetting.set("token", response.idToken);
              cookieSetting.set("ACCESS_TOKEN", response.accessToken);

              originalRequest.headers.Authorization = `Bearer ${response.accessToken}`;
              return authApi(originalRequest);
            } catch (silentError) {
              if (silentError instanceof InteractionRequiredAuthError) {
                try {
                  const popupResponse = await msalInstance.acquireTokenPopup(
                    request
                  );
                  cookieSetting.set("token", popupResponse.idToken);
                  cookieSetting.set("ACCESS_TOKEN", popupResponse.accessToken);
                  originalRequest.headers.Authorization = `Bearer ${popupResponse.accessToken}`;
                  return authApi(originalRequest);
                } catch (popupError) {
                  ClearTokenCookies();
                  Router.push("/auth/login");
                  return Promise.reject(popupError);
                }
              }
            }
          } else {
            ClearTokenCookies();
            Router.push("/auth/login");
          }
        } catch (tokenError) {
          ClearTokenCookies();
          Router.push("/auth/login");
          return Promise.reject(error);
        }
      }
      if (error.response && error.response.status === 403) {
        if (
          error.response?.data?.error?.code === CODE_LIST.ERROR_CODES_4030000
        ) {
          showError(error.response?.data?.error?.message);
          return Promise.reject(error);
        }
        // if(cookieSetting.get('TYPE') === 'MS365'){
        clearMsalAccount(error);
        // }
        ClearTokenCookies();
        Router.push("/auth/login");
        return Promise.reject(error);
      }

      if (
        error.response &&
        error.response.status === 404 &&
        error.response?.data?.error?.code === CODE_LIST.ERROR_CODES_4030004
      ) {
        showError(error.response?.data?.error?.message);
        return Promise.reject(error);
      }

      // Xử lý các lỗi khác
      return Promise.reject(error);
    };
    // Interceptor để thêm token vào headers trước khi gửi request
    const reqInterceptor = (config: InternalAxiosRequestConfig) => {
      const token = cookieSetting.get("token");
      const accessToken = cookieSetting.get("ACCESS_TOKEN");
      const bearerToken = `Bearer ${token}`;
      config.headers.Authorization = token ? bearerToken : "";
      if (accessToken) {
        config.headers["access-token"] = accessToken;
      }
      return config;
    };
    const reqErrInterceptor = (error: AxiosError) => Promise.reject(error);
    const interceptorRes = authApi.interceptors.response.use(
      resInterceptor,
      errResInterceptor
    );
    const interceptorReq = authApi.interceptors.request.use(
      reqInterceptor,
      reqErrInterceptor
    );
    setIsRender(true);
    return () => {
      authApi.interceptors.response.eject(interceptorRes);
      authApi.interceptors.request.eject(interceptorReq);
    };
  }, []);
  return <>{isRender && children}</>;
};

export default authApi;
export { AxiosInterceptor };
export interface ApiError {
  code: number;
  message: string;
}

export interface ResponseWrapper<T> {
  error?: ApiError;
  result?: T;
  success?: boolean;
}

export type ExtractFnReturnType<FnType extends (...args: any) => any> = Awaited<
  ReturnType<FnType>
>;

export type MutationConfig<MutationFnType extends (...args: any) => any> =
  UseMutationOptions<
    ExtractFnReturnType<MutationFnType>,
    AxiosError,
    Parameters<MutationFnType>[0]
  >;

export type QueryConfig<QueryFnType extends (...args: any) => any> = Omit<
  UseQueryOptions<ExtractFnReturnType<QueryFnType>>,
  "queryKey" | "queryFn"
>;
