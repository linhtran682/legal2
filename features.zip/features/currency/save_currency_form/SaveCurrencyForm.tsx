import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormCheckbox } from "@/components/commons/form_inputs/FormCheckbox";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import {
  SaveCurrencyDTO,
  SaveCurrencyRequestFieldNames,
  SaveCurrencyRequestSchema,
  SaveCurrencyRequestSchemaI,
} from "@/models/currency/Currency";
import { BasicSaveForm } from "@/models/ui/form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveCurrencyFormProps
  extends BasicSaveForm<SaveCurrencyDTO, SaveCurrencyDTO> {}

const initialEmptyValue: SaveCurrencyDTO = {
  name: "",
  active: 0,
  unit: "",
};

export const SaveCurrencyForm = (props: SaveCurrencyFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<SaveCurrencyRequestSchemaI>({
    resolver: yupResolver(SaveCurrencyRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue && form.reset(props.initialValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <Grid container direction={"column"} spacing={GLOBAL_SPACING}>
              <Grid item>
                <FormTextField
                  control={form.control}
                  name={SaveCurrencyRequestFieldNames.NAME}
                  label={t(
                    `currency.field_name.${SaveCurrencyRequestFieldNames.NAME}`
                  )}
                  placeHolder={t(
                    `currency.field_name.${SaveCurrencyRequestFieldNames.NAME}`
                  )}
                  required
                />
              </Grid>
              <Grid item>
                <FormTextField
                  control={form.control}
                  name={SaveCurrencyRequestFieldNames.UNIT}
                  label={t(
                    `currency.field_name.${SaveCurrencyRequestFieldNames.UNIT}`
                  )}
                  placeHolder={t(
                    `currency.field_name.${SaveCurrencyRequestFieldNames.UNIT}`
                  )}
                  required
                />
              </Grid>

              <Grid item>
                <FormCheckbox
                  control={form.control}
                  name={SaveCurrencyRequestFieldNames.ACTIVE}
                  label={t(
                    `currency.field_name.${SaveCurrencyRequestFieldNames.ACTIVE}`
                  )}
                  inputTransform={(value: number) => value != 0}
                  outputTransform={(bool) => (bool ? 1 : 0)}
                />
              </Grid>
            </Grid>
          </Grid>
        </Grid>

        <FormActionButtons
          formMode={props.formMode}
          loading={props.loading}
          onCancel={props.onCancel}
          cancelConfirm={form.formState.isDirty}
          onDelete={props.onDelete}
          onSave={props.onSubmit}
        />
      </FormProvider>
    </Grid>
  );
};
