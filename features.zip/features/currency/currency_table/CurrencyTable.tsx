import MultipleFilterTable, {
  MultipleFilterTableColumn,
} from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { GridFilterItem } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";

import { Checkbox } from "@mui/material";
import {
  CurrencyFieldNames,
  GetCurrenciesParams,
} from "@/models/currency/Currency";
import {
  deleteCurrencies,
  getCurrencies,
} from "@/apis/service/currency/Currency";
import { CurrencyTableAtions } from "./currency_table_actions/CurrencyTableActions";
import { CURRENCY_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { TableGroupedActionButtons } from "@/components/commons/action_button/TableGroupedActionButtons";

export const CurrencyTableConst = {
  TABLE_NAME: "CurrencyTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getCurrencyList",
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetCurrenciesParams => {
  const params: GetCurrenciesParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: CurrencyFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == CurrencyFieldNames.NAME) {
      params.name = item.value;
    }
    if (item.field == CurrencyFieldNames.ACTIVE) {
      params.active = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() || "";
  }

  return params;
};

export const CurrencyTable = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [currencyTableColumns] = useState<MultipleFilterTableColumn[]>(() => [
    {
      key: CurrencyFieldNames.ID,
      label: CurrencyFieldNames.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: true,
    },
    {
      key: CurrencyFieldNames.NAME,
      label: CurrencyFieldNames.NAME,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: false,
      flex: 1,
    },
    {
      key: CurrencyFieldNames.UNIT,
      label: CurrencyFieldNames.UNIT,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: false,
      flex: 1,
    },
    {
      key: CurrencyFieldNames.ACTIVE,
      label: CurrencyFieldNames.ACTIVE,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: true,
      renderCell: (params) => <Checkbox checked={params.value == 1} />,
    },
    {
      key: CurrencyFieldNames.CREATED_BY,
      label: CurrencyFieldNames.CREATED_BY,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: true,
      flex: 1,
    },
    {
      key: CurrencyFieldNames.CREATED_AT,
      label: CurrencyFieldNames.CREATED_AT,
      type: "date",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: true,
      flex: 1,
    },
    {
      key: "action",
      label: "",
      type: undefined,
      renderCell: CurrencyTableAtions,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "stickyRight",
    },
  ]);

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getCurrencyListQuery = useQuery({
    queryKey: [CurrencyTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getCurrencies(castTableStateToParams(tableState)),
  });

  const deleteCurrenciesQuery = useMutation({
    mutationFn: deleteCurrencies,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.currency"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [CurrencyTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  // Watch table state then refetch new data for the table
  useEffect(() => {
    tableState &&
      getCurrencyListQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  return (
    <MultipleFilterTable
      data={getCurrencyListQuery.data?.currencyResponses || []}
      columns={currencyTableColumns
        // .filter((column) => appContext.meCanWrite || column.key != "action")
        .map((column) => ({
          ...column,
          label: column.label && `currency.column.${column.label}`,
        }))}
      getRowId={(item) => item.id.toString()}
      loading={getCurrencyListQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getCurrencyListQuery.data?.total}
      onRowClick={(params) => {
        router.push(`/${CURRENCY_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`);
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: CurrencyFieldNames.NAME,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(`currency.column.${fieldKey}`).toLocaleLowerCase(),
          }),
      }}
      groupedActions={(model) => (
        <TableGroupedActionButtons
          selectModel={model}
          onDelete={deleteCurrenciesQuery.mutate}
        />
      )}
    />
  );
};
