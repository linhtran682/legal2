import { LANGUAGES } from "@/locales/config-translation";
import { SimpleTreeView, TreeItem, treeItemClasses } from "@mui/x-tree-view";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useVirtualizer } from "@tanstack/react-virtual";
import { QuickFilter } from "@/components/commons/tables/multiple_filter_table/multiple_filter_table_bar/quick_filter/QuickFilter";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { getDepartments } from "@/apis/service/department/department";
import { Department } from "@/models/department/Department";
import { styled } from "@mui/material";
import { removeVietnameseTones } from "@/utils";

export interface DepartmentPickerProps {
  onSelect?: (department: Department) => void;
}

// const findNodeWithAncestors = (
//   root: Department,
//   searchTerm: string,
//   path: Department[] = [],
//   compare: keyof Department = "name"
// ): Department[] | null => {
//   if (!root || !root?.children) {
//     return null;
//   }
//   const value = root[compare];

//   if (
//     typeof value === "string" &&
//     value?.toLowerCase()?.startsWith(searchTerm?.toLowerCase())
//   ) {
//     return [...path, root];
//   }

//   for (let i = 0; i < root.children.length; i++) {
//     const result = findNodeWithAncestors(
//       root.children[i],
//       searchTerm,
//       [...path, root],
//       compare
//     );
//     if (result !== null) {
//       return result;
//     }
//   }

//   return null;
// };

const findDepartmentByName = (
  department: Department,
  searchString: string
): Department | null => {
  // Remove tones, trim and lowercase comparison
  if (removeVietnameseTones(department?.name?.trim()?.toLowerCase())
    ?.includes(removeVietnameseTones(searchString?.trim())?.toLowerCase())) {
    return department;
  }

  // Search in the children using depth-first search (DFS)
  if (department?.children) {
    for (const child of department?.children) {
      const found = findDepartmentByName(child, searchString);
      if (found) {
        return found;
      }
    }
  }

  return null;
};


const extractIds = (arr: Department[]) => {
  let ids: string[] = [];
  arr.forEach(item => {
    ids.push(item.id);
    if (item.children) {
      ids = ids.concat(extractIds(item.children));
    }
  });
  return ids;
}
const StyledTreeItem = styled(TreeItem)(() => ({
  [`& .${treeItemClasses.label}`]: {
    fontSize: '13px !important',
    fontWeight: '700 !important'
  }
}));

export const DepartmentPicker = (props: DepartmentPickerProps) => {
  const { i18n, t } = useTranslation();
  const [searchKey, setSearchKey] = useState("");
  const [selectedItem, setSelectedItem] = useState("");
  const parentRef = useRef<HTMLDivElement>(null);
  const [expanded, setExpanded] = useState<string[]>([]);

  const getDepartmentsQuery = useQuery({
    queryKey: ["department.getDepartment"],
    queryFn: async () =>
      getDepartments({ searchTerm: searchKey }).then(
        (response) => response?.departments ?? []
      ),

    enabled: false,
  });

  const virtualizer = useVirtualizer({
    count: (getDepartmentsQuery.data || []).length,
    getScrollElement: () => parentRef.current,
    estimateSize: () =>
      Math.round((parentRef.current?.clientHeight ?? 240 - 56) / 32),
    overscan: 10,
  });

  useEffect(() => {
    getDepartmentsQuery.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchKey]);

  // useEffect(() => {
  //   if (getDepartmentsQuery.data && props?.onSelect) {
  //     const allDepartmentIds = extractIds(getDepartmentsQuery.data);
  //     allDepartmentIds?.length && setExpanded(allDepartmentIds);
  //     !selectedItem && setSelectedItem(getDepartmentsQuery.data![0].id);
  //     props?.onSelect(getDepartmentsQuery.data![0]);
  //   }
  // }, [getDepartmentsQuery?.data]);

  const items = virtualizer.getVirtualItems();

  const renderTreeItem = (department: Department) => {
    const name =
      i18n.language == LANGUAGES.VIETNAMESE
        ? department.name
        : department.nameEnglish;

    (department.children || []).forEach((child) => {
      child.parentDepartmentNames = department.parentDepartmentNames
        ? [department.parentDepartmentNames, department.name].join(" > ")
        : department.name;

      child.parentDepartmentNameEnglish = department.parentDepartmentNameEnglish
        ? [department.parentDepartmentNameEnglish, department.nameEnglish].join(
          " > "
        )
        : department.nameEnglish;
    });

    return (
      <StyledTreeItem
        key={department.id}
        itemId={department.id}
        label={name}
        onClick={() => props.onSelect && props.onSelect(department)}
      >
        {department.children &&
          department.children.length > 0 &&
          department.children.map((child) => renderTreeItem(child))}
      </StyledTreeItem>
    );
  };

  useEffect(() => {
    if (!searchKey && !getDepartmentsQuery.data) return;

    const allDepartmentIds = extractIds(getDepartmentsQuery.data ?? []);
    allDepartmentIds?.length && setExpanded(allDepartmentIds);

    if (!searchKey) {
      setSelectedItem(getDepartmentsQuery.data![0]?.id);
      props?.onSelect?.(getDepartmentsQuery.data![0]);
      return;
    }
    // let initialExpanded: Department[] | null = [];
    // getDepartmentsQuery.data?.forEach((getDepartmentsQueryData: Department) => {
    //   const name =
    //     i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish";
    //   initialExpanded = findNodeWithAncestors(
    //     getDepartmentsQueryData,
    //     searchKey,
    //     [],
    //     name
    //   );
    // });
    let found: Department | null = null;
    for (const department of (getDepartmentsQuery.data ?? [])) {
      found = findDepartmentByName(department, searchKey);
      if (found) {
        break;
      }
    }
    setSelectedItem(found?.id ?? getDepartmentsQuery.data![0]?.id);
    (props?.onSelect)
      && props?.onSelect(found ?? getDepartmentsQuery.data![0]);
  }, [getDepartmentsQuery?.data, searchKey]);

  const handleToggle = (event: any, nodeIds: string) => {
    const initialExpanded: string[] | null = [...expanded];

    const expandedToggle = initialExpanded?.includes(nodeIds)
      ? initialExpanded?.filter((id) => id !== nodeIds)
      : [...initialExpanded, nodeIds]
    // getDepartmentsQuery.data?.forEach((getDepartmentsQueryData: Department) => {
    //   const departmentFindId = findNodeWithAncestors(
    //     getDepartmentsQueryData,
    //     nodeIds,
    //     [],
    //     "id"
    //   );
    //   if (departmentFindId) initialExpanded = departmentFindId;
    // });
    // if (!initialExpanded) return;
    // let expandedToggle = [...expanded];
    // const indexExpanded = expandedToggle?.findIndex(
    //   (expandedId) => expandedId === nodeIds
    // );

    // if (indexExpanded !== -1) {
    //   if (
    //     (initialExpanded?.[initialExpanded?.length - 2]?.children?.length ||
    //       0) > 1
    //   ) {
    //     expandedToggle.forEach((expand) => {
    //       const findExpanded = findNodeWithAncestors(
    //         initialExpanded?.[initialExpanded?.length - 1] as Department,
    //         expand,
    //         [],
    //         "id"
    //       );
    //       if (findExpanded) expandedToggle?.splice(indexExpanded, 1);
    //     });
    //   } else {
    //     expandedToggle = expandedToggle.slice(0, indexExpanded);
    //   }
    // } else {
    //   expandedToggle.push(nodeIds);
    // }
    setExpanded(expandedToggle);
  };

  return (
    <div
      ref={parentRef}
      style={{
        height: "100%",
        overflowY: "auto",
        contain: "strict",
        position: "relative",
        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
      }}
    >
      <div
        style={{
          position: "sticky",
          top: 0,
          zIndex: 100,
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
          padding: GLOBAL_SMALL_SPACING,
        }}
      >
        <QuickFilter
          filterOptions={[{ key: "name", label: "name" }]}
          defaultSelectedOptionKey="name"
          placeHolder={() => t("common.place_holder.search_department_name")}
          onChange={(_, searchValue) => setSearchKey(searchValue)}
        />
      </div>
      <div
        style={{
          height: virtualizer.getTotalSize(),
          width: "100%",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            transform: `translateY(${items[0]?.start ?? 0}px)`,
          }}
        >
          {items.map((virtualRow) => (
            <div
              key={virtualRow.key}
              data-index={virtualRow.index}
              ref={virtualizer.measureElement}
            >
              <SimpleTreeView
                key={virtualRow.key}
                sx={{
                  "& .Mui-selected": {
                    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    color: COLOR_TYPE.TOYOTA.TOYOTA1,
                  },
                }}
                expandedItems={expanded}
                onItemExpansionToggle={handleToggle}
                selectedItems={selectedItem}
                onSelectedItemsChange={(_, itemId) => {
                  setSelectedItem(itemId ?? "");
                }}
              >
                {renderTreeItem(getDepartmentsQuery.data![virtualRow.index])}
              </SimpleTreeView>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
