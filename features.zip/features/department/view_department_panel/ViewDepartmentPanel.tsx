import { useTranslation } from "react-i18next";
import { Divider, Grid, Typography } from "@mui/material";
import { GLOBAL_LARGE_SPACING, GLOBAL_SPACING } from "@/constants/format";
import { Field } from "@/features/user/view_user_panel/ViewUserPanel";
import { LANGUAGES } from "@/locales/config-translation";
import {
  Department,
  DepartmentFieldNames,
} from "@/models/department/Department";

export interface ViewDepartmentPanelProps {
  department: Department | undefined;
}

export const ViewDepartmentPanel = (props: ViewDepartmentPanelProps) => {
  const [t, i18n] = useTranslation();

  return (
    <>
      {props.department && (
        <Grid
          container
          className='form-wrapper'
          height={"100%"}
          sx={{ overflow: "hidden" }}
        >
          <Grid
            container
            direction={"column"}
            wrap='nowrap'
            rowGap={GLOBAL_SPACING}
            alignItems={"flex-start"}
            className='form-section-wrapper'
            height={"100%"}
            padding={GLOBAL_LARGE_SPACING}
            sx={{
              height: "100%",
              overflowY: "auto",
              contain: "strict",
              position: "relative",
            }}
          >
            <Grid item>
              <Typography variant="h2">
                {i18n.language == LANGUAGES.VIETNAMESE
                  ? props.department.name
                  : props.department.nameEnglish}
              </Typography>
            </Grid>

            <Field
              title={t(`department.field_name.${DepartmentFieldNames.NAME}`)}
              value={
                i18n.language == LANGUAGES.VIETNAMESE
                  ? props.department.name
                  : props.department.nameEnglish
              }
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`department.field_name.${DepartmentFieldNames.CODE}`)}
              value={props.department.code}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            {props.department.description ?
              <>
                <Field
                  title={t(
                    `department.field_name.${DepartmentFieldNames.DESCRIPTION}`
                  )}
                  value={props.department.description ?? ""}
                />
                <Grid item width={"100%"}>
                  <Divider />
                </Grid>
              </> : null}

            <Field
              title={t(`department.field_name.${DepartmentFieldNames.TYPE}`)}
              value={props.department?.departmentType?.name ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`department.field_name.${DepartmentFieldNames.PARENT}`)}
              value={
                i18n.language == LANGUAGES.VIETNAMESE
                  ? props.department.parentDepartmentNames
                  : props.department.parentDepartmentNameEnglish
              }
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`department.field_name.${DepartmentFieldNames.STATUS}`)}
              value={props.department.status ?? ""}
            />
          </Grid>
        </Grid>
      )}
    </>
  );
};
