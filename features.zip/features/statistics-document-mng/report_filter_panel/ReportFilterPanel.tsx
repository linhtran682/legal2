import { getDepartments } from "@/apis/service/department/department";
import {
  getDocumentMngStock,
} from "@/apis/service/document_management/DocumentManagement";
import { getStatusList } from "@/apis/service/status/Status";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import ReportTypeSelect from "@/components/commons/report_type_select/ReportTypeSelect";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { ModuleFields } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import {
  castDepartmentToSchema,
  Department,
} from "@/models/department/Department";
import { BasedDocumentManagementFieldNames } from "@/models/document_management/DocumentManagement";
import { FieldFieldNames } from "@/models/field/Field";
import { toIsoEndOfDay, toIsoStartOfDay } from "@/utils";
import { Box, Button, Grid, Stack } from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

interface ReportFilterPanelProps {
  onSearch?: (data: any) => void;
  onExport?: (data: any) => void;
  loading?: boolean;
  noStatus?: boolean;
}
const ReportFilterPanel = (props: ReportFilterPanelProps) => {
  const { onExport, onSearch, loading, noStatus } = props;
  const form = useForm();
  const { t } = useTranslation();

  const getParams = () => {
    const data = form.getValues();
    const params = {
      startDate: toIsoStartOfDay(data?.from as Date),
      endDate: toIsoEndOfDay(data?.to as Date),
      folderIds: data?.[BasedDocumentManagementFieldNames.FOLDER_ID]?.map((folderId: any)=>folderId?.id),
      departmentIds: data?.[BasedDocumentManagementFieldNames.MANAGEMENT_DEPARTMENTS]?.map((departmentId: any)=>departmentId?.id),
      [BasedDocumentManagementFieldNames.DOCUMENT_TYPE]:
        data?.[BasedDocumentManagementFieldNames.DOCUMENT_TYPE],
    };
    return params;
  };

  const handleSearch = () => {
    const params = getParams();
    onSearch?.(params);
  };
  const handleExport = () => {
    const params = getParams();
    onExport?.(params);
  };

  return (
    <FormProvider {...form}>
      <Box
        sx={{
          backgroundColor: "white",
          p: 1,
          ...formInputSxProps,
        }}
      >
        <Grid container spacing={1}>
          <ReportTypeSelect />

          {noStatus ? null : (
            <Grid item xs={12} md={6}>
              <FormMultipleSelect
                control={form.control}
                name={"status"}
                label={t(`report.status`)}
                placeholder={t(`report.status`)}
                keyQuery={"document-management-report-status-query"}
                getOptions={async () => {
                  const response = await getStatusList({
                    page: 0,
                    size: 100,
                    sortBy: FieldFieldNames.NAME,
                    orderBy: "ASC",
                    modules: [ModuleFields.DOCUMENT_MANAGEMENT.module],
                    active: 1,
                  });
                  return response?.statusResponses || [];
                }}
                showAllSelected={false}
                getOptionKey={(option) => option.id.toString()}
                getOptionLabel={(option) => option?.name}
                isFocus
              />
            </Grid>
          )}
          <Grid item xs={12} md={6}>
            <FormSelectTreeView
              name={BasedDocumentManagementFieldNames.FOLDER_ID}
              control={form.control}
              label={t(
                `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.FOLDER_ID}`
              )}
              placeholder={t(
                `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.FOLDER_ID}`
              )}
              getOptions={async (keyword) => {
                try {
                  const response = await getDocumentMngStock({ name: keyword });
                  return (response?.folders as unknown as Department[]) ?? [];
                } catch (e) {
                  return [];
                }
              }}
              getOptionLabel={(option) => option.name ?? ""}
              getOptionKey={(option) => option.id ?? ""}
              getOptionChildren={(option) => option?.children}
              variant="outlined"
              debounceMs={FILTER_DEBOUNCE_MS}
              onChange={(value: any) => {
                form.setValue("folderId", (value ?? []));
              }}
              queryKeyCheck={"statistics-document-management-folders"}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <FormTextField
              control={form.control}
              name={BasedDocumentManagementFieldNames.DOCUMENT_TYPE}
              label={t(
                `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.DOCUMENT_TYPE}`
              )}
              placeHolder={t(
                `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.DOCUMENT_TYPE}`
              )}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <FormSelectTreeView
              name={BasedDocumentManagementFieldNames.MANAGEMENT_DEPARTMENTS}
              control={form.control}
              label={t(
                `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.MANAGEMENT_DEPARTMENTS}`
              )}
              placeholder={t(
                `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.MANAGEMENT_DEPARTMENTS}`
              )}
              getOptions={async (keyword) => {
                try {
                  const response = await getDepartments({
                    searchTerm: keyword,
                  });
                  const first100Departments: Department[] = (
                    response?.departments ?? []
                  ).slice(0, 150);
                  return first100Departments;
                } catch (e) {
                  return [];
                }
              }}
              getOptionLabel={(option) => option.name ?? ""}
              getOptionKey={(option) => option.id ?? ""}
              getOptionChildren={(option: any) => option?.children}
              variant="outlined"
              debounceMs={FILTER_DEBOUNCE_MS}
              onChange={(value: Department[]) => {
                form.setValue(
                  "managementDepartments",
                  (value ?? []).map((department) =>
                    castDepartmentToSchema(department)
                  )
                );
              }}
              rules={{ required: "This field is required" }}
              queryKeyCheck="statistics-document-management-department"
            />
          </Grid>
        </Grid>
      </Box>
      <Stack
        sx={{
          backgroundColor: "white",
        }}
        p={1.5}
        direction={"row"}
        mt={1.5}
        gap={1.5}
        width={"100%"}
        justifyContent={"flex-end"}
      >
        <Button
          variant="contained"
          className="confirm"
          disabled={loading}
          sx={{ minWidth: 128 }}
          onClick={form.handleSubmit(handleSearch)}
        >
          {t("report.search")}
        </Button>
        {onExport ? (
          <Button
            variant="contained"
            className="confirm"
            disabled={loading}
            sx={{ minWidth: 128 }}
            onClick={form.handleSubmit(handleExport)}
          >
            Export
          </Button>
        ) : null}
      </Stack>
    </FormProvider>
  );
};

export default ReportFilterPanel;
