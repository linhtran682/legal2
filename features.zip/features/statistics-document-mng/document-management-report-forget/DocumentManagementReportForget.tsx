import { getStatisticDocumentMngTableForgetFn } from "@/apis/service/document_management/DocumentManagement";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import StandardTable, {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import {
  BasedDocumentManagementFieldNames,
  castTableStateToParams,
  getFieldLabelDocumentMng,
  IReportFilters,
} from "@/models/document_management/DocumentManagement";
import { Button, Radio, Stack } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useEffect, useState } from "react";
import ReportFilterPanel from "../report_filter_panel/ReportFilterPanel";

const DocumentManagementReportForget = () => {
  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [reportFilters, setReportFilters] = useState<IReportFilters>({});

  const [documentManagementTableColumns] = useState<
    MultipleFilterTableColumn[]
  >([
    {
      key: BasedDocumentManagementFieldNames.ID,
      label: BasedDocumentManagementFieldNames.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
    },
    {
      key: BasedDocumentManagementFieldNames.FOLDER_ID,
      label: BasedDocumentManagementFieldNames.FOLDER_ID,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      flex: 1,
      minWidth: 150,
      renderCell: (row) => <>{row.row.folderName}</>,
    },
    {
      key: BasedDocumentManagementFieldNames.DOCUMENT_TYPE,
      label: BasedDocumentManagementFieldNames.DOCUMENT_TYPE,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      flex: 1,
    },
    {
      key: BasedDocumentManagementFieldNames.NAME,
      label: BasedDocumentManagementFieldNames.NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 150,
      flex: 1,
    },
    {
      key: BasedDocumentManagementFieldNames.STATUS,
      label: BasedDocumentManagementFieldNames.STATUS,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 220,
      renderCell: (params) => {
        return (
          <Button
            variant="outlined"
            style={{
              background:
                params?.row?.status?.name &&
                params?.row?.status?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params?.row?.status?.name &&
                params?.row?.status?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params?.row?.status?.name}
          </Button>
        );
      },
    },
    {
      key: BasedDocumentManagementFieldNames.AGENCY_ISSUED,
      label: BasedDocumentManagementFieldNames.AGENCY_ISSUED,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 150,
      flex: 1,
    },
    {
      key: BasedDocumentManagementFieldNames.DATE_ISSUED,
      label: BasedDocumentManagementFieldNames.DATE_ISSUED,
      type: "date",
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      renderCell: (params) =>
        params.row.dateIssued
          ? format(new Date(params.row.dateIssued), "dd/MM/yyyy")
          : "",
    },
    {
      key: BasedDocumentManagementFieldNames.DOCUMENT_CHANGE_DATE,
      label: BasedDocumentManagementFieldNames.DOCUMENT_CHANGE_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      renderCell: (params) =>
        params.row.documentChangeDate
          ? format(new Date(params.row.documentChangeDate), "dd/MM/yyyy")
          : "",
    },
    {
      key: BasedDocumentManagementFieldNames.EXPIRY_DATE,
      label: BasedDocumentManagementFieldNames.EXPIRY_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      renderCell: (params) =>
        params.row.expiryDate
          ? format(new Date(params.row.expiryDate), "dd/MM/yyyy")
          : "",
    },
    {
      key: BasedDocumentManagementFieldNames.NOTE_UPDATE_TIME,
      label: BasedDocumentManagementFieldNames.NOTE_UPDATE_TIME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 150,
      flex: 1,
    },
    {
      key: BasedDocumentManagementFieldNames.COMPANY_SCOPE,
      label: BasedDocumentManagementFieldNames.COMPANY_SCOPE,
      type: "string",
      filterable: false,
      sortable: false,
      align: "center",
      renderCell: (params) => <Radio checked={params.value} />,
      minWidth: 120,
    },
    {
      key: BasedDocumentManagementFieldNames.DEPARTMENT_SCOPE,
      label: BasedDocumentManagementFieldNames.DEPARTMENT_SCOPE,
      type: "string",
      filterable: false,
      sortable: false,
      minWidth: 120,
      align: "center",
      renderCell: (params) => (
        <Radio style={{ width: 10 }} checked={params.value} />
      ),
    },
    {
      key: BasedDocumentManagementFieldNames.CREATOR,
      label: "sender",
      type: "string",
      sortable: true,
      minWidth: 200,
      renderCell: (row) => <>{row.row.createdBy.name}</>,
    },
    {
      key: BasedDocumentManagementFieldNames.RECEIVERS,
      label: "receiversReport",
      type: "string",
      sortable: true,
      minWidth: 200,
      flex: 1,
      renderCell: (params) =>
        (params.value || []).map((item: any) => item.name).join(","),
    },
    {
      key: BasedDocumentManagementFieldNames.RELATED_DEPARTMENTS,
      label: BasedDocumentManagementFieldNames.RELATED_DEPARTMENTS,
      type: "string",
      sortable: true,
      renderCell: (params) =>
        (params.value || []).map((item: any) => item.name).join(","),
      minWidth: 200,
      flex: 1,
    },
  ]);

  const getTableQuery = useQuery({
    queryKey: ["document-management/statistic/table"],
    queryFn: async () =>
      await getStatisticDocumentMngTableForgetFn(
        castTableStateToParams(tableState, reportFilters)
      ),
    enabled: false,
  });

  useEffect(() => {
    tableState && getTableQuery.refetch();
  }, [tableState, reportFilters]);

  const onSearchClick = (data: any) => {
    setReportFilters({
      ...data,
    });
  };

  return (
    <Stack direction={"column"} height={"100%"}>
      <ReportFilterPanel onSearch={onSearchClick} noStatus />
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.data ?? []}
          columns={documentManagementTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabelDocumentMng(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          // onRowClick={(params) =>
          //   router.push(
          //     `/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
          //   )
          // }
          hideRowCheckbox
        />
      </div>
    </Stack>
  );
};

export default DocumentManagementReportForget;
