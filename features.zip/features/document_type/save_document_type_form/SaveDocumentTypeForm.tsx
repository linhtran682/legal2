import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import {
  SaveDocumentTypeDTO,
  SaveDocumentTypeRequestFieldNames,
  SaveDocumentTypeRequestSchema,
  SaveDocumentTypeRequestSchemaI,
} from "@/models/document_type/DocumentType";
import { BasicSaveForm } from "@/models/ui/form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveDocumentTypeFormProps
  extends BasicSaveForm<SaveDocumentTypeDTO, SaveDocumentTypeDTO> {}

const initialEmptyValue: SaveDocumentTypeDTO = {
  name: "",
  description: "",
};

export const SaveDocumentTypeForm = (props: SaveDocumentTypeFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<SaveDocumentTypeRequestSchemaI>({
    resolver: yupResolver(SaveDocumentTypeRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue && form.reset(props.initialValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <FormTextField
              control={form.control}
              name={SaveDocumentTypeRequestFieldNames.NAME}
              label={t(
                `document_type.field_name.${SaveDocumentTypeRequestFieldNames.NAME}`
              )}
              placeHolder={t(
                `document_type.field_name.${SaveDocumentTypeRequestFieldNames.NAME}`
              )}
              required
            />
          </Grid>

          <Grid item width={"100%"}>
            <FormTextArea
              control={form.control}
              name={SaveDocumentTypeRequestFieldNames.DESCRIPTION}
              label={t(
                `document_type.field_name.${SaveDocumentTypeRequestFieldNames.DESCRIPTION}`
              )}
              placeHolder={t(
                `document_type.field_name.${SaveDocumentTypeRequestFieldNames.DESCRIPTION}`
              )}
              minRows={3}
            />
          </Grid>
        </Grid>

        <FormActionButtons
          loading={props.loading}
          onCancel={props.onCancel}
          cancelConfirm={form.formState.isDirty}
          onDelete={props.onDelete}
          onSave={props.onSubmit}
          formMode={props.formMode}
        />
      </FormProvider>
    </Grid>
  );
};
