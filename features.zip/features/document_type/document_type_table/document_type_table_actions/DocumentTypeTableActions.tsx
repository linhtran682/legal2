import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { GridRenderCellParams } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import DeleteIcon from "@mui/icons-material/Delete";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { deleteDocumentTypes } from "@/apis/service/document_type/DocumentType";
import { DocumentTypeTableConst } from "../DocumentTypeTable";
import { DOCUMENT_TYPE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";

export const DocumentTypeTableAtions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  const queryClient = useQueryClient();

  const deleteDocumentTypesQuery = useMutation({
    mutationFn: deleteDocumentTypes,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.documentType"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [DocumentTypeTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_document_type",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(
              `/${DOCUMENT_TYPE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            ),
          tooltipTitle: t("common.button.update"),
        },
        {
          key: "delete_document_type",
          icon: <DeleteIcon color='primary' />,
          onClick: (params) =>
            params.id && deleteDocumentTypesQuery.mutate([Number(params.id)]),
          tooltipTitle: t("common.button.delete"),
          confirmPopupProps: {
            icon: <DeleteRecordDialogIcon />,
            title: t("common.message.confirm_delete"),
          },
        },
      ]}
    />
  );
};
