import MultipleFilterTable, {
  MultipleFilterTableColumn,
} from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { GridFilterItem } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import {
  DocumentTypeFieldNames,
  GetDocumentTypesParams,
} from "@/models/document_type/DocumentType";
import { DocumentTypeTableAtions } from "./document_type_table_actions/DocumentTypeTableActions";
import {
  deleteDocumentTypes,
  getDocumentTypes,
} from "@/apis/service/document_type/DocumentType";
import { useRouter } from "next/navigation";
import { DOCUMENT_TYPE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useTranslation } from "react-i18next";
import { TableGroupedActionButtons } from "@/components/commons/action_button/TableGroupedActionButtons";

export const DocumentTypeTableConst = {
  TABLE_NAME: "DocumentTypeTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getDocumentTypes",
};

const DocumentTypeTableColumns: MultipleFilterTableColumn[] = [
  {
    key: DocumentTypeFieldNames.ID,
    label: DocumentTypeFieldNames.ID,
    type: "number",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
  },
  {
    key: DocumentTypeFieldNames.NAME,
    label: DocumentTypeFieldNames.NAME,
    type: "string",
    quickFilter: true,
    filterable: true,
    sortable: true,
    hideable: false,
    flex: 1,
  },
  {
    key: DocumentTypeFieldNames.CREATED_BY,
    label: DocumentTypeFieldNames.CREATED_BY,
    type: "string",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
    flex: 1,
  },
  {
    key: DocumentTypeFieldNames.CREATED_AT,
    label: DocumentTypeFieldNames.CREATED_AT,
    type: "date",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
    flex: 1,
  },
  {
    key: "action",
    label: "",
    type: undefined,
    renderCell: DocumentTypeTableAtions,
    quickFilter: false,
    filterable: false,
    sortable: false,
    hideable: false,
    cellClassName: "stickyRight",
  },
];

const castTableStateToParams = (
  tableState: StandardTableState
): GetDocumentTypesParams => {
  const params: GetDocumentTypesParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: DocumentTypeFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == DocumentTypeFieldNames.NAME) {
      params.name = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};

export const DocumentTypeTable = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getDocumentTypesQuery = useQuery({
    queryKey: [DocumentTypeTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getDocumentTypes(castTableStateToParams(tableState)),
  });

  const deleteDocumentTypesQuery = useMutation({
    mutationFn: deleteDocumentTypes,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.documentType"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [DocumentTypeTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  // Watch table state then refetch new data for the table
  useEffect(() => {
    tableState &&
      getDocumentTypesQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  return (
    <MultipleFilterTable
      data={getDocumentTypesQuery.data?.documentTypes || []}
      columns={DocumentTypeTableColumns
      // .filter((column) => appContext.meCanWrite || column.key != "action")
      .map((column) => ({
        ...column,
        label: column.label && `document_type.column.${column.label}`,
      }))}
      getRowId={(item) => item.id.toString()}
      loading={getDocumentTypesQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getDocumentTypesQuery.data?.total}
      onRowClick={(params) => {
        router.push(
          `/${DOCUMENT_TYPE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
        );
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: DocumentTypeFieldNames.NAME,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(
              `document_type.column.${fieldKey}`
            ).toLocaleLowerCase(),
          }),
      }}
      groupedActions={(model) => (
        <TableGroupedActionButtons
          selectModel={model}
          onDelete={deleteDocumentTypesQuery.mutate}
        />
      )}
    />
  );
};
