import { getRoles } from "@/apis/service/role/Role";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { UserStatus, UserType } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { RoleDTO } from "@/models/role/Role";
import { BasicSaveForm } from "@/models/ui/form";
import {
  castSaveUserRequestSchemaIToSaveUserRequestDTO,
  castUserProfileDTOToSaveUserRequestSchemaI,
  SaveUserRequestDTO,
  SaveUserRequestSchema,
  SaveUserRequestSchemaFieldnames,
  SaveUserRequestSchemaI,
  UserProfileDTO,
  UserProfileFieldNames,
} from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveUserFormProps
  extends BasicSaveForm<UserProfileDTO, SaveUserRequestDTO> {
  userId?: string;
}

const initialEmptyValue: SaveUserRequestSchemaI = {
  name: "",
  roles: [],
  status: "ACTIVE",
  email: "",
  type: "GUEST",
  company: "",
};

export const SaveUserForm = (props: SaveUserFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm({
    resolver: yupResolver(SaveUserRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue &&
      form.reset(
        castUserProfileDTOToSaveUserRequestSchemaI(props.initialValue)
      );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  const onSubmit = (value: SaveUserRequestSchemaI) => {
    props.onSubmit(
      castSaveUserRequestSchemaIToSaveUserRequestDTO(value, props?.userId)
    );
  };
  const isMe = props?.userId === appContext.me?.id;

  const isTMV = form.getValues().type == UserType.TMV;
  const isAdmin = (props.initialValue?.roles || []).some(
    (role) => role.name == "Administrator"
  );
  const isNotEditable = !props.initialValue?.editable;
  const isCreate = props.formMode === 'create';

  return (
    <FormProvider {...form}>
      <Grid container className='form-wrapper'>
        <Grid
          container
          direction={"row"}
          flexShrink={0}
          spacing={GLOBAL_SPACING}
          alignItems={"flex-start"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item xs={6}>
            <FormTextField
              control={form.control}
              name={SaveUserRequestSchemaFieldnames.NAME}
              label={t(`user.field_name.${UserProfileFieldNames.NAME}`)}
              placeHolder={t(`user.field_name.${UserProfileFieldNames.NAME}`)}
              required
              disabled={(isTMV || isAdmin || isNotEditable) && !isCreate && !isMe}
            />
          </Grid>

          <Grid item xs={6}>
            <FormSelect
              control={form.control}
              name={SaveUserRequestSchemaFieldnames.TYPE}
              label={t(`user.field_name.${UserProfileFieldNames.TYPE}`)}
              placeHolder={t(`user.field_name.${UserProfileFieldNames.TYPE}`)}
              options={Array.from(Object.values(UserType)).map((key) => ({
                label: key,
                value: key,
              }))}
              getOptionKey={(option) => option.value}
              getOptionLabel={(option) => option.label}
              required
              disabled
            />
          </Grid>

          <Grid item xs={6}>
            <FormTextField
              control={form.control}
              name={SaveUserRequestSchemaFieldnames.EMAIL}
              label={t(`user.field_name.${UserProfileFieldNames.EMAIL}`)}
              placeHolder={t(`user.field_name.${UserProfileFieldNames.EMAIL}`)}
              disabled={(isTMV || isAdmin || isNotEditable) && !isCreate && !isMe}
              required
            />
          </Grid>

          <Grid item xs={6}>
            <FormTextField
              control={form.control}
              name={SaveUserRequestSchemaFieldnames.COMPANY}
              label={t(`user.field_name.${UserProfileFieldNames.COMPANY}`)}
              placeHolder={t(
                `user.field_name.${UserProfileFieldNames.COMPANY}`
              )}
              disabled={(isTMV || isAdmin || isNotEditable) && !isCreate && !isMe}
            />
          </Grid>

          <Grid item xs={6}>
            <FormMultipleSelect<SaveUserRequestSchemaI, RoleDTO>
              control={form.control}
              name={SaveUserRequestSchemaFieldnames.ROLES}
              label={t(`user.field_name.${UserProfileFieldNames.ROLES}`)}
              placeholder={t(`user.field_name.${UserProfileFieldNames.ROLES}`)}
              getOptions={async (keyword) => {
                const response = await getRoles({
                  searchTerm: keyword,
                  page: 0,
                  size: 100,
                });

                return response?.roles ?? [];
              }}
              getOptionLabel={(option) => option.name ?? ""}
              getOptionKey={(option) => option.id}
              keyQuery='user.queryRole'
              required
              disabled={isAdmin && !isMe}
            />
          </Grid>

          <Grid item xs={6}>
            <FormSelect
              control={form.control}
              name={SaveUserRequestSchemaFieldnames.STATUS}
              label={t(`user.field_name.${UserProfileFieldNames.STATUS}`)}
              placeHolder={t(`user.field_name.${UserProfileFieldNames.STATUS}`)}
              options={Array.from(Object.values(UserStatus)).map((key) => ({
                label: key,
                value: key,
              }))}
              getOptionKey={(option) => option.value}
              getOptionLabel={(option) => option.label}
              required
              disabled={isAdmin && !isMe}
            />
          </Grid>

          {isTMV && (
            <Grid item xs={6}>
              <FormTextField
                control={form.control}
                name={SaveUserRequestSchemaFieldnames.POSITION}
                label={t(
                  `user.field_name.${UserProfileFieldNames.POSITION}`
                )}
                placeHolder={t(
                  `user.field_name.${UserProfileFieldNames.POSITION}`
                )}
                disabled
              />
            </Grid>
          )}
          {isTMV && (
            <Grid item xs={6}>
              <FormTextField
                control={form.control}
                name={SaveUserRequestSchemaFieldnames.DEPARTMENT_NAME}
                label={t(
                  `user.field_name.${UserProfileFieldNames.DEPARTMENT}`
                )}
                placeHolder={t(
                  `user.field_name.${UserProfileFieldNames.DEPARTMENT}`
                )}
                disabled
              />
            </Grid>
          )}
          {isTMV && (
            <Grid item xs={6}>
              <FormTextField
                control={form.control}
                name={SaveUserRequestSchemaFieldnames.EMPLOYEE_CODE}
                label={t(
                  `user.field_name.${UserProfileFieldNames.EMPLOYEE_CODE}`
                )}
                placeHolder={t(
                  `user.field_name.${UserProfileFieldNames.EMPLOYEE_CODE}`
                )}
                disabled
              />
            </Grid>
          )}

          {isTMV && (
            <Grid item xs={6}>
              <FormTextField
                control={form.control}
                name={SaveUserRequestSchemaFieldnames.ENTRA_ID}
                label={t(`user.field_name.${UserProfileFieldNames.ENTRA_ID}`)}
                placeHolder={t(
                  `user.field_name.${UserProfileFieldNames.ENTRA_ID}`
                )}
                disabled
              />
            </Grid>
          )}
        </Grid>

        {isAdmin && !isMe ? null
          : <FormActionButtons
            formMode={props.formMode}
            loading={props.loading}
            onCancel={props.onCancel}
            cancelConfirm={form.formState.isDirty}
            onDelete={props.onDelete}
            onSave={onSubmit}
          />
        }
      </Grid>
    </FormProvider>
  );
};
