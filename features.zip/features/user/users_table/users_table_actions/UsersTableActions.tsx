import { GridRenderCellParams } from "@mui/x-data-grid";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import EditIcon from "@mui/icons-material/Edit";
import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { UI_PATH, USER_ROOT_PATH } from "@/constants/paths";

export const UsersTableActions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_user",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(`/${USER_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`),
          tooltipTitle: t("common.button.update"),
        },
      ]}
    />
  );
};
