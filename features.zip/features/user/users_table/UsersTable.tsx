import { getUsers } from "@/apis/service/user/User";
import MultipleFilterTable from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableColumn,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import { UI_PATH, USER_ROOT_PATH } from "@/constants/paths";
import { LANGUAGES } from "@/locales/config-translation";
import { RoleDTO } from "@/models/role/Role";
import { GetUsersParams, UserProfileFieldNames } from "@/models/user/User";
import SwapVertRoundedIcon from '@mui/icons-material/SwapVertRounded';
import { Grid, IconButton, Menu, MenuItem } from "@mui/material";
import { GridFilterItem } from "@mui/x-data-grid";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { UsersTableActions } from "./users_table_actions/UsersTableActions";

export const UsersTableConst = {
  TABLE_NAME: "UsersTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getUsers",
};

export const UsersTable = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const { i18n } = useTranslation();

  const castTableStateToParams = (
    tableState: StandardTableState
  ): GetUsersParams => {
    const params: GetUsersParams = {
      page: tableState?.paginationModel?.page || 0,
      size: tableState?.paginationModel?.pageSize || 0,
      sortBy:
        i18n.language == LANGUAGES.VIETNAMESE
          ? UserProfileFieldNames.NAME
          : UserProfileFieldNames.NAME_ENGLISH,
      sortOrder: "DESC",
      status: 'all'
    };

    (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
      if (item.field == UserProfileFieldNames.NAME) {
        params.searchTerm = item.value;
      }
    });

    if ((tableState.sorterModel || []).length > 0) {
      params.sortBy = tableState.sorterModel![0].field;
      params.sortOrder =
        tableState.sorterModel![0].sort?.toUpperCase() ?? "DESC";
    }

    return params;
  };

  const [usersTableColumns] = useState<StandardTableColumn[]>(() => [
    {
      key:
        i18n.language == LANGUAGES.VIETNAMESE
          ? UserProfileFieldNames.NAME
          : UserProfileFieldNames.NAME_ENGLISH,
      label: UserProfileFieldNames.NAME,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      flex: 1,
      minWidth: 200
    },
    {
      key: UserProfileFieldNames.ROLES,
      label: UserProfileFieldNames.ROLES,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      flex: 1,
      minWidth: 240,
      renderCell: (params) =>
        ((params.value as RoleDTO[]) ?? []).map((role) => role.name).join(", "),
    },
    {
      key: UserProfileFieldNames.ENTRA_ID,
      label: UserProfileFieldNames.ENTRA_ID,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      flex: 1,
      minWidth: 200,
    },
    {
      key: UserProfileFieldNames.EMAIL,
      label: UserProfileFieldNames.EMAIL,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      flex: 1,
      minWidth: 240,
    },
    {
      key: UserProfileFieldNames.STATUS,
      label: UserProfileFieldNames.STATUS,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      minWidth: 150,
    },
    {
      key: UserProfileFieldNames.TYPE,
      label: UserProfileFieldNames.TYPE,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      minWidth: 150,
    },
    {
      key: UserProfileFieldNames.COMPANY,
      label: UserProfileFieldNames.COMPANY,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      minWidth: 150,
    },
    {
      key: UserProfileFieldNames.DEPARTMENT,
      label: UserProfileFieldNames.DEPARTMENT,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      renderCell: (params) => params.value?.name,
      flex: 1,
      minWidth: 200,
    },
    {
      key: UserProfileFieldNames.POSITION,
      label: UserProfileFieldNames.POSITION,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      renderCell: (params) =>
        i18n.language == LANGUAGES.VIETNAMESE
          ? params.value?.name
          : params.value?.nameEnglish,
      flex: 1,
      minWidth: 180,
    },
    {
      key: "action",
      label: "",
      type: undefined,
      renderCell: UsersTableActions,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "last-column-sticky",
      headerClassName: "last-column-sticky-header",
    },
  ]);

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [{ field: 'name', sort: 'asc' }],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getUsersQuery = useQuery({
    queryKey: [UsersTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getUsers(castTableStateToParams(tableState)),
  });

  const [selectedIndex, setSelectedIndex] = useState<'asc' | 'desc'>('asc');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuItemClick = (
    index: 'asc' | 'desc',
  ) => {
    setSelectedIndex(index);
    setAnchorEl(null);
    setTableState({
      ...tableState,
      sorterModel: [{ field: 'name', sort: index }]
    })
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  // Watch table state then refetch new data for the table
  useEffect(() => {
    if (tableState) {
      getUsersQuery.refetch();
      if (tableState.sorterModel?.length) {
        const findSortByName = tableState.sorterModel?.find((ele) => ele.field === 'name');
        setSelectedIndex(findSortByName?.sort ?? selectedIndex)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  const renderSortButton = () => {
    return <Grid item>
      <IconButton
        disabled={getUsersQuery.isFetching}
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
        }}
        onClick={handleClick}
      >
        <SwapVertRoundedIcon />
      </IconButton>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <MenuItem selected={selectedIndex === 'asc'} onClick={() => handleMenuItemClick('asc')}>{t('common.option.sort.nameAsc')}</MenuItem>
        <MenuItem selected={selectedIndex === 'desc'} onClick={() => handleMenuItemClick('desc')}>{t('common.option.sort.nameDesc')}</MenuItem>
      </Menu>
    </Grid>
  }

  return (
    <MultipleFilterTable
      data={getUsersQuery.data?.users || []}
      columns={usersTableColumns
        // .filter((column) => appContext.meCanWrite || column.key != "action")
        .map((column) => ({
          ...column,
          label: column.label && `user.field_name.${column.label}`,
        }))}
      getRowId={(item) => item.id.toString()}
      loading={getUsersQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getUsersQuery.data?.total}
      // multipleFilter
      onRowClick={(params) => {
        router.push(`/${USER_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`);
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: UserProfileFieldNames.NAME,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(`user.field_name.${fieldKey}`).toLocaleLowerCase(),
          }),
      }}
      sortButton={renderSortButton()}
    />
  );
};
