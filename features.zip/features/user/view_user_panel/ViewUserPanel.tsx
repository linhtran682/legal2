import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_LARGE_SPACING, GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { UserProfileDTO, UserProfileFieldNames } from "@/models/user/User";
import { Button, Divider, Grid, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";

export interface ViewUserPanelProps {
  user: UserProfileDTO | undefined;
  loading: boolean;
  onUpdate: () => void;
}

export const ViewUserPanel = (props: ViewUserPanelProps) => {
  const [t, i18n] = useTranslation();

  const userName =
    i18n.language == LANGUAGES.VIETNAMESE
      ? props.user?.name
      : props.user?.nameEnglish;

  const positionName =
    i18n.language == LANGUAGES.VIETNAMESE
      ? props.user?.position?.name
      : props.user?.position?.nameEnglish;

  return (
    <>
      {props.user && (
        <Grid container className='form-wrapper'>
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"flex-start"}
            className='form-section-wrapper'
            padding={GLOBAL_LARGE_SPACING}
          >
            <Grid item>
              <Typography variant='h1'>
                {t("user.title.user_details")}
              </Typography>
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.NAME}`)}
              value={userName ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.ROLES}`)}
              value={(props.user.roles || [])
                .map((role) => role.name)
                .join(", ")}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(
                `user.field_name.${UserProfileFieldNames.EMPLOYEE_CODE}`
              )}
              value={props.user.employeeCode ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.ENTRA_ID}`)}
              value={props.user.entraId ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.EMAIL}`)}
              value={props.user.email ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.STATUS}`)}
              value={props.user.status ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.TYPE}`)}
              value={props.user.type ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.COMPANY}`)}
              value={props.user.company ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.DEPARTMENT}`)}
              value={props.user.department?.name ?? ""}
            />

            <Grid item width={"100%"}>
              <Divider />
            </Grid>

            <Field
              title={t(`user.field_name.${UserProfileFieldNames.POSITION}`)}
              value={positionName ?? ""}
            />
          </Grid>

          <Grid
            container
            justifyContent={"end"}
            style={{ position: "sticky", bottom: 0 }}
          >
            <Grid item style={{ position: "sticky", right: 0 }}>
              <Grid container padding={GLOBAL_SPACING} spacing={GLOBAL_SPACING}>
                <Grid item>
                  <Button
                    onClick={props.onUpdate}
                    variant='contained'
                    disabled={props.loading}
                  >
                    {t("common.button.update")}
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      )}
    </>
  );
};

export const Field = (props: { title: string; value: string | undefined }) => {
  return (
    <Grid item width={"100%"}>
      <Grid container direction={"row"} justifyContent={"start"} wrap='nowrap'>
        <Grid item xs={3}>
          <Typography
            flexWrap={"wrap"}
            variant='h6'
            color={COLOR_TYPE.TOYOTA.TOYOTA4}
          >
            {props.title}:
          </Typography>
        </Grid>
        <Grid item xs={9}>
          <Typography variant="h6" flexWrap={"wrap"}>{props.value}</Typography>
        </Grid>
      </Grid>
    </Grid>
  );
};
