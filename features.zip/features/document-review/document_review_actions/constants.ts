export const DrrActionsBtnKey = {
  CREATE_NEW: "create", // Tạo mới
  UPDATE: "update",

  RECALL: "recall", // Thu hồi
  FORWARD: "forward", // Chuyển tiếp
  FEEDBACK: "feedback", // Phản hồi
  REQUEST_MEETING: "requestMeeting", // Y/C họp
  SEND_MAIL: "sendMail",
  REQUEST_TIME_EXTENSION: "requestTimeExtension", // Yêu cầu gia hạn thời gian
  CONFIRM: "confirm", // Xác nhận
  ASSIGNMENT: "assignment", // Phân công
  REQUEST_VENDOR: "requestVendor",
  FEEDBACK_ADVISE: "feedbackAdvise", // Phản hồi tư vấn,
  REQUEST_ADDITIONAL: "requestAdditional", // Yêu cầu bổ sung thông tin
  ADVISE: "review", // Tư vấn
  FINISH_REVIEW: "finishReview",
  DONE: "done", // Hoàn thành
  NOT_AVAILABLE: "notAvailable", // Đang không ở trạng thái của role

  SHARE: "share",
  RECHECK: "recheck",
  UNKNOWN_24: "unknown24",
  INFO_ADDED: "infoAdded",
};

export const DrrActionsBtnR: Map<number, string> = new Map([
  [0, DrrActionsBtnKey.NOT_AVAILABLE],
  [1, DrrActionsBtnKey.CREATE_NEW],
  [2, DrrActionsBtnKey.UPDATE],
  [3, DrrActionsBtnKey.ASSIGNMENT],
  [4, DrrActionsBtnKey.FORWARD],
  [5, DrrActionsBtnKey.ADVISE],
  [6, DrrActionsBtnKey.FEEDBACK_ADVISE],
  [7, DrrActionsBtnKey.REQUEST_MEETING],
  [8, DrrActionsBtnKey.CONFIRM],
  [9, DrrActionsBtnKey.REQUEST_ADDITIONAL],
  // [10, DrrActionsBtnKey.FINISH_REVIEW], // BE define finish review
  [10, DrrActionsBtnKey.DONE],
  // [11, DrrActionsBtnKey.REQUEST_EVALUATE],
  // [12, DrrActionsBtnKey.FEEDBACK_EVALUATE],
  // [13, DrrActionsBtnKey.LC_FEEDBACK],
  // [14, DrrActionsBtnKey.FINISH_EVALUATE],
  // [15, DrrActionsBtnKey.SIGN_REQUEST],
  // [16, DrrActionsBtnKey.APPROVE_SIGN],
  [17, DrrActionsBtnKey.REQUEST_TIME_EXTENSION],
  // [18, DrrActionsBtnKey.REQUEST_TIME_EXTENSION],
  [19, DrrActionsBtnKey.SEND_MAIL],
  [20, DrrActionsBtnKey.REQUEST_VENDOR],
  [21, DrrActionsBtnKey.FEEDBACK],
  [22, DrrActionsBtnKey.RECALL],
  // [11, DrrActionsBtnKey.RECALL],
  // [6, DrrActionsBtnKey.FORWARD],
  // [19, DrrActionsBtnKey.FEEDBACK],
  // [13, DrrActionsBtnKey.REQUEST_MEETING],
  // [12, DrrActionsBtnKey.SEND_MAIL],
  // [9, DrrActionsBtnKey.REQUEST_TIME_EXTENSION],
  // [20, DrrActionsBtnKey.CONFIRM],
  // [5, DrrActionsBtnKey.ASSIGNMENT],
  // [15, DrrActionsBtnKey.REQUEST_VENDOR],
  // [4, DrrActionsBtnKey.FEEDBACK_ADVISE],
  // [7, DrrActionsBtnKey.REQUEST_ADDITIONAL],
  // [3, DrrActionsBtnKey.ADVISE],
  // [16, DrrActionsBtnKey.ADVISE],
  // [10, DrrActionsBtnKey.DONE],
  // [0, DrrActionsBtnKey.NOT_AVAILABLE],
  [23, DrrActionsBtnKey.RECHECK],
  [24, DrrActionsBtnKey.UNKNOWN_24],
]);

export const DrrUserRoleKey = {
  PIC: "PIC",
  L_C: "L_C",
  HEAD_OF_L_C: "HEAD_OF_L_C",
  SUPERVISOR: "SUPERVISOR",
  RELATED_PERSON: "RELATED_PERSON",
  FORWARD: "FORWARD",
  VIEWER: "VIEWER",
  SIGNER: "SIGNER",
};

export const DrrUserRole: Map<string, number> = new Map([
  [DrrUserRoleKey.PIC, 1],
  [DrrUserRoleKey.L_C, 2],
  [DrrUserRoleKey.HEAD_OF_L_C, 3],
  [DrrUserRoleKey.SUPERVISOR, 4],
  [DrrUserRoleKey.RELATED_PERSON, 5],
  [DrrUserRoleKey.VIEWER, 6],
  [DrrUserRoleKey.FORWARD, 7],
  [DrrUserRoleKey.SIGNER, 8],
]);
