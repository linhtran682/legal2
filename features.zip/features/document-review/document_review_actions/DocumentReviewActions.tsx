import { IconAdvise } from "@/assets/iconMenu/IconAdvise";
import { IconAssignment } from "@/assets/iconMenu/IconAssignment";
import { IconConfirm } from "@/assets/iconMenu/IconConfirm";
import IconCopy from "@/assets/iconMenu/IconCopy";
import { IconDone } from "@/assets/iconMenu/IconDone";
import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";
import { IconFeedback } from "@/assets/iconMenu/IconFeedback";
import { IconFeedbackAdvise } from "@/assets/iconMenu/IconFeedbackAdvise";
import { IconForward } from "@/assets/iconMenu/IconForward";
import { IconRecall } from "@/assets/iconMenu/IconRecall";
import { IconRequestAdditional } from "@/assets/iconMenu/IconRequestAdditional";
import { IconRequestMeeting } from "@/assets/iconMenu/IconRequestMeeting";
import { IconRequestVendor } from "@/assets/iconMenu/IconRequestVendor";
import { IconSendMail } from "@/assets/iconMenu/IconSendMail";
import IconShare from "@/assets/iconMenu/IconShare";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";
import {
  ActionButtonCustom,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButtonCustom";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { COLOR_TYPE } from "@/constants/color";
import { DocumentReviewBodyReceive, DocumentReviewStatusList, DONE_STATUS, DrrmRoles, LCS_DONE_STATUS } from "@/models/document-review/DocumentReviewDetail";
import { TypeActionsRole } from "@/models/law_document/LawDocument";
import AddTaskIcon from '@mui/icons-material/AddTask';
import { useTranslation } from "react-i18next";
import { DrrActionsBtnKey, DrrActionsBtnR, DrrUserRole, DrrUserRoleKey } from "./constants";

type TypeActionRole = {
  typeBtn: string;
  disable?: boolean;
};

type TypePropsDocumentReviewActions = {
  params: { row: DocumentReviewBodyReceive };
  isActionDetail?: boolean;
  handleClickRecall?: () => void;
  handleClickForWard?: () => void;
  handleClickFeedBack?: () => void;
  handleClickRequestMeeting?: () => void;
  handleClickSendMail?: () => void;
  handleClickExtendTime?: () => void;
  handleClickConfirm?: () => void;
  handleClickAssignment?: () => void;
  handleClickRequestVendor?: () => void;
  handleClickFeedbackAdvise?: () => void;
  handleClickRequestAdditional?: () => void;
  handleClickAdvise?: () => void;
  handleClickDone?: () => void;
  handleClickShare?: () => void;
  handleClickRecheck?: () => void;
  handleClickAddInfo?: () => void;
};

const uniqueCheck = (checkData: TypeActionRole[]) => {
  return checkData.reduce(
    (accumulator: TypeActionRole[], currentValue: TypeActionRole) => {
      const existing = accumulator.find(
        (item) => item.typeBtn === currentValue.typeBtn
      );

      if (existing) {
        if (Boolean(existing?.disable) === Boolean(currentValue?.disable)) {
          accumulator = accumulator.filter(
            (item) => item.typeBtn !== currentValue.typeBtn
          );
          accumulator.push(currentValue);
        } else {
          const indexAcc = accumulator.findIndex(
            (item: TypeActionRole) => item.typeBtn === currentValue.typeBtn
          );
          accumulator.splice(indexAcc, 1, { ...currentValue, disable: false });
        }
      } else {
        accumulator.push(currentValue);
      }

      return accumulator;
    },
    []
  );
};

const authorizedActionMapCallBack = (legalAdviceActions: TypeActionsRole[], params: {
  row: DocumentReviewBodyReceive
},
  isDetail: boolean = false) => {
  const listItemActionPicReviewDone = [
    {
      typeBtn: DrrActionsBtnKey.SHARE,
    },
  ];
  const listItemActionPicDone = [
    {
      typeBtn: DrrActionsBtnKey.RECHECK,
    },
    {
      typeBtn: DrrActionsBtnKey.SHARE,
    },
  ];
  let roleList = [];
  if (params?.row?.userLastActionAndRoleResponse?.userLastActionAndRoleList?.length) {
    const { userLastActionAndRoleResponse: { userLastActionAndRoleList } } = params?.row;
    roleList = userLastActionAndRoleList?.map((ele: any) => ele.role)
  }

  if (params?.row?.status?.name === DONE_STATUS || params?.row?.lcsStatus === LCS_DONE_STATUS) {
    return roleList.includes(DrrmRoles.PIC)
      ? listItemActionPicDone
      : (
        roleList.includes(DrrmRoles.HEAD_OF_L_C)
          || roleList.includes(DrrmRoles.L_C)
          || roleList.includes(DrrmRoles.SUPERVISOR)
          ? listItemActionPicReviewDone
          : []);
  }
  if (params?.row?.status?.name === DocumentReviewStatusList.DONE_DOCUMENT_REVIEW || !!params?.row?.lcsId) {
    return roleList.includes(DrrmRoles.PIC)
      || roleList.includes(DrrmRoles.HEAD_OF_L_C)
      || roleList.includes(DrrmRoles.L_C)
      || roleList.includes(DrrmRoles.SUPERVISOR)
      ? listItemActionPicReviewDone : [];
  }
  const btnCondition = {
    [DrrActionsBtnKey.RECALL]:
      params?.row?.userLastActionAndRoleResponse
        ?.otherActionsAvailableFlag,
    [DrrActionsBtnKey.FEEDBACK]:
      params?.row?.userLastActionAndRoleResponse
        ?.otherActionsAvailableFlag,
    [DrrActionsBtnKey.REQUEST_TIME_EXTENSION]:
      params?.row?.userLastActionAndRoleResponse
        ?.requestTimeExtensionAvailableFlag,
    [DrrActionsBtnKey.FEEDBACK_ADVISE]:
      [DocumentReviewStatusList.DONE_REVIEW,
      DocumentReviewStatusList.REVIEW_FEEDBACK]
        ?.includes(params?.row?.status?.name as DocumentReviewStatusList),
    [DrrActionsBtnKey.DONE]:
      [DocumentReviewStatusList.DONE_REVIEW]
        ?.includes(params?.row?.status?.name as DocumentReviewStatusList),
    [DrrActionsBtnKey.INFO_ADDED]:
      [DocumentReviewStatusList.REQUEST_INFORMATION]
        ?.includes(params?.row?.status?.name as DocumentReviewStatusList) && isDetail,
    [DrrActionsBtnKey.REQUEST_ADDITIONAL]:
      [DocumentReviewStatusList.DONE_REVIEW,
      DocumentReviewStatusList.SUPERVISOR_REVIEWED,
      DocumentReviewStatusList.SENT_TO_SUPERVISOR]
        ?.includes(params?.row?.status?.name as DocumentReviewStatusList),
    [DrrActionsBtnKey.REQUEST_VENDOR]:
      [DocumentReviewStatusList.DONE_REVIEW,
      DocumentReviewStatusList.SUPERVISOR_REVIEWED,
      DocumentReviewStatusList.SENT_TO_SUPERVISOR]
        ?.includes(params?.row?.status?.name as DocumentReviewStatusList),
    [DrrActionsBtnKey.CONFIRM]:
      !!params?.row?.confirmFlag,
  };

  const listItemActionsPic = [
    ...(!!btnCondition[DrrActionsBtnKey.INFO_ADDED] ? [{
      typeBtn: DrrActionsBtnKey.INFO_ADDED,
    }] : []),
    { typeBtn: DrrActionsBtnKey.FORWARD },
    {
      typeBtn: DrrActionsBtnKey.RECALL,
    },
    {
      typeBtn: DrrActionsBtnKey.FEEDBACK,
      disable: !btnCondition[DrrActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: DrrActionsBtnKey.REQUEST_MEETING },
    { typeBtn: DrrActionsBtnKey.SEND_MAIL },
    // {
    //   typeBtn: DrrActionsBtnKey.REQUEST_TIME_EXTENSION,
    //   disable: !btnCondition[DrrActionsBtnKey.REQUEST_TIME_EXTENSION],
    // },
    {
      typeBtn: DrrActionsBtnKey.FEEDBACK_ADVISE,
      disable: !btnCondition[DrrActionsBtnKey.FEEDBACK_ADVISE],
    },
    {
      typeBtn: DrrActionsBtnKey.DONE,
      disable: !btnCondition[DrrActionsBtnKey.DONE],
    },
    {
      typeBtn: DrrActionsBtnKey.SHARE,
    },
  ];

  const listItemActionsForWard = [
    { typeBtn: DrrActionsBtnKey.FORWARD },
    {
      typeBtn: DrrActionsBtnKey.RECALL,
    },
    ...(!btnCondition[DrrActionsBtnKey.FEEDBACK]
      ? [
        {
          typeBtn: DrrActionsBtnKey.FEEDBACK,
        },
      ]
      : []),
  ];

  const listItemActionsLcAndHeadLc = [
    { typeBtn: DrrActionsBtnKey.FORWARD },
    { typeBtn: DrrActionsBtnKey.RECALL },
    {
      typeBtn: DrrActionsBtnKey.FEEDBACK,
      disable: !btnCondition[DrrActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: DrrActionsBtnKey.REQUEST_MEETING },
    { typeBtn: DrrActionsBtnKey.SEND_MAIL },
    { typeBtn: DrrActionsBtnKey.REQUEST_TIME_EXTENSION },
    {
      typeBtn: DrrActionsBtnKey.CONFIRM,
      disable: btnCondition[DrrActionsBtnKey.CONFIRM],
    },
    { typeBtn: DrrActionsBtnKey.ASSIGNMENT },
    {
      typeBtn: DrrActionsBtnKey.REQUEST_VENDOR,
      disable: btnCondition[DrrActionsBtnKey.REQUEST_VENDOR],
    },
    {
      typeBtn: DrrActionsBtnKey.REQUEST_ADDITIONAL,
      disable: btnCondition[DrrActionsBtnKey.REQUEST_ADDITIONAL],
    },
    { typeBtn: DrrActionsBtnKey.ADVISE },
    {
      typeBtn: DrrActionsBtnKey.SHARE,
    },
  ];

  const listItemActionsSupervisor = [
    { typeBtn: DrrActionsBtnKey.RECALL },
    { typeBtn: DrrActionsBtnKey.FORWARD },
    {
      typeBtn: DrrActionsBtnKey.FEEDBACK,
      disable: !btnCondition[DrrActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: DrrActionsBtnKey.REQUEST_MEETING },
    { typeBtn: DrrActionsBtnKey.REQUEST_TIME_EXTENSION },
    { typeBtn: DrrActionsBtnKey.ADVISE },
    {
      typeBtn: DrrActionsBtnKey.SHARE,
    },
  ];

  const listItemActionsRelatedPerson = [
    {
      typeBtn: DrrActionsBtnKey.RECALL,
      disable: !!btnCondition[DrrActionsBtnKey.DONE],
    },
    {
      typeBtn: DrrActionsBtnKey.FORWARD,
      disable: !!btnCondition[DrrActionsBtnKey.DONE],
    },
    {
      typeBtn: DrrActionsBtnKey.FEEDBACK,
      disable: !!btnCondition[DrrActionsBtnKey.DONE],
    },
  ];

  const listActionsPic = {
    [DrrActionsBtnKey.CREATE_NEW]: [
      ...(!!btnCondition[DrrActionsBtnKey.INFO_ADDED] ? [{
        typeBtn: DrrActionsBtnKey.INFO_ADDED,
      }] : []),
      { typeBtn: DrrActionsBtnKey.FORWARD },
      {
        typeBtn: DrrActionsBtnKey.RECALL,
      },
      {
        typeBtn: DrrActionsBtnKey.FEEDBACK,
        disable: !btnCondition[DrrActionsBtnKey.FEEDBACK],
      },
      // { typeBtn: DrrActionsBtnKey.REQUEST_MEETING },
      { typeBtn: DrrActionsBtnKey.SEND_MAIL },
      {
        typeBtn: DrrActionsBtnKey.FEEDBACK_ADVISE,
        disable: !btnCondition[DrrActionsBtnKey.FEEDBACK_ADVISE],
      },
      {
        typeBtn: DrrActionsBtnKey.DONE,
        disable: !btnCondition[DrrActionsBtnKey.DONE],
      },
      {
        typeBtn: DrrActionsBtnKey.SHARE,
      },
    ],
    [DrrActionsBtnKey.RECHECK]: [
      ...(!!btnCondition[DrrActionsBtnKey.INFO_ADDED] ? [{
        typeBtn: DrrActionsBtnKey.INFO_ADDED,
      }] : []),
      { typeBtn: DrrActionsBtnKey.FORWARD },
      {
        typeBtn: DrrActionsBtnKey.RECALL,
      },
      ...(!btnCondition[DrrActionsBtnKey.FEEDBACK]
        ? [
          {
            typeBtn: DrrActionsBtnKey.FEEDBACK,
            disable: true,
          },
        ]
        : []),
      // { typeBtn: DrrActionsBtnKey.REQUEST_MEETING },
      { typeBtn: DrrActionsBtnKey.SEND_MAIL },
      {
        typeBtn: DrrActionsBtnKey.FEEDBACK_ADVISE,
        disable: !btnCondition[DrrActionsBtnKey.FEEDBACK_ADVISE],
      },
      {
        typeBtn: DrrActionsBtnKey.DONE,
        disable: !btnCondition[DrrActionsBtnKey.DONE],
      },
      {
        typeBtn: DrrActionsBtnKey.SHARE,
      },
    ],
    [DrrActionsBtnKey.RECALL]: [
      ...(!!btnCondition[DrrActionsBtnKey.INFO_ADDED] ? [{
        typeBtn: DrrActionsBtnKey.INFO_ADDED,
      }] : []),
      { typeBtn: DrrActionsBtnKey.FORWARD },
      {
        typeBtn: DrrActionsBtnKey.RECALL,
      },
      ...(!btnCondition[DrrActionsBtnKey.FEEDBACK]
        ? [
          {
            typeBtn: DrrActionsBtnKey.FEEDBACK,
            disable: true,
          },
        ]
        : []),
      // { typeBtn: DrrActionsBtnKey.REQUEST_MEETING },
      { typeBtn: DrrActionsBtnKey.SEND_MAIL },
      ...(!btnCondition[DrrActionsBtnKey.REQUEST_TIME_EXTENSION]
        ? [
          {
            typeBtn: DrrActionsBtnKey.REQUEST_TIME_EXTENSION,
            disable: true,
          },
        ]
        : []),
      {
        typeBtn: DrrActionsBtnKey.FEEDBACK_ADVISE,
        disable: !btnCondition[DrrActionsBtnKey.FEEDBACK_ADVISE],
      },
      ...(!btnCondition[DrrActionsBtnKey.DONE]
        ? [
          {
            typeBtn: DrrActionsBtnKey.DONE,
            disable: true,
          },
        ]
        : []),
      {
        typeBtn: DrrActionsBtnKey.SHARE,
      },
    ],
    [DrrActionsBtnKey.FORWARD]: listItemActionsPic,
    [DrrActionsBtnKey.FEEDBACK]: listItemActionsPic,
    // [DrrActionsBtnKey.REQUEST_MEETING]: listItemActionsPic,
    [DrrActionsBtnKey.SEND_MAIL]: listItemActionsPic,
    [DrrActionsBtnKey.REQUEST_TIME_EXTENSION]: listItemActionsPic,
    [DrrActionsBtnKey.FEEDBACK_ADVISE]: listItemActionsPic,
    // [DrrActionsBtnKey.DONE]: [
    //   { typeBtn: DrrActionsBtnKey.FORWARD },
    //   {
    //     typeBtn: DrrActionsBtnKey.RECALL,
    //   },
    //   ...(!btnCondition[DrrActionsBtnKey.FEEDBACK]
    //     ? [
    //         {
    //           typeBtn: DrrActionsBtnKey.FEEDBACK,
    //           disable: true,
    //         },
    //       ]
    //     : []),
    //   { typeBtn: DrrActionsBtnKey.REQUEST_MEETING },
    //   { typeBtn: DrrActionsBtnKey.SEND_MAIL },
    //   {
    //     typeBtn: DrrActionsBtnKey.FEEDBACK_ADVISE,
    //     disable: !btnCondition[DrrActionsBtnKey.FEEDBACK_ADVISE],
    //   },
    //   {
    //     typeBtn: DrrActionsBtnKey.DONE,
    //     disable: !btnCondition[DrrActionsBtnKey.DONE],
    //   },
    // ],
    [DrrActionsBtnKey.DONE]: listItemActionsPic?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: listItemDefault.typeBtn !== DrrActionsBtnKey.SHARE,
      })
    ),
    [DrrActionsBtnKey.NOT_AVAILABLE]: listItemActionsPic,
    [DrrActionsBtnKey.UNKNOWN_24]: listItemActionsPic,
    [DrrActionsBtnKey.CONFIRM]: listItemActionsPic,
  };

  const listActionsLcAndHeadLc = {
    [DrrActionsBtnKey.RECALL]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.FORWARD]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.FEEDBACK]: listItemActionsLcAndHeadLc,
    // [DrrActionsBtnKey.REQUEST_MEETING]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.SEND_MAIL]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.REQUEST_TIME_EXTENSION]:
      listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.CONFIRM]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.ASSIGNMENT]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.REQUEST_VENDOR]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.REQUEST_ADDITIONAL]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.ADVISE]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.NOT_AVAILABLE]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.UNKNOWN_24]: listItemActionsLcAndHeadLc,
    [DrrActionsBtnKey.DONE]: listItemActionsLcAndHeadLc?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
  };

  const listActionsSupervisor = {
    [DrrActionsBtnKey.RECALL]: listItemActionsSupervisor,
    [DrrActionsBtnKey.FORWARD]: listItemActionsSupervisor,
    [DrrActionsBtnKey.FEEDBACK]: listItemActionsSupervisor,
    [DrrActionsBtnKey.REQUEST_TIME_EXTENSION]:
      listItemActionsSupervisor,
    // [DrrActionsBtnKey.REQUEST_MEETING]: listItemActionsSupervisor,
    [DrrActionsBtnKey.ADVISE]: listItemActionsSupervisor,
    [DrrActionsBtnKey.NOT_AVAILABLE]: listItemActionsSupervisor,
    [DrrActionsBtnKey.UNKNOWN_24]: listItemActionsSupervisor,
    [DrrActionsBtnKey.DONE]: listItemActionsSupervisor?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
  };
  const listActionsRelatedPerson = {
    [DrrActionsBtnKey.NOT_AVAILABLE]: listItemActionsRelatedPerson,
    [DrrActionsBtnKey.FORWARD]: listItemActionsRelatedPerson,
    [DrrActionsBtnKey.RECALL]: listItemActionsRelatedPerson,
    [DrrActionsBtnKey.FEEDBACK]: listItemActionsRelatedPerson,
    [DrrActionsBtnKey.DONE]: listItemActionsRelatedPerson?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
  }
  const listActionsForWard = {
    [DrrActionsBtnKey.FORWARD]: listItemActionsForWard,
    [DrrActionsBtnKey.RECALL]: listItemActionsForWard,
    [DrrActionsBtnKey.FEEDBACK]: listItemActionsForWard,
    [DrrActionsBtnKey.DONE]: listItemActionsForWard?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
    [DrrActionsBtnKey.NOT_AVAILABLE]: [
      { typeBtn: DrrActionsBtnKey.FORWARD },
      {
        typeBtn: DrrActionsBtnKey.RECALL,
      },
      {
        typeBtn: DrrActionsBtnKey.FEEDBACK,
      }
    ],
  };
  const authorizedActionMap = new Map<number | string, any>([
    [DrrUserRole.get(DrrUserRoleKey.PIC)!, listActionsPic],
    [
      DrrUserRole.get(DrrUserRoleKey.L_C)!,
      listActionsLcAndHeadLc,
    ],
    [
      DrrUserRole.get(DrrUserRoleKey.HEAD_OF_L_C)!,
      listActionsLcAndHeadLc,
    ],
    [
      DrrUserRole.get(DrrUserRoleKey.SUPERVISOR)!,
      listActionsSupervisor,
    ],
    [
      DrrUserRole.get(DrrUserRoleKey.RELATED_PERSON)!,
      listActionsRelatedPerson,
    ],
    [
      DrrUserRole.get(DrrUserRoleKey.FORWARD)!,
      listActionsForWard,
    ],
    [DrrUserRole.get(DrrUserRoleKey.VIEWER)!, []],
    [DrrUserRole.get(DrrUserRoleKey.SIGNER)!, []],
  ]);
  let listActionAuthorizedMap: TypeActionRole[] = [];
  legalAdviceActions.forEach((legalDocumentItemAction: any) => {
    const authorizedAction =
      authorizedActionMap?.get(legalDocumentItemAction?.role)?.[
      DrrActionsBtnR.get(
        legalDocumentItemAction?.lastAction
      ) as string
      ] || [];
    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });
  return uniqueCheck(listActionAuthorizedMap);
};

export const DocumentReviewActions = (
  props: TypePropsDocumentReviewActions
) => {
  const {
    params,
    isActionDetail = false,
    handleClickRecall = () => { },
    handleClickForWard = () => { },
    handleClickFeedBack = () => { },
    handleClickRequestMeeting = () => { },
    handleClickSendMail = () => { },
    handleClickExtendTime = () => { },
    handleClickConfirm = () => { },
    handleClickAssignment = () => { },
    handleClickRequestVendor = () => { },
    handleClickFeedbackAdvise = () => { },
    handleClickRequestAdditional = () => { },
    handleClickAdvise = () => { },
    handleClickDone = () => { },
    handleClickRecheck = () => { },
    handleClickShare = () => { },
    handleClickAddInfo = () => { },
  } = props;
  const [t] = useTranslation();
  const styleBtn = { background: COLOR_TYPE.TOYOTA.TOYOTA1, color: COLOR_TYPE.TOYOTA.TOYOTA8 }
  const buttonMap = new Map<string, ActionButtonItem>([
    [
      DrrActionsBtnKey.RECALL,
      {
        key: DrrActionsBtnKey.RECALL,
        icon: <IconRecall />,
        iconDisable: <IconRecall color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.RECALL}`),
        onClick: handleClickRecall,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.RECALL}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `legalAdvice.recallLegalAdvice.message.confirm_${DrrActionsBtnKey.RECALL}`
          ),
        },
        styleBtn,
        secondaryBtn: 1,
      },
    ],
    [
      DrrActionsBtnKey.FORWARD,
      {
        key: DrrActionsBtnKey.FORWARD,
        icon: <IconForward />,
        iconDisable: <IconForward color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.FORWARD}`),
        onClick: handleClickForWard,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.FORWARD}`
        ),
        styleBtn,
        secondaryBtn: 3,
      },
    ],
    [
      DrrActionsBtnKey.FEEDBACK,
      {
        key: DrrActionsBtnKey.FEEDBACK,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.FEEDBACK}`),
        onClick: handleClickFeedBack,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.FEEDBACK}`
        ),
        styleBtn,
        secondaryBtn: 4,
      },
    ],
    [
      DrrActionsBtnKey.REQUEST_MEETING,
      {
        key: DrrActionsBtnKey.REQUEST_MEETING,
        icon: <IconRequestMeeting />,
        iconDisable: <IconRequestMeeting color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_MEETING}`
        ),
        onClick: handleClickRequestMeeting,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_MEETING}`
        ),
        styleBtn,
        secondaryBtn: 5,
      },
    ],
    [
      DrrActionsBtnKey.SEND_MAIL,
      {
        key: DrrActionsBtnKey.SEND_MAIL,
        icon: <IconSendMail />,
        iconDisable: <IconSendMail color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.SEND_MAIL}`),
        onClick: handleClickSendMail,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.SEND_MAIL}`
        ),
        styleBtn,
        secondaryBtn: 2,
      },
    ],
    [
      DrrActionsBtnKey.REQUEST_TIME_EXTENSION,
      {
        key: DrrActionsBtnKey.REQUEST_TIME_EXTENSION,
        icon: <IconExtendDeadline />,
        iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_TIME_EXTENSION}`
        ),
        onClick: handleClickExtendTime,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_TIME_EXTENSION}`
        ),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      DrrActionsBtnKey.CONFIRM,
      {
        key: DrrActionsBtnKey.CONFIRM,
        icon: <IconConfirm />,
        iconDisable: <IconConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.CONFIRM}`),
        onClick: handleClickConfirm,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.CONFIRM}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `legalAdvice.confirmLegalAdvice.message.confirm_done`
          ),
        },
        styleBtn
      },
    ],
    [
      DrrActionsBtnKey.ASSIGNMENT,
      {
        key: DrrActionsBtnKey.ASSIGNMENT,
        icon: <IconAssignment />,
        iconDisable: <IconAssignment color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.ASSIGNMENT}`),
        onClick: handleClickAssignment,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.ASSIGNMENT}`
        ),
        styleBtn
      },
    ],
    [
      DrrActionsBtnKey.REQUEST_VENDOR,
      {
        key: DrrActionsBtnKey.REQUEST_VENDOR,
        icon: <IconRequestVendor />,
        iconDisable: <IconRequestVendor color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_VENDOR}`
        ),
        onClick: handleClickRequestVendor,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_VENDOR}`
        ),
        styleBtn
      },
    ],
    [
      DrrActionsBtnKey.FEEDBACK_ADVISE,
      {
        key: DrrActionsBtnKey.FEEDBACK_ADVISE,
        icon: <IconFeedbackAdvise />,
        iconDisable: <IconFeedbackAdvise color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.FEEDBACK_ADVISE}`
        ),
        onClick: handleClickFeedbackAdvise,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.FEEDBACK_ADVISE}`
        ),
        styleBtn
      },
    ],
    [
      DrrActionsBtnKey.REQUEST_ADDITIONAL,
      {
        key: DrrActionsBtnKey.REQUEST_ADDITIONAL,
        icon: <IconRequestAdditional />,
        iconDisable: <IconRequestAdditional color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_ADDITIONAL}`
        ),
        onClick: handleClickRequestAdditional,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.REQUEST_ADDITIONAL}`
        ),
        styleBtn
      },
    ],
    [
      DrrActionsBtnKey.ADVISE,
      {
        key: DrrActionsBtnKey.ADVISE,
        icon: <IconAdvise />,
        iconDisable: <IconAdvise color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.ADVISE}`),
        onClick: handleClickAdvise,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.ADVISE}`
        ),
        styleBtn
      },
    ],
    [
      DrrActionsBtnKey.DONE,
      {
        key: DrrActionsBtnKey.DONE,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.DONE}Review`),
        onClick: handleClickDone,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.DONE}`
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
      },
    ],
    [
      DrrActionsBtnKey.SHARE,
      {
        key: DrrActionsBtnKey.SHARE,
        icon: <IconShare />,
        iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${DrrActionsBtnKey.SHARE}`),
        onClick: handleClickShare,
        tooltipTitle: t(
          `legalAdvice.button.${DrrActionsBtnKey.SHARE}`
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        secondaryBtn: 7,
      },
    ],
    [
      DrrActionsBtnKey.RECHECK,
      {
        key: DrrActionsBtnKey.RECHECK,
        icon: <IconCopy />,
        iconDisable: <IconCopy color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${DrrActionsBtnKey.RECHECK}Review`),
        onClick: handleClickRecheck,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${DrrActionsBtnKey.RECHECK}Review`
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
      },
    ],
    [
      DrrActionsBtnKey.INFO_ADDED,
      {
        key: DrrActionsBtnKey.INFO_ADDED,
        icon: <AddTaskIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA1 }} />,
        iconDisable: <AddTaskIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA5 }} />,
        textBtn: t('DOCUMENT_REVIEW.button.infoAdded'),
        onClick: handleClickAddInfo,
        tooltipTitle: t(
          'DOCUMENT_REVIEW.buttons.infoAdded'
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `DOCUMENT_REVIEW.messages.infoAddedConfirm`
          ),
        },
      },
    ]
  ])
  if (isActionDetail)
    return (
      <ActionButtonDetail
        params={params}
        actionButtonItems={authorizedActionMapCallBack(
          params?.row?.userLastActionAndRoleResponse
            ?.userLastActionAndRoleList
          // ?.map((item) => ({
          //   ownerAction: item.lastAction,
          //   ownerRole: item.role
          // })) 
          ?? [],
          params,
          true
        )?.map((buttons: TypeActionRole) => ({
          ...buttonMap.get(buttons?.typeBtn)!,
          disable: buttons?.disable,
        }))}
      />
    );

  return (
    <ActionButtonCustom
      params={params}
      actionButtonItems={authorizedActionMapCallBack(
        params?.row?.userLastActionAndRoleResponse
          ?.userLastActionAndRoleList
        ?? [],
        params
      )?.map((buttons: TypeActionRole) => ({
        ...buttonMap.get(buttons?.typeBtn)!,
        disable: buttons?.disable,
      }))}
      listActions={
        props?.params?.row?.userLastActionAndRoleResponse
          ?.userLastActionAndRoleList
        ?? []
      }
    />
  );
};
