import { COLOR_TYPE } from '@/constants/color'
import { IconButton } from '@mui/material'
import React from 'react'
import AddIcon from "@mui/icons-material/Add";


interface AddItemButtonProps {
  onClick?: () => void;
  mt?: number;
  id?: string;
}

const AddItemButton = (props: AddItemButtonProps) => {
  const { onClick, mt = 2, id } = props;
  return (
    <IconButton
      id={id}
      sx={{
        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
        mt: mt,
        color: "white",
        borderRadius: "50%",
        "&:hover": {
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
        },
        "&:focus, &:focus-visible": {
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
        },
      }}
      onClick={onClick}
    >
      <AddIcon
        fontSize='small'
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
          color: "white",
          borderRadius: "50%",
        }}
      />
    </IconButton>
  )
}

export default AddItemButton