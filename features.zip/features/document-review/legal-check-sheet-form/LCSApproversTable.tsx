import { getUser, getUsers } from '@/apis/service/user/User';
import { FormAsyncSelect } from '@/components/commons/form_inputs/FormAsyncSelect';
import { FormTextField } from '@/components/commons/form_inputs/FormTextField';
import { COLOR_TYPE } from '@/constants/color';
import { useAppContext } from '@/context/AppContext';
import { GetUsersParams, UserProfileDTO } from '@/models/user/User';
import { formatDate } from '@/utils';
import ArrowDownwardRounded from '@mui/icons-material/ArrowDownwardRounded';
import ArrowUpwardRoundedIcon from '@mui/icons-material/ArrowUpwardRounded';
import CheckRoundedIcon from '@mui/icons-material/CheckRounded';
import DragHandleIcon from '@mui/icons-material/DragHandle';
import EditNoteRoundedIcon from '@mui/icons-material/EditNoteRounded';
import RemoveCircleOutlineOutlinedIcon from '@mui/icons-material/RemoveCircleOutlineOutlined';
import { Box, FormHelperText, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { ReactNode, useCallback, useEffect, useState } from 'react';
import { useFieldArray, useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
// import AddItemButton from './AddItemButton';

interface LCSApproverTableColumn {
  key: string;
  label: string;
  type: "string" | "number" | "date" | "bool" | "action" | "select";
  width?: string;
  align?: 'left' | 'center' | 'right';
  renderCell?: (params?: any, index?: number) => ReactNode;
  editable?: boolean;
}

interface LCSApproversTableProps {
  control: any;
  checkSheetIndex: number;
  disabled?: boolean;
}
const LCSApproversTable = (props: LCSApproversTableProps) => {
  const { checkSheetIndex, control, disabled } = props;
  const { t } = useTranslation();
  // const [dragOverId, setDragOverId] = useState<string>('');
  const [editRowId, setEditRowId] = useState<number>(-1);
  const appContext = useAppContext();

  const { getValues, formState, watch, clearErrors } = useFormContext()
  const signerFields = useFieldArray({
    name: `legalCheckSheetToBeSigned.${checkSheetIndex}.signers`,
    control: control,
    keyName: "rowId"
  });


  const removeApprover = (approverIndex: number) => {
    setEditRowId(-1);
    signerFields.remove(approverIndex);
  }

  const watchSigners = watch(`legalCheckSheetToBeSigned.${checkSheetIndex}.signers`);
  useEffect(() => {
    const validSigners = !!watchSigners?.[0]?.signerId && // Position 1 (index 0)
      !!watchSigners?.[1]?.signerId && // Position 2 (index 1)
      !!watchSigners?.[4]?.signerId && // Position 5 (index 4)
      !!watchSigners?.[5]?.signerId && // Position 6 (index 5)
      !!watchSigners?.[6]?.signerId; // Position 7 (index 6)

    if (validSigners) {
      clearErrors(`legalCheckSheetToBeSigned.${checkSheetIndex}.signers`);
    }


  }, [watchSigners]);

  const [columns] = useState<LCSApproverTableColumn[]>([
    {
      key: "move",
      label: "DOCUMENT_REVIEW.field_name.move",
      type: "string",
      width: '90px',
      align: 'center',
    },
    {
      key: "id",
      label: "DOCUMENT_REVIEW.field_name.step",
      type: "string",
      width: '50px',
      align: 'center',
      renderCell: (params) => {
        return <span>{params.index + 1}</span>
      }
    },
    {
      key: "name",
      label: "DOCUMENT_REVIEW.field_name.approvers",
      type: "string",
      width: '300px',
      editable: true
    },
    {
      key: "department",
      label: "DOCUMENT_REVIEW.field_name.department",
      type: "string",
      width: '240px',
    },
    {
      key: "position",
      label: "DOCUMENT_REVIEW.field_name.position",
      type: "string",
      width: '150px',
    },
    {
      key: "date",
      label: "DOCUMENT_REVIEW.field_name.processDate",
      type: "string",
      width: '200px',
      editable: true
    },
    {
      key: "status",
      label: "DOCUMENT_REVIEW.labels.status",
      type: "string",
      width: '180px',
    },
    {
      key: "note",
      label: "DOCUMENT_REVIEW.field_name.note",
      type: "string",
      width: '300px',
      editable: true
    },
    {
      key: "action",
      label: "",
      type: "string",
      width: '70px',
      renderCell: (params, index) => <Box sx={{
        width: '100%',
        height: "100%",
        display: 'flex',
        // justifyContent: "space-between",
        alignItems: 'center'
      }}>
        <IconButton>
          <EditNoteRoundedIcon fontSize="small" />
        </IconButton>
        <IconButton onClick={() => removeApprover(index!)}>
          <RemoveCircleOutlineOutlinedIcon fontSize="small" />
        </IconButton>
      </Box>

    },
  ])

  const handleMoveRow = (rowIndex: number, dir: 'up' | 'down') => {

    if ((rowIndex === 0 && dir === 'up')
      || (rowIndex === signerFields.fields.length - 1 && dir === 'down')) {
      return;
    }
    setEditRowId(-1);
    if (dir === 'up') {
      signerFields.swap(rowIndex, rowIndex - 1)
    }
    if (dir === 'down') {
      signerFields.swap(rowIndex, rowIndex + 1)
    }
  }

  const firstSigner = watch(`legalCheckSheetToBeSigned.${checkSheetIndex}.signers.0`);

  const getExcludedIds = useCallback((index: number): any[] => {
    const list: any = [];
    const firstSignerId = firstSigner?.signerId;
    const myId = appContext?.me?.id
    if (!!myId && myId !== firstSignerId && index !== 0) {
      list.push(myId);
    }
    return list;
  }, [firstSigner, appContext?.me])

  const onRowChange = async (selectedKey: any, option: any, rowIndex: number) => {
    signerFields.update(
      rowIndex,
      {
        ...signerFields.fields[rowIndex],
        signerId: selectedKey ?? null,
        name: option?.name ?? '',
        department: option?.department,
        position: option?.position,
      }
    );
    if (selectedKey !== appContext?.me?.id && rowIndex === 0) {
      signerFields?.fields?.forEach((row: any, index: number) => {
        if (!!row?.signerId && row?.signerId === appContext?.me?.id && index !== 0) {
          const dataUpdate = {
            ...row,
            name: null,
            department: null,
            signerId: null,
            user: null,
            status: null,
            processingDate: null,
            note: null,
          }
          signerFields.update(index, dataUpdate)
        }
      })
    }
  }


  const renderRowCell = (column: LCSApproverTableColumn, rowIndex: number) => {

    const currentField: any = signerFields?.fields?.[rowIndex];
    if (column.key === 'dragHandler') {
      return <DragHandleIcon fontSize='small' sx={{ cursor: 'move' }} />
    }
    if (column.key === 'id') {
      return rowIndex + 1
    }
    if (column.key === 'name') {
      return editRowId === rowIndex ?
        (<FormAsyncSelect<any, UserProfileDTO>
          control={control}
          name={`legalCheckSheetToBeSigned.${checkSheetIndex}.signers.${rowIndex}.signerId`}
          label={""}
          minCharLength={1}
          placeholder={t("DOCUMENT_REVIEW.field_name.approvers")}
          getOptions={async (keyword) => {
            const excludedIds = getExcludedIds(rowIndex);
            if (typeof keyword == "string") {
              const params: GetUsersParams = {
                searchTerm: keyword,
                page: 0,
                size: 100,
                sortBy: "name",
                sortOrder: "ASC",
              };
              const response = await getUsers(params);
              return response
                ?.users
                ?.filter((user) => !excludedIds.includes(user.id))
                ?? [];
            } else if (keyword?.length && keyword.length > 0) {
              return getUser(keyword[0])
                .then((response) => (response ? [response] : []))
                .catch(() => []);
            }

            return [];
          }}
          getOptionLabel={(option) =>
            `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? ""
            }`
          }
          onChange={(selectedKey, option) => onRowChange(selectedKey, option, rowIndex)}
          getOptionKey={(option) => option.id}
          keyQuery={`lcs/approver/queryUser-${currentField?.rowId}`}
          isFocus={true}
          disabled={editRowId !== rowIndex}
        />)
        : currentField?.name
    }
    if (column.key === 'note') {
      return editRowId === rowIndex ? (
        <FormTextField
          control={control}
          name={`legalCheckSheetToBeSigned.${checkSheetIndex}.signers.${rowIndex}.note`}
          label={""}
          placeHolder={t('DOCUMENT_REVIEW.field_name.note')}
          disabled={editRowId !== rowIndex}
        />
      )
        : getValues(`legalCheckSheetToBeSigned.${checkSheetIndex}.signers.${rowIndex}.note`)
    }
    if (column.key === 'date') {
      const dateField = `legalCheckSheetToBeSigned.${checkSheetIndex}.signers.${rowIndex}.date`
      // return editRowId === rowIndex ? (
      //   <DateInput
      //     control={control}
      //     name={`legalCheckSheetToBeSigned.${checkSheetIndex}.signers.${rowIndex}.date`}
      //     isVisibleHidden={false}
      //     placeholder={'dd/mm/yyyy'}
      //     disabled={editRowId !== rowIndex}
      //   />
      // )
      //   : (!!getValues(dateField)
      //     ? formatDate(getValues(dateField)) : "")
      return (!!getValues(dateField)
        ? formatDate(getValues(dateField)) : "")
    }
    if (column.key === 'department') {
      return currentField?.department?.name
    }
    if (column.key === 'position') {
      return currentField?.position?.name
    }
    if (column.key === 'status') {
      return t(`DOCUMENT_REVIEW.signerStatus.${currentField?.status ?? 0}`)
    }
    if (column.key == 'action') {
      return <Box sx={{
        width: '100%',
        height: "100%",
        display: 'flex',
        justifyContent: "center",
        alignItems: 'center'
      }}>
        <IconButton disabled={disabled} onClick={() => setEditRowId(
          editRowId === rowIndex
            ? -1
            : rowIndex
        )}>
          {editRowId === rowIndex
            ? <CheckRoundedIcon fontSize="small" />
            : <EditNoteRoundedIcon fontSize="small" />
          }
        </IconButton>
        {/* <IconButton disabled={disabled} onClick={() => removeApprover(rowIndex!)}>
          <RemoveCircleOutlineOutlinedIcon fontSize="small" />
        </IconButton> */}
      </Box>
    }
    if (column.key == 'move') {
      return <Box sx={{
        width: '100%',
        height: "100%",
        display: 'flex',
        justifyContent: "center",
        alignItems: 'center'
      }}>
        <IconButton disabled={disabled} size='small' onClick={() => handleMoveRow(rowIndex, 'up')}>
          <ArrowUpwardRoundedIcon fontSize="small" />
        </IconButton>
        <IconButton disabled={disabled} size='small' onClick={() => handleMoveRow(rowIndex, 'down')}>
          <ArrowDownwardRounded fontSize="small" />
        </IconButton >
      </Box>
    }

    // return signerFields?.fields?.[rowIndex]?.[`${column.key}`] ?? ''
    return ''
  }

  const [draggedId, setDraggedId] = useState<any>(null);
  const onDragStart = (e: any, index: number) => {
    setDraggedId(index);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/html", e.target.parentNode);
    e.dataTransfer.setDragImage(e.target.parentNode, 20, 20);
  }
  // const onDragEnd = () => {
  //   setDraggedId(null);
  // }

  const onDragOver = (index: number) => {
    if (draggedId === index) {
      return;
    }
    signerFields.swap(draggedId, index)
    // const draggedOverItem = signerFields.fields?.[index];

    // // // if the item is dragged over itself, ignore
    // if (draggedItem.rowId === draggedOverItem.rowId) {
    //   return;
    // }

    // // // filter out the currently dragged item
    // let filteredItems = signerFields.fields.filter(item => item.rowId !== draggedItem.rowId);

    // // // add the dragged item after the dragged over item
    // filteredItems.splice(index, 0, draggedItem);



    // this.setState({ items });
  }

  const error = (formState.errors as any)
    ?.['legalCheckSheetToBeSigned']
    ?.[`${checkSheetIndex}`]?.["signers"]

  return (
    <Box
      sx={{ backgroundColor: "white", maxWidth: "100%" }}
    >
      <TableContainer
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          overflowX: "auto",
          "& .MuiTableCell-root.MuiTableCell-head": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
            fontFamily:
              "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
            "&:focus-within": {
              outline: "none",
            },
            fontWeight: 700,
            border: "1px solid #ccc",
          },
        }}
      >
        <Table sx={{ minWidth: '1600px', overflowX: 'auto' }} size="small">
          <TableHead>
            {
              columns.map((col, colIndex) => (
                <TableCell
                  key={`approver_tbl_col_header_${colIndex}`}
                  sx={{
                    width: col?.width,
                    padding: '6px 10px',
                    textAlign: col?.align ?? 'left'
                  }}>{t(col.label)}</TableCell>
              ))
            }
          </TableHead>

          <TableBody>
            {
              signerFields.fields.map((row: any, rowIndex: number) => (
                // <TableRow key={row.rowId!}>
                <TableRow
                  // key={`approver_tbl_row_${rowIndex}`}
                  key={row.rowId!}
                  sx={{
                    backgroundColor: 'white',
                    // display: draggedItem?.rowId === row.rowId ? 'none' : 'flex'
                  }}
                  // onDrop={() => onDrop(rowIndex)}
                  onDragOver={() => onDragOver(rowIndex)}

                >
                  {columns.map((col, colIndex) => (
                    <TableCell
                      key={`approver_tbl_col_${colIndex}_row_${rowIndex}`}
                      draggable={col.key === 'dragHandler'}
                      onDragStart={(e) => onDragStart(e, rowIndex)}
                      onClick={() => {
                        if (col?.editable && !disabled) {
                          setEditRowId(rowIndex)
                        }
                      }}
                      sx={{
                        cursor: col?.editable && !disabled ? 'pointer' : 'default',
                        padding: '6px 10px',
                        border: "1px solid #e0e0e0", // Add borders for all cells
                        textAlign: col?.align ?? 'left'
                      }}
                    >
                      {renderRowCell(col, rowIndex)}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            }
          </TableBody>
        </Table>
      </TableContainer>
      {error?.message ? <FormHelperText sx={{ color: "#d32f2f", marginLeft: "14px" }}>
        {t(error?.message as string, {
          fieldName: t('DOCUMENT_REVIEW.labels.filesToApprove')?.toLowerCase(),
        })}
      </FormHelperText> : null}

      {/* {(signerFields.fields?.length < 7 && !disabled) ? <AddItemButton onClick={appendApprover} /> : null} */}
    </Box>
  )
}

export default LCSApproversTable