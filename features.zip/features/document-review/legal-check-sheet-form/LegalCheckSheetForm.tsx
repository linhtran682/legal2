import { checkSharePointPermissionFn, getLcsDefaultSignerList } from '@/apis/service/document-review/legalCheckSheet';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormTextField } from '@/components/commons/form_inputs/FormTextField';
import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import DateInput from '@/components/commons/inputs/date_input/DateInput';
import { DefaultConfirmPopupState } from '@/components/commons/popups/confirm_popup/ConfirmPopup';
import DropPreviewFileUploadComponent, { ALLOWED_DOCUMENT_TYPE } from '@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload';
import { COLOR_TYPE } from '@/constants/color';
import { GLOBAL_SPACING } from '@/constants/format';
import { formInputSxProps } from '@/constants/theme';
import { AppContext } from '@/context/AppContext';
import { DocumentReviewBodyReceive, DONE_STATUS, DrrmRoles, DocumentReviewDetailFields as Fields, LCS_DONE_STATUS, LegalCheckSheetStatusCodeList } from '@/models/document-review/DocumentReviewDetail';
import { ApproverStatus, LcsFields, LcsRoles, LegalCheckSheetBodyReceive, LegalCheckSheetBodySend, LegalCheckSheetItemStatus, LegalCheckSheetSchema, ToBeSignedItem } from '@/models/document-review/LegalCheckSheet';
import { BasedUser, UserProfileDTO } from '@/models/user/User';
import { cookieSetting, getUserLabel } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import ExpandLessRoundedIcon from '@mui/icons-material/ExpandLessRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import { Button, FormHelperText, Grid, InputLabel, Stack, Typography } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { uniqueId } from 'lodash';
import { FC, ReactNode, useContext, useEffect, useRef, useState } from 'react';
import { FormProvider, useFieldArray, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import { DefaultEsignFormState, EsignForm, EsignFormProps } from '../form_esign/EsignForm';
import WarningDialog from '../form_esign/WarningDialog';
import LastAttachmentsTable from './LastAttachmentsTable';
import LCSApproversTable from './LCSApproversTable';
import LCSFilesToApproveTable from './LCSFilesToApproveTable';


export interface LegalCheckSheetFormProps {
  formMode?: "create" | "update";
  initialValue?: any;
  onSubmit: (data: any) => void;
  onUpdate: (data: any) => void;
  onUpdateSilent: (data: any) => void;
  onSubmitDraft?: (data: any) => void;
  onCancel: () => void;
  loading?: boolean;
  initialValueReceive?: DocumentReviewBodyReceive;
  children?: ReactNode;
  initialLcs?: LegalCheckSheetBodyReceive;
  onCallToEsign?: (data: any) => void;
  onRecallCheckSheet?: (data: any) => void;
  canCreate?: boolean;
  setUploadIds: (ids: number[]) => void;
  drrmRoles?: number[];
}

const FIELD_PATH = "DOCUMENT_REVIEW.field_name"
const LABEL_PATH = "DOCUMENT_REVIEW.labels"

const initialEmptyValue = {
  checkDeptHeadFlag: true,
  checkDivisionFlag: true,
  attachmentFiles: [],
  otherAttachmentFiles: [],
}

const legalCheckSheetToBeSignedTemplate = {
  // attachmentFiles: [],
  // lastAttachmentFiles: [],
  signers: [],
  signedAttachments: []
}

const LegalCheckSheetForm: FC<LegalCheckSheetFormProps> = (props) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const formRef = useRef<HTMLFormElement>(null);
  const [defaultSigners, setDefaultSigners] = useState<Partial<BasedUser>[]>([]);
  // Only one file for signing
  // const [orgSignFileId, setOrgSignFileId] = useState<number | undefined>(undefined);
  const [radioId, setRadioId] = useState<number | undefined>(undefined);
  // Sharepoint files
  const [orgSpFileIds, setOrgSpFileIds] = useState<number[]>([]);
  // const [checkedIds, setCheckedIds] = useState<number[]>([]);

  const accessToken = cookieSetting.get("ACCESS_TOKEN");
  const { formMode = 'create', drrmRoles } = props;

  const [processing, setProcessing] = useState(false);
  const [confirmEsignPopupState, setConfirmEsignPopupState] = useState<EsignFormProps>(
    () => DefaultEsignFormState
  );
  const [warningVisible, setWarningVisible] = useState(true);

  const form = useForm({
    resolver: yupResolver(LegalCheckSheetSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: 'onBlur',
    // disabled: !appContext.meCanWrite
    //   || (props.formMode === "update" && !ownRole.includes(1)),
  });

  const checkSheetFields = useFieldArray({
    name: 'legalCheckSheetToBeSigned',
    control: form.control,
    keyName: 'rowId'
  });

  useEffect(() => {
    if (props.initialLcs) {
      let attachmentFiles: any = [];
      // let originalSignFile = undefined;
      if (props?.initialLcs?.attachmentFiles?.length) {
        attachmentFiles = [...(props?.initialLcs?.attachmentFiles ?? [])?.map((item) => {
          // if (item?.toBeSigned) {
          //   originalSignFile = item.fileId
          // }
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        })];
      }
      if (props?.initialLcs?.sharePointAttachmentFiles?.length) {
        attachmentFiles = [...attachmentFiles, ...(props?.initialLcs?.sharePointAttachmentFiles ?? [])?.map((item) => {
          // if (item?.toBeSigned) {
          //   originalSignFile = item.id
          // }
          return {
            ...item,
            name: item.fileName,
            path: item.storePath,
            id: item.id,
            // uploadDate: item.uploadDate,
          };
        })];
        const sharepointFileIds = props?.initialLcs?.sharePointAttachmentFiles?.map((file) => file.id)
        setOrgSpFileIds(sharepointFileIds);
        // setCheckedIds(sharepointFileIds);
      } else {
        setOrgSpFileIds([]);
        // setCheckedIds([]);
      }
      setRadioId(undefined);
      // setOrgSignFileId(originalSignFile);
      let otherAttachmentFiles: any = []
      if (props?.initialLcs?.otherAttachmentFiles?.length) {
        otherAttachmentFiles = [...(props?.initialLcs?.otherAttachmentFiles ?? [])?.map((item) => {
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        })];
      }
      const initialFormValues = {
        ...props.initialLcs,
        assignUsers: props?.initialLcs?.assignmentUsers?.map((user: any) => ({
          ...user,
          department: user?.departmentResponse
        })),
        evaluateUsers: props?.initialLcs?.evaluateUsers?.map((user: any) => ({
          ...user,
          department: user?.departmentResponse
        })),

        deadlineLCS: props.initialLcs?.deadlineLCS ? new Date(props.initialLcs?.deadlineLCS) : undefined,
        legalCheckSheetToBeSigned: props.initialLcs?.legalCheckSheetToBeSigned?.map((lcs: ToBeSignedItem) => {

          const signers = lcs?.signers?.map((item: any) => ({
            ...item,
            id: item?.id,
            signerId: item?.user?.id,
            note: item?.note,
            status: item.status,
            name: item?.user?.name,
            department: item?.user?.department,
            position: item?.user?.position,
            date: item?.processingDate ? new Date(item?.processingDate) : undefined
          })) ?? []

          const lastAttachmentFiles = lcs?.lastAttachmentFiles?.map((item) => ({
            ...item,
            path: item?.storagePath
          })) ?? [];

          const filesToApprove = lcs?.attachmentFilesWithApprove?.map((item) => ({
            ...item,
            path: item?.storagePath,
          }));

          // const findSignedAttachment = attachmentFiles?.find((item: any) => !!item?.toBeSigned);
          return {
            ...lcs,
            lastAttachmentFiles,
            signers,
            signedAttachments: filesToApprove ?? []
          }

        }),
        attachmentFiles,
        otherAttachmentFiles
      }
      form.reset(
        initialFormValues
      )
    }

    props.initialLcs?.ownerRoles && setOwnRole(props.initialLcs?.ownerRoles)
  }, [props.initialLcs])


  useEffect(() => {
    if (formMode === 'create') {
      form?.setValue?.('status', LegalCheckSheetStatusCodeList.LCS_NEW);
    }
    getDefaultSignersQuery.refetch().then((res) => {
      const transformSignerList = (res.data?.signers ?? []).map((signer) => ({
        note: "",
        signerId: signer.id,
        department: signer?.department,
        position: signer?.position,
        name: signer?.name,
        status: 0,
        id: undefined
      }))
      setDefaultSigners(transformSignerList);
      // if (formMode === 'create') {
      //   form.setValue('legalCheckSheetToBeSigned.0.signers', transformSignerList)
      // }
    })
  }, [])

  const getDefaultSignersQuery = useQuery({
    queryKey: ['legal-check-sheet/default-signers'],
    queryFn: () => getLcsDefaultSignerList(props.initialValueReceive?.id as number),
    enabled: false
  })

  const checkSharepointPermission = useQuery({
    queryKey: ['sharepoint-permission', appContext?.me?.id],
    queryFn: () => checkSharePointPermissionFn(),
    enabled: !!appContext?.me?.id
  })

  const confirmedWithManagers = form.watch(Fields.CONFIRMED_WITH_MANAGERS);

  const appendCheckSheet = async () => {
    if (processing) { return }
    // if (!radioId) {
    //   toast.error(t('DOCUMENT_REVIEW.messages.selectFileToSign'));
    //   return;
    // }
    try {
      // setProcessing(true);
      // const params = handleSaveParams();
      // props.initialValueReceive?.lcsId && (await props?.onUpdate?.({
      //   lcsId: props.initialValueReceive?.lcsId,
      //   request: params
      // }));
      // Nếu file duyệt thay đổi => Update lại LCS sau đó mới gọi api PDF
      // if (orgSignFileId && radioId !== orgSignFileId) {
      //   const newFilesToUploadSharepoint = checkedIds?.filter((file: any) => !orgSpFileIds?.includes(file));
      //   if (newFilesToUploadSharepoint?.length) {
      //     for (const uploadId of newFilesToUploadSharepoint) {
      //       await uploadCurrentFileToSharepoint({
      //         fileId: uploadId,
      //         lcsId: props.initialValueReceive?.lcsId as number
      //       });
      //     }
      //   }
      // }
      // const resPdf = await getLcsPdfFile(props.initialValueReceive?.lcsId as number);
      const timestamp = new Date().valueOf();
      checkSheetFields?.append?.({
        ...legalCheckSheetToBeSignedTemplate,
        scrollToViewId: timestamp.toString(),
        signers: [...defaultSigners],
        // signedAttachments: resPdf ? [{
        //   ...resPdf,
        //   path: resPdf?.url,
        //   status: 1
        // }] : []

      });
      setTimeout(() => document?.getElementById?.(timestamp.toString())?.scrollIntoView({
        behavior: 'smooth',
      }), 100);
    } catch (error) {

    } finally {
      setProcessing(false)
    }
  }

  const handleSaveParams = () => {
    const values = form.getValues();
    const params: LegalCheckSheetBodySend = {} as LegalCheckSheetBodySend;
    params.confirmedWithManagement = !!values?.confirmedWithManagement;
    params.deadlineLCS = values?.deadlineLCS?.toISOString();
    params.status = Number(values.status);
    params.name = values.name;

    params.drrmId = props.initialValueReceive?.id as number;
    params.inChangeUserIds = [];

    // 1. Lọc ra các file trước đó đã là sharepoint 
    // và giờ vẫn là sharepoint
    // 2. Các file mới thêm và tích sharepoint sẽ đẩy lên theo trường attachmentFiles
    // sau đó được upload sau khi đã update LCS
    const sharepointIds = orgSpFileIds;

    params.attachmentFiles = values?.attachmentFiles
      ?.filter((file: any) => !sharepointIds?.includes(file?.id))
      ?.map((file: any) => ({
        fileId: file.id,
        // toBeSigned: file.id === radioId
      })) ?? [];

    params.sharePointAttachmentFiles = values?.attachmentFiles
      ?.filter((file: any) => sharepointIds?.includes(file?.id))
      ?.map((file: any) => ({
        fileId: file.id,
        // toBeSigned: file.id === radioId
      })) ?? [];

    params.otherAttachmentFiles = values?.otherAttachmentFiles?.map((a: any) => a.id) ?? [];
    params.legalCheckSheetToBeSigned = values?.legalCheckSheetToBeSigned?.map((lcs: any) => {
      const lastAttachmentFiles = lcs?.lastAttachmentFiles?.map((a: any) => a.id);
      const signers = lcs?.signers?.map((item: any, index: number) => ({
        id: item?.id ?? undefined,
        position: index + 1,
        signerId: item?.signerId,
        note: item?.note,
        processingDate: item?.date ? item?.date?.toISOString?.() : undefined
      }))

      return {
        id: lcs?.id ?? undefined,
        // attachmentFiles,
        lastAttachmentFiles,
        signers,
        signFileIds: lcs?.signedAttachments?.map((ele: any) => ele?.id) ?? []
        // approvalContent: lcs?.approvalContent ?? undefined
      }
    })

    return params;
  }
  const handleRecallCheckSheet = async (checkSheet: any) => {
    try {
      await props?.onRecallCheckSheet?.({
        lcsId: props.initialValueReceive?.lcsId,
        tobeSignId: checkSheet?.id
      })
    } catch (error) {
    }
  }

  const handleCallEsign = async (checkSheetIndex: number) => {
    try {
      const hasPendingItem = checkSheetFields.fields.some((ele: any, index: number) => {
        const isOtherItem = checkSheetIndex !== index;
        const calledEsign = ele?.status === LegalCheckSheetItemStatus.CALLED_TO_ESIGN;
        const hasRejection = ele?.signers?.some((s: any) => s?.status === ApproverStatus.REJECT);
        const hasNotSigned = ele?.signers?.some((s: any) => s?.status === ApproverStatus.NEW);
        return isOtherItem && calledEsign && hasNotSigned && !hasRejection;
      })

      if (hasPendingItem) {
        toast.error(t('DOCUMENT_REVIEW.messages.esignPending'));
        return;
      }

      const noError = await form.trigger();
      const signedAttachments = form.getValues()?.legalCheckSheetToBeSigned?.[checkSheetIndex]?.signedAttachments;
      const signers = form.getValues()?.legalCheckSheetToBeSigned?.[checkSheetIndex]?.signers;
      const validSigners = !!signers?.[0]?.signerId && // Position 1 (index 0)
        !!signers?.[1]?.signerId && // Position 2 (index 1)
        !!signers?.[4]?.signerId && // Position 5 (index 4)
        !!signers?.[5]?.signerId && // Position 6 (index 5)
        !!signers?.[6]?.signerId; // Position 7 (index 6)
      if (!validSigners) {
        form.setError(`legalCheckSheetToBeSigned.${checkSheetIndex}.signers`,
          {
            message: t('DOCUMENT_REVIEW.messages.requiredPositions')
          });
        return;
      }
      if (!signedAttachments?.length) {
        form.setError(`legalCheckSheetToBeSigned.${checkSheetIndex}.signedAttachments`,
          {
            message: t('DOCUMENT_REVIEW.messages.selectApproveFile')
          },
          { shouldFocus: true });
        document?.getElementById?.(`lcs-item-${checkSheetIndex}`)?.scrollIntoView({
          behavior: 'smooth',
        });
        return;
      }
      if (!noError) return;
      setConfirmEsignPopupState({
        open: true,
        title: t("visitation.label.callEsign"),
        handleConfirm: (content?: string, reasonForLate?: string) => callEsignConfirmed(content ?? "", checkSheetIndex, reasonForLate),
        handleCancel: () =>
          setConfirmEsignPopupState(DefaultConfirmPopupState),
      })

    } catch (error) {
    }
  }
  const callEsignConfirmed = async (content: string, checkSheetIndex: number, reasonForLate?: string) => {
    try {
      setConfirmEsignPopupState(DefaultConfirmPopupState);
      appContext?.setIsCallingEsign?.(true);
      const params = handleSaveParams();
      // (!props.initialValueReceive?.lcsId && props.formMode) &&
      //   (await props?.onSubmit?.(params));
      props.initialValueReceive?.lcsId && (await props?.onUpdateSilent?.({
        lcsId: props.initialValueReceive?.lcsId,
        request: params
      }));
      // const newFilesToUploadSharepoint = checkedIds?.filter((file: any) => !orgSpFileIds?.includes(file));
      // if (newFilesToUploadSharepoint?.length) {
      //   for (const uploadId of newFilesToUploadSharepoint) {
      //     await uploadCurrentFileToSharepoint({
      //       fileId: uploadId,
      //       lcsId: props.initialValueReceive?.lcsId as number
      //     });
      //   }
      // }
      await props?.onCallToEsign?.({
        lcsId: props.initialValueReceive?.lcsId ?? props.initialValueReceive?.id,
        position: checkSheetIndex + 1,
        data: {
          message: content,
          reasonForLate: reasonForLate
        }
      })
    } catch {
    } finally {
      appContext?.setIsCallingEsign?.(false);
    }

  }
  const isStatusDone = props?.initialValueReceive?.status?.name === DONE_STATUS
    || props?.initialLcs?.status === LCS_DONE_STATUS;

  const commonDisabled = !appContext.meCanWrite ||
    (props.formMode === "update" && !ownRole?.includes(LcsRoles.REQUEST_DEPT)) || props?.loading || isStatusDone;

  const disabledLcsAttachment = !appContext.meCanWrite ||
    (props.formMode === "update"
      && !drrmRoles?.includes(DrrmRoles.PIC)
      // && !drrmRoles?.includes(DrrmRoles.L_C)
      && !ownRole?.includes(LcsRoles.LC)
      // && !ownRole?.includes(LcsRoles.SUPERVISOR)
    ) || props?.loading || isStatusDone;

  const disabledOtherAttachment = !appContext.meCanWrite ||
    (props.formMode === "update"
      && !drrmRoles?.includes(DrrmRoles.PIC)
      // && !drrmRoles?.includes(DrrmRoles.L_C)
      // && !drrmRoles?.includes(DrrmRoles.HEAD_OF_L_C)
      // && !drrmRoles?.includes(DrrmRoles.SUPERVISOR)
      // && !drrmRoles?.includes(DrrmRoles.SIGNER)
      && !ownRole?.includes(LcsRoles.LC)
      // && !ownRole?.includes(LcsRoles.SUPERVISOR)
    ) || props?.loading || isStatusDone;


  const legalCheckSheetToBeSignedError = form.formState.errors?.legalCheckSheetToBeSigned;

  const getPdfParams = () => {
    let params = null;
    if (!!radioId) {
      params = {
        id: props.initialValueReceive?.lcsId as number,
        data: {
          fileNormalId: orgSpFileIds?.includes(radioId) ? undefined : radioId,
          fileSharepointId: orgSpFileIds?.includes(radioId) ? radioId : undefined,
        }
      }
    }
    return params;
  }

  const addFileToRecordCb = async (fileList: any) => {
    try {
      const listSharepointIds = [...orgSpFileIds];
      for (const file of fileList) {
        file?.isSharepoint && listSharepointIds.push(file?.id);
        // const params: LcsFileIdBody = {
        //   fileNormalId: !file?.isSharepoint ? file?.id : undefined,
        //   fileSharepointId: file?.isSharepoint ? file?.id : undefined,
        // }
        // await addFilesToLcsFn(props.initialValueReceive?.id as number, params);
      }
      setOrgSpFileIds(listSharepointIds);
      // const promises = fileList.map((file: any) => {
      //   const params: LcsFileIdBody = {
      //     fileNormalId: !file?.isSharepoint ? file?.id : undefined,
      //     fileSharepointId: file?.isSharepoint ? file?.id : undefined,
      //   }
      //   return addFilesToLcsFn(props.initialValueReceive?.id as number, params);
      // });
      // await Promise.all(promises);
    } catch (error) {
    }
  }
  return (
    <FormProvider {...form}>
      <form ref={formRef}>
        <Grid
          container
          className="form-wrapper"
          minWidth={'100%'}
        >
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={formInputSxProps}
            width={'100%'}
          >

            {/* Xác nhận với cấp quản lý */}
            <Grid item width={"100%"}>
              <CheckboxInput
                checked={confirmedWithManagers}
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                onChange={(e) => {
                  if (commonDisabled) return;
                  form.setValue(Fields.CONFIRMED_WITH_MANAGERS, e)
                }}
                label={t(`${LABEL_PATH}.confirmWithManagers`)}
                disabled={commonDisabled}
              />
            </Grid>

            <Grid item width={"100%"} >
              <InputLabel required>{t(`${LABEL_PATH}.sender`)}</InputLabel>
              {props?.initialValueReceive?.pic && <Typography>{getUserLabel(props?.initialValueReceive?.pic)}</Typography>}
            </Grid>

            {/* Tên lcs */}
            <Grid item width={"100%"}>
              <FormTextField
                control={form.control}
                name={LcsFields.LCS_NAME}
                label={t(`${FIELD_PATH}.${Fields.LCS_NAME}`)}
                placeHolder={t(`${FIELD_PATH}.${Fields.LCS_NAME}`)}
                required
                disabled={commonDisabled}
              />
            </Grid>
            {/* Thời hạn LCS */}
            <Grid item width={"100%"}>
              <DateInput
                name={LcsFields.LCS_DEADLINE}
                control={form.control}
                label={t(`${FIELD_PATH}.${Fields.LCS_DUE_DATE}`)}
                placeholder={'dd/mm/yyyy'}
                // required
                disabled={commonDisabled}
              />
            </Grid>
            {/* Nhân viên L&C đánh giá */}
            {props?.initialLcs?.evaluateUsers?.length ? <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={LcsFields.EVALUATE_USERS}
                label={t(`${LABEL_PATH}.${LcsFields.EVALUATE_USERS}`)}
                placeholder={t(`${LABEL_PATH}.${LcsFields.EVALUATE_USERS}`)}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });

                  return response?.users ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                  }`
                }
                getOptionKey={(option) => option.id}
                keyQuery="lcs-evaluate-users"
                disabled
              />
            </Grid> : null}
            {/* Phân công đánh giá */}
            {props?.initialLcs?.assignmentUsers?.length ? <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={LcsFields.ASSIGNMENT_USERS}
                label={t(`${LABEL_PATH}.${LcsFields.ASSIGNMENT_USERS}`)}
                placeholder={t(`${LABEL_PATH}.${LcsFields.ASSIGNMENT_USERS}`)}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });

                  return response?.users ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                  }`
                }
                getOptionKey={(option) => option.id}
                keyQuery="lcs-assignment-users"
                disabled
              />
            </Grid> : null}

            <Grid item width={"100%"}>
              {/* Tài liệu legal check sheet */}
              <DropPreviewFileUploadComponent
                isLcs
                dropView={formMode === 'create'}
                preview={formMode === 'update'}
                inputId={'attachmentFiles'}
                title={t(`${LABEL_PATH}.lcsFiles`)}
                name={'attachmentFiles'}
                files={form.watch('attachmentFiles') ?? []}
                setFiles={(files) => {
                  form.setValue('attachmentFiles', files);
                  form.trigger('attachmentFiles')
                }}
                preventOnchange
                disabled={disabledLcsAttachment}
                required
                onFileDelete={(file) => {
                  if (file?.id === radioId) {
                    setRadioId(undefined)
                  }
                }}
                // selectionId={selectionId}
                // setSelectedId={(id) => setSelectionId(prev => id === prev ? undefined : id)}
                selectionId={radioId}
                setSelectedId={(id) => setRadioId(id === radioId ? undefined : id)}
                hasRadio
                disableCheckbox={!accessToken}

                additionNote={t("DOCUMENT_REVIEW.messages.lcsFileNote")}

                spPermission={checkSharepointPermission?.data?.result}
                // spPermission={SpPermissionTypes.ACC_365_UPLOAD}
                spFolder={"Document Review Request Management"}
                addFileToRecordCb={addFileToRecordCb}
                typeUpload="lcs"
                radioPurpose='DOCUMENT_REVIEW.labels.toAddFileSign'
                accept={ALLOWED_DOCUMENT_TYPE}
              />
            </Grid>

            {/* Tài liệu đính kèm */}
            <DropPreviewFileUploadComponent
              dropView={formMode === 'create'}
              preview={formMode === 'update'}
              inputId={'otherAttachmentFiles'}
              title={t(`legalAdvice.label.attachments`)}
              name={'otherAttachmentFiles'}
              files={form.watch('otherAttachmentFiles') ?? []}
              setFiles={(files) => {
                form.setValue('otherAttachmentFiles', files)
              }}
              preventOnchange
              disabled={disabledOtherAttachment}
            />

            {formMode === 'update'
              && props.initialLcs?.isEnableAddLCS
              && props.initialLcs?.status !== LCS_DONE_STATUS
              && <Grid item width={"100%"}>
                <Button
                  sx={styleBtn}
                  className="confirm"
                  variant="contained"
                  onClick={appendCheckSheet}
                  color="primary">

                  {t('DOCUMENT_REVIEW.lcsButtons.addLcs')}</Button>
              </Grid>

            }

            {/* Thông tin Legal check sheet cần ký */}
            {
              checkSheetFields?.fields?.map((checkSheet: any, checkSheetIndex) => {
                const lcsStatus = checkSheet?.status;
                const lastAttachments = checkSheet?.lastAttachmentFiles ?? [];
                // const signers = checkSheet?.signers;

                // const calledEsign = lcsStatus === LegalCheckSheetItemStatus.CALLED_TO_ESIGN;
                // const hasRejection = (signers ?? [])
                //   .some((ele: any) => ele.status === ApproverStatus.REJECT)
                //   || (lastAttachments ?? [])
                //     .some((file: LcsLastAttachment) => file.status === FileStatus.REJECT
                //       || file.status === FileStatus.REVOKE)
                //   ;
                // const isFinish = lastAttachments?.some((file: LcsLastAttachment) => file?.isDoneLegalCheckSheet)
                //   || lcsStatus === LegalCheckSheetItemStatus.DONE;

                // Trạng thái block
                // const isNew = lcsStatus === LegalCheckSheetItemStatus.NEW;
                const isDone = lcsStatus === LegalCheckSheetItemStatus.DONE;
                // const isRecalled = lcsStatus === LegalCheckSheetItemStatus.RECALLED;
                // const isRefuse = lcsStatus === LegalCheckSheetItemStatus.REFUSE;
                const isCalledToEsign = lcsStatus === LegalCheckSheetItemStatus.CALLED_TO_ESIGN;

                return <Grid id={checkSheet?.scrollToViewId} key={checkSheet?.rowId ?? uniqueId('check_sheet_')} item width={"100%"} sx={{ backgroundColor: 'white' }}>
                  <Grid
                    container
                    direction={"column"}
                    className='form-sub-section-wrapper'
                    rowGap={"0.5rem"}
                    width={'100%'}
                    overflow={'hidden'}
                    sx={{ p: 0, gap: 0 }}
                  >
                    <DropDownItem>
                      <Grid container sx={{ p: 2, pt: 0 }} width={"100%"}>
                        <Grid item width={"100%"} mt={1.5} mb={1.5}>
                          <Typography sx={{ mb: 1 }} variant='h5'>{t(`${LABEL_PATH}.finalDocuments`)}</Typography>
                          <LastAttachmentsTable
                            lastAttachments={lastAttachments}
                          />
                        </Grid>

                        <Grid item width={"100%"} mt={1.5}>
                          <div id={`lcs-item-${checkSheetIndex}`} />
                          <LCSFilesToApproveTable
                            showButton={ownRole?.includes(LcsRoles.REQUEST_DEPT)}
                            control={form?.control}
                            checkSheetIndex={checkSheetIndex}
                            disabled={!radioId
                              || commonDisabled
                              || isCalledToEsign
                              || isDone
                            }
                            getPdfParams={getPdfParams}
                          />
                        </Grid>
                        <Grid item width={"100%"} mt={1.5}>
                          <Typography variant='h5' sx={{ mb: 1 }}>{t(`${LABEL_PATH}.approver`)}</Typography>
                          <LCSApproversTable
                            control={form?.control}
                            checkSheetIndex={checkSheetIndex}
                            disabled={commonDisabled
                              || isCalledToEsign
                              || isDone
                            }
                          />
                        </Grid>
                        {commonDisabled ? null : <Grid
                          item
                          width={"100%"}
                          display={'flex'}
                          justifyContent={'flex-end'}
                          mt={2}
                          flexDirection={'row'} gap={1}>
                          <Button
                            className="cancel"
                            disabled={
                              // Enable: Tạo mới, Thu hồi, Từ chối
                              // Disable: Call esign, Hoàn thành
                              isCalledToEsign || isDone
                            }
                            variant="contained"
                            onClick={() => checkSheetFields.remove(checkSheetIndex)}
                            color="primary" sx={styleBtn}>{t('DOCUMENT_REVIEW.lcsButtons.delete')}</Button>
                          <Button
                            variant="contained"
                            className="saveDraft"
                            onClick={() => handleRecallCheckSheet(checkSheet)}
                            disabled={
                              // Enable: Call esign
                              // Disable: Tạo mới, thu hồi, từ chối, hoàn thành
                              !isCalledToEsign
                            }
                            sx={{ ...styleBtn, backgroundColor: '#E8AE00' }}>{t('DOCUMENT_REVIEW.lcsButtons.recall')}</Button>
                          <Button
                            sx={styleBtn}
                            className="confirm"
                            disabled={
                              // Enable: Tạo mới, Thu hồi, Từ chối, 
                              // Disable: Call esign, Hoàn thành
                              isCalledToEsign || isDone
                            }
                            variant="contained"
                            onClick={() => handleCallEsign(checkSheetIndex)}
                            color="primary">{t('DOCUMENT_REVIEW.lcsButtons.callEsign')}</Button>
                        </Grid>}
                      </Grid>
                    </DropDownItem>

                  </Grid>

                </Grid>
              })}

            {legalCheckSheetToBeSignedError?.message ? <Grid item width={"100%"} ><FormHelperText sx={{ color: "#d32f2f", marginLeft: "14px", textAlign: 'left' }}>
              {t(legalCheckSheetToBeSignedError?.message as string)}
            </FormHelperText></Grid> : null}
          </Grid>
        </Grid >
        {confirmEsignPopupState?.open
          ? <EsignForm  {...confirmEsignPopupState} signingDate={props?.initialValueReceive?.signingDate} />
          : null
        }
        {warningVisible
          && props?.initialLcs?.reasonForLate
          && ownRole?.includes(LcsRoles.SIGNER)
          && !drrmRoles?.includes(DrrmRoles.PIC)
          && props?.initialLcs?.status === LegalCheckSheetStatusCodeList.REQUEST_SIGNING
          ? <WarningDialog
            reason={props?.initialLcs?.reasonForLate}
            onClose={() => setWarningVisible(false)} />
          : null}
        {(ownRole?.includes(LcsRoles.REQUEST_DEPT)
          || ownRole?.includes(LcsRoles.LC)
          || props?.canCreate) && <FormActionButtons
            formMode={props.formMode}
            loading={props.loading}
            onCancel={props.onCancel}
            isDisableButonSave={
              props.initialLcs?.status === LCS_DONE_STATUS
              || isStatusDone
            }
            onSave={async () => {
              try {
                // const newFilesToUploadSharepoint = checkedIds?.filter((file: any) => !orgSpFileIds?.includes(file));
                // if (newFilesToUploadSharepoint?.length) {
                //   setUploadIds?.(newFilesToUploadSharepoint);
                // }
                const params: any = handleSaveParams();
                if (props.formMode === 'create') {
                  props?.onSubmit?.(params);
                }
                if (props.formMode === 'update') {
                  props?.onUpdate?.({
                    lcsId: props.initialValueReceive?.lcsId,
                    request: params
                  });
                }
              } catch (error) {
              }
            }}
          />}
      </form>
    </FormProvider>
  )
}

export default LegalCheckSheetForm

const styleBtn = { minWidth: "168px", height: 40 };


interface DropDownItemProps {
  children: ReactNode;
}

const DropDownItem = (props: DropDownItemProps) => {
  const { t } = useTranslation();
  const { children } = props;
  const [visible, setVisible] = useState(true);
  return <>
    <Stack
      onClick={() => setVisible(prev => !prev)}
      direction={'row'} justifyContent={'space-between'} alignItems={'center'} sx={{ mb: 0, padding: '8px 16px', backgroundColor: '#FFE5E5', cursor: 'pointer' }}>
      <Typography variant='h5'>{t(`${LABEL_PATH}.signLegalCheckSheetInformation`)}</Typography>
      {visible ? <ExpandLessRoundedIcon sx={{ color: '#808080' }} />
        : <ExpandMoreRoundedIcon sx={{ color: '#808080' }} />}
    </Stack>
    {visible && children}
  </>
}