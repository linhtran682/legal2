import { COLOR_TYPE } from "@/constants/color";
import { LcsLastAttachment } from "@/models/document-review/LegalCheckSheet";
import { formatDate } from "@/utils";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import {
  Box,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { uniqueId } from "lodash";
import { ReactNode } from "react";
import { useTranslation } from "react-i18next";

interface FileTableColumn {
  key: string;
  label: string;
  type: "string" | "number" | "date" | "bool" | "action" | "select";
  width?: string;
  renderCell?: (params: LcsLastAttachment & { index: number }) => ReactNode;
}
interface Props {
  lastAttachments?: LcsLastAttachment[];
}

const LastAttachmentsTable = ({
  lastAttachments = [],
}: Props) => {
  const { t } = useTranslation();

  const onDownloadClick = (e: any, file: any) => {
    e.stopPropagation();
    const a = document.createElement("a");
    a.href = file?.file?.filePath ?? file?.storagePath;
    a.download = file.name;
    a.click();
  };

  const columns: FileTableColumn[] = [
    {
      key: "index",
      label: "LEGISLATION.column.id",
      type: "string",
      width: '52px',
      renderCell: (params) => {
        return <span>{params.index + 1}</span>
      }
    },
    {
      key: "processingDate",
      label: "DOCUMENT_REVIEW.labels.responseDate",
      type: "string",
      width: "150px",
      renderCell: (params) => params?.processingDate ? formatDate(params.processingDate) : "",
    },
    {
      key: "status",
      label: "DOCUMENT_REVIEW.labels.status",
      type: "string",
      width: "200px",
      renderCell: (params) => params?.status ? t(`DOCUMENT_REVIEW.fileStatus.${params?.status}`) : ''
    },
    {
      key: "name",
      label: "DOCUMENT_REVIEW.field_name.file",
      type: "string",
    },
    {
      key: "action",
      label: "",
      type: "string",
      width: '60px',
      renderCell: (params: any) => (
        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <IconButton onClick={(e) => onDownloadClick(e, params)}>
            <FileDownloadOutlinedIcon fontSize="small" />
          </IconButton>
        </Box>
      ),
    },
  ];

  return (
    <Box
      sx={{
        backgroundColor: "white",
        maxWidth: "100%",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <TableContainer
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          overflowX: "auto",
          "& .MuiTableCell-root.MuiTableCell-head": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
            fontFamily:
              "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
            "&:focus-within": {
              outline: "none",
            },
            fontWeight: 700,
            border: "1px solid #ccc",
          },
        }}
      >
        <Table
          sx={{ width: "100%", minWidth: "850px", overflowX: "auto" }}
          size="small"
        >
          <TableHead>
            {columns.map((col) => (
              <TableCell
                key={uniqueId("col_header_")}
                sx={{ width: col?.width }}
              >
                {t(col.label)}
              </TableCell>
            ))}
          </TableHead>
          <TableBody>
            {lastAttachments.map((row: any, rowIndex: number) => (
              <TableRow key={uniqueId("row_")}>
                {columns.map((col) => (
                  <TableCell
                    key={uniqueId("cell_")}
                    sx={{
                      border: "1px solid #e0e0e0", // Add borders for all cells
                    }}
                  >
                    {col?.renderCell
                      ? col?.renderCell?.({ ...row, index: rowIndex })
                      : row?.[col?.key]}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default LastAttachmentsTable;
