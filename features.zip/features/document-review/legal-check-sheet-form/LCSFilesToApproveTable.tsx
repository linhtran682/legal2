import { getLcsPdfFile } from '@/apis/service/document-review/legalCheckSheet';
import { COLOR_TYPE } from '@/constants/color';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import { Box, Button, CircularProgress, FormHelperText, IconButton, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import { uniqueId } from 'lodash';
import { ReactNode, useState } from 'react';
import { useFieldArray, useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

interface LCSFileTableColumn {
  key: string;
  label: string;
  type: "string" | "number" | "date" | "bool" | "action" | "select";
  width?: string;
  renderCell?: (params?: any) => ReactNode;
}
interface LCSFilesToApproveTableProps {
  control: any;
  checkSheetIndex: number;
  disabled?: boolean;
  showButton?: boolean;
  getPdfParams?: () => any;
  // addUpdateSignFile?: (cb: (resPdf: any) => void) => void;
}

const LABEL_PATH = "DOCUMENT_REVIEW.labels";

const LCSFilesToApproveTable = (props: LCSFilesToApproveTableProps) => {
  const { control, checkSheetIndex, showButton, disabled, getPdfParams } = props;
  const { t } = useTranslation();
  const { formState, clearErrors } = useFormContext();
  const [processing, setProcessing] = useState(false);
  const fileFields = useFieldArray({
    name: `legalCheckSheetToBeSigned.${checkSheetIndex}.signedAttachments`,
    control: control,
  });

  // const removeFile = (fileIndex: number) => {
  //   fileFields.remove(fileIndex);
  // }

  const onDownloadClick = (e: any, file: any) => {
    e.stopPropagation();
    const a = document.createElement("a");
    a.href = file?.path ?? file?.storagePath;
    a.download = file.name;
    a.click();
  };


  const columns: LCSFileTableColumn[] = [
    {
      key: "index",
      label: "LEGISLATION.column.id",
      type: "string",
      width: '52px',
      renderCell: (params) => {
        return <span>{params.index + 1}</span>
      }
    },
    {
      key: "fileType",
      label: "DOCUMENT_REVIEW.field_name.fileType",
      type: "string",
      width: '150px',
      renderCell: (params) => params?.fileType || 'LCS'
    },
    // {
    //   key: "status",
    //   label: "DOCUMENT_REVIEW.labels.status",
    //   type: "string",
    //   width: '200px',
    //   renderCell: (params) => params?.status ? t(`DOCUMENT_REVIEW.fileStatus.${params?.status}`) : ''
    // },
    {
      key: "name",
      label: "DOCUMENT_REVIEW.field_name.file",
      type: "string",
    },
    {
      key: "action",
      label: "",
      type: "string",
      width: '60px',
      renderCell: (params: any) => (
        <Box sx={{
          width: '100%',
          height: "100%",
          display: 'flex',
          justifyContent: "center",
          alignItems: 'center'
        }}>
          {/* <IconButton onClick={(e) => { params?.sharePointLink && window.open(params?.sharePointLink, '_blank') }}> */}
          <IconButton onClick={(e) => onDownloadClick(e, params)}>
            <FileDownloadOutlinedIcon fontSize="small" />
          </IconButton>
          {/* <IconButton disabled={disabled} onClick={() => removeFile(params?.index)}>
            <RemoveCircleOutlineOutlinedIcon fontSize="small" />
          </IconButton> */}
        </Box>
      )
    },
  ];

  const addUpdateSignFile = async () => {
    try {
      setProcessing(true);
      const params = getPdfParams?.();
      if (params) {
        const resPdf = await getLcsPdfFile(params?.id as number, params?.data);
        if (resPdf) {
          const newFile = {
            ...resPdf,
            path: resPdf?.url,
            status: 1
          }
          fileFields.update(0, newFile);
          clearErrors(`legalCheckSheetToBeSigned.${checkSheetIndex}.signedAttachments`);
        }
      }
    } catch (error) {
    } finally {
      setProcessing(false);
    }
  }

  const error = (formState.errors as any)?.['legalCheckSheetToBeSigned']?.[`${checkSheetIndex}`]?.["signedAttachments"]
  return (<>
    <Stack direction={"row"} flexWrap={"wrap"} alignItems={"center"} justifyContent={"space-between"} mb={1}>
      <Typography variant='h5' sx={{ flex: 1 }}>{t(`${LABEL_PATH}.filesToApprove`)}</Typography>
      {processing ? <CircularProgress size={16} sx={{ mx: 2 }} /> : null}
      {showButton ? <Button
        sx={{
          minWidth: 168,
          alignSelf: "flex-end",

        }}
        className="confirm"
        variant="contained"
        onClick={addUpdateSignFile}
        disabled={disabled || processing}
        color="primary"
      >
        {fileFields.fields?.length > 0 ? t(`visitation.label.updateApproveFile`) : t(`visitation.label.addApproveFile`)}
      </Button> : null}
    </Stack>
    <Box
      sx={{ backgroundColor: "white", maxWidth: "100%" }}
    >
      <TableContainer
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          overflowX: "auto",
          "& .MuiTableCell-root.MuiTableCell-head": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
            fontFamily:
              "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
            "&:focus-within": {
              outline: "none",
            },
            fontWeight: 700,
            border: "1px solid #ccc",
          },
        }}
      >
        <Table sx={{ width: '100%', minWidth: '850px', overflowX: 'auto' }} size="small">
          <TableHead>
            {
              columns.map((col) => (
                <TableCell key={uniqueId('col_header_')} sx={{ width: col?.width }}>{t(col.label)}</TableCell>
              ))
            }
          </TableHead>
          <TableBody>
            {
              fileFields.fields?.map((row: any, rowIndex: number) => (
                <TableRow
                  key={uniqueId('row_')}
                >
                  {columns.map((col) => (
                    <TableCell
                      key={uniqueId('cell_')}
                      sx={{
                        border: "1px solid #e0e0e0", // Add borders for all cells
                      }}
                    >
                      {col?.renderCell
                        ? col?.renderCell?.({ ...row, index: rowIndex })
                        : row?.[col?.key]}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            }
          </TableBody>
        </Table>
      </TableContainer>

      {error?.message ? <FormHelperText sx={{ color: "#d32f2f", marginLeft: "14px" }}>
        {t(error?.message as string, {
          fieldName: t('DOCUMENT_REVIEW.labels.filesToApprove')?.toLowerCase(),
        })}
      </FormHelperText> : null}
    </Box>
  </>
  )
}

export default LCSFilesToApproveTable