import { createInspectionMutationFn, getInspectionDetailQueryFn, getInspectionList, updateInspectionMutationFn } from "@/apis/service/document-review/inspection";
import { getStatusListNames } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleFields, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { DocumentReviewBodyReceive, DocumentReviewStatusList } from "@/models/document-review/DocumentReviewDetail";
import { castInspectionDTO, DocumentReviewInspectionItem, InspectionFieldNames, InspectionSchema, SupervisorInspectionOptions, SupervisorInspectionStatusList, TypeAdvisorLegal } from "@/models/document-review/Inspection";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useContext, useEffect, useRef, useState } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { INSPECTION_LIST_QUERY_KEY } from "../document-review-form-list/ReviewList";
import { ListInspection } from "../form_document_review_conduction_feedback/ListInspection";

const initialEmptyValue = {
  [InspectionFieldNames.CONTENT]: "",
  [InspectionFieldNames.USERS]: [],
  [InspectionFieldNames.FINISH]: false,
  [InspectionFieldNames.REMIND]: undefined,
};


export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: any;
  documentReviewId?: number;
  inspectionId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  isFeedBack?: boolean;
  isSupervisorReview?: boolean;
  name?: string;
  module?: number;
  minDateAdvisor?: Date | undefined;
  inspection?: DocumentReviewInspectionItem;
  senderDocumentManagement?: any;
  refetchQueryKeys?: string[];
  initialDocumentReview?: DocumentReviewBodyReceive
}

export const DocumentReviewConductionSupervisorForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup,
    initialValue = initialEmptyValue,
    documentReviewId,
    inspectionId,
    isOpen = false,
    setIsOpen,
    isFeedBack = false,
    module = Module.get(ModuleKeys.DOCUMENT),
    senderDocumentManagement,
    name,
    refetchQueryKeys = [],
    initialDocumentReview
  } = props;
  const [files, setFiles] = useState<any>([]);
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const formRef = useRef<HTMLFormElement>(null);
  const appContext = useContext(AppContext)

  const form = useForm<any>({
    resolver: yupResolver(
      InspectionSchema
    ),
    // defaultValues: initialValue,
  });

  const { data: listInspectionData, isFetching: isLoadingInspectionList, refetch: refetchInspectionList } = useQuery({
    queryKey: [INSPECTION_LIST_QUERY_KEY, documentReviewId],
    queryFn: () => getInspectionList(documentReviewId as number),
    enabled: false,
  });

  useEffect(() => {
    getStatusListQuery.refetch();
    inspectionId && refetchDetail();
    refetchInspectionList().then((data) => {
      const userIds = data?.data?.responses
        ?.filter((res) => !res?.inspectedBySupervisor && res?.user?.id !== appContext?.me?.id)
        ?.map((res) => res?.user) ?? [];
      form?.setValue?.('userIds', userIds)
    });
    // form?.setValue?.('userIds', initialValue?.userIds)
  }, [initialValue])

  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list/supervisor'],
    queryFn: async () => {
      const response = await getStatusListNames({
        names: [DocumentReviewStatusList.DONE_REVIEW, DocumentReviewStatusList.SUPERVISOR_REVIEWED],
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: false
  });

  const { data: getInspectionDetail, isLoading, refetch: refetchDetail } = useQuery({
    queryKey: ['inspection-detail', documentReviewId, inspectionId],
    queryFn: () => getInspectionDetailQueryFn({
      documentReviewId: documentReviewId as number,
      inspectionId: inspectionId as number
    }),
    enabled: false
  });

  const { mutateAsync: createInspectionAsync, isPending } = useMutation({
    mutationFn: createInspectionMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(`DOCUMENT_REVIEW.popup.review`),
        })
      );
      refetchQueryKeys?.length && queryClient.invalidateQueries({ queryKey: refetchQueryKeys });
      onCloseForm(true);
    },
  })

  const { mutateAsync: updateInspectionAsync, isPending: isUpdatePending } = useMutation({
    mutationFn: updateInspectionMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t(`DOCUMENT_REVIEW.popup.review`),
        })
      );
      refetchQueryKeys?.length && queryClient.invalidateQueries({ queryKey: refetchQueryKeys });
      onCloseForm(true);
    },
  })

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    const findStatus = data?.type === 0
      ? getStatusListQuery?.data?.find(
        (status: any) =>
          status?.name ===
          SupervisorInspectionStatusList.DONE_REVIEW
      )?.id
      : getStatusListQuery?.data?.find(
        (status: any) =>
          status?.name ===
          SupervisorInspectionStatusList.SUPERVISOR_REVIEWED
      )?.id
    if (inspectionId && documentReviewId) {
      await updateInspectionAsync({
        documentReviewId,
        inspectionId,
        request: {
          ...data,
          ...(findStatus && { status: +findStatus }),
        },
      });
      return;
    }
    !!documentReviewId && (await createInspectionAsync({
      id: documentReviewId,
      request: {
        ...data,
        ...(findStatus && { status: +findStatus }),
      },
    }));
  };

  useEffect(() => {
    if (getInspectionDetail) {
      const { content, ...restGetDataTimeExtension } =
        getInspectionDetail;
      restGetDataTimeExtension?.attachments &&
        setFiles(
          restGetDataTimeExtension.attachments?.map((item: any) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          })
        );
      form.reset({
        // ...restGetDataTimeExtension,
        content,
        finish: !!getInspectionDetail.finishFlag,
        // userIds: receivers,
        // departments: [department?.id],
      });
    }
  }, [getInspectionDetail]);

  const handleChangeRadioType = (
    _event: React.ChangeEvent<HTMLInputElement>,
    value: string | number | boolean
  ) => {
    const userIds = listInspectionData?.responses
      ?.filter((res) => !res?.inspectedBySupervisor && res?.user?.id !== appContext?.me?.id)
      ?.map((res) => res?.user) ?? [];
    form.setValue(
      'userIds',
      value === TypeAdvisorLegal.toPic
        ? initialDocumentReview?.pic ? [initialDocumentReview?.pic] : []
        : userIds
    );
  };

  if (isLoading) return;

  return (
    <ModalCommon
      title={t(
        titlePopup ??
        `DOCUMENT_REVIEW.popup.supervisorReview`
      )}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`DOCUMENT_REVIEW.popup.supervisorReviewer`)}
                </InputLabel>
                <Typography>
                  {getUserLabel(senderDocumentManagement)}
                </Typography>
              </Grid>
              {listInspectionData && (
                <ListInspection data={listInspectionData.responses?.filter((res) => !res?.inspectedBySupervisor)} />
              )}

              <Grid item width={"100%"}>
                <RadioGroupField
                  isNumber
                  items={SupervisorInspectionOptions}
                  name={InspectionFieldNames.TYPE}
                  error={
                    form.formState.errors[
                    InspectionFieldNames.TYPE
                    ] as FieldError
                  }
                  onChangeRadioGroup={handleChangeRadioType}
                  defaultValue={
                    SupervisorInspectionOptions[1]?.value as number
                  }
                />
              </Grid>
              {/* <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={InspectionFieldNames.STATUS}
                  label={t(`legalAdvice.advisorLegalAdvice.title.status`)}
                  placeholder={t(
                    `legalAdvice.advisorLegalAdvice.title.status`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"inspection-status-list"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusListNames({
                        names: Object.values(SupervisorInspectionStatusList),
                        modules: [ModuleFields.DOCUMENT_REVIEW.module],
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }
                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option?.name}
                  required
                />
              </Grid> */}
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={InspectionFieldNames.CONTENT}
                  label={t(
                    `DOCUMENT_REVIEW.popup.${InspectionFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `DOCUMENT_REVIEW.popup.${InspectionFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                  disabled={isFeedBack}
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={!inspectionId}
                  preview={!!inspectionId}
                  files={files}
                  setFiles={setFiles}
                  title={t(`legalAdvice.advisorLegalAdvice.title.file`)}
                  inputId="advisorLegalAdvice"
                />
              </Grid>
              {/* <Grid item width={"100%"}>
                <FormCheckbox
                  control={form.control}
                  name={InspectionFieldNames.FINISH}
                  label={t(
                    `DOCUMENT_REVIEW.popup.reviewFinish`
                  )}
                  inputTransform={(value: boolean) => !!value}
                  outputTransform={(bool) => (bool ? true : false)}
                />
              </Grid> */}

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={InspectionFieldNames.USERS}
                  label={t('DOCUMENT_REVIEW.labels.receivers')}
                  placeholder={t('common.place_holder.enter_name_code')}
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option?.name ?? ""} (${option?.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"advisorLegalAdvice/queryUser"}
                  isFocus
                  required
                />
              </Grid>



            </Grid>
            <ReminderPickerSubForm
              name={InspectionFieldNames.REMIND}
              module={module}
              placeholder={t('menu.reminder')}
            />
            <FormActionButtons
              formMode="create"
              textSave={`common.button.${isFeedBack ? "verify" : "send"}`}
              loading={
                isPending ||
                isUpdatePending ||
                isLoadingInspectionList
              }
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  const attachmentIds: number[] = files?.map((item: any) => item.id) ?? []
                  onSubmit(
                    castInspectionDTO({
                      ...form.getValues(),
                      attachmentIds,
                    })
                  );
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon >
  );
};
