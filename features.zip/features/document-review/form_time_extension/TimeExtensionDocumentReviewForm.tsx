import {
  createLcsTimeExtensionMutationFn,
  updateLcsTimeExtensionMutationFn,
  useCreateTimeExtension,
  useGetTimeExtension,
  useLcsGetTimeExtension,
  useUpdateTimeExtension,
} from "@/apis/service/document-review/timeExtensionDocumentReview";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { ConfirmExtensionRequestSchema, ExtensionOptions, TimeExtensionRequestFieldNames, TimeExtensionRequestSchema, TimeExtensionRequestSchemaI } from "@/models/document-review/TimeExtension";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const initialEmptyValue: TimeExtensionRequestSchemaI = {
  [TimeExtensionRequestFieldNames.DEADLINE]: "",
  [TimeExtensionRequestFieldNames.REASON]: "",
  [TimeExtensionRequestFieldNames.USERS]: [],
  [TimeExtensionRequestFieldNames.REMIND]: undefined,
};

export interface TimeExtensionTypeFormProps {
  titlePopup?: string;
  initialValue?: TimeExtensionRequestSchemaI;
  documentReviewId?: number;
  timeExtensionRequestId?: number;
  lcsTimeExtensionRequestId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  isConfirmExtension?: boolean;
  name?: string;
  handleSubmit?: any;
  module?: number;
  senderDocumentManagement?: any;
  lcsId?: number;
  isLcs?: boolean;
}

export const TimeExtensionDocumentReviewForm = (props: TimeExtensionTypeFormProps) => {
  const {
    titlePopup,
    initialValue = initialEmptyValue,
    documentReviewId,
    timeExtensionRequestId,
    lcsTimeExtensionRequestId,
    isOpen = false,
    setIsOpen,
    isConfirmExtension = false,
    name,
    handleSubmit,
    module = Module.get(ModuleKeys.DOCUMENT),
    senderDocumentManagement,
    isLcs,
    lcsId
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const { data: getDataTimeExtension, isLoading } = useGetTimeExtension({
    request: { documentReviewId, timeExtensionRequestId },
    config: {
      enabled:
        !!documentReviewId && !!timeExtensionRequestId && isConfirmExtension,
    },
  });
  const { data: getLcsDataTimeExtension, isLoading: isLcsLoading } = useLcsGetTimeExtension({
    request: { lcsId, lcsTimeExtensionRequestId },
    config: {
      enabled:
        !!documentReviewId && !!lcsTimeExtensionRequestId && isConfirmExtension,
    },
  });

  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmExtension
        ? TimeExtensionRequestSchema.concat(ConfirmExtensionRequestSchema)
        : TimeExtensionRequestSchema
    ),
    defaultValues: initialValue,
  });

  const { mutateAsync: createTimeExtension, isPending } =
    useCreateTimeExtension({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(
                titlePopup ??
                `legalAdvice.timeExtension.title.${isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                }`
              ),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const {
    mutateAsync: updateTimeExtension,
    isPending: isLoadingUpdateTimeExtension,
  } = useUpdateTimeExtension({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(
              titlePopup ??
              `legalAdvice.timeExtension.title.${isConfirmExtension ? "titlePopup" : "titlePopupRequest"
              }`
            ),
          })
        );
        onCloseForm(true);
      },
    },
  });


  // LCS

  const { mutateAsync: createLcsTimeExtension, isPending: isLcsCreatePending } = useMutation({
    mutationFn: createLcsTimeExtensionMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(
            titlePopup ??
            `legalAdvice.timeExtension.title.${isConfirmExtension ? "titlePopup" : "titlePopupRequest"
            }`
          ),
        })
      );
      onCloseForm(true);
    },
  });
  const { mutateAsync: updateLcsTimeExtension, isPending: isLcsUpdatePending } = useMutation({
    mutationFn: updateLcsTimeExtensionMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(
            titlePopup ??
            `legalAdvice.timeExtension.title.${isConfirmExtension ? "titlePopup" : "titlePopupRequest"
            }`
          ),
        })
      );
      onCloseForm(true);
    },
  });

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    if (isConfirmExtension) {
      const params = {
        remind: data?.remind,
        users: data?.users,
        type: data?.confirm,
        ...(!data?.confirm && {
          deadlineAccept: data?.acceptableDeadline,
          reason: data?.acceptableReason,
        }),
      }
      !isLcs && (await updateTimeExtension({
        documentReviewId,
        timeExtensionRequestId,
        data: params
      }));
      isLcs && (await updateLcsTimeExtension({
        lcsId,
        lcsTimeExtensionRequestId,
        data: params
      }));

      handleSubmit && handleSubmit();
      return;
    }
    (!isLcs && documentReviewId) && (await createTimeExtension({
      documentReviewId,
      data,
    }));
    (isLcs && lcsId) && (await createLcsTimeExtension({
      lcsId,
      data,
    }));
  };

  useEffect(() => {
    if (getDataTimeExtension) {
      const { user, department, deadline, ...restGetDataTimeExtension } =
        getDataTimeExtension;

      form.reset({
        ...restGetDataTimeExtension,
        [TimeExtensionRequestFieldNames.CONFIRM]: 1,
        [TimeExtensionRequestFieldNames.DEADLINE]: deadline ? new Date(deadline) : undefined,
        users: [user],
        departments: [department?.id],
      });
    }
  }, [getDataTimeExtension]);
  useEffect(() => {
    if (getLcsDataTimeExtension) {
      const { user, department, ...restGetLcsDataTimeExtension } =
        getLcsDataTimeExtension;

      form.reset({
        ...restGetLcsDataTimeExtension,
        [TimeExtensionRequestFieldNames.CONFIRM]: 1,
        users: [user],
        departments: [department?.id],
      });
    }
  }, [getLcsDataTimeExtension]);

  if (isLoading || isLcsLoading) return;

  return (
    <ModalCommon
      title={t(
        titlePopup ??
        `legalAdvice.timeExtension.title.${isConfirmExtension ? "titlePopup" : "titlePopupRequest"
        }`
      )}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </InputLabel>
                {senderDocumentManagement && (
                  <Typography>
                    {getUserLabel(senderDocumentManagement)}
                  </Typography>
                )}
              </Grid>

              <Grid
                container
                className={`${isConfirmExtension ? "form-sub-section-wrapper" : ""
                  }`}
                position={"relative"}
                rowGap={GLOBAL_SPACING}
              >
                {isConfirmExtension && (
                  <Grid item width={"100%"}>
                    <Typography fontWeight="bold">
                      {t(
                        "legalAdvice.timeExtension.title.requestInformation"
                      )}
                    </Typography>
                  </Grid>
                )}
                <Grid item width={"100%"}>
                  <DateTimeInput
                    name={TimeExtensionRequestFieldNames.DEADLINE}
                    control={form.control}
                    label={t(`legalAdvice.timeExtension.title.newDeadline`)}
                    placeholder="dd/mm/yyyy hh:mm"
                    minDate={new Date()}
                    required={!isConfirmExtension}
                    disabled={isConfirmExtension}
                  />
                </Grid>
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={TimeExtensionRequestFieldNames.REASON}
                    label={t(`legalAdvice.timeExtension.title.reason`)}
                    placeHolder={t(
                      `legalAdvice.timeExtension.placeHolder.reason`
                    )}
                    minRows={3}
                    required={!isConfirmExtension}
                    disabled={isConfirmExtension}
                  />
                </Grid>
              </Grid>

              {isConfirmExtension && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={ExtensionOptions}
                    name={TimeExtensionRequestFieldNames.CONFIRM}
                    error={
                      form.formState.errors[
                      TimeExtensionRequestFieldNames.CONFIRM
                      ] as FieldError
                    }
                    onChangeRadioGroup={(_, value) => {
                      if (value === 1) {
                        form.setValue(TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE, undefined)
                        form.setValue(TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON, undefined)
                      }
                    }}
                  />
                </Grid>
              )}

              {(isConfirmExtension && !form?.watch(
                TimeExtensionRequestFieldNames.CONFIRM
              )) && (
                  <>
                    <Grid item width={"100%"}>
                      <DateTimeInput
                        name={TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE}
                        control={form.control}
                        label={t(
                          `legalAdvice.timeExtension.title.newDeadlineAccept`
                        )}
                        placeholder={t(
                          `legalAdvice.timeExtension.placeHolder.newDeadlineAccept`
                        )}
                        required
                        minDate={new Date()}
                      />
                    </Grid>
                    <Grid item width={"100%"}>
                      <FormTextArea
                        control={form.control}
                        name={
                          TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON
                        }
                        label={t(`legalAdvice.timeExtension.title.reason`)}
                        placeHolder={t(
                          `legalAdvice.timeExtension.placeHolder.reason`
                        )}
                        minRows={3}
                        required
                      />
                    </Grid>
                  </>
                )}

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={TimeExtensionRequestFieldNames.USERS}
                  label={t('DOCUMENT_REVIEW.popup.pic')}
                  placeholder={t('DOCUMENT_REVIEW.popup.enterUserName')}
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const selectedDepartments = form.getValues(
                      'departments'
                    );
                    if (selectedDepartments?.length) {
                      params.departmentIds = selectedDepartments;
                    }
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option?.name ?? ""} (${option?.email ?? ""}) - ${option?.departmentName ?? option?.department?.name
                    }`
                  }
                  getOptionKey={(option) => option?.id}
                  keyQuery={"timeExtensionLegalAdvice/queryUser"}
                  isFocus
                  disabled={!isConfirmExtension}
                />
              </Grid>


            </Grid>
            <ReminderPickerSubForm
              name={TimeExtensionRequestFieldNames.REMIND}
              module={module}
              placeholder={t('menu.reminder')}
            />
            <FormActionButtons
              formMode="create"
              textSave={`common.button.${isConfirmExtension ? "confirm" : "send"
                }`}
              loading={isPending || isLoadingUpdateTimeExtension
                || isLoading || isLcsCreatePending || isLcsUpdatePending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    deadline: form.getValues('deadline')?.toISOString?.(),
                    reason: form.getValues('reason'),
                    users: form.getValues('users')?.map((item: BasedUser) => item?.id) ?? [],
                    remind: castReminderSchemaToSaveReminderDTO(form.getValues('remind'))
                  });
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
