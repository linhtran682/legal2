import { createSignAndApproveFn } from '@/apis/service/document-review/signer';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormTextArea } from '@/components/commons/form_inputs/FormTextArea';
import { ModalCommon } from '@/components/commons/popups/modal/Modal';
import { GLOBAL_SPACING } from '@/constants/format';
import { ModuleFields } from '@/constants/general';
import { formInputSxProps } from '@/constants/theme';
import { ReminderPickerSubForm } from '@/features/reminder_template/reminder_picker/ReminderPickerSubForm';
import { LegalCheckSheetStatusCodeList } from '@/models/document-review/DocumentReviewDetail';
import { castSigningDTO, SignSchema } from '@/models/document-review/Signer';
import { UserProfileDTO } from '@/models/user/User';
import { getUserLabel } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import { Grid, InputLabel, Typography } from '@mui/material';
import { useMutation } from '@tanstack/react-query';
import { useEffect } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';


export interface SignApproveFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  documentReviewId?: number;
  lcsId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  initialValues?: any;
  // selectedDocuments?: BasedLegalDocument[];
  module?: number;
  sender?: any;
  isSigning?: boolean;
  defaultStatus?: string;
}
const SignApproveForm = (props: SignApproveFormProps) => {
  const {
    isOpen,
    setIsOpen,
    name,
    sender,
    lcsId,
    titlePopup = `DOCUMENT_REVIEW.popup.signApprove`,
    initialValues
  } = props;
  const { t } = useTranslation();

  const form = useForm({
    resolver: yupResolver(SignSchema),
    mode: 'onBlur'
  });

  useEffect(() => {

    // getStatusListQuery.refetch().then((res) => {
    //   const finishReviewStatus = res.data
    //     ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
    //       === removeVietnameseTones(defaultStatus).trim())
    //   finishReviewStatus?.id && form?.setValue?.('status', finishReviewStatus?.id);
    // })
    form?.setValue?.('status', LegalCheckSheetStatusCodeList.SIGN_DONE);
    initialValues?.userIds && form?.setValue?.('userIds', initialValues?.userIds);
  }, [initialValues])

  // const getStatusListQuery = useQuery({
  //   queryKey: ['document-review/get-status-list'],
  //   queryFn: async () => {
  //     const response = await getStatusList({
  //       modules: [ModuleFields.DOCUMENT_REVIEW.module],
  //       page: 0,
  //       size: 100,
  //       sortBy: StatusFieldNames.ID,
  //       orderBy: "ASC",
  //       active: 1
  //     });
  //     return response?.statusResponses || [];
  //   },
  //   placeholderData: prev => prev,
  //   enabled: false
  // });

  const { mutateAsync: createSignApproveAsync, isPending: isSignApprovePending } = useMutation({
    mutationFn: createSignAndApproveFn,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t(titlePopup),
      }));
      onCloseForm(true)
    },
  });

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSave = async (data: any) => {
    lcsId && (await createSignApproveAsync({
      lcsId: lcsId,
      request: castSigningDTO(data)
    }));
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm(false)}>
      <FormProvider {...form}>
        <Grid container className="form-wrapper" marginTop="20px">
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={{ ...formInputSxProps, paddingBottom: 0 }}
          >
            <Grid item width={"100%"}>
              <Typography fontWeight="bold">
                {t("DOCUMENT_REVIEW.field_name.documentName")}
              </Typography>
              <Typography>{name}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <InputLabel>{t(`DOCUMENT_REVIEW.popup.requester`)}</InputLabel>
              {sender && (
                <Typography>
                  {getUserLabel(sender)}
                </Typography>
              )}
            </Grid>



            {/* <Grid item width={"100%"}>
              <FormSelect
                control={form.control}
                name={'status'}
                label={t(`legalAdvice.requestAdditional.title.status`)}
                placeHolder={t(`legalAdvice.requestAdditional.title.status`)}
                options={
                  Object.entries(LegalCheckSheetStatusCodeList).map(([, v]) => {
                    return ({
                      id: v,
                      name: (LcsStatusLabels as any)?.[v]
                    })
                  }) ?? []
                }
                getOptionKey={(option) => option?.id}
                getOptionLabel={(option) => t(option?.name)}
                required
              />
            </Grid> */}

            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={'content'}
                label={t(`DOCUMENT_REVIEW.popup.content`)}
                placeHolder={t(`DOCUMENT_REVIEW.popup.content`)}
                minRows={3}
                required
              />
            </Grid>

            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={'userIds'}
                label={t(`DOCUMENT_REVIEW.popup.pic`)}
                placeholder={t(`DOCUMENT_REVIEW.popup.pic`)}
                minCharLength={1}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });
                  return response?.users ?? []
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? (option?.departmentName ?? '')
                  }`
                }
                required
                getOptionKey={(option) => option.id}
                keyQuery='queryAdvisor'
                isFocus
              />
            </Grid>
          </Grid>
          <Grid item>
            <ReminderPickerSubForm
              name={'remind'}
              module={ModuleFields.DOCUMENT_REVIEW.module}
              placeholder={t('menu.reminder')}
            />
          </Grid>
          <FormActionButtons
            formMode={"update"}
            loading={isSignApprovePending}
            onCancel={() => onCloseForm()}
            cancelConfirm={form.formState.isDirty}
            onSave={onSave}
          />
        </Grid>
      </FormProvider>
    </ModalCommon>
  )
}

export default SignApproveForm