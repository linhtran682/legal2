import { createEvaluateFn } from '@/apis/service/document-review/lcsEvaluation';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormTextArea } from '@/components/commons/form_inputs/FormTextArea';
import { ModalCommon } from '@/components/commons/popups/modal/Modal';
import { GLOBAL_SPACING } from '@/constants/format';
import { ModuleFields } from '@/constants/general';
import { formInputSxProps } from '@/constants/theme';
import { ReminderPickerSubForm } from '@/features/reminder_template/reminder_picker/ReminderPickerSubForm';
import { LegalCheckSheetStatusCodeList } from '@/models/document-review/DocumentReviewDetail';
import { castRequestEvaluateDTO, EvaluateSchema } from '@/models/document-review/LcsEvaluate';
import { UserProfileDTO } from '@/models/user/User';
import { getUserLabel } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import { Grid, InputLabel, Typography } from '@mui/material';
import { useMutation } from '@tanstack/react-query';
import { useEffect } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';


export interface EvaluateFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  documentReviewId?: number;
  lcsId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  initialValues?: any;
  // selectedDocuments?: BasedLegalDocument[];
  module?: number;
  sender?: any;
}
const EvaluateForm = (props: EvaluateFormProps) => {

  const {
    isOpen,
    setIsOpen,
    lcsId,
    name, sender, titlePopup = 'metadata.evaluation.title',
    initialValues
  } = props;
  const { t } = useTranslation();

  const form = useForm<any>({
    resolver: yupResolver(EvaluateSchema),
    mode: 'onBlur'
  });

  useEffect(() => {
    form?.setValue?.('status', LegalCheckSheetStatusCodeList.EVALUATED);
    initialValues?.userIds && form?.setValue?.('userIds', initialValues?.userIds);
  }, [initialValues]);

  const { mutateAsync: createEvaluateAsync, isPending } = useMutation({
    mutationFn: createEvaluateFn,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t(titlePopup),
      }));
      onCloseForm(true)
    },
  })

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSave = async (data: any) => {
    lcsId && (await createEvaluateAsync({
      lcsId: lcsId,
      request: castRequestEvaluateDTO(data)
    }))
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <FormProvider {...form}>
        <Grid container className="form-wrapper" marginTop="20px">
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={{ ...formInputSxProps, paddingBottom: 0 }}
          >

            <Grid item width={"100%"}>
              <Typography fontWeight="bold">
                {t("DOCUMENT_REVIEW.field_name.documentName")}
              </Typography>
              <Typography>{name}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <InputLabel >
                {t(`DOCUMENT_REVIEW.popup.requester`)}
              </InputLabel>
              {sender && (
                <Typography>
                  {getUserLabel(sender)}
                </Typography>
              )}
            </Grid>

            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={'content'}
                label={t(`feedbackLc.title.content`)}
                placeHolder={t(`feedbackLc.title.content`)}
                minRows={3}
                required
              />
            </Grid>
            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={'userIds'}
                label={t('legalAdvice.label.receiver')}
                placeholder={t('legalAdvice.label.receiver')}
                minCharLength={1}
                getOptions={async (keyword) => {
                  // if (!getLegalDepartmentQuery.data) return []
                  // const advisorIds = getAssignedPersonQuery?.data?.users?.map((user) => user.id) ?? [];
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                    // departmentIds: getLegalDepartmentQuery.data ? [getLegalDepartmentQuery.data] : []
                  });
                  return response?.users ?? []
                  // ?.map((user, index) => ({
                  //   ...user,
                  //   rank: advisorIds?.includes(user.id) ? index : 99999
                  // }))?.sort((first, second) => first.rank - second.rank)
                  // ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? (option?.departmentName ?? '')
                  }`
                }
                required
                getOptionKey={(option) => option.id}
                keyQuery='queryAdvisor'
                isFocus
              />
            </Grid>
          </Grid>
          <Grid item>
            <ReminderPickerSubForm
              name={'remind'}
              module={ModuleFields.DOCUMENT_REVIEW.module}
              placeholder={t('menu.reminder')}
            />
          </Grid>
        </Grid>
        <FormActionButtons
          formMode={"update"}
          loading={isPending}
          onCancel={() => onCloseForm()}
          cancelConfirm={form.formState.isDirty}
          onSave={onSave}
        />
      </FormProvider>
    </ModalCommon>
  )
}

export default EvaluateForm