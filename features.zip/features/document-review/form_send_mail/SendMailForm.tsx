import { sendMailLcs } from "@/apis/service/document-review/legalCheckSheet";
import { sendMailDocumentReview } from "@/apis/service/document-review/sendMail";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { EditorField } from "@/components/commons/EditorField/EditorField";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { SendMailRequestSchema } from "@/models/legal-advice/SendMail";
// import { SendMailRequestSchema } from '@/models/legal-advice/SendMail';
import { BasedUser } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, InputLabel, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { FC } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export interface SendMailFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  senderDocumentManagement?: BasedUser;
  lcsId?: number;
  isLcs?: boolean;
}

const SendMailForm: FC<SendMailFormProps> = (props) => {
  const {
    titlePopup = "legalAdvice.sendMail.title.titlePopup",
    isOpen = false,
    setIsOpen,
    documentReviewId,
    name,
    isLcs,
    lcsId,
    senderDocumentManagement,
  } = props;
  const [t] = useTranslation();
  // const appContext = useContext(AppContext);

  const form = useForm({
    resolver: yupResolver(SendMailRequestSchema),
    mode: "onBlur",
    // disabled: !appContext.meCanWrite,
  });

  const sendMailQuery = useMutation({
    mutationFn: sendMailDocumentReview,
    onSuccess: () => {
      toast.success(t("legalAdvice.messages.sendMailSuccess"));
      onCloseForm(true);
    },
  });
  const sendMailLcsQuery = useMutation({
    mutationFn: sendMailLcs,
    onSuccess: () => {
      toast.success(t("legalAdvice.messages.sendMailSuccess"));
      onCloseForm(true);
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSave = () => {
    !isLcs &&
      documentReviewId &&
      sendMailQuery.mutate({
        id: documentReviewId,
        request: {
          ...form.getValues(),
          receivers: form
            .getValues("receivers")
            ?.map((user: BasedUser) => user.id),
        },
      });
    isLcs &&
      lcsId &&
      sendMailLcsQuery.mutate({
        lcsId: lcsId,
        request: {
          ...form.getValues(),
          receivers: form
            .getValues("receivers")
            ?.map((user: BasedUser) => user.id),
        },
      });
  };
  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm(false)}
    >
      <Grid container className="form-wrapper">
        <FormProvider {...form}>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <Typography fontWeight="bold">
                    {t("DOCUMENT_REVIEW.field_name.documentName")}
                  </Typography>
                  <Typography>{name}</Typography>
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </InputLabel>
                {senderDocumentManagement && (
                  <Typography>
                    {getUserLabel(senderDocumentManagement)}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name="subject"
                  label={t("visitation.label.subject")}
                  placeHolder={t("visitation.label.subject")}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <EditorField
                  control={form.control}
                  name="content"
                  label={t("legalAdvice.sendMail.title.content")}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={"receivers"}
                  label={t("legalAdvice.label.receiver")}
                  placeholder={t("legalAdvice.label.receiver")}
                  getOptions={async (keyword) => {
                    const params: any = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);
                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option.department?.name ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="document-review/send-mail/users"
                  minCharLength={1}
                  required
                  isFocus
                />
              </Grid>
            </Grid>
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={sendMailQuery.isPending || sendMailLcsQuery.isPending}
            onCancel={() => onCloseForm()}
            cancelConfirm={form.formState.isDirty}
            onSave={onSave}
          />
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};

export default SendMailForm;
