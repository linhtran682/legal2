import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import { COLOR_TYPE } from '@/constants/color';
import useObserveElementSize from '@/hooks/useObserveElementSize';
import { DocumentReviewBodyReceive } from '@/models/document-review/DocumentReviewDetail';
import { Box } from '@mui/material';
import { useTranslation } from 'react-i18next';

interface OverviewHeaderProps {
  initialValueReceive?: DocumentReviewBodyReceive;
  handleUpdateBookMeeting?: (params: any) => void;
  isMeeting?: boolean;
  disabled?: boolean;
  isLoading?: boolean;
  scrollToTab: (tab: number) => void;
}

const OverviewHeader = (props: OverviewHeaderProps) => {
  const { t } = useTranslation();
  // const [isBooked, setIsBooked] = useState(false);
  // const [ownRole, setOwnRole] = useState<number[]>([]);
  // const appContext = useContext(AppContext);
  const { scrollToTab } = props;


  // useEffect(() => {
  //   if (props.initialValueReceive) {
  //     setIsBooked(!!props?.initialValueReceive?.bookingFlag);
  //   }
  //   if (
  //     props.initialValueReceive &&
  //     props.initialValueReceive?.userLastActionAndRoleResponse?.userLastActionAndRoleList?.length
  //   ) {
  //     const { userLastActionAndRoleResponse: { userLastActionAndRoleList } } = props.initialValueReceive;
  //     const roleList = userLastActionAndRoleList?.map((ele) => ele.role)
  //     setOwnRole(roleList);
  //   } else {
  //     setOwnRole([]);
  //   }

  // }, [props.initialValueReceive]);

  // const isStatusDone = props?.initialValueReceive?.status?.name === DONE_STATUS;

  // const canBookMeeting = (ownRole.includes(1)
  //   || ownRole.includes(2)
  //   || ownRole.includes(3)
  //   || ownRole.includes(4)
  //   || ownRole.includes(5)
  //   || ownRole.includes(8)) && !isStatusDone

  // const disableBookMeeting = !appContext.meCanWrite ||
  //   (!canBookMeeting)
  //   || props.isLoading

  const { elementRef, size } = useObserveElementSize();

  const responsiveSx = {
    minWidth: 170,
    flex: 1
  }
  return (
    <Box
      ref={elementRef}
      sx={{
        display: size.width <= 1172 ? 'grid' : 'flex',
        p: 2, backgroundColor: 'white',
        mb: 2,
        gridTemplateColumns: `repeat(auto-fill, minmax(170px, 1fr))`
      }}
    >
      {/* <Stack sx={{ p: 2, backgroundColor: 'white' }} direction={"row"} flexWrap={'wrap'}> */}
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={(props.initialValueReceive?.meetingNumber as number) > 0}
          labelColor={COLOR_TYPE.BLUE.BLUE6}
          disabled
          label={`${t("LEGISLATION.evaluateField.meeting")}
          ${(props.initialValueReceive?.meetingNumber as number) > 0
              ? ` (${props.initialValueReceive?.meetingNumber})`
              : ""
            }`}
          onLabelClick={() => scrollToTab(6)}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          disabled
          checked={!!props.initialValueReceive?.confirmFlag}
          label={t("DOCUMENT_REVIEW.overview.confirmReview")}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          disabled
          checked={!!props.initialValueReceive?.inspectionNumber}
          // label={t("DOCUMENT_REVIEW.overview.completeReview")}
          label={`${t("DOCUMENT_REVIEW.overview.completeReview")}
          ${(props.initialValueReceive?.requestInspectionNumber as number) > 0
              ? ` (${props.initialValueReceive?.inspectionNumber}/${props.initialValueReceive?.requestInspectionNumber})`
              : ""
            }`}

        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.confirmLCSFlag}
          disabled
          label={t("DOCUMENT_REVIEW.overview.confirmLCS")}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.evaluateNumber}
          disabled
          // label={t("DOCUMENT_REVIEW.overview.completeLCS")}
          label={`${t("DOCUMENT_REVIEW.overview.completeLCS")}`}
        // label={`${t("DOCUMENT_REVIEW.overview.completeLCS")}
        // ${(props.initialValueReceive?.evaluateNumber as number) > 0
        //     ? ` (${props.initialValueReceive?.evaluateNumber})`
        //     : ""
        //   }
        //   `}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.esignSigned}
          disabled
          label={t("DOCUMENT_REVIEW.overview.approved")}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.supervisorInspectionNumber}
          disabled
          // label={t("DOCUMENT_REVIEW.overview.supervisorReview")}
          label={`${t("DOCUMENT_REVIEW.overview.supervisorReview")}
          ${(props.initialValueReceive?.requestSupervisorInspectionNumber as number) > 0
              ? ` (${props.initialValueReceive?.supervisorInspectionNumber}/${props.initialValueReceive?.requestSupervisorInspectionNumber})`
              : ""
            }`}
        />
      </Box>
      {/* </Stack > */}
    </Box>
  )
}

export default OverviewHeader