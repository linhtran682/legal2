import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { DocumentReviewInspectionItem } from "@/models/document-review/Inspection";
import { LegalAdviceDetailFields } from "@/models/legal-advice/LegalAdviceDetail";
import { getUserLabel } from "@/utils";
import { Box, Grid, InputLabel, Typography } from "@mui/material";
import { FC, useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";


interface ReviewListItemProps {
  inspection: DocumentReviewInspectionItem;
  onEditClick?: () => void;
}
const ReviewListItem: FC<ReviewListItemProps> = (props) => {
  const { inspection } = props
  const form = useForm()
  const [t] = useTranslation();
  const [files, setFiles] = useState<any>([]);


  const resetForm = (newAdvise: DocumentReviewInspectionItem) => {
    if (newAdvise?.attachments?.length) {
      setFiles(
        newAdvise.attachments?.map((item) => {
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        })
      );
    }
    form?.reset?.({
      advisor: newAdvise.user.id,
      content: newAdvise.content
    })
  }

  useEffect(() => {
    resetForm(inspection)
  }, [inspection])

  return <Grid
    container
    direction={"column"}
    className='form-sub-section-wrapper'
    rowGap={GLOBAL_SPACING}
    position={'relative'}
    sx={{
      backgroundColor: inspection.inspectedBySupervisor ? COLOR_TYPE.BLUE.BLUE06 : undefined
    }}
  >
    <Grid
      item
      xs={12}
      display={'flex'}
    >
      <Box flex={1}>
        <InputLabel>{inspection.inspectedBySupervisor
          ? t("DOCUMENT_REVIEW.popup.supervisorReviewer")
          : t("DOCUMENT_REVIEW.popup.reviewer")}</InputLabel>
        <Typography>{getUserLabel(inspection.user)}</Typography>
      </Box>
      {/* {inspection.editAvailable && <IconButton onClick={onEditClick} sx={{ height: 'fit-content' }}>
        <EditNoteRoundedIcon />
      </IconButton>} */}
    </Grid>
    <Grid item width={"100%"}>
      <FormTextArea
        control={form.control}
        name={LegalAdviceDetailFields.CONTENT}
        label={t("DOCUMENT_REVIEW.popup.reviewContent")}
        placeHolder={t(`legalAdvice.fields.${LegalAdviceDetailFields.CONTENT}`)}
        // required
        minRows={2}
        disabled
      />
    </Grid>
    {files?.length ? <Grid item width={"100%"}>
      <DropPreviewFileUploadComponent
        preview
        disabled
        inputId={`file-input-${inspection.id}`}
        files={files}
        setFiles={setFiles}
        title={t(`legalAdvice.label.${LegalAdviceDetailFields.ATTACHMENTS}`)}
      />
    </Grid> : null}
  </Grid>
}

export default ReviewListItem