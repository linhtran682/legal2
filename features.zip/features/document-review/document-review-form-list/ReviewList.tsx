import { getInspectionList } from "@/apis/service/document-review/inspection";
import { GLOBAL_SPACING } from "@/constants/format";
import { DocumentReviewInspectionItem } from "@/models/document-review/Inspection";
import { Box } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { FC, useEffect, useState } from "react";
import { DocumentReviewConductionForm } from "../form_document_review_conduction/DocumentReviewConductionForm";
import ReviewListItem from "./ReviewListItem";
import { DocumentReviewBodyReceive } from "@/models/document-review/DocumentReviewDetail";
import { DocumentReviewConductionSupervisorForm } from "../form_document_review_conduction_supervisor/DocumentReviewConductionSupervisorForm";

interface ReviewListProps {
  documentReviewId: number;
  documentReview: DocumentReviewBodyReceive;
}

export const INSPECTION_LIST_QUERY_KEY = "get-document-review-inspection-list"

const ReviewList: FC<ReviewListProps> = (props) => {
  const { documentReviewId, documentReview } = props;
  const [popupVisible, setPopupVisible] = useState(false);
  const [inspection, setInspection] = useState<
    DocumentReviewInspectionItem | undefined
  >(undefined);

  useEffect(() => {
    documentReviewId && getAdviseListQuery.refetch();
  }, [documentReviewId]);

  const getAdviseListQuery = useQuery({
    queryKey: [INSPECTION_LIST_QUERY_KEY, documentReviewId],
    queryFn: () => getInspectionList(documentReviewId),
    enabled: !!documentReviewId,
  });

  const handleEditClick = (inspection: DocumentReviewInspectionItem) => {
    setInspection(inspection);
    setPopupVisible(true);
  };

  const onPopupClose = () => {
    setPopupVisible(false);
    setInspection(undefined);
    getAdviseListQuery?.refetch();
  };

  return getAdviseListQuery?.data?.responses?.length ? (
    <Box display={"flex"} flexDirection={"column"} gap={GLOBAL_SPACING}>
      {(getAdviseListQuery?.data?.responses ?? [])?.map(
        (inspection: any) => (
          <ReviewListItem
            key={inspection.id.toString()}
            onEditClick={() => handleEditClick(inspection)}
            inspection={inspection}
          />
        )
      )}
      {(popupVisible && !inspection?.inspectedBySupervisor) && (
        <DocumentReviewConductionForm
          documentReviewId={documentReviewId}
          name={documentReview.documentName}
          isOpen={popupVisible}
          inspectionId={inspection?.id}
          inspection={inspection}
          setIsOpen={onPopupClose}
          senderDocumentManagement={inspection?.user}
          refetchQueryKeys={[INSPECTION_LIST_QUERY_KEY]}
          initialDocumentReview={documentReview}
        />
      )}
      {(popupVisible && inspection?.inspectedBySupervisor || documentReview?.isSupervisor) && (
        <DocumentReviewConductionSupervisorForm
          documentReviewId={documentReviewId}
          name={documentReview.documentName}
          isOpen={popupVisible}
          inspectionId={inspection?.id}
          inspection={inspection}
          setIsOpen={onPopupClose}
          senderDocumentManagement={inspection?.user}
          refetchQueryKeys={[INSPECTION_LIST_QUERY_KEY]}
          initialDocumentReview={documentReview}
        />
      )}
    </Box>
  ) : null;
};

export default ReviewList;
