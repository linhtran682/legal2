import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GLOBAL_SPACING } from "@/constants/format";
import { DocumentReviewInspectionItem } from "@/models/document-review/Inspection";
import { Grid, InputLabel, TextField, Typography } from "@mui/material";
import { uniqueId } from "lodash";
import { useTranslation } from "react-i18next";

type TypePropsListInspection = {
  data?: DocumentReviewInspectionItem[];
};

export const ListInspection = (props: TypePropsListInspection) => {
  const { data } = props;
  const { t } = useTranslation();
  return (
    <>
      {data?.map((item) => {
        const attachmentsItem = item.attachments?.map((item: any) => {
          return {
            name: item?.fileName,
            path: item?.filePath,
            id: item?.fileId,
            uploadDate: item?.uploadDate,
          };
        });
        return (
          <Grid
            container
            direction={"column"}
            className='form-sub-section-wrapper'
            rowGap={GLOBAL_SPACING}
            position={'relative'}
            key={uniqueId("list_inspection_item_")}>
            <Grid key={item?.id} item width={"100%"}>
              <InputLabel >
                {item.inspectedBySupervisor
                  ? t("DOCUMENT_REVIEW.popup.supervisorReviewer")
                  : t("DOCUMENT_REVIEW.popup.reviewer")}
              </InputLabel>
              <Typography>{`${item?.user?.name} (${item?.user?.email}) - ${item?.department?.name}`}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <InputLabel >
                {t("DOCUMENT_REVIEW.popup.reviewContent")}
              </InputLabel>
              <TextField
                value={item?.content}
                label={""}
                placeholder={t("DOCUMENT_REVIEW.popup.reviewContent")}
                minRows={3}
                size="small"
                multiline
                fullWidth
                disabled
              />
            </Grid>
            <Grid item width={"100%"}>
              <DropPreviewFileUploadComponent
                files={attachmentsItem as any}
                setFiles={() => { }}
                preview
                disabled
                inputId={`file-input-${item?.id}`}
              />
            </Grid>
          </Grid>
        );
      })}
    </>
  );
};
