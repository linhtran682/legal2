import { createInspectionFeedbackMutationFn, getInspectionList } from "@/apis/service/document-review/inspection";
import { getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleFields, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { DocumentReviewStatusList } from "@/models/document-review/DocumentReviewDetail";
import { castInspectionFeedbackDTO, InspectionFeedbackSchema, InspectionFieldNames } from "@/models/document-review/Inspection";
import {
  AdvisorLegalAdviceSchemaI
} from "@/models/legal-advice/AdvisorLegalAdvice";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUserLabel, removeVietnameseTones } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { INSPECTION_LIST_QUERY_KEY } from "../document-review-form-list/ReviewList";
import { ListInspection } from "./ListInspection";

const initialEmptyValue: AdvisorLegalAdviceSchemaI = {
  [InspectionFieldNames.CONTENT]: "",
  [InspectionFieldNames.USERS]: [],
  [InspectionFieldNames.FINISH]: false,
  [InspectionFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: AdvisorLegalAdviceSchemaI;
  documentReviewId?: number;
  adviseId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  isFeedBack?: boolean;
  isSuperVisorAdvisor?: boolean;
  name?: string;
  module?: number;
  minDateAdvisor?: Date | undefined;
  advise?: any;
  senderDocumentManagement?: any;
}

export const DocumentReviewConductionFeedbackForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = 'DOCUMENT_REVIEW.popup.reviewFeedback',
    initialValue = initialEmptyValue,
    documentReviewId,
    isOpen = false,
    setIsOpen,
    isFeedBack = false,
    module = Module.get(ModuleKeys.ADVISE),
    minDateAdvisor = undefined,
    senderDocumentManagement,
    name
  } = props;
  const [files, setFiles] = useState<any>([]);
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(
      InspectionFeedbackSchema
    ),
    defaultValues: initialValue,
  });



  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list/feedback-review'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.ID,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: false
  });

  const { data: listInspectionData, isFetching: isLoadingInspectionList } = useQuery({
    queryKey: [INSPECTION_LIST_QUERY_KEY, documentReviewId],
    queryFn: () => getInspectionList(documentReviewId as number),
    enabled: !!documentReviewId,
  });

  useEffect(() => {
    initialValue?.deadlineNew && form?.setValue?.(InspectionFieldNames.DEADLINE_NEW, initialValue?.deadlineNew)
  }, [initialValue])

  useEffect(() => {
    getStatusListQuery.refetch().then((res) => {
      const reviewFeedbackStatus = res.data
        ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
          === removeVietnameseTones(DocumentReviewStatusList.REVIEW_FEEDBACK).trim())
      reviewFeedbackStatus?.id && form?.setValue?.('status', reviewFeedbackStatus?.id);
    });
    if (listInspectionData?.responses?.length) {
      const reviewUsers = listInspectionData?.responses?.map((res: any) => res?.user);
      reviewUsers?.length && form?.setValue?.('userIds', reviewUsers);
    }
  }, [listInspectionData])

  const { mutateAsync: createInspectionFeedbackAsync, isPending } = useMutation({
    mutationFn: createInspectionFeedbackMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      // refetchQueryKeys?.length && queryClient.invalidateQueries({ queryKey: refetchQueryKeys });
      onCloseForm(true);
    },
  })

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    documentReviewId && (await createInspectionFeedbackAsync({
      id: documentReviewId,
      request: data,
    }));
  };

  if (isLoadingInspectionList) return;

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel >
                  {t(`feedbackLc.title.responder`)}
                </InputLabel>
                <Typography>
                  {getUserLabel(senderDocumentManagement)}
                </Typography>
              </Grid>
              {listInspectionData && (
                <ListInspection data={listInspectionData.responses} />
              )}

              {/* <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={InspectionFieldNames.STATUS}
                  label={t(`legalAdvice.advisorLegalAdvice.title.status`)}
                  placeholder={t(
                    'legalAdvice.advisorLegalAdvice.title.status'

                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.ADVISE_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                />
              </Grid> */}
              {false && <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView
                  preview={false}
                  files={files}
                  setFiles={setFiles}
                  title={t(`legalAdvice.feedbackAdvice.title.file`)}
                  inputId="feedbackReview"
                />
              </Grid>}

              <Grid item width={"100%"}>
                <DateTimeInput
                  name={InspectionFieldNames.DEADLINE_NEW}
                  control={form.control}
                  label={t(
                    `DOCUMENT_REVIEW.popup.newDeadline`
                  )}
                  placeholder={t(
                    `DOCUMENT_REVIEW.popup.newDeadline`
                  )}
                  minDate={isFeedBack ? minDateAdvisor : undefined}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={InspectionFieldNames.REASON}
                  label={t(`DOCUMENT_REVIEW.popup.reason`)}
                  placeHolder={t(
                    `DOCUMENT_REVIEW.popup.reason`
                  )}
                  minRows={3}
                  required
                />
              </Grid>


              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={InspectionFieldNames.USERS}
                  label={t('DOCUMENT_REVIEW.labels.receivers')}
                  placeholder={t('common.place_holder.enter_name_code')}
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option?.name ?? ""} (${option?.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"advisorLegalAdvice/queryUser"}
                  isFocus
                  required
                />
              </Grid>


            </Grid>
            <ReminderPickerSubForm
              name={InspectionFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave={`common.button.${isFeedBack ? "verify" : "send"}`}
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  const attachmentIds: number[] = files?.map((item: any) => item.id) ?? []

                  onSubmit(
                    castInspectionFeedbackDTO({
                      ...form.getValues(),
                      attachmentIds,
                    })
                  );
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon >
  );
};
