import { createLcsInformationRequestFn, useCreateRequestAdditional } from "@/apis/service/document-review/requestAdditional";
import { getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  Module,
  ModuleFields,
  ModuleKeys
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { DocumentReviewStatusList, LegalCheckSheetStatusCodeList } from "@/models/document-review/DocumentReviewDetail";
import {
  RequestAdditionalFieldNames,
  RequestAdditionalSchema,
  RequestAdditionalSchemaI,
} from "@/models/document-review/RequestAdditional";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUserLabel, removeVietnameseTones } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const initialEmptyValue: RequestAdditionalSchemaI = {
  // [RequestAdditionalFieldNames.STATUS]: LegalAdviceStatus.get(
  //   LegalAdviceStatusKey.REQUEST_ADDITIONAL
  // ),
  [RequestAdditionalFieldNames.DEADLINE]: "",
  [RequestAdditionalFieldNames.CONTENT]: "",
  [RequestAdditionalFieldNames.USERS]: [],
  [RequestAdditionalFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestAdditionalSchemaI;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  lcsId?: number;
  isLcs?: boolean;
  maxDate?: string;
}

export const RequestAdditionalForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.requestAdditional.title.titlePopup",
    initialValue = initialEmptyValue,
    documentReviewId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DOCUMENT),
    senderDocumentManagement,
    isLcs,
    lcsId,
    maxDate
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(RequestAdditionalSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createRequestApproval, isPending } =
    useCreateRequestAdditional({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const { mutateAsync: createLcsInformationRequest, isPending: isLcsPending } = useMutation({
    mutationFn: createLcsInformationRequestFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm(true);
    },
  })

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { users, ...restData } = data;
    (documentReviewId && !isLcs) && (await createRequestApproval({
      documentReviewId,
      data: { ...restData, status: +data?.status },
    }));
    (lcsId && isLcs) && (await createLcsInformationRequest({
      lcsId,
      request: { ...restData, status: +data?.status },
    }));
  };

  useEffect(() => {
    !isLcs && getStatusListQuery.refetch().then((res) => {
      const requestAdditionalStatus = res.data
        ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
          === removeVietnameseTones(DocumentReviewStatusList.REQUEST_INFORMATION).trim())
      requestAdditionalStatus?.id && form?.setValue?.('status', requestAdditionalStatus?.id);
    })
    isLcs && form?.setValue?.('status', LegalCheckSheetStatusCodeList.REQUEST_INFORMATION);
    form?.setValue?.('users', initialValue?.userIds)
  }, [initialValue])

  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.ID,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: false
  });

  useEffect(() => {
    if (initialValue?.users) {
      form.reset({
        ...initialEmptyValue,
        users: initialValue?.users,
      });
    }
  }, [initialValue?.users]);

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </InputLabel>
                {senderDocumentManagement && (
                  <Typography>
                    {getUserLabel(senderDocumentManagement)}
                  </Typography>
                )}
              </Grid>
              {/* <Grid item width={"100%"}>
                {isLcs
                  ? <FormSelect
                    control={form.control}
                    name={'status'}
                    label={t(`legalAdvice.requestAdditional.title.status`)}
                    placeHolder={t(`legalAdvice.requestAdditional.title.status`)}
                    options={
                      Object.entries(LegalCheckSheetStatusCodeList).map(([, v]) => {
                        return ({
                          id: v,
                          name: (LcsStatusLabels as any)?.[v]
                        })
                      }) ?? []
                    }
                    getOptionKey={(option) => option?.id}
                    getOptionLabel={(option) => t(option?.name)}
                    disabled
                    required
                  />
                  : <FormAsyncSelect
                    control={form.control}
                    name={RequestAdditionalFieldNames.STATUS}
                    label={t(`legalAdvice.requestAdditional.title.status`)}
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    keyQuery={"status-query"}
                    getOptions={async (keyword) => {
                      if (typeof keyword == "string") {
                        const response = await getStatusList({
                          name: keyword,
                          modules: [ModuleFields.DOCUMENT_REVIEW.module],
                          page: 0,
                          size: 100,
                          sortBy: StatusFieldNames.NAME,
                          orderBy: "ASC",
                          active: 1
                        });

                        return response?.statusResponses || [];
                      } else {
                        if (keyword?.length && keyword.length > 0) {
                          return getStatus(Number(keyword[0])).then((value) =>
                            value ? [value] : []
                          );
                        }
                      }

                      return [] as StatusDTO[];
                    }}
                    getOptionKey={(option) => option.id.toString()}
                    getOptionLabel={(option) => option.name}
                    required
                    disabled
                  />}
              </Grid> */}
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestAdditionalFieldNames.DEADLINE}
                  control={form.control}
                  placeholder="dd/mm/yyyy"
                  label={t(`legalAdvice.requestAdditional.title.deadline`)}
                  required
                  maxDate={maxDate ? new Date(maxDate) : undefined}
                // minDate={new Date()}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestAdditionalFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.requestAdditional.title.${RequestAdditionalFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.requestAdditional.placeHolder.${RequestAdditionalFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={RequestAdditionalFieldNames.USERS}
                    disabled
                    label={t("legalAdvice.forwardLegalAdvice.title.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const selectedDepartments = form.getValues("departments");
                      if (selectedDepartments?.length) {
                        params.departmentIds = selectedDepartments;
                      }
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option?.name ?? ""} (${option?.email ?? ""}) - ${option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"requestAdditional/queryUser"}
                    isFocus
                    // disabled
                    required
                  />
                </Grid>
              </Grid>

            </Grid>
            <ReminderPickerSubForm
              name={RequestAdditionalFieldNames.REMIND}
              module={module}
              placeholder={t('menu.reminder')}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isLcsPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                        form.getValues().remind
                      )
                      : undefined,
                  });
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
