import { useCreateRequestVendor } from "@/apis/service/document-review/requestVendorReview";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleFields, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { DocumentReviewStatusList } from "@/models/document-review/DocumentReviewDetail";
import {
  RequestVendorFieldNames,
  RequestVendorSchema,
  RequestVendorSchemaI,
} from "@/models/document-review/RequestVendorReview";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const initialEmptyValue: RequestVendorSchemaI = {
  [RequestVendorFieldNames.DEADLINE]: "",
  [RequestVendorFieldNames.USERS]: [],
  [RequestVendorFieldNames.REMIND]: undefined,
};

export interface RequestVendorTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestVendorSchemaI;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  maxDateReturnAdvice?: Date | undefined;
  senderDocumentManagement?: any;
  defaultStatus?: string
}

export const RequestVendorReviewForm = (props: RequestVendorTypeFormProps) => {
  const {
    titlePopup = "DOCUMENT_REVIEW.popup.requestVendor",
    initialValue = initialEmptyValue,
    documentReviewId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DOCUMENT),
    maxDateReturnAdvice = undefined,
    senderDocumentManagement,
    defaultStatus = DocumentReviewStatusList.REQUEST_VENDOR_REVIEW!
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    initialValue?.userIds && form?.setValue?.(RequestVendorFieldNames.USERS, initialValue?.userIds ?? []);
  }, [initialValue])

  const form = useForm<any>({
    resolver: yupResolver(RequestVendorSchema),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    modules: ModuleFields.DOCUMENT_REVIEW.module,
    queryKey: "DOCUMENT_REVIEW_REQUEST_VENDOR",
  });

  const { mutateAsync: createRequestVender, isPending } =
    useCreateRequestVendor({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { user, ...restData } = data;
    await createRequestVender({
      documentReviewId,
      data: { ...restData, status: +data?.status },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel >
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </InputLabel>
                {senderDocumentManagement && (
                  <Typography>
                    {getUserLabel(senderDocumentManagement)}
                  </Typography>
                )}
              </Grid>
              {/* <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={RequestVendorFieldNames.STATUS}
                  label={t(`legalAdvice.requestVendor.title.status`)}
                  keyQuery={"status-query-requestVendor"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.ADVISE_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }
                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option?.id?.toString()}
                  getOptionLabel={(option) => option?.name}
                  required
                />
              </Grid> */}
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestVendorFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.requestVendor.title.deadline`)}
                  required
                  maxDate={maxDateReturnAdvice}
                  placeholder="dd/mm/yyyy"
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={RequestVendorFieldNames.USERS}
                    label={t("legalAdvice.requestVendor.title.receiver")}
                    placeholder={t('common.place_holder.enter_name_code')}
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"requestVendor/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={RequestVendorFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    userIds: form
                      .getValues()
                      .userIds?.map((user: any) => user?.id),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                        form.getValues().remind
                      )
                      : undefined,
                  });
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
