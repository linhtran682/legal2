'use client'
import { COLOR_TYPE } from '@/constants/color';
import { EXPECTED_DATE_TIME_LOCALE } from '@/constants/format';
import { LEGAL_ADVICE_ROOT_PATH } from '@/constants/paths';
import { LANGUAGES } from '@/locales/config-translation';
import { Avatar, List, ListItem, ListItemAvatar, ListItemText, Stack, styled, Tooltip, tooltipClasses, TooltipProps } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { FC, Fragment, ReactElement, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { getTooltip } from '../search-panel/SearchPanel';
import { getAllHierarchyById } from '@/apis/service/document-review/documentReview';

const CustomizedTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 400,
    minWidth: 360,
    fontSize: theme.typography.pxToRem(12),
    border: `1px solid ${COLOR_TYPE.TOYOTA.TOYOTA5}`,
  },
}));


interface DocumentReviewTableTooltipProps {
  children: ReactElement;
  documentReviewId: string | number;
  requestName: string;
}
const DocumentReviewTableTooltip: FC<DocumentReviewTableTooltipProps> = (props) => {
  const { children, documentReviewId, requestName } = props;
  const { i18n } = useTranslation();
  const { isFetching, data, refetch } = useQuery({
    queryKey: ['document-review/getHierarchy', documentReviewId],
    queryFn: () => getAllHierarchyById({ id: documentReviewId }).catch(() => ({})),
    enabled: false
  })

  const handleOpen = () => {
    refetch();
  };
  const isEnglish = i18n.language === LANGUAGES.ENGLISH
  const renderTooltipContent = useCallback(() => {
    if (isFetching || !data?.children?.length) return null;
    return <List sx={{ padding: '4px 8px' }}>
      <ListItem disablePadding dense alignItems='flex-start'>
        {data?.createdUser && (
          <ListItemAvatar>
            <Tooltip title={getTooltip(data?.createdUser, isEnglish)}>
              <Avatar
                key={data?.createdUser?.id}
                alt={data?.createdUser?.name}
                src={data?.createdUser?.imgUrl}
                sx={{ width: 40, height: 40 }}
              />
            </Tooltip>
          </ListItemAvatar>
        )}
        <ListItemText
          primary={
            <Link rel="noopener noreferrer" target="_blank" href={`/${LEGAL_ADVICE_ROOT_PATH}/update/${data?.legalAdviceId}`} passHref>
              {data?.legalAdviceName}
            </Link>}
          secondary={data?.createdDate ? Intl.DateTimeFormat(
            EXPECTED_DATE_TIME_LOCALE,
            {
              dateStyle: "short",
              timeStyle: "short",
            }
          ).format(new Date(data?.createdDate)) : null}
          primaryTypographyProps={{
            variant: "h5",
            sx: {
              overflow: "hidden",
              textOverflow: "ellipsis",
              display: "-webkit-box",
              WebkitLineClamp: "2",
              WebkitBoxOrient: "vertical",
              title: data?.legalAdviceName,
            },
          }}
        />
      </ListItem>
      <ListItem dense sx={{ justifyContent: 'space-between' }}>
        <ListItemAvatar>
          <Stack direction={'row'} gap={0.5}>
            {data?.receiverUsers?.map((person: any) => (
              <Tooltip title={getTooltip(person, isEnglish)} key={person.id}>
                <Avatar
                  alt={person.name}
                  src={person?.avatarUrl}
                  sx={{ width: 32, height: 32, }}
                />
              </Tooltip>
            ))}
          </Stack>
        </ListItemAvatar>
        <Link rel="noopener noreferrer" target="_blank" href={`/${LEGAL_ADVICE_ROOT_PATH}/update/${data?.legalAdviceId}`} passHref>
          <ListItemText primary={data?.status?.name} sx={{ cursor: 'pointer', textAlign: 'right', color: '#007AFF', textDecorationLine: 'underline' }} />
        </Link>
      </ListItem>
      {(data?.children ?? []).map((child: any, index: number) => (
        <Fragment key={child.id}>
          <ListItem key={child.id} dense>
            <ListItemText
              primary={`Yêu cầu kiểm tra lần ${index + 2}`}
            />
          </ListItem>
          <ListItem key={child.id} dense sx={{ justifyContent: 'space-between' }}>
            <ListItemAvatar>
              <Stack direction={'row'} gap={0.25}>
                {child?.receiverUsers?.map((person: any) => (
                  <Tooltip title={getTooltip(person, isEnglish)} key={person.id}><Avatar
                    alt={person?.name}
                    src={person?.avatarUrl}
                    sx={{ width: 24, height: 24 }}
                  />
                  </Tooltip>
                ))}
              </Stack>
            </ListItemAvatar>
            <Link rel="noopener noreferrer" target="_blank" href={`/${LEGAL_ADVICE_ROOT_PATH}/update/${child?.legalAdviceId}`} passHref>
              <ListItemText
                primary={`Lần ${index + 2}: ${child?.status?.name}`}
                sx={{ textAlign: 'right', color: COLOR_TYPE.BLUE.BLUE6, textDecorationLine: 'underline', cursor: 'pointer', }}
              /></Link>
          </ListItem>
        </Fragment>
      ))}
    </List>
  }, [isFetching, data])
  return (
    <CustomizedTooltip
      title={renderTooltipContent()}
      placement='left'
      onOpen={handleOpen}
    >
      <Tooltip placement='bottom-start' title={data?.children?.length ? null : requestName}>
        {children}
      </Tooltip>
    </CustomizedTooltip>
  )
}

export default DocumentReviewTableTooltip