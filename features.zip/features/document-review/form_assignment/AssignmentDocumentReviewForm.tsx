import { getDepartmentHeads, getLegalDepartments } from "@/apis/service/department/department";
import { createAssignmentDocumentReviewMutationFn, createAssignmentLcsMutationFn } from "@/apis/service/document-review/assignmentDocumentReview";
import { getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  Module,
  ModuleFields,
  ModuleKeys
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  AssignmentDocumentReviewFieldNames,
  AssignmentDocumentReviewSchema,
  AssignmentDocumentReviewSchemaI,
  castAssignmentDocumentReviewRequestSchemaToDTO
} from "@/models/document-review/AssignmentDocumentReview";
import { DocumentReviewBodyReceive, DocumentReviewStatusList, LegalCheckSheetStatusCodeList } from "@/models/document-review/DocumentReviewDetail";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser } from "@/models/user/User";
import { getUserLabel, removeVietnameseTones } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const initialEmptyValue: AssignmentDocumentReviewSchemaI = {
  [AssignmentDocumentReviewFieldNames.CONTENT]: "",
  [AssignmentDocumentReviewFieldNames.USERS_IDS]: [],
  [AssignmentDocumentReviewFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: AssignmentDocumentReviewSchemaI;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  lcsId?: number;
  isLcs?: boolean;
  documentReview?: DocumentReviewBodyReceive;
}

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}

export const AssignmentDocumentReviewForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.assignment.title.titlePopup",
    initialValue = initialEmptyValue,
    documentReviewId,
    isOpen = false,
    setIsOpen,
    name,
    isLcs,
    lcsId,
    module = Module.get(ModuleKeys.DOCUMENT),
    senderDocumentManagement,
    documentReview
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(AssignmentDocumentReviewSchema),
    defaultValues: initialValue,
  });

  useEffect(() => {
    getStatusListQuery.refetch().then((res) => {
      const finishReviewStatus = res.data
        ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
          === removeVietnameseTones(DocumentReviewStatusList.ASSIGNMENT).trim())
      if (!isLcs) {
        finishReviewStatus?.id && form?.setValue?.('status', finishReviewStatus?.id);
      } else {
        form?.setValue?.('status', LegalCheckSheetStatusCodeList.ASSIGNMENT);
      }
    })
  }, [])


  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.ID,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: false
  });

  const assignmentDocumentReviewMutation = useMutation({
    mutationFn: createAssignmentDocumentReviewMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("legalAdvice.assignment.title.titlePopup"),
        })
      );
      onCloseForm(true);
    },
  });
  const assignmentLcsMutation = useMutation({
    mutationFn: createAssignmentLcsMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("legalAdvice.assignment.title.titlePopup"),
        })
      );
      onCloseForm(true);
    },
  });

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["legal-advice/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) { }
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const getDepartmentHeadQuery = useQuery({
    queryKey: ['document-review/get-department-heads'],
    queryFn: () => getDepartmentHeads(getLegalDepartmentQuery?.data as string),
    placeholderData: prev => prev,
    enabled: !!getLegalDepartmentQuery?.data?.length
  })

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    (documentReviewId && !isLcs) && (await assignmentDocumentReviewMutation.mutateAsync({
      documentReviewId,
      data,
    }));
    (!!lcsId && isLcs) && (await assignmentLcsMutation.mutateAsync({
      lcsId,
      data,
    }));
  };

  const excludedIds = useMemo(() => {
    const list = [];
    if (!!documentReview?.checkDeptHeadFlag && getDepartmentHeadQuery?.data?.deptHead?.id) {
      list.push(getDepartmentHeadQuery?.data?.deptHead?.id)
    }
    if (!!documentReview?.checkDivisionFlag && getDepartmentHeadQuery?.data?.division?.id) {
      list.push(getDepartmentHeadQuery?.data?.division?.id);
    }
    if (documentReview?.assignUsers?.length) {
      list.push(...(
        documentReview?.assignUsers?.map((ele) => ele?.id) ?? []
      ));
    }
    if (documentReview?.receiverUsers?.length) {
      list.push(...(
        documentReview?.receiverUsers?.map((ele) => ele?.id) ?? []
      ));
    }
    if (documentReview?.responsibleUsers) {
      list.push(...(
        documentReview?.responsibleUsers?.map((ele) => ele?.id) ?? []
      ));
    }
    if (documentReview?.pic) {
      list.push(documentReview?.pic?.id);
    }
    return list;
  }, [documentReview])

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </InputLabel>
                {senderDocumentManagement && (
                  <Typography>
                    {getUserLabel(senderDocumentManagement)}
                  </Typography>
                )}
              </Grid>
              {/* {isLcs && <Grid item width={"100%"}>
                <FormSelect
                  control={form.control}
                  name={AssignmentDocumentReviewFieldNames.STATUS}
                  label={t(`legalAdvice.requestAdditional.title.status`)}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  options={Object.entries(LegalCheckSheetStatusCodeList).map(([, v]) => {
                    return ({
                      id: v,
                      name: (LcsStatusLabels as any)?.[v]
                    })
                  }) ?? []}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  disabled
                  required
                />
              </Grid>} */}
              {/* {!isLcs && <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={AssignmentDocumentReviewFieldNames.STATUS}
                  label={t(`legalAdvice.requestAdditional.title.status`)}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.DOCUMENT_REVIEW.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  disabled
                  required
                />
              </Grid>} */}
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AssignmentDocumentReviewFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.assignment.title.${AssignmentDocumentReviewFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.assignment.placeHolder.${AssignmentDocumentReviewFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AssignmentDocumentReviewFieldNames.USERS_IDS}
                    label={t("DOCUMENT_REVIEW.popup.pic")}
                    placeholder={t('common.place_holder.enter_name_code')}
                    getOptions={async (keyword) => {
                      if (!getLegalDepartmentQuery.data) return [];
                      const response = await getUsers({
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                        departmentIds: getLegalDepartmentQuery.data
                          ? [getLegalDepartmentQuery.data]
                          : [],
                      });
                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }))?.filter((user) => !excludedIds?.includes(user?.id));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"assignmentReview/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>

            </Grid>
            <ReminderPickerSubForm
              name={AssignmentDocumentReviewFieldNames.REMIND}
              module={module}
              placeholder={t('menu.reminder')}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={assignmentDocumentReviewMutation.isPending
                || assignmentLcsMutation.isPending
              }
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castAssignmentDocumentReviewRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
