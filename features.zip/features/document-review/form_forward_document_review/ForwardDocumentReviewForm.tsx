import { forwardDocumentReviewFn, forwardLcsFn } from "@/apis/service/document-review/forwardDocumentReview";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { castForwardDocumentReviewRequestSchemaToDTO, ForwardDocumentReviewFieldNames, ForwardDocumentReviewRequestSchema } from "@/models/document-review/ForwardDocumentReview";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { useContext, useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const initialEmptyValue: any = {
  [ForwardDocumentReviewFieldNames.USERS_IDS]: [],
  [ForwardDocumentReviewFieldNames.DEADLINE]: "",
  [ForwardDocumentReviewFieldNames.CONTENT]: "",
  [ForwardDocumentReviewFieldNames.REMIND]: undefined,
};

export interface ForwardDocumentReviewTypeFormProps {
  titlePopup?: string;
  initialValue?: any;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  lcsId?: number;
  isLcs?: boolean;

}

export const ForwardDocumentReviewForm = (
  props: ForwardDocumentReviewTypeFormProps
) => {
  const {
    isLcs,
    titlePopup = isLcs ? "metadata.forward.title" : "DOCUMENT_REVIEW.popup.forward",
    initialValue = initialEmptyValue,
    documentReviewId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DOCUMENT),
    senderDocumentManagement,
    lcsId,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const appContext = useContext(AppContext);

  const form = useForm({
    resolver: yupResolver(ForwardDocumentReviewRequestSchema),
    defaultValues: initialValue,
  });

  useEffect(() => {
    initialValue?.deadline && form.setValue('deadline', initialValue?.deadline ? new Date(initialValue?.deadline) : undefined)
  }, [initialValue])

  const forwardDocumentReviewMutation = useMutation({
    mutationFn: forwardDocumentReviewFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm();
    },
  })
  const forwardLcsMutation = useMutation({
    mutationFn: forwardLcsFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm();
    },
  })

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    const { ...restData } = data;
    (documentReviewId && !isLcs) && (await forwardDocumentReviewMutation.mutateAsync({
      id: documentReviewId as number,
      request: restData,
    }));
    (lcsId && isLcs) && (await forwardLcsMutation.mutateAsync({
      lcsId: lcsId,
      request: restData,
    }));
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </InputLabel>
                {senderDocumentManagement && (
                  <Typography>
                    {getUserLabel(senderDocumentManagement)}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateTimeInput
                  name={ForwardDocumentReviewFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`DOCUMENT_REVIEW.field_name.responseDeadlineType`)}
                  placeholder="dd/mm/yyyy hh:mm"
                  minDate={new Date()}
                  // required
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ForwardDocumentReviewFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.forwardLegalAdvice.title.${ForwardDocumentReviewFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.forwardLegalAdvice.placeHolder.${ForwardDocumentReviewFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>

                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ForwardDocumentReviewFieldNames.USERS_IDS}
                  label={t('DOCUMENT_REVIEW.labels.receivers')}
                  placeholder={t('common.place_holder.enter_name_code')}
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }))?.filter((user) => user?.id !== appContext?.me?.id);
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.departmentName ?? ""
                    }`
                  }
                  required
                  getOptionKey={(option) => option.id}
                  keyQuery={"forwardDocumentReview/queryUser"}
                  isFocus
                />

              </Grid>


            </Grid>
            <ReminderPickerSubForm
              name={ForwardDocumentReviewFieldNames.REMIND}
              module={module}
              placeholder={t('menu.reminder')}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={forwardDocumentReviewMutation.isPending || forwardLcsMutation.isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castForwardDocumentReviewRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
