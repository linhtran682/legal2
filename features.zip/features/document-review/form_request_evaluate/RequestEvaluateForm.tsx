import { getAssignedPerson } from '@/apis/service/assignment/Assignment';
import { getLegalDepartments } from '@/apis/service/department/department';
import { getInspectionList } from '@/apis/service/document-review/inspection';
import { createRequestEvaluateFn } from '@/apis/service/document-review/lcsEvaluation';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormTextArea } from '@/components/commons/form_inputs/FormTextArea';
import DateInput from '@/components/commons/inputs/date_input/DateInput';
import { ModalCommon } from '@/components/commons/popups/modal/Modal';
import { GLOBAL_SPACING } from '@/constants/format';
import { ModuleFields } from '@/constants/general';
import { formInputSxProps } from '@/constants/theme';
import { useAppContext } from '@/context/AppContext';
import { ReminderPickerSubForm } from '@/features/reminder_template/reminder_picker/ReminderPickerSubForm';
import { LegalCheckSheetStatusCodeList } from '@/models/document-review/DocumentReviewDetail';
import { castRequestEvaluateDTO, RequestEvaluateSchema } from '@/models/document-review/LcsEvaluate';
import { LegalCheckSheetBodyReceive } from '@/models/document-review/LegalCheckSheet';
import { UserProfileDTO } from '@/models/user/User';
import { findDeepestId, mergeArraysByKey } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import { Grid, InputLabel, Typography } from '@mui/material';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import { INSPECTION_LIST_QUERY_KEY } from '../document-review-form-list/ReviewList';


export interface RequestEvaluateFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  initialValues?: any;
  lcsId?: number;
  module?: number;
  sender?: any;
  legalCheckSheet?: LegalCheckSheetBodyReceive;
  // documentReview?: DocumentReviewBodyReceive;
}
const RequestEvaluateForm = (props: RequestEvaluateFormProps) => {

  const {
    isOpen,
    setIsOpen,
    name, sender, titlePopup = 'DOCUMENT_REVIEW.popup.requestEvaluate',
    lcsId,
    documentReviewId,
    legalCheckSheet
  } = props;
  const { t } = useTranslation();
  const appContext = useAppContext();

  const form = useForm<any>({
    resolver: yupResolver(RequestEvaluateSchema),
    mode: 'onBlur'
  });

  useEffect(() => {

    getAdviseListQuery.refetch().then((res) => {
      const reviewers = res?.data?.responses?.map((ele) => ele.user) ?? [];
      const lcMembers = legalCheckSheet?.evaluateUsers ?? [];
      const mergedArray = mergeArraysByKey([
        reviewers,
        lcMembers
      ], item => item.id)
      form?.setValue('userIds', mergedArray)
    })
    form?.setValue?.('status', LegalCheckSheetStatusCodeList.REQUEST_EVALUATION);
    // getStatusListQuery.refetch().then((res) => {
    //   const finishReviewStatus = res.data
    //     ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
    //       === removeVietnameseTones(defaultStatus).trim())
    //   finishReviewStatus?.id && form?.setValue?.('status', finishReviewStatus?.id);
    // })
  }, [])

  // const getStatusListQuery = useQuery({
  //   queryKey: ['document-review/get-status-list'],
  //   queryFn: async () => {
  //     const response = await getStatusList({
  //       modules: [ModuleFields.DOCUMENT_REVIEW.module],
  //       page: 0,
  //       size: 100,
  //       sortBy: StatusFieldNames.ID,
  //       orderBy: "ASC",
  //       active: 1
  //     });
  //     return response?.statusResponses || [];
  //   },
  //   placeholderData: prev => prev,
  //   enabled: false
  // });
  const getLegalDepartmentQuery = useQuery({
    queryKey: ["legal-advice/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) { }
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const getAssignedPersonQuery = useQuery({
    queryKey: ['legal-advice/get-legal-assigned-person'],
    queryFn: () => getAssignedPerson(),
    placeholderData: prev => prev,
    enabled: false
  })

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };


  const { mutateAsync: createRequestEvaluateAsync, isPending } = useMutation({
    mutationFn: createRequestEvaluateFn,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t(titlePopup),
      }));
      onCloseForm(true)
    },
  });

  const getAdviseListQuery = useQuery({
    queryKey: [INSPECTION_LIST_QUERY_KEY, documentReviewId],
    queryFn: () => getInspectionList(documentReviewId as number),
    // enabled: !!documentReviewId,
    enabled: false
  });

  const onSave = async (data: any) => {
    lcsId && (await createRequestEvaluateAsync({
      lcsId: lcsId,
      request: castRequestEvaluateDTO(data)
    }))
  }


  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <FormProvider {...form}>
        <Grid container className="form-wrapper" marginTop="20px">
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={{ ...formInputSxProps, paddingBottom: 0 }}
          >

            <Grid item width={"100%"}>
              <Typography fontWeight="bold">
                {t("DOCUMENT_REVIEW.field_name.documentName")}
              </Typography>
              <Typography>{name}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <InputLabel >
                {t(`DOCUMENT_REVIEW.popup.requester`)}
              </InputLabel>
              {sender && (
                <Typography>
                  {sender?.name} ({sender?.email}) -{" "}
                  {sender?.department?.name}
                </Typography>
              )}
            </Grid>

            <Grid item width={'100%'}>
              <DateInput
                name={'responseDate'}
                control={form.control}
                label={t(`DOCUMENT_REVIEW.popup.responseDate`)}
                placeholder="dd/mm/yyyy"
                required
              />
            </Grid>
            {/* <Grid item width={"100%"}>
              <FormSelect
                control={form.control}
                name={'status'}
                label={t(`legalAdvice.requestAdditional.title.status`)}
                placeHolder={t(`legalAdvice.requestAdditional.title.status`)}
                options={
                  Object.entries(LegalCheckSheetStatusCodeList).map(([, v]) => {
                    return ({
                      id: v,
                      name: (LcsStatusLabels as any)?.[v]
                    })
                  }) ?? []
                }
                getOptionKey={(option) => option?.id}
                getOptionLabel={(option) => t(option?.name)}
                required
              />
            </Grid> */}

            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={'content'}
                label={t(`DOCUMENT_REVIEW.popup.content`)}
                placeHolder={t(`DOCUMENT_REVIEW.popup.content`)}
                minRows={3}
                required
              />
            </Grid>
            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={'userIds'}
                label={t(`DOCUMENT_REVIEW.popup.pic`)}
                placeholder={t(`DOCUMENT_REVIEW.popup.pic`)}
                minCharLength={1}
                getOptions={async (keyword) => {
                  if (!getLegalDepartmentQuery.data) return []
                  const advisorIds = getAssignedPersonQuery?.data?.users?.map((user) => user.id) ?? [];
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                    departmentIds: getLegalDepartmentQuery.data ? [getLegalDepartmentQuery.data] : []
                  });
                  return response?.users
                    ?.map((user, index) => ({
                      ...user,
                      rank: advisorIds?.includes(user.id) ? index : 99999
                    }))?.sort((first, second) => first.rank - second.rank)
                    ?.filter((user) => user?.id !== appContext?.me?.id)
                    ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? (option?.departmentName ?? '')
                  }`
                }
                required
                getOptionKey={(option) => option.id}
                keyQuery='queryAdvisor'
                isFocus
              />
            </Grid>
          </Grid>
          <Grid item>
            <ReminderPickerSubForm
              name={'remind'}
              module={ModuleFields.DOCUMENT_REVIEW.module}
              placeholder={t('menu.reminder')}
            />
          </Grid>
        </Grid>
        <FormActionButtons
          formMode={"update"}
          loading={isPending}
          onCancel={() => onCloseForm()}
          cancelConfirm={form.formState.isDirty}
          onSave={onSave}
        />
      </FormProvider>
    </ModalCommon>
  )
}

export default RequestEvaluateForm