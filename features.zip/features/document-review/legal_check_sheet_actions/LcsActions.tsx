import { IconOption } from '@/assets/iconMenu/IconOption';
import { SaveRecordDialogIcon } from '@/assets/images/icons/iconSaveRecordDialog';
import { ActionButtonItem } from '@/components/commons/action_button/ActionButtonCustom';
import ActionButtonToolTip from '@/components/commons/action_button/ActionButtonToolTip';
import { ConfirmPopup, ConfirmPopupProps, DefaultConfirmPopupState } from '@/components/commons/popups/confirm_popup/ConfirmPopup';
import { DocumentReviewBodyReceive, DONE_STATUS, DrrmRoles, LCS_DONE_STATUS } from '@/models/document-review/DocumentReviewDetail';
import { DocumentReviewActionBtnKey } from '@/models/document-review/DocumentReviewList';
import { LcsButtonActions, LcsButtonActionStatus, LcsRoles, LegalCheckSheetBodyReceive, PrimaryButtonList, SecondaryButtonList } from '@/models/document-review/LegalCheckSheet';
import { Box, Button, Stack } from '@mui/material';
import { uniqueId } from 'lodash';
import { useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface LcsActionProps {
  documentReview?: DocumentReviewBodyReceive;
  legalCheckSheet: LegalCheckSheetBodyReceive;

  handleClickRequestEvaluate: () => void;
  handleClickRequestSign: () => void;
  handleClickFeedbackLc: () => void;
  handleClickSignApprove: () => void;
  handleClickConfirm: () => void;
  handleClickAssignment: () => void;
  handleClickInformationRequest: () => void;
  handleClickFeedbackEvaluate: () => void;
  handleClickEvaluate: () => void;
  handleClickFinish: () => void;
  handleClickRecall: () => void;
  handleClickSendMail: () => void;
  handleClickForward: () => void;
  handleClickFeedback: () => void;
  handleClickRequestMeeting: () => void;
  handleClickTimeExtensionRequest: () => void;
  handleClickRecheck: () => void;
  handleClickShare: () => void;
  drrmRoles?: number[];
}

const LcsActions = (props: LcsActionProps) => {
  const { legalCheckSheet, drrmRoles, documentReview } = props;
  const { t } = useTranslation();
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const scrollContainerRef = useRef(null);

  // Scroll to the right when the button is clicked
  // const scrollRight = () => {
  //   scrollContainerRef?.current?.scrollBy?.({ left: 100, behavior: 'smooth' });
  // };

  const callbackMap: Record<string, () => void> = useMemo(() => ({
    [DocumentReviewActionBtnKey.REQUEST_EVALUATE]: props.handleClickRequestEvaluate,
    [DocumentReviewActionBtnKey.REQUEST_SIGN]: props.handleClickRequestSign,
    [DocumentReviewActionBtnKey.FEEDBACK_LC]: props.handleClickFeedbackLc,
    [DocumentReviewActionBtnKey.SIGN_AND_APPROVE]: props.handleClickSignApprove,
    [DocumentReviewActionBtnKey.CONFIRM]: props.handleClickConfirm,
    [DocumentReviewActionBtnKey.ASSIGNMENT]: props.handleClickAssignment,
    [DocumentReviewActionBtnKey.INFORMATION_REQUEST]: props.handleClickInformationRequest,
    [DocumentReviewActionBtnKey.FEEDBACK_EVALUATE]: props.handleClickFeedbackEvaluate,
    [DocumentReviewActionBtnKey.EVALUATE]: props.handleClickEvaluate,
    [DocumentReviewActionBtnKey.FINISH]: props.handleClickFinish,
    [DocumentReviewActionBtnKey.RECHECK]: props.handleClickRecheck,

    [DocumentReviewActionBtnKey.RECALL]: props.handleClickRecall,
    [DocumentReviewActionBtnKey.SEND_MAIL]: props.handleClickSendMail,
    [DocumentReviewActionBtnKey.FORWARD]: props.handleClickForward,
    [DocumentReviewActionBtnKey.FEEDBACK]: props.handleClickFeedback,
    [DocumentReviewActionBtnKey.REQUEST_MEETING]: props.handleClickRequestMeeting,
    [DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST]: props.handleClickTimeExtensionRequest,
    [DocumentReviewActionBtnKey.SHARE]: props.handleClickShare

  }), [])

  const handleButtonClick = (type: keyof LcsButtonActions | 'share') => {
    if (type === DocumentReviewActionBtnKey.CONFIRM
      || type === DocumentReviewActionBtnKey.RECALL
    ) {
      setConfirmPopupState({
        open: true,
        icon: <SaveRecordDialogIcon />,
        title: t(`DOCUMENT_REVIEW.popup.${type}Prompt`),
        handleConfirm: () => {
          if (callbackMap?.[type]) {
            callbackMap?.[type]?.();
            setConfirmPopupState(DefaultConfirmPopupState);
          }
        },
        handleCancel: () =>
          setConfirmPopupState(DefaultConfirmPopupState),
      })
    } else {
      callbackMap?.[type]?.();
    }
  }

  // const legalCheckSheet = {
  //   buttonAction: {
  //     "requestEvaluate": 1, // YC đánh giá - API done
  //     "requestSign": 1, // YC ký - API done
  //     "feedbackLC": 1,
  //     "finish": 1,
  //     "signAndApprove": 1, // Ký duyệt - API done
  //     "confirm": 1,
  //     "assignment": 1,
  //     "informationRequest": 1,
  //     "feedbackEvaluate": 1,
  //     "evaluate": 1,
  //     "timeExtensionRequest": 1,
  //     "timeExtension": 1,
  //     "recall": 1,
  //     "sendMail": 1,
  //     "forward": 1,
  //     "requestMeeting": 1,
  //     "feedback": 1
  //   }
  // }
  const primaryList = useMemo(() => {

    const buttonList = PrimaryButtonList.filter((button) => legalCheckSheet.buttonAction
      ?.[button as keyof LcsButtonActions] !== LcsButtonActionStatus.HIDE) ?? [];

    if (documentReview?.status?.name === DONE_STATUS || legalCheckSheet.status === LCS_DONE_STATUS) {
      return drrmRoles?.includes(1) ? [DocumentReviewActionBtnKey.RECHECK] : [];
    }
    return buttonList;

  }, [documentReview, legalCheckSheet, drrmRoles])




  const secondaryList: ActionButtonItem[] = useMemo(() => {
    let buttonList = SecondaryButtonList.map((button) => ({
      key: legalCheckSheet.buttonAction?.[button as keyof LcsButtonActions]
        === LcsButtonActionStatus.HIDE ? 'hidden' : button,
      textBtn: t(`DOCUMENT_REVIEW.lcsButtons.${button}`),
      disable: legalCheckSheet.buttonAction?.[button as keyof LcsButtonActions]
        === LcsButtonActionStatus.SHOW_DISABLE,
      icon: <></>,
      tooltipTitle: t(`DOCUMENT_REVIEW.lcsButtons.${button}`),
      onClick: () => handleButtonClick(button as keyof LcsButtonActions)
    }))?.filter((btn) => btn.key !== 'hidden') ?? [];

    const canShare = drrmRoles?.includes(DrrmRoles.PIC)
      || drrmRoles?.includes(DrrmRoles.L_C)
      || drrmRoles?.includes(DrrmRoles.HEAD_OF_L_C)
      || drrmRoles?.includes(DrrmRoles.SUPERVISOR)
      || legalCheckSheet?.ownerRoles?.includes(LcsRoles.REQUEST_DEPT)
      || legalCheckSheet?.ownerRoles?.includes(LcsRoles.LC)
      || legalCheckSheet?.ownerRoles?.includes(LcsRoles.SUPERVISOR)

    const shareButton = {
      key: DocumentReviewActionBtnKey.SHARE,
      textBtn: t(`legalAdvice.button.share`),
      disable: false,
      icon: <></>,
      tooltipTitle: t(`DOCUMENT_REVIEW.lcsButtons.share`),
      onClick: () => handleButtonClick('share')
    }

    if (canShare) {
      buttonList.push(shareButton);
    }
    if (canShare && legalCheckSheet.status === LCS_DONE_STATUS) {
      buttonList = [shareButton];
    }
    if (!canShare && legalCheckSheet.status === LCS_DONE_STATUS) {
      buttonList = [];
    }
    return buttonList;

  }, [legalCheckSheet, drrmRoles, t])

  // SecondaryButtonList.map((button) => ({
  //   key: legalCheckSheet.buttonAction?.[button as keyof LcsButtonActions]
  //     === LcsButtonActionStatus.HIDE ? 'hidden' : button,
  //   textBtn: t(`DOCUMENT_REVIEW.lcsButtons.${button}`),
  //   disable: legalCheckSheet.buttonAction?.[button as keyof LcsButtonActions]
  //     === LcsButtonActionStatus.SHOW_DISABLE,
  //   icon: <></>,
  //   tooltipTitle: t(`DOCUMENT_REVIEW.lcsButtons.${button}`),
  //   onClick: () => handleButtonClick(button as keyof LcsButtonActions)
  // }))?.filter((btn) => btn.key !== 'hidden') ?? []

  return (
    <>
      <Stack direction={'row'} alignItems={'start'}>
        <Box ref={scrollContainerRef} width={'100%'} whiteSpace={'nowrap'} sx={{ overflowY: 'hidden', paddingBottom: `${primaryList?.length ? 16 : 0}px`, flexWrap: 'nowrap' }}>
          {
            primaryList.map((button: any) => {
              return <Button
                key={uniqueId('lcs_button_')}
                onClick={() => handleButtonClick(button)}
                disabled={legalCheckSheet.buttonAction?.[button as keyof LcsButtonActions] === LcsButtonActionStatus.SHOW_DISABLE
                  || (!!documentReview?.confirmLCSFlag && button === 'confirm')
                }
                sx={{
                  height: "36px",
                  padding: "4px 12px",
                  fontSize: '14px',
                  alignItems: 'center',
                  whiteSpace: 'nowrap',
                  width: "fit-content",
                  mr: 1
                }}
                variant='contained'
                className="confirm"
              >{t(`DOCUMENT_REVIEW.lcsButtons.${button}`)}</Button>
            })
          }
        </Box>
        {!!secondaryList?.length && <ActionButtonToolTip
          listBtn={secondaryList}
        >
          <Box
            sx={{ padding: 0, width: 'fit-content', "&:hover": { background: "transparent" } }}
          >
            <IconOption />
          </Box>
        </ActionButtonToolTip>}
      </Stack>

      <ConfirmPopup {...confirmPopupState} />
    </>
  )
}

export default LcsActions