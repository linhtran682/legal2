import { cloneDocumentReviewRequestFn, getDocumentReviewExcel, getDocumentReviewRequests, shareDocumentReviewFn } from '@/apis/service/document-review/documentReview';
import { getStatusList, getStatusListNames } from '@/apis/service/status/Status';
import { getUsers } from '@/apis/service/user/User';
import IconRecheck from '@/assets/iconMenu/IconRecheck';
import { getMultipleAsyncChoosingOperators } from '@/components/commons/filters/MultipleAsyncChoosingFilter';
import { getMultipleSelectOperators } from '@/components/commons/filters/MultipleSelectFilter';
import HierarchyToolTip from '@/components/commons/hierarchy-tooltip/HierarchyTooltip';
import { ConfirmPopup, ConfirmPopupProps, DefaultConfirmPopupState } from '@/components/commons/popups/confirm_popup/ConfirmPopup';
import SharePopup from '@/components/commons/share_popup/SharePopup';
import { StatusBadge } from '@/components/commons/status_badge/StatusBadge';
import { MultipleFilterTableColumn } from '@/components/commons/tables/multiple_filter_table/MultipleFilterTable';
import MultipleTabsTable from '@/components/commons/tables/multiple_tabs_table/MultipleTabsTable';
import { DEFAULT_PAGE_MODAL, StandardTableState } from '@/components/commons/tables/standard_table/StandardTable';
import { COLOR_TYPE } from '@/constants/color';
import { URL_OUTLOOK } from '@/constants/constraint';
import { MIME_TYPES, ModuleFields } from '@/constants/general';
import { DOCUMENT_REVIEW_ROOT_PATH, UI_PATH } from '@/constants/paths';
import { THOUSAND_SEPARATOR } from '@/constants/regex';
import { AppContext } from '@/context/AppContext';
import { DocumentReviewBodyReceive, documentReviewSearchPanelConfig, DocumentReviewStatusList, LcsStatusLabels, LegalCheckSheetStatusCodeList } from '@/models/document-review/DocumentReviewDetail';
import { ATTACHMENT_TYPES, DocumentReviewActionBtnKey, DocumentReviewTableFields, GetDocumentReviewListParams, SAMPLE_CONTRACT_TYPES } from '@/models/document-review/DocumentReviewList';
import { StatusDTO, StatusFieldNames } from '@/models/status/Status';
import { BasedUser } from '@/models/user/User';
import { downloadFile, formatDate } from '@/utils';
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { Button, Grid, IconButton, Tooltip } from '@mui/material';
import { GridFilterItem } from '@mui/x-data-grid';
import { useMutation, useQuery } from '@tanstack/react-query';
import { endOfDay, format } from 'date-fns';
import { useRouter } from 'next/router';
import { useContext, useEffect, useState } from 'react';
import { Range } from 'react-date-range';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import { DocumentReviewActions } from '../document_review_actions/DocumentReviewActions';
import { AssignmentDocumentReviewForm } from '../form_assignment/AssignmentDocumentReviewForm';
import { DocumentReviewConductionForm } from '../form_document_review_conduction/DocumentReviewConductionForm';
import { DocumentReviewConductionFeedbackForm } from '../form_document_review_conduction_feedback/DocumentReviewConductionFeedbackForm';
import { DocumentReviewConductionSupervisorForm } from '../form_document_review_conduction_supervisor/DocumentReviewConductionSupervisorForm';
import { FeedbackGeneralForm } from '../form_feedback/FeedbackGeneralForm';
import FinishReviewForm from '../form_finish_review/FinishReviewForm';
import { ForwardDocumentReviewForm } from '../form_forward_document_review/ForwardDocumentReviewForm';
import { RequestAdditionalForm } from '../form_request_additional_information/RequestAdditionalForm';
import { RequestVendorReviewForm } from '../form_request_vendor_review/RequestVendorReviewForm';
import SendMailForm from '../form_send_mail/SendMailForm';
import { TimeExtensionDocumentReviewForm } from '../form_time_extension/TimeExtensionDocumentReviewForm';
import { getMultipleChoosingOperators } from '@/components/commons/filters/MultipleChoosingFilter';


export const DocumentReviewTableConst = {
  GENERAL_TABLE: "DOCUMENT_REVIEW.labels.allRequests",
  GET_ALL_QUERY_KEY: "document-review/get-all-requests",
  PERSONAL_TABLE: "DOCUMENT_REVIEW.labels.myRequests",
  GET_PERSONAL_QUERY_KEY: "document-review/get-personal-requests",
  GET_DOCUMENT_REVIEW_EXCEL: "document-review/get-excel",
};

const DocumentReviewTable = () => {
  const { t, i18n } = useTranslation();
  const [activeTab, setActiveTab] = useState<number>(0);
  const router = useRouter();
  const appContext = useContext(AppContext);
  const [initialDocumentReview, setInitialDocumentReview] = useState<
    DocumentReviewBodyReceive | undefined
  >(undefined);
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );


  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialDocumentReview(row);
      changePopupVisible(type, true);
    }
  };
  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const cloneMutation = useMutation({
    mutationFn: cloneDocumentReviewRequestFn,
    onSuccess: () => {
      toast.success(
        t(`DOCUMENT_REVIEW.messages.recheckSuccess`)
      );
    },
  });

  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list-all'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.LEGISLATION_NAME.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.NAME,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: true
  });
  const handleRecheck = (review: any) => {
    setConfirmPopupState({
      open: true,
      icon: <IconRecheck />,
      title: t(`DOCUMENT_REVIEW.messages.confirmRecheck`),
      handleConfirm: () => {
        const requestAdviceStatus = getStatusListQuery?.data
          ?.find((ele: StatusDTO) => ele.name === DocumentReviewStatusList.REQUEST_REVIEW
          )

        review?.id && cloneMutation.mutate({
          id: review?.id as number,
          data: {
            childStatus: requestAdviceStatus?.id as number,
            status: review?.status?.id as number
          }
        })
      },
      handleCancel: () => {
        setConfirmPopupState(DefaultConfirmPopupState);
      },
    })
  }

  const [DocumentReviewTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: DocumentReviewTableFields.ID,
      label: DocumentReviewTableFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: 'center'
    },
    {
      key: DocumentReviewTableFields.DOCUMENT_NAME,
      label: DocumentReviewTableFields.DOCUMENT_NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      flex: 1,
      renderCell: (params) => (
        <HierarchyToolTip
          {...documentReviewSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.documentName}
          openNewTab
        >
          <span>{params.value}</span>
        </HierarchyToolTip>
      ),
    },
    {
      key: DocumentReviewTableFields.STATUS,
      label: DocumentReviewTableFields.STATUS,
      type: "string",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => {
        return (
          // <Button
          //   variant="outlined"
          //   style={{
          //     background:
          //       params?.row?.status?.name && params?.row?.status?.name === "Hoàn thành"
          //         ? "#E7F4EE"
          //         : "#D781001A",
          //     borderRadius: "100px",
          //     color:
          //       params?.row?.status?.name && params?.row?.status?.name === "Hoàn thành"
          //         ? "#0D894F"
          //         : "#D78100",
          //     border: "none",
          //     padding: "4px 12px",
          //   }}
          // >
          //   {params?.row?.isDraft ? t('common.label.draft') : params?.row?.status?.name}
          // </Button>
          <StatusBadge label={params?.row?.isDraft
            ? t('common.label.draft')
            : (params?.row?.lcsStatus
              ? (LcsStatusLabels as any)?.[params?.row?.lcsStatus?.toString?.()]
              : params?.row?.status?.name as string)} />
        )
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusListNames({
              names: Object.values(DocumentReviewStatusList),
              modules: [ModuleFields.DOCUMENT_REVIEW.module],
            });
            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item.id,
          getOptionLabel: (item) => item.name,
          keyQuery: DocumentReviewTableFields.STATUS,
        },
        t
      ),
    },
    {
      key: DocumentReviewTableFields.ATTACHMENT_TYPE,
      label: DocumentReviewTableFields.ATTACHMENT_TYPE,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => t(ATTACHMENT_TYPES
        ?.find((ele) => ele?.value === params?.value)?.label ?? '')
    },
    {
      key: DocumentReviewTableFields.SIGNERS,
      label: DocumentReviewTableFields.SIGNERS,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 280,
      renderCell: (params) =>
        <Tooltip
          placement="bottom-start"
          title={
            <>
              {params.row?.signerList
                ?.map(
                  (user: any) => <p key={user?.id}>{user.name} - {user?.departmentResponse?.name}</p>
                )}
            </>
          }>
          {params.row?.signerList
            ?.map(
              (user: any) => `${user.name} - ${user?.departmentResponse?.name}`
            )
            .join(", ")}
        </Tooltip>
    },
    {
      key: DocumentReviewTableFields.SIGNING_DATE,
      label: DocumentReviewTableFields.SIGNING_DATE,
      type: "date",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: DocumentReviewTableFields.EFFECTIVE_DATE,
      label: DocumentReviewTableFields.EFFECTIVE_DATE,
      type: "date",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: DocumentReviewTableFields.EFFECTIVE_END_DATE,
      label: DocumentReviewTableFields.EFFECTIVE_END_DATE,
      type: "date",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: DocumentReviewTableFields.SOW_CONTRACT,
      label: DocumentReviewTableFields.SOW_CONTRACT,
      type: "string",
      sortable: true,
      hideable: false,
      minWidth: 240,
    },
    {
      key: DocumentReviewTableFields.CONTRACT_VALUE,
      label: DocumentReviewTableFields.CONTRACT_VALUE,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => `${String(params.value)?.replace?.(THOUSAND_SEPARATOR, ",")} ${params.row?.currency?.unit ?? ''}`.trim(),
    },
    {
      key: DocumentReviewTableFields.SAMPLE_CONTRACT_TYPE,
      label: DocumentReviewTableFields.SAMPLE,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => t(SAMPLE_CONTRACT_TYPES
        ?.find((ele) => ele?.value === params?.value)?.label ?? '')
    },
    {
      key: DocumentReviewTableFields.LCS_STATUS,
      label: DocumentReviewTableFields.LCS_STATUS,
      type: "string",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      filterRank: 1,
      renderCell: (params) => {
        if (!params.row?.lcsStatus) return null;
        return (
          <Button
            variant="outlined"
            style={{
              background:
                ((LcsStatusLabels as any)?.[params.row?.lcsStatus]) === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                ((LcsStatusLabels as any)?.[params.row?.lcsStatus]) === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {(LcsStatusLabels as any)?.[params.row?.lcsStatus] ?? ""}
          </Button>
        )
      },
      filterOperators: getMultipleChoosingOperators(
        {
          options: Object.entries(LegalCheckSheetStatusCodeList).map(([, v]) => {
            return ({
              value: v,
              label: (LcsStatusLabels as any)?.[v]
            })
          }) ?? [],
          getOptionKey: (option) => option.value,
          getOptionLabel: (option) => option.label,
        },
        t
      ),
    },
    {
      key: DocumentReviewTableFields.PIC,
      label: DocumentReviewTableFields.PIC,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 250,
      renderCell: (params) => <Tooltip
        placement="bottom-start"
        title={params.row?.pic
          ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
          : ""}>
        <span>
          {params.row?.pic
            ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
            : ""}
        </span>
      </Tooltip>,
      filterOperators: getMultipleSelectOperators(
        {
          getOptions: async (keyword) => {
            const response = await getUsers({
              searchTerm: keyword,
              page: 0,
              size: 100,
              sortBy: "name",
              sortOrder: "ASC",
            });

            return response?.users ?? [];
          },
          getOptionKey: (item) => item.id.toString(),
          getOptionLabel: (item) =>
            `${item?.name} - ${item?.position?.name ? `${item?.position?.name}.` : ""
            }${item?.department?.name ?? ""}`,
          keyQuery: 'document-review/pic',
        },
        t
      ),
    },
    {
      key: DocumentReviewTableFields.ACTION,
      label: DocumentReviewTableFields.ACTION,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "last-column-sticky",
      headerClassName: "last-column-sticky-header",
      renderCell: (params) => (!params?.row?.isDraft
        // && params?.row?.status?.name !== DONE_STATUS
      )
        && <DocumentReviewActions
          params={{
            row: params.row,
          }}
          // handleClickRecall={async () => initialDocumentReview?.id && await recallDrrAsync(initialDocumentReview?.id)}
          handleClickForWard={() =>
            handleClick(DocumentReviewActionBtnKey.FORWARD, params.row)
          }
          handleClickFeedBack={() =>
            handleClick(DocumentReviewActionBtnKey.FEEDBACK, params.row)
          }
          handleClickRequestMeeting={() => window.open(URL_OUTLOOK, "_blank")}
          handleClickSendMail={() =>
            handleClick(DocumentReviewActionBtnKey.SEND_MAIL, params.row)
          }
          handleClickExtendTime={() =>
            handleClick(DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST, params.row)
          }
          // handleClickConfirm={async () => await confirmDocumentReview(Number(id))}
          handleClickAssignment={() =>
            handleClick(DocumentReviewActionBtnKey.ASSIGNMENT, params.row)
          }
          handleClickRequestVendor={() =>
            handleClick(DocumentReviewActionBtnKey.REQUEST_VENDOR, params.row)
          }
          handleClickFeedbackAdvise={() =>
            handleClick(DocumentReviewActionBtnKey.FEEDBACK_INSPECTION, params.row)
          }
          handleClickRequestAdditional={() =>
            handleClick(DocumentReviewActionBtnKey.INFORMATION_REQUEST, params.row)
          }
          handleClickAdvise={() => handleClick(DocumentReviewActionBtnKey.INSPECTION, params.row)}
          handleClickDone={() => handleClick(DocumentReviewActionBtnKey.FINISH, params.row)}
          handleClickShare={() =>
            handleClick(DocumentReviewActionBtnKey.SHARE, params.row)}
          handleClickRecheck={() => {
            handleRecheck(params.row);
          }}



        // isActionDetail
        />
    },
  ]);

  /** Get all legal advice */
  const getAllRequestQuery = useQuery({
    queryKey: [DocumentReviewTableConst.GET_ALL_QUERY_KEY],
    queryFn: () => getDocumentReviewRequests({
      ...castTableStateToParams(generalTableState),
      tab: 0,
    }),
    enabled: false,
  });
  /** Get personal legal advice request */
  const getPersonalRequestQuery = useQuery({
    queryKey: [DocumentReviewTableConst.GET_PERSONAL_QUERY_KEY],
    queryFn: () => getDocumentReviewRequests({
      ...castTableStateToParams(generalTableState),
      tab: 1,
    }),
    enabled: false,
  });

  /** Get excel file */
  const getExcelQuery = useQuery({
    queryKey: [DocumentReviewTableConst.GET_DOCUMENT_REVIEW_EXCEL],
    queryFn: () => getDocumentReviewExcel({
      ...castTableStateToParams(generalTableState),
      tab: activeTab,
      isEnglish: i18n.language === "en"
    }),
    enabled: false,
  });

  const changePopupVisible = (type: any, state: boolean = false, reload = false) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state && reload) {
      getAllRequestQuery.refetch();
      getPersonalRequestQuery.refetch();
      setInitialDocumentReview(undefined);
    }
  };

  useEffect(() => {
    generalTableState &&
      activeTab === 0 &&
      getAllRequestQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generalTableState, activeTab]);

  useEffect(() => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalRequestQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [personalTableState, activeTab]);

  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getExcelQuery.refetch().then((response: any) => {
              const fileName = `${i18n.language === "en"
                ? "DocumentReviewRequest"
                : "Yêu cầu kiểm tra tài liệu"
                }_${format(new Date(), "ddMMyyyy")}`;
              response?.data &&
                downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getAllRequestQuery.isFetching ||
            getPersonalRequestQuery.isFetching ||
            getExcelQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };

  const shareMutation = useMutation({
    mutationFn: shareDocumentReviewFn,
    onSuccess: () => {
      toast.success(
        t(`DOCUMENT_REVIEW.messages.shareSuccess`)
      );
    },
  });

  return (
    <>
      <MultipleTabsTable
        tableTabs={[
          {
            tabName: t(DocumentReviewTableConst.GENERAL_TABLE),
            tabKey: DocumentReviewTableConst.GENERAL_TABLE,
            data: getAllRequestQuery?.data?.data ?? [],
            loading: getAllRequestQuery?.isFetching,
            rowCount: getAllRequestQuery?.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t(DocumentReviewTableConst.PERSONAL_TABLE),
            tabKey: DocumentReviewTableConst.PERSONAL_TABLE,
            data: getPersonalRequestQuery?.data?.data ?? [],
            loading: getPersonalRequestQuery?.isFetching,
            rowCount: getPersonalRequestQuery?.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={DocumentReviewTableColumns.map((column) => ({
          ...column,
          label: column.label ? getFieldLabel(column.label) : "",
        }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        quickFilterProps={{
          defaultSelectedOptionKey: DocumentReviewTableFields.DOCUMENT_NAME,
          placeHolder: () => t("DOCUMENT_REVIEW.placeholder.enterRequestName"),
        }}
        onRowClick={(params) =>
          router.push(
            `/${DOCUMENT_REVIEW_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
          )
        }
        exportFile={renderExportButton()}
        onTabChange={setActiveTab}
      />
      <ConfirmPopup {...confirmPopupState} />
      {popupVisibleState?.[DocumentReviewActionBtnKey.SHARE] && <SharePopup
        setIsOpen={(state, reload) =>
          changePopupVisible(DocumentReviewActionBtnKey.SHARE, state, reload)
        }
        isOpen={true}
        owner={initialDocumentReview?.pic}
        // pics={initialDocumentReview?.responsibleUsers}
        pics={[]}
        onSubmit={async (data: any) => {
          const params = {
            id: initialDocumentReview?.id as number,
            data
          }
          await shareMutation.mutateAsync(params)
        }}
        initialValue={{
          legalAccessType: initialDocumentReview?.legalAccessType,
          sharedDepartments: initialDocumentReview?.sharedDepartments,
          sharedUsers: initialDocumentReview?.sharedUsers
        }}
      />}
      {/* Send mail - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.SEND_MAIL] && <SendMailForm
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.SEND_MAIL]}
        name={initialDocumentReview?.documentName}
        documentReviewId={initialDocumentReview?.id}
        lcsId={initialDocumentReview?.lcsId}
        // isLcs={!!routeLcsAction}
        senderDocumentManagement={appContext?.me}
        setIsOpen={(state) =>
          changePopupVisible(DocumentReviewActionBtnKey.SEND_MAIL, state)
        }
      />}
      {/* Phân công - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.ASSIGNMENT] && <AssignmentDocumentReviewForm
        documentReviewId={initialDocumentReview?.id}
        senderDocumentManagement={appContext?.me}
        name={initialDocumentReview?.documentName}
        lcsId={initialDocumentReview?.lcsId}
        // isLcs={!!routeLcsAction}
        documentReview={initialDocumentReview}
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.ASSIGNMENT]}
        setIsOpen={(state) =>
          changePopupVisible(DocumentReviewActionBtnKey.ASSIGNMENT, state)
        }
      />}

      {/* Chuyển tiếp - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.FORWARD] && <ForwardDocumentReviewForm
        name={initialDocumentReview?.documentName}
        documentReviewId={initialDocumentReview?.id}
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FORWARD]}
        setIsOpen={(state) =>
          changePopupVisible(DocumentReviewActionBtnKey.FORWARD, state)
        }
        initialValue={{
          deadline: initialDocumentReview?.responseDate
        }}
        lcsId={initialDocumentReview?.lcsId}
        // isLcs={!!routeLcsAction}
        senderDocumentManagement={appContext?.me}
      />}

      {/* Hoàn thành KTTL - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.FINISH] && <FinishReviewForm
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FINISH]}
        setIsOpen={(state) =>
          changePopupVisible(DocumentReviewActionBtnKey.FINISH, state)
        }
        documentReviewId={initialDocumentReview?.id}
        name={initialDocumentReview?.documentName}
        sender={appContext?.me}
        initialValues={{
          userIds: [
            ...(initialDocumentReview?.receiverUsers ?? [])
          ]
        }}
      />}

      {/* YC bổ sung thtin - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.INFORMATION_REQUEST] && <RequestAdditionalForm
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.INFORMATION_REQUEST]}
        documentReviewId={initialDocumentReview?.id}
        name={initialDocumentReview?.documentName}
        senderDocumentManagement={appContext?.me}
        lcsId={initialDocumentReview?.lcsId}
        // isLcs={!!routeLcsAction}
        initialValue={{
          userIds: [initialDocumentReview?.pic]
        }}
        maxDate={initialDocumentReview?.responseDate}
        setIsOpen={(state, reload) =>
          changePopupVisible(DocumentReviewActionBtnKey.INFORMATION_REQUEST, state, reload)
        } />}

      {/* YC gia hạn thgian - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST] && <TimeExtensionDocumentReviewForm
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST]}
        documentReviewId={initialDocumentReview?.id}
        name={initialDocumentReview?.documentName}
        senderDocumentManagement={appContext?.me}
        initialValue={{
          users: [initialDocumentReview?.pic],
        }}
        lcsId={initialDocumentReview?.lcsId}
        // isLcs={!!routeLcsAction}
        setIsOpen={(state, reload) =>
          changePopupVisible(DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST, state, reload)
        } />}

      {/* Kiểm tra  - API done */}
      {(popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !initialDocumentReview?.isSupervisor) && <DocumentReviewConductionForm
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !initialDocumentReview?.isSupervisor}
        name={initialDocumentReview?.documentName}
        documentReviewId={initialDocumentReview?.id}
        senderDocumentManagement={appContext?.me}
        // refetchQueryKeys={[INSPECTION_LIST_QUERY_KEY]}
        initialDocumentReview={initialDocumentReview}
        inspectionId={initialDocumentReview?.inspectionId}
        initialValue={{
          userIds: [initialDocumentReview?.pic]
        }}
        setIsOpen={(state, reload) =>
          changePopupVisible(DocumentReviewActionBtnKey.INSPECTION, state, reload)
        } />}
      {/* Phản hồi kiểm tra - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_INSPECTION] &&
        <DocumentReviewConductionFeedbackForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_INSPECTION]}
          isFeedBack
          documentReviewId={initialDocumentReview?.id}
          name={initialDocumentReview?.documentName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            deadlineNew: initialDocumentReview?.responseDate ?
              new Date(initialDocumentReview?.responseDate) : null
          }}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.FEEDBACK_INSPECTION, state, reload)
          } />}
      {/* Supervisor kiểm tra */}
      {(popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !!initialDocumentReview?.isSupervisor) && <DocumentReviewConductionSupervisorForm
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !!initialDocumentReview?.isSupervisor}
        documentReviewId={initialDocumentReview?.id}
        name={initialDocumentReview?.documentName}
        senderDocumentManagement={appContext?.me}
        initialDocumentReview={initialDocumentReview}
        inspectionId={initialDocumentReview?.inspectionId}
        initialValue={{
          userIds: [initialDocumentReview?.pic]
        }}
        setIsOpen={(state, reload) =>
          changePopupVisible(DocumentReviewActionBtnKey.INSPECTION, state, reload)
        } />}

      {/* YC vendor kiểm tra - API done */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.REQUEST_VENDOR] && <RequestVendorReviewForm
        isOpen
        name={initialDocumentReview?.documentName}
        documentReviewId={initialDocumentReview?.id}
        senderDocumentManagement={appContext?.me}
        initialValue={{
          userIds: [
            initialDocumentReview?.pic as BasedUser,
            appContext?.me as BasedUser,
          ]
        }}
        setIsOpen={(state, reload) =>
          changePopupVisible(DocumentReviewActionBtnKey.REQUEST_VENDOR, state, reload)
        } />}
      {/* Phản hồi văn bản - API 500 */}
      {popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK] && <FeedbackGeneralForm
        isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK]}
        name={initialDocumentReview?.documentName}
        documentReviewId={initialDocumentReview?.id}
        senderDocumentManagement={appContext?.me}
        setIsOpen={(state, reload) =>
          changePopupVisible(DocumentReviewActionBtnKey.FEEDBACK, state, reload)
        }
        initialValue={{
          deadline: initialDocumentReview?.responseDate
        }}
        lcsId={initialDocumentReview?.id}
      // isLcs={!!routeLcsAction}
      />}


    </>
  )
}

export default DocumentReviewTable;

const getFieldLabel = (key: string) => {
  return `DOCUMENT_REVIEW.column.${key}`;
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetDocumentReviewListParams => {
  const params: GetDocumentReviewListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 10,
    sortBy: DocumentReviewTableFields.ID,
    orderBy: "DESC",
  };
  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == DocumentReviewTableFields.DOCUMENT_NAME) {
      params.documentName = item.value;
    }

    if (item.field == DocumentReviewTableFields.STATUS) {
      params.statusList = (item.value ?? [])
        .map((item: StatusDTO) => item.id ?? item)
        .join(",");
    }
    if (item.field == DocumentReviewTableFields.LCS_STATUS) {
      params.lcsStatus = (item.value ?? [])
        .map((item: StatusDTO) => item.id ?? item)
        .join(",");
    }
    if (item.field == DocumentReviewTableFields.PIC) {
      params.picIds = (item.value ?? [])
        .map((item: StatusDTO) => item.id ?? item)
        .join(",");
    }

    if (item.field == DocumentReviewTableFields.SIGNING_DATE) {
      params.signingDateFrom = (
        item.value as Range
      ).startDate?.toISOString();

      params.signingDateTo = endOfDay(
        new Date((item.value as Range).endDate as Date)
      )?.toISOString();
    }

    if (item.field == DocumentReviewTableFields.EFFECTIVE_DATE) {
      params.effectiveDateFrom = (
        item.value as Range
      ).startDate?.toISOString();

      params.effectiveDateTo = endOfDay(
        new Date((item.value as Range).endDate as Date)
      )?.toISOString();
    }
    if (item.field == DocumentReviewTableFields.EFFECTIVE_END_DATE) {
      params.effectiveEndDateFrom = (
        item.value as Range
      ).startDate?.toISOString();

      params.effectiveEndDateTo = endOfDay(
        new Date((item.value as Range).endDate as Date)
      )?.toISOString();
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};