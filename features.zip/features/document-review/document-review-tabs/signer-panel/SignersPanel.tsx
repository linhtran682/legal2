import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { SignerItem } from "@/models/document-review/Signer";
import { formatDate } from "@/utils";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

export interface SignerPanelProps {
  queryKey: string;
  getTabSigner: () => Promise<SignerItem[]>;
}

export const SignerPanel = (props: SignerPanelProps) => {
  const { t, i18n } = useTranslation();
  const getEvaluationsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getTabSigner(),
  });

  const EvaluationTableColumns: StandardSimpleTableColumn<SignerItem>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +(params?.id ?? 0) + 1,
    },
    {
      key: "department",
      label: "metadata.evaluation.column.department",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.departmentResponse?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.evaluation.column.user",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row?.userResponse?.name,
    },
    {
      key: "deadline",
      label: "DOCUMENT_REVIEW.labels.signingDeadline",
      type: "date",
      flex: 1,
      renderCell: (params) => params.row.deadline ? formatDate(params.row.deadline) : "",
    },
    {
      key: "signer",
      label: "DOCUMENT_REVIEW.labels.signer",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row?.signer?.name,
    },
    {
      key: "status",
      label: "metadata.evaluation.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row.status ? t(
        `DOCUMENT_REVIEW.signingStatus.${params.row.status}`
      ) : ''
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        loading={getEvaluationsQuery.isFetching}
        columns={EvaluationTableColumns}
        data={getEvaluationsQuery.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
    </div>
  );
};
