import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { AppContext } from "@/context/AppContext";
import { LANGUAGES } from "@/locales/config-translation";
import { DocumentReviewBodyReceive } from "@/models/document-review/DocumentReviewDetail";
import { ReviewTimeExtension } from "@/models/document-review/TimeExtension";
import { AdviceExtension } from "@/models/legal-advice/LegalAdviceList";
import { Button } from "@mui/material";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import { TimeExtensionDocumentReviewForm } from "../../form_time_extension/TimeExtensionDocumentReviewForm";
// import { TimeExtensionAdviceForm } from "../../time_extension_Advice_form/TimeExtensionAdviceForm";

export interface DocumentReviewExtendPanelProps {
  queryKey: string;
  getExtendRecords: () => Promise<ReviewTimeExtension[]>;
  documentReviewId?: number;
  documentReview?: DocumentReviewBodyReceive;
  isLcs?: boolean;
  reloadDetail?: () => void;
}

export const DocumentReviewExtendPanel = (props: DocumentReviewExtendPanelProps) => {
  const { i18n, t } = useTranslation();
  const queryClient = useQueryClient();
  const appContext = useContext(AppContext);
  const { documentReviewId, documentReview, reloadDetail } = props;

  const [extendDeadlineId, setExtendDeadlineId] = useState<number>();
  const [isOpenTimeExtension, setIsOpenTimeExtension] =
    useState<boolean>(false);
  const getExtendRecordsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getExtendRecords(),
  });
  const handleClickExtend = (params: ReviewTimeExtension) => {
    setIsOpenTimeExtension(true);
    setExtendDeadlineId(params?.id);
  };

  const ExtendTableColumns: StandardSimpleTableColumn<AdviceExtension>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +(params?.id) + 1,
    },
    {
      key: "department",
      label: "metadata.extend.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.extend.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "reason",
      label: "timeExtension.title.reason",
      type: "string",
      flex: 1,
    },
    {
      key: "requestDeadline",
      label: "legalAdvice.tabs.requestDeadline",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row.requestDeadline ? format(new Date(params.row.requestDeadline), 'dd/MM/yyyy') : ''
    },
    {
      key: "acceptDeadline",
      label: "legalAdvice.tabs.acceptDeadline",
      type: "date",
      flex: 1,
      renderCell: (params) => params.row.acceptDeadline ? format(new Date(params.row.acceptDeadline), 'dd/MM/yyyy') : ''
    },
    {
      key: "status",
      label: "metadata.extend.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row.type ? t(`legalAdvice.extendType.${params.row.type}`) : ''
    },
    {
      key: "actionType",
      label: "Action",
      type: "string",
      flex: 1,
      renderCell: (params) => {
        return params.row?.showExtension ? (
          <Button disabled={!params.row?.enableExtension} onClick={() => handleClickExtend(params?.row)}>{t('metadata.extend.button.extend')}</Button>
        ) : (
          <></>
        );
      },
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={ExtendTableColumns}
        data={getExtendRecordsQuery?.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
      {(isOpenTimeExtension && extendDeadlineId && documentReviewId && documentReview?.documentName) && (
        <TimeExtensionDocumentReviewForm
          setIsOpen={(state, reload) => {
            setIsOpenTimeExtension(state);
            reload && reloadDetail?.();
          }}
          documentReviewId={documentReviewId}
          senderDocumentManagement={appContext?.me}
          isOpen={isOpenTimeExtension}
          timeExtensionRequestId={props?.isLcs ? undefined : extendDeadlineId}
          lcsTimeExtensionRequestId={props?.isLcs ? extendDeadlineId : undefined}
          isLcs={props.isLcs}
          lcsId={documentReview?.lcsId}
          name={documentReview?.documentName}
          isConfirmExtension
          handleSubmit={async () =>
            await queryClient.invalidateQueries(props.queryKey as any)
          }
        />
      )}
    </div>
  );
};
