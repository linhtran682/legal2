import { getDocumentReviewAssignments, getLcsAssignments } from '@/apis/service/document-review/assignmentDocumentReview';
import { commentDocumentReview, createDrrmMeeting, deleteDrrmMeeting, getDocumentReviewComments, getDocumentReviewHistory, getDocumentReviewInformationRequests, getDrrmMeeting, updateDrrmMeeting } from '@/apis/service/document-review/documentReview';
import { getFeedbackLcsTabFn, getFeedbackTabFn } from '@/apis/service/document-review/feedback';
import { getDocumentReviewForwards, getLcsForwards } from '@/apis/service/document-review/forwardDocumentReview';
import { getEvaluationTabFn } from '@/apis/service/document-review/lcsEvaluation';
import { commentLcs, getLcsComments, getLcsHistory } from '@/apis/service/document-review/legalCheckSheet';
import { getLcsInformationRequests } from '@/apis/service/document-review/requestAdditional';
import { LoadingWrapper } from '@/components/commons/loading_indicator/LoadingWrapper';
import { TabNav } from '@/components/commons/tab-nav/TabNav';
import { UploadPanel } from '@/components/commons/upload/upload_panel/UploadPanel';
import { COLOR_TYPE } from '@/constants/color';
import { AppContext } from '@/context/AppContext';
import { CommentPanel } from '@/features/metadata_tab_panel/comment_panel/CommentPanel';
import { InformationRequestPanel } from '@/features/metadata_tab_panel/information_request_panel/InformationRequestPanel';
import { AdviceAssignment, LegalAdviceForward } from '@/models/legal-advice/LegalAdviceList';
import { ForwardedRef, forwardRef, useContext, useImperativeHandle, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
// import { getSignerTab } from '@/apis/service/document-review/signer';
import { getLcsTimeExtensionList, getTimeExtensionList } from '@/apis/service/document-review/timeExtensionDocumentReview';
import { getAttachmentTab } from '@/apis/service/files_upload/files';
import { ReferenceFileTypes } from '@/constants/general';
import { LegalAdviceFeedbackPanel } from '@/features/legal-advice/legal-advice-tabs/legal-advice-feedback-panel/LegalAdviceFeedbackPanel';
// import { EvaluationPanel } from '@/features/metadata_tab_panel/evaluation_panel/EvaluationPanel';
import { GenericContentPanel } from '@/features/metadata_tab_panel/generic_content_panel/GenericContentPanel';
import { LANGUAGES } from '@/locales/config-translation';
import { DocumentReviewBodyReceive } from '@/models/document-review/DocumentReviewDetail';
import { DrrFeedbackItem } from '@/models/document-review/Feedback';
import { getUserLabel } from '@/utils';
import { DocumentReviewHistoryPanel } from './history-panel/HistoryPanel';
// import { SignerPanel } from './signer-panel/SignersPanel';
import { MeetingPanel } from '@/features/metadata_tab_panel/meeting_panel/MeetingPanel';
import { DrrmEvaluationPanel } from './evaluate-panel/EvaluatePanel';
import { DocumentReviewExtendPanel } from './time-extension-panel/TimeExtensionPanel';

export interface DocumentReviewTabsProps {
  documentReviewId: number;
  documentReview?: DocumentReviewBodyReceive;
  loading?: boolean;
  activeTab?: number;
  handleReloadDrrmQuery: () => void;
}
export interface DocumentReviewTabsRef {
  scrollToTab: (tab: number) => void;
}
const VIEW_ID = "document-review-tabs";
const DocumentReviewTabs = forwardRef(function DocumentReviewTabs(
  props: DocumentReviewTabsProps,
  ref: ForwardedRef<DocumentReviewTabsRef>
) {
  const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const { loading, handleReloadDrrmQuery } = props;
  const isEnglish = i18n.language === LANGUAGES.ENGLISH;
  const [activeIndex, setActiveIndex] = useState(0);

  const scrollToTab = (tab: number) => {
    setActiveIndex(tab);
    const tabElement = document.getElementById(VIEW_ID);
    setTimeout(() => tabElement?.scrollIntoView({
      behavior: 'smooth',
    }), 400)
  };

  useImperativeHandle(ref, () => ({
    scrollToTab: (tab: number) => scrollToTab(tab)
  }));

  const ownerRole = useMemo(() => {
    const roles = props.documentReview
      ?.userLastActionAndRoleResponse
      ?.userLastActionAndRoleList?.map((role) => role.role) ?? [];
    return roles;
  }, [props.documentReview]);

  return (
    <LoadingWrapper loading={loading || appContext.loading}>
      <div id={VIEW_ID} style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
        <TabNav
          index={activeIndex}
          onChangeTabIndex={setActiveIndex}
          tabItems={[
            // 1. Yêu cầu bổ sung thông tin
            {
              key: "information-request",
              label: t("metadata.informationRequest.title"),
              content: (
                <InformationRequestPanel
                  queryKey={props?.activeTab === 0
                    ? `drr-information-request-${props.documentReviewId}`
                    : `lcs-information-request-${props.documentReviewId}`
                  }
                  getInformationRequests={async () => {
                    if (props.activeTab === 1) {
                      return props.documentReview?.lcsId ? (await getLcsInformationRequests((props.documentReview?.lcsId)))
                        ?.detailInformationRequestResponses?.map((ele, index: number) => ({
                          ...ele,
                          id: index + 1
                        })) ?? [] : []
                    }
                    return (await getDocumentReviewInformationRequests((props.documentReviewId)))
                      ?.detailInformationRequestResponses?.map((ele, index: number) => ({
                        ...ele,
                        id: index + 1
                      })) ?? []

                  }
                  }
                />
              )
            },
            // 2. Phân công 
            {
              key: 'assignment',
              label: t('legalAdvice.tabs.assignment'),
              content: (
                <GenericContentPanel<AdviceAssignment>
                  getData={async () => {
                    if (props.activeTab === 1) {
                      return props?.documentReview?.lcsId ? (
                        (await getLcsAssignments(props.documentReviewId))
                          ?.assignmentResponseDetails ?? []
                      ) : []
                    }
                    return (
                      (await getDocumentReviewAssignments(props.documentReviewId))
                        ?.assignmentResponseDetails ?? []
                    )
                  }}
                  getTitle={(item) => getUserLabel(item.assignUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t(`DOCUMENT_REVIEW.tabs.${props.activeTab}`)}:  ${item?.receiveUsers?.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='legalAdvice.tabs.assignmentContent'
                  getContent={(item) => item.content}
                  queryKey={props?.activeTab === 0
                    ? `advice-assignment-${props.documentReviewId}`
                    : `lcs-assignment-${props.documentReviewId}`}
                />
              )
            },
            // 3. Đánh giá
            {
              key: "evaluation",
              label: t("metadata.evaluation.title"),
              content: (
                <DrrmEvaluationPanel
                  queryKey={`document-review-evaluation-${props.documentReviewId}`}
                  getEvaluations={async () => {
                    if (!props?.documentReview?.lcsId) return [];
                    return (await getEvaluationTabFn(props?.documentReview?.lcsId))
                      .result?.responses ?? []
                  }}
                />
              ),
            },
            // 4. Signer ký
            // {
            //   key: "signer",
            //   label: t("DOCUMENT_REVIEW.labels.signing"),
            //   content: (
            //     <SignerPanel
            //       queryKey="document-review-signer"
            //       getTabSigner={async () => {
            //         if (!props?.documentReview?.lcsId) return [];
            //         return (await getSignerTab(props.documentReview?.lcsId))
            //           ?.responses ?? []
            //       }}
            //     />
            //   ),
            // },
            // 5. Gia hạn thời gian
            {
              key: 'extend',
              label: t("metadata.extend.title"),
              content: (
                <DocumentReviewExtendPanel
                  isLcs={props.activeTab === 1}
                  documentReview={props.documentReview}
                  documentReviewId={props.documentReviewId}
                  reloadDetail={handleReloadDrrmQuery}
                  getExtendRecords={async () => {
                    if (props.activeTab === 1) {
                      return props.documentReview?.lcsId
                        ? ((await getLcsTimeExtensionList(props.documentReview?.lcsId))
                          ?.timeExtensionResponseDetails ?? [])
                        : []
                    }
                    return ((await getTimeExtensionList(props.documentReviewId))
                      ?.timeExtensionResponseDetails ?? [])

                  }}
                  queryKey={props.activeTab === 0 ? `document-review-extend-tab-${props.documentReviewId}` : `lcs-extend-tab-${props.documentReviewId}`}
                />
              )
            },
            // 6. Phản hồi
            {
              key: props.activeTab === 0 ? 'feedback-all' : 'feedback-lcs-all',
              label: t('DOCUMENT_REVIEW.labels.feedback'),
              content: (
                <LegalAdviceFeedbackPanel<DrrFeedbackItem>
                  getData={async () => {
                    if (props.activeTab === 1) {
                      return props.documentReview?.lcsId
                        ? (await getFeedbackLcsTabFn(props.documentReview?.lcsId))
                          ?.feedbackAdviseResponseDetails ?? []
                        : []
                    }
                    return (await getFeedbackTabFn(props.documentReviewId))
                      ?.feedbackResponseDetails ?? []
                  }}
                  getTitle={(item) => getUserLabel(item.feedbackUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t(`DOCUMENT_REVIEW.feedbackType.${(item?.feedbackType ?? item?.type) ?? 1}`)}: ${item.receiveUser
                    ? getUserLabel(item.receiveUser, isEnglish)
                    : item?.receiveUsers?.map?.((user) => getUserLabel(user, isEnglish)).join(', ')
                    }`}
                  contentHeaderFn={(item) => t(`DOCUMENT_REVIEW.feedbackContent.${(item?.feedbackType ?? item?.type) ?? 1}`)}
                  getContent={(item) => item.content}
                  queryKey={`request-feedback-${props.documentReviewId}`}
                />
              )
            },

            // 7. Chuyển tiếp
            {
              key: "forward",
              label: t("metadata.forward.title"),
              content: (
                <LegalAdviceFeedbackPanel<LegalAdviceForward>
                  getData={async () => {
                    if (props.activeTab === 1) {
                      return props.documentReview?.lcsId
                        ? (await getLcsForwards(props.documentReview?.lcsId))
                          ?.forwardResponseDetails ?? []
                        : []
                    }
                    return (await getDocumentReviewForwards(props.documentReviewId))
                      ?.forwardResponseDetails ?? []
                  }}
                  getTitle={(item) => `${getUserLabel(item.forwardUser, isEnglish)}`}
                  getDisplayDate={(item) => item.forwardDate}
                  getSubtitle={(item) => `${t('legalAdvice.tabs.forwardedTo')}:  ${item?.receiveUsers?.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='legalAdvice.forwardLegalAdvice.title.content'
                  getContent={(item) => item.content}
                  queryKey={props.activeTab === 0
                    ? `document-review-forward-${props.documentReviewId}`
                    : `lcs-forward-${props.documentReviewId}`
                  }
                />
              ),
            },
            // 7. Book lịch họp
            {
              key: "meeting",
              label: t("metadata.meeting.tab"),
              content: (
                <MeetingPanel
                  // containerHeight={props.containerHeight}
                  queryKey={`drrm-meeting-${props.documentReviewId}`}
                  reloadDetail={handleReloadDrrmQuery}
                  updateMeeting={(data) => updateDrrmMeeting({
                    id: props.documentReviewId,
                    content: data.content,
                    meetingId: data.meetingId
                  })
                  }
                  deleteMeeting={(meetingId) => deleteDrrmMeeting({
                    id: props.documentReviewId,
                    meetingId: meetingId
                  })}
                  getMeetings={async () => {
                    return (
                      (await getDrrmMeeting(props.documentReviewId))
                        .result?.meetingResponses ?? []
                    );
                  }}
                  addMeeting={(content) =>
                    createDrrmMeeting({
                      id: props.documentReviewId,
                      content: content,
                    })
                  }
                  disabled={
                    !appContext.meCanRead
                    || (!ownerRole.includes(1)
                      && !ownerRole.includes(2)
                      && !ownerRole.includes(4))
                  }
                />
              ),
            },
            // 8. Bình luận
            {
              key: "comment",
              label: t("metadata.comment.title"),
              content: (
                <CommentPanel
                  queryKey={props.activeTab === 0
                    ? `document-review-comment-${props.documentReviewId}`
                    : `lcs-comment-${props.documentReviewId}`}
                  getComments={async () => {
                    if (props.activeTab === 1) {
                      return props.documentReview?.lcsId
                        ? ((await getLcsComments(props.documentReview?.lcsId))
                          .result?.data ?? [])
                        : []
                    }
                    return (await getDocumentReviewComments(props.documentReviewId))
                      .result?.data ?? []

                  }}
                  addComment={(comment) => {
                    if (props.activeTab === 1 && props.documentReview?.lcsId) {
                      return commentLcs({
                        id: props.documentReview?.lcsId,
                        content: comment,
                      })
                    }
                    return commentDocumentReview({
                      id: props.documentReviewId,
                      content: comment,
                    })
                  }}
                  disabled={props.activeTab === 1 && !props.documentReview?.lcsId}
                // disabled={
                //   !appContext.meCanRead ||
                //   props.legalAdvice?.userLastActionAndLegalAdviceRoleResponse
                //     ?.userLastActionAndRoleList?.length === 0
                // }
                />
              ),
            },
            // 9. Đính kèm
            {
              key: "attachment",
              label: t("metadata.attachment.title"),
              content: (
                <UploadPanel
                  queryKey={props.activeTab === 0 ? `document-review-upload-${props.documentReviewId}` : `lcs-attachment-tab-${props.documentReviewId}`}
                  onGetFiles={async () => {
                    return (await getAttachmentTab({
                      documentId: props.documentReviewId,
                      referenceFileTypes: (props.activeTab === 0 ? [
                        ReferenceFileTypes.REQUEST_REVIEW_DOCUMENT_ATTACHMENT_TAB,
                        ReferenceFileTypes.REQUEST_REVIEW_DOCUMENT_ATTACHMENT,
                        ReferenceFileTypes.BACKDATE_APPROVAL_EMAIL_ATTACHMENT,
                        ReferenceFileTypes.SAMPLE_CONTRACT_ATTACHMENT,
                        ReferenceFileTypes.REQUEST_REVIEW_DOCUMENT_INSPECTION_ATTACHMENT,
                      ] : [
                        ReferenceFileTypes.LEGAL_CHECK_SHEET
                      ])
                        .join(',')
                    }))?.data ?? []
                  }
                  }
                  onDelete={() => Promise.resolve()}
                  onUpload={async () => { }}
                  disabled
                />
              ),
            },
            // 10. Lịch sử
            {
              key: "history",
              label: t("metadata.history.title"),
              content: (
                <DocumentReviewHistoryPanel
                  queryKey={props.activeTab === 0 ? `document-review-history-${props.documentReviewId}` : `lcs-history-tab-${props.documentReviewId}`}
                  isLegalCheckSheet={props.activeTab === 1}
                  getHistoryRecords={async () => {
                    if (props.activeTab === 1) {
                      return props.documentReview?.lcsId
                        ? (await getLcsHistory(props?.documentReview?.lcsId)).result
                          ?.data ?? []
                        : []
                    }
                    return (await getDocumentReviewHistory(props.documentReviewId)).result
                      ?.data ?? []
                  }}
                />
              ),
            },
          ]}
        />
      </div>
    </LoadingWrapper>
  )
})

export default DocumentReviewTabs