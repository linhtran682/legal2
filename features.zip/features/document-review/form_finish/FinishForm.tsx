import { finishAllMutationFn, finishReviewMutationFn } from '@/apis/service/document-review/finishReview';
import { getStatusListNames } from '@/apis/service/status/Status';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormTextArea } from '@/components/commons/form_inputs/FormTextArea';
import { ModalCommon } from '@/components/commons/popups/modal/Modal';
import { GLOBAL_SPACING } from '@/constants/format';
import { ModuleFields } from '@/constants/general';
import { formInputSxProps } from '@/constants/theme';
import { ReminderPickerSubForm } from '@/features/reminder_template/reminder_picker/ReminderPickerSubForm';
import { DONE_STATUS, LCS_DONE_STATUS } from '@/models/document-review/DocumentReviewDetail';
import { castFinishReviewDTO, FinishReviewSchema } from '@/models/document-review/FinishReview';
import { StatusDTO } from '@/models/status/Status';
import { UserProfileDTO } from '@/models/user/User';
import { getUserLabel, removeVietnameseTones } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import { Grid, InputLabel, Typography } from '@mui/material';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';


export interface FinishFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  initialValues?: any;
  // selectedDocuments?: BasedLegalDocument[];
  module?: number;
  sender?: any;
  lcsId?: number;
}
const FinishForm = (props: FinishFormProps) => {

  const {
    isOpen,
    setIsOpen,
    lcsId, initialValues, documentReviewId,
    name, sender, titlePopup = 'DOCUMENT_REVIEW.popup.finish'
  } = props;
  const { t } = useTranslation();

  const form = useForm<any>({
    resolver: yupResolver(FinishReviewSchema),
    mode: 'onBlur'
  });


  useEffect(() => {
    getStatusListQuery.refetch().then((res) => {
      const finishReviewStatus = res.data
        ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
          === removeVietnameseTones(DONE_STATUS).trim())
      finishReviewStatus?.id && form?.setValue?.('status', finishReviewStatus?.id);
    })
    // form?.setValue?.('status', LCS_DONE_STATUS);
    initialValues?.userIds && form?.setValue?.('userIds', initialValues?.userIds);
  }, [initialValues])

  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list-finish-form'],
    queryFn: async () => {
      const response = await getStatusListNames({
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
        names: [DONE_STATUS]
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: false
  });

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };


  const { mutateAsync: finishAllAsync, isPending } = useMutation({
    mutationFn: finishAllMutationFn,
    onSuccess: () => {
    },
  })

  const finishReviewMutation = useMutation({
    mutationFn: finishReviewMutationFn,
    onSuccess: () => {
    },
  })

  const onSave = async (data: any) => {
    try {
      lcsId && (await finishAllAsync({
        lcsId: lcsId,
        data: {
          ...castFinishReviewDTO(data),
          status: LCS_DONE_STATUS
        }
      }));
      documentReviewId && (await finishReviewMutation.mutateAsync({
        documentReviewId,
        data: castFinishReviewDTO(data)
      }));

      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm(true);
    } catch (error) {

    }

  }



  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <FormProvider {...form}>
        <Grid container className="form-wrapper" marginTop="20px">
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={{ ...formInputSxProps, paddingBottom: 0 }}
          >

            <Grid item width={"100%"}>
              <Typography fontWeight="bold">
                {t("DOCUMENT_REVIEW.field_name.documentName")}
              </Typography>
              <Typography>{name}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <InputLabel>
                {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
              </InputLabel>
              {sender && (
                <Typography>
                  {getUserLabel(sender)}
                </Typography>
              )}
            </Grid>

            {/* <Grid item width={"100%"}>
              <FormAsyncSelect
                control={form.control}
                name={'status'}
                label={t(`legalAdvice.requestAdditional.title.status`)}
                placeholder={t(`legalAdvice.requestAdditional.title.status`)}
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                keyQuery={"status-query"}
                getOptions={async (keyword) => {
                  if (typeof keyword == "string") {
                    const response = await getStatusListNames({
                      names: [DONE_STATUS],
                      modules: [ModuleFields.DOCUMENT_REVIEW.module],
                    });

                    return response?.statusResponses || [];
                  } else {
                    if (keyword?.length && keyword.length > 0) {
                      return getStatus(Number(keyword[0])).then((value) =>
                        value ? [value] : []
                      );
                    }
                  }

                  return [] as StatusDTO[];
                }}
                getOptionKey={(option) => option.id.toString()}
                getOptionLabel={(option) => option.name}
                required
                disabled
              />
            </Grid> */}

            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={'content'}
                label={t(`DOCUMENT_REVIEW.popup.content`)}
                placeHolder={t(`DOCUMENT_REVIEW.popup.content`)}
                minRows={3}
                required
              />
            </Grid>
            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={'userIds'}
                label={t('legalAdvice.label.receiver')}
                placeholder={t('legalAdvice.label.receiver')}
                minCharLength={1}
                getOptions={async (keyword) => {
                  // if (!getLegalDepartmentQuery.data) return []
                  // const advisorIds = getAssignedPersonQuery?.data?.users?.map((user) => user.id) ?? [];
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                    // departmentIds: getLegalDepartmentQuery.data ? [getLegalDepartmentQuery.data] : []
                  });
                  return response?.users ?? []
                  // ?.map((user, index) => ({
                  //   ...user,
                  //   rank: advisorIds?.includes(user.id) ? index : 99999
                  // }))?.sort((first, second) => first.rank - second.rank)
                  // ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? (option?.departmentName ?? '')
                  }`
                }
                required
                getOptionKey={(option) => option.id}
                keyQuery='queryAdvisor'
                isFocus
              />
            </Grid>
          </Grid>
          <Grid item>
            <ReminderPickerSubForm
              name={'remind'}
              module={ModuleFields.DOCUMENT_REVIEW.module}
              placeholder={t('menu.reminder')}
            />
          </Grid>
        </Grid>
        <FormActionButtons
          formMode={"update"}
          loading={isPending}
          onCancel={() => onCloseForm()}
          cancelConfirm={form.formState.isDirty}
          onSave={onSave}
        />
      </FormProvider>
    </ModalCommon>
  )
}

export default FinishForm