import { IconWarning } from '@/assets/iconMenu/IconWarning'
import { COLOR_TYPE } from '@/constants/color'
import { GLOBAL_SPACING } from '@/constants/format'
import { Button, Dialog, Grid, InputLabel, Typography } from '@mui/material'
import { ReactNode } from 'react'
import { useTranslation } from 'react-i18next'

export interface WarningDialogProps {
  open?: boolean;
  icon?: ReactNode;
  title?: string;
  textCancel?: string;
  onClose?: () => void;
  reason?: string | null;
}

const WarningDialog = (props: WarningDialogProps) => {
  const [t] = useTranslation();
  const {
    // icon,
    textCancel = "common.button.close",
    title = "Call eSign",
    onClose,
    reason
  } = props;
  return (
    <Dialog open={true}>
      <Grid
        container
        direction={"column"}
        alignItems={"center"}
        spacing={GLOBAL_SPACING}
        padding={"1.5rem 2rem"}
        borderRadius={"5px"}
      >
        <Grid item>
          <Typography variant="h5">{t(title)}</Typography>
        </Grid>
        <Grid item width={"100%"} display={"flex"} flexDirection={"row"} alignItems={"center"} gap={1}>
          <IconWarning />
          <Typography sx={{ fontSize: '14px', display: 'inline', color: COLOR_TYPE.TOYOTA.TOYOTA1 }}>
            {t("DOCUMENT_REVIEW.labels.createApprovalInquiry")}
            <Typography variant="h5" sx={{ fontSize: '14px', display: 'inline' }}>
              {" "}{t("DOCUMENT_REVIEW.labels.withinOrAfter")}{" "}
            </Typography>
            {t("DOCUMENT_REVIEW.labels.contractDate")}
          </Typography>
        </Grid>
        <Grid item width={"100%"}>
          <InputLabel sx={{ fontSize: '14px', }}>{t("DOCUMENT_REVIEW.popup.reason")}</InputLabel>
          <Typography>{reason}</Typography>
        </Grid>
        <Grid item width={"100%"}>
          <Button
            variant="contained"
            color="primary"
            className="cancel"
            onClick={onClose}
            fullWidth
          >
            {t(textCancel)}
          </Button>
        </Grid>
      </Grid>
    </Dialog>
  )
}

export default WarningDialog