import { IconWarning } from "@/assets/iconMenu/IconWarning";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { VALIDATION_MSG } from "@/constants/message";
import { formInputSxProps } from "@/constants/theme";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, Typography } from "@mui/material";
import { isBefore, startOfDay } from "date-fns";
import { ReactNode, useMemo } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import * as Yup from 'yup';

export interface EsignFormProps {
  icon?: ReactNode;
  title?: string;
  open: boolean;
  handleCancel: () => void;
  handleConfirm?: (content?: string, reasonForLate?: string) => void;
  loading?: boolean;
  signingDate?: string;
}

export const DefaultEsignFormState: EsignFormProps = {
  open: false,
  handleConfirm: () => { },
  handleCancel: () => { },
  icon: <></>,
  title: "",
  signingDate: ""
};

export const EsignForm = ({
  handleCancel,
  handleConfirm,
  open,
  title = 'Call eSign',
  loading,
  signingDate
}: EsignFormProps) => {
  const [t] = useTranslation();

  const showWarning = useMemo(() => {
    const startOfSignDate = signingDate ? startOfDay(new Date(signingDate)) : undefined;
    if (!startOfSignDate) return false;
    const startOfToday = startOfDay(new Date());
    return !isBefore(startOfToday, startOfSignDate);
  }, [signingDate]);


  const validateReason = Yup.object().shape({
    reasonForLate: Yup.string()
      .when('status', {
        is: () => showWarning,
        then: () => Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }),
    content: Yup.string().optional()
  })

  const form = useForm({
    resolver: yupResolver(validateReason),
    disabled: loading
  });

  return (
    <ModalCommon title={t(title)} open={open} onClose={handleCancel}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={{ ...formInputSxProps, paddingBottom: 0 }}
          >
            {showWarning ? <>
              <Grid item width={"100%"} display={"flex"} flexDirection={"row"} alignItems={"center"} gap={1}>
                <IconWarning />
                <Typography sx={{ fontSize: '14px', display: 'inline', color: COLOR_TYPE.TOYOTA.TOYOTA1 }}>
                  {t("DOCUMENT_REVIEW.labels.createApprovalInquiry")}
                  <Typography variant="h5" sx={{ fontSize: '14px', display: 'inline' }}>
                    {" "}{t("DOCUMENT_REVIEW.labels.withinOrAfter")}{" "}
                  </Typography>
                  {t("DOCUMENT_REVIEW.labels.contractDate")}
                </Typography>
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={'reasonForLate'}
                  label={t("DOCUMENT_REVIEW.popup.reason")}
                  placeHolder={t("DOCUMENT_REVIEW.popup.reason")}
                  minRows={3}
                  required
                />
              </Grid>
            </> : null}
            <Grid item width={"100%"} mb={2}>
              <FormTextArea
                control={form.control}
                name={'content'}
                label={t("DOCUMENT_REVIEW.labels.contentCallEsign")}
                placeHolder={t("DOCUMENT_REVIEW.labels.contentCallEsign")}
                minRows={3}
              />
            </Grid>

          </Grid>
          <FormActionButtons
            formMode="create"
            textSave="common.button.send"
            loading={loading}
            onCancel={handleCancel}
            isShowConfirm
            onSave={(data: any) => {
              handleConfirm?.(data?.content, data?.reasonForLate);
            }}
          />
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
