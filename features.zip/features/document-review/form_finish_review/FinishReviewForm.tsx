import { finishReviewMutationFn } from '@/apis/service/document-review/finishReview';
import { getStatusList } from '@/apis/service/status/Status';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormTextArea } from '@/components/commons/form_inputs/FormTextArea';
import { ModalCommon } from '@/components/commons/popups/modal/Modal';
import { GLOBAL_SPACING } from '@/constants/format';
import { ModuleFields } from '@/constants/general';
import { formInputSxProps } from '@/constants/theme';
import { ReminderPickerSubForm } from '@/features/reminder_template/reminder_picker/ReminderPickerSubForm';
import { DocumentReviewStatusList } from '@/models/document-review/DocumentReviewDetail';
import { castFinishReviewDTO, FinishReviewSchema } from '@/models/document-review/FinishReview';
import { StatusDTO, StatusFieldNames } from '@/models/status/Status';
import { UserProfileDTO } from '@/models/user/User';
import { getUserLabel, removeVietnameseTones } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import { Grid, InputLabel, Typography } from '@mui/material';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';


export interface FinishReviewFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  documentReviewId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  initialValues?: any;
  module?: number;
  sender?: any;
  defaultStatus?: string;
}
const FinishReviewForm = (props: FinishReviewFormProps) => {
  const {
    isOpen,
    setIsOpen,
    documentReviewId,
    initialValues,
    name, sender,
    defaultStatus = DocumentReviewStatusList.DONE_DOCUMENT_REVIEW,
    titlePopup = 'DOCUMENT_REVIEW.popup.finishReview'
  } = props;
  const { t } = useTranslation();

  const form = useForm<any>({
    resolver: yupResolver(FinishReviewSchema),
    mode: 'onBlur',
    defaultValues: initialValues,
  });

  useEffect(() => {
    getStatusListQuery.refetch().then((res) => {
      const finishReviewStatus = res.data
        ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
          === removeVietnameseTones(defaultStatus).trim())
      finishReviewStatus?.id && form?.setValue?.('status', finishReviewStatus?.id);
    })
  }, [])

  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.ID,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: false
  });

  const finishReviewMutation = useMutation({
    mutationFn: finishReviewMutationFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm(true);
    },
  })

  const onSubmit = async (data: any) => {
    documentReviewId && (await finishReviewMutation.mutateAsync({
      documentReviewId,
      data,
    }));
  };

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <FormProvider {...form}>
        <Grid container className="form-wrapper" marginTop="20px">
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={{ ...formInputSxProps, paddingBottom: 0 }}
          >

            <Grid item width={"100%"}>
              <Typography fontWeight="bold">
                {t("DOCUMENT_REVIEW.field_name.documentName")}
              </Typography>
              <Typography>{name}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <InputLabel>
                {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
              </InputLabel>
              {sender && (
                <Typography>
                  {getUserLabel(sender)}
                </Typography>
              )}
            </Grid>

            {/* <Grid item width={"100%"}>
              <FormAsyncSelect
                control={form.control}
                name={'status'}
                label={t(`legalAdvice.requestAdditional.title.status`)}
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                keyQuery={"status-query"}
                getOptions={async (keyword) => {
                  if (typeof keyword == "string") {
                    const response = await getStatusListNames({
                      names: Object.values(DocumentReviewStatusList),
                      modules: [ModuleFields.DOCUMENT_REVIEW.module],
                    });

                    return response?.statusResponses || [];
                  } else {
                    if (keyword?.length && keyword.length > 0) {
                      return getStatus(Number(keyword[0])).then((value) =>
                        value ? [value] : []
                      );
                    }
                  }

                  return [] as StatusDTO[];
                }}
                getOptionKey={(option) => option.id.toString()}
                getOptionLabel={(option) => option.name}
                required
                disabled
              />
            </Grid> */}

            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={'content'}
                label={t('legalAdvice.label.content')}
                placeHolder={t('legalAdvice.label.content')}
                minRows={3}
                required
              />
            </Grid>
            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={'userIds'}
                label={t('legalAdvice.label.receiver')}
                placeholder={t('legalAdvice.label.receiver')}
                minCharLength={1}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });
                  return response?.users ?? []
                }}
                getOptionLabel={(option) =>
                  `${option?.name ?? ""} (${option?.email ?? ""}) - ${option?.department?.name ?? (option?.departmentName ?? '')
                  }`
                }
                required
                getOptionKey={(option) => option.id}
                keyQuery='finish-review/receivers'
                isFocus
              />
            </Grid>
          </Grid>
          <Grid item>
            <ReminderPickerSubForm
              name={'remind'}
              module={ModuleFields.DOCUMENT_REVIEW.module}
              placeholder={t('menu.reminder')}
            />
          </Grid>
          <FormActionButtons
            formMode="create"
            textSave="common.button.send"
            loading={finishReviewMutation.isPending}
            onCancel={onCloseForm}
            onSave={async () => {
              try {
                onSubmit(
                  castFinishReviewDTO({
                    ...form.getValues(),
                  })
                );
              } catch (error) { }
            }}
          />
        </Grid>
      </FormProvider>
    </ModalCommon>
  )
}

export default FinishReviewForm