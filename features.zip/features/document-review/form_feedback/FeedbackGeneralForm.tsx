import { createLcsFeedbackFn, useCreateFeedbackDocumentReview } from "@/apis/service/document-review/feedback";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  castFeedbackRequestSchemaToDTO,
  FeedbackFieldNames,
  FeedbackSchema,
  FeedbackSchemaI,
} from "@/models/document-review/Feedback";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, InputLabel, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const initialEmptyValue: FeedbackSchemaI = {
  [FeedbackFieldNames.USERS]: [],
  [FeedbackFieldNames.DEADLINE]: "",
  [FeedbackFieldNames.CONTENT]: "",
  [FeedbackFieldNames.REMIND]: undefined,
};

export interface FeedbackGeneralFormProps {
  titlePopup?: string;
  initialValue?: FeedbackSchemaI;
  documentReviewId?: number;
  lcsId?: number;
  isLcs?: boolean;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  minDateReturnAdvice?: Date | undefined;
  senderDocumentManagement?: any;
}

export const FeedbackGeneralForm = (
  props: FeedbackGeneralFormProps
) => {
  const {
    titlePopup = "legalAdvice.feedbackLegalAdvice.title.titlePopup",
    initialValue = initialEmptyValue,
    documentReviewId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DOCUMENT),
    minDateReturnAdvice = undefined,
    senderDocumentManagement,
    isLcs,
    lcsId
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(FeedbackSchema),
    defaultValues: initialValue,
  });
  useEffect(() => {
    initialValue?.deadline && form.setValue(FeedbackFieldNames.DEADLINE,
      initialValue?.deadline
        ? new Date(initialValue?.deadline)
        : undefined)
  }, [initialValue])

  const { mutateAsync: createDocumentReviewFeedback, isPending } =
    useCreateFeedbackDocumentReview({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const { mutateAsync: createLcsFeedback, isPending: isLcsPending } = useMutation({
    mutationFn: createLcsFeedbackFn,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm(true);
    },
  })

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    const { ...restData } = data;
    (documentReviewId && !isLcs) && (await createDocumentReviewFeedback({
      documentReviewId,
      data: restData,
    }));
    (lcsId && isLcs) && (await createLcsFeedback({
      lcsId,
      request: restData,
    }));
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_REVIEW.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <InputLabel >
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </InputLabel>
                {senderDocumentManagement && (
                  <Typography>
                    {getUserLabel(senderDocumentManagement)}
                  </Typography>
                )}
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >

              </Grid>
              <Grid item width={"100%"}>
                <DateTimeInput
                  name={FeedbackFieldNames.DEADLINE}
                  control={form.control}
                  minDate={minDateReturnAdvice}
                  label={t(`DOCUMENT_REVIEW.field_name.responseDeadlineType`)}
                  placeholder="dd/mm/yyyy hh:mm"
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedbackFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.feedbackLegalAdvice.title.${FeedbackFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.feedbackLegalAdvice.placeHolder.${FeedbackFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={FeedbackFieldNames.USERS}
                  label={t("legalAdvice.feedbackLegalAdvice.title.receiver")}
                  placeholder={t('common.place_holder.enter_name_code')}
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"feedbackDocumentReview/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={FeedbackFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isLcsPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedbackRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
