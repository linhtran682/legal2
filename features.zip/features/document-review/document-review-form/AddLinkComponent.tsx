'use client'
import { FormTextField } from '@/components/commons/form_inputs/FormTextField';
import { IconButton, Stack, Typography } from '@mui/material';
import React, { useState } from 'react'
import { useFormContext } from 'react-hook-form';
import NorthEastRoundedIcon from '@mui/icons-material/NorthEastRounded';
import { REGEX_LINK } from '@/constants/regex';

interface AddLinkComponentProps {
  name: string;
  label?: string;
  placeholder?: string;
}

const AddLinkComponent = (props: AddLinkComponentProps) => {
  const {
    name,
    label,
    placeholder
  } = props;

  const [editLink, setEditLink] = useState<boolean>(false);

  const form = useFormContext();

  const linkValue = form.watch(name)
  const error = form.formState?.errors?.[name]

  return !editLink ? (
    <Typography onClick={() => setEditLink(true)} sx={{ cursor: 'pointer', color: '#007AFF', textDecorationLine: 'underline' }}>Add link</Typography>
  ) : <>
    <Stack flex={1}>
      <FormTextField
        control={form.control}
        name={name}
        label={label}
        placeHolder={placeholder}
      />
    </Stack>
    <IconButton sx={{ ml: 1, mb: error ? 3 : undefined }} disabled={!REGEX_LINK.test(linkValue)} onClick={() => window.open(linkValue)}>
      <NorthEastRoundedIcon />
    </IconButton>
  </>
}

export default AddLinkComponent