import { getAssignedPerson } from '@/apis/service/assignment/Assignment';
import { getCurrencies, getCurrency } from '@/apis/service/currency/Currency';
import { getDepartmentHeads, getLegalDepartments } from '@/apis/service/department/department';
import { getHelpList } from '@/apis/service/help/Help';
import { getStatusList } from '@/apis/service/status/Status';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormAsyncSelect } from '@/components/commons/form_inputs/FormAsyncSelect';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormSelect } from '@/components/commons/form_inputs/FormSelect';
import { FormTextArea } from '@/components/commons/form_inputs/FormTextArea';
import { FormTextField } from '@/components/commons/form_inputs/FormTextField';
import { RadioGroupField } from '@/components/commons/form_inputs/RadioGroupField';
import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import DateInput from '@/components/commons/inputs/date_input/DateInput';
import DateTimeInput from '@/components/commons/inputs/date_time_input/DateTimeInput';
import DropPreviewFileUploadComponent from '@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload';
import { COLOR_TYPE } from '@/constants/color';
import { GLOBAL_SPACING } from '@/constants/format';
import { ModuleFields } from '@/constants/general';
import { THOUSAND_SEPARATOR } from '@/constants/regex';
import { formInputSxProps } from '@/constants/theme';
import { AppContext } from '@/context/AppContext';
import { HelpTableConst } from '@/features/help/help_table/HelperTable';
import { ConvertDataCodetoNameHelp } from '@/features/legal-document/form-legal-document/LegalDocumentForm';
import { ReminderPickerSubForm } from '@/features/reminder_template/reminder_picker/ReminderPickerSubForm';
import { CurrencyDTO } from '@/models/currency/Currency';
import { AttachmentTypes, DocumentReviewBodyReceive, DocumentReviewBodySend, DocumentReviewRequestSchema, DocumentReviewStatusList, DONE_STATUS, DocumentReviewDetailFields as Fields } from '@/models/document-review/DocumentReviewDetail';
import { castReminderInputToReminderSchema, castReminderSchemaToSaveReminderDTO } from '@/models/reminder_template/ReminderDTO';
import { StatusDTO, StatusFieldNames } from '@/models/status/Status';
import { BasedUser, UserProfileDTO } from '@/models/user/User';
import { removeVietnameseTones } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import { FormHelperText, Grid, Stack, Typography } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { add, isBefore, isValid, startOfDay } from 'date-fns';
import { ForwardedRef, forwardRef, ReactNode, useContext, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import ReviewList from '../document-review-form-list/ReviewList';
import AddLinkComponent from './AddLinkComponent';


export interface DocumentReviewFormProps {
  formMode?: "create" | "update";
  initialValue?: any;
  onSubmit: (data: any) => void;
  onSubmitDraft?: (data: any) => void;
  onCancel: () => void;
  loading?: boolean;
  initialValueReceive?: DocumentReviewBodyReceive;
  children?: ReactNode;
}

export interface DocumentReviewFormRef {
  getParams: () => DocumentReviewBodySend;
}

const FIELD_PATH = "DOCUMENT_REVIEW.field_name"
const LABEL_PATH = "DOCUMENT_REVIEW.labels"

const initialEmptyValue = {
  checkDeptHeadFlag: true,
  checkDivisionFlag: true,
  signers: [],
  purpose: 1,
  backdateApprovalEmailAttachmentType: -1
}

const DocumentReviewForm = forwardRef(function DocumentReviewForm(
  props: DocumentReviewFormProps,
  ref: ForwardedRef<DocumentReviewFormRef>
) {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const formRef = useRef<HTMLFormElement>(null);
  const [departmentId, setDepartmentId] = useState<string>('');
  const [files, setFiles] = useState<any>([]);
  const [backdateFiles, setBackdateFiles] = useState<any>([]);
  const [contractFiles, setContractFiles] = useState<any>([]);
  const [confirmed, setConfirmed] = useState<boolean>(false);

  const { formMode = 'create' } = props;

  useImperativeHandle(ref, () => ({
    getParams: () => handleSaveParams()
  }))

  // const validateVendorDate = Yup.object().shape({
  //   [DocumentReviewDetailFields.VENDOR_RESPONSE_DATE]: Yup.mixed()
  //     .when('status', {
  //       is: () => isRequestVendorReview,
  //       then: () => Yup.date().typeError(VALIDATION_MSG.ENTER_VALID_VALUE).required(VALIDATION_MSG.REQUIRED_FIELD),
  //       otherwise: (schema) => schema.optional().nullable(),
  //     }),
  // })

  const isStatusDone = props?.initialValueReceive?.status?.name === DONE_STATUS;
  const isRequestInformation = useMemo(() => props?.initialValueReceive?.status?.name
    === DocumentReviewStatusList.REQUEST_INFORMATION
    , [props?.initialValueReceive?.status]);

  //DocumentReviewFormSend
  const form = useForm<any>({
    resolver: yupResolver(DocumentReviewRequestSchema),
    // resolver: yupResolver(DocumentReviewRequestSchema.concat(validateVendorDate)),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: 'onBlur',
    disabled: !appContext.meCanWrite
      || (props.formMode === "update" && !ownRole.includes(1))
      || (props.formMode === "update" && !isRequestInformation && !props.initialValueReceive?.isDraft)
    ,
  });

  useEffect(() => {
    if (formMode === 'create') {
      getAssignedPersonQuery.refetch().then((res) => {
        form?.setValue(Fields.RECEIVERS, res.data?.users ?? [])
      })
      getStatusListQuery.refetch().then((res) => {
        const requestReviewStatus = res.data
          ?.find((ele: StatusDTO) => removeVietnameseTones(ele?.name).trim()
            === removeVietnameseTones(DocumentReviewStatusList.REQUEST_REVIEW).trim())
        requestReviewStatus?.id && form?.setValue?.('status', requestReviewStatus?.id);
      })
      form?.setValue(Fields.CONTRACT_VALUE, '0');
      form?.setValue(Fields.RESPONSIBLE_USERS, appContext?.me ? [appContext?.me] : []);
    }
  }, [])

  useEffect(() => {
    if (props.initialValueReceive) {
      if (props?.initialValueReceive?.attachments) {
        let attachments: any[] = [];
        if (props?.initialValueReceive?.attachments.length) {
          attachments = props.initialValueReceive.attachments?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setFiles([...attachments]);
      }
      if (props?.initialValueReceive?.backdateApprovalEmailAttachmentFiles) {
        let attachments: any[] = [];
        if (props?.initialValueReceive?.backdateApprovalEmailAttachmentFiles.length) {
          attachments = props.initialValueReceive.backdateApprovalEmailAttachmentFiles?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setBackdateFiles([...attachments]);
      }
      if (props?.initialValueReceive?.sampleContractAttachmentFiles) {
        let attachments: any[] = [];
        if (props?.initialValueReceive?.sampleContractAttachmentFiles.length) {
          attachments = props.initialValueReceive.sampleContractAttachmentFiles?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setContractFiles([...attachments]);
      }
      if (props?.initialValueReceive?.attachments) {
        let attachments: any[] = [];
        if (props?.initialValueReceive?.attachments.length) {
          attachments = props.initialValueReceive.attachments?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setFiles([...attachments]);
      }
      // const files =
      //   disableSpecialFields
      //     ? props.initialValueReceive?.attachments
      //     : props.initialValueReceive?.attachments?.length
      //       ? props.initialValueReceive?.attachments
      //       : null;
      !!props.initialValueReceive?.confirmWithManagementLevelFlag && setConfirmed(true);
      props.initialValueReceive &&
        form.reset({
          ...props.initialValueReceive,
          files,
          // fieldId: props.initialValueReceive?.field?.id,
          confirmWithManagementLevelFlag: !!props.initialValueReceive?.confirmWithManagementLevelFlag,
          backDateAttachments: props.initialValueReceive?.backdateApprovalEmailAttachmentFiles,
          contractAttachments: props.initialValueReceive?.sampleContractAttachmentFiles,
          status: props.initialValueReceive?.status?.id,
          contractValue: props.initialValueReceive?.contractValue?.toString()?.replace(THOUSAND_SEPARATOR, ",") || '',
          contractCurrency: props.initialValueReceive?.currency?.id,
          receivers: props?.initialValueReceive?.receiverUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          signers: props?.initialValueReceive?.signerList?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          responsibleUsers: props?.initialValueReceive?.responsibleUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          assignUsers: props?.initialValueReceive?.assignUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          relatedUsers: props?.initialValueReceive?.relateUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          vendorResponseDate: props?.initialValueReceive?.vendorResponseDate
            ? new Date(props?.initialValueReceive?.vendorResponseDate)
            : undefined,
          backdateApprovalEmailDebtDate: props?.initialValueReceive?.backdateApprovalEmailDebtDate
            ? new Date(props?.initialValueReceive?.backdateApprovalEmailDebtDate)
            : undefined,
          signingDate: props?.initialValueReceive?.signingDate
            ? new Date(props?.initialValueReceive?.signingDate)
            : undefined,
          effectiveDate: props?.initialValueReceive?.effectiveDate
            ? new Date(props?.initialValueReceive?.effectiveDate)
            : undefined,
          effectiveEndDate: props?.initialValueReceive?.effectiveEndDate
            ? new Date(props?.initialValueReceive?.effectiveEndDate)
            : undefined,
          responseDate: props?.initialValueReceive?.responseDeadlineType === 1 && props?.initialValueReceive?.responseDate
            ? new Date(props?.initialValueReceive?.responseDate)
            : undefined,
          urgentResponseDate: props?.initialValueReceive?.responseDeadlineType === 2 && props?.initialValueReceive?.responseDate
            ? new Date(props?.initialValueReceive?.responseDate)
            : undefined,
          remind: props.initialValueReceive.remind?.title
            ? castReminderInputToReminderSchema(
              props.initialValueReceive!.remind!
            )
            : undefined,
        });
      if (props.initialValueReceive?.userLastActionAndRoleResponse?.userLastActionAndRoleList?.length) {
        const { userLastActionAndRoleResponse: { userLastActionAndRoleList } } = props.initialValueReceive;
        const roleList = userLastActionAndRoleList?.map((ele) => ele.role)
        setOwnRole(roleList);
      } else {
        setOwnRole([]);
      }
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValueReceive]);


  const getLegalDepartmentQuery = useQuery({
    queryKey: ['legal-advice/get-legal-department'],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(response?.departments?.length ? response?.departments?.[0] : null)
        setDepartmentId(deepestId?.id ?? '')
        return deepestId?.id ?? null
      } catch (error) {
      }
      return null
    },
    placeholderData: prev => prev,
  })

  const getAssignedPersonQuery = useQuery({
    queryKey: ['document-review/get-legal-assigned-person'],
    queryFn: () => getAssignedPerson(),
    placeholderData: prev => prev,
    enabled: false
  })

  const getDepartmentHeadQuery = useQuery({
    queryKey: ['document-review/get-department-heads'],
    queryFn: () => getDepartmentHeads(departmentId),
    placeholderData: prev => prev,
    enabled: !!departmentId?.length
  })

  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.ID,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: true
  });

  const getHelpListQuery = useQuery({
    queryKey: [HelpTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () =>
      getHelpList({
        page: 0,
        size: 999,
        sortBy: "id",
        orderBy: "DESC",
        modules: [3],
      }),
  });

  const getExplanation = (fieldName: string) => {
    const helpList = ConvertDataCodetoNameHelp(
      fieldName,
      getHelpListQuery.data?.fieldResponses
    );

    return helpList.length > 0 && helpList[0].active === 1
      ? helpList[0].description
      : "";
  };

  const deadlineType = form.watch(Fields.RESPONSE_TYPE);
  // const status = form.watch('status');
  const checkDeptHeadFlag = form.watch('checkDeptHeadFlag');
  const checkDivisionFlag = form.watch('checkDivisionFlag');
  const attachmentType = form.watch('attachmentType');
  const effectiveDate = form.watch('effectiveDate');
  const backdateApprovalEmailAttachmentType = form.watch('backdateApprovalEmailAttachmentType');
  const sampleType = form.watch(Fields.SAMPLE);
  // const confirmedWithManagers = form.watch(Fields.CONFIRMED_WITH_MANAGERS);

  const showBackDateApproval = isValid(new Date(effectiveDate))
    && isBefore(startOfDay(new Date(effectiveDate)), startOfDay(new Date()));

  useEffect(() => {
    if (!showBackDateApproval) {
      form?.setValue?.('backdateApprovalEmailAttachmentType', -1);
      form.setValue(Fields.BACKDATE_DUE_DATE, undefined);
      form.setValue(Fields.BACKDATE_DEBT_REASON, undefined);
      form.setValue('backDateAttachments', []);
      setBackdateFiles([]);
    }
  }, [showBackDateApproval])


  const sendToError = !checkDeptHeadFlag && !checkDivisionFlag
  // const isRequestVendorReview = removeVietnameseTones(getStatusListQuery?.data
  //   ?.find((ele: StatusDTO) => ele.id === Number(status))
  //   ?.name?.toLocaleLowerCase() || '') === removeVietnameseTones('gửi vendor kiểm tra');


  const handleSaveParams = () => {

    const receiverUsers = form.getValues(Fields.RECEIVERS);
    const relatedUsers = form.getValues(Fields.RELATED_USERS);
    const signers = form.getValues(Fields.SIGNERS);
    const responsibleUsers = form.getValues(Fields.RESPONSIBLE_USERS);

    const formValues = form.getValues()
    const params: DocumentReviewBodySend = {};

    params.documentName = formValues?.documentName;
    params.statusId = Number(formValues?.status);
    params.attachmentType = Number(formValues?.attachmentType);
    params.confirmWithManagementLevelFlag = formValues?.confirmWithManagementLevelFlag ? 1 : 0;

    params.attachmentIds = files?.map((item: any) => item?.id) ?? [];
    params.repaymentDate = formValues?.repaymentDate
      ? formValues?.repaymentDate?.toISOString()
      : undefined;
    params.repaymentReason = formValues?.repaymentReason;

    params.signerIds = signers?.map((ite: any) => ite.id);
    params.signingDate = formValues?.signingDate
      ? formValues?.signingDate?.toISOString()
      : undefined;
    params.effectiveDate = formValues?.effectiveDate
      ? formValues?.effectiveDate?.toISOString()
      : undefined;
    params.effectiveEndDate = formValues?.effectiveEndDate
      ? formValues?.effectiveEndDate?.toISOString()
      : undefined;

    params.backdateApprovalEmailAttachmentType = Number(formValues?.backdateApprovalEmailAttachmentType) > -1
      ? Number(formValues?.backdateApprovalEmailAttachmentType)
      : undefined;
    params.backdateApprovalEmailAttachmentIds = backdateFiles?.map((item?: any) => item?.id);
    params.backdateApprovalEmailDebtDate = formValues?.backdateApprovalEmailDebtDate
      ? formValues?.backdateApprovalEmailDebtDate?.toISOString()
      : undefined
    params.backdateApprovalEmailDebtReason = formValues?.backdateApprovalEmailDebtReason ?? undefined;

    params.sowContract = formValues?.sowContract;
    params.contractValue = Number(formValues?.contractValue?.replace?.(/\D/g, ''));
    params.currencyId = Number(formValues?.contractCurrency);

    params.sampleContractType = Number(formValues?.sampleContractType);
    params.sampleOtherContent = params.sampleContractType === 2 ? formValues?.sampleOtherContent : undefined;
    params.sampleContractContent = formValues?.sampleContractContent;
    params.sampleContractAttachmentIds = contractFiles?.map((item: any) => item?.id) ?? [];
    params.sampleContractLink = formValues?.sampleContractLink;


    params.problem = formValues?.problem;
    params.opinion = formValues?.opinion;
    params.desiredCondition = formValues?.desiredCondition;
    params.responseDeadlineType = Number(formValues?.responseDeadlineType);
    if (formValues.responseDate && formValues.responseDeadlineType === 1) {
      params.responseDate = formValues.responseDate?.toISOString();
    }
    if (formValues.urgentResponseDate && formValues.responseDeadlineType === 2) {
      params.responseDate = formValues.urgentResponseDate?.toISOString();
      params.urgentResponseReason = formValues.urgentResponseReason;
    }

    params.responsibleUsers = responsibleUsers?.map((ite: any) => ite.id);
    params.receiverUserIds = receiverUsers?.map((ite: any) => ite.id);
    params.relatedUserIds = relatedUsers?.map((ite: any) => ite.id);

    params.checkDivisionFlag = formValues.checkDivisionFlag ? 1 : 0;
    params.checkDeptHeadFlag = formValues.checkDeptHeadFlag ? 1 : 0;
    params.bookingFlag = formValues.bookingFlag ? 1 : 0;

    params.remind =
      (formMode === 'create' && !!form.getValues("remind")?.id)
        || (formMode === 'update' && !!form.getValues("remind")?.title)
        ? {
          ...castReminderSchemaToSaveReminderDTO(
            form.getValues("remind")!
          ),
        }
        : {
          title: "",
          description: "",
          module: 2,
          receivedTitle: [],
          receivingDepartment: [],
          remindContents: [],
          relatedUsers: []
        };
    return params;
  }
  const watchLc = form.watch(Fields.RECEIVERS);
  const watchPic = form.watch(Fields.RESPONSIBLE_USERS);

  const excludedPicIds = useMemo(() => {
    return (watchLc ?? []).map((item: BasedUser) => item.id);
  }, [watchLc])
  const excludedIds = useMemo(() => {
    const list = [];
    const myId = appContext.me?.id;
    const deptHeadId = getDepartmentHeadQuery?.data?.deptHead?.id;
    myId && list.push(myId);
    deptHeadId && list.push(deptHeadId);
    watchPic?.length && list.push(...((watchPic ?? []).map((item: BasedUser) => item.id)));
    return list;
  }, [appContext.me?.id, getDepartmentHeadQuery?.data?.deptHead, watchPic]);

  const showHead = useMemo(() => {
    const myId = appContext.me?.id;
    const deptHeadId = getDepartmentHeadQuery?.data?.deptHead?.id;
    const divHeadId = getDepartmentHeadQuery?.data?.division?.id;
    const picId = props.initialValueReceive?.pic?.id;
    let dept = false;
    let div = false;
    if (props.formMode === 'create') {
      dept = !!myId && !!deptHeadId && (deptHeadId !== myId);
      div = !!myId && !!divHeadId && (divHeadId !== myId);
    }
    if (props.formMode === 'update') {
      dept = !!picId && !!deptHeadId && (deptHeadId !== picId);
      div = !!picId && !!divHeadId && (divHeadId !== picId)
    }
    return {
      dept, div
    }
  }, [
    appContext.me?.id,
    getDepartmentHeadQuery?.data?.deptHead,
    getDepartmentHeadQuery?.data?.division,
    props.formMode,
    props.initialValueReceive?.pic
  ]);


  const disableSpecialFields = useMemo(() => {
    return !appContext.meCanWrite
      || (props.formMode === "update"
        && !ownRole.includes(1)
        && !ownRole.includes(2)
        && !ownRole.includes(3)
        && !ownRole.includes(4)
        && !ownRole.includes(5)
      )
      || !!props.loading
      || isStatusDone
  }, [appContext.meCanWrite, props.formMode, ownRole, props.loading])

  const commonDisabled = !appContext.meCanWrite ||
    (props.formMode === "update" && !ownRole.includes(1)) || props?.loading || isStatusDone
    || (props.formMode === "update" && !isRequestInformation && !props.initialValueReceive?.isDraft)
    ;

  return (
    <Grid
      container
      className="form-wrapper"
      style={{ marginTop: props.formMode === "update" ? 0 : 0, flex: 1 }}
    >
      <Typography sx={{ m: '1rem 0' }}>
        <Typography component={'span'} variant='h5'>{t(`${FIELD_PATH}.${Fields.PURPOSE}`)}: </Typography>
        <Typography component={'span'} sx={{
          fontWeight: 400,
          fontSize: "1rem",
          lineHeight: "1.5rem",
        }}>{t(`${LABEL_PATH}.checkingSupport`)}</Typography>
      </Typography>

      <FormProvider {...form}>
        <form ref={formRef}>
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={formInputSxProps}
          >
            {/* Tên yêu cầu kiểm tra */}
            {formMode === 'create' ? <Grid item width={"100%"}>
              <FormTextField
                control={form.control}
                name={Fields.DOCUMENT_NAME}
                label={t(`${FIELD_PATH}.${Fields.DOCUMENT_NAME}`)}
                placeHolder={t(`${FIELD_PATH}.${Fields.DOCUMENT_NAME}`)}
                required
                disabled={commonDisabled}
              />
            </Grid> : null}
            {/* Xác nhận với cấp quản lý */}
            <Grid item width={"100%"}>
              <CheckboxInput
                // checked={confirmedWithManagers}
                checked={confirmed}
                borderColor={commonDisabled ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                disabled={commonDisabled}
                onChange={(e) => {
                  setConfirmed(e);
                  form.setValue(Fields.CONFIRMED_WITH_MANAGERS, e)
                }}
                label={t(`${LABEL_PATH}.confirmWithManagers`)}
              />
            </Grid>
            {/* Trạng thái tài liệu */}
            {/* <Grid item width={"100%"}>
              <FormSelectButton
                control={form.control}
                name={Fields.STATUS}
                label={t(`${FIELD_PATH}.${Fields.STATUS}`)}
                placeholder={t(`${FIELD_PATH}.${Fields.STATUS}`)}
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                keyQuery={`drr-status-query-${props?.initialValueReceive?.id}-${props?.initialValueReceive?.status?.name}`}
                getOptions={async (keyword) => {
                  if (props?.initialValueReceive?.status?.name === DONE_STATUS) {
                    const response = await getStatusListNames({
                      names: [DONE_STATUS],
                      modules: [ModuleFields.DOCUMENT_REVIEW.module],
                    });
                    return response?.statusResponses || [];
                  }
                  if (typeof keyword == "string") {
                    const statusNameList = Object.values(DocumentReviewStatusList)
                    const response = await getStatusListNames({
                      names: statusNameList,
                      modules: [ModuleFields.DOCUMENT_REVIEW.module],
                    });
                    return response?.statusResponses || [];
                  } else {
                    if (keyword?.length && keyword.length > 0) {
                      return getStatus(Number(keyword[0])).then((value) =>
                        value ? [value] : []
                      );
                    }
                  }

                  return [] as StatusDTO[];
                }}
                getOptionKey={(option) => option.id.toString()}
                getOptionLabel={(option) => option.name}
                required
                isFocus
                disabled={commonDisabled
                  || props?.initialValueReceive?.status?.name === DONE_STATUS
                  || formMode === 'create'
                }
              />
            </Grid> */}

            {/* Đính kèm - chọn loại */}
            <Grid item width={"100%"}>
              <FormSelect
                control={form.control}
                required
                name={Fields.ATTACHMENT_TYPE}
                label={t(`${FIELD_PATH}.${Fields.ATTACHMENT_TYPE}`)}
                placeHolder={t(`${LABEL_PATH}.${Fields.ATTACHMENT_TYPE}`)}
                disabled={commonDisabled}
                options={[
                  {
                    value: 0,
                    label: 'Ringi'
                  },
                  {
                    value: 1,
                    label: 'PR'
                  },
                  {
                    value: 2,
                    label: `${LABEL_PATH}.draftContract`
                  },
                  {
                    value: 3,
                    label: `${LABEL_PATH}.debt`
                  },
                  {
                    value: 4,
                    label: 'Other'
                  },
                ]}
                getOptionKey={(option) => option.value}
                getOptionLabel={(option) => t(option.label)}
                onChange={() => {
                  form.setValue(Fields.REPAYMENT_DATE, undefined);
                  form.setValue(Fields.REPAYMENT_REASON, undefined);
                }}
              />
            </Grid>
            {/* Tệp đính kèm */}
            <Grid item width={"100%"}>
              <DropPreviewFileUploadComponent
                dropView={formMode === 'create'}
                preview={formMode === 'update'}
                name={'attachments'}
                inputId='attachments'
                control={form.control}
                disabled={disableSpecialFields}
                files={files}
                preventOnchange
                setFiles={(files) => {
                  setFiles(files);
                  form.setValue('attachments', files ?? []);
                  form.trigger('attachments')
                }}
                title={t(`legalAdvice.label.attachments`)}
                required
              />
            </Grid>
            {/* Nợ */}
            {attachmentType === AttachmentTypes.DEBT_FILE ?
              <Grid item width={"100%"} mt={0.5}>
                <Grid
                  container
                  direction={"column"}
                  className='form-sub-section-wrapper'
                  rowGap={"0.5rem"}
                // borderColor={sendToError ? COLOR_TYPE.TOYOTA.TOYOTA1 : undefined}
                >
                  <Typography variant='h5'>{t(`${LABEL_PATH}.debt`)}</Typography>

                  {/* Ngày trả */}
                  <Grid item width={"100%"}>
                    <DateInput
                      name={Fields.REPAYMENT_DATE}
                      control={form.control}
                      label={t((`${FIELD_PATH}.${Fields.REPAYMENT_DATE}`))}
                      placeholder='dd/mm/yyyy'
                      required
                      disabled={commonDisabled}
                    />
                  </Grid>
                  {/* Lý do */}
                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={Fields.REPAYMENT_REASON}
                      label={t(`${FIELD_PATH}.${Fields.REPAYMENT_REASON}`)}
                      placeHolder={t(`${FIELD_PATH}.${Fields.REPAYMENT_REASON}`)}
                      required
                      minRows={3}
                      disabled={commonDisabled}
                    />
                  </Grid>
                </Grid>
              </Grid>
              : null
            }

            <Grid item width={"100%"}>
              <Grid
                container
                direction={"column"}
                className='form-sub-section-wrapper'
                rowGap={"0.5rem"}
              >
                <Typography variant='h5'>{t(`${LABEL_PATH}.documentInfo`)}</Typography>
                {/* Người ký */}

                <Grid item width={"100%"}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={Fields.SIGNERS}
                    label={t(`${FIELD_PATH}.${Fields.SIGNERS}`)}
                    placeholder={t(`${FIELD_PATH}.${Fields.SIGNERS}`)}
                    getOptions={async (keyword) => {
                      const params: any = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      }
                      const response = await getUsers(params);
                      return response?.users ?? [];
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${option.department?.name ?? ""
                      }`
                    }
                    required
                    getOptionKey={(option) => option.id}
                    keyQuery='queryUser-signers'
                    minCharLength={1}
                    isFocus
                    disabled={commonDisabled}
                  />
                </Grid>
                {/* Ngày ký */}
                <Grid item width={"100%"}>
                  <DateInput
                    name={Fields.SIGNING_DATE}
                    control={form.control}
                    label={t(`${FIELD_PATH}.${Fields.SIGNING_DATE}`)}
                    placeholder='dd/mm/yyyy'
                    required
                    disabled={commonDisabled}
                  />
                </Grid>
                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={2}
                >
                  <Grid item xs={6}>
                    <DateInput
                      name={Fields.EFFECTIVE_DATE}
                      control={form.control}
                      label={t(`${FIELD_PATH}.${Fields.EFFECTIVE_DATE}`)}
                      placeholder='dd/mm/yyyy'
                      required
                      disabled={commonDisabled}
                      maxDate={form.watch(
                        Fields.EFFECTIVE_END_DATE
                      )}
                      shouldRemove
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <DateInput
                      name={Fields.EFFECTIVE_END_DATE}
                      control={form.control}
                      label={t(`${FIELD_PATH}.${Fields.EFFECTIVE_END_DATE}`)}
                      placeholder='dd/mm/yyyy'
                      required
                      disabled={commonDisabled}
                      minDate={form.watch(
                        Fields.EFFECTIVE_DATE
                      )}
                      shouldRemove
                    />
                  </Grid>
                </Grid>
                {/* Đính kèm backdate approval email */}
                {showBackDateApproval
                  ?
                  <Stack>
                    <Stack width={"100%"} mt={1} direction={'row'} alignItems={'center'} gap={4}>
                      <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA1, fontStyle: 'italic' }} >{t(`${LABEL_PATH}.attachBackDateApproval`)}*:</Typography>
                      <RadioGroupField
                        control={form.control}
                        showError={false}
                        isDisabled={commonDisabled}
                        isNumber
                        items={[
                          { label: 'Attach file', value: 0 },
                          { label: t(`${LABEL_PATH}.oweApproval`), value: 1 },
                        ]}
                        name={Fields.BACKDATE_APPROVAL_TYPE}
                        label={t(`${LABEL_PATH}.attachBackDateApproval`)}
                        disabled={commonDisabled}
                        onChangeRadioGroup={() => {
                          form.setValue(Fields.BACKDATE_DUE_DATE, undefined);
                          form.setValue(Fields.BACKDATE_DEBT_REASON, undefined);
                          form.setValue('backDateAttachments', []);
                          setBackdateFiles([])
                        }}
                      />
                    </Stack>
                    {form?.formState?.errors?.[Fields.BACKDATE_APPROVAL_TYPE] ?
                      <FormHelperText error>{t((form?.formState?.errors?.[Fields.BACKDATE_APPROVAL_TYPE] as any)?.message,
                        {
                          fieldName: t(`${LABEL_PATH}.attachBackDateApproval`)
                        })}</FormHelperText>
                      : null}
                  </Stack>
                  : null
                }
                {/* Attach backdate approval email */}
                {showBackDateApproval && backdateApprovalEmailAttachmentType === 0 ? <Grid item width={"100%"} mt={0.5}>

                  {/* <Grid
                    container
                    direction={"column"}
                    className='form-sub-section-wrapper'
                    rowGap={"0.5rem"}
                  > */}
                  {/* <Typography variant='h5'>{t('Attach file')}</Typography> */}
                  <DropPreviewFileUploadComponent
                    dropView={formMode === 'create'}
                    preview={formMode === 'update'}
                    name={'backDateAttachments'}
                    control={form.control}
                    disabled={commonDisabled}
                    files={backdateFiles}
                    title={t(`legalAdvice.label.attachments`)}
                    preventOnchange
                    setFiles={(files) => {
                      setBackdateFiles(files);
                      form.setValue('backDateAttachments', files ?? []);
                      form.trigger('backDateAttachments');
                    }}
                    inputId='backDateAttachments'
                    required
                  />
                </Grid>
                  // </Grid>
                  : null}
                {/* Nợ backdate approval email */}
                {showBackDateApproval && backdateApprovalEmailAttachmentType === 1 ? <Grid item width={"100%"} mt={0.5}>
                  <Grid
                    container
                    direction={"column"}
                    className='form-sub-section-wrapper'
                    rowGap={"0.5rem"}
                  // borderColor={sendToError ? COLOR_TYPE.TOYOTA.TOYOTA1 : undefined}
                  >
                    <Typography variant='h5'>{t(`${LABEL_PATH}.debt`)}</Typography>
                    {/* Ngày trả */}
                    <Grid item width={"100%"}>
                      <DateInput
                        name={Fields.BACKDATE_DUE_DATE}
                        control={form.control}
                        label={t(`${FIELD_PATH}.${Fields.BACKDATE_DUE_DATE}`)}
                        placeholder='dd/mm/yyyy'
                        required
                        disabled={commonDisabled}
                      />
                    </Grid>
                    {/* Lý do */}
                    <Grid item width={"100%"}>
                      <FormTextArea
                        name={Fields.BACKDATE_DEBT_REASON}
                        control={form.control}
                        label={t(`${FIELD_PATH}.${Fields.BACKDATE_DEBT_REASON}`)}
                        placeHolder={t(`${FIELD_PATH}.${Fields.BACKDATE_DEBT_REASON}`)}
                        required
                        minRows={2}
                        disabled={commonDisabled}
                      />
                    </Grid>
                  </Grid>
                </Grid> : null}
                {/* SOW của hợp đồng */}
                <Grid item width={"100%"}>
                  <FormTextField
                    control={form.control}
                    name={Fields.SOW_CONTRACT}
                    label={t(`${FIELD_PATH}.${Fields.SOW_CONTRACT}`)}
                    placeHolder={t(`${FIELD_PATH}.${Fields.SOW_CONTRACT}`)}
                    required
                    disabled={commonDisabled}
                  />
                </Grid>
                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 2 }}
                // sx={formInputSxProps}
                >
                  <Grid item xs={3.5}>
                    <FormTextField
                      control={form.control}
                      name={Fields.CONTRACT_VALUE}
                      label={t(`${FIELD_PATH}.${Fields.CONTRACT_VALUE}`)}
                      placeHolder={t(`${FIELD_PATH}.${Fields.CONTRACT_VALUE}`)}
                      required
                      type='integer'
                      disabled={commonDisabled}
                      inputAlign='right'
                    />
                  </Grid>
                  <Grid item xs={2.5} sx={{ marginTop: '24px' }}>
                    <FormAsyncSelect
                      control={form.control}
                      name={Fields.CONTRACT_CURRENCY}
                      placeholder={t(`currency.field_name.unit`)}
                      // eslint-disable-next-line @typescript-eslint/no-explicit-any
                      keyQuery={"document-review/form/currency"}
                      isFocus
                      getOptions={async (keyword) => {
                        if (typeof keyword == "string") {
                          const response = await getCurrencies({
                            name: keyword,
                            page: 0,
                            size: 100,
                            sortBy: StatusFieldNames.ID,
                            orderBy: "ASC",
                            active: 1
                          });

                          return response?.currencyResponses || [];
                        } else {
                          if (keyword?.length && keyword.length > 0) {
                            return getCurrency(Number(keyword[0])).then((value) =>
                              value ? [value] : []
                            );
                          }
                        }

                        return [] as CurrencyDTO[];
                      }}
                      getOptionKey={(option) => option.id.toString()}
                      getOptionLabel={(option) => option.unit}
                      disabled={commonDisabled}
                    />
                  </Grid>
                </Grid>
                {/* Sample */}
                <Grid item width={"100%"}>
                  <FormSelect
                    control={form.control}
                    required
                    name={Fields.SAMPLE}
                    label={'Sample'}
                    placeHolder={'Sample'}
                    disabled={commonDisabled}
                    options={[
                      {
                        value: 0,
                        label: t(`${LABEL_PATH}.useBlockContract`)
                      },
                      {
                        value: 1,
                        label: t(`${LABEL_PATH}.useSignedContract`)
                      },
                      {
                        value: 2,
                        label: t(`${LABEL_PATH}.other`)
                      },
                    ]}
                    getOptionKey={(option) => option.value}
                    getOptionLabel={(option) => t(option.label)}
                    onChange={(event) => {
                      if (event?.target?.value !== 2) {
                        form.setValue(Fields.OTHER_SAMPLE_CONTENT, undefined)
                      }
                    }}
                  />
                </Grid>
                {
                  sampleType === 2
                    ? <Grid item width={"100%"}>
                      <FormTextArea
                        control={form.control}
                        name={Fields.OTHER_SAMPLE_CONTENT}
                        label={''}
                        placeHolder={t(`${FIELD_PATH}.${Fields.CONTRACT_CONTENT}`)}
                        minRows={2}
                        disabled={commonDisabled}
                      />
                    </Grid>
                    : null
                }
                {/* Nội dung */}
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={Fields.SAMPLE_CONTRACT_CONTENT}
                    label={t(`${FIELD_PATH}.${Fields.CONTRACT_CONTENT}`)}
                    placeHolder={t(`${FIELD_PATH}.${Fields.CONTRACT_CONTENT}`)}
                    required
                    minRows={3}
                    disabled={commonDisabled}
                    explanation={getExplanation(
                      Fields.CONTRACT_CONTENT
                    )}
                  />
                </Grid>

                {/* Attachment của hợp đồng */}
                <Grid item width={"100%"}>
                  <DropPreviewFileUploadComponent
                    dropView={formMode === 'create'}
                    preview={formMode === 'update'}
                    name={'contractAttachments'}
                    control={form.control}
                    disabled={commonDisabled}
                    files={contractFiles}
                    title={t(`legalAdvice.label.attachments`)}
                    preventOnchange
                    setFiles={(files) => {
                      setContractFiles(files);
                      form.setValue('contractAttachments', files ?? []);
                      form.trigger('contractAttachments')
                    }}
                    required
                    inputId='contractAttachments'
                  />
                </Grid>

                <Grid item width={"100%"} display={'flex'} flexDirection={'row'} alignItems={'end'}>
                  <AddLinkComponent
                    name={"sampleContractLink"}
                    label='Add link'
                    placeholder='Link'
                  />
                </Grid>
              </Grid>
            </Grid>
            {/* Tình trạng mong muốn */}
            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={Fields.DESIRED_CONDITION}
                label={t(`${FIELD_PATH}.${Fields.DESIRED_CONDITION}`)}
                placeHolder={t(`${FIELD_PATH}.${Fields.DESIRED_CONDITION}`)}
                required
                minRows={3}
                disabled={commonDisabled}
              />
            </Grid>
            {/* Vấn đề */}
            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={Fields.PROBLEM}
                label={t(`${FIELD_PATH}.${Fields.PROBLEM}`)}
                placeHolder={t(`${FIELD_PATH}.${Fields.PROBLEM}`)}
                // required
                minRows={3}
                disabled={commonDisabled}
              />
            </Grid>
            {/* Ý kiến nghiên cứu của phòng ban */}
            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={Fields.OPINION}
                label={t(`${FIELD_PATH}.${Fields.OPINION}`)}
                placeHolder={t(`${FIELD_PATH}.${Fields.OPINION}`)}
                // required
                minRows={3}
                disabled={commonDisabled}
              />
            </Grid>
            {/* Ngày vendor phản hồi - chỉ hiện khi trạng thái là Gửi vendor kiểm tra */}
            {props?.initialValueReceive?.vendorResponseDate && <Grid item width={"100%"}>
              <DateInput
                name={Fields.VENDOR_RESPONSE_DATE}
                control={form.control}
                label={t(`${FIELD_PATH}.${Fields.VENDOR_RESPONSE_DATE}`)}
                placeholder='dd/mm/yyyy'
                // required
                // disabled={commonDisabled}
                disabled
              />
            </Grid>}
            {/* Thời hạn phản hồi */}
            <Grid item width={"100%"}>
              <FormSelect
                control={form.control}
                required
                name={Fields.RESPONSE_TYPE}
                label={t(`${FIELD_PATH}.${Fields.RESPONSE_TYPE}`)}
                placeHolder={t(`${FIELD_PATH}.${Fields.RESPONSE_TYPE}`)}
                disabled={commonDisabled}
                options={[
                  {
                    value: 1,
                    label: t('legalAdvice.label.SOP')
                  },
                  {
                    value: 2,
                    label: 'Urgent'
                  },
                ]}
                getOptionKey={(option) => option.value}
                getOptionLabel={(option) => option.label}
                onChange={(event) => {
                  const value = event.target.value;
                  form.setValue(Fields.RESPONSE_DATE, value === 1 ? add(new Date(), { days: 5 }) : undefined);
                  form.setValue(Fields.URGENT_RESPONSE_DATE, new Date());
                  form.setValue(Fields.URGENT_RESPONSE_REASON, undefined);
                }}
              />
            </Grid>
            {/* Ngày trả */}
            {deadlineType === 1 && <Grid item width={"100%"}>
              <DateTimeInput
                control={form.control}
                name={Fields.RESPONSE_DATE}
                label={t(`${FIELD_PATH}.${Fields.RESPONSE_DATE}`)}
                required
                disabled={commonDisabled}
              />
            </Grid>}
            {/* Ngày trả gấp + Lý do trả gấp */}
            {deadlineType === 2 &&
              <>
                <Grid item width={"100%"}>
                  <DateTimeInput
                    control={form.control}
                    name={Fields.URGENT_RESPONSE_DATE}
                    label={t(`${FIELD_PATH}.${Fields.URGENT_RESPONSE_DATE}`)}
                    required
                    disabled={commonDisabled}
                  />
                </Grid>
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={Fields.URGENT_RESPONSE_REASON}
                    label={t(`${FIELD_PATH}.${Fields.URGENT_RESPONSE_REASON}`)}
                    placeHolder={t(`${FIELD_PATH}.${Fields.URGENT_RESPONSE_REASON}`)}
                    required
                    minRows={3}
                    disabled={commonDisabled}
                  />
                </Grid>
              </>}

            {/* Người chịu trách nhiệm */}
            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={Fields.RESPONSIBLE_USERS}
                label={t(
                  `legalAdvice.fields.${Fields.RESPONSIBLE_USERS}`
                )}
                placeholder={t(
                  `legalAdvice.fields.${Fields.RESPONSIBLE_USERS}`
                )}
                minCharLength={1}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });
                  return response?.users?.filter((user) => !excludedPicIds?.includes(user.id)) ?? [];
                  ;
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                  }`
                }
                required
                getOptionKey={(option) => option.id}
                keyQuery="document-review-query-pics"
                isFocus
              />
            </Grid>

            {/* Người tư vấn  */}
            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={Fields.RECEIVERS}
                label={t(`${FIELD_PATH}.${Fields.RECEIVERS}`)}
                placeholder={t(`${FIELD_PATH}.${Fields.RECEIVERS}`)}
                minCharLength={1}
                getOptions={async (keyword) => {
                  if (!getLegalDepartmentQuery.data) return []
                  const advisorIds = getAssignedPersonQuery?.data?.users?.map((user) => user.id) ?? [];
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                    departmentIds: getLegalDepartmentQuery.data ? [getLegalDepartmentQuery.data] : []
                  });
                  return (response?.users?.map((user, index) => ({
                    ...user,
                    rank: advisorIds?.includes(user.id) ? index : 99999
                  }))?.sort((first, second) => first.rank - second.rank) ?? [])
                    ?.filter((user) => !excludedIds?.includes(user?.id));
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? (option?.departmentName ?? '')
                  }`
                }
                required
                getOptionKey={(option) => option.id}
                keyQuery='document-review-query-reviewers'
                isFocus
                disabled={commonDisabled}
              />
            </Grid>

            {/* Bắt buộc gửi tới Dept Head / Division Head */}
            <Stack direction={'row'} width={"100%"} mt={0.5} gap={2}>
              <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA1, fontStyle: 'italic' }} >{t(`legalAdvice.label.requiredToBeSentTo`)}*:</Typography>
              <Stack gap={"1rem"}>
                {showHead?.dept ? <CheckboxInput
                  fontSize={'1rem'}
                  checked={form.watch("checkDeptHeadFlag")}
                  borderColor={commonDisabled ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                  checkboxBg={commonDisabled ? COLOR_TYPE.TOYOTA.TOYOTA6 : 'white'}
                  onChange={(value) => {
                    form.setValue(
                      "checkDeptHeadFlag",
                      value
                    );
                  }}
                  label={
                    getDepartmentHeadQuery?.data?.deptHead
                      ? `${getDepartmentHeadQuery?.data?.deptHead?.name} - Dept Head.${getDepartmentHeadQuery?.data?.deptHead?.department?.name}`
                      : t(
                        "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                      )
                  }
                  disabled={commonDisabled || !showHead?.div}
                /> : null}
                {showHead?.div ? <CheckboxInput
                  fontSize={'1rem'}
                  checked={form.watch("checkDivisionFlag")}
                  borderColor={commonDisabled ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                  checkboxBg={commonDisabled ? COLOR_TYPE.TOYOTA.TOYOTA6 : 'white'}
                  onChange={(value) => {
                    form.setValue(
                      "checkDivisionFlag",
                      value
                    );
                  }}
                  label={
                    getDepartmentHeadQuery?.data?.division
                      ? `${getDepartmentHeadQuery?.data?.division?.name} - Division Head.${getDepartmentHeadQuery?.data?.division?.department?.name}`
                      : t(
                        "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                      )
                  }
                  disabled={commonDisabled || !showHead?.dept}
                /> : null}
                {sendToError ? <FormHelperText error>{t('legalAdvice.messages.requiredToBeSentTo')}</FormHelperText> : null}
              </Stack>
            </Stack>
            {/* <Grid item width={"100%"} mt={0.5}>
              <InputLabel required>{t('legalAdvice.label.requiredToBeSentTo')}</InputLabel>
              <Grid
                container
                direction={"column"}
                className='form-sub-section-wrapper'
                rowGap={"0.5rem"}
                borderColor={sendToError ? COLOR_TYPE.TOYOTA.TOYOTA1 : undefined}
              >
                <Grid
                  container
                  direction={"row"}
                  rowGap={"0.5rem"}
                >
                  <Grid item xs={6}>
                    <FormControlLabel
                      name='checkDeptHeadFlag'
                      control={
                        <Checkbox
                          checked={checkDeptHeadFlag}
                          onChange={(e) => {
                            form.setValue('checkDeptHeadFlag', e.target.checked)
                          }}
                          disabled={commonDisabled}
                        />
                      }
                      label={
                        getDepartmentHeadQuery?.data?.deptHead
                          ? `${getDepartmentHeadQuery?.data?.deptHead?.name} - Dept Head.${getDepartmentHeadQuery?.data?.deptHead?.department?.name}`
                          : t('reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT')}
                    // disabled={
                    //   !appContext.meCanWrite
                    //   || (props.formMode === "update" && !ownRole.includes(1))
                    // }
                    />

                  </Grid>
                  <Grid item xs={6}>
                    <FormControlLabel
                      name='checkDivisionFlag'
                      control={
                        <Checkbox
                          checked={checkDivisionFlag}
                          onChange={(e) => {
                            form.setValue('checkDivisionFlag', e.target.checked)
                          }}
                          disabled={commonDisabled}
                        />
                      }
                      label={
                        getDepartmentHeadQuery?.data?.division
                          ? `${getDepartmentHeadQuery?.data?.division?.name} - Division Head.${getDepartmentHeadQuery?.data?.division?.department?.name}`
                          : t('reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT')}
                    // disabled={
                    //   !appContext.meCanWrite
                    //   || (props.formMode === "update" && !ownRole.includes(1))
                    // }
                    />
                  </Grid>
                </Grid>
                {sendToError ? <FormHelperText error>{t('legalAdvice.messages.requiredToBeSentTo')}</FormHelperText> : null}
              </Grid>
            </Grid> */}
            {props?.initialValueReceive?.assignUsers?.length ? <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={Fields.ASSIGNMENT_USERS}
                label={t(`${LABEL_PATH}.${Fields.ASSIGNMENT_USERS}`)}
                placeholder={t(`${LABEL_PATH}.${Fields.ASSIGNMENT_USERS}`)}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });

                  return response?.users ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                  }`
                }
                getOptionKey={(option) => option.id}
                keyQuery="legal-advice-assigners"
                disabled
              />
            </Grid> : null}
            {/* Người liên quan  */}
            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={Fields.RELATED_USERS}
                label={t(`${FIELD_PATH}.${Fields.RELATED_USERS}`)}
                placeholder={t(`${FIELD_PATH}.${Fields.RELATED_USERS}`)}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });

                  return response?.users ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? (option?.departmentName ?? '')
                  }`
                }
                getOptionKey={(option) => option.id}
                keyQuery='queryRelatedUser'
                disabled={commonDisabled}
              />
            </Grid>


            {/* {(formMode === 'update' && props?.initialValueReceive?.id) && <Grid item width={"100%"}> */}
            {(formMode === 'update' && props?.initialValueReceive) && <Grid item width={"100%"}>
              <ReviewList documentReviewId={props?.initialValueReceive?.id}
                documentReview={props?.initialValueReceive}
              />
            </Grid>}
          </Grid>

          {/* Nhắc nhở */}
          <ReminderPickerSubForm
            name={'remind'}
            module={ModuleFields.DOCUMENT_REVIEW.module}
            placeholder={t('menu.reminder')}
          />

          <FormActionButtons
            formMode={props.formMode}
            loading={props.loading}
            onCancel={props.onCancel}
            isDisableButonSave={
              isStatusDone
              || !appContext.meCanWrite
              || (props.formMode === "update" && !ownRole.includes(1))
              || (props.formMode === "update" && !isRequestInformation && !props.initialValueReceive?.isDraft)
            }
            allowDraft={props.formMode === "create" || props?.initialValueReceive?.isDraft}
            onSaveDraft={async () => {
              try {
                const params: any = await handleSaveParams();
                params.isDraft = true;
                props?.onSubmitDraft?.(params);
              } catch (error) { }
            }}
            onSave={async () => {
              try {
                const params: any = await handleSaveParams();
                params.isDraft = false;
                props?.onSubmit?.(params);
              } catch (error) {
              }
            }}
          />
        </form>
      </FormProvider>
    </Grid >
  )
})

export default DocumentReviewForm

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}