
import { EmptyIndicator } from "@/components/commons/empty_idicator/EmptyIndicator";
import { GenericSearchPanel } from "@/components/commons/search_panel/GenericSearchPanel";
import { DocumentReviewBodyReceive, documentReviewSearchPanelConfig } from "@/models/document-review/DocumentReviewDetail";
import { Grid, Stack } from "@mui/material";
import { ReactNode, useState } from "react";

export interface LegalDocumentLayoutProps {
  children: ReactNode | ReactNode[];
  initialValueReceive?: DocumentReviewBodyReceive;
}

export const DocumentReviewDetailLayout = (props: LegalDocumentLayoutProps) => {
  const [isResultSearchPanel, setIsResultSearchPanel] = useState(true);

  const handleSetResultSearchPanel = (value: boolean) => {
    setIsResultSearchPanel(value)
  }

  return (
    <Stack sx={{ height: '100%' }}>
      {/* <OverviewHeader
        initialValueReceive={props.initialValueReceive}
        onChangeMeeting={() => { }}
      /> */}
      <Grid
        direction={"row"}
        wrap='nowrap'
        sx={{ display: "flex", overflow: "hidden", height: "100%" }}
      >
        <Grid
          item
          sx={{ overflow: "auto", height: "100%", position: "relative" }}
        >
          {/* <SearchPanel /> */}
          <GenericSearchPanel<any>
            {...documentReviewSearchPanelConfig}
            setIsResultSearchPanel={handleSetResultSearchPanel}
          />
        </Grid>
        <Grid
          item
          flex={1}
          style={{
            maxWidth: "100%",
            transition: "max-width 0.2s ease",
            // height: "calc(100vh - 200px)",
            height: '100%',
            overflow: "auto",
            position: "relative",
          }}
        >
          {!isResultSearchPanel
            ? <EmptyIndicator bgColor="white" />
            : props.children
          }
        </Grid>
      </Grid>
    </Stack>
  );
};


