import { getFields } from "@/apis/service/field/Field";
import {
  getFollowViolationList,
  getViolationExcel,
  getViolationStatusList,
  shareFollowViolationFn,
} from "@/apis/service/follow_violation/followViolationAPI";
import { useConfirmFollowViolation } from "@/apis/service/follow_violation/confirmFollowViolation";
import { useRecallViolation } from "@/apis/service/follow_violation/recallViolation";
import { getUsers } from "@/apis/service/user/User";
import { getMultipleAsyncChoosingOperators } from "@/components/commons/filters/MultipleAsyncChoosingFilter";
import { getMultipleSelectOperators } from "@/components/commons/filters/MultipleSelectFilter";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import MultipleTabsTable from "@/components/commons/tables/multiple_tabs_table/MultipleTabsTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import { URL_OUTLOOK } from "@/constants/constraint";
import {
  FollowViolationActionsBtnKey,
  FollowViolationUserRole,
  FollowViolationUserRoleKey,
} from "@/constants/followViolation";
import { MIME_TYPES, ModuleFields } from "@/constants/general";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import { FieldDTO, FieldFieldNames } from "@/models/field/Field";
import { FollowViolationListParams } from "@/models/follow_violation/apiType";
import { FollowViolationFields } from "@/models/follow_violation/FollowViolationType";
import { StatusDTO } from "@/models/status/Status";
import { BasedUser } from "@/models/user/User";
import { downloadFile, formatDate } from "@/utils";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { Button, Grid, IconButton, Tooltip } from "@mui/material";
import { GridFilterItem } from "@mui/x-data-grid";
import { useMutation, useQuery } from "@tanstack/react-query";
import { endOfDay, format } from "date-fns";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { Range as DateRange } from "react-date-range";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { FollowViolationTableActions } from "./FollowViolationTableActions";
import { ForwardFollowViolationForm } from "./components/forward_follow_violation_form/ForwardFollowViolationForm";
import SendMailFollowViolationForm from "./components/send_mail_follow_violation_form/SendMailFollowViolationForm";
import { FeedBackLcFollowViolationForm } from "./components/feedback_lc_follow_violation_form/FeedBackLcFollowViolationForm";
import { FeedBackFollowViolationForm } from "./components/feedback_follow_violation_form/FeedBackFollowViolationForm";
import { AdviceFollowViolationForm } from "./components/advice_follow_violation_form/AdviceFollowViolationForm";
import { RequestAddInfoFollowViolationForm } from "./components/request_add_info_follow_violation_form/RequestAddInfoFollowViolationForm";
import { AssignmentFollowViolationForm } from "./components/assignment_follow_violation_form/AssignmentFollowViolationForm";
import { RequestVendorFollowViolationForm } from "./components/request_vendor_follow_violation_form/RequestVendorFollowViolationForm";
import { TimeExtensionFollowViolationForm } from "./components/time_extension_follow_violation_form/TimeExtensionFollowViolationForm";
import { FeedBackNextActionFollowViolationForm } from "./components/feedback_next_action_follow_violation_form/FeedBackNextActionFollowViolationForm";
import { TrackNextActionFollowViolationForm } from "./components/track_next_action_follow_violation_form/TrackNextActionFollowViolationForm";
import { FinishFollowViolationForm } from "./components/finish_follow_violation_form/FinishFollowViolationForm";
import { AdviceFinishedFollowViolationForm } from "./components/advice_finished_follow_violation_form/AdviceFinishedFollowViolationForm";
import HierarchyToolTip from "@/components/commons/hierarchy-tooltip/HierarchyTooltip";
import { violationSearchPanelConfig } from "@/models/follow_violation/FormType";
import { useAdditionalInformationFollowViolation } from "@/apis/service/follow_violation/additionalInformationFollowViolation";
import SharePopup from "@/components/commons/share_popup/SharePopup";

export const FollowViolationTableConst = {
  GENERAL_TABLE: "followViolation.label.generateTable",
  GET_ALL_QUERY_KEY: "getAllFollowViolation",
  PERSONAL_TABLE: "followViolation.label.personalTable",
  GET_PERSONAL_QUERY_KEY: "getPersonalViolation",
  GET_VIOLATION_EXCEL: "getViolationExcel",
};

const getFieldLabel = (key: string) => {
  return `followViolation.fields.${key}`;
};

const castTableStateToParams = (
  tableState: StandardTableState
): FollowViolationListParams => {
  const params: FollowViolationListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 10,
    sortBy: FollowViolationFields.ID,
    orderBy: "DESC",
  };
  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == FollowViolationFields.REQUEST_NAME) {
      params.name = item.value;
    }

    if (item.field == FollowViolationFields.FIELD) {
      params.field = (item.value ?? [])
        .map((item: FieldDTO) => item.id ?? item)
        .join(",");
    }

    if (item.field == FollowViolationFields.STATUS) {
      params.status = (item.value ?? [])
        .map((item: StatusDTO) => item.id ?? item)
        .join(",");
    }
    if (item.field == FollowViolationFields.STATUS_NEXT_ACTION) {
      params.nextActionStatus = (item.value ?? [])
        .map((item: StatusDTO) => item.id ?? item)
        .join(",");
    }
    if (item.field == FollowViolationFields.SENDER) {
      params.picIds = (item.value ?? [])
        .map((item: BasedUser) => item.id)
        .join(",");
    }

    if (item.field == FollowViolationFields.RESPONSE_DATE) {
      params.responseDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();

      params.responseDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};

const FollowViolationTable = () => {
  const { t, i18n } = useTranslation();
  const [activeTab, setActiveTab] = useState<number>(0);
  const router = useRouter();
  const appContext = useContext(AppContext);
  const [initialFollowViolation, setInitialFollowViolation] =
    useState<any>(undefined);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [legalDocumentTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: FollowViolationFields.ID,
      label: FollowViolationFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: "center",
    },
    {
      key: FollowViolationFields.REQUEST_NAME,
      label: FollowViolationFields.REQUEST_NAME,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: false,
      filterRank: 2,
      minWidth: 240,
      renderCell: (params) => (
        <HierarchyToolTip
          {...violationSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.name}
          openNewTab
        >
          <span>{params.value}</span>
        </HierarchyToolTip>
      ),
    },

    {
      key: FollowViolationFields.FIELD,
      label: FollowViolationFields.FIELD,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      filterRank: 1,
      minWidth: 180,
      renderCell: (params) => <span>{params.value?.name}</span>,
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getFields({
              page: 0,
              size: 100,
              sortBy: FieldFieldNames.NAME,
              orderBy: "ASC",
            });

            return response?.fieldResponses || [];
          },
          getOptionKey: (item) => item.id.toString(),
          getOptionLabel: (item) => item.name,
          keyQuery: FollowViolationFields.FIELD,
        },
        t
      ),
    },
    {
      key: FollowViolationFields.PURPOSE,
      label: FollowViolationFields.PURPOSE,
      type: undefined,
      quickFilter: false,
      // filterable: true,
      sortable: true,
      minWidth: 200,
      // hideable: true,
    },
    {
      key: FollowViolationFields.STATUS,
      label: "statusViolation",
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        const status = params?.row?.isDraft ? t("common.label.draft") : params.value?.name
        return <Button
          variant="outlined"
          style={{
            background: status === "Hoàn thành" ? "#E7F4EE" : "#D781001A",
            borderRadius: "100px",
            color: status === "Hoàn thành" ? "#0D894F" : "#D78100",
            border: "none",
            padding: "4px 12px",
          }}
        >
          {status}
        </Button>
      },
        
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getViolationStatusList({
              page: 0,
              size: 100,
              sortBy: FieldFieldNames.NAME,
              tab: 0,
              orderBy: "ASC",
              modules: [ModuleFields.VIOLATE_NAME.module],
              active: 1,
            });

            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item.id,
          getOptionLabel: (item) => item.name,
          keyQuery: `violation-${FollowViolationFields.STATUS}`,
        },
        t
      ),
    },
    {
      key: FollowViolationFields.DEADLINE_TYPE,
      label: FollowViolationFields.DEADLINE,
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 130,
      renderCell: (params) =>
        params.value === 1 ? t("followViolation.label.SOP") : "Urgent",
    },
    {
      key: FollowViolationFields.RESPONSE_DATE,
      label: FollowViolationFields.RETURN_DATE_ALL,
      filterLabel: "followViolation.label.responseDeadline",
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy HH:mm"),
    },
    {
      key: FollowViolationFields.SENDER,
      label: FollowViolationFields.SENDER,
      filterLabel: "followViolation.label.creator",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 250,
      renderCell: (params) => (
        <Tooltip
          placement="bottom-start"
          title={
            params.row?.createBy
              ? `${params.row?.createBy?.name} - ${params.row?.createBy?.department?.name}`
              : ""
          }
        >
          <span>
            {params.row?.createBy
              ? `${params.row?.createBy?.name} - ${params.row?.createBy?.department?.name}`
              : ""}
          </span>
        </Tooltip>
      ),
      filterOperators: getMultipleSelectOperators(
        {
          getOptions: async (keyword) => {
            const response = await getUsers({
              searchTerm: keyword,
              page: 0,
              size: 100,
              sortBy: "name",
              sortOrder: "ASC",
            });

            return response?.users ?? [];
          },
          getOptionKey: (item) => item.id.toString(),
          getOptionLabel: (item) =>
            `${item?.name} - ${
              item?.position?.name ? `${item?.position?.name}.` : ""
            }${item?.department?.name ?? ""}`,
          keyQuery: FollowViolationFields.SENDER,
        },
        t
      ),
    },
    {
      key: FollowViolationFields.RECEIVER,
      label: FollowViolationFields.RECEIVER,
      type: "string",
      quickFilter: false,
      // filterable: true,
      sortable: true,
      minWidth: 250,
      renderCell: (params) => (
        <Tooltip
          placement="bottom-start"
          title={
            <>
              {params.row?.receiverUsers?.map((user: any) => (
                <p key={user?.id}>
                  {user.name} - {user?.department?.name}
                </p>
              ))}
            </>
          }
        >
          {params.row?.receiverUsers
            ?.map((user: any) => `${user.name} - ${user?.department?.name}`)
            .join(", ")}
        </Tooltip>
      ),
    },
    {
      key: FollowViolationFields.ACTION,
      label: FollowViolationFields.ACTION,
      type: undefined,
      renderCell: (params) => {
        return FollowViolationTableActions({
          params,
          handleClickConfirm: async () =>
            await confirmFollowViolation(Number(params?.id)),
          handleClickRecall: async () =>
            await recallViolation(Number(params?.id)),
          handleClickForWard: () =>
            handleClick(FollowViolationActionsBtnKey.FORWARD, params?.row),
          handleClickFeedBack: () =>
            handleClick(FollowViolationActionsBtnKey.FEEDBACK, params?.row),
          handleClickShare: () =>
            handleClick(FollowViolationActionsBtnKey.SHARE, params?.row),
          handleClickFeedBackLc: () => {
            handleClick(FollowViolationActionsBtnKey.FEEDBACK_LC, params?.row);
          },
          handleClickRequestMeeting: () => window.open(URL_OUTLOOK, "_blank"),
          handleClickSendMail: () =>
            handleClick(FollowViolationActionsBtnKey.SEND_MAIL, params?.row),
          handleClickExtendTime: () =>
            handleClick(
              FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
              params?.row
            ),
          handleClickAssignment: () =>
            handleClick(FollowViolationActionsBtnKey.ASSIGNMENT, params?.row),
          handleClickRequestVendor: () =>
            handleClick(
              FollowViolationActionsBtnKey.REQUEST_VENDOR,
              params?.row
            ),
          handleClickAdviseFinished: () =>
            handleClick(
              FollowViolationActionsBtnKey.ADVICE_FINISHED,
              params?.row
            ),
          handleClickFeedbackAdvise: () =>
            handleClick(
              FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
              params?.row
            ),
          handleClickRequestAdditional: () =>
            handleClick(
              FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
              params?.row
            ),
          handleClickAdditionalInformation: async () => {
            await additionalInformationFollowViolation(Number(params?.id));
          },
          handleClickAdvise: () =>
            handleClick(FollowViolationActionsBtnKey.ADVICE, params?.row),
          handleClickFeedBackNextAction: () =>
            handleClick(
              FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION,
              params?.row
            ),
          handleClickTrackNextAction: () =>
            handleClick(
              FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
              params?.row
            ),
          handleClickFinish: () =>
            handleClick(FollowViolationActionsBtnKey.FINISH, params?.row),
        });
      },
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "last-column-sticky",
      headerClassName: "last-column-sticky-header",
    },
    // {
    //   key: FollowViolationFields.STATUS_NEXT_ACTION,
    //   label: FollowViolationFields.STATUS_NEXT_ACTION,
    //   type: undefined,
    //   quickFilter: false,
    //   filterable: true,
    //   hideable: true,
    //   filterOperators: getMultipleAsyncChoosingOperators(
    //     {
    //       getOptions: async () => {
    //         const response = await getStatusList({
    //           page: 0,
    //           size: 100,
    //           sortBy: FieldFieldNames.NAME,
    //           orderBy: "ASC",
    //           modules: [ModuleFields.VIOLATE_NAME.module],
    //           active: 1,
    //         });

    //         return response?.statusResponses || [];
    //       },
    //       getOptionKey: (item) => item.id,
    //       getOptionLabel: (item) => item.name,
    //       keyQuery: `violation-${FollowViolationFields.STATUS}`,
    //     },
    //     t
    //   ),
    // },
  ]);

  /** Get all Follow Violation */
  const getAllFollowViolationQuery = useQuery({
    queryKey: [FollowViolationTableConst.GET_ALL_QUERY_KEY],
    queryFn: () =>
      getFollowViolationList({
        ...castTableStateToParams(generalTableState),
        tab: 0,
      }),
    enabled: false,
  });
  /** Get personal Follow Violation request */
  const getPersonalFollowViolationQuery = useQuery({
    queryKey: [FollowViolationTableConst.GET_PERSONAL_QUERY_KEY],
    queryFn: () =>
      getFollowViolationList({
        ...castTableStateToParams(personalTableState),
        tab: 1,
      }),
    enabled: false,
  });

  const { mutateAsync: recallViolation } = useRecallViolation({
    config: {
      onSuccess: () => {
        toast.success(
          t("followViolation.recallFollowViolation.message.recall_success")
        );
        getAllFollowViolationQuery.refetch();
        getPersonalFollowViolationQuery.refetch();
      },
    },
  });

  const { mutateAsync: confirmFollowViolation } = useConfirmFollowViolation({
    config: {
      onSuccess: () => {
        toast.success(
          t("followViolation.confirmFollowViolation.message.confirm_success")
        );
        getAllFollowViolationQuery.refetch();
        getPersonalFollowViolationQuery.refetch();
      },
    },
  });

  const { mutateAsync: additionalInformationFollowViolation } =
    useAdditionalInformationFollowViolation({
      config: {
        onSuccess: () => {
          toast.success(
            t(
              "followViolation.additionalInformationFollowViolation.message.additionalInformationSuccess"
            )
          );
          getAllFollowViolationQuery.refetch();
          getPersonalFollowViolationQuery.refetch();
        },
      },
    });

  const shareMutation = useMutation({
    mutationFn: shareFollowViolationFn,
    onSuccess: () => {
      toast.success(t(`followViolation.messages.shareSuccess`));
    },
  });

  // const recallQuery = useMutation({
  //   mutationFn: recallLegalDocument,
  //   onSuccess: () => {
  //     toast.success(
  //       t("LEGISLATION.message.recall_success")
  //     );
  //     refetchGeneralTab();
  //     refetchPersonalTab();
  //   },
  // });

  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload: boolean = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));

    if (!state) {
      setInitialFollowViolation(undefined);
    }

    if (reload) {
      getAllFollowViolationQuery.refetch();
      getPersonalFollowViolationQuery.refetch();
    }
  };

  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialFollowViolation(row);
      changePopupVisible(type, true);
    }
  };

  useEffect(() => {
    generalTableState &&
      activeTab === 0 &&
      getAllFollowViolationQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generalTableState, activeTab]);

  useEffect(() => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalFollowViolationQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [personalTableState, activeTab]);

  /** Get excel file */
  const getViolationExcelQuery = useQuery({
    queryKey: [FollowViolationTableConst.GET_VIOLATION_EXCEL],
    queryFn: () =>
      getViolationExcel({
        ...castTableStateToParams(
          activeTab === 0 ? generalTableState : personalTableState
        ),
        tab: activeTab,
        size: 9999,
        isEnglish: i18n.language === "en",
      }),
    enabled: false,
  });

  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getViolationExcelQuery.refetch().then((response: any) => {
              const fileName = `${
                i18n.language === "en"
                  ? "ViolationTracking"
                  : "Theo dõi vụ việc vi phạm"
              }_${format(new Date(), "ddMMyyyy")}`;
              response?.data &&
                downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getAllFollowViolationQuery.isFetching ||
            getPersonalFollowViolationQuery.isFetching ||
            getViolationExcelQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };

  return (
    <>
      <MultipleTabsTable
        tableTabs={[
          {
            tabName: t("followViolation.label.generateTable"),
            tabKey: FollowViolationTableConst.GENERAL_TABLE,
            data: getAllFollowViolationQuery?.data?.data ?? [],
            loading: getAllFollowViolationQuery?.isFetching,
            rowCount: getAllFollowViolationQuery?.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t("followViolation.label.personalTable"),
            tabKey: FollowViolationTableConst.PERSONAL_TABLE,
            data: getPersonalFollowViolationQuery?.data?.data ?? [],
            loading: getPersonalFollowViolationQuery?.isFetching,
            rowCount: getPersonalFollowViolationQuery?.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={legalDocumentTableColumns.map((column) => ({
          ...column,
          label: column.label ? getFieldLabel(column.label) : "",
        }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        quickFilterProps={{
          defaultSelectedOptionKey: FollowViolationFields.REQUEST_NAME,
          placeHolder: () => t("followViolation.placeholder.enterName"),
        }}
        onRowClick={(params) =>
          router.push(
            `/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
          )
        }
        exportFile={renderExportButton()}
        onTabChange={setActiveTab}
        // initalColumnVisibilityModel={{
        //   [FollowViolationFields.STATUS_NEXT_ACTION]: false,
        // }}
      />

      {popupVisibleState?.[FollowViolationActionsBtnKey.SEND_MAIL] && (
        <SendMailFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.SEND_MAIL, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.SEND_MAIL]}
          followViolationId={initialFollowViolation?.id}
          followViolation={initialFollowViolation}
          name={initialFollowViolation?.name}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FORWARD] && (
        <ForwardFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FORWARD, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FORWARD]}
          violationId={initialFollowViolation?.id}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
          answerDate={initialFollowViolation?.answerDate}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK] && (
        <FeedBackFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FEEDBACK, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK]}
          violationId={initialFollowViolation?.id}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          answerDate={initialFollowViolation?.answerDate}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.SHARE,
              state,
              reload
            )
          }
          isOpen={true}
          owner={initialFollowViolation?.createBy}
          pics={initialFollowViolation?.responsibleUsers}
          initialValue={{
            legalAccessType: initialFollowViolation?.legalAccessType,
            sharedDepartments: initialFollowViolation?.sharedDepartments,
            sharedUsers: initialFollowViolation?.sharedUsers,
          }}
          onSubmit={async (data: any) => {
            const params = {
              id: initialFollowViolation?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAddInfoFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]
          }
          violationId={initialFollowViolation?.id}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          answerDate={initialFollowViolation?.answerDate || ""}
          createBy={initialFollowViolation?.createBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ASSIGNMENT] && (
        <AssignmentFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.ASSIGNMENT, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.ASSIGNMENT]}
          violationId={initialFollowViolation?.id}
          violation={initialFollowViolation}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_VENDOR] && (
        <RequestVendorFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.REQUEST_VENDOR,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_VENDOR]
          }
          violationId={initialFollowViolation?.id}
          violation={initialFollowViolation}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
        />
      )}

      {popupVisibleState?.[
        FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST
      ] && (
        <TimeExtensionFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
              state
            )
          }
          violationId={initialFollowViolation?.id}
          isOpen={
            popupVisibleState?.[
              FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST
            ]
          }
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_LC] && (
        <FeedBackLcFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FEEDBACK_LC, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_LC]}
          violationId={initialFollowViolation?.id}
          name={initialFollowViolation?.name}
          receiverUsers={initialFollowViolation?.receiverUsers}
          sender={appContext?.me}
          initialValue={{}}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE_FINISHED] && (
        <AdviceFinishedFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.ADVICE_FINISHED,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE_FINISHED]
          }
          violationId={initialFollowViolation?.id}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          initialValue={{
            users: initialFollowViolation?.receiverUsers,
          }}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE] && (
        <AdviceFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.ADVICE, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE]}
          violationId={initialFollowViolation?.id}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
          initialValue={{}}
          isAdvice
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE] &&
        Array.isArray(
          initialFollowViolation?.lastActionAndRole?.userLastActionAndRoleList
        ) &&
        initialFollowViolation?.lastActionAndRole?.userLastActionAndRoleList.some(
          (item: any) =>
            item?.role ===
            FollowViolationUserRole.get(FollowViolationUserRoleKey.SUPERVISOR)
        ) && (
          <AdviceFollowViolationForm
            setIsOpen={(state) =>
              changePopupVisible(FollowViolationActionsBtnKey.ADVICE, state)
            }
            isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE]}
            violationId={initialFollowViolation?.id}
            name={initialFollowViolation?.name}
            sender={appContext?.me}
            createBy={initialFollowViolation?.createBy}
            isSuperviorAdvisor
          />
        )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_ADVICE] && (
        <AdviceFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_ADVICE]
          }
          violationId={initialFollowViolation?.id}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
          isFeedBackAdvice
        />
      )}

      {popupVisibleState?.[
        FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION
      ] && (
        <FeedBackNextActionFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION
            ]
          }
          violationId={initialFollowViolation?.id}
          initialValue={{}}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION] && (
        <TrackNextActionFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]
          }
          violationId={initialFollowViolation?.id}
          initialValue={{}}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createBy}
          receiverUsers={initialFollowViolation?.receiverUsers}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FINISH] && (
        <FinishFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FINISH, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FINISH]}
          violationId={initialFollowViolation?.id}
          initialValue={{}}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
        />
      )}
    </>
  );
};

export default FollowViolationTable;
