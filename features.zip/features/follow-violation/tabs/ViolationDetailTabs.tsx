import { uploadDocumentTabAttachments } from '@/apis/service/files_upload/files';
import { LoadingWrapper } from '@/components/commons/loading_indicator/LoadingWrapper';
import { TabNav } from '@/components/commons/tab-nav/TabNav';
import { UploadPanel } from '@/components/commons/upload/upload_panel/UploadPanel';
import { COLOR_TYPE } from '@/constants/color';
import { AppContext } from '@/context/AppContext';
import { CommentPanel } from '@/features/metadata_tab_panel/comment_panel/CommentPanel';
import { ForwardedRef, forwardRef, useContext, useImperativeHandle, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { LANGUAGES } from '@/locales/config-translation';
import { BasedUser } from '@/models/user/User';
import { ViolationFeedbackPanel } from '../components/ViolationFeedbackPanel';
import { ViolationExtendPanel } from '../components/ViolationExtendPanel';
import { ViolationHistoryPanel } from '../components/ViolationHistoryPanel';
import { FollowViolationDetail, ViolationAssignment, ViolationFeedback, ViolationForward, ViolationRequestFeedback, ViolationTabsRef } from '@/models/follow_violation/FormType';
import { commentViolation, createViolationMeeting, deleteViolationMeeting, getViolationApproval, getViolationAssignments, getViolationAttachment, getViolationComments, getViolationExtensions, getViolationFeedbacks, getViolationForwards, getViolationHistory, getViolationInformationRequests, getViolationLCFeedback, getViolationMeeting, getViolationNextActionFeedback, getViolationRequestFeedback, updateViolationMeeting } from '@/apis/service/follow_violation/followViolationAPI';
import { InformationRequestPanel } from '../components/InformationRequestPanel';
import { ViolationApproval } from '../components/ViolationApproval';
import { formatDate } from '@/utils';
import { useQueryClient } from '@tanstack/react-query';
import { MeetingPanel } from '@/features/metadata_tab_panel/meeting_panel/MeetingPanel';

export interface ViolationTabsProps {
  violation?: FollowViolationDetail;
  violationId: number;
  containerHeight: number;
  loading?: boolean;
  ownRole?: number[];
}

const VIEW_ID = "violation-tabs";

const getUserLabel = (user: BasedUser, isEnglish: boolean) => {
  const name = user?.name;
  const positionObject = user?.position ?? user?.positionResponse;
  let position = isEnglish ? positionObject?.nameEnglish : positionObject?.name;
  position = position ? `${position}.` : "";
  const department = isEnglish ? user?.department?.nameEnglish : user?.department?.name;
  return `${name} (${user?.email}) - ${position}${department ?? ""}`
}

const ViolationDetailTabs = forwardRef(function VisitationTabs(
  props: ViolationTabsProps,
  ref: ForwardedRef<ViolationTabsRef>
) {
  const { loading, violationId, containerHeight, ownRole = [] } = props;
  const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const [activeIndex, setActiveIndex] = useState(0);
  const isEnglish = i18n.language === LANGUAGES.ENGLISH
  const queryClient = useQueryClient();
  
  const reloadDetail = () => queryClient.invalidateQueries({
    queryKey: ["get_initial_visitation_detail"],
  })

  const scrollToTab = (tab: number) => {
    setActiveIndex(tab);
    const tabElement = document.getElementById(VIEW_ID);
    setTimeout(() => tabElement?.scrollIntoView({
      behavior: 'smooth',
    }), 400)
  }

  useImperativeHandle(ref, () => ({
    scrollToTab: (tab: number) => scrollToTab(tab)
  }))

  return (
    <LoadingWrapper loading={loading || appContext.loading}>
      <div id={VIEW_ID} style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
        <TabNav
          index={activeIndex}
          onChangeTabIndex={setActiveIndex}
          tabItems={[
            // 1. Yêu cầu bổ sung thông tin
            {
              key: "information-request",
              label: t("metadata.informationRequest.title"),
              content: (
                <InformationRequestPanel
                  queryKey='violation-information-request'
                  getInformationRequests={async () => {
                    return (
                      (await getViolationInformationRequests((props.violationId)))
                        ?.map((ele, index: number) => ({
                          ...ele,
                          id: index + 1
                        })) ?? []
                    )
                  }
                  }
                />
              )

            },
            // 2. Phân công 
            {
              key: 'assignment',
              label: t('legalAdvice.tabs.assignment'),
              content: (
                <ViolationFeedbackPanel<ViolationAssignment>
                  getData={async () => {
                    return (
                      (await getViolationAssignments(props.violationId))
                        ?.assignmentResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) => item?.receiveUsers?.map((user) => getUserLabel(user, isEnglish)).join(', ')}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('followViolation.tabs.assignedBy')}:  ${getUserLabel(item.assignUser, isEnglish)}`}
                  contentHeader='followViolation.tabs.assignmentContent'
                  getContent={(item) => item.content}
                  queryKey='violation-assignment'
                />
              )
            },
            // 3. Chuyển tiếp
            {
              key: "forward",
              label: t("metadata.forward.title"),
              content: (
                <ViolationFeedbackPanel<ViolationForward>
                  getData={async () => {
                    return (await getViolationForwards(props.violationId))
                      ?.forwardResponseDetails ?? []
                  }}
                  getTitle={(item) => item?.receiveUsers?.map((user) => getUserLabel(user, isEnglish)).join(', ')}
                  getDisplayDate={(item) => item.forwardDate}
                  getSubtitle={(item) => `${t('followViolation.tabs.forwardedTo')}:  ${item?.receiveUsers
                    ?.map((user) => getUserLabel(user, isEnglish))
                    .join(", ")}`}
                  contentHeader='followViolation.forwardLegalAdvice.title.content'
                  getContent={(item) => item.content}
                  queryKey='violation-forward'
                />
              ),
            },
            // 4. Gia hạn thời gian
            {
              key: 'extend',
              label: t("metadata.extend.title"),
              content: (
                <ViolationExtendPanel
                  violationId={props.violationId}
                  violation={props.violation}
                  getExtendRecords={async () => {
                    return (await getViolationExtensions(props.violationId))
                      ?.timeExtensionResponseDetails ?? []
                  }}
                  queryKey='violation-extend-tab'
                />
              )
            },
            // 5. Phản hồi tư vấn
            {
              key: 'violation-feedback',
              label: t('followViolation.tabs.adviceFeedback'),
              content: (
                <ViolationFeedbackPanel<ViolationFeedback>
                  getData={async () => {
                    return (await getViolationFeedbacks(props.violationId))
                      ?.feedbackAdviseResponseDetails ?? []
                  }
                  }
                  getTitle={(item) => getUserLabel(item.feedbackAdviseUser, isEnglish)}
                  getDisplayDate={(item) => (item.date)}
                  getSubtitle={(item) => `${t('followViolation.tabs.feedbackTo')}: ${getUserLabel(item.receiveUser, isEnglish)}`}
                  contentHeader='followViolation.tabs.adviceFeedbackContent'
                  getContent={(item) => item.reason}
                  getNewDeadline={(item) => formatDate(item.deadline)}
                  queryKey='violation-feedback'
                />
              )
            },
            // 6. Phản hồi L&C
            {
              key: 'violation-legal-feedback',
              label: t('followViolation.tabs.lcFeedback'),
              content: (
                <ViolationFeedbackPanel<ViolationRequestFeedback>
                  getData={async () => {
                    return (await getViolationLCFeedback(props.violationId))
                      ?.feedbackResponseDetails ?? []
                  }}
                  getTitle={(item) => getUserLabel(item.feedbackUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('followViolation.tabs.feedbackToLC')}: ${item.receiveUsers.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='followViolation.tabs.feedbackContent'
                  getContent={(item) => item.content}
                  queryKey='violation-legal-feedback'
                />
              )
            },
            // 7. Phản hồi next action
            {
              key: 'violation-next-action-feedback',
              label: t('followViolation.tabs.nextActionFeedback'),
              content: (
                <ViolationFeedbackPanel<ViolationRequestFeedback>
                  getData={async () => {
                    return (await getViolationNextActionFeedback(props.violationId))
                      ?.feedbackResponseDetails ?? []
                  }}
                  getTitle={(item) => getUserLabel(item.feedbackUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('followViolation.tabs.feedbackNextActionTo')}: ${item.receiveUsers.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='followViolation.tabs.feedbackNextActionContent'
                  getContent={(item) => item.content}
                  queryKey='violation-next-action-feedback'
                />
              )
            },
            
            // 8. Phản hồi văn bản
            {
              key: 'violation-document-feedback',
              label: t('legalAdvice.tabs.documentFeedback'),
              content: (
                <ViolationFeedbackPanel<ViolationRequestFeedback>
                  getData={async () => {
                    return (await getViolationRequestFeedback(props.violationId))
                      ?.feedbackResponseDetails ?? []
                  }}
                  getTitle={(item) => getUserLabel(item.feedbackUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('followViolation.tabs.feedbackInformationTo')}: ${item.receiveUsers.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='followViolation.tabs.feedbackContent'
                  getContent={(item) => item.content}
                  queryKey='violation-document-feedback'
                />
              )
            },
            // 9. Book lịch họp
            {
              key: "meeting",
              label: t("metadata.meeting.tab"),
              content: (
                <MeetingPanel
                  containerHeight={containerHeight}
                  queryKey={`violation-meeting-${violationId}`}
                  reloadDetail={reloadDetail}
                  updateMeeting={(data) => updateViolationMeeting({
                    id: violationId,
                    content: data.content,
                    meetingId: data.meetingId
                  })
                  }
                  deleteMeeting={(meetingId) => deleteViolationMeeting({
                    id: violationId,
                    meetingId: meetingId
                  })}
                  getMeetings={async () => {
                    return (
                      (await getViolationMeeting(violationId))
                        .result?.meetingResponses ?? []
                    );
                  }}
                  addMeeting={(content) =>
                    createViolationMeeting({
                      id: violationId,
                      content: content,
                    })
                  }
                  disabled={
                    !appContext.meCanRead
                    || (!ownRole.includes(1)
                      && !ownRole.includes(2)
                    )
                  }
                />
              ),
            },
            // 10. Duyệt
            {
              key: 'violation-approval',
              label: t('followViolation.tabs.approval'),
              content: (
                <ViolationApproval
                  getData={async () => {
                    return (await getViolationApproval(props.violationId)) ?? []
                  }}
                  queryKey='violation-approval-tab'
                />
              )
            },
            // 11. Bình luận
            {
              key: "comment",
              label: t("metadata.comment.title"),
              content: (
                <CommentPanel
                  queryKey="violation-comment"
                  getComments={async () => {
                    return (
                      (await getViolationComments(props.violationId))
                        .result?.data ?? []
                    );
                  }}
                  addComment={(comment) =>
                    commentViolation({
                      id: props.violationId,
                      content: comment,
                    })
                  }
                  disabled={
                    !appContext.meCanRead ||
                    props.violation?.lastActionAndRole
                      ?.userLastActionAndRoleList?.length === 0
                  }
                />
              ),
            },
            // 12. Đính kèm
            {
              key: "attachment",
              label: t("metadata.attachment.title"),
              content: (
                <UploadPanel
                  queryKey="violation-upload"
                  onGetFiles={async () =>
                    (
                      (await getViolationAttachment(props.violationId))
                        ?.data || []
                    ).map((attachment) => ({
                      fileId: attachment.fileId,
                      fileName: attachment.fileName,
                      storagePath: attachment.filePath,
                      uploadDate: formatDate(attachment.uploadDate),
                    }))
                  }
                  onDelete={() => Promise.resolve()}
                  onUpload={async (files) => {
                    await uploadDocumentTabAttachments({
                      files: files,
                      id: props.violationId,
                      reference_file_type: 4
                    });
                  }}
                  disabled
                />
              ),
            },
            // 13. Lịch sử
            {
              key: "history",
              label: t("metadata.history.title"),
              content: (
                <ViolationHistoryPanel
                  queryKey="violation-history"
                  ownRole={ownRole}
                  getHistoryRecords={async () => {
                    return (await getViolationHistory(props.violationId))?.data ?? []
                  }}
                />
              ),
            },
          ]}
        />
      </div>
    </LoadingWrapper>
  )
})

export default ViolationDetailTabs