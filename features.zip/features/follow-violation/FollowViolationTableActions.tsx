import React, { useContext, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { IconAdvise } from "@/assets/iconMenu/IconAdvise";
import { IconAssignment } from "@/assets/iconMenu/IconAssignment";
import { IconConfirm } from "@/assets/iconMenu/IconConfirm";
import { IconDone } from "@/assets/iconMenu/IconDone";
import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";
import { IconFeedback } from "@/assets/iconMenu/IconFeedback";
import { IconFeedbackAdvise } from "@/assets/iconMenu/IconFeedbackAdvise";
import { IconForward } from "@/assets/iconMenu/IconForward";
import { IconRequestAdditional } from "@/assets/iconMenu/IconRequestAdditional";
import { IconRequestMeeting } from "@/assets/iconMenu/IconRequestMeeting";
import { IconSendMail } from "@/assets/iconMenu/IconSendMail";
import { IconRecall } from "@/assets/iconMenu/IconRecall";
import { IconNextAction } from "@/assets/iconMenu/IconNextAction";
import { IconRequestVendor } from "@/assets/iconMenu/IconRequestVendor";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";
import {
  ActionButtonCustom,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButtonCustom";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { COLOR_TYPE } from "@/constants/color";
import { TypeActionRole } from "@/constants/general";
import { IconResponseLc } from "@/assets/iconMenu/IconResponseLc";
import { NextActionContext } from "@/context/NextActionContext";
import {
  recheckRequestApprovalNextAction,
  recheckViolation,
} from "@/apis/service/follow_violation/followViolationAPI";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useMutation } from "@tanstack/react-query";
import router from "next/router";
import { toast } from "react-toastify";
import {
  authorizedActionMapCallBack,
  authorizedDetailActionMapCallBack,
  authorizedNextlActionMapCallBack,
  FollowViolationActionsBtnKey,
  FollowViolationStatusKey,
  FollowViolationStatusR,
} from "@/constants/followViolation";
import IconShare from "@/assets/iconMenu/IconShare";
import { AppContext } from "@/context/AppContext";

type TypePropsFollowViolationTableActions = {
  params: any;
  activeTab?: number;
  isEditNextActionTab?: boolean;
  isActionDetail?: boolean;
  handleClickRecall?: () => void;
  handleClickForWard?: () => void;
  handleClickFeedBack?: () => void;
  handleClickShare?: () => void;
  handleClickFeedBackLc?: () => void;
  handleClickRequestMeeting?: () => void;
  handleClickSendMail?: () => void;
  handleClickExtendTime?: () => void;
  handleClickConfirm?: () => void;
  handleClickAssignment?: () => void;
  handleClickRequestVendor?: () => void;
  handleClickAdviseFinished?: () => void;
  handleClickFeedbackAdvise?: () => void;
  handleClickRequestAdditional?: () => void;
  handleClickAdditionalInformation?: () => void;
  handleClickAdvise?: () => void;
  handleClickSendToSupervisor?: () => void;
  handleClickRequestApprovalDeptHead?: () => void;
  handleClickApprovalDeptHead?: (list: string[]) => void;
  handleClickRequestApprovalGroupHead?: () => void;
  handleClickApprovalGroupHead?: () => void;
  handleClickRequestApprovalTopHead?: () => void;
  handleClickApprovalTopHead?: () => void;
  handleClickFeedBackNextAction?: () => void;
  handleClickTrackNextAction?: () => void;
  handleClickFinish?: () => void;
  handleClickRequestRecheck?: () => void;
};

export const FollowViolationTableActions = (
  props: TypePropsFollowViolationTableActions
) => {
  const {
    params,
    isActionDetail = false,
    handleClickRecall = () => {},
    handleClickForWard = () => {},
    handleClickFeedBack = () => {},
    handleClickShare = () => {},
    handleClickFeedBackLc = () => {},
    handleClickRequestMeeting = () => {},
    handleClickSendMail = () => {},
    handleClickExtendTime = () => {},
    handleClickConfirm = () => {},
    handleClickAssignment = () => {},
    handleClickRequestVendor = () => {},
    handleClickAdviseFinished = () => {},
    handleClickFeedbackAdvise = () => {},
    handleClickRequestAdditional = () => {},
    handleClickAdditionalInformation = () => {},
    handleClickAdvise = () => {},
    handleClickSendToSupervisor = () => {},
    handleClickFeedBackNextAction = () => {},
    handleClickTrackNextAction = () => {},
    handleClickFinish = () => {},
    // handleClickRequestRecheck = () => {},
  } = props;
  const [t] = useTranslation();
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { approve } = useContext(NextActionContext);
  const appContext = useContext(AppContext);

  const requestRecheckQuery = useMutation({
    mutationFn: recheckViolation,
    onSuccess: () => {
      toast.success(
        t("followViolation.requestRecheck.message.success", {
          recordName: t("menu.violationTracking"),
        })
      );
      router.push(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const recheckRequestApprovalNextActionQuery = useMutation({
    mutationFn: recheckRequestApprovalNextAction,
    onSuccess: () => {
      toast.success(
        t("followViolation.requestApprovalNextActionAgain.message.success", {
          recordName: t("menu.violationTracking"),
        })
      );
      router.push(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const styleBtn = {
    background: COLOR_TYPE.TOYOTA.TOYOTA1,
    color: COLOR_TYPE.TOYOTA.TOYOTA8,
  };

  const handleClickRequestRecheck = () => {
    requestRecheckQuery.mutate({ id: +(params?.row?.id ?? 0) });
  };

  const handleClickRequestApprovalNextAction = () => {
    recheckRequestApprovalNextActionQuery.mutate({
      id: +(params?.row?.id ?? 0),
    });
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const buttonMap = new Map<string, ActionButtonItem>([
    [
      FollowViolationActionsBtnKey.RECALL,
      {
        key: FollowViolationActionsBtnKey.RECALL,
        icon: <IconRecall />,
        iconDisable: <IconRecall color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.RECALL}`
        ),
        onClick: handleClickRecall,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.RECALL}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `followViolation.recallFollowViolation.message.confirm_${FollowViolationActionsBtnKey.RECALL}`
          ),
        },
        styleBtn,
        secondaryBtn: 1,
      },
    ],
    [
      FollowViolationActionsBtnKey.FORWARD,
      {
        key: FollowViolationActionsBtnKey.FORWARD,
        icon: <IconForward />,
        iconDisable: <IconForward color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FORWARD}`
        ),
        onClick: handleClickForWard,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FORWARD}`
        ),
        styleBtn,
        secondaryBtn: 3,
      },
    ],
    [
      FollowViolationActionsBtnKey.FEEDBACK,
      {
        key: FollowViolationActionsBtnKey.FEEDBACK,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK}`
        ),
        onClick: handleClickFeedBack,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK}`
        ),
        styleBtn,
        secondaryBtn: 4,
      },
    ],
    [
      FollowViolationActionsBtnKey.REQUEST_MEETING,
      {
        key: FollowViolationActionsBtnKey.REQUEST_MEETING,
        icon: <IconRequestMeeting />,
        iconDisable: <IconRequestMeeting color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_MEETING}`
        ),
        onClick: handleClickRequestMeeting,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_MEETING}`
        ),
        styleBtn,
        secondaryBtn: 5,
      },
    ],
    [
      FollowViolationActionsBtnKey.SHARE,
      {
        key: FollowViolationActionsBtnKey.SHARE,
        icon: <IconShare />,
        iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.SHARE}`
        ),
        onClick: handleClickShare,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.SHARE}`
        ),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      FollowViolationActionsBtnKey.SEND_MAIL,
      {
        key: FollowViolationActionsBtnKey.SEND_MAIL,
        icon: <IconSendMail />,
        iconDisable: <IconSendMail color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.SEND_MAIL}`
        ),
        onClick: handleClickSendMail,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.SEND_MAIL}`
        ),
        styleBtn,
        secondaryBtn: 2,
      },
    ],
    [
      FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
      {
        key: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
        icon: <IconExtendDeadline />,
        iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST}`
        ),
        onClick: handleClickExtendTime,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST}`
        ),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      FollowViolationActionsBtnKey.CONFIRM,
      {
        key: FollowViolationActionsBtnKey.CONFIRM,
        icon: <IconConfirm />,
        iconDisable: <IconConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.CONFIRM}`
        ),
        onClick: handleClickConfirm,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.CONFIRM}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `followViolation.confirmFollowViolation.message.confirm_done`
          ),
        },
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.ASSIGNMENT,
      {
        key: FollowViolationActionsBtnKey.ASSIGNMENT,
        icon: <IconAssignment />,
        iconDisable: <IconAssignment color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ASSIGNMENT}`
        ),
        onClick: handleClickAssignment,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ASSIGNMENT}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.REQUEST_VENDOR,
      {
        key: FollowViolationActionsBtnKey.REQUEST_VENDOR,
        icon: <IconRequestVendor />,
        iconDisable: <IconRequestVendor color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_VENDOR}`
        ),
        onClick: handleClickRequestVendor,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_VENDOR}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.ADVICE_FINISHED,
      {
        key: FollowViolationActionsBtnKey.ADVICE_FINISHED,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ADVICE_FINISHED}`
        ),
        onClick: handleClickAdviseFinished,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ADVICE_FINISHED}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
      {
        key: FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
        icon: <IconFeedbackAdvise />,
        iconDisable: <IconFeedbackAdvise color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK_ADVICE}`
        ),
        onClick: handleClickFeedbackAdvise,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK_ADVICE}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
      {
        key: FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
        icon: <IconRequestAdditional />,
        iconDisable: (
          <IconRequestAdditional color={COLOR_TYPE.TOYOTA.TOYOTA5} />
        ),
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_ADDITIONAL}`
        ),
        onClick: handleClickRequestAdditional,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_ADDITIONAL}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION,
      {
        key: FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION}`
        ),
        onClick: handleClickAdditionalInformation,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `followViolation.additionalInformationFollowViolation.message.confirm_${FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION}`
          ),
        },
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.ADVICE,
      {
        key: FollowViolationActionsBtnKey.ADVICE,
        icon: <IconAdvise />,
        iconDisable: <IconAdvise color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ADVICE}`
        ),
        onClick: handleClickAdvise,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.ADVICE}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.SENT_SUPERVISOR,
      {
        key: FollowViolationActionsBtnKey.SENT_SUPERVISOR,
        icon: <IconRequestVendor />,
        iconDisable: <IconRequestVendor color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.SENT_SUPERVISOR}`
        ),
        onClick: handleClickSendToSupervisor,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.SENT_SUPERVISOR}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.FEEDBACK_LC,
      {
        key: FollowViolationActionsBtnKey.FEEDBACK_LC,
        icon: <IconResponseLc />,
        iconDisable: <IconResponseLc color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK_LC}`
        ),
        onClick: handleClickFeedBackLc,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK_LC}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION,
      {
        key: FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION,
        icon: <IconResponseLc />,
        iconDisable: <IconResponseLc color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION}`
        ),
        onClick: handleClickFeedBackNextAction,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
      {
        key: FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
        icon: <IconNextAction />,
        iconDisable: <IconNextAction color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.TRACK_NEXT_ACTION}`
        ),
        onClick: handleClickTrackNextAction,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.TRACK_NEXT_ACTION}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.FINISH,
      {
        key: FollowViolationActionsBtnKey.FINISH,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FINISH}`
        ),
        onClick: handleClickFinish,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.FINISH}`
        ),
        styleBtn,
      },
    ],
    [
      FollowViolationActionsBtnKey.REQUEST_RECHECK,
      {
        key: FollowViolationActionsBtnKey.REQUEST_RECHECK,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_RECHECK}`
        ),
        onClick: handleClickRequestRecheck,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_RECHECK}`
        ),
        styleBtn,
        confirmPopupProps: {
          icon: <IconDone />,
          title: t(`followViolation.requestRecheck.message.confirm`),
        },
      },
    ],
    [
      FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN,
      {
        key: FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN}`
        ),
        onClick: handleClickRequestApprovalNextAction,
        tooltipTitle: t(
          `followViolation.button.${FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN}`
        ),
        styleBtn,
        confirmPopupProps: {
          icon: <IconDone />,
          title: t(
            `followViolation.requestApprovalNextActionAgain.message.confirm`
          ),
        },
      },
    ],
  ]);

  const getActionButtonItems = useMemo(() => {
    if (props.activeTab === 0) {
      let detailButtons = authorizedDetailActionMapCallBack(
        params?.row?.lastActionAndRole?.userLastActionAndRoleList ?? [],
        params
      )?.map((buttons: TypeActionRole) => ({
        ...buttonMap.get(buttons?.typeBtn)!,
        disable: buttons?.disable,
      }));

      const currentRowStatus = FollowViolationStatusR.get(
        params?.row?.status?.code as number
      );

      if (currentRowStatus === FollowViolationStatusKey.FINISH) {
        detailButtons = detailButtons.filter(
          (button) =>
            button.key === FollowViolationActionsBtnKey.REQUEST_RECHECK
        );
      } else {
        detailButtons = detailButtons.filter(
          (button) =>
            button.key !== FollowViolationActionsBtnKey.REQUEST_RECHECK
        );
      }

      if (
        currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED &&
        appContext?.me?.id === params?.row?.createdBy?.id
      ) {
        // Với người tạo, trạng thái Hoàn thành tư vấn => Hiển thị action Hoàn thành và Chia sẻ
        detailButtons = detailButtons.filter(
          (button) =>
            button.key === FollowViolationActionsBtnKey.SHARE ||
            button.key === FollowViolationActionsBtnKey.FINISH
        );
      } else if (
        currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED &&
        appContext?.me?.id !== params?.row?.createdBy?.id
      ) {
        // Với không phải người tạo, trạng thái Hoàn thành tư vấn => Chỉ hiển thị action Chia sẻ
        detailButtons = detailButtons.filter(
          (button) => button.key === FollowViolationActionsBtnKey.SHARE
        );
      } else {
      }

      return detailButtons;
    }

    if (!props.isEditNextActionTab) {
      return [];
    }

    let nextActionButtons = authorizedNextlActionMapCallBack(
      params?.row?.lastActionAndRole?.userLastActionAndRoleList ?? [],
      params
    )?.map((buttons: TypeActionRole) => {
      const disabled = buttons?.disable;
      return {
        ...buttonMap.get(buttons?.typeBtn)!,
        disable: disabled,
      };
    });

    const currentRowStatus = FollowViolationStatusR.get(
      params?.row?.status?.code as number
    );

    if (currentRowStatus === FollowViolationStatusKey.FINISH) {
      nextActionButtons = nextActionButtons.filter(
        (button) =>
          button.key ===
          FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN
      );
    } else {
      nextActionButtons = nextActionButtons.filter(
        (button) =>
          button.key !==
          FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN
      );
    }

    return nextActionButtons;
  }, [
    appContext?.me?.id,
    buttonMap,
    params,
    props.activeTab,
    props.isEditNextActionTab,
  ]);

  if (isActionDetail) {
    return (
      <ActionButtonDetail
        params={params}
        actionButtonItems={getActionButtonItems}
      />
    );
  }

  let listButtons = authorizedActionMapCallBack(
    params?.row?.lastActionAndRole?.userLastActionAndRoleList ?? [],
    params
  )?.map((buttons: TypeActionRole) => ({
    ...buttonMap.get(buttons?.typeBtn)!,
    disable: buttons?.disable,
  }));

  const currentRowStatus = FollowViolationStatusR.get(
    params?.row?.status?.code as number
  );

  if (currentRowStatus === FollowViolationStatusKey.FINISH) {
    listButtons = listButtons.filter(
      (button) =>
        button.key === FollowViolationActionsBtnKey.REQUEST_RECHECK ||
        button.key ===
          FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN
    );
  } else {
    listButtons = listButtons.filter(
      (button) =>
        button.key !== FollowViolationActionsBtnKey.REQUEST_RECHECK &&
        button.key !==
          FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN
    );
  }

  if (
    currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED &&
    appContext?.me?.id === params?.row?.createBy?.id
  ) {
    // Với người tạo, trạng thái Hoàn thành tư vấn => Hiển thị action Hoàn thành và Chia sẻ
    listButtons = listButtons.filter(
      (button) =>
        button.key === FollowViolationActionsBtnKey.SHARE ||
        button.key === FollowViolationActionsBtnKey.FINISH
    );
  } else if (
    currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED &&
    appContext?.me?.id !== params?.row?.createBy?.id
  ) {
    // Với không phải người tạo, trạng thái Hoàn thành tư vấn => Chỉ hiển thị action Chia sẻ
    listButtons = listButtons.filter(
      (button) => button.key === FollowViolationActionsBtnKey.SHARE
    );
  } else {
  }

  return (
    <ActionButtonCustom
      params={params}
      actionButtonItems={listButtons}
      listActions={
        props?.params?.row?.lastActionAndRole?.userLastActionAndRoleList ?? []
      }
    />
  );
};
