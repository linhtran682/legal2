import FileUploadComponent from "@/components/commons/upload/file_upload/FileUpload";
import {
  AdvisorLegalAdviceFieldNames,
  ResponsesAdvisorLegalAdviceDTO,
} from "@/models/legal-advice/AdvisorLegalAdvice";
import { Grid, InputLabel, TextField, Typography } from "@mui/material";
import React from "react";
import { useTranslation } from "react-i18next";

type TypePropsListAdvisorLegal = {
  data?: ResponsesAdvisorLegalAdviceDTO[];
};

export const ListAdvisorLegalAdvice = (props: TypePropsListAdvisorLegal) => {
  const { data } = props;
  const { t } = useTranslation();
  return (
    <>
      {data?.map((item) => {
        const attachmentsItem = item.attachments?.map((item: any) => {
          return {
            name: item?.fileName,
            path: item?.filePath,
            id: item?.fileId,
            uploadDate: item?.uploadDate,
          };
        });
        return (
          <>
            <Grid key={item?.id} item width={"100%"}>
              <InputLabel shrink sx={{ ml: 1.7 }}>
                {t("legalAdvice.advisorLegalAdvice.title.receiverUsers")}
              </InputLabel>
              <Typography>{`${item?.user?.name} (${item?.user?.email}) - ${item?.department?.name}`}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <TextField
                value={item?.content}
                label={t(
                  `legalAdvice.advisorLegalAdvice.title.${AdvisorLegalAdviceFieldNames.CONTENT}`
                )}
                placeholder={t(
                  `legalAdvice.advisorLegalAdvice.placeHolder.${AdvisorLegalAdviceFieldNames.CONTENT}`
                )}
                minRows={3}
                size="small"
                InputLabelProps={{
                  shrink: true,
                }}
                multiline
                fullWidth
                disabled
              />
            </Grid>
            <Grid item width={"100%"}>
              <FileUploadComponent
                files={attachmentsItem as any}
                setFiles={() => {}}
                disabled
                inputId={`file-input-${item?.id}`}
              />
            </Grid>
          </>
        );
      })}
    </>
  );
};
