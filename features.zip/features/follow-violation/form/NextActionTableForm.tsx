import { getUser, getUsers } from "@/apis/service/user/User";
import { AddButton } from "@/components/commons/action_button/AddButton";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { COLOR_TYPE } from "@/constants/color";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  NextActionFieldsName,
  NextActionItem,
  NextActionTableFieldsName,
  ViolationNextActionResponse,
} from "@/models/follow_violation/FormType";
import {
  Box,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import { useContext, useEffect, useState } from "react";
import { useFieldArray } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { isNil } from "lodash";
import { toast } from "react-toastify";
import {
  FollowViolationUserRole,
  FollowViolationUserRoleKey,
} from "@/constants/followViolation";
import { NextActionContext } from "@/context/NextActionContext";
import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { UserProfileDTO } from "@/models/user/User";

// Define a custom type for renderCell parameters
export interface CustomRenderCellParams<T> {
  id: string;
  value: any;
  field: string;
  row: T;
}

interface ColumnType {
  key: NextActionTableFieldsName;
  label: string;
  type:
    | "label"
    | "input"
    | "checkbox"
    | "date"
    | "select"
    | "radio"
    | "multipleSelect"
    | undefined;
}

export interface StandardSimpleTableColumn<T> {
  key: string;
  label: string;
  type: "date" | "number" | "string" | "checkbox" | undefined;
  flex?: number;
  renderCell?: (params: CustomRenderCellParams<T>) => React.ReactNode;
}

export interface StandardSimpleTableProps<T> {
  recordName?: string;
  data: T[];
  getRowId: (data: T, index: number) => string;
  columns: StandardSimpleTableColumn<T>[];
  loading?: boolean;
}

const DEFAULT_COLUMNS: ColumnType[] = [
  {
    key: NextActionTableFieldsName.POSITION,
    label: "followViolation.nextAction.position",
    type: "label",
  },
  {
    key: NextActionTableFieldsName.CATEGORY,
    label: "followViolation.nextAction.category",
    type: "input",
  },
  {
    key: NextActionTableFieldsName.LEGAL_REQUIREMENTS,
    label: "followViolation.nextAction.legalRequirement",
    type: "input",
  },
  {
    key: NextActionTableFieldsName.COMPLIANCE_ASSESSMENT,
    label: "followViolation.nextAction.complianceAssessment",
    type: "input",
  },

  {
    key: NextActionTableFieldsName.CURRENT_STATUS,
    label: "followViolation.nextAction.currentStatus",
    type: "input",
  },
  {
    key: NextActionTableFieldsName.WORK_NEED,
    label: "followViolation.nextAction.workNeed",
    type: "input",
  },
  {
    key: NextActionTableFieldsName.RECEIVERS_IDS,
    label: "followViolation.label.receiver",
    type: "multipleSelect",
  },
  {
    key: NextActionTableFieldsName.DEADLINE,
    label: "followViolation.nextAction.deadline",
    type: "date",
  },
];

type Props = {
  error: any;
  form: any;
  isCreate: boolean;
  onDeleteItems: (deleteItems: number[]) => Promise<void>;
  formMode: "create" | "update";
  ownRole: number[];
  nextActionData?: ViolationNextActionResponse | undefined;
  dimensions: number;
  isDisable: boolean;
};
export function NextActionTableForm({
  error,
  form,
  isCreate,
  onDeleteItems,
  ownRole,
  dimensions,
  isDisable,
}: Props) {
  const { control } = form;
  const [t] = useTranslation();
  const [selected, setSelected] = useState<number[]>([]);
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const { selectApproveItems } = useContext(NextActionContext);
  
  const { fields, append } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormProvider)
    name: NextActionFieldsName.NEXT_ACTION, // unique name for your Field Array
  });

  useEffect(() => {
    return () => {
      selectApproveItems(null, []);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const picRole =
    FollowViolationUserRole.get(FollowViolationUserRoleKey.PIC) ?? 0;

  const isEnableDelete = ownRole.includes(picRole);
  const disabled = isDisable;

  const renderCell = (column: ColumnType, index: number) => {
    const fieldName = `${NextActionFieldsName.NEXT_ACTION}.${index}.${column.key}`;
    switch (column.type) {
      case "input":
        return (
          <FormTextField
            control={control}
            name={fieldName}
            disabled={isDisable}
          />
        );
      case "date":
        return (
          <Box sx={{ width: 140 }}>
            <DateInput
              name={fieldName}
              control={control}
              disabled={isDisable}
              isVisibleHidden={false}
            />
          </Box>
        );
      case "select":
        return (
          <Box sx={{ width: 200 }}>
            <FormAsyncSelect
              control={control}
              name={fieldName}
              disabled={isDisable}
              label={""}
              placeholder={t(`followViolation.placeholder.relatedIds`)}
              getOptions={async (keyword) => {
                if (typeof keyword == "string") {
                  const params = {
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  };

                  const response = await getUsers(params);

                  return response?.users ?? [];
                } else if (keyword?.length && keyword.length > 0) {
                  return getUser(keyword[0])
                    .then((response) => (response ? [response] : []))
                    .catch(() => []);
                }

                return [];
              }}
              getOptionLabel={(option) =>
                `${option.name ?? ""} (${option.email ?? ""}) - ${
                  option?.department?.name ?? option?.departmentName ?? ""
                }`
              }
              getOptionKey={(option) => option.id}
              keyQuery={`queryRelatedUser_${fieldName}`}
            />
          </Box>
        );
      case "multipleSelect": 
        return  <Box sx={{ width: 650 }}>
        <FormMultipleSelect<any, UserProfileDTO>
          control={form.control}
          name={fieldName}
          label=""
          placeholder={t(`followViolation.label.receiver`)}
          minCharLength={1}
          getOptions={async (keyword) => {
            const response = await getUsers({
              searchTerm: keyword,
              page: 0,
              size: 100,
              sortBy: "name",
              sortOrder: "ASC",
            });
            return (
              response?.users
                ?.map((user) => ({
                  ...user,
                  rank: 99999,
                }))
                ?.sort((first, second) => first.rank - second.rank) ??
              []
            );
          }}
          getOptionLabel={(option) =>
            `${option.name ?? ""}`
          }
          required
          getOptionKey={(option) => option.id}
          keyQuery="queryNextActionReceived"
          isFocus
        />
        </Box>
        
      default:
        return index + 1;
    }
  };

  const handleAddNextAction = () => {
    append({
      [NextActionTableFieldsName.CATEGORY]: "",
      [NextActionTableFieldsName.LEGAL_REQUIREMENTS]: "",
      [NextActionTableFieldsName.COMPLIANCE_ASSESSMENT]: "",
      [NextActionTableFieldsName.CURRENT_STATUS]: "",
      [NextActionTableFieldsName.WORK_NEED]: "",
      [NextActionTableFieldsName.RECEIVERS_IDS]: "",
    });
  };

  const handleSelectAllClick = (checked: boolean) => {
    if (checked) {
      const newSelected = fields.map((n, index) => index);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };

  const handleClickCheckbox = (event: any, index: number) => {
    const selectedIndex = selected.indexOf(index);
    let newSelected: number[] = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, index);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }
    setSelected(newSelected);
  };

  const handleDeleteItems = () => {
    const actionsData: NextActionItem[] = form.getValues(
      NextActionFieldsName.NEXT_ACTION
    );
    const actionsDeletedData = actionsData.filter((_, index) =>
      selected.includes(index)
    );

    for (let index = 0; index < actionsDeletedData.length; index++) {
      const deletedItem = actionsDeletedData[index];
      if (deletedItem?.nextActionId) {
        const isAllApproved =
          deletedItem.deptHeadApproved &&
          deletedItem.groupHeadApproved &&
          deletedItem.topHeadApproved;
        const isOneApproved =
          deletedItem.deptHeadApproved ||
          deletedItem.groupHeadApproved ||
          deletedItem.topHeadApproved;
        const isOneApproving =
          isNil(deletedItem.deptHeadApproved) ||
          isNil(deletedItem.groupHeadApproved) ||
          isNil(deletedItem.topHeadApproved);
        if (isAllApproved || (isOneApproved && isOneApproving)) {
          toast.error(t("followViolation.messages.deleteNextActionFailure"));
          return;
        }
      }
    }
    setConfirmPopupState({
      open: true,
      handleConfirm: () => {
        const selectedItem = [...selected];
        onDeleteItems(selectedItem);
        setTimeout(() => {
          setConfirmPopupState((pre) => ({ ...pre, open: false }));
          setSelected([]);
        }, 200);
      },
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
      icon: <DeleteRecordDialogIcon />,
      title: t("common.message.confirm_delete"),
    });
  };

  return (
    <Box sx={{ overflow: "hidden", width: "100%" }}>
      <Typography
        variant="body2"
        component="div"
        sx={{
          mb: 1,
          visibility: selected?.length > 0 ? "visible" : "hidden",
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <Typography
          variant="body2"
          component="span"
          sx={{ fontWeight: "bold" }}
        >
          {selected.length}&nbsp;
        </Typography>
        {t("common.table.records_selected", {
          recordName: t("common.table.record"),
        })}
        {!isCreate && isEnableDelete && (
          <Box component="span" ml={1}>
            <IconButton aria-label="delete" onClick={handleDeleteItems}>
              <DeleteIcon />
            </IconButton>
          </Box>
        )}
      </Typography>
      <Paper
        sx={{ width: "100%", overflowX: "auto", maxWidth: dimensions - 50 }}
      >
        <TableContainer
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          overflowX: "auto",
          "& .MuiTableCell-root.MuiTableCell-head": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
            fontFamily:
              "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
            "&:focus-within": {
              outline: "none",
            },
            fontWeight: 700,
            border: "1px solid #ccc",
          },
        }}
      >
        <Table
          stickyHeader
          aria-label="sticky table"
          sx={{ whiteSpace: "nowrap", overflowX: "auto", minWidth: "2000px", }}>
          <TableHead>
            <TableRow>
              <TableCell
                width={60}
                sx={{
                  backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA6}`,
                  width: 60,
                }}
              >
                <CheckboxInput
                  borderColor={
                    disabled
                      ? COLOR_TYPE.TOYOTA.TOYOTA5
                      : COLOR_TYPE.TOYOTA.TOYOTA1
                  }
                  checkboxBg={disabled ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"}
                  labelVariant={disabled ? "subtitle1" : undefined}
                  checked={
                    fields.length > 0 && selected.length === fields.length
                  }
                  disabled={disabled}
                  onChange={handleSelectAllClick}
                  wraperStyles={{ justifyContent: "center" }}
                />
              </TableCell>
              {DEFAULT_COLUMNS.map((column) => (
                <TableCell
                  key={column.key}
                  sx={{
                    backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA6}`,
                    color: COLOR_TYPE.TOYOTA.TOYOTA2,
                    fontWeight: "bold",
                  }}
                >
                  {t(column.label)}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {fields.map((item, index) => {
              const isItemSelected = selected.includes(index);
              return (
                <TableRow key={item.id}>
                  <TableCell
                    width={60}
                    sx={{
                      width: 60,
                      border: "1px solid #e0e0e0",
                    }}
                  >
                    <CheckboxInput
                      borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
                      checkboxBg={
                        disabled ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"
                      }
                      labelVariant={disabled ? "subtitle1" : undefined}
                      checked={isItemSelected}
                      disabled
                      onChange={(value) => handleClickCheckbox(value, index)}
                      wraperStyles={{ justifyContent: "center" }}
                    />
                  </TableCell>
                  {DEFAULT_COLUMNS.map((column) => (
                    <TableCell
                      key={`${column.key}-${item.id}`}
                      component="th"
                      scope="row"
                      sx={{
                        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                        border: "1px solid #e0e0e0",
                        p: 1,
                        textAlign: "center",
                      }}
                    >
                      {renderCell(column, index)}
                    </TableCell>
                  ))}
                </TableRow>
              );
            })}
            {isEnableDelete && (
              <TableRow>
                <TableCell sx={{ p: 1, pt: 0, border: "none" }}>
                  <AddButton
                    onClick={handleAddNextAction}
                    ariaLabel="next_action_table"
                  />
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        {error && (
          <Typography
            sx={{ color: "#d32f2f", fontWeight: 400, fontSize: "0.75rem" }}
          >
            {t(error, { fieldName: "Next Action" })}
          </Typography>
        )}
        </TableContainer>
      </Paper>
      <ConfirmPopup {...confirmPopupState} />
    </Box>
  );
}
