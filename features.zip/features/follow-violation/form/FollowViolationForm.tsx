import { getAssignedPerson } from "@/apis/service/assignment/Assignment";
import {
  getDepartmentHeads,
  getLegalDepartments,
} from "@/apis/service/department/department";
import { getField, getFields } from "@/apis/service/field/Field";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { ModuleFields,  } from "@/constants/general";
import { ViolationStatusCode } from "@/constants/followViolation";
import { VALIDATION_MSG } from "@/constants/message";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FieldDTO } from "@/models/field/Field";
import { FileInfo } from "@/models/law_document/LawDocument";
import {
  castReminderInputToReminderSchema,
  castReminderSchemaToSaveReminderDTO,
} from "@/models/reminder_template/ReminderDTO";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser, UserProfileDTO } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Box,
  FormControlLabel,
  FormHelperText,
  Grid,
  Stack,
  Typography,
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { add } from "date-fns";
import {
  FC,
  ReactNode,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import * as Yup from "yup";
import AdviceList from "./AdviceList";
import { findDeepestId } from "@/utils";
import {
  FollowViolationDetail,
  FollowViolationFieldsName,
  FollowViolationRequest,
  ViolationNextActionResponse,
} from "@/models/follow_violation/FormType";
import { FollowVoilationSchema } from "@/models/follow_violation/schema";
import { getViolationStatusList } from "@/apis/service/follow_violation/followViolationAPI";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";
import moment from "moment";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";

export interface FollowViolationFormProps {
  formMode?: "create" | "update";
  initialValue?: FollowViolationDetail;
  onSubmit: (data: FollowViolationRequest) => void;
  onSubmitDraft?: (data: FollowViolationRequest) => void;
  onCancel: () => void;
  onDelete?: () => void;
  loading?: boolean;
  initialValueReceive?: FollowViolationDetail;
  nextActionData?: ViolationNextActionResponse;
  ownRole?: number[];
  children?: ReactNode;
}
const initialEmptyValue = {
  checkDeptHeadFlag: true,
  checkDivisionFlag: true,
  isApprovedByManager: false,
};

const FollowViolationForm: FC<FollowViolationFormProps> = (props) => {
  const { formMode = "create", ownRole = [], initialValueReceive } = props;
  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const [departmentId, setDepartmentId] = useState<string>("");
  // const currentRowStatus = FollowViolationStatusR.get(
  //   props.initialValueReceive?.status?.code as number
  // );


    const isDisable = !((appContext.meCanWrite && formMode === "create") ||
      (ownRole.includes(1) &&
        (initialValueReceive?.isDraft ||
          initialValueReceive?.status?.code ===
          ViolationStatusCode.ADDITIONAL_INFORMATION_ADDED )))

  const validateVendorDate = Yup.object().shape({
    [FollowViolationFieldsName.VENDOR_MUST_RESPONSE_DATE]: Yup.mixed().when(
      "status",
      {
        is: () => isRequestVendorAdvice,
        then: () =>
          Yup.date()
            .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
            .required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
  });

  const form = useForm({
    resolver: yupResolver(FollowVoilationSchema.concat(validateVendorDate)),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled:
      !appContext.meCanWrite ||
      isDisable,
  });

  // const disableSpecialFields = useMemo(() => {
  //   return (
  //     !appContext.meCanWrite ||
  //     (props.formMode === "update" &&
  //       !ownRole.length &&
  //       !ownRole.includes(1) &&
  //       !ownRole.includes(2) &&
  //       !ownRole.includes(3) &&
  //       !ownRole.includes(5) &&
  //       !ownRole.includes(6) &&
  //       !ownRole.includes(7)) ||
  //     !!props.loading
  //   );
  // }, [appContext.meCanWrite, props.formMode, ownRole, props.loading]);

  useEffect(() => {
    if (props.initialValueReceive) {
      if (props?.initialValueReceive?.attachments) {
        let attachments: any[] = [];
        const attachmentsSharepoint: any[] = [];

        if (props?.initialValueReceive?.attachments.length) {
          attachments = props.initialValueReceive.attachments?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setFiles([...attachments, ...attachmentsSharepoint]);
      }

      const files = isDisable
        ? props.initialValueReceive?.attachments
        : props.initialValueReceive?.attachments?.length
        ? props.initialValueReceive?.attachments
        : null;
      props.initialValueReceive &&
        form.reset({
          ...props.initialValueReceive,
          attachmentFileIds: files,
          fieldId: props.initialValueReceive?.field?.id,
          status: props.initialValueReceive?.status?.id,
          isApprovedByManager: props.initialValueReceive?.isApprovedByManager,
          receiverIds: props?.initialValueReceive?.receiverUsers?.map(
            (user: any) => ({
              ...user,
              department: user?.department,
            })
          ),
          relatedIds: props?.initialValueReceive?.relatedUsers?.map(
            (user: any) => ({
              ...user,
              department: user?.department,
            })
          ),
          responsibleUsers: props?.initialValueReceive?.responsibleUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          assignmentUsers: props?.initialValueReceive?.assignmentUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          departmentIds: props?.initialValueReceive?.departments?.map(
            (user: any) => ({
              ...user,
              department: user?.department,
            })
          ),
          vendorMustResponseDate: props?.initialValueReceive
            ?.vendorMustResponseDate
            ? moment.utc(props?.initialValueReceive?.vendorMustResponseDate).local().toDate()
            : undefined,
          answerDate: props?.initialValueReceive?.answerDate
            ? moment.utc(props?.initialValueReceive?.answerDate).local().toDate()
            : undefined,
          urgentReason:
            props?.initialValueReceive?.consultingDeadlineType === 2 &&
            props?.initialValueReceive?.urgentReason
              ? props?.initialValueReceive?.urgentReason
              : undefined,
          remind: props.initialValueReceive.remind?.title
            ? castReminderInputToReminderSchema(
                props.initialValueReceive!.remind!
              )
            : undefined,
        });
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValueReceive]);

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["follow-violation/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        setDepartmentId(deepestId?.id ?? "");
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const getAssignedPersonQuery = useQuery({
    queryKey: ["follow-violation/get-legal-assigned-person"],
    queryFn: () => getAssignedPerson(),
    placeholderData: (prev) => prev,
    enabled: false,
  });

  const getDepartmentHeadQuery = useQuery({
    queryKey: ["follow-violation/get-department-heads"],
    queryFn: () => getDepartmentHeads(departmentId),
    placeholderData: (prev) => prev,
    enabled: !!departmentId?.length,
  });

  const getStatusListQuery = useQuery({
    queryKey: ["follow-violation/get-status-list"],
    queryFn: async () => {
      const response = await getViolationStatusList({
        modules: [ModuleFields.VIOLATE_NAME.module],
        page: 0,
        size: 100,
        tab: 0,
        sortBy: StatusFieldNames.NAME,
        orderBy: "ASC",
        active: 1,
      });
      return response?.statusResponses || [];
    },
    placeholderData: (prev) => prev,
    enabled: true,
  });

  useEffect(() => {
    if (formMode === "create") {
      getAssignedPersonQuery.refetch().then((res) => {
        form?.setValue(
          FollowViolationFieldsName.RECEIVER_IDS,
          res.data?.users ?? []
        );
      });

      form?.setValue(FollowViolationFieldsName.RESPONSIBLE_USERS, appContext?.me ? [appContext?.me] : [])
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appContext?.me, form, formMode]);
  
  const deadlineType = form.watch(FollowViolationFieldsName.DEADLINE_TYPE);
  const status = form.watch(FollowViolationFieldsName.STATUS);
  const checkDeptHeadFlag = form.watch("checkDeptHeadFlag");
  const checkDivisionFlag = form.watch("checkDivisionFlag");
  const isApprovedByManager = form.watch("isApprovedByManager");

  const sendToError = !checkDeptHeadFlag && !checkDivisionFlag;
  const isRequestVendorAdvice =
    getStatusListQuery?.data
      ?.find((ele: StatusDTO) => ele.id === Number(status))
      ?.code === ViolationStatusCode.REQUEST_VENDOR_ADVISE;

    const showHead = useMemo(() => {
      const myId = appContext.me?.id;
      const deptHeadId = getDepartmentHeadQuery?.data?.deptHead?.id;
      const divHeadId = getDepartmentHeadQuery?.data?.division?.id;
      const picId = props.initialValueReceive?.createdBy?.id;
      let dept = false;
      let div = false;
      if (props.formMode === 'create') {
        dept = !!myId && !!deptHeadId && (deptHeadId !== myId);
        div = !!myId && !!divHeadId && (divHeadId !== myId);
      }
      if (props.formMode === 'update') {
        dept = !!picId && !!deptHeadId && (deptHeadId !== picId);
        div = !!picId && !!divHeadId && (divHeadId !== picId)
      }
      return {
        dept, div
      }
    }, [
      appContext.me?.id,
      getDepartmentHeadQuery?.data?.deptHead,
      getDepartmentHeadQuery?.data?.division,
      props.formMode,
      props.initialValueReceive?.createdBy
    ]);

  const watchLc = form.watch(FollowViolationFieldsName.RECEIVER_IDS);
  const watchPic = form.watch(FollowViolationFieldsName.RESPONSIBLE_USERS);

  const excludedPicIds = useMemo(() => {
    return (watchLc ?? []).map((item: BasedUser) => item.id)
  }, [watchLc])

  const excludedIds = useMemo(() => { // trường người tư vấn
    const list = [];
    const myId = appContext.me?.id;
    const createById = props.initialValueReceive?.createdBy?.id;
    const deptHeadId = getDepartmentHeadQuery?.data?.deptHead?.id;
    myId && list.push(myId);
    createById && list.push(createById);
    deptHeadId && list.push(deptHeadId);
    watchPic?.length && list.push(...((watchPic ?? []).map((item: BasedUser) => item.id)))
    return list;
  }, [appContext.me?.id, getDepartmentHeadQuery?.data?.deptHead?.id, props.initialValueReceive?.createdBy?.id, watchPic]);
    
  const handleSaveParams = async () => {
    let attachments: number[] = [];
    if (files.length > 0) {
      const filterFile: any = [];
      const filterFileId: number[] = [];

      files.filter((item: any) => {
        if (item?.id === undefined) {
          filterFile.push(item);
        } else {
          filterFileId.push(item?.id);
        }
      });
      if (filterFile.length > 0) {
        const response = await GetListIdFile(filterFile);
        const formatResponse: number[] = response.fileUploadResponses.map(
          (item: FileInfo) => item.fileId
        );
        attachments = [...formatResponse, ...filterFileId];
      } else {
        attachments = [...filterFileId];
      }
    }

    const receiverUsers = form.getValues("receiverIds");
    const relatedUsers = form.getValues("relatedIds");
    const responsibleUsers = form.getValues(FollowViolationFieldsName.RESPONSIBLE_USERS);
    const formValues = form.getValues();
    const params: FollowViolationRequest = {} as FollowViolationRequest;

    params.name = formValues.name;
    params.fieldId = Number(formValues.fieldId);
    params.attachmentFileIds = attachments;
    params.purpose = formValues.purpose;
    params.vendorMustResponseDate = formValues.vendorMustResponseDate
      ? formValues.vendorMustResponseDate?.toISOString()
      : undefined;
    params.summary = formValues.summary;
    params.researchOpinion = formValues.researchOpinion;
    params.consultingDeadlineType = formValues.consultingDeadlineType;
    params.answerDate = formValues.answerDate?.toISOString();

    if (formValues.consultingDeadlineType === 2) {
      params.urgentReason = formValues.urgentReason;
    }
    
    params.responsibleIds = responsibleUsers?.map((ite: any) => ite.id);
    params.receiverIds = receiverUsers?.map((ite: any) => ite.id);
    params.relatedIds = relatedUsers?.map((ite: any) => ite.id);

    params.remind =
      (formMode === "create" && !!form.getValues("remind")?.id) ||
      (formMode === "update" && form.getValues("remind") !== undefined)
        ? {
            ...castReminderSchemaToSaveReminderDTO(form.getValues("remind")!),
          }
        : {
            title: "",
            description: "",
            module: 4,
            receivedTitle: [],
            receivingDepartment: [],
            remindContents: [],
            relatedUsers: [],
          };

    if (
      !(typeof params.remind === "object" && Object.keys(params.remind).length)
    ) {
      params.remind = undefined;
    }

    params.isApprovedByManager = !!formValues.isApprovedByManager;
    params.isBookMeeting = !!formValues.isBookMeeting;
    params.isRequestVendorAdvice = isRequestVendorAdvice;
    params.checkDivisionFlag = !showHead.div ? false : formValues.checkDivisionFlag;
    params.checkDeptHeadFlag = !showHead.dept ? false : formValues.checkDeptHeadFlag;

    return params;
  };

  return (
    <>
      <Grid
        container
        className="form-wrapper"
        style={{ marginTop: props.formMode === "update" ? 24 : 0 }}
      >
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}
                sx={{
                  display:
                    formMode === "create"
                      ? "initial"
                      : "none",
                }}
              >
                <FormTextField
                  control={form.control}
                  name={FollowViolationFieldsName.NAME}
                  label={t(`followViolation.label.name`)}
                  placeHolder={t(`followViolation.placeholder.name`)}
                  required
                  disabled={!appContext.meCanWrite || isDisable}
                  inputProps={{ maxLength: 255 }}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormControlLabel
                  name="isApprovedByManager"
                  sx={{px: 1.5}}
                  control={
                    <CheckboxInput
                    
                    borderColor={
                      !appContext.meCanWrite || isDisable
                        ? COLOR_TYPE.TOYOTA.TOYOTA5
                        : COLOR_TYPE.TOYOTA.TOYOTA1
                    }
                      checked={isApprovedByManager}
                      disabled={isDisable}
                      onChange={(val) => {
                        form.setValue("isApprovedByManager", val);
                      }}
                    />
                  }
                  disabled={!appContext.meCanWrite || isDisable}
                  label={<Box sx={{pl: 1.5}}>{t("followViolation.label.approvedByManager")}</Box>}
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={formMode === "create"}
                  preview={formMode === "update"}
                  name={FollowViolationFieldsName.ATTACHMENT_FILE_IDS}
                  control={form.control}
                  disabled={isDisable}
                  files={files}
                  setFiles={(files) => {
                    setFiles(files);
                    form.setValue(FollowViolationFieldsName.ATTACHMENT_FILE_IDS, files ?? []);
                    form.trigger(FollowViolationFieldsName.ATTACHMENT_FILE_IDS)
                  }}
                  title={t(`followViolation.label.attachments`)}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={FollowViolationFieldsName.FIELD_ID}
                  label={t(`followViolation.label.field`)}
                  placeholder={t(`followViolation.placeholder.field`)}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"field-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getFields({
                        name: keyword,
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                      });

                      return response?.fieldResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getField(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as FieldDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled={!appContext.meCanWrite || isDisable}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FollowViolationFieldsName.PURPOSE}
                  label={t(`followViolation.label.purpose`)}
                  placeHolder={t(`followViolation.placeholder.purpose`)}
                  required
                  minRows={3}
                  disabled={!appContext.meCanWrite || isDisable}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FollowViolationFieldsName.SUMMARY_ISSUE}
                  label={t(`followViolation.label.summaryIssue`)}
                  placeHolder={t(`followViolation.placeholder.summaryIssue`)}
                  required
                  minRows={3}
                  disabled={!appContext.meCanWrite || isDisable}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FollowViolationFieldsName.PROBLEM}
                  label={t(`followViolation.label.problem`)}
                  placeHolder={t(`followViolation.label.problem`)}
                  minRows={3}
                  disabled={!appContext.meCanWrite || isDisable}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FollowViolationFieldsName.RESEARCH_OPINION}
                  label={t(`followViolation.label.researchOpinion`)}
                  placeHolder={t(`followViolation.placeholder.researchOpinion`)}
                  minRows={3}
                  disabled={!appContext.meCanWrite || isDisable}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormSelect
                  control={form.control}
                  required
                  name={FollowViolationFieldsName.DEADLINE_TYPE}
                  label={t(
                    `followViolation.label.${FollowViolationFieldsName.DEADLINE_TYPE}`
                  )}
                  placeHolder={t(
                    `followViolation.placeholder.${FollowViolationFieldsName.DEADLINE_TYPE}`
                  )}
                  options={[
                    {
                      value: 1,
                      label: t("followViolation.label.SOP"),
                    },
                    {
                      value: 2,
                      label: "Urgent",
                    },
                  ]}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  onChange={(event) => {
                    const value = event.target.value;
                    form.setValue(
                      FollowViolationFieldsName.ANSWER_DATE,
                      value === 1 ? add(new Date(), { days: 5 }) : new Date()
                    );
                    form.setValue(
                      FollowViolationFieldsName.URGENT_REASON,
                      value === 1 ? undefined : ""
                    );
                  }}
                />
              </Grid>

              {/* chỉ hiện khi trạng thái là Yêu cầu vendor tư vấn */}
              {isRequestVendorAdvice && (
                <Grid item width={"100%"}>
                  <DateInput
                    name={FollowViolationFieldsName.VENDOR_MUST_RESPONSE_DATE}
                    control={form.control}
                    label={t(`followViolation.label.vendorMustResponseDate`)}
                    placeholder={"DD/MM/YYYY"}
                    required
                    disabled={!appContext.meCanWrite || isDisable}
                  />
                </Grid>
              )}

              {deadlineType === 1 && (
                <Grid item width={"100%"}>
                  <DateTimeInput
                    control={form.control}
                    name={FollowViolationFieldsName.ANSWER_DATE}
                    required
                    label={t(`followViolation.label.answerDate`)}
                    disabled={!appContext.meCanWrite || isDisable}
                  />
                </Grid>
              )}
              {deadlineType === 2 && (
                <>
                  <Grid item width={"100%"}>
                    <DateTimeInput
                      control={form.control}
                      name={FollowViolationFieldsName.ANSWER_DATE}
                      label={t(`followViolation.label.urgentDate`)}
                      required
                      disabled={!appContext.meCanWrite || isDisable}
                    />
                  </Grid>
                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={FollowViolationFieldsName.URGENT_REASON}
                      label={t(`followViolation.label.urgentReason`)}
                      placeHolder={t(`followViolation.label.urgentReason`)}
                      required
                      minRows={3}
                      disabled={!appContext.meCanWrite || isDisable}
                    />
                  </Grid>
                </>
              )}
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={FollowViolationFieldsName.RESPONSIBLE_USERS}
                  label={t(
                    `followViolation.fields.${FollowViolationFieldsName.RESPONSIBLE_USERS}`
                  )}
                  placeholder={t(
                    `followViolation.fields.${FollowViolationFieldsName.RESPONSIBLE_USERS}`
                  )}
                  minCharLength={1}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });
                    return response?.users?.filter((user) => !excludedPicIds?.includes(user.id)) ?? [];
                    ;
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  required
                  getOptionKey={(option) => option.id}
                  keyQuery="legal-advice-pics"
                  isFocus
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={FollowViolationFieldsName.RECEIVER_IDS}
                  label={t(`followViolation.label.advisor`)}
                  placeholder={t(`followViolation.label.advisor`)}
                  minCharLength={1}
                  getOptions={async (keyword) => {
                    if (!getLegalDepartmentQuery.data) return [];
                    const advisorIds =
                      getAssignedPersonQuery?.data?.users?.map(
                        (user) => user.id
                      ) ?? [];
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                      departmentIds: getLegalDepartmentQuery.data
                        ? [getLegalDepartmentQuery.data]
                        : [],
                    });
                    const list = response?.users
                    ?.map((user, index) => ({
                      ...user,
                      rank: advisorIds?.includes(user.id) ? index : 99999,
                    }))
                    ?.sort((first, second) => first.rank - second.rank) ?? [];

                    return list.filter(item => !excludedIds?.includes(item?.id));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  required
                  getOptionKey={(option) => option.id}
                  keyQuery="queryAdvisor"
                  isFocus
                />
              </Grid>
              <Stack direction={'row'} width={"100%"} mt={0.5} gap={2}>
                <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA1, fontStyle: 'italic' }} >{t(`followViolation.label.requiredToBeSentTo`)}*:</Typography>
                <Stack gap={"1rem"}>
                  {showHead?.dept ? <CheckboxInput
                    fontSize={'1rem'}
                    checked={form.watch("checkDeptHeadFlag")}
                    borderColor={!appContext.meCanWrite || isDisable ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                    checkboxBg={!appContext.meCanWrite || isDisable ? COLOR_TYPE.TOYOTA.TOYOTA6 : 'white'}
                    onChange={(value) => {
                      form.setValue(
                        "checkDeptHeadFlag",
                        value
                      );
                    }}
                    label={
                      getDepartmentHeadQuery?.data?.deptHead
                        ? `${getDepartmentHeadQuery?.data?.deptHead?.name} - Dept Head.${getDepartmentHeadQuery?.data?.deptHead?.department?.name}`
                        : t(
                          "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                        )
                    }
                    disabled={!appContext.meCanWrite || isDisable || !showHead?.div}
                  /> : null}
                  {showHead?.div ? <CheckboxInput
                    fontSize={'1rem'}
                    checked={form.watch("checkDivisionFlag")}
                    borderColor={!appContext.meCanWrite || isDisable ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                    checkboxBg={!appContext.meCanWrite || isDisable ? COLOR_TYPE.TOYOTA.TOYOTA6 : 'white'}
                    onChange={(value) => {
                      form.setValue(
                        "checkDivisionFlag",
                        value
                      );
                    }}
                    label={
                      getDepartmentHeadQuery?.data?.division
                        ? `${getDepartmentHeadQuery?.data?.division?.name} - Division Head.${getDepartmentHeadQuery?.data?.division?.department?.name}`
                        : t(
                          "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                        )
                    }
                    disabled={!appContext.meCanWrite || isDisable || !showHead?.dept}
                  /> : null}
                  {sendToError ? (
                    <FormHelperText error>
                      {t("followViolation.messages.requiredToBeSentTo")}
                    </FormHelperText>
                  ) : null}
                </Stack>
              </Stack>
              {props?.initialValueReceive?.assignmentUsers?.length && <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={FollowViolationFieldsName.ASSIGNMENT_USERS}
                  label={t(
                    `followViolation.fields.${FollowViolationFieldsName.ASSIGNMENT_USERS}`
                  )}
                  placeholder={t(
                    `followViolation.fields.${FollowViolationFieldsName.ASSIGNMENT_USERS}`
                  )}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });

                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="legal-advice-assigners"
                  disabled
                />
              </Grid>}
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={FollowViolationFieldsName.RELATED_IDS}
                  label={t(`followViolation.placeholder.relatedIds`)}
                  placeholder={t(`followViolation.placeholder.relatedIds`)}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });

                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryRelatedUser"
                  disabled={!appContext.meCanWrite || isDisable}
                />
              </Grid>

              {formMode === "update" && props?.initialValueReceive?.id && (
                <Grid item width={"100%"}>
                  <AdviceList
                    violationId={props?.initialValueReceive?.id}
                    initialFollowViolation={props?.initialValueReceive}
                  />
                </Grid>
              )}
            </Grid>
            <ReminderPickerSubForm
              name={"remind"}
              module={ModuleFields.VIOLATE_NAME.module}
              placeholder={t("menu.reminder")}
            />

            <FormActionButtons
              formMode={props.formMode}
              loading={props.loading}
              onCancel={props.onCancel} 
              isDisableButonSave={isDisable}
              allowDraft={
                props.formMode === "create" ||
                !!props.initialValueReceive?.isDraft
              }
              onSaveDraft={async () => {
                try {
                  const params = await handleSaveParams();
                  params.isDraft = true;
                  if (props.formMode === "create") {
                    props?.onSubmitDraft?.(params);
                  } else {
                    props?.onSubmit?.(params);
                  }
                } catch (error) {}
              }}
              onSave={async () => {
                try {
                  const params = await handleSaveParams();
                  params.isDraft = false;
                  props?.onSubmit?.(params);
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </>
  );
};

export default FollowViolationForm;
