import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";
import { COLOR_TYPE } from "@/constants/color";
import useObserveElementSize from "@/hooks/useObserveElementSize";
import { FollowViolationDetail } from "@/models/follow_violation/FormType";
import { Box } from "@mui/material";
import { FC, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

interface ViolationInformationProps {
  initialValueReceive?: FollowViolationDetail;
  handleUpdateBookMeeting: (params: any) => void;
  isMeeting?: boolean;
  disabled: boolean;
  scrollToTab: (tab: number) => void;
}
const ViolationInformation: FC<ViolationInformationProps> = (props) => {
  const [t] = useTranslation();
  const [isBooked, setIsBooked] = useState(false);

  const { elementRef, size } = useObserveElementSize();
  const responsiveSx = {};

  useEffect(() => {
    if (props.initialValueReceive) {
      setIsBooked(!!props?.initialValueReceive?.isBookMeeting);
    }
  }, [props.initialValueReceive]);

  return (
    <Box
      ref={elementRef}
      sx={{
        display: size.width <= 580 ? "grid" : "flex",
        p: 2,
        backgroundColor: "white",
        mb: 2,
        flexFlow: "wrap",
        overflow: "hidden",
        columnGap: 10,
        rowGap: 2
      }}
    >
      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          labelColor={COLOR_TYPE.BLUE.BLUE6}
          checked={isBooked}
          // onChange={(e) => props?.onChangeMeeting(e)}
          disabled
          onLabelClick={() => props?.scrollToTab(8)}
          label={`${t("LEGISLATION.evaluateField.meeting")}
          ${(props.initialValueReceive?.totalBookMeeting ?? 0) > 0
              ? ` (${props.initialValueReceive?.totalBookMeeting})`
              : ""
            }`}
        />
      </Box>

      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.isVerifiedConsulting}
          disabled
          label={t("followViolation.label.adviceConfirm")}
        />
      </Box>
      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.isCompletedConsulting}
          disabled
          label={`${t("followViolation.label.adviceCompleted")}
          ${(props.initialValueReceive?.totalUserAdvice ?? 0) > 0
              ? ` (${props.initialValueReceive?.currentUserAdvice ?? 0}/${props.initialValueReceive?.totalUserAdvice ?? 0})`
              : ""
            }`}
        />
      </Box>
      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.isSupervisorConsulting}
          disabled
          label={`${t("followViolation.label.supervisorAdvised")}
          ${(props.initialValueReceive?.totalSupervisorAdvice ?? 0) > 0
              ? ` (${props.initialValueReceive?.currentSupervisorAdvice ?? 0}/${props.initialValueReceive?.totalSupervisorAdvice ?? 0})`
              : ""
            }`}
        />
      </Box>

      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          disabled
          checked={!!props.initialValueReceive?.isNextActionReport}
          label={t("followViolation.label.reportAndNextAction")}
        />
      </Box>
    </Box>
  );
};

export default ViolationInformation;
