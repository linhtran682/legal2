import { GLOBAL_SPACING } from "@/constants/format";
import { Box } from "@mui/material";
import { FC, useContext, useState } from "react";
import AdviceListItem from "./AdviceListItem";
import { useQuery } from "@tanstack/react-query";
import { getViolationAdviseList } from "@/apis/service/follow_violation/followViolationAPI";
import { ViolationAdvise } from "@/models/follow_violation/FormType";
import { AdviceFollowViolationForm } from "../components/advice_follow_violation_form/AdviceFollowViolationForm";
import { AppContext } from "@/context/AppContext";
import {
  FollowViolationStatusKey,
  FollowViolationStatusR,
} from "@/constants/followViolation";

interface AdviceListProps {
  violationId: number;
  initialFollowViolation?: any;
  handleReloadFollowViolationQuery?: () => void;
}

const AdviceList: FC<AdviceListProps> = (props) => {
  const appContext = useContext(AppContext);
  const { violationId, initialFollowViolation } = props;
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedAdvise, setSelectedAdvise] = useState<
    ViolationAdvise | undefined
  >(undefined);

  const getAdviseListQuery = useQuery({
    queryKey: ["get-violation-advise-list", violationId],
    queryFn: () => getViolationAdviseList(violationId),
    enabled: !!violationId,
  });

  const handleEditClick = (advise: ViolationAdvise) => {
    setSelectedAdvise(advise);
    setPopupVisible(true);
  };

  const onPopupClose = () => {
    setPopupVisible(false);
    setSelectedAdvise(undefined);
    getAdviseListQuery?.refetch();
    props?.handleReloadFollowViolationQuery &&
      props.handleReloadFollowViolationQuery();
  };

  const checkEditAvailable = (
    advise: ViolationAdvise,
    initialFollowViolation: any
  ) => {
    const isMine = advise?.createBy?.id === appContext?.me?.id;
    const currentRowStatus = FollowViolationStatusR.get(
      initialFollowViolation?.status?.code as number
    );

    return isMine && currentRowStatus !== FollowViolationStatusKey.FINISH;
  };

  return (
    <>
      {getAdviseListQuery?.data?.length ? (
        <Box display={"flex"} flexDirection={"column"} gap={GLOBAL_SPACING}>
          {(getAdviseListQuery?.data ?? [])?.map((advise: ViolationAdvise) => (
            <AdviceListItem
              key={advise.id.toString()}
              editAvailable={checkEditAvailable(advise, initialFollowViolation)}
              onEditClick={() => handleEditClick(advise)}
              advise={advise}
            />
          ))}
        </Box>
      ) : null}

      {popupVisible && (
        <AdviceFollowViolationForm
          setIsOpen={onPopupClose}
          isOpen={popupVisible}
          violationId={initialFollowViolation?.id}
          advise={selectedAdvise}
          name={initialFollowViolation?.name}
          sender={appContext?.me}
          createBy={initialFollowViolation?.createdBy}
          isAdvice={!selectedAdvise?.isSupervisor}
          isSuperviorAdvisor={selectedAdvise?.isSupervisor}
        />
      )}
    </>
  );
};

export default AdviceList;
