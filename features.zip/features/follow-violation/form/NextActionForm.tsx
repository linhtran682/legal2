import {
  createViolationNextAction,
  updateViolationNextAction,
} from "@/apis/service/follow_violation/followViolationAPI";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import {
  NextActionDTO,
  NextActionFieldsName,
  ViolationNextActionRequest,
  ViolationNextActionResponse,
} from "@/models/follow_violation/FormType";
import { VoilationNextActionSchema } from "@/models/follow_violation/schema";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, Typography } from "@mui/material";
import React, { useContext, useEffect, useMemo, useRef, useState } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { AppContext } from "@/context/AppContext";
import { useTranslation } from "react-i18next";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { useRouter } from "next/router";
import { NextActionTableForm } from "./NextActionTableForm";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { FileInfo } from "@/models/law_document/LawDocument";
import {
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { SearchPanelQueries } from "../components/SearchPanel";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";

type Props = {
  formMode?: "create" | "update";
  ownRole: number[];
  onCancel: () => void;
  cancelConfirm?: boolean;
  onDelete?: () => void;
  nextActionData?: ViolationNextActionResponse;
  // onSave: (data: any) => void;
};
function NextActionForm({
  onCancel,
  nextActionData,
  ownRole = [],
}: // onSave,

Props) {
  const formRef = useRef<HTMLFormElement>(null);
  const [nextActionFiles, setNextActionFiles] = useState<any>([]);
  const { t } = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const appContext = useContext(AppContext);
  const isCreate = !nextActionData?.name;
  const formMode = nextActionData?.name ? "update" : "create";
  const queryClient = useQueryClient();
  const [defaultConfirmPopupState, setDefaultConfirmPopupState] =
    useState<ConfirmPopupProps>();
  const width = screen.availWidth;
  const defaultWidth = width - 700;
  const [dimensions, setDimensions] = useState(defaultWidth);

  const form = useForm({
    resolver: yupResolver(VoilationNextActionSchema),
    mode: "onBlur",
    disabled:
      !appContext.meCanWrite || (formMode === "update" && !ownRole.includes(1)),
  });

  useEffect(() => {
    const observeTarget = formRef.current;
    if (!observeTarget) return;

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setDimensions((pre) =>
          pre > entry.contentRect.width ? defaultWidth : entry.contentRect.width
        );
      }
    });

    observer.observe(formRef.current);

    // Cleanup function
    return () => {
      observer.disconnect();
    };
  }, [defaultWidth]);

  const loading = false;

  const updateNextAction = useMutation({
    mutationFn: updateViolationNextAction,
  });

  const createNextAction = useMutation({
    mutationFn: createViolationNextAction,
    onSuccess: () => {
      setDefaultConfirmPopupState({ ...DefaultConfirmPopupState });
      queryClient.invalidateQueries({
        queryKey: ["get_violation_next_action_query"],
      });
      queryClient.invalidateQueries({
        queryKey: ["get_initial_violation_query"],
      });
    },
  });

  const disableSpecialFields = useMemo(() => {
    return (
      !appContext.meCanWrite ||
      (formMode === "update" &&
        !ownRole.length &&
        !ownRole.includes(1)) ||
      !!loading
    );
  }, [appContext.meCanWrite, formMode, ownRole, loading]);

  useEffect(() => {
    if (nextActionData && nextActionData?.name) {
      const { name, deadline, nextActionItems } = nextActionData;
      const fileIData = nextActionData.files;
      if (fileIData) {
        let attachments: any[] = [];
        const attachmentsSharepoint: any[] = [];

        if (fileIData.length) {
          attachments = fileIData?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setNextActionFiles([...attachments, ...attachmentsSharepoint]);
      }

      const files = disableSpecialFields
        ? fileIData
        : fileIData?.length
        ? fileIData
        : null;
      form.reset({
        name,
        deadline: deadline ? new Date(deadline) : undefined,
        fileIds: files as any,
        nextActions: nextActionItems?.map((action) => ({
          category: action.category,
          complianceAssessment: action.complianceAssessment,
          currentStatusTMV: action.currentStatusTMV,
          deadline: action.deadline ? new Date(action.deadline) : undefined,
          legalRequirements: action.legalRequirements,
          nextActionId: action.nextActionId,
          receiverIds: action.receivers,
          workNeed: action.workNeed,
          deptHeadApproved: action.deptHeadApproved,
          groupHeadApproved: action.groupHeadApproved,
          topHeadApproved: action.topHeadApproved,
        })),
      });
    }
  }, [disableSpecialFields, form, nextActionData]);

  const handleSubmit = async (
    actionMessage = "",
    deleteItems: number[] = []
  ) => {
    const formValues = form.getValues();
    let attachments: number[] = [];

    if (nextActionFiles.length > 0) {
      const filterFile: any = [];
      const filterFileId: number[] = [];

      nextActionFiles.filter((item: any) => {
        if (item?.id === undefined) {
          filterFile.push(item);
        } else {
          filterFileId.push(item?.id);
        }
      });
      if (filterFile.length > 0) {
        const response = await GetListIdFile(filterFile);
        const formatResponse: number[] = response.fileUploadResponses.map(
          (item: FileInfo) => item.fileId
        );
        attachments = [...formatResponse, ...filterFileId];
      } else {
        attachments = [...filterFileId];
      }
    }
    const params: ViolationNextActionRequest = {} as ViolationNextActionRequest;
    params.name = formValues.name;
    params.deadline = formValues.deadline?.toISOString() ?? "";
    params.fileIds = attachments;

    let nextActions: NextActionDTO[] = (formValues.nextActions ?? []).map(
      (item, index) =>
        ({
          ...item,
          deadline: item.deadline?.toISOString(),
          receiverIds: item?.receiverIds?.map((ite: any) => ite.id),
          position: index + 1,
        } as NextActionDTO)
    );
    if (deleteItems.length > 0) {
      nextActions = nextActions.filter(
        (_, index) => !deleteItems.includes(index)
      );
    }
    params.nextActions = nextActions;
    const violationId = typeof id == "string" ? Number(id) : Number(id?.[0]);
    if (isCreate) {
      const res = await createNextAction.mutateAsync({
        request: { ...params },
        violationId,
      });

      if (res) {
        toast.success(
          t("common.message.create_success", {
            recordName: t("followViolation.tabs.nextAction"),
          })
        );
      }
      setDefaultConfirmPopupState({ ...DefaultConfirmPopupState });
      queryClient.invalidateQueries({
        queryKey: ["get_violation_next_action_query"],
      });

      queryClient.invalidateQueries({
        queryKey: ["get_initial_violation_query"],
      });
      queryClient.invalidateQueries({
        queryKey: [SearchPanelQueries.GET_HIERARCHY],
      });
      return;
    }

    const res = await updateNextAction.mutateAsync({
      request: { ...params },
      violationId,
    });

    if (res) {
      toast.success(
        t(actionMessage || "common.message.update_success", {
          recordName: t("followViolation.tabs.nextAction"),
        })
      );

      setDefaultConfirmPopupState({ ...DefaultConfirmPopupState });
      queryClient.invalidateQueries({
        queryKey: ["get_violation_next_action_query"],
      });

      queryClient.invalidateQueries({
        queryKey: ["get_initial_violation_query"],
      });
      queryClient.invalidateQueries({
        queryKey: [SearchPanelQueries.GET_HIERARCHY],
      });
    }
  };

  return (
    <FormProvider {...form}>
      <form ref={formRef}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className="form-section-wrapper"
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <label style={{ display: "flex" }}>
              {t(`followViolation.forwardLegalAdvice.title.sender`)}
            </label>
          <Typography>
            {nextActionData?.createBy.name} ({nextActionData?.createBy.email}) -{" "}
            {nextActionData?.createBy.departmentName}
          </Typography>
            
          </Grid>
          <Grid item width={"100%"}>
            <DropPreviewFileUploadComponent
              dropView={formMode === "create"}
              preview={formMode === "update"}
              name={NextActionFieldsName.FILE_IDS}
              control={form.control}
              disabled={disableSpecialFields}
              files={nextActionFiles}
              setFiles={setNextActionFiles}
              inputId="next-action-input"
              title={t(`followViolation.label.attachments`)}
              required
            />
          </Grid>
          <Grid item width={"100%"}>
            <FormTextField
              control={form.control}
              name={NextActionFieldsName.NAME}
              label={t(`followViolation.nextAction.nextActionName`)}
              placeHolder={t(`followViolation.nextAction.nextActionName`)}
              required
              disabled={disableSpecialFields}
            />
          </Grid>
          <Grid item width={"100%"}>
            <DateInput
              name={NextActionFieldsName.DEADLINE}
              control={form.control}
              label={t(`followViolation.label.vendorMustResponseDate`)}
              placeholder={"DD/MM/YYYY"}
              required
              disabled={disableSpecialFields}
            />
          </Grid>
          <NextActionTableForm
            form={form}
            formMode={formMode}
            dimensions={dimensions}
            ownRole={ownRole}
            nextActionData={nextActionData}
            isDisable={!!disableSpecialFields}
            error={form.formState.errors?.nextActions?.message}
            isCreate={isCreate}
            onDeleteItems={async (deleteItems: number[]) => {
              try {
                handleSubmit("common.message.delete_success", deleteItems);
              } catch (error) {}
            }}
          />
        </Grid>
        <FormActionButtons
          formMode={formMode}
          loading={loading}
          onCancel={onCancel}
          allowDraft={false}
          isDisableButonSave={
            !appContext.meCanWrite ||
            (formMode === "update" && !ownRole.includes(1))
          }
          defaultConfirmPopupState={defaultConfirmPopupState}
          onSave={async () => {
            try {
              handleSubmit();
            } catch (error) {}
          }}
        />
      </form>
    </FormProvider>
  );
}

export default NextActionForm;
