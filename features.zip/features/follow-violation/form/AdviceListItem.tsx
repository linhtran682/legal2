import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { ViolationAdvise } from "@/models/follow_violation/FormType";
import { LegalAdviceDetailFields } from "@/models/legal-advice/LegalAdviceDetail";
import { Box, Grid, IconButton, InputLabel, Typography } from "@mui/material";
import EditNoteRoundedIcon from "@mui/icons-material/EditNoteRounded";
import { FC, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";

interface AdviceListItemProps {
  advise: ViolationAdvise;
  editAvailable?: boolean;
  onEditClick?: () => void;
}
const AdviceListItem: FC<AdviceListItemProps> = (props) => {
  const { advise, editAvailable, onEditClick } = props;
  const form = useForm();
  const [t] = useTranslation();
  const [files, setFiles] = useState<any>([]);

  const resetForm = (newAdvise: ViolationAdvise) => {
    if (newAdvise?.attachments?.length) {
      setFiles(
        newAdvise.attachments?.map((item) => {
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        })
      );
    }
    form?.reset?.({
      advisor: newAdvise.createBy.id,
      content: newAdvise.content,
    });
  };

  useEffect(() => {
    resetForm(advise);
  }, [advise]);

  return (
    <Grid
      container
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
      sx={{
        backgroundColor: advise.isSupervisor
          ? COLOR_TYPE.BLUE.BLUE06
          : undefined,
      }}
    >
      <Grid item xs={12} display={"flex"}>
        <Box flex={1}>
          <InputLabel required>
            {advise.isSupervisor
              ? t(
                  `legalAdvice.fields.${LegalAdviceDetailFields.SUPERVISOR_ADVISOR}`
                )
              : t(`legalAdvice.fields.${LegalAdviceDetailFields.ADVISOR}`)}
          </InputLabel>
          <Typography>
            {advise.createBy.name} ({advise.createBy.email}) -{" "}
            {advise.createBy.department?.name}
          </Typography>
        </Box>
        {editAvailable && (
          <IconButton onClick={onEditClick} sx={{ height: "fit-content" }}>
            <EditNoteRoundedIcon />
          </IconButton>
        )}
      </Grid>

      <Grid item width={"100%"}>
        <FormTextArea
          control={form.control}
          name={LegalAdviceDetailFields.CONTENT}
          label={t(`legalAdvice.fields.${LegalAdviceDetailFields.CONTENT}`)}
          placeHolder={t(
            `legalAdvice.fields.${LegalAdviceDetailFields.CONTENT}`
          )}
          required
          minRows={2}
          disabled
        />
      </Grid>

      {Array.isArray(files) && files.length > 0 && (
        <Grid item width={"100%"}>
          <DropPreviewFileUploadComponent
            title={t(
              `legalAdvice.label.${LegalAdviceDetailFields.ATTACHMENTS}`
            )}
            files={files}
            setFiles={setFiles}
            preview
            disabled
            inputId={`file-input-${advise?.id}`}
          />
        </Grid>
      )}
    </Grid>
  );
};

export default AdviceListItem;
