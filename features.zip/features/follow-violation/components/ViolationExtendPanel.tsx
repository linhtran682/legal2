import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { Button } from "@mui/material";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import { FollowViolationDetail, ViolationExtension } from "@/models/follow_violation/FormType";
import { TimeExtensionFollowViolationForm } from "./time_extension_follow_violation_form/TimeExtensionFollowViolationForm";
import { AppContext } from "@/context/AppContext";

export interface violationExtendPanelProps {
  queryKey: string;
  getExtendRecords: () => Promise<ViolationExtension[]>;
  violationId?: number;
  violation?: FollowViolationDetail;
}

export const ViolationExtendPanel = ({ violation, violationId, queryKey, getExtendRecords }: violationExtendPanelProps) => {
  const { i18n, t } = useTranslation();
  const queryClient = useQueryClient();
  const appContext = useContext(AppContext);
  const [extendDeadline, setExtendDeadline] = useState<ViolationExtension>();
  const [isOpenTimeExtension, setIsOpenTimeExtension] =
    useState<boolean>(false);
  const getExtendRecordsQuery = useQuery({
    queryKey: [queryKey],
    queryFn: () => getExtendRecords(),
  });
  const handleClickExtend = (params: ViolationExtension) => {
    setIsOpenTimeExtension(true);
    setExtendDeadline(params);
  };

  const ExtendTableColumns: StandardSimpleTableColumn<ViolationExtension>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +(params?.id) + 1,
    },
    {
      key: "department",
      label: "metadata.extend.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.extend.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "reason",
      label: "timeExtension.title.reason",
      type: "string",
      flex: 1,
    },
    {
      key: "requestDeadline",
      label: "followViolation.tabs.requestDeadline",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row.requestDeadline ? format(new Date(params.row.requestDeadline), 'dd/MM/yyyy hh:mm') : ''
    },
    {
      key: "acceptDeadline",
      label: "followViolation.tabs.acceptDeadline",
      type: "date",
      flex: 1,
      renderCell: (params) => params.row.acceptDeadline ? format(new Date(params.row.acceptDeadline), 'dd/MM/yyyy hh:mm') : ''
    },
    {
      key: "status",
      label: "metadata.extend.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row.type ? t(`followViolation.extendType.${params.row.type}`) : ''
    },
    {
      key: "actionType",
      label: "Action",
      type: "string",
      flex: 1,
      renderCell: (params) => {
        return params.row?.showExtension ? (
          <Button disabled={!params.row?.enableExtension} onClick={() => handleClickExtend(params?.row)}>
            {t("followViolation.action.extend")}</Button>
        ) : (
          <></>
        );
      },
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={ExtendTableColumns}
        data={getExtendRecordsQuery?.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
      {(isOpenTimeExtension && extendDeadline && violationId && violation?.name) && (
        <TimeExtensionFollowViolationForm
          setIsOpen={(state) => setIsOpenTimeExtension(state)}
          violationId={violationId}
          initialValue={{}}
          isOpen={isOpenTimeExtension}
          timeExtensionRequest={extendDeadline}
          name={violation?.name}
          sender={appContext?.me}
          isConfirmExtension
          handleSubmit={async () =>
            await queryClient.invalidateQueries(queryKey as any)
          }
        />
      )}
    </div>
  );
};
