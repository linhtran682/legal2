import moment from "moment";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import {
  RequestVendorFvFieldNames,
  RequestVendorFvSchema,
  RequestVendorFvSchemaI,
} from "@/models/follow_violation/RequestVendorFollowViolation";
import { useCreateRequestVendorFv } from "@/apis/service/follow_violation/requestVendorFollowViolation";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";

const initialEmptyValue: RequestVendorFvSchemaI = {
  [RequestVendorFvFieldNames.DEADLINE]: "",
  [RequestVendorFvFieldNames.USERS]: [],
  [RequestVendorFvFieldNames.REMIND]: undefined,
};

export interface RequestVendorFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: RequestVendorFvSchemaI;
  violationId?: number;
  violation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  maxDateReturnAdvice?: Date | undefined;
  sender?: any;
  createBy?: any;
}

export const RequestVendorFollowViolationForm = (
  props: RequestVendorFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.requestVendor.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    violation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.ADVISE),
    maxDateReturnAdvice = undefined,
    sender,
    createBy,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(RequestVendorFvSchema),
    defaultValues: initialValue,
  });

  /**
   * Set values to form
   */
  useEffect(() => {
    if (!violation || !sender || !createBy) {
      return;
    }

    const newUsers = [sender, createBy].reduce((acc: any, cur: any) => {
      if (!acc.some((a: any) => a?.id === cur?.id)) {
        acc.push(cur);
      }
      return acc;
    }, []);

    form.reset({
      [RequestVendorFvFieldNames.DEADLINE]: violation?.vendorMustResponseDate
        ? moment.utc(violation?.vendorMustResponseDate).local().toDate()
        : undefined,
      [RequestVendorFvFieldNames.USERS]: newUsers,
    });
  }, [form, violation, sender, createBy]);

  const { mutateAsync: createRequestVendorFv, isPending } =
    useCreateRequestVendorFv({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { user, ...restData } = data;

    await createRequestVendorFv({
      violationId,
      data: { ...restData },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.requestVendor.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`followViolation.requestVendor.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={RequestVendorFvFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`followViolation.requestVendor.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  required
                  maxDate={maxDateReturnAdvice}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={RequestVendorFvFieldNames.USERS}
                  label={t("followViolation.requestVendor.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"requestVendor/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={RequestVendorFvFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    userIds: form
                      .getValues()
                      .userIds?.map((user: any) => user?.id),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
