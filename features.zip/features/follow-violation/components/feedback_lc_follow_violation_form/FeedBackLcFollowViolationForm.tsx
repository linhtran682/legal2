import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { castFeedBackFollowViolationRequestSchemaToDTO } from "@/models/follow_violation/FeedBackFollowViolation";
import { useCreateFeedBackLcFollowViolation } from "@/apis/service/follow_violation/feedbackLcFollowViolation";
import {
  FeedBackLcFollowViolationRequestFieldNames,
  RequestFeedBackLcFollowViolationSchema,
  RequestFeedBackLcFollowViolationSchemaI,
} from "@/models/follow_violation/FeedBackLcFollowViolation";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";

const initialEmptyValue: RequestFeedBackLcFollowViolationSchemaI = {
  [FeedBackLcFollowViolationRequestFieldNames.CONTENT]: "",
  [FeedBackLcFollowViolationRequestFieldNames.USERS]: [],
  [FeedBackLcFollowViolationRequestFieldNames.REMIND]: undefined,
};

export interface FeedBackLcFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: RequestFeedBackLcFollowViolationSchemaI;
  violationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  receiverUsers?: any[];
  module?: number;
  sender?: any;
}

export const FeedBackLcFollowViolationForm = (
  props: FeedBackLcFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.feedbackLc.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    isOpen = false,
    setIsOpen,
    name,
    receiverUsers,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(RequestFeedBackLcFollowViolationSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createFeedBackLcFollowViolation, isPending } =
    useCreateFeedBackLcFollowViolation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("followViolation.feedbackLc.title.titlePopup"),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  useEffect(() => {
    if (!(Array.isArray(receiverUsers) && receiverUsers.length)) {
      return;
    }

    form.setValue(FeedBackLcFollowViolationRequestFieldNames.USERS, receiverUsers);
  }, [receiverUsers]);

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createFeedBackLcFollowViolation({
      violationId,
      data: { ...data, status: data?.status && +data?.status },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.feedbackLc.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t("followViolation.feedbackLc.title.feedbackPerson")}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedBackLcFollowViolationRequestFieldNames.CONTENT}
                  label={t(`followViolation.feedbackLc.title.${"content"}`)}
                  placeHolder={t(
                    `followViolation.feedbackLc.placeHolder.${"content"}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={FeedBackLcFollowViolationRequestFieldNames.USERS}
                  label={t("response_to_lc_form.field_name.users")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };

                    const response = await getUsers(params);
                    const results = response?.users ?? [];

                    return results.map((user) => ({
                      id: user?.id,
                      name: user?.name ?? "",
                      departmentName: user?.department?.name,
                      email: user?.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"feedbackkLc/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={FeedBackLcFollowViolationRequestFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedBackFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
