"use client";
import { COLOR_TYPE } from "@/constants/color";
import { EXPECTED_DATE_TIME_LOCALE } from "@/constants/format";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";
import { LANGUAGES } from "@/locales/config-translation";
import {
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Stack,
  styled,
  Tooltip,
  tooltipClasses,
  TooltipProps,
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { FC, Fragment, ReactElement, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { getTooltip, SearchPanelQueries } from "./SearchPanel";
import { getAllHierarchyViolationById } from "@/apis/service/follow_violation/followViolationAPI";

interface TooltipCustomProps extends TooltipProps {
  hierachy?: boolean;
}

const CustomizedTooltip = styled(
  ({ className, ...props }: TooltipCustomProps) => (
    <Tooltip {...props} classes={{ popper: className }} />
  )
)(({ theme, hierachy }) =>
  hierachy
    ? {
        [`& .${tooltipClasses.tooltip}`]: {
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          color: "rgba(0, 0, 0, 0.87)",
          maxWidth: 400,
          minWidth: 360,
          fontSize: theme.typography.pxToRem(12),
          border: `1px solid ${COLOR_TYPE.TOYOTA.TOYOTA5}`,
        },
      }
    : {}
);

interface Props {
  children: ReactElement;
  id: string | number;
  name: string;
}
const ViolationTableTooltip: FC<Props> = (props) => {
  const { children, id, name } = props;
  const { i18n, t } = useTranslation();
  const { isFetching, data, refetch } = useQuery({
    queryKey: [SearchPanelQueries.GET_HIERARCHY, id],
    queryFn: () => getAllHierarchyViolationById({ id: id }).catch(() => ({})),
    enabled: false,
  });
  const handleOpen = () => refetch();

  const isEnglish = i18n.language === LANGUAGES.ENGLISH;
  const renderTooltipContent = useCallback(() => {
    if (!data?.children?.length) return "";
    return (
      <List sx={{ padding: "4px 8px" }}>
        <ListItem disablePadding dense alignItems="flex-start">
          {data?.createdUser && (
            <ListItemAvatar>
              <Tooltip title={getTooltip(data?.createdUser, isEnglish) ?? ""}>
                <Avatar
                  key={data?.createdUser?.id}
                  alt={data?.createdUser?.name}
                  src={data?.createdUser?.imgUrl}
                  sx={{ width: 40, height: 40 }}
                />
              </Tooltip>
            </ListItemAvatar>
          )}
          <ListItemText
            primary={
              <Link
                rel="noopener noreferrer"
                target="_blank"
                href={`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/update/${data?.id}`}
                passHref
              >
                {data?.name}
              </Link>
            }
            secondary={
              data?.createdDate
                ? Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                    dateStyle: "short",
                    timeStyle: "short",
                  }).format(new Date(data?.createdDate))
                : null
            }
            primaryTypographyProps={{
              variant: "h5",
              sx: {
                overflow: "hidden",
                textOverflow: "ellipsis",
                display: "-webkit-box",
                WebkitLineClamp: "2",
                WebkitBoxOrient: "vertical",
                title: data?.legalAdviceName,
              },
            }}
          />
        </ListItem>
        <ListItem dense sx={{ justifyContent: "space-between" }}>
          <ListItemAvatar>
            <Stack direction={"row"} gap={0.5}>
              {data?.receiverUsers?.map((person: any) => (
                <Tooltip
                  title={getTooltip(person, isEnglish) ?? ""}
                  key={person.id}
                >
                  <Avatar
                    alt={person.name}
                    src={person?.avatarUrl}
                    sx={{ width: 32, height: 32 }}
                  />
                </Tooltip>
              ))}
            </Stack>
          </ListItemAvatar>
          <Link
            rel="noopener noreferrer"
            target="_blank"
            href={`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/update/${data?.id}`}
            passHref
          >
            <ListItemText
              primary={data?.status?.name}
              sx={{
                cursor: "pointer",
                textAlign: "right",
                color: "#007AFF",
                textDecorationLine: "underline",
              }}
            />
          </Link>
        </ListItem>
        {(data?.children ?? []).map((child: any, index: number) => (
          <Fragment key={child.id}>
            <ListItem dense>
              <ListItemText
                primary={t(`followViolation.tooltip.requestInspection`, {
                  time: index + 2,
                })}
              />
            </ListItem>
            <ListItem dense sx={{ justifyContent: "space-between" }}>
              <ListItemAvatar>
                <Stack direction={"row"} gap={0.25}>
                  {child?.receiverUsers?.map((person: any) => (
                    <Tooltip
                      title={getTooltip(person, isEnglish) ?? ""}
                      key={person.id}
                    >
                      <Avatar
                        alt={person?.name}
                        src={person?.avatarUrl}
                        sx={{ width: 24, height: 24 }}
                      />
                    </Tooltip>
                  ))}
                </Stack>
              </ListItemAvatar>
              <Link
                rel="noopener noreferrer"
                target="_blank"
                href={`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/update/${child?.id}`}
                passHref
              >
                <ListItemText
                  primary={`${t("followViolation.tooltip.requestInspection", {
                    time: index + 2,
                  })}: ${child?.status?.name}`}
                  sx={{
                    textAlign: "right",
                    color: COLOR_TYPE.BLUE.BLUE6,
                    textDecorationLine: "underline",
                    cursor: "pointer",
                  }}
                />
              </Link>
            </ListItem>
          </Fragment>
        ))}
      </List>
    );
  }, [isFetching, data]);
  return (
    <CustomizedTooltip
      title={renderTooltipContent() || name}
      placement={data?.children?.length ? "left" : "bottom-start"}
      onOpen={handleOpen}
      hierachy={!!data?.children?.length}
    >
      {children}
    </CustomizedTooltip>
  );
};

export default ViolationTableTooltip;
