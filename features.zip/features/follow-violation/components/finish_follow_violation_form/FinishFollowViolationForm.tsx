import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import {
  castFinishFollowViolationRequestSchemaToDTO,
  FinishFollowViolationFieldNames,
  FinishFollowViolationSchema,
  FinishFollowViolationSchemaI,
} from "@/models/follow_violation/FinishFollowViolation";
import { useCreateFinishFollowViolation } from "@/apis/service/follow_violation/finishFollowViolation";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";
import { useGetAdvisorFollowViolationList } from "@/apis/service/follow_violation/advisorFollowViolation";

const initialEmptyValue: FinishFollowViolationSchemaI = {
  [FinishFollowViolationFieldNames.USERS]: [],
  [FinishFollowViolationFieldNames.CONTENT]: "",
  [FinishFollowViolationFieldNames.REMIND]: undefined,
};

export interface FinishFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: FinishFollowViolationSchemaI;
  violationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
}

export const FinishFollowViolationForm = (
  props: FinishFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.finish.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(FinishFollowViolationSchema),
    defaultValues: initialValue,
  });

  const {
    data: getAdvisorFollowViolationList,
    isLoading: isLoadingAdvisorFollowViolationList,
  } = useGetAdvisorFollowViolationList({
    request: { violationId },
    config: {
      enabled: !!violationId,
    },
  });

  useEffect(() => {
    let advisorList = getAdvisorFollowViolationList;
    advisorList =
      Array.isArray(advisorList) && advisorList.length ? [...advisorList] : [];

    const newUsers = advisorList.map((item) => {
      return {
        ...item?.createBy,
        nameEnglish: item?.createBy?.nameEnglish || item?.createBy?.name,
      };
    });

    form.setValue(FinishFollowViolationFieldNames.USERS, newUsers);
  }, [form, sender, getAdvisorFollowViolationList]);

  const { mutateAsync: createTrackFollowViolation, isPending } =
    useCreateFinishFollowViolation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;
    await createTrackFollowViolation({
      violationId,
      data: restData,
    });
  };

  if (isLoadingAdvisorFollowViolationList) return;

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.finish.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`followViolation.finish.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FinishFollowViolationFieldNames.CONTENT}
                  label={t(
                    `followViolation.finish.title.${FinishFollowViolationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `followViolation.finish.placeHolder.${FinishFollowViolationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={FinishFollowViolationFieldNames.USERS}
                  label={t("followViolation.finish.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"trackNextAction/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={FinishFollowViolationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFinishFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
