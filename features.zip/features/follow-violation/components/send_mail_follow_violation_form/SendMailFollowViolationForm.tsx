import { sendMailFollowViolation } from "@/apis/service/follow_violation/sendMailFollowViolation";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { SendMailFollowViolationRequestSchema } from "@/models/follow_violation/SendMailFollowViolation";
import { BasedUser } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { FC, useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { SearchPanelQueries } from "../SearchPanel";
import { ModuleFields } from "@/constants/general";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { EditorField } from "@/components/commons/EditorField/EditorField";
import { useGetEmailTemplate } from "@/apis/service/email_template/EmailTemplate";

export interface SendMailFollowViolationFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  followViolationId?: number;
  followViolation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
}

const SendMailFollowViolationForm: FC<SendMailFollowViolationFormProps> = (
  props
) => {
  const {
    titlePopup = "followViolation.sendMail.title.titlePopup",
    isOpen = false,
    setIsOpen,
    followViolation,
    followViolationId,
  } = props;
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();

  const {
    data: mailTemplateDetail,
    isLoading: isLoadingGetEmailTemplate,
  } = useGetEmailTemplate({
    request: {
      module: ModuleFields.VIOLATE_NAME.module,
      id: followViolationId,
    },
    config: {
      enabled: !!followViolationId,
    },
  });

  const form = useForm({
    resolver: yupResolver(SendMailFollowViolationRequestSchema),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const sendMailQuery = useMutation({
    mutationFn: sendMailFollowViolation,
    onSuccess: () => {
      toast.success(t("followViolation.messages.sendMailSuccess"));
      queryClient.invalidateQueries({
        queryKey: ["get_violation_next_action_query"],
      });
      queryClient.invalidateQueries({
        queryKey: ["get_initial_violation_query"],
      });
      queryClient.invalidateQueries({
        queryKey: [SearchPanelQueries.GET_HIERARCHY],
      });
      onCloseForm(true);
    },
  });

  useEffect(() => {
    if (mailTemplateDetail) {
      form.reset({
        title: mailTemplateDetail.title,
        content: mailTemplateDetail.content,
      });
    }
  }, [form, mailTemplateDetail])
  
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSave = () => {
    followViolationId &&
      sendMailQuery.mutate({
        id: followViolationId,
        request: {
          ...form.getValues(),
          receivers: form
            .getValues("receivers")
            ?.map((user: BasedUser) => user?.id),
        },
      });
  };

  if (isLoadingGetEmailTemplate) {
    return;
  }

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm(false)}
    >
      <Grid container className="form-wrapper">
        <FormProvider {...form}>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <Typography fontWeight="bold">
                    {t("followViolation.label.requestName")}
                  </Typography>
                  <Typography>{followViolation?.name}</Typography>
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={"title"}
                  label={t(`setting.mail.label.title`)}
                  placeHolder={t(`setting.mail.label.title`)}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <EditorField
                  control={form.control}
                  name="content"
                  label={t("followViolation.label.contentMail")}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={"receivers"}
                  label={t("followViolation.label.receiver")}
                  placeholder={t("followViolation.label.receiver")}
                  getOptions={async (keyword) => {
                    const params: any = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);
                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option.department?.name ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryUser"
                  minCharLength={1}
                  isFocus
                  required
                />
              </Grid>
            </Grid>
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={sendMailQuery.isPending}
            onCancel={() => onCloseForm()}
            cancelConfirm={form.formState.isDirty}
            onSave={onSave}
          />
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};

export default SendMailFollowViolationForm;
