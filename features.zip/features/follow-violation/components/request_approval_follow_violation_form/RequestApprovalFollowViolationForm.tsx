import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Card, Grid, Typography } from "@mui/material";
import React, { useContext, useEffect, useMemo, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import {
  APPROVAL_ROLE_ID,
  ApprovalConfirmRequestFvSchema,
  RequestApprovalRequestFvFieldNames,
  RequestApprovalRequestFvSchema,
  RequestApprovalRequestFvSchemaI,
} from "@/models/follow_violation/RequestApprovalFollowViolation";
import {
  useCreateApprovalFv,
  useCreateRequestApprovalFv,
  useGetRequestApprovalFollowViolation,
} from "@/apis/service/follow_violation/requestApprovalFollowViolation";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { castRequestApproveNextActionSchemaToDTO } from "@/models/follow_violation/FeedBackFollowViolation";
import { castReminderInputToReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { getDepartmentHeads } from "@/apis/service/department/department";
import { NextActionContext } from "@/context/NextActionContext";
import { useQueryClient } from "@tanstack/react-query";
import { ApproveType } from "@/models/follow_violation/FormType";
import { SearchPanelQueries } from "../SearchPanel";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { getViolationApproval } from "@/apis/service/follow_violation/followViolationAPI";

const initialEmptyValue: RequestApprovalRequestFvSchemaI = {
  [RequestApprovalRequestFvFieldNames.DEADLINE]: "",
  [RequestApprovalRequestFvFieldNames.CONTENT]: "",
  [RequestApprovalRequestFvFieldNames.USERS]: [],
  [RequestApprovalRequestFvFieldNames.REMIND]: undefined,
};

export interface RequestApprovalFollowViolationFormProps {
  titlePopup?: string;
  approvalRoleId: APPROVAL_ROLE_ID;
  initialValue?: RequestApprovalRequestFvSchemaI;
  violationId?: number;
  requestApprovalId?: number;
  nextActionItems?: any[];
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  isConfirmRequestApproval?: boolean;
  name?: string;
  module?: number;
  sender?: any;
  createBy?: any;
}

export const RequestApprovalFollowViolationForm = (
  props: RequestApprovalFollowViolationFormProps
) => {
  const {
    titlePopup,
    approvalRoleId,
    initialValue = initialEmptyValue,
    violationId,
    requestApprovalId,
    nextActionItems,
    isOpen = false,
    setIsOpen,
    isConfirmRequestApproval = false,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
    createBy,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();
  const { approve } = useContext(NextActionContext);
  const [requestInfo, setRequestInfo] = useState<any>([]);

  const titlePopupLangKey = useMemo(() => {
    return titlePopup
      ? titlePopup
      : isConfirmRequestApproval
      ? "requestApproval.title.titlePopupConfirm"
      : "requestApproval.title.titlePopup";
  }, [titlePopup, isConfirmRequestApproval]);

  const { data: dataRequestApproval } = useGetRequestApprovalFollowViolation({
    request: { violationId, requestApprovalId },
    config: {
      enabled: !!violationId && !!requestApprovalId,
    },
  });

  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmRequestApproval
        ? (ApprovalConfirmRequestFvSchema as any)
        : RequestApprovalRequestFvSchema
    ),
    defaultValues: initialValue,
  });

  const { mutateAsync: createRequestApprovalFv, isPending } =
    useCreateRequestApprovalFv({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopupLangKey),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const { mutateAsync: createApprovalFv, isPending: isLoadingCreateApproval } =
    useCreateApprovalFv({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopupLangKey),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  useEffect(() => {
    if (dataRequestApproval) {
      form.reset({
        ...dataRequestApproval,
        remind: dataRequestApproval.remind
          ? castReminderInputToReminderSchema(
              dataRequestApproval?.remind as any
            )
          : undefined,
      });
    }
  }, [form, dataRequestApproval]);

  /**
   * Get request info
   */
  useEffect(() => {
    if (!isConfirmRequestApproval || !violationId) {
      return;
    }

    (async () => {
      const requestInfoList = await getViolationApproval(violationId);

      if (!(Array.isArray(requestInfoList) && requestInfoList.length)) {
        return;
      }

      const lastRequestUserId = requestInfoList[0]?.user?.id;
      const lastRequestInfoList = requestInfoList.filter(
        (item) => item?.user?.id === lastRequestUserId
      );

      const newRequestInfo = {
        user: requestInfoList[0]?.user,
        contents: lastRequestInfoList,
      };

      setRequestInfo(newRequestInfo);
    })();
  }, [violationId, isConfirmRequestApproval]);

  const approvalIds = useMemo(() => {
    if (
      !isConfirmRequestApproval ||
      !(Array.isArray(nextActionItems) && nextActionItems.length)
    ) {
      return [];
    }

    let newIds = [] as number[];

    if (
      approve?.status === ApproveType.APPROVED &&
      Array.isArray(approve?.values) &&
      approve?.values.length
    ) {
      newIds = approve?.values.map((i) => {
        return nextActionItems[i]?.nextActionId;
      });
    }

    return newIds;
  }, [isConfirmRequestApproval, nextActionItems, approve]);

  const deniedIds = useMemo(() => {
    if (
      !isConfirmRequestApproval ||
      !(Array.isArray(nextActionItems) && nextActionItems.length)
    ) {
      return [];
    }

    let newIds = [] as number[];

    if (
      approve?.status === ApproveType.REJECTED &&
      Array.isArray(approve?.values) &&
      approve?.values.length
    ) {
      newIds = approve?.values.map((i) => {
        return nextActionItems[i]?.nextActionId;
      });
    }

    return newIds;
  }, [isConfirmRequestApproval, nextActionItems, approve]);

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  useEffect(() => {
    (async () => {
      // PIC yêu cầu Dept head duyệt, chỗ người phụ trách, điền mặc định Dept head của PIC
      // Dept head yêu cầu Group head duyệt, chỗ người phụ trách, điền mặc định Group head của Dept head
      // Group head yêu cầu Top head duyệt, chỗ người phụ trách, điền mặc định Top head của Group head
      if (!isConfirmRequestApproval && sender?.department?.id) {
        const headOfSender = await getDepartmentHeads(sender?.department?.id);
        const newUser = {
          ...headOfSender?.deptHead,
          nameEnglish:
            headOfSender?.deptHead?.nameEnglish || headOfSender?.deptHead?.name,
        };
        form.setValue(
          RequestApprovalRequestFvFieldNames.USERS,
          newUser?.id ? [newUser] : []
        );
      }

      // Dept head đang duyệt, chỗ người nhận điền ông yêu cầu duyệt, là ông tạo VVVP
      else if (
        isConfirmRequestApproval &&
        approvalRoleId === APPROVAL_ROLE_ID.DEPT_HEAD &&
        createBy?.id
      ) {
        const newUser = {
          ...createBy,
          nameEnglish: createBy?.nameEnglish || createBy?.name,
        };
        form.setValue(
          RequestApprovalRequestFvFieldNames.USERS,
          newUser?.id ? [newUser] : []
        );
      }
    })();
  }, [form, isConfirmRequestApproval, approvalRoleId, sender, createBy]);

  const onSubmit = async (data: any) => {
    // Duyệt
    if (isConfirmRequestApproval) {
      await createApprovalFv({
        violationId,
        data: {
          ...data,
          approvalRoleId,
          approvalIds: approvalIds ?? [],
          deniedIds: deniedIds ?? [],
        },
      });
    }

    // Yêu cầu duyệt
    else {
      await createRequestApprovalFv({
        violationId,
        data: { ...data, approvalRoleId },
      });
    }
  };

  return (
    <ModalCommon
      title={t(titlePopupLangKey)}
      open={isOpen}
      onClose={onCloseForm}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.requestApproval.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {isConfirmRequestApproval
                    ? t(`followViolation.requestApproval.title.approver`)
                    : t(`followViolation.requestApproval.title.requester`)}
                </label>
                <Typography>
                  {sender?.name} ({sender?.email}) - {sender?.department?.name}
                </Typography>
              </Grid>

              {isConfirmRequestApproval && requestInfo?.user?.id && (
                <Grid item width={"100%"}>
                  <label style={{ padding: 0 }}>
                    {t(
                      `followViolation.requestApproval.title.informationRequired`
                    )}
                  </label>
                  <Card
                    style={{
                      width: "100%",
                      padding: 15,
                      marginBottom: 15,
                    }}
                  >
                    <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                      <label style={{ padding: 0 }}>
                        {t("followViolation.advisor.title.consultant")}
                      </label>
                      <Typography>{`${requestInfo?.user?.name} (${requestInfo?.user?.email}) - ${requestInfo?.user?.department?.name}`}</Typography>
                    </Grid>

                    <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                      <label style={{ padding: 0 }}>
                        {t("followViolation.advisor.title.content")}
                      </label>

                      {Array.isArray(requestInfo?.contents) && (
                        <ul>
                          {requestInfo?.contents.map((item: any) => {
                            return (
                              <li key={item?.id}>- {item?.content || ""}</li>
                            );
                          })}
                        </ul>
                      )}
                    </Grid>
                  </Card>
                </Grid>
              )}

              {!isConfirmRequestApproval && (
                <Grid item width={"100%"}>
                  <DateInput
                    name={RequestApprovalRequestFvFieldNames.DEADLINE}
                    control={form.control}
                    label={t(`followViolation.requestApproval.title.deadline`)}
                    placeholder="dd/mm/yyyy"
                    required
                  />
                </Grid>
              )}

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestApprovalRequestFvFieldNames.CONTENT}
                  label={
                    isConfirmRequestApproval
                      ? t(`followViolation.requestApproval.title.reason`)
                      : t(`followViolation.requestApproval.title.content`)
                  }
                  placeHolder={
                    isConfirmRequestApproval
                      ? t(`followViolation.requestApproval.placeHolder.reason`)
                      : t(`followViolation.requestApproval.placeHolder.content`)
                  }
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={RequestApprovalRequestFvFieldNames.USERS}
                  label={
                    isConfirmRequestApproval
                      ? t(`followViolation.requestApproval.title.receiver`)
                      : t(
                          `followViolation.requestApproval.title.personInCharge`
                        )
                  }
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"requestApproval/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={RequestApprovalRequestFvFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isLoadingCreateApproval}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castRequestApproveNextActionSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
