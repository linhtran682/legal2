import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { ViolationRole } from "@/models/follow_violation/FollowViolationType";
import { HistoryRecord } from "@/models/metadata/Metadata";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";



export interface Props {
  queryKey: string;
  getHistoryRecords: () => Promise<HistoryRecord[]>;
  ownRole?: number[];
}

export const ViolationHistoryPanel = (props: Props) => {
  const { t,i18n } = useTranslation();
  const getHistoryRecordsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getHistoryRecords(),
  });

  const isEnglish = i18n.language === LANGUAGES.ENGLISH;

  const getUserAction = (history: HistoryRecord) => {
    // action tiếp đón là 19
    if (history.action === 23 || history.action === 19) {
      return t(`followViolation.actionContent.${history.action}`, {
        username: history.actionOwner.name,
        receiverUser: history?.receiverUsers?.map((user) => user.name)?.join(', ')
      })
    }
    if (history.action === 26 || history.action === 36 || history.action === 39) {
      return <>
        <p>{t(`followViolation.actionContent.${history.action}`, {
          username: history.actionOwner.name,
        })}
        </p>
        <p>{t(`followViolation.label.content`)}: {history.content}</p>
      </>
    }

    if (history.action === 22) {
      const isSuppervisorRole = (props.ownRole ?? []).includes(ViolationRole.SUPERVISOR);
      let text = "";
      if (isSuppervisorRole) {
        text = isEnglish ? " monitor" : " giám sát";
      }
      
      return t(`followViolation.actionContent.${history.action}`, {
        username: history.actionOwner.name,
        text,
      })
    }

    return t(`followViolation.actionContent.${history.action}`, {
      username: history.actionOwner.name
    })
  }

  const HistoryTableColumns: StandardSimpleTableColumn<HistoryRecord>[] = [
    {
      key: "date",
      label: "metadata.history.column.date",
      type: "date",
      flex: 1,
    },
    {
      key: "user",
      label: "metadata.history.column.user",
      type: "string",
      flex: 1,
      renderCell: (params) => getUserAction(params.row)
    },
    {
      key: "action",
      label: "Action",
      type: "string",
      flex: 1,
      renderCell: (params) => t(`followViolation.actions.${params.row.action}`),
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={HistoryTableColumns}
        data={getHistoryRecordsQuery.data ?? []}
        getRowId={(row) => row.date}
      />
    </div>
  );
};
