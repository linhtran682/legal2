import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { InformationRequestType } from "@/models/follow_violation/FormType";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";

export interface InformationRequestPanelProps {
  queryKey: string;
  getInformationRequests: () => Promise<InformationRequestType[]>;
}

export const InformationRequestPanel = (
  props: InformationRequestPanelProps
) => {

  const InformationRequestColumns: StandardSimpleTableColumn<InformationRequestType>[] =
    [
      {
        key: "id",
        label: "metadata.informationRequest.column.id",
        type: "number",
        flex: 1,
        renderCell: (params) => +params?.id + 1,
      },
      {
        key: "departmentName",
        label: "metadata.informationRequest.column.departmentName",
        type: "string",
        flex: 1,
        renderCell: (params) => params.row.user?.department?.name ?? "",
      },
      {
        key: "employeeName",
        label: "metadata.informationRequest.column.employeeName",
        type: "string",
        flex: 1,
        renderCell: (params) => params.row.user?.name ?? "",
      },
      {
        key: "content",
        label: "metadata.informationRequest.column.content1",
        type: "string",
        flex: 1,
      },
      {
        key: "deadline",
        label: "metadata.informationRequest.column.deadline",
        type: "string",
        flex: 1,
        renderCell: (params) =>
          params?.value ? format(new Date(params?.value), "dd/MM/yyyy") : "",
      },
    ];

  const getInformationRequestQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getInformationRequests(),
  });
  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={InformationRequestColumns}
        data={getInformationRequestQuery.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
    </div>
  );
};
