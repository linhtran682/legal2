import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { useCreateRequestAddInfoFv } from "@/apis/service/follow_violation/requestAddInfoFollowViolation";
import {
  RequestAddInfoFvFieldNames,
  RequestAddInfoFvSchemaI,
  RequestAddInfoSchemaFV,
} from "@/models/follow_violation/RequestAddInfoFollowViolation";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";

const initialEmptyValue: RequestAddInfoFvSchemaI = {
  [RequestAddInfoFvFieldNames.DEADLINE]: "",
  [RequestAddInfoFvFieldNames.CONTENT]: "",
  [RequestAddInfoFvFieldNames.USERS]: [],
  [RequestAddInfoFvFieldNames.REMIND]: undefined,
};

export interface RequestAddInfoFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: RequestAddInfoFvSchemaI;
  violationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  createBy?: any;
  answerDate?: Date | string;
}

export const RequestAddInfoFollowViolationForm = (
  props: RequestAddInfoFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.requestAdditional.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
    createBy,
    answerDate,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(RequestAddInfoSchemaFV),
    defaultValues: initialValue,
  });

  const { mutateAsync: createRequestAddInfoFv, isPending } =
    useCreateRequestAddInfoFv({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  useEffect(() => {
    if (!createBy) {
      return;
    }

    form.reset({
      [RequestAddInfoFvFieldNames.USERS]: [createBy],
    });
  }, [form, createBy]);

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const users =
      Array.isArray(data?.users) && data?.users.length
        ? [...data?.users].map((item) => item?.id)
        : [];

    await createRequestAddInfoFv({
      violationId,
      data: { ...data, users },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`followViolation.requestAdditional.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={RequestAddInfoFvFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`followViolation.requestAdditional.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  maxDate={answerDate}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestAddInfoFvFieldNames.CONTENT}
                  label={t(
                    `followViolation.requestAdditional.title.${RequestAddInfoFvFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `followViolation.requestAdditional.placeHolder.${RequestAddInfoFvFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={RequestAddInfoFvFieldNames.USERS}
                  label={t(
                    "followViolation.requestAdditional.title.personInCharge"
                  )}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"requestAdditional/queryUser"}
                  isFocus
                  disabled
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={RequestAddInfoFvFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
