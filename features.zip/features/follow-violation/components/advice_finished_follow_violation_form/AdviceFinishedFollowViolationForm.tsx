import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import { useGetAdvisorFollowViolationList } from "@/apis/service/follow_violation/advisorFollowViolation";
import {
  castAdviceFinishedFvRequestSchemaToDTO,
  AdviceFinishedFollowViolationFieldNames,
  AdviceFinishedFollowViolationSchema,
  AdviceFinishedFollowViolationSchemaI,
} from "@/models/follow_violation/AdviceFinishedFollowViolation";
import { useCreateAdviceFinishedFollowViolation } from "@/apis/service/follow_violation/adviceFinishedFollowViolation";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";

const initialEmptyValue: AdviceFinishedFollowViolationSchemaI = {
  [AdviceFinishedFollowViolationFieldNames.USERS]: [],
  [AdviceFinishedFollowViolationFieldNames.CONTENT]: "",
  [AdviceFinishedFollowViolationFieldNames.REMIND]: undefined,
};

export interface AdviceFinishedFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: AdviceFinishedFollowViolationSchemaI;
  violationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
}

export const AdviceFinishedFollowViolationForm = (
  props: AdviceFinishedFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.adviceFinished.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();
  const form = useForm<any>({
    resolver: yupResolver(AdviceFinishedFollowViolationSchema),
    defaultValues: initialValue,
  });

  useEffect(() => {
    if (initialValue?.users) {
      form.reset({
        ...initialEmptyValue,
      });
    }
  }, [form, initialValue?.users]);

  const { mutateAsync: createAdviceFinishedFollowViolation, isPending } =
    useCreateAdviceFinishedFollowViolation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const {
    data: getAdvisorFollowViolationList,
    isLoading: isLoadingAdvisorFollowViolationList,
  } = useGetAdvisorFollowViolationList({
    request: { violationId },
    config: {
      enabled: !!violationId,
    },
  });

  useEffect(() => {
    if (
      Array.isArray(getAdvisorFollowViolationList) &&
      getAdvisorFollowViolationList.length
    ) {
      const newUsers = getAdvisorFollowViolationList.reduce(
        (acc: any, cur: any) => {
          if (!acc.some((a: any) => a?.id === cur?.createBy?.id)) {
            acc.push(cur?.createBy);
          }
          return acc;
        },
        []
      );

      form.setValue(AdviceFinishedFollowViolationFieldNames.USERS, newUsers);
    }
  }, [form, getAdvisorFollowViolationList]);

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;

    await createAdviceFinishedFollowViolation({
      violationId,
      data: restData,
    });
  };

  if (isLoadingAdvisorFollowViolationList) return;

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.adviceFinished.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`followViolation.adviceFinished.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AdviceFinishedFollowViolationFieldNames.CONTENT}
                  label={t(
                    `followViolation.adviceFinished.title.${AdviceFinishedFollowViolationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `followViolation.adviceFinished.placeHolder.${AdviceFinishedFollowViolationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={AdviceFinishedFollowViolationFieldNames.USERS}
                  label={t("followViolation.adviceFinished.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"adviceFinished/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={AdviceFinishedFollowViolationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castAdviceFinishedFvRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
