import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  Grid,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import moment from "moment";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  castForwardFollowViolationRequestSchemaToDTO,
  ForwardFollowViolationFieldNames,
  ForwardFollowViolationSchema,
  ForwardFollowViolationSchemaI,
} from "@/models/follow_violation/ForwardFollowViolation";
import { useCreateForwardForwardFollow } from "@/apis/service/follow_violation/forwardFollowViolation";
import { DateRangeIcon } from "@mui/x-date-pickers";
import { Module, ModuleKeys } from "@/constants/general";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";

const initialEmptyValue: ForwardFollowViolationSchemaI = {
  [ForwardFollowViolationFieldNames.USERS_IDS]: [],
  [ForwardFollowViolationFieldNames.DEADLINE]: "",
  [ForwardFollowViolationFieldNames.CONTENT]: "",
  [ForwardFollowViolationFieldNames.REMIND]: undefined,
};

export interface ForwardFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: ForwardFollowViolationSchemaI;
  violationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  createBy?: any;
  answerDate?: Date | string;
}

export const ForwardFollowViolationForm = (
  props: ForwardFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.forwardFollowViolation.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
    createBy,
    answerDate,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(ForwardFollowViolationSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createForward, isPending } =
    useCreateForwardForwardFollow({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    await createForward({
      violationId,
      data: {
        ...values,
        [ForwardFollowViolationFieldNames.DEADLINE]: moment(answerDate).toISOString(),
      },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.forwardFollowViolation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                {" "}
                <label style={{ padding: 0 }}>
                  {t(`response_to_lc_form.field_name.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`followViolation.forwardFollowViolation.title.deadline`)}
                </InputLabel>

                <TextField
                  value={
                    answerDate
                      ? moment
                          .utc(answerDate)
                          .local()
                          .format("DD/MM/YYYY hh:mm")
                      : ""
                  }
                  minRows={3}
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <DateRangeIcon />
                      </InputAdornment>
                    ),
                  }}
                  fullWidth
                  disabled
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ForwardFollowViolationFieldNames.CONTENT}
                  label={t(
                    `followViolation.forwardFollowViolation.title.${ForwardFollowViolationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `followViolation.forwardFollowViolation.placeHolder.${ForwardFollowViolationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ForwardFollowViolationFieldNames.USERS_IDS}
                  label={t(
                    "followViolation.forwardFollowViolation.title.receiver"
                  )}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? [])
                      .filter((user) => user?.id !== createBy?.id)
                      .map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"forwardFollowViolation/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ForwardFollowViolationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castForwardFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
