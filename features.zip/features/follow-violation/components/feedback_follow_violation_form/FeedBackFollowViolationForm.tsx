import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  Grid,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import moment from "moment";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { DateRangeIcon } from "@mui/x-date-pickers";
import { Module, ModuleKeys } from "@/constants/general";
import {
  castFeedBackFollowViolationRequestSchemaToDTO,
  FeedbackFollowViolationFieldNames,
  FeedbackFollowViolationSchema,
  FeedbackFollowViolationSchemaI,
} from "@/models/follow_violation/FeedBackFollowViolation";
import { useCreateFeedbackFollowViolation } from "@/apis/service/follow_violation/feedbackFollowViolation";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";
import {
  FollowViolationUserRole,
  FollowViolationUserRoleKey,
} from "@/constants/followViolation";
import { getViolationById } from "@/apis/service/follow_violation/followViolationAPI";
import { FollowViolationDetail } from "@/models/follow_violation/FormType";

const initialEmptyValue: FeedbackFollowViolationSchemaI = {
  [FeedbackFollowViolationFieldNames.USERS]: [],
  [FeedbackFollowViolationFieldNames.DEADLINE]: "",
  [FeedbackFollowViolationFieldNames.CONTENT]: "",
  [FeedbackFollowViolationFieldNames.REMIND]: undefined,
};

export interface FeedBackFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: FeedbackFollowViolationSchemaI;
  violationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  answerDate?: Date | string;
}

export const FeedBackFollowViolationForm = (
  props: FeedBackFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.feedbackFollowViolation.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
    answerDate,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();
  const [violation, setViolation] = useState<FollowViolationDetail>();

  const form = useForm<any>({
    resolver: yupResolver(FeedbackFollowViolationSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createFeedbackFollowViolation, isPending } =
    useCreateFeedbackFollowViolation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  useEffect(() => {
    if (!violationId) {
      return;
    }

    (async () => {
      const res = await getViolationById(violationId);

      if (res) {
        setViolation(res);
      }
    })();
  }, [violationId]);

  const hasRelatedPerson = useMemo(() => {
    const roleList = violation?.lastActionAndRole?.userLastActionAndRoleList;

    if (!(Array.isArray(roleList) && roleList.length)) {
      return true;
    }

    return roleList.some((r) => {
      return (
        r?.role ===
        FollowViolationUserRole.get(FollowViolationUserRoleKey.RELATED_PERSON)
      );
    });
  }, [violation?.lastActionAndRole?.userLastActionAndRoleList]);

  const userList = useMemo(() => {
    if (!violation?.id) {
      return [];
    }

    const responsibleUsers =
      Array.isArray(violation?.responsibleUsers) &&
      violation?.responsibleUsers.length
        ? [...violation?.responsibleUsers]
        : [];

    const receiverUsers =
      Array.isArray(violation?.receiverUsers) && violation?.receiverUsers.length
        ? [...violation?.receiverUsers]
        : [];

    const assignmentUsers =
      Array.isArray(violation?.assignmentUsers) &&
      violation?.assignmentUsers.length
        ? [...violation?.assignmentUsers]
        : [];

    const supervisorUsers =
      Array.isArray(violation?.supervisorUsers) &&
      violation?.supervisorUsers.length
        ? [...violation?.supervisorUsers]
        : [];

    const newUsers = [
      violation?.createdBy,
      ...responsibleUsers,
      ...receiverUsers,
      ...assignmentUsers,
      ...supervisorUsers,
    ].reduce((acc: any, cur: any) => {
      if (cur?.id && !acc.some((a: any) => a?.id === cur?.id)) {
        acc.push(cur);
      }
      return acc;
    }, []);

    return newUsers;
  }, [violation]);

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    await createFeedbackFollowViolation({
      violationId,
      data: {
        ...values,
        [FeedbackFollowViolationFieldNames.DEADLINE]:
          moment(answerDate).toISOString(),
      },
    });
  };

  if (
    !violation?.id ||
    hasRelatedPerson === undefined ||
    userList === undefined
  ) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.feedbackFollowViolation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`followViolation.feedbackFollowViolation.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`followViolation.feedbackFollowViolation.title.deadline`)}
                </InputLabel>

                <TextField
                  value={
                    answerDate
                      ? moment
                          .utc(answerDate)
                          .local()
                          .format("DD/MM/YYYY hh:mm")
                      : ""
                  }
                  minRows={3}
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <DateRangeIcon />
                      </InputAdornment>
                    ),
                  }}
                  fullWidth
                  disabled
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedbackFollowViolationFieldNames.CONTENT}
                  label={t(
                    `followViolation.feedbackFollowViolation.title.${FeedbackFollowViolationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `followViolation.feedbackFollowViolation.placeHolder.${FeedbackFollowViolationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={FeedbackFollowViolationFieldNames.USERS}
                  label={t(
                    "followViolation.feedbackFollowViolation.title.receiver"
                  )}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"feedbackFollowViolation/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={FeedbackFollowViolationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedBackFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
