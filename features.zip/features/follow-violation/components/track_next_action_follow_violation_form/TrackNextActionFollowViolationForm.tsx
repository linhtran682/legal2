import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import {
  castTrackFollowViolationRequestSchemaToDTO,
  TrackNextActionFvFieldNames,
  TrackNextActionFvSchema,
  TrackNextActionFvSchemaI,
} from "@/models/follow_violation/TrackNextActionFollowViolation";
import { useCreateTrackNextActionFv } from "@/apis/service/follow_violation/trackNextActionFollowViolation";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";

const initialEmptyValue: TrackNextActionFvSchemaI = {
  [TrackNextActionFvFieldNames.USERS]: [],
  [TrackNextActionFvFieldNames.CONTENT]: "",
  [TrackNextActionFvFieldNames.REMIND]: undefined,
};

export interface TrackNextActionFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: TrackNextActionFvSchemaI;
  violationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  createBy?: any;
  receiverUsers?: BasedUser[];
}

export const TrackNextActionFollowViolationForm = (
  props: TrackNextActionFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.trackNextAction.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
    createBy,
    receiverUsers,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(TrackNextActionFvSchema),
    defaultValues: initialValue,
  });

  useEffect(() => {
    const newCreateBy = {
      ...createBy,
      nameEnglish: createBy?.nameEnglish || createBy?.name,
    };
    let newUsers =
      Array.isArray(receiverUsers) && receiverUsers.length
        ? [...receiverUsers]
        : [];

    if (!newUsers.some((item) => item?.id === createBy?.id)) {
      newUsers = [...newUsers, newCreateBy];
    }

    newUsers = newUsers.filter((item) => item?.id !== sender?.id);

    form.setValue(TrackNextActionFvFieldNames.USERS, newUsers);
  }, [form, sender, createBy, receiverUsers]);

  const { mutateAsync: createTrackFollowViolation, isPending } =
    useCreateTrackNextActionFv({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;

    await createTrackFollowViolation({
      violationId,
      data: restData,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.trackNextAction.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`followViolation.trackNextAction.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={TrackNextActionFvFieldNames.CONTENT}
                  label={t(
                    `followViolation.trackNextAction.title.${TrackNextActionFvFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `followViolation.trackNextAction.placeHolder.${TrackNextActionFvFieldNames.CONTENT}`
                  )}
                  minRows={3}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={TrackNextActionFvFieldNames.USERS}
                  label={t("followViolation.trackNextAction.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"trackNextAction/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={TrackNextActionFvFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castTrackFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
