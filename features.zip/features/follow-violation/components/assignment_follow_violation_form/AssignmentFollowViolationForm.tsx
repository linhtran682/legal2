import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { getLegalDepartments } from "@/apis/service/department/department";
import { BasedUser } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  AssignmentFollowViolationFieldNames,
  AssignmentFollowViolationSchema,
  AssignmentFollowViolationSchemaI,
  castAssignmentFollowViolationRequestSchemaToDTO,
} from "@/models/follow_violation/AssignmentFollowViolation";
import { useCreateAssignmentFollowViolation } from "@/apis/service/follow_violation/assignmentFollowViolation";
import { Module, ModuleKeys } from "@/constants/general";
import { SearchPanelQueries } from "../SearchPanel";
import { useGetAdvisorFollowViolationList } from "@/apis/service/follow_violation/advisorFollowViolation";

const initialEmptyValue: AssignmentFollowViolationSchemaI = {
  [AssignmentFollowViolationFieldNames.CONTENT]: "",
  [AssignmentFollowViolationFieldNames.USERS_IDS]: [],
  [AssignmentFollowViolationFieldNames.REMIND]: undefined,
};

export interface AssignmentFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: AssignmentFollowViolationSchemaI;
  violationId?: number;
  violation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  createBy?: any;
}

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}

export const AssignmentFollowViolationForm = (
  props: AssignmentFollowViolationFormProps
) => {
  const {
    titlePopup = "followViolation.assignment.title.titlePopup",
    initialValue = initialEmptyValue,
    violationId,
    violation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
    createBy,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(AssignmentFollowViolationSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createAssignmentFollowViolation, isPending } =
    useCreateAssignmentFollowViolation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("followViolation.assignment.title.titlePopup"),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["follow-violation/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const {
    data: getAdvisorFollowViolationList,
    isLoading: isLoadingAdvisorFollowViolationList,
  } = useGetAdvisorFollowViolationList({
    request: { violationId },
    config: {
      enabled: !!violationId,
    },
  });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createAssignmentFollowViolation({
      violationId,
      data,
    });
  };

  if (isLoadingAdvisorFollowViolationList) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.assignment.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`followViolation.assignment.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AssignmentFollowViolationFieldNames.CONTENT}
                  label={t(
                    `followViolation.assignment.title.${AssignmentFollowViolationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `followViolation.assignment.placeHolder.${AssignmentFollowViolationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                />
              </Grid>

              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AssignmentFollowViolationFieldNames.USERS_IDS}
                    label={t("followViolation.assignment.title.personInCharge")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      if (!getLegalDepartmentQuery.data) return [];

                      let advisorList = getAdvisorFollowViolationList;
                      advisorList =
                        Array.isArray(advisorList) && advisorList.length
                          ? [...advisorList]
                          : [];

                      let receiverUsers = violation?.receiverUsers;
                      receiverUsers =
                        Array.isArray(receiverUsers) && receiverUsers.length
                          ? [...receiverUsers]
                          : [];

                      let assignmentUsers = violation?.assignmentUsers;
                      assignmentUsers =
                        Array.isArray(assignmentUsers) && assignmentUsers.length
                          ? [...assignmentUsers]
                          : [];

                      const response = await getUsers({
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                        departmentIds: getLegalDepartmentQuery.data
                          ? [getLegalDepartmentQuery.data]
                          : [],
                      });

                      return (response?.users ?? [])
                        .filter((user) => {
                          return (
                            user?.id !== createBy?.id &&
                            user?.id !== sender?.id &&
                            !advisorList.some(
                              (u: any) => user?.id === u?.createBy?.id
                            ) &&
                            ![...receiverUsers, ...assignmentUsers].some(
                              (u: any) => user?.id === u?.id
                            )
                          );
                        })
                        .map((user) => ({
                          id: user.id,
                          name: user.name ?? "",
                          departmentName: user.department?.name,
                          email: user.email,
                        }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"assignmentAdvice/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={AssignmentFollowViolationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castAssignmentFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
