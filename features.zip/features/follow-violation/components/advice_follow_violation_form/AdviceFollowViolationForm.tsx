import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams, UserProfileDTO } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import {
  AdviceFvOptions,
  AdviceSupervisorFvOptions,
  AdvisorFollowViolationFieldNames,
  AdvisorFollowViolationSchema,
  AdvisorFollowViolationSchemaI,
  castAdvisorFollowViolationRequestSchemaToDTO,
  FeedBackAdvisorFollowViolationSchema,
  FileInfo,
  ResponsesAdvisorFollowViolationDTO,
  TypeAdvisorFollowViolation,
} from "@/models/follow_violation/AdvisorFollowViolation";
import {
  useCreateAdvisorFollowViolation,
  useFeedbackAdviceFollowViolation,
  useGetAdvisorFollowViolationList,
  useUpdateAdvisorFollowViolationDetail,
} from "@/apis/service/follow_violation/advisorFollowViolation";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { getDepartmentHeads } from "@/apis/service/department/department";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { ListAdvisorFollowViolation } from "./ListAdvisorFollowViolation";

const initialEmptyValue: AdvisorFollowViolationSchemaI = {
  [AdvisorFollowViolationFieldNames.CONTENT]: "",
  [AdvisorFollowViolationFieldNames.TYPE]: undefined,
  [AdvisorFollowViolationFieldNames.USERS]: [],
  [AdvisorFollowViolationFieldNames.REMIND]: undefined,
};

export interface AdviceFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: AdvisorFollowViolationSchemaI;
  violationId?: number;
  advise?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  isAdvice?: boolean;
  isFeedBackAdvice?: boolean;
  isSuperviorAdvisor?: boolean;
  name?: string;
  module?: number;
  minDateAdvisor?: Date | undefined;
  sender?: any;
  createBy?: any;
}

export const AdviceFollowViolationForm = (
  props: AdviceFollowViolationFormProps
) => {
  const {
    titlePopup,
    initialValue = initialEmptyValue,
    violationId,
    advise = undefined,
    isOpen = false,
    setIsOpen,
    isAdvice = true,
    isFeedBackAdvice = false,
    isSuperviorAdvisor = false,
    name,
    module = Module.get(ModuleKeys.ADVISE),
    minDateAdvisor = undefined,
    sender,
    createBy,
  } = props;
  const [files, setFiles] = useState<any>([]);
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(
      isFeedBackAdvice
        ? AdvisorFollowViolationSchema.concat(
            FeedBackAdvisorFollowViolationSchema
          )
        : AdvisorFollowViolationSchema
    ),
    defaultValues: initialValue,
  });

  const {
    data: getAdvisorFollowViolationList,
    isLoading: isLoadingAdvisorFollowViolationList,
  } = useGetAdvisorFollowViolationList({
    request: { violationId },
    config: {
      enabled: !!violationId,
    },
  });

  /**
   * Current advice
   */
  const currentAdvice = useMemo(() => {
    if (!(isAdvice || isSuperviorAdvisor)) {
      return;
    }

    // When click to edit button, on detail page
    if (advise?.id) {
      return advise;
    }

    // When click button: "Tư vấn"
    else {
      let advisorList = getAdvisorFollowViolationList;
      advisorList =
        Array.isArray(advisorList) && advisorList.length
          ? [...advisorList]
          : [];

      const reversedAdvisorList = advisorList.reverse();
      const foundAdvice = reversedAdvisorList.find(
        (item) => item?.createBy?.id === sender?.id
      );

      if (foundAdvice) {
        return foundAdvice;
      }
    }
  }, [
    sender,
    isAdvice,
    isSuperviorAdvisor,
    advise,
    getAdvisorFollowViolationList,
  ]);

  const {
    mutateAsync: createAdvisorFollowViolation,
    isPending: isLoadingCreateAdvisorFollowViolation,
  } = useCreateAdvisorFollowViolation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t(
              titlePopup ?? `followViolation.advisor.title.titlePopupAdvice`
            ),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_violation_next_action_query"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_violation_query"],
        });
        queryClient.invalidateQueries({
          queryKey: [SearchPanelQueries.GET_HIERARCHY],
        });
        onCloseForm();
      },
    },
  });

  const {
    mutateAsync: feedbackAdviceFollowViolation,
    isPending: isLoadingFeedbackAdviceFollowViolation,
  } = useFeedbackAdviceFollowViolation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(
              titlePopup ?? `followViolation.advisor.title.titlePopupFeedback`
            ),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_violation_next_action_query"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_violation_query"],
        });
        queryClient.invalidateQueries({
          queryKey: [SearchPanelQueries.GET_HIERARCHY],
        });
        onCloseForm();
      },
    },
  });

  const {
    mutateAsync: updateAdvisorFollowViolationDetail,
    isPending: isLoadingUpdateAdvisorFollowViolationDetail,
  } = useUpdateAdvisorFollowViolationDetail({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(
              titlePopup ?? `followViolation.advisor.title.titlePopupFeedback`
            ),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_violation_next_action_query"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_violation_query"],
        });
        queryClient.invalidateQueries({
          queryKey: [SearchPanelQueries.GET_HIERARCHY],
        });
        onCloseForm();
      },
    },
  });

  /**
   * Set values to form
   */
  useEffect(() => {
    const advisorList = getAdvisorFollowViolationList;

    if (currentAdvice?.id) {
      form.reset({
        [AdvisorFollowViolationFieldNames.CONTENT]:
          currentAdvice?.content ?? "",
      });
    }

    if (isFeedBackAdvice && Array.isArray(advisorList) && advisorList.length) {
      const newUsers = advisorList.reduce((acc: any, cur: any) => {
        if (!acc.some((a: any) => a?.id === cur?.createBy?.id)) {
          acc.push(cur?.createBy);
        }
        return acc;
      }, []);

      form.setValue(AdvisorFollowViolationFieldNames.USERS, newUsers);
    } else if ((isAdvice || isSuperviorAdvisor) && createBy?.id) {
      const newUser = {
        ...createBy,
        nameEnglish: createBy?.nameEnglish || createBy?.name,
      };

      form.setValue(AdvisorFollowViolationFieldNames.USERS, [newUser]);
    } else {
    }
  }, [
    form,
    isAdvice,
    isSuperviorAdvisor,
    isFeedBackAdvice,
    currentAdvice,
    createBy,
    getAdvisorFollowViolationList,
  ]);

  /**
   * Get users for feedback advice case
   */
  const getUsersForFeedbackAdviceCase = (
    advisors: ResponsesAdvisorFollowViolationDTO[],
    keyword: string
  ) => {
    let users = Array.isArray(advisors) && advisors.length ? [...advisors] : [];
    users = users
      .filter((item) => {
        const _keyword =
          keyword !== null && keyword !== undefined ? keyword : "";
        const name =
          item?.createBy?.name !== null && item?.createBy?.name !== undefined
            ? item?.createBy?.name
            : "";
        const email =
          item?.createBy?.email !== null && item?.createBy?.email !== undefined
            ? item?.createBy?.email
            : "";

        return (
          name
            .toString()
            .trim()
            .toLowerCase()
            .indexOf(_keyword.toString().trim().toLowerCase()) > -1 ||
          email
            .toString()
            .trim()
            .toLowerCase()
            .indexOf(_keyword.toString().trim().toLowerCase()) > -1
        );
      })
      .map((item) => item?.createBy);

    return users;
  };

  /**
   * On change type
   */
  const onChangeType = async (val: any) => {
    form.reset({
      [AdvisorFollowViolationFieldNames.TYPE]: val,
      [AdvisorFollowViolationFieldNames.USERS]: [],
    });

    // Gửi tới giám sát, set user là deptHead
    if (val === TypeAdvisorFollowViolation.toSupervisor) {
      const headOfLC = await getDepartmentHeads(sender?.department?.id);

      form.setValue(
        AdvisorFollowViolationFieldNames.USERS,
        headOfLC?.deptHead?.id ? [headOfLC?.deptHead] : []
      );
    }

    // Gửi tới người yêu cầu tư vấn, set user là người tạo
    else if (val === TypeAdvisorFollowViolation.toPic && createBy?.id) {
      form.setValue(AdvisorFollowViolationFieldNames.USERS, [createBy]);
    }

    // Khi giám sát tư vấn mà chọn Gửi tới người tư vấn, set user là người tư vấn
    else if (isSuperviorAdvisor && val === TypeAdvisorFollowViolation.toUser) {
      let advisorList = getAdvisorFollowViolationList;
      advisorList =
        Array.isArray(advisorList) && advisorList.length
          ? [...advisorList]
          : [];

      const foundAdvide = advisorList.find((item) => !item?.isSupervisor);

      form.setValue(
        AdvisorFollowViolationFieldNames.USERS,
        foundAdvide?.createBy?.id ? [foundAdvide?.createBy] : []
      );
    } else {
    }
  };

  /**
   * On close form
   */
  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  /**
   * On submit
   */
  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { ...restData } = data;

    // Update advice
    if (currentAdvice?.id) {
      await updateAdvisorFollowViolationDetail({
        violationId,
        adviseId: currentAdvice?.id,
        data: {
          type: restData?.type,
          content: restData?.content,
          finish: restData?.type === TypeAdvisorFollowViolation.toPic,
          attachmentIds: restData?.attachmentIds,
          userIds: restData?.userIds,
          remind: restData?.remind,
        },
      });
      return;
    }

    // Feedback advice
    else if (isFeedBackAdvice) {
      await feedbackAdviceFollowViolation({
        violationId,
        data: {
          content: restData?.content,
          deadline: restData?.deadline,
          attachmentIds: restData?.attachmentIds,
          userIds: restData?.userIds,
          remind: restData?.remind,
        },
      });
      return;
    }

    // Create advice
    else {
      await createAdvisorFollowViolation({
        violationId,
        data: {
          type: restData?.type,
          content: restData?.content,
          finish: restData?.type === TypeAdvisorFollowViolation.toPic,
          attachmentIds: restData?.attachmentIds,
          userIds: restData?.userIds,
          remind: restData?.remind,
        },
      });
    }
  };

  if (isLoadingAdvisorFollowViolationList) return;

  return (
    <ModalCommon
      title={t(
        titlePopup ??
          `followViolation.advisor.title.${
            isSuperviorAdvisor
              ? "titlePopupSupervisor"
              : isFeedBackAdvice
              ? "titlePopupFeedback"
              : "titlePopupAdvice"
          }`
      )}
      open={isOpen}
      onClose={onCloseForm}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.advisor.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {isSuperviorAdvisor
                    ? t(`followViolation.advisor.title.supervisor`)
                    : isFeedBackAdvice
                    ? t(`followViolation.advisor.title.feedbackPerson`)
                    : t(`followViolation.advisor.title.consultant`)}
                </label>
                <Typography>
                  {sender?.name} ({sender?.email}) - {sender?.department?.name}
                </Typography>
              </Grid>

              {(isSuperviorAdvisor || isFeedBackAdvice) &&
                Array.isArray(getAdvisorFollowViolationList) &&
                getAdvisorFollowViolationList.length && (
                  <ListAdvisorFollowViolation
                    data={
                      isSuperviorAdvisor
                        ? getAdvisorFollowViolationList.filter(
                            (item) => !item?.isSupervisor
                          )
                        : getAdvisorFollowViolationList
                    }
                  />
                )}

              {!isFeedBackAdvice && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={(isSuperviorAdvisor
                      ? AdviceSupervisorFvOptions
                      : AdviceFvOptions
                    ).map((item) => {
                      return {
                        label: t(`${item?.label}`),
                        value: item?.value,
                      };
                    })}
                    name={AdvisorFollowViolationFieldNames.TYPE}
                    error={
                      form.formState.errors[
                        AdvisorFollowViolationFieldNames.TYPE
                      ] as FieldError
                    }
                    defaultValue={
                      (!currentAdvice?.isSupervisor
                        ? AdviceFvOptions
                        : AdviceSupervisorFvOptions)[0]?.value as number
                    }
                    onChangeRadioGroup={(e, val) => onChangeType(val)}
                  />
                </Grid>
              )}

              {!isFeedBackAdvice && (
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={AdvisorFollowViolationFieldNames.CONTENT}
                    label={t(
                      `followViolation.advisor.title.${AdvisorFollowViolationFieldNames.CONTENT}`
                    )}
                    placeHolder={t(
                      `followViolation.advisor.placeHolder.${AdvisorFollowViolationFieldNames.CONTENT}`
                    )}
                    minRows={3}
                    required
                    disabled={isFeedBackAdvice}
                  />
                </Grid>
              )}

              {!isFeedBackAdvice && (
                <Grid item width={"100%"}>
                  <DropPreviewFileUploadComponent
                    dropView
                    preview={false}
                    files={files}
                    setFiles={setFiles}
                    title={t(`followViolation.advisor.title.file`)}
                    inputId="advisorFollowViolation"
                  />
                </Grid>
              )}

              {isFeedBackAdvice && (
                <>
                  <Grid item width={"100%"}>
                    <DateTimeInput
                      name={AdvisorFollowViolationFieldNames.DEADLINE}
                      control={form.control}
                      label={t(`followViolation.advisor.title.newDeadline`)}
                      placeholder="dd/mm/yyyy hh:mm"
                      minDate={isFeedBackAdvice ? minDateAdvisor : undefined}
                      required
                    />
                  </Grid>

                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={AdvisorFollowViolationFieldNames.CONTENT}
                      label={t(`followViolation.advisor.title.reason`)}
                      placeHolder={t(
                        `followViolation.advisor.placeHolder.reason`
                      )}
                      minRows={3}
                      required
                    />
                  </Grid>
                </>
              )}

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={AdvisorFollowViolationFieldNames.USERS}
                  label={
                    isSuperviorAdvisor
                      ? t("followViolation.advisor.title.receiver")
                      : t("followViolation.advisor.title.receiver")
                  }
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    let users = [] as any[];

                    if (isFeedBackAdvice) {
                      const advisors =
                        getAdvisorFollowViolationList as ResponsesAdvisorFollowViolationDTO[];
                      users = getUsersForFeedbackAdviceCase(advisors, keyword);
                    } else {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);
                      users = response?.users as UserProfileDTO[];
                      users =
                        Array.isArray(users) && users.length ? [...users] : [];
                    }

                    if (
                      form?.watch(AdvisorFollowViolationFieldNames.TYPE) ===
                      TypeAdvisorFollowViolation.toSupervisor
                    ) {
                      let advisorList = getAdvisorFollowViolationList;
                      advisorList =
                        Array.isArray(advisorList) && advisorList.length
                          ? [...advisorList]
                          : [];

                      users = users.filter((user) => {
                        return (
                          user?.id !== createBy?.id &&
                          user?.id !== sender?.id &&
                          !advisorList.some(
                            (u: any) => user?.id === u?.createBy?.id
                          )
                        );
                      });
                    }

                    return users.map((user: any) => ({
                      id: user?.id,
                      name: user?.name ?? "",
                      departmentName: user?.department?.name,
                      email: user?.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"advisorFollowViolation/queryUser"}
                  isFocus
                  required={isSuperviorAdvisor}
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={AdvisorFollowViolationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave={`common.button.${isFeedBackAdvice ? "verify" : "send"}`}
              loading={
                isLoadingCreateAdvisorFollowViolation ||
                isLoadingFeedbackAdviceFollowViolation ||
                isLoadingUpdateAdvisorFollowViolationDetail ||
                isLoadingAdvisorFollowViolationList
              }
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit(
                    castAdvisorFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                      attachmentIds: attachments,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
