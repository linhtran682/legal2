import React from "react";
import { useTranslation } from "react-i18next";
import { Box, Grid, InputLabel, TextField, Typography } from "@mui/material";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import {
  AdvisorFollowViolationFieldNames,
  ResponsesAdvisorFollowViolationDTO,
} from "@/models/follow_violation/AdvisorFollowViolation";
import { GLOBAL_SPACING } from "@/constants/format";
import { COLOR_TYPE } from "@/constants/color";

type TypePropsListAdvisorLegal = {
  data?: ResponsesAdvisorFollowViolationDTO[];
};

export const ListAdvisorFollowViolation = (
  props: TypePropsListAdvisorLegal
) => {
  const { data } = props;
  const { t } = useTranslation();

  return (
    <>
      {Array.isArray(data) &&
        data.length > 0 &&
        data?.map((advise) => {
          const attachmentsItem = advise?.attachments?.map((item: any) => {
            return {
              name: item?.fileName,
              path: item?.filePath,
              id: item?.fileId,
              uploadDate: item?.uploadDate,
            };
          });

          return (
            <Grid
              key={advise?.id}
              container
              direction={"column"}
              className="form-sub-section-wrapper"
              rowGap={GLOBAL_SPACING}
              position={"relative"}
              sx={{
                backgroundColor: advise.isSupervisor
                  ? COLOR_TYPE.BLUE.BLUE06
                  : undefined,
              }}
            >
              <Grid item xs={12} display={"flex"}>
                <Box flex={1}>
                  <InputLabel required>
                    {advise.isSupervisor
                      ? t("followViolation.advisor.title.titlePopupSupervisor")
                      : t("followViolation.advisor.title.consultant")}
                  </InputLabel>
                  <Typography>
                    {advise.createBy.name} ({advise.createBy.email}) -{" "}
                    {advise.createBy.department?.name}
                  </Typography>
                </Box>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel required>
                  {t(
                    `followViolation.advisor.title.${AdvisorFollowViolationFieldNames.CONTENT}`
                  )}
                </InputLabel>

                <TextField
                  value={advise?.content}
                  placeholder={t(
                    `followViolation.advisor.placeHolder.${AdvisorFollowViolationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  multiline
                  fullWidth
                  disabled
                />
              </Grid>

              {Array.isArray(attachmentsItem) && attachmentsItem.length > 0 && (
                <Grid item width={"100%"}>
                  <DropPreviewFileUploadComponent
                    title={t(
                      `followViolation.label.${AdvisorFollowViolationFieldNames.ATTACHMENTS}`
                    )}
                    files={attachmentsItem as any}
                    setFiles={() => {}}
                    preview
                    disabled
                    inputId={`file-input-${advise?.id}`}
                  />
                </Grid>
              )}
            </Grid>
          );
        })}
    </>
  );
};
