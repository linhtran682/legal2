import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useTranslation } from "react-i18next";
// import { ViolationTimeExtensionForm } from "./ViolationTimeExtensionForm";
import {
  ApprovalRecord,
  FollowViolationDetail,
} from "@/models/follow_violation/FormType";

export interface Props {
  queryKey: string;
  getData: () => Promise<ApprovalRecord[]>;
  violationId?: number;
  violation?: FollowViolationDetail;
}

export const ViolationApproval = ({
  violation,
  violationId,
  queryKey,
  getData,
}: Props) => {
  const { i18n, t } = useTranslation();
  // const [extendDeadlineId, setExtendDeadlineId] = useState<number>();
  // const [isOpenTimeExtension, setIsOpenTimeExtension] = useState<boolean>(false);

  const getExtendRecordsQuery = useQuery({
    queryKey: [queryKey],
    queryFn: () => getData(),
  });

  const TableColumns: StandardSimpleTableColumn<ApprovalRecord>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +params?.id + 1,
    },
    {
      key: "department",
      label: "metadata.extend.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.department?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.extend.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "content",
      label: "followViolation.label.contentReson",
      type: "string",
      flex: 1,
    },
    {
      key: "deadline",
      label: "followViolation.label.deadline",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row.deadline
          ? format(new Date(params.row.deadline), "dd/MM/yyyy")
          : "",
    },
    {
      key: "status",
      label: "metadata.extend.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row.status
          ? t(`followViolation.approvalStatus.${params.row.status}`)
          : "",
    },
    // {
    //   key: "actionType",
    //   label: "Action",
    //   type: "string",
    //   flex: 1,
    //   renderCell: (params) => {
    //     return params.row?.showExtension ? (
    //       <Button disabled={!params.row?.enableExtension} onClick={() => handleClickExtend(params?.row)}>
    //         {t("followViolation.action.extend")}</Button>
    //     ) : (
    //       <></>
    //     );
    //   },
    // },
  ];

  if (!violation || !violationId) {
    return;
  }

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={TableColumns}
        data={getExtendRecordsQuery?.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
      {/* {(isOpenTimeExtension && extendDeadlineId && violationId && violation?.name) && (
        <TimeExtensionFollowViolationForm
          setIsOpen={(state) => setIsOpenTimeExtension(state)}
          violationId={violationId}
          initialValue={{}}
          isOpen={isOpenTimeExtension}
          timeExtensionRequestId={extendDeadlineId}
          name={violation?.name}
          sender={appContext?.me}
          isConfirmExtension
          handleSubmit={async () =>
            await queryClient.invalidateQueries(queryKey as any)
          }
        />
      )} */}
    </div>
  );
};
