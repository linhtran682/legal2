import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Card, Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import moment from "moment";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import { castFeedBackFollowViolationRequestSchemaToDTO } from "@/models/follow_violation/FeedBackFollowViolation";
import {
  ConfirmExtensionFollowViolationType,
  ConfirmExtensionRequestFvSchema,
  ExtensionFvOptions,
  TimeExtensionRequestFvFieldNames,
  TimeExtensionRequestFvSchema,
  TimeExtensionRequestFvSchemaI,
} from "@/models/follow_violation/TimeExtensionFollowViolation";
import {
  useCreateTimeExtensionFv,
  useUpdateTimeExtensionFv,
} from "@/apis/service/follow_violation/timeExtensionFollowViolation";
import { useQueryClient } from "@tanstack/react-query";
import { SearchPanelQueries } from "../SearchPanel";

const initialEmptyValue: TimeExtensionRequestFvSchemaI = {
  [TimeExtensionRequestFvFieldNames.DEADLINE]: "",
  [TimeExtensionRequestFvFieldNames.REASON]: "",
  [TimeExtensionRequestFvFieldNames.USERS]: [],
  [TimeExtensionRequestFvFieldNames.REMIND]: undefined,
};

export interface TimeExtensionFollowViolationFormProps {
  titlePopup?: string;
  initialValue?: TimeExtensionRequestFvSchemaI;
  violationId?: number;
  timeExtensionRequest?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  isConfirmExtension?: boolean;
  name?: string;
  handleSubmit?: any;
  module?: number;
  sender?: any;
  createBy?: any;
}

export const TimeExtensionFollowViolationForm = (
  props: TimeExtensionFollowViolationFormProps
) => {
  const {
    titlePopup,
    initialValue = initialEmptyValue,
    violationId,
    timeExtensionRequest,
    isOpen = false,
    setIsOpen,
    isConfirmExtension = false,
    name,
    handleSubmit,
    module = Module.get(ModuleKeys.ADVISE),
    sender,
    createBy,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  // const { data: getDataTimeExtensionFv, isLoading } = useGetTimeExtensionFv({
  //   request: { violationId, timeExtensionRequestId },
  //   config: {
  //     enabled: !!violationId && !!timeExtensionRequestId && isConfirmExtension,
  //   },
  // });

  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmExtension
        ? TimeExtensionRequestFvSchema.concat(ConfirmExtensionRequestFvSchema)
        : TimeExtensionRequestFvSchema
    ),
    defaultValues: initialValue,
  });

  const { mutateAsync: createTimeExtensionFv, isPending } =
    useCreateTimeExtensionFv({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(
                titlePopup ??
                  `followViolation.timeExtension.title.${
                    isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                  }`
              ),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_violation_next_action_query"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_violation_query"],
          });
          queryClient.invalidateQueries({
            queryKey: [SearchPanelQueries.GET_HIERARCHY],
          });
          onCloseForm();
        },
      },
    });

  const {
    mutateAsync: updateTimeExtensionFv,
    isPending: isLoadingUpdateTimeExtension,
  } = useUpdateTimeExtensionFv({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(
              titlePopup ??
                `followViolation.timeExtension.title.${
                  isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                }`
            ),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_violation_next_action_query"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_violation_query"],
        });
        queryClient.invalidateQueries({
          queryKey: [SearchPanelQueries.GET_HIERARCHY],
        });
        onCloseForm();
      },
    },
  });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  useEffect(() => {
    if (isConfirmExtension && timeExtensionRequest) {
      const { user, ...restGetDataTimeExtension } = timeExtensionRequest;

      form.reset({
        ...restGetDataTimeExtension,
        [TimeExtensionRequestFvFieldNames.CONFIRM]:
          ConfirmExtensionFollowViolationType.APPROVE,
        [TimeExtensionRequestFvFieldNames.DEADLINE]:
          timeExtensionRequest?.requestDeadline
            ? moment.utc(timeExtensionRequest?.requestDeadline).local().toDate()
            : undefined,
        users: [user],
      });
    } else if (!isConfirmExtension) {
      form.reset({
        [TimeExtensionRequestFvFieldNames.USERS]: [createBy],
      });
    } else {
    }
  }, [form, isConfirmExtension, createBy, timeExtensionRequest]);

  const onSubmit = async (values: any) => {
    const users =
      Array.isArray(values?.users) && values?.users.length
        ? [...values?.users].map((item) => item?.id)
        : [];

    const isNewDeadline =
      values?.confirm === ConfirmExtensionFollowViolationType.NEW_DEADLINE;

    if (isConfirmExtension) {
      await updateTimeExtensionFv({
        violationId,
        timeExtensionRequestId: timeExtensionRequest?.id,
        data: {
          remind: values?.remind,
          users,
          type: values?.confirm,
          ...(isNewDeadline && {
            deadlineAccept: values?.acceptableDeadline,
            reason: values?.acceptableReason,
          }),
        },
      });

      handleSubmit && handleSubmit();
      return;
    }

    await createTimeExtensionFv({
      violationId,
      data: {
        ...values,
        users,
      },
    });
  };

  return (
    <ModalCommon
      title={t(
        titlePopup ??
          `followViolation.timeExtension.title.${
            isConfirmExtension ? "titlePopup" : "titlePopupRequest"
          }`
      )}
      open={isOpen}
      onClose={onCloseForm}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("followViolation.timeExtension.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t("followViolation.timeExtension.title.sender")}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Card
                style={
                  isConfirmExtension
                    ? {
                        width: "100%",
                        padding: 15,
                        marginBottom: 10,
                      }
                    : {
                        width: "100%",
                        boxShadow: "none",
                        padding: 0,
                        marginBottom: 0,
                      }
                }
              >
                {isConfirmExtension && (
                  <Typography fontWeight="bold" sx={{ mb: 2.5 }}>
                    {t("followViolation.timeExtension.title.textName")}
                  </Typography>
                )}

                <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                  <DateTimeInput
                    name={TimeExtensionRequestFvFieldNames.DEADLINE}
                    control={form.control}
                    label={t(`followViolation.timeExtension.title.newDeadline`)}
                    placeholder="dd/mm/yyyy hh:mm"
                    minDate={new Date()}
                    required={!isConfirmExtension}
                    disabled={isConfirmExtension}
                  />
                </Grid>

                <Grid item width={"100%"} sx={{ mb: 0.5 }}>
                  <FormTextArea
                    control={form.control}
                    name={TimeExtensionRequestFvFieldNames.REASON}
                    label={t(`followViolation.timeExtension.title.reason`)}
                    placeHolder={t(
                      `followViolation.timeExtension.placeHolder.reason`
                    )}
                    minRows={3}
                    required={!isConfirmExtension}
                    disabled={isConfirmExtension}
                  />
                </Grid>
              </Card>

              {isConfirmExtension && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={ExtensionFvOptions}
                    name={TimeExtensionRequestFvFieldNames.CONFIRM}
                    error={
                      form.formState.errors[
                        TimeExtensionRequestFvFieldNames.CONFIRM
                      ] as FieldError
                    }
                  />
                </Grid>
              )}

              {isConfirmExtension &&
                form?.watch(TimeExtensionRequestFvFieldNames.CONFIRM) ===
                  ConfirmExtensionFollowViolationType.NEW_DEADLINE && (
                  <>
                    <Grid item width={"100%"}>
                      <DateTimeInput
                        name={
                          TimeExtensionRequestFvFieldNames.ACCEPTABLE_DEADLINE
                        }
                        control={form.control}
                        label={t(
                          `followViolation.timeExtension.title.newDeadlineAccept`
                        )}
                        placeholder="dd/mm/yyyy hh:mm"
                        minDate={new Date()}
                        required
                      />
                    </Grid>
                    <Grid item width={"100%"}>
                      <FormTextArea
                        control={form.control}
                        name={
                          TimeExtensionRequestFvFieldNames.ACCEPTABLE_DEADLINE_REASON
                        }
                        label={t(`followViolation.timeExtension.title.reason`)}
                        placeHolder={t(
                          `followViolation.timeExtension.placeHolder.reason`
                        )}
                        minRows={3}
                        required
                      />
                    </Grid>
                  </>
                )}

              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={TimeExtensionRequestFvFieldNames.USERS}
                    label={t(
                      "followViolation.timeExtension.title.personDocument"
                    )}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"timeExtensionDocumentManagement/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={TimeExtensionRequestFvFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave={`common.button.${
                isConfirmExtension ? "confirm" : "send"
              }`}
              loading={isPending || isLoadingUpdateTimeExtension}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...castFeedBackFollowViolationRequestSchemaToDTO({
                      ...form.getValues(),
                    }),
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
