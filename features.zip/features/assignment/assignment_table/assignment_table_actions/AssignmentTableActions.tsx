import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { deleteAssignment } from "@/apis/service/assignment/Assignment";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { ASSIGNMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { GridRenderCellParams } from "@mui/x-data-grid";
import { AssignmentTableEnum } from "../AssignmentTable";

export const AssignmentTableActions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  const queryClient = useQueryClient();

  const deleteRoleQuery = useMutation({
    mutationFn: deleteAssignment,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.assignment"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [AssignmentTableEnum.GET_LIST_QUERY_KEY],
      });
    },
  });

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_status",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`),
          tooltipTitle: t("common.button.update"),
        },
        {
          key: "delete_status",
          icon: <DeleteIcon color='primary' />,
          onClick: (params) =>
            params.id && deleteRoleQuery.mutate(params?.id as number),
          tooltipTitle: t("common.button.delete"),
          confirmPopupProps: {
            icon: <DeleteRecordDialogIcon />,
            title: t("common.message.confirm_delete"),
          },
        },
      ]}
    />
  );
};
