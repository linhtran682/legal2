import { getAssignments } from "@/apis/service/assignment/Assignment";
import StandardTable, {
  DEFAULT_PAGE_MODAL,
  StandardTableColumn,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { ASSIGNMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import {
  AssignmentColumnNames,
  GetAssignmentsParams,
} from "@/models/assignment/Assignment";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { AssignmentTableActions } from "./assignment_table_actions/AssignmentTableActions";
import { Tooltip } from "@mui/material";
import { uniqueId } from "lodash";

const assignmentTableColumns: StandardTableColumn[] = [
  {
    key: AssignmentColumnNames.ID,
    label: AssignmentColumnNames.ID,
    type: "string",
    filterable: false,
    sortable: false,
    hideable: false,
    maxWidth: 52,
    cellClassName: (params) => params.row?.draft ? 'draft' : ''
  },
  {
    key: AssignmentColumnNames.FULL_NAME,
    label: AssignmentColumnNames.FULL_NAME,
    renderCell: (params) => params?.row?.assignedPerson?.name,
    type: "string",
    filterable: false,
    sortable: false,
    hideable: false,
    minWidth: 200,
    flex: 1,
    cellClassName: (params) => params.row?.draft ? 'draft' : ''
  },
  {
    key: AssignmentColumnNames.DEPARTMENT,
    label: AssignmentColumnNames.DEPARTMENT,
    renderCell: (params) => (params?.row?.assignedPerson?.department?.name),
    type: "string",
    filterable: false,
    sortable: false,
    hideable: false,
    minWidth: 240,
    flex: 1,
    cellClassName: (params) => params.row?.draft ? 'draft' : ''
  },
  {
    key: AssignmentColumnNames.MANAGED_DEPARTMENTS,
    label: AssignmentColumnNames.MANAGED_DEPARTMENTS,
    type: "string",
    renderCell: (params) => <Tooltip
      placement="bottom-start"
      title={
        params?.row?.managedDepartments
          ?.map((ele: any) => <p key={uniqueId('dept_name_')}>{ele?.name}</p>)
      }>{
        params?.row?.managedDepartments
          ?.map((ele: any) => ele?.name)
          ?.join(", ")
      }
    </Tooltip>,
    filterable: false,
    sortable: false,
    hideable: false,
    flex: 2,
    minWidth: 300,
    cellClassName: (params) => params.row?.draft ? 'draft' : ''
  },
  {
    key: AssignmentColumnNames.MANAGED_USERS,
    label: AssignmentColumnNames.MANAGED_USERS,
    type: "string",
    renderCell: (params) => (
      <Tooltip
        placement="bottom-start"
        title={
          params?.row?.managedUsers
            ?.map((ele: any) => <p key={uniqueId('emp_name_')}>{ele?.name} - {ele?.department?.name}</p>)
        }>
        {params?.row?.managedUsers
          ?.map((ele: any) => `${ele?.name} - ${ele?.department?.name}`)
          ?.join(", ")}
      </Tooltip>
    ),
    filterable: false,
    sortable: false,
    hideable: false,
    flex: 2,
    minWidth: 300,
    cellClassName: (params) => params.row?.draft ? 'draft' : ''
  },
  {
    key: "action",
    label: "",
    type: undefined,
    renderCell: AssignmentTableActions,
    filterable: false,
    sortable: false,
    hideable: false,
    cellClassName: "last-column-sticky",
    headerClassName: 'last-column-sticky-header',
  },
];

export enum AssignmentTableEnum {
  TABLE_NAME = "RoleTable",
  GET_LIST_QUERY_KEY = "assignment/get-assignment-list",
}

const castTableStateToParams = (
  tableState: StandardTableState
): GetAssignmentsParams => {
  const params: GetAssignmentsParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
  };
  return params;
};

const AssignmentTable = () => {
  const router = useRouter();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });
  const { data, isFetching, refetch } = useQuery({
    queryKey: [AssignmentTableEnum.GET_LIST_QUERY_KEY],
    queryFn: async () =>
      await getAssignments(castTableStateToParams(tableState)),
  });

  useEffect(() => {
    tableState && refetch();
  }, [tableState]);

  return (
    <StandardTable
      data={data?.assignments ?? []}
      columns={assignmentTableColumns
        .map((column) => ({
          ...column,
          label: column.label && `assignment.column.${column.label}`,
        }))}
      getRowId={(item) => item?.id?.toString()}
      loading={isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={data?.total}
      onRowClick={(params) => {
        router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`);
      }}
      hideRowCheckbox
    />
  );
};

export default AssignmentTable;
