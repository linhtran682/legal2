import { getDepartments } from "@/apis/service/department/department";
import { getUser, getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
// import renderUserOptions from "@/components/commons/user_option";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
// import { LANGUAGES } from "@/locales/config-translation";
import {
  AssignmentDTO,
  SaveAssignmentRequestSchema,
} from "@/models/assignment/Assignment";
import { Department } from "@/models/department/Department";
import { GetUsersParams, UserProfileDTO } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { FC, useContext, useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveAssignmentFormProps {
  formMode: "create" | "update";
  initialValue?: AssignmentDTO;
  onSubmit: (data: any) => void;
  onDelete?: () => void;
  onSubmitDraft?: (data: any) => void;
  onCancel: () => void;
  loading?: boolean;
}

const initialEmptyValue = {
  departments: [],
  assignedPersonId: null,
  managedDepartments: undefined,
  managedUsers: [],
};

const SaveAssignmentForm: FC<SaveAssignmentFormProps> = (props) => {
  const formRef = useRef<HTMLFormElement>(null);
  const { t } = useTranslation();
  // const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const [selectedUser, setSelectedUser] = useState<UserProfileDTO | null | undefined>(null);

  const form = useForm<any>({
    resolver: yupResolver(SaveAssignmentRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });
  useEffect(() => {
    props.initialValue &&
      form.reset({
        assignedPersonId: props?.initialValue?.assignedPerson?.id,
        managedDepartments: props?.initialValue?.managedDepartments?.map(
          (ele: any) => ele?.id
        ),
        departments: props.initialValue?.assignedPerson?.department
          ? [props.initialValue.assignedPerson.department?.id]
          : [],
        managedUsers: props?.initialValue?.managedUsers
      });
  }, [props.initialValue]);

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <form ref={formRef}>
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className='form-section-wrapper'
            sx={formInputSxProps}
          >
            <Grid
              container
              rowSpacing={1}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
              sx={formInputSxProps}
            >
              <Grid item xs={6}>
                <FormSelectTreeView
                  name={"departments"}
                  control={form.control}
                  label={t("assignment.column.assignedPerson")}
                  getOptions={async (keyword) => {
                    try {
                      const response = await getDepartments({
                        searchTerm: keyword,
                      });
                      const first100Departments: Department[] = (
                        response?.departments ?? []
                      ).slice(0, 150);
                      return first100Departments; // Assuming the data is in response.data
                    } catch (e) {
                      return [];
                    }
                  }}
                  getOptionLabel={(option) => option.name ?? ""}
                  getOptionKey={(option) => option.id ?? ""}
                  getOptionChildren={(option) => option.children}
                  variant='outlined'
                  debounceMs={FILTER_DEBOUNCE_MS}
                  onChange={(value: Department[]) => {
                    const mappedValue: string[] = value.map(
                      (item) => item.id ?? ""
                    ) || [];
                    form.setValue("departments", mappedValue);
                    if (!mappedValue?.includes(selectedUser?.department?.id as string)) {
                      form.setValue('assignedPersonId', null);
                    }
                  }}
                  rules={{ required: "This field is required" }}
                  selectedItemsProp={
                    props?.initialValue?.assignedPerson?.department
                      ? [props.initialValue.assignedPerson.department!]
                      : undefined
                  }
                  required
                  ignoreChildren
                />
              </Grid>
              <Grid item xs={6} sx={{ marginTop: '24px' }}>
                <FormAsyncSelect<any, UserProfileDTO>
                  control={form.control}
                  name={"assignedPersonId"}
                  label={""}
                  minCharLength={1}
                  placeholder={t('assignment.column.user')}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const selectedDepartments = form.getValues("departments")
                      if (selectedDepartments.length) {
                        params.departmentIds = selectedDepartments
                      }
                      const response = await getUsers(params);

                      return response?.users ?? [];
                    } else if (keyword?.length && keyword.length > 0) {
                      return getUser(keyword[0])
                        .then((response) => (response ? [response] : []))
                        .catch(() => []);
                    }

                    return [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? ""
                    }`
                  }
                  onChange={(_, option) => {
                    setSelectedUser(option)
                  }}
                  getOptionKey={(option) => option.id}
                  // renderOption={(optionProps, option, selected) => renderUserOptions(
                  //   optionProps,
                  //   option,
                  //   selected,
                  //   i18n.language === LANGUAGES.ENGLISH,
                  //   false
                  // )}
                  keyQuery={"assignment/queryUser"}
                  isFocus={true}
                />
              </Grid>
            </Grid>

            <Grid item width={"100%"}>
              <FormSelectTreeView
                name={"managedDepartments"}
                control={form.control}
                label={t("assignment.column.managedDepartments")}
                getOptions={async (keyword) => {
                  try {
                    const response = await getDepartments({
                      searchTerm: keyword,
                    });
                    const first100Departments: Department[] = (
                      response?.departments ?? []
                    ).slice(0, 150);
                    return first100Departments; // Assuming the data is in response.data
                  } catch (e) {
                    return [];
                  }
                }}
                getOptionLabel={(option) => option.name ?? ""}
                getOptionKey={(option) => option.id ?? ""}
                getOptionChildren={(option) => option.children}
                variant='outlined'
                debounceMs={FILTER_DEBOUNCE_MS}
                onChange={(value: Department[]) => {
                  const mappedValue: string[] = value.map(
                    (item) => item.id ?? ""
                  );
                  form.setValue("managedDepartments", mappedValue);
                }}
                rules={{ required: "This field is required" }}
                required
                selectedItemsProp={
                  props?.initialValue?.managedDepartments ?? undefined
                }
                ignoreChildren
              />
            </Grid>

            <Grid item width={"100%"}>
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={"managedUsers"}
                label={t("assignment.column.managedUsers")}
                placeholder={t('assignment.column.user')}
                getOptions={async (keyword) => {
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });

                  return response?.users ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? ""
                  }`
                }
                getOptionKey={(option) => option.id}
                keyQuery='queryUser'
              // renderOption={(optionProps, option, selected) => renderUserOptions(
              //   optionProps,
              //   option,
              //   selected,
              //   i18n.language === LANGUAGES.ENGLISH,
              //   true
              // )}
              />
            </Grid>
          </Grid>
          <FormActionButtons
            formMode={props.formMode}
            allowDraft={props?.formMode !== "update" || props.initialValue?.draft}
            loading={props?.loading}
            onCancel={props?.onCancel}
            onDelete={props?.onDelete}
            onSave={async () => {
              try {
                props.onSubmit({
                  ...form.getValues(),
                  managedUsers: form.getValues('managedUsers')?.map((ele: any) => ele?.id)
                });
              } catch (error) { }
            }}
            onSaveDraft={async () => {
              try {
                props?.onSubmitDraft?.({
                  ...form.getValues(),
                  managedUsers: form.getValues('managedUsers')?.map((ele: any) => ele?.id)
                });
              } catch (error) { }
            }}
          />
        </form>
      </FormProvider>
    </Grid>
  );
};

export default SaveAssignmentForm;
