import {
  Checkbox,
  FormControlLabel,
  Grid,
  IconButton,
  Typography,
} from "@mui/material";
import { ReactElement, useEffect, useState } from "react";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  ReminderContentSchemaI,
  ReminderFieldNames,
} from "@/models/reminder_template/ReminderDTO";
import {
  RemindReceiverType,
  RemindValueType,
  RemindValueTypeKeys,
  TimeStatus,
  TimeStatusKeys,
  TimeUnit,
  TimeUnitKeys,
  VendorResponseStatus,
  VendorResponseStatusKeys,
} from "@/constants/general";
import { useTranslation } from "react-i18next";
import { useFieldArray, useFormContext } from "react-hook-form";
import AddIcon from "@mui/icons-material/Add";
import { ReminderPickerContentItem } from "./reminder_picker_content_item/ReminderPickerContentItem";

export interface ReminderPickerContentProps {
  parentName: string;
  title: string;
  children?: ReactElement;
  remindReceiverTypeKey: string;
  module?: number;
}

export const ReminderPickerContent = (props: ReminderPickerContentProps) => {
  const [t] = useTranslation();

  const formContext = useFormContext();

  const remindContentFieldArray = useFieldArray({
    name: `${props.parentName}.${ReminderFieldNames.REMIND_CONTENTS}.${
      RemindReceiverType.get(props.remindReceiverTypeKey)! - 1
    }`,
  });

  const [checked, setChecked] = useState(
    remindContentFieldArray.fields.length > 0
  );

  useEffect(() => {
    if (remindContentFieldArray.fields.length > 0) {
      setChecked(true);
    } else {
      setChecked(false);
    }
  }, [remindContentFieldArray]);

  const handleAddRemindContent = () => {
    remindContentFieldArray.append({
      remindReceiverType: RemindReceiverType.get(props.remindReceiverTypeKey)!,
      remindValueType: RemindValueType.get(RemindValueTypeKeys.TIME)!,
      timeStatus: TimeStatus.get(TimeStatusKeys.BEFORE)!,
      vendorResponseStatus:
        props.module === 1
          ? VendorResponseStatus.get(VendorResponseStatusKeys.DATE_ISSUED)!
          : VendorResponseStatus.get(
              VendorResponseStatusKeys.DEADLINE_IMPROVE_INFO
            )!,
      time: 0,
      timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
      isSend: true,
    });
  };

  const handleRemoveReminderTemplateContentItem = (actualIndex: number) => {
    remindContentFieldArray.remove(actualIndex);
  };
  return (
    <Grid container direction={"column"} spacing={GLOBAL_SPACING}>
      {!props.children && (
        <Grid item>
          <FormControlLabel
            control={
              <Checkbox
                checked={checked}
                disabled={formContext.formState.disabled}
                onChange={(e) => {
                  if (e.target.checked) {
                    if (!checked) {
                      formContext.setValue(
                        `${props.parentName}.${
                          ReminderFieldNames.REMIND_CONTENTS
                        }.${
                          RemindReceiverType.get(props.remindReceiverTypeKey)! -
                          1
                        }`,
                        [
                          {
                            remindReceiverType: RemindReceiverType.get(
                              props.remindReceiverTypeKey
                            )!,
                            remindValueType: RemindValueType.get(
                              RemindValueTypeKeys.TIME
                            )!,
                            timeStatus: TimeStatus.get(TimeStatusKeys.BEFORE)!,
                            vendorResponseStatus:
                              props.module === 1
                                ? VendorResponseStatus.get(
                                    VendorResponseStatusKeys.DATE_ISSUED
                                  )!
                                : VendorResponseStatus.get(
                                    VendorResponseStatusKeys.DEADLINE_IMPROVE_INFO
                                  )!,
                            time: 0,
                            timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
                          },
                        ]
                      );
                    }
                  } else {
                    formContext.setValue(
                      `${props.parentName}.${
                        ReminderFieldNames.REMIND_CONTENTS
                      }.${
                        RemindReceiverType.get(props.remindReceiverTypeKey)! - 1
                      }`,
                      []
                    );
                  }
                }}
              />
            }
            label={props.title}
          />
        </Grid>
      )}

      {props.children && <Grid item>{props.children}</Grid>}

      {remindContentFieldArray.fields.length > 0 && (
        <>
          <Grid item>
            <Typography variant="h5">
              {t("reminder_template.title.remind_time_setting")}
            </Typography>
          </Grid>
          <Grid item>
            <Grid container direction={"column"}>
              {remindContentFieldArray.fields.map(
                (field, index) =>
                  !Array.isArray(field) && (
                    <Grid item key={field.id}>
                      <ReminderPickerContentItem
                        parentName={props.parentName}
                        index={index}
                        field={field as unknown as ReminderContentSchemaI}
                        remindReceiverTypeKey={props.remindReceiverTypeKey}
                        handleRemoveReminderTemplateContentItem={
                          handleRemoveReminderTemplateContentItem
                        }
                        module={props.module}
                      />
                    </Grid>
                  )
              )}
              <Grid item width={"100%"}>
                <Grid container direction={"row"} justifyContent={"end"}>
                  <IconButton
                    className="red-round"
                    onClick={handleAddRemindContent}
                    disabled={formContext.formState.disabled}
                  >
                    <AddIcon />
                  </IconButton>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </>
      )}
    </Grid>
  );
};
