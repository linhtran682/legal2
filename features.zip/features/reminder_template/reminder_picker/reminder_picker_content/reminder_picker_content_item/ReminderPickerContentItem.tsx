import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  ModuleFields,
  RemindReceiverType,
  RemindValueType,
  RemindValueTypeKeys,
  TimeStatus,
  TimeUnit,
  VendorResponseStatus,
  VendorResponseStatusKeys,
} from "@/constants/general";
import {
  ReminderContentFieldNames,
  ReminderContentSchemaI,
  ReminderFieldNames,
} from "@/models/reminder_template/ReminderDTO";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { Grid, IconButton, Typography } from "@mui/material";
import { useState } from "react";

import { useFormContext } from "react-hook-form";
import { useTranslation } from "react-i18next";
import DeleteIcon from "@mui/icons-material/Delete";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { ReminderTemplateContentFieldNames } from "@/models/reminder_template/ReminderTemplateDTO";

export interface ReminderPickerContentItemProps {
  parentName: string;
  field: ReminderContentSchemaI;
  remindReceiverTypeKey: string;
  index: number;
  handleRemoveReminderTemplateContentItem: (index: number) => void;
  module?: number
}

export const ReminderPickerContentItem = (
  props: ReminderPickerContentItemProps
) => {
  const [t] = useTranslation();
  const [remindValueType, setRemindValueType] = useState(
    () => props.field.remindValueType
  );
  const [timeStatus, setTimeStatus] = useState(() => props.field.timeStatus);

  const formContext = useFormContext();
  return (
    <Grid
      container
      direction={"row"}
      wrap="nowrap"
      spacing={GLOBAL_SPACING}
      alignItems={"start"}
    >
      <Grid item xs={0.8}>
        <Typography sx={{ marginTop: "0.4rem" }}>
          {t(`reminder_template.title.reminder_content_item_no`, {
            index: props.index + 1,
          })}
        </Typography>
      </Grid>
      <Grid item xs={2}>
        <FormSelect
          control={formContext.control}
          name={[
            props.parentName,
            ReminderFieldNames.REMIND_CONTENTS,
            RemindReceiverType.get(props.remindReceiverTypeKey)! - 1,
            props.index,
            ReminderContentFieldNames.REMIND_VALUE_TYPE,
          ].join(".")}
          placeHolder={t(
            `reminder_template.field_name.${ReminderContentFieldNames.REMIND_VALUE_TYPE}`
          )}
          options={Array.from(RemindValueType.keys()).map((key) => ({
            label: t(
              `reminder_template.option.${ReminderContentFieldNames.REMIND_VALUE_TYPE}.${key}`
            ),
            value: RemindValueType.get(key)!,
          }))}
          getOptionKey={(option) => option.value}
          getOptionLabel={(option) => option.label}
          onChange={(e) => {
            setRemindValueType(e.target.value);
          }}
        />
      </Grid>
      {remindValueType == RemindValueType.get(RemindValueTypeKeys.TIME) && (
        <>
          <Grid item xs={2}>
            <FormSelect
              control={formContext.control}
              name={[
                props.parentName,
                ReminderFieldNames.REMIND_CONTENTS,
                RemindReceiverType.get(props.remindReceiverTypeKey)! - 1,
                props.index,
                ReminderContentFieldNames.TIME_STATUS,
              ].join(".")}
              placeHolder={t(
                `reminder_template.field_name.${ReminderContentFieldNames.TIME_STATUS}`
              )}
              options={Array.from(TimeStatus.keys()).map((key) => ({
                label: t(
                  `reminder_template.option.${ReminderContentFieldNames.TIME_STATUS}.${key}`
                ),
                value: TimeStatus.get(key)!,
              }))}
              getOptionKey={(option) => option.value}
              getOptionLabel={(option) => option.label}
              onChange={(e) => {
                setTimeStatus(e.target.value);
              }}
            />
          </Grid>
          <Grid item flex={3}>
            <FormSelect
              control={formContext.control}
              name={[
                props.parentName,
                ReminderFieldNames.REMIND_CONTENTS,
                RemindReceiverType.get(props.remindReceiverTypeKey)! - 1,
                props.index,
                ReminderContentFieldNames.VENDOR_RESPONSE_STATUS,
              ].join(".")}
              placeHolder={t(
                `reminder_template.field_name.${ReminderContentFieldNames.VENDOR_RESPONSE_STATUS}`
              )}
              options={Array.from(VendorResponseStatus.keys())
                .map((key) => {
                  if (
                    formContext.getValues().module === 1 || props.module === 1 &&
                    (key ===
                      VendorResponseStatusKeys.DATE_RECEIVED_FROM_VENDOR ||
                      key ===
                        VendorResponseStatusKeys.VENDOR_RESPONSE_DATE ||
                      key ===
                        VendorResponseStatusKeys.DEADLINE_FOR_SENDING ||
                      key ===
                        VendorResponseStatusKeys.DATE_REQUIRED_FOR_DEPARTMENT_RESPONSE ||
                      key === VendorResponseStatusKeys.DATE_ISSUED ||
                      key === VendorResponseStatusKeys.EFFECTIVE_DATE ||
                      key ===
                        VendorResponseStatusKeys.DEADLINE_FOR_RESPONSE ||
                      key === VendorResponseStatusKeys.APPROVE_DEADLINE ||
                      key === VendorResponseStatusKeys.TRANSITION_PERIOD)
                  ) {
                    return {
                      label: t(
                        `reminder_template.option.${ReminderTemplateContentFieldNames.VENDOR_RESPONSE_STATUS}.${key}`
                      ),
                      value: VendorResponseStatus.get(key)!,
                    };
                  } else if (
                    formContext.getValues().module === 2 || props.module === 2 &&
                    (key ===
                      VendorResponseStatusKeys.VENDOR_RESPONSE_DATE ||
                      key ===
                        VendorResponseStatusKeys.CONSULTING_PAYMENT_DEADLINE ||
                      key ===
                        VendorResponseStatusKeys.DEADLINE_IMPROVE_INFO ||
                      key === VendorResponseStatusKeys.TRANSITION_PERIOD ||
                      key ===
                        VendorResponseStatusKeys.DEADLINE_FOR_RESPONSE)
                  ) {
                    return {
                      label: t(
                        `reminder_template.option.${ReminderTemplateContentFieldNames.VENDOR_RESPONSE_STATUS}.${key}`
                      ),
                      value: VendorResponseStatus.get(key)!,
                    };
                  } else if (
                    formContext.getValues().module === 4 || props.module === 4 &&
                    (key ===
                      VendorResponseStatusKeys.VENDOR_RESPONSE_DATE ||
                      key ===
                        VendorResponseStatusKeys.CONSULTING_PAYMENT_DEADLINE ||
                      key ===
                        VendorResponseStatusKeys.DEADLINE_IMPROVE_INFO ||
                      key === VendorResponseStatusKeys.TRANSITION_PERIOD ||
                      key ===
                        VendorResponseStatusKeys.DEADLINE_FOR_RESPONSE ||
                      key ===
                        VendorResponseStatusKeys.DEADLINE_NEXT_ACTION ||
                      key === VendorResponseStatusKeys.APPROVE_DEADLINE)
                  ) {
                    return {
                      label: t(
                        `reminder_template.option.${ReminderTemplateContentFieldNames.VENDOR_RESPONSE_STATUS}.${key}`
                      ),
                      value: VendorResponseStatus.get(key)!,
                    };
                  } else if (
                    formContext.getValues().module === 5 || props.module === 5 &&
                    (key === VendorResponseStatusKeys.ISSUE_DATE ||
                      key === VendorResponseStatusKeys.MODIFICATION_DATE ||
                      key === VendorResponseStatusKeys.EXPIRATION_DATE
                      ||
                      key === VendorResponseStatusKeys.DEADLINE_IMPROVE_INFO
                     ||  key === VendorResponseStatusKeys.TRANSITION_PERIOD
                    )
                  ) {
                    return {
                      label: t(
                        `reminder_template.option.${ReminderTemplateContentFieldNames.VENDOR_RESPONSE_STATUS}.${key}`
                      ),
                      value: VendorResponseStatus.get(key)!,
                    };
                  }

                  return undefined;
                })
                .filter(
                  (option) => option !== null && option !== undefined
                )}
              getOptionKey={(option) => option.value}
              getOptionLabel={(option) => option.label}
            />
          </Grid>
          {timeStatus !== 1 && (
            <>
              <Grid item xs={2}>
                <FormTextField
                  type="number"
                  control={formContext.control}
                  name={[
                    props.parentName,
                    ReminderFieldNames.REMIND_CONTENTS,
                    RemindReceiverType.get(props.remindReceiverTypeKey)! - 1,
                    props.index,
                    ReminderContentFieldNames.TIME,
                  ].join(".")}
                  placeHolder={t(
                    `reminder_template.field_name.${ReminderContentFieldNames.TIME}`
                  )}
                  emptyIsZero
                />
              </Grid>
              <Grid item xs={2}>
                <FormSelect
                  control={formContext.control}
                  name={[
                    props.parentName,
                    ReminderFieldNames.REMIND_CONTENTS,
                    RemindReceiverType.get(props.remindReceiverTypeKey)! - 1,
                    props.index,
                    ReminderContentFieldNames.TIME_TYPE,
                  ].join(".")}
                  placeHolder={t(
                    `reminder_template.field_name.${ReminderContentFieldNames.TIME_TYPE}`
                  )}
                  options={Array.from(TimeUnit.keys()).map((key) => ({
                    label: t(
                      `common.option.${ReminderContentFieldNames.TIME_TYPE}.${key}`
                    ),
                    value: TimeUnit.get(key)!,
                  }))}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                />
              </Grid>
            </>
          )}
        </>
      )}
      {remindValueType == RemindValueType.get(RemindValueTypeKeys.STATUS) && (
        <Grid item flex={9}>
          <FormAsyncSelect
            control={formContext.control}
            name={[
              props.parentName,
              ReminderFieldNames.REMIND_CONTENTS,
              RemindReceiverType.get(props.remindReceiverTypeKey)! - 1,
              props.index,
              ReminderContentFieldNames.LEGAL_STATUS,
            ].join(".")}
            keyQuery={[
              props.parentName,
              ReminderFieldNames.REMIND_CONTENTS,
              RemindReceiverType.get(props.remindReceiverTypeKey)! - 1,
              props.index,
              ReminderContentFieldNames.LEGAL_STATUS,
            ].join(".")}
            placeholder={t(
              `reminder_template.field_name.${ReminderContentFieldNames.LEGAL_STATUS}`
            )}
            getOptions={async (keyword) => {
              if (typeof keyword == "string") {
                const response = await getStatusList({
                  name: keyword,
                  modules: [ModuleFields.LEGISLATION_NAME.module],
                  page: 0,
                  size: 100,
                  sortBy: StatusFieldNames.NAME,
                  orderBy: "ASC",
                  active: 1,
                });

                return response?.statusResponses ?? [];
              } else if (keyword?.length && keyword.length > 0) {
                return getStatus(Number(keyword[0]))
                  .then((response) => (response ? [response] : []))
                  .catch(() => []);
              }

              return [] as StatusDTO[];
            }}
            getOptionKey={(option) => option.id.toString()}
            getOptionLabel={(option) => option.name}
          />
        </Grid>
      )}
      <Grid item>
        <IconButton
          color="primary"
          onClick={() =>
            props.handleRemoveReminderTemplateContentItem(props.index)
          }
          disabled={formContext.formState.disabled}
        >
          <DeleteIcon />
        </IconButton>
      </Grid>
    </Grid>
  );
};
