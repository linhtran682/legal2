import {
  getBasedReminderTemplates,
  getPositionFn,
  getReminderTemplate,
} from "@/apis/service/reminder_template/ReminderTemplate";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  RemindReceiverType,
  RemindReceiverTypeKeys,
  RemindValueType,
  RemindValueTypeKeys,
  TimeStatus,
  TimeStatusKeys,
  TimeUnit,
  TimeUnitKeys,
  VendorResponseStatus,
  VendorResponseStatusKeys,
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import {
  BasedReminderTemplate,
  BasedReminderTemplateFieldNames,
} from "@/models/reminder_template/BaseReminderTemplate";
import {
  castReminderContentMapToMapSchema,
  PositionType,
  ReminderFieldNames,
  ReminderSchemaI,
} from "@/models/reminder_template/ReminderDTO";
import { Grid } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useFormContext, useWatch } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { ReminderPickerContent } from "./reminder_picker_content/ReminderPickerContent";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { BasedUser } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { getDepartments } from "@/apis/service/department/department";
import { Department } from "@/models/department/Department";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";

export interface ReminderPickerSubFormProps {
  name: string;
  module?: number;
  placeholder?: string;
}

const defaultEmptyValue: ReminderSchemaI = {
  id: -1,
};

export const ReminderPickerSubForm = (props: ReminderPickerSubFormProps) => {
  const [t] = useTranslation();
  const formContext = useFormContext();

  const [selectedReminderId, setSelectedReminderId] = useState(-1);

  const reminder: ReminderSchemaI = useWatch({
    control: formContext.control,
    name: props.name,
  });
  const [intialReceiveTitle, setIntialReceiveTitle] = useState<any>()
  const handleSearchReminder = async (keyword: string | string[]) => {
    if (typeof keyword == "string") {
      return getBasedReminderTemplates({
        title: keyword,
        page: 0,
        size: 100,
        orderBy: "ASC",
        sortBy: BasedReminderTemplateFieldNames.TITLE,
      })
        .then(
          (response) =>
            response?.remindBaseData.map(
              (element) => {
                if (element.module === props.module) {
                  return element
                }
                return undefined
              }
            ).filter((option) => option !== null && option !== undefined) ?? []
        )
        .catch(() => []);
    } else {
      return Promise.resolve([
        {
          id: reminder.id,
          module: reminder.module,
          title: reminder.title,
          registerTime: "",
          registerUserName: "",
        } as BasedReminderTemplate,
      ]);
    }
  };

  const getReminderTemplateQuery = useQuery({
    queryKey: ["reminder_picker", "get_reminder_template"],
    queryFn: () => {
      if (
        reminder.id == -1 ||
        !selectedReminderId ||
        selectedReminderId == -1
      ) {
        return Promise.resolve({ ...defaultEmptyValue, ...reminder });
      } else {
        return getReminderTemplate(selectedReminderId).then(
          (response): any => ({
            ...(response ?? {}),
            id: selectedReminderId,
            module: response?.module ?? -1,
            title: response?.title ?? "",
            remindContents: castReminderContentMapToMapSchema(
              response?.remindContents
            ),
            receivedTitle: response?.receivedTitle && response?.receivedTitle?.length > 0 ? response?.receivedTitle[0]?.id : undefined
          })
        );
      }
    },
    enabled: false,
  });

  useEffect(() => {
    if (reminder?.receivedTitleCopy?.[0]) {
      setIntialReceiveTitle(reminder?.receivedTitleCopy?.[0])
    }
    selectedReminderId !== -1 &&
      getReminderTemplateQuery.refetch().then((response) => {
        formContext.reset({
          ...formContext.getValues(),
          [props.name]: response.data
        });
        // formContext.resetField(props.name, {
        //   defaultValue: response.data
        // })
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedReminderId]);

  useEffect(() => {
    if (reminder?.receivedTitleCopy?.[0] && !intialReceiveTitle) {
      setIntialReceiveTitle(reminder.receivedTitleCopy[0]);
    }
  }, [reminder?.receivedTitleCopy]);
  return (
    <Grid
      direction={"column"}
      flexShrink={0}
      alignItems={"center"}
      className="form-section-wrapper"
      sx={formInputSxProps}
    >
      <Grid item width={"100%"} paddingBottom={GLOBAL_SPACING}>
        <FormAsyncSelect
          control={formContext.control}
          name={`${props.name}.${ReminderFieldNames.ID}`}
          label={t(`reminder_template.field_name.${ReminderFieldNames.TITLE}`)}
          placeholder={props?.placeholder}
          keyQuery={[props.name, ReminderFieldNames.ID].join(".")}
          getOptions={handleSearchReminder}
          getOptionKey={(option) => option.id.toString()}
          getOptionLabel={(option) => option.title}
          onChange={(selectedId) => {
            setSelectedReminderId(Number(selectedId ?? -1));
            if (!selectedId) {
              formContext.setValue(props.name, undefined)
            }
          }}
          isFocus
        />
      </Grid>

      <Grid
        container
        direction={"column"}
        spacing={GLOBAL_SPACING}
        alignItems={"center"}
      >
        {reminder?.remindContents && (
          <>
            <Grid item width={"100%"}>
              <Grid
                container
                direction={"column"}
                alignItems={"center"}
                className="form-sub-section-wrapper"
                rowGap={"2rem"}
              >
                {[
                  RemindReceiverTypeKeys.DEPT_HEAD_OF_THE_SENDER,
                  RemindReceiverTypeKeys.DIVISION_HEAD_OF_THE_SENDER,
                  RemindReceiverTypeKeys.RECEIVER,
                  RemindReceiverTypeKeys.DEPT_HEAD_OF_THE_RECIPIENT,
                  RemindReceiverTypeKeys.DIVISION_HEAD_OF_THE_RECIPIENT,
                ].map((key) => (
                  <Grid item key={key} width={"100%"}>
                    <ReminderPickerContent
                      parentName={props.name}
                      title={t(`reminder_template.title.${key}`)}
                      remindReceiverTypeKey={key}
                      module={props.module}
                    />
                  </Grid>
                ))}
              </Grid>
            </Grid>

            <Grid item width={"100%"}>
              <Grid
                container
                direction={"column"}
                alignItems={"center"}
                className="form-sub-section-wrapper"
              >
                <ReminderPickerContent
                  parentName={props.name}
                  title={t(
                    `reminder_template.title.${RemindReceiverTypeKeys.PEOPLE_INVOLVED}`
                  )}
                  remindReceiverTypeKey={RemindReceiverTypeKeys.PEOPLE_INVOLVED}
                >
                  <FormMultipleSelect<any, BasedUser>
                    control={formContext.control}
                    name={`${props.name}.${ReminderFieldNames.RELATED_USERS}`}
                    label={t(
                      `reminder_template.field_name.${ReminderFieldNames.RELATED_USERS}`
                    )}
                    placeholder={t(`common.place_holder.enter_value`, {
                      fieldName: t(
                        `reminder_template.field_name.${ReminderFieldNames.RELATED_USERS}`
                      ),
                    })}
                    getOptions={async (keyword) => {
                      const response = await getUsers({
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      });

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${option.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery="queryUser"
                    onChange={(keys) => {
                      if (
                        keys.length > 0 &&
                        (!reminder.relatedUsers ||
                          reminder.relatedUsers?.length == 0)
                      ) {
                        formContext.setValue(
                          `${props.name}.${ReminderFieldNames.REMIND_CONTENTS
                          }.${RemindReceiverType.get(
                            RemindReceiverTypeKeys.PEOPLE_INVOLVED
                          )! - 1
                          }`,
                          [
                            {
                              remindReceiverType: RemindReceiverType.get(
                                RemindReceiverTypeKeys.PEOPLE_INVOLVED
                              )!,
                              remindValueType: RemindValueType.get(
                                RemindValueTypeKeys.TIME
                              )!,
                              timeStatus: TimeStatus.get(
                                TimeStatusKeys.BEFORE
                              )!,
                              vendorResponseStatus: VendorResponseStatus.get(
                                VendorResponseStatusKeys.DATE_ISSUED
                              )!,
                              time: 0,
                              timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
                            },
                          ]
                        );
                      } else {
                        formContext.setValue(
                          `${props.name}.${ReminderFieldNames.REMIND_CONTENTS
                          }.${RemindReceiverType.get(
                            RemindReceiverTypeKeys.PEOPLE_INVOLVED
                          )! - 1
                          }`,
                          []
                        );
                      }
                    }}
                  />
                </ReminderPickerContent>
              </Grid>
            </Grid>

            <Grid item width={"100%"}>
              <Grid
                container
                direction={"column"}
                alignItems={"center"}
                className="form-sub-section-wrapper"
              >
                <ReminderPickerContent
                  parentName={props.name}
                  title={t(
                    `reminder_template.title.${RemindReceiverTypeKeys.RECEIVING_DEPARTMENT}`
                  )}
                  remindReceiverTypeKey={
                    RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                  }
                >
                  <FormSelectTreeView
                    control={formContext.control}
                    name={`${props.name}.${ReminderFieldNames.RECEIVING_DEPARTMENT}`}
                    label={t(
                      `reminder_template.field_name.${ReminderFieldNames.RECEIVING_DEPARTMENT}`
                    )}
                    placeholder={t(`common.place_holder.enter_value`, {
                      fieldName: t(
                        `reminder_template.field_name.${ReminderFieldNames.RECEIVING_DEPARTMENT}`
                      ),
                    })}
                    getOptions={async (keyword) => {
                      try {
                        const response = await getDepartments({
                          searchTerm: keyword,
                        });
                        const first100Departments: Department[] = (
                          response?.departments ?? []
                        ).slice(0, 150);
                        return first100Departments;
                      } catch (e) {
                        return [];
                      }
                    }}
                    getOptionLabel={(option) => option.name ?? ""}
                    getOptionKey={(option) => option.id ?? ""}
                    getOptionChildren={(option: any) => option.children}
                    variant="outlined"
                    debounceMs={FILTER_DEBOUNCE_MS}
                    onChange={(value: Department[]) => {
                      if (
                        value.length > 0 &&
                        (!reminder.receivingDepartment ||
                          reminder.receivingDepartment?.length == 0)
                      ) {
                        formContext.setValue(
                          `${props.name}.${ReminderFieldNames.REMIND_CONTENTS
                          }.${RemindReceiverType.get(
                            RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                          )! - 1
                          }`,
                          [
                            {
                              remindReceiverType: RemindReceiverType.get(
                                RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                              )!,
                              remindValueType: RemindValueType.get(
                                RemindValueTypeKeys.TIME
                              )!,
                              timeStatus: TimeStatus.get(
                                TimeStatusKeys.BEFORE
                              )!,
                              vendorResponseStatus: VendorResponseStatus.get(
                                VendorResponseStatusKeys.DATE_ISSUED
                              )!,
                              time: 0,
                              timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
                            },
                          ]
                        );
                      } else {
                        formContext.setValue(
                          `${props.name}.${ReminderFieldNames.REMIND_CONTENTS
                          }.${RemindReceiverType.get(
                            RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                          )! - 1
                          }`,
                          []
                        );
                      }

                      formContext.setValue(
                        `${props.name}.${ReminderFieldNames.RECEIVING_DEPARTMENT}`,
                        value
                      );
                    }}
                    rules={{ required: "This field is required" }}
                    selectedItemsProp={
                      reminder.receivingDepartment
                        ? reminder.receivingDepartment
                        : undefined
                    }
                  />
                </ReminderPickerContent>
              </Grid>
            </Grid>

            <Grid item width={"100%"}>
              <Grid
                container
                direction={"column"}
                alignItems={"center"}
                className="form-sub-section-wrapper"
              >
                <ReminderPickerContent
                  parentName={props.name}
                  title={t(
                    `reminder_template.title.${RemindReceiverTypeKeys.RECEIVED_TITLE}`
                  )}
                  remindReceiverTypeKey={RemindReceiverTypeKeys.RECEIVED_TITLE}
                >
                  <FormAsyncSelect<any, PositionType>
                    control={formContext.control}
                    name={`${props.name}.${ReminderFieldNames.RECEIVED_TITLE}`}
                    label={t(
                      `reminder_template.field_name.${ReminderFieldNames.RECEIVED_TITLE}`
                    )}
                    placeholder={t(`common.place_holder.enter_value`, {
                      fieldName: t(
                        `reminder_template.field_name.${ReminderFieldNames.RECEIVED_TITLE}`
                      ),
                    })}
                    getOptions={async (keyword) => {
                      if (typeof keyword == "string") {
                        const response = await getPositionFn(keyword);
                        return response?.positions ?? [];
                      } else if (keyword?.length && keyword.length > 0) {
                        return [intialReceiveTitle];
                      }

                      return [];
                    }}
                    getOptionLabel={(option) => `${option?.name ?? ""}`}
                    getOptionKey={(option) => option?.id}
                    keyQuery="received_title/queryRole"
                    onChange={(_, option) => {
                      setIntialReceiveTitle(option)
                      if (
                        formContext.getValues().receivedTitle
                      ) {
                        formContext.setValue(
                          `${props.name}.${ReminderFieldNames.REMIND_CONTENTS
                          }.${RemindReceiverType.get(
                            RemindReceiverTypeKeys.RECEIVED_TITLE
                          )! - 1
                          }`,
                          [
                            {
                              remindReceiverType: RemindReceiverType.get(
                                RemindReceiverTypeKeys.RECEIVED_TITLE
                              )!,
                              remindValueType: RemindValueType.get(
                                RemindValueTypeKeys.TIME
                              )!,
                              timeStatus: TimeStatus.get(
                                TimeStatusKeys.BEFORE
                              )!,
                              vendorResponseStatus: VendorResponseStatus.get(
                                VendorResponseStatusKeys.DATE_ISSUED
                              )!,
                              time: 0,
                              timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
                            },
                          ]
                        );
                      } else {
                        formContext.setValue(
                          `${props.name}.${ReminderFieldNames.REMIND_CONTENTS
                          }.${RemindReceiverType.get(
                            RemindReceiverTypeKeys.RECEIVED_TITLE
                          )! - 1
                          }`,
                          []
                        );
                      }
                    }}
                    initialValue={intialReceiveTitle as any}
                  />
                </ReminderPickerContent>
              </Grid>
            </Grid>
          </>
        )}
      </Grid>
    </Grid>
  );
};
