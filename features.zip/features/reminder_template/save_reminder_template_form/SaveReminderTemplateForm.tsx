import { Grid, Typography } from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  castReminderTemplateContentMapToMapSchema,
  GetReminderTemplateDTO,
  SaveReminderTemplateDTO,
  SaveReminderTemplateDTOFieldNames,
  SaveReminderTemplateSchema,
  SaveReminderTemplateSchemaI,
} from "@/models/reminder_template/ReminderTemplateDTO";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import {
  Module,
  RemindReceiverType,
  RemindReceiverTypeKeys,
  RemindValueType,
  RemindValueTypeKeys,
  TimeStatus,
  TimeStatusKeys,
  TimeUnit,
  TimeUnitKeys,
  VendorResponseStatus,
  VendorResponseStatusKeys,
} from "@/constants/general";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { useTranslation } from "react-i18next";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { createContext, useContext, useEffect, useState } from "react";
import { formInputSxProps } from "@/constants/theme";
import { GLOBAL_SPACING } from "@/constants/format";
import { BasicSaveForm } from "@/models/ui/form";
import { ReminderTemplateContentForm } from "./reminder_template_content_form/ReminderTemplateContentForm";
import { getUsers } from "@/apis/service/user/User";
import { BasedUser } from "@/models/user/User";
import { AppContext } from "@/context/AppContext";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { getDepartments } from "@/apis/service/department/department";
import { Department } from "@/models/department/Department";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { LANGUAGES } from "@/locales/config-translation";
import { getPositionFn } from "@/apis/service/reminder_template/ReminderTemplate";
import { PositionType } from "@/models/reminder_template/ReminderDTO";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";

export interface SaveReminderTemplateFormProps
  extends BasicSaveForm<GetReminderTemplateDTO, SaveReminderTemplateDTO> {}

interface SaveReminderTemplateFormContextI {
  changedModule: number | undefined;
}

export const SaveReminderTemplateFormContext = createContext({
  changedModule: undefined,
} as SaveReminderTemplateFormContextI);

const initialEmptyValue: SaveReminderTemplateDTO = {
  title: "",
  description: "",
  module: 1,
  remindContents: undefined,
  relatedUsers: [],
  receivedTitle: [],
  receivingDepartment: [],
};

export const SaveReminderTemplateForm = (
  props: SaveReminderTemplateFormProps
) => {
  const [t, i18n] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<any>({
    resolver: yupResolver(SaveReminderTemplateSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue &&
      form.reset({
        module: props.initialValue.module ?? -1,
        title: props.initialValue.title ?? "",
        receivedTitle: (props?.initialValue?.receivedTitle?.[0] as unknown as PositionType).id,
        receivingDepartment: props.initialValue.receivingDepartment ?? [],
        relatedUsers: props.initialValue.relatedUsers,
        remindContents: castReminderTemplateContentMapToMapSchema(
          props.initialValue.remindContents
        ),
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  const [changedModule, setChangedModule] =
    useState<SaveReminderTemplateFormContextI>({ changedModule: undefined });

  const onSubmit = (value: SaveReminderTemplateSchemaI) => {
    props.onSubmit({
      ...value,
      relatedUsers: (value.relatedUsers ?? []).map((user) => user.id),
      remindContents: Array.from(
        Object.values(value.remindContents ?? {})
      ).flat(),
      receivingDepartment: (value.receivingDepartment ?? []).map(
        (department) => department.id
      ),
      receivedTitle: value.receivedTitle  ? [value.receivedTitle] as unknown as string[] : [],
    });
  };
  return (
    <FormProvider {...form}>
      <SaveReminderTemplateFormContext.Provider value={changedModule}>
        <Grid container className="form-wrapper">
          <Grid item width={"100%"} marginBottom={"2rem"}>
            <Grid
              container
              direction={"column"}
              flexShrink={0}
              spacing={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={SaveReminderTemplateDTOFieldNames.TITLE}
                  label={t(
                    `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.TITLE}`
                  )}
                  placeHolder={t(
                    `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.TITLE}`
                  )}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormSelect
                  control={form.control}
                  name={SaveReminderTemplateDTOFieldNames.MODULE}
                  label={t(
                    `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.MODULE}`
                  )}
                  placeHolder={t(
                    `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.MODULE}`
                  )}
                  options={Array.from(Module.keys()).map((key) => ({
                    label: t(
                      `common.option.${SaveReminderTemplateDTOFieldNames.MODULE}.${key}`
                    ),
                    value: Module.get(key)!,
                  }))}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  required
                  onChange={(e) => {
                    setChangedModule({ changedModule: e.target.value });
                  }}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={SaveReminderTemplateDTOFieldNames.DESCRIPTION}
                  label={t(
                    `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.DESCRIPTION}`
                  )}
                  placeHolder={t(
                    `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.DESCRIPTION}`
                  )}
                  minRows={3}
                />
              </Grid>
            </Grid>
          </Grid>

          <Grid item width={"100%"}>
            <Grid
              container
              direction={"column"}
              spacing={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <Typography variant="h5">
                  {t("reminder_template.title.reminder_sent_to")}
                </Typography>
              </Grid>
              <Grid item width={"100%"}>
                <Grid
                  container
                  direction={"column"}
                  alignItems={"center"}
                  className="form-sub-section-wrapper"
                  rowGap={"2rem"}
                >
                  {[
                    RemindReceiverTypeKeys.DEPT_HEAD_OF_THE_SENDER,
                    RemindReceiverTypeKeys.DIVISION_HEAD_OF_THE_SENDER,
                  ].map((key) => (
                    <Grid item key={key} width={"100%"}>
                      <ReminderTemplateContentForm
                        title={t(`reminder_template.title.${key}`)}
                        remindReceiverTypeKey={key}
                      />
                    </Grid>
                  ))}
                </Grid>
              </Grid>

              <Grid item width={"100%"}>
                <Grid
                  container
                  direction={"column"}
                  alignItems={"center"}
                  className="form-sub-section-wrapper"
                  rowGap={"2rem"}
                >
                  {[
                    RemindReceiverTypeKeys.RECEIVER,
                    RemindReceiverTypeKeys.DEPT_HEAD_OF_THE_RECIPIENT,
                    RemindReceiverTypeKeys.DIVISION_HEAD_OF_THE_RECIPIENT,
                  ].map((key) => (
                    <Grid item key={key} width={"100%"}>
                      <ReminderTemplateContentForm
                        title={t(`reminder_template.title.${key}`)}
                        remindReceiverTypeKey={key}
                      />
                    </Grid>
                  ))}
                </Grid>
              </Grid>

              <Grid item width={"100%"}>
                <Grid
                  container
                  direction={"column"}
                  alignItems={"center"}
                  className="form-sub-section-wrapper"
                  rowGap={"2rem"}
                >
                  <Grid item width={"100%"}>
                    <ReminderTemplateContentForm
                      title={t(
                        `reminder_template.title.${RemindReceiverTypeKeys.PEOPLE_INVOLVED}`
                      )}
                      remindReceiverTypeKey={
                        RemindReceiverTypeKeys.PEOPLE_INVOLVED
                      }
                    >
                      <FormMultipleSelect<
                        SaveReminderTemplateSchemaI,
                        BasedUser
                      >
                        control={form.control}
                        name={SaveReminderTemplateDTOFieldNames.RELATED_USERS}
                        label={t(
                          `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.RELATED_USERS}`
                        )}
                        placeholder={t(
                          `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.RELATED_USERS}`
                        )}
                        getOptions={async (keyword) => {
                          const response = await getUsers({
                            searchTerm: keyword,
                            page: 0,
                            size: 100,
                            sortBy: "name",
                            sortOrder: "ASC",
                          });

                          return (response?.users ?? []).map((user) => ({
                            id: user.id,
                            name: user.name ?? "",
                            nameEnglish: user.nameEnglish ?? "",
                            departmentName: user.department?.name,
                            email: user.email,
                          }));
                        }}
                        getOptionLabel={(option) =>
                          `${
                            i18n.language == LANGUAGES.VIETNAMESE
                              ? option.name ?? ""
                              : option.nameEnglish ?? ""
                          } (${option.email ?? ""}) - ${
                            option.departmentName ?? ""
                          }`
                        }
                        getOptionKey={(option) => option.id}
                        keyQuery="queryUser"
                        onChange={(keys) => {
                          if (
                            keys.length > 0 &&
                            (!form.getValues().relatedUsers ||
                              form.getValues().relatedUsers?.length == 0)
                          ) {
                            form.setValue(
                              `${
                                SaveReminderTemplateDTOFieldNames.REMIND_CONTENTS
                              }.${
                                RemindReceiverType.get(
                                  RemindReceiverTypeKeys.PEOPLE_INVOLVED
                                )! - 1
                              }`,
                              [
                                {
                                  remindReceiverType: RemindReceiverType.get(
                                    RemindReceiverTypeKeys.PEOPLE_INVOLVED
                                  )!,
                                  remindValueType: RemindValueType.get(
                                    RemindValueTypeKeys.TIME
                                  )!,
                                  timeStatus: TimeStatus.get(
                                    TimeStatusKeys.BEFORE
                                  )!,
                                  vendorResponseStatus:
                                    VendorResponseStatus.get(
                                      VendorResponseStatusKeys.DATE_ISSUED
                                    )!,
                                  time: 0,
                                  timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
                                },
                              ]
                            );
                          } else {
                            form.setValue(
                              `${
                                SaveReminderTemplateDTOFieldNames.REMIND_CONTENTS
                              }.${
                                RemindReceiverType.get(
                                  RemindReceiverTypeKeys.PEOPLE_INVOLVED
                                )! - 1
                              }`,
                              []
                            );
                          }
                        }}
                      />
                    </ReminderTemplateContentForm>
                  </Grid>
                </Grid>
              </Grid>

              <Grid item width={"100%"}>
                <Grid
                  container
                  direction={"column"}
                  alignItems={"center"}
                  className="form-sub-section-wrapper"
                  rowGap={"2rem"}
                >
                  <Grid item width={"100%"}>
                    <ReminderTemplateContentForm
                      title={t(
                        `reminder_template.title.${RemindReceiverTypeKeys.RECEIVING_DEPARTMENT}`
                      )}
                      remindReceiverTypeKey={
                        RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                      }
                    >
                      <FormSelectTreeView
                        name={
                          SaveReminderTemplateDTOFieldNames.RECEIVING_DEPARTMENT
                        }
                        control={form.control}
                        label={t(
                          `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.RECEIVING_DEPARTMENT}`
                        )}
                        placeholder={t(
                          `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.RECEIVING_DEPARTMENT}`
                        )}
                        getOptions={async (keyword) => {
                          try {
                            const response = await getDepartments({
                              searchTerm: keyword,
                            });
                            const first100Departments: Department[] = (
                              response?.departments ?? []
                            ).slice(0, 150);
                            return first100Departments;
                          } catch (e) {
                            return [];
                          }
                        }}
                        getOptionLabel={(option) => option.name ?? ""}
                        getOptionKey={(option) => option.id ?? ""}
                        getOptionChildren={(option) => option.children}
                        variant="outlined"
                        debounceMs={FILTER_DEBOUNCE_MS}
                        onChange={(value: Department[]) => {
                          if (
                            value.length > 0 &&
                            (!form.getValues().receivingDepartment ||
                              form.getValues().receivingDepartment?.length == 0)
                          ) {
                            form.setValue(
                              `${
                                SaveReminderTemplateDTOFieldNames.REMIND_CONTENTS
                              }.${
                                RemindReceiverType.get(
                                  RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                                )! - 1
                              }`,
                              [
                                {
                                  remindReceiverType: RemindReceiverType.get(
                                    RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                                  )!,
                                  remindValueType: RemindValueType.get(
                                    RemindValueTypeKeys.TIME
                                  )!,
                                  timeStatus: TimeStatus.get(
                                    TimeStatusKeys.BEFORE
                                  )!,
                                  vendorResponseStatus:
                                    VendorResponseStatus.get(
                                      VendorResponseStatusKeys.DATE_ISSUED
                                    )!,
                                  time: 0,
                                  timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
                                },
                              ]
                            );
                          } else {
                            form.setValue(
                              `${
                                SaveReminderTemplateDTOFieldNames.REMIND_CONTENTS
                              }.${
                                RemindReceiverType.get(
                                  RemindReceiverTypeKeys.RECEIVING_DEPARTMENT
                                )! - 1
                              }`,
                              []
                            );
                          }

                          form.setValue(
                            SaveReminderTemplateDTOFieldNames.RECEIVING_DEPARTMENT,
                            value
                          );
                        }}
                        rules={{ required: "This field is required" }}
                        selectedItemsProp={
                          props.initialValue
                            ? props.initialValue?.receivingDepartment
                            : undefined
                        }
                        required
                      />
                    </ReminderTemplateContentForm>
                  </Grid>
                </Grid>
              </Grid>

              <Grid item width={"100%"}>
                <Grid
                  container
                  direction={"column"}
                  alignItems={"center"}
                  className="form-sub-section-wrapper"
                  rowGap={"2rem"}
                >
                  <Grid item width={"100%"}>
                    <ReminderTemplateContentForm
                      title={t(
                        `reminder_template.title.${RemindReceiverTypeKeys.RECEIVED_TITLE}`
                      )}
                      remindReceiverTypeKey={
                        RemindReceiverTypeKeys.RECEIVED_TITLE
                      }
                    >
                      <FormAsyncSelect<any, PositionType>
                        control={form.control}
                        name={SaveReminderTemplateDTOFieldNames.RECEIVED_TITLE}
                        label={t(
                          `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.RECEIVED_TITLE}`
                        )}
                        placeholder={t(
                          `reminder_template.field_name.${SaveReminderTemplateDTOFieldNames.RECEIVED_TITLE}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const response = await getPositionFn(keyword);
                            return response?.positions ?? [];
                          } else if (keyword?.length && keyword.length > 0) {
                            return [props?.initialValue?.receivedTitle?.[0]];
                          }

                          return [];
                        }}
                        getOptionLabel={(option) => `${option?.name ?? ""}`}
                        getOptionKey={(option) => option?.id}
                        keyQuery="received_title/queryRole"
                        onChange={() => {
                          if (form.getValues().receivedTitle) {
                            form.setValue(
                              `${
                                SaveReminderTemplateDTOFieldNames.REMIND_CONTENTS
                              }.${
                                RemindReceiverType.get(
                                  RemindReceiverTypeKeys.RECEIVED_TITLE
                                )! - 1
                              }`,
                              [
                                {
                                  remindReceiverType: RemindReceiverType.get(
                                    RemindReceiverTypeKeys.RECEIVED_TITLE
                                  )!,
                                  remindValueType: RemindValueType.get(
                                    RemindValueTypeKeys.TIME
                                  )!,
                                  timeStatus: TimeStatus.get(
                                    TimeStatusKeys.BEFORE
                                  )!,
                                  vendorResponseStatus:
                                    VendorResponseStatus.get(
                                      VendorResponseStatusKeys.DATE_ISSUED
                                    )!,
                                  time: 0,
                                  timeUnit: TimeUnit.get(TimeUnitKeys.MINUTE),
                                },
                              ]
                            );
                          } else {
                            form.setValue(
                              `${
                                SaveReminderTemplateDTOFieldNames.REMIND_CONTENTS
                              }.${
                                RemindReceiverType.get(
                                  RemindReceiverTypeKeys.RECEIVED_TITLE
                                )! - 1
                              }`,
                              []
                            );
                          }
                        }}
                        initialValue={props?.initialValue?.receivedTitle?.[0] as any}
                      />
                    </ReminderTemplateContentForm>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Grid>

          <FormActionButtons
            formMode={props.formMode}
            loading={props.loading}
            onCancel={props.onCancel}
            cancelConfirm={form.formState.isDirty}
            onDelete={props.onDelete}
            onSave={onSubmit}
          />
        </Grid>
      </SaveReminderTemplateFormContext.Provider>
    </FormProvider>
  );
};
