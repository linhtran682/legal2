import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { GridRenderCellParams } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import { useRouter } from "next/navigation";
import { REMINDER_TEMPLATE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useTranslation } from "react-i18next";
import DeleteIcon from "@mui/icons-material/Delete";
import { toast } from "react-toastify";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteReminderTemplates } from "@/apis/service/reminder_template/ReminderTemplate";
import { ReminderTemplateTableConst } from "../ReminderTemplateTable";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";

export const ReminderTemplateTableAtions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  const queryClient = useQueryClient();

  const deleteReminderTemplatesQuery = useMutation({
    mutationFn: deleteReminderTemplates,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.reminder"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [ReminderTemplateTableConst.GET_TABLE_ITEM_QUERY_KEY],
      });
    },
  });

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_reminder_template",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(
              `/${REMINDER_TEMPLATE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            ),
          tooltipTitle: t("common.button.edit"),
        },
        {
          key: "delete_reminder_template",
          icon: <DeleteIcon color='primary' />,
          onClick: (params) =>
            params.id &&
            deleteReminderTemplatesQuery.mutate([Number(params.id)]),
          tooltipTitle: t("common.button.delete"),
          confirmPopupProps: {
            icon: <DeleteRecordDialogIcon />,
            title: t("common.message.confirm_delete"),
          },
        },
      ]}
    />
  );
};
