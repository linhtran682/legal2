import {
  deleteReminderTemplates,
  getBasedReminderTemplates,
} from "@/apis/service/reminder_template/ReminderTemplate";
import MultipleFilterTable, {
  MultipleFilterTableColumn,
} from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import {
  BasedReminderTemplateFieldNames,
  GetBasedReminderTemplatesParams,
} from "@/models/reminder_template/BaseReminderTemplate";
import { GridFilterItem } from "@mui/x-data-grid";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { ReminderTemplateTableAtions } from "./reminder_template_table_actions/ReminderTemplateTableActions";
import { useTranslation } from "react-i18next";
import { Module, ModuleR } from "@/constants/general";
import { useRouter } from "next/navigation";
import { REMINDER_TEMPLATE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { TableGroupedActionButtons } from "@/components/commons/action_button/TableGroupedActionButtons";
import { StatusFieldNames } from "@/models/status/Status";
import { getMultipleChoosingOperators } from "@/components/commons/filters/MultipleChoosingFilter";

export const ReminderTemplateTableConst = {
  TABLE_NAME: "ReminderTemplateTable",
  GET_TABLE_ITEM_QUERY_KEY: "getBasedReminderTemplates",
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetBasedReminderTemplatesParams => {
  const params: GetBasedReminderTemplatesParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: BasedReminderTemplateFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == BasedReminderTemplateFieldNames.TITLE) {
      params.title = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() || "";
  }

  return params;
};

export const ReminderTemplateTable = () => {
  const router = useRouter();
  const [t] = useTranslation();
  const queryClient = useQueryClient();

  const [reminderTemplateTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: BasedReminderTemplateFieldNames.ID,
      label: BasedReminderTemplateFieldNames.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: true,
    },
    {
      key: BasedReminderTemplateFieldNames.MODULE,
      label: BasedReminderTemplateFieldNames.MODULE,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      filterOperators: getMultipleChoosingOperators(
        {
          options: Array.from(Module.keys()).map((key) => ({
            label: t(`common.option.${StatusFieldNames.MODULE}.${key}`),
            value: Module.get(key)!,
          })),
          getOptionKey: (option) => option.value,
          getOptionLabel: (option) => option.label,
        },
        t
      ),
      renderCell: (params) => (
        <>
          {t(
            `common.option.${
              BasedReminderTemplateFieldNames.MODULE
            }.${ModuleR.get(Number(params.value))!}`
          )}
        </>
      ),
    },
    {
      key: BasedReminderTemplateFieldNames.TITLE,
      label: BasedReminderTemplateFieldNames.TITLE,
      type: "string",
      quickFilter: true,
      filterable: false,
      sortable: true,
      hideable: false,
      flex: 1,
    },
    {
      key: BasedReminderTemplateFieldNames.REGISTER_USER_NAME,
      label: BasedReminderTemplateFieldNames.REGISTER_USER_NAME,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: true,
      flex: 1,
    },
    {
      key: BasedReminderTemplateFieldNames.REGISTER_TIME,
      label: BasedReminderTemplateFieldNames.REGISTER_TIME,
      type: "date",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: true,
      flex: 1,
    },
    {
      key: "action",
      label: "",
      type: undefined,
      renderCell: ReminderTemplateTableAtions,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "stickyRight",
    },
  ]);

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getBasedReminderTemplatesQuery = useQuery({
    queryKey: [ReminderTemplateTableConst.GET_TABLE_ITEM_QUERY_KEY],
    queryFn: () =>
      getBasedReminderTemplates(castTableStateToParams(tableState)),
  });

  const deleteReminderTemplatesQuery = useMutation({
    mutationFn: deleteReminderTemplates,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.reminder"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [ReminderTemplateTableConst.GET_TABLE_ITEM_QUERY_KEY],
      });
    },
  });

  // Watch table state then refetch new data for the table
  useEffect(() => {
    tableState &&
      getBasedReminderTemplatesQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  return (
    <MultipleFilterTable
      data={getBasedReminderTemplatesQuery.data?.remindBaseData || []}
      columns={reminderTemplateTableColumns
        // .filter((column) => appContext.meCanWrite || column.key != "action")
        .map((column) => ({
          ...column,
          label: column.label && `reminder_template.column.${column.label}`,
        }))}
      getRowId={(item) => item.id.toString()}
      loading={getBasedReminderTemplatesQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getBasedReminderTemplatesQuery.data?.total}
      onRowClick={(params) => {
        router.push(
          `/${REMINDER_TEMPLATE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
        );
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: BasedReminderTemplateFieldNames.TITLE,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(
              `reminder_template.column.${fieldKey}`
            ).toLocaleLowerCase(),
          }),
      }}
      groupedActions={(model) => (
        <TableGroupedActionButtons
          selectModel={model}
          onDelete={deleteReminderTemplatesQuery.mutate}
        />
      )}
    />
  );
};
