import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { EXPECTED_DATE_TIME_LOCALE, GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { Evaluation } from "@/models/metadata/Metadata";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

export interface EvaluationPanelProps {
  queryKey: string;
  getEvaluations: () => Promise<Evaluation[]>;
}

export const EvaluationPanel = (props: EvaluationPanelProps) => {
  const { t, i18n } = useTranslation();
  const getEvaluationsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getEvaluations(),
  });

  const OptionsEvaluation = [
    {
      label: t("metadata.evaluation.options.rate"),
      value: true,
    },
    {
      label: t("metadata.evaluation.options.notRate"),
      value: false,
    },
  ];

  const EvaluationTableColumns: StandardSimpleTableColumn<Evaluation>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +(params?.id ?? 0) + 1,
    },
    {
      key: "department",
      label: "metadata.evaluation.column.department",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.department?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.evaluation.column.user",
      type: "string",
      flex: 1,
      renderCell: (params) => params.row?.user?.name,
    },
    {
      key: "deadline",
      label: "metadata.evaluation.column.evaluationTime",
      type: "date",
      flex: 1,
      renderCell: (params) =>
        params.row.deadline
          ? Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
              dateStyle: "short",
              timeStyle: "medium",
            }).format(new Date(params.row.deadline as string))
          : null,
    },
    {
      key: "evaluated",
      label: "metadata.evaluation.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        OptionsEvaluation?.find(
          (evaluation) => evaluation?.value == params?.row?.evaluated
        )?.label,
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        loading={getEvaluationsQuery.isFetching}
        columns={EvaluationTableColumns}
        data={getEvaluationsQuery.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
    </div>
  );
};
