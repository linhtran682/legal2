import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { COLOR_TYPE } from "@/constants/color";
import {
  EXPECTED_DATE_TIME_LOCALE,
  GLOBAL_LARGE_SPACING,
} from "@/constants/format";
import { Forward } from "@/models/metadata/Metadata";
import {
  Avatar,
  Divider,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { Fragment } from "react";
import { useTranslation } from "react-i18next";

export interface ForwardPanelProps {
  queryKey: string;
  getForwards: () => Promise<Forward[]>;
}

export const ForwardPanel = (props: ForwardPanelProps) => {
  const [t] = useTranslation();

  const getForwardsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getForwards(),
  });

  return (
    <List dense>
      <LoadingWrapper loading={getForwardsQuery.isLoading}>
        {(getForwardsQuery.data || []).map((forward) => (
          <Fragment key={forward.forwardDate}>
            <ListItem>
              <ListItemAvatar>
                <Avatar src="/" />
              </ListItemAvatar>
              <ListItemText
                primary={`${forward?.receiveUser?.name} (${forward?.receiveUser?.email}) - ${forward?.receiveUser?.departmentName ?? forward?.receiveUser?.department?.name}`}
                secondary={Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                  dateStyle: "short",
                  timeStyle: "medium",
                }).format(new Date(forward.forwardDate))}
                secondaryTypographyProps={{
                  variant: "caption",
                }}
                primaryTypographyProps={{
                  variant: "h5",
                }}
              />
            </ListItem>
            <ListItem sx={{ paddingLeft: GLOBAL_LARGE_SPACING }}>
              <ListItemText
                secondary={t("metadata.forward.forwarder", {
                  forwarder: `${forward.forwardUser.name} (${forward.forwardUser.email}) - ${forward.forwardUser.departmentName ?? forward?.forwardUser?.department?.name}`,
                })}
                secondaryTypographyProps={{
                  color: COLOR_TYPE.TOYOTA.TOYOTA2,
                  variant: "body2",
                }}
              />
            </ListItem>
            <Divider variant="middle" />
          </Fragment>
        ))}
      </LoadingWrapper>
    </List>
  );
};
