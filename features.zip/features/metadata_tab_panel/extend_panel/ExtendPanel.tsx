import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { EXPECTED_DATE_TIME_LOCALE, GLOBAL_SPACING } from "@/constants/format";
import { LegalDocumentStatusContent, LegalDocumentUserStatusKey } from "@/constants/general";
import { StatusTimeExtension } from "@/constants/options";
import { TimeExtensionForm } from "@/features/legal-document/time_extension_form/TimeExtensionForm";
import { LANGUAGES } from "@/locales/config-translation";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import { TypeExtendResponses } from "@/models/metadata/Metadata";
import { Button } from "@mui/material";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useTranslation } from "react-i18next";

export interface ExtendPanelProps {
  queryKey: string;
  getExtendRecords: () => Promise<TypeExtendResponses[]>;
  documentId: number;
  legalDocument?: LawDocumentBodyReceive;
}

export const ExtendPanel = (props: ExtendPanelProps) => {
  const { i18n } = useTranslation();
  const queryClient = useQueryClient();
  const [extendDeadlineId, setExtendDeadlineId] = useState<number>();
  const [isOpenTimeExtension, setIsOpenTimeExtension] =
    useState<boolean>(false);
  const getExtendRecordsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getExtendRecords(),
  });

  const handleClickExtend = (params: any) => {
    setIsOpenTimeExtension(true);
    setExtendDeadlineId(params?.row?.extendDeadlineId);
  };

  const ExtendTableColumns: StandardSimpleTableColumn<TypeExtendResponses>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +(params?.id) + 1,
    },
    {
      key: "department",
      label: "metadata.extend.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.department?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.extend.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "proposedDeadline",
      label: "metadata.extend.column.date",
      type: "date",
      flex: 1,
      renderCell: (params) =>
        Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
          dateStyle: "short",
          timeStyle: "medium",
        }).format(
          new Date(
            params.row.proposedDeadline ?? (params.row.newDeadline as string)
          )
        ),
    },
    {
      key: "status",
      label: "metadata.extend.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        (
          StatusTimeExtension.find(
            (status) => status.value === params.row.status
          ) ?? {}
        ).label,
    },
    {
      key: "actionType",
      label: "metadata.extend.column.action",
      type: "string",
      flex: 1,
      renderCell: (params) => {
        return params?.row?.status === StatusTimeExtension[2]?.value &&
          params?.row?.extendDeadlineId ? (
          <Button
            disabled={
              props.legalDocument?.status?.name ===
              LegalDocumentStatusContent.get(LegalDocumentUserStatusKey.DONE)!
            }
            onClick={() => handleClickExtend(params)}
          >
            Gia hạn
          </Button>
        ) : (
          <></>
        );
      },
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={ExtendTableColumns}
        data={getExtendRecordsQuery?.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
      {isOpenTimeExtension && (
        <TimeExtensionForm
          setIsOpen={(state) => setIsOpenTimeExtension(state)}
          legalDocumentId={props?.documentId}
          initialValue={{}}
          isOpen={isOpenTimeExtension}
          extendDeadlineId={extendDeadlineId}
          name={props?.legalDocument?.documentName}
          isConfirmExtension
          handleSubmit={async () =>
            await queryClient.invalidateQueries(props.queryKey as any)
          }
        />
      )}
    </div>
  );
};
