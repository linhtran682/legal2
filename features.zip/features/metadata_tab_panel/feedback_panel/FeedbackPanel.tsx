import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { COLOR_TYPE } from "@/constants/color";
import {
  EXPECTED_DATE_TIME_LOCALE,
  GLOBAL_LARGE_SPACING,
  GLOBAL_SMALL_SPACING,
} from "@/constants/format";
import { Feedback } from "@/models/metadata/Metadata";
import {
  Avatar,
  Divider,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Typography,
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { Fragment } from "react";
import { useTranslation } from "react-i18next";

export interface FeedbackPanelProps {
  subjectTitle: string;
  queryKey: string;
  getFeedbacks: () => Promise<Feedback[]>;
}

export const FeedbackPanel = (props: FeedbackPanelProps) => {
  const [t] = useTranslation();

  const getFeedbacksQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getFeedbacks(),
  });

  return (
    <List dense>
      <LoadingWrapper loading={getFeedbacksQuery.isLoading}>
        {(getFeedbacksQuery.data || []).map((feedback) => (
          <Fragment key={feedback.feedbackDate}>
            <ListItem>
              <ListItemAvatar>
                <Avatar src='/' />
              </ListItemAvatar>
              <ListItemText
                primary={`${feedback.feedbackUser.name} (${feedback.feedbackUser.email}) - ${feedback.feedbackUser.departmentName}`}
                secondary={Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                  dateStyle: "short",
                  timeStyle: "medium",
                }).format(new Date(feedback.feedbackDate))}
                secondaryTypographyProps={{
                  variant: "caption",
                }}
                primaryTypographyProps={{
                  variant: "h5",
                }}
              />
            </ListItem>
            <ListItem sx={{ paddingLeft: GLOBAL_LARGE_SPACING }}>
              <ListItemText
                secondary={
                  <>
                    <Typography
                      variant='body2'
                      sx={{ paddingBottom: GLOBAL_SMALL_SPACING }}
                    >
                      {t("metadata.feedback.subject", {
                        subjectTitle: props.subjectTitle,
                      })}
                    </Typography>
                    <Typography variant='h5'>
                      {t("metadata.feedback.content")}:{" "}
                    </Typography>
                    <Typography variant='body2'>{feedback.content}</Typography>
                  </>
                }
                secondaryTypographyProps={{
                  color: COLOR_TYPE.TOYOTA.TOYOTA2,
                }}
              />
            </ListItem>
            <Divider variant='middle' />
          </Fragment>
        ))}
      </LoadingWrapper>
    </List>
  );
};
