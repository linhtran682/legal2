import { COLOR_TYPE } from "@/constants/color";
import {
  EXPECTED_DATE_TIME_LOCALE,
  GLOBAL_LARGE_SPACING,
  GLOBAL_SPACING,
} from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import {
  Avatar,
  CircularProgress,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  TextField,
} from "@mui/material";
import { Fragment, useState } from "react";
import SendIcon from "@mui/icons-material/Send";
import { Comment } from "@/models/metadata/Metadata";
import { useMutation, useQuery } from "@tanstack/react-query";

export interface CommentPanelProps {
  queryKey: string;
  getComments: () => Promise<Comment[]>;
  addComment: (comment: string) => Promise<any>;
  disabled?: boolean;
}

export const CommentPanel = (props: CommentPanelProps) => {
  const [comment, setComment] = useState<string>("");

  const getCommentsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getComments(),
  });

  const addCommentQuery = useMutation({
    mutationFn: props.addComment,
    onSuccess: () => {
      getCommentsQuery.refetch();
      setComment("");
    },
  });

  const handleAddComment = () => {
    comment && addCommentQuery.mutate(comment);
  };

  return (
    <>
      <List dense>
        {(getCommentsQuery.data ?? []).map((comment) => (
          <Fragment key={comment.commentId}>
            {" "}
            <ListItem>
              <ListItemAvatar>
                <Avatar src={"/"} />
              </ListItemAvatar>
              <ListItemText
                primary={`${comment.userInfo.name} (${comment.userInfo.email}) - ${comment.userInfo.departmentName}`}
                secondary={Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                  dateStyle: "short",
                  timeStyle: "medium",
                }).format(new Date(comment.commentDate))}
                secondaryTypographyProps={{
                  variant: "caption",
                }}
                primaryTypographyProps={{
                  variant: "h5",
                }}
              />
            </ListItem>
            <ListItem sx={{ paddingLeft: GLOBAL_LARGE_SPACING }}>
              <ListItemText
                secondary={comment.comment}
                secondaryTypographyProps={{
                  color: COLOR_TYPE.TOYOTA.TOYOTA2,
                  variant: "body2",
                }}
              />
            </ListItem>
            <Divider variant='middle' />
          </Fragment>
        ))}
      </List>

      {!props.disabled && (
        <TextField
          size='small'
          fullWidth
          sx={{
            ...formInputSxProps,
            padding: GLOBAL_SPACING,
            position: "sticky",
            bottom: 0,
            background: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          onKeyDown={(e) => {
            if (e.key == "Enter") {
              handleAddComment();
            }
          }}
          disabled={
            getCommentsQuery.isLoading ||
            addCommentQuery.isPending ||
            props.disabled
          }
          multiline
          InputProps={{
            endAdornment:
              getCommentsQuery.isLoading || addCommentQuery.isPending ? (
                <CircularProgress color='primary' size={"1rem"} />
              ) : (
                <IconButton
                  onClick={() => handleAddComment()}
                  size='small'
                  disabled={props.disabled}
                >
                  <SendIcon fontSize='small' />
                </IconButton>
              ),
          }}
        />
      )}
    </>
  );
};
