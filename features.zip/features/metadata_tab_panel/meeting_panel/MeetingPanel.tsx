import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { ConfirmPopup, ConfirmPopupProps, DefaultConfirmPopupState } from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { COLOR_TYPE } from "@/constants/color";
import {
  GLOBAL_SPACING
} from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { MeetingDetail } from "@/models/metadata/Metadata";
import { getUserLabel } from "@/utils";
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import EditNoteRoundedIcon from '@mui/icons-material/EditNoteRounded';
import SendIcon from "@mui/icons-material/Send";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  IconButton,
  Stack,
  TextField,
  Typography
} from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Fragment, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";

export interface MeetingPanelProps {
  queryKey: string;
  getMeetings: () => Promise<MeetingDetail[]>;
  addMeeting: (content: string) => Promise<any>;
  updateMeeting: (data: { content: string, meetingId: number }) => Promise<any>;
  deleteMeeting: (meetingId: number) => Promise<any>;
  disabled?: boolean;
  reloadDetail: () => void;
  containerHeight?: number;
}

export const MeetingPanel = (props: MeetingPanelProps) => {
  const { t } = useTranslation();
  const [comment, setComment] = useState<string>("");
  const [editItem, setEditItem] = useState<MeetingDetail | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const getMeetingsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getMeetings(),
  });

  const addCommentQuery = useMutation({
    mutationFn: props.addMeeting,
    onSuccess: () => {
      getMeetingsQuery.refetch().then(() => {
        if (listRef.current) {
          listRef.current.scrollTo({
            top: 0,
            behavior: 'smooth', // Add smooth scrolling
          });
        }
      });
      setComment("");
      props.reloadDetail?.();
    },
  });

  const updateBookingMutation = useMutation({
    mutationFn: props.updateMeeting,
    onSuccess: () => {
      getMeetingsQuery.refetch().then(() => {
        setEditItem(null)
      });
    },
  });
  const deleteBookingMutation = useMutation({
    mutationFn: props.deleteMeeting,
    onSuccess: () => {
      setEditItem(null)
      getMeetingsQuery.refetch();
      setConfirmPopupState(DefaultConfirmPopupState);
      props.reloadDetail?.();
    },
  });

  const handleAddComment = () => {
    comment && addCommentQuery.mutate(comment);
  };
  return (
    <Stack maxHeight={(props?.containerHeight as number) > 0 ? ((props?.containerHeight as number) - 52) : '60vh'}>
      <ConfirmPopup {...confirmPopupState} />
      {getMeetingsQuery.data?.length ? <Box ref={listRef} sx={{ flex: 1, overflowY: 'auto' }}>
        {(getMeetingsQuery.data ?? []).toReversed().map((meeting, index) => (
          <Fragment key={meeting.id}>
            <MeetingItem
              meeting={meeting}
              isEditing={editItem?.id === meeting.id}
              onEditClick={() => setEditItem(meeting)}
              onCancelClick={() => setEditItem(null)}
              isLoading={(editItem?.id === meeting.id
                && (updateBookingMutation.isPending || getMeetingsQuery.isFetching))
              }
              onConfirmClick={(content: string) => updateBookingMutation.mutate({
                content,
                meetingId: meeting.id
              })}
              onDeleteClick={() => {
                setConfirmPopupState({
                  open: true,
                  handleConfirm: () => deleteBookingMutation.mutate(meeting.id),
                  handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
                  icon: <DeleteRecordDialogIcon />,
                  title: t("common.message.confirm_delete"),
                });
              }}
              index={(getMeetingsQuery.data?.length as number) - index}
            // updateFn={props.updateBooking}
            // deleteFn={props.deleteBooking}
            />
            <Divider variant='middle' />
          </Fragment>
        ))}
      </Box> : null}
      {!props.disabled && (
        <TextField
          size='small'
          fullWidth
          sx={{
            ...formInputSxProps,
            padding: GLOBAL_SPACING,
            // position: "sticky",
            // bottom: 0,
            background: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
          value={comment}
          placeholder={t("metadata.meeting.enterContent")}
          onChange={(e) => setComment(e.target.value)}
          // onKeyDown={(e) => {
          //   if (e.key == "Enter") {
          //     handleAddComment();
          //   }
          // }}
          disabled={
            getMeetingsQuery.isLoading ||
            addCommentQuery.isPending ||
            props.disabled
          }
          multiline
          InputProps={{
            endAdornment:
              getMeetingsQuery.isLoading || addCommentQuery.isPending ? (
                <CircularProgress color='primary' size={"1rem"} />
              ) : (
                <IconButton
                  onClick={() => handleAddComment()}
                  size='small'
                  disabled={props.disabled}
                >
                  <SendIcon fontSize='small' />
                </IconButton>
              ),
          }}
        />
      )}
    </Stack>
  );
};


interface MeetingItemProps {
  meeting: MeetingDetail;
  index: number;
  // updateFn: (data: { content: string, meetingId: number }) => Promise<any>;
  // deleteFn: (meetingId: number) => Promise<any>;
  isEditing: boolean;
  isLoading: boolean;
  onEditClick: () => void;
  onDeleteClick: () => void;
  onConfirmClick: (value: string) => void;
  onCancelClick: () => void;
}

const MeetingItem = (props: MeetingItemProps) => {
  const { t } = useTranslation();
  const { meeting, index, isEditing, onEditClick, onCancelClick, onConfirmClick, onDeleteClick, isLoading } = props;
  const [value, setValue] = useState(meeting.content);
  const inputRef = useRef<HTMLInputElement>(null);


  useEffect(() => {
    if (!isEditing) {
      setValue(meeting.content);
    }
  }, [isEditing])

  return <Stack p={2} key={meeting.id}>
    <Stack direction={'row'} alignItems={'center'} height={32}>
      <Typography flex={1} variant="h5">{t("metadata.meeting.meetingNo", { value: index })}</Typography>
      {meeting?.isEdit && !isEditing && !isLoading ? <>
        <IconButton size="small" onClick={onDeleteClick}><DeleteRoundedIcon sx={{ fontSize: 22, color: COLOR_TYPE.TOYOTA.TOYOTA1 }} /></IconButton>
        <IconButton size="small" onClick={onEditClick}><EditNoteRoundedIcon sx={{ fontSize: 22 }} /></IconButton>
      </> : null}
      {meeting?.isEdit && isEditing && !isLoading ? <>
        <Button variant="contained" className="cancel" size="small" onClick={onCancelClick} sx={{ mr: 1.5 }}>
          <Typography variant="body2">{t("common.button.cancel")}</Typography>
          {/* <ClearRoundedIcon sx={{ fontSize: 22 }} /> */}
        </Button>
        <Button variant="contained" className="confirm" size="small" onClick={() => onConfirmClick(value)}>
          <Typography variant="body2">{t("common.button.save")}</Typography>
          {/* <CheckRoundedIcon sx={{ fontSize: 22 }} /> */}
        </Button>
      </> : null}
      {isLoading ? <CircularProgress size={20} sx={{ m: '0.75' }} /> : null}
    </Stack>

    <Typography><Typography display={'inline'} variant="h5">{t("metadata.meeting.booker")}:</Typography> {getUserLabel(meeting.createUser)}</Typography>
    <TextField
      ref={inputRef}
      autoFocus
      size='small'
      fullWidth
      disabled={!isEditing || isLoading}
      value={value}
      onChange={(e) => setValue(e.target.value)}
      multiline
      rows={3}
      sx={{
        ...formInputSxProps,
        mt: 1.5,
        // position: "sticky",
        // bottom: 0,
        background: COLOR_TYPE.TOYOTA.TOYOTA8,
      }}
    />
  </Stack >
}