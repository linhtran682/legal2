import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { InformationRequestDetail } from "@/models/metadata/Metadata";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useTranslation } from "react-i18next";

export interface InformationRequestPanelProps {
  queryKey: string;
  getInformationRequests: () => Promise<InformationRequestDetail[]>;
}

export const InformationRequestPanel = (
  props: InformationRequestPanelProps
) => {
  const { t } = useTranslation();

  const InformationRequestColumns: StandardSimpleTableColumn<InformationRequestDetail>[] =
    [
      {
        key: "id",
        label: "metadata.informationRequest.column.id",
        type: "number",
        flex: 1,
        renderCell: (params) => +params?.id + 1,
      },
      {
        key: "departmentName",
        label: "metadata.informationRequest.column.departmentName",
        type: "string",
        flex: 1,
        renderCell: (params) => params.row.user?.department?.name ?? "",
      },
      {
        key: "employeeName",
        label: "metadata.informationRequest.column.employeeName",
        type: "string",
        flex: 1,
        renderCell: (params) => params.row.user?.name ?? "",
      },
      {
        key: "content",
        label: "metadata.informationRequest.column.content",
        type: "string",
        flex: 1,
      },
      {
        key: "deadline",
        label: "metadata.informationRequest.column.deadline",
        type: "string",
        flex: 1,
        renderCell: (params) =>
          params?.value ? format(new Date(params?.value), "dd/MM/yyyy") : "",
      },
      {
        key: "status",
        label: "metadata.informationRequest.column.status",
        type: "string",
        flex: 1,
        renderCell: (params) =>
          params.row.type
            ? t(`legalAdvice.informationRequestType.${params.row.type}`)
            : "",
      },
    ];

  const getInformationRequestQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getInformationRequests(),
  });
  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={InformationRequestColumns}
        data={getInformationRequestQuery.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
    </div>
  );
};
