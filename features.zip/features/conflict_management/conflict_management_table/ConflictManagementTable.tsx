import {
  getConflictManagementExcel,
  getListConflictManagementQueryFn,
  shareConflictFn,
} from "@/apis/service/conflict_management/conflictManagementForm";
import { getStatusListNames } from "@/apis/service/status/Status";
import { getUser, getUsers } from "@/apis/service/user/User";
import { getAsyncSelectOperators } from "@/components/commons/filters/AsyncSelectFilter";
import { getMultipleAsyncChoosingOperators } from "@/components/commons/filters/MultipleAsyncChoosingFilter";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import MultipleTabsTable from "@/components/commons/tables/multiple_tabs_table/MultipleTabsTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import {
  ConflictActionsBtnKey,
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  MIME_TYPES,
  Module,
  ModuleKeys,
} from "@/constants/general";
import { CONFLICT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
// import ConflictManagementTableTooltip from "@/features/legal-advice/legal-advice-table-tooltip/LegalAdviceTableTooltip";
import {
  BaseConflictManagementFields,
  GetConflictManagementListParams,
} from "@/models/conflict_management/ConflictManagementList";
import { StatusDTO } from "@/models/status/Status";
import { GetUsersParams } from "@/models/user/User";
import { downloadFile, formatDate } from "@/utils";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { Button, Grid, IconButton } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { endOfDay, format } from "date-fns";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { Range as DateRange } from "react-date-range";
import { ConflictMngActions } from "./ConflictMngActions/ConflictMngActions";
import { ForwardConflictMngForm } from "../conflict _management_dialog/forward_conflict_mng_form";
import { TimeExtensionConflictMngForm } from "../conflict _management_dialog/time_extension_conflict_mng_form";
import { RequestAdditionalForm } from "../conflict _management_dialog/request_additional_information_form";
import { RequestEvaluateConflictForm } from "../conflict _management_dialog/RequestEvalueteConfictForm";
import { RequestApprovalConflictForm } from "../conflict _management_dialog/request_approval_form";
import { ConfirmConflictMngForm } from "../conflict _management_dialog/confirm_conflict_mng_form";
import { FinishConflictForm } from "../conflict _management_dialog/finish_conflict_mng_form";
import { AppContext } from "@/context/AppContext";
import { GridFilterItem } from "@mui/x-data-grid";
import { useRecallConflict } from "@/apis/service/conflict_management/conflictMngFormPopup";
import SendMailConflictForm from "../conflict _management_dialog/sendmail_conflict_form";
import { FollowConflictForm } from "../conflict _management_dialog/follow_conflict_mng_form";
import { FeedbackConflictForm } from "../conflict _management_dialog/feedback_conflict_mng_form";
import {
  ConflictManagementDetailFields,
  listStatusConfirmConflict,
  listStatusEvaluateConflict,
} from "@/models/conflict_management/ConflictManagementDetail";
import { SignApprovalConflictMngForm } from "../conflict _management_dialog/sign_approval_conflict_form";
import { EvaluateConflictMngForm } from "../conflict _management_dialog/evaluate_form";
import SharePopup from "@/components/commons/share_popup/SharePopup";

export const ConflictManagementTableConst = {
  GENERAL_TABLE: "LEGAL_ADVICE.title.general_table",
  GET_ALL_QUERY_KEY: "getAllConflictManagement",
  PERSONAL_TABLE: "LEGAL_ADVICE.title.personal_table",
  GET_PERSONAL_QUERY_KEY: "getPersonalConflictManagement",
  GET_CONFLICT_MANAGEMENT_EXCEL: "getConflictManagementExcel",
};

const getFieldLabel = (key: string) => {
  return `CONFLICT_MANAGEMENT.fields.${key}`;
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetConflictManagementListParams => {
  const params: GetConflictManagementListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 10,
    sortBy: BaseConflictManagementFields.ID,
    orderBy: "DESC",
  };
  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == BaseConflictManagementFields.CONFLICT_NAME) {
      params[BaseConflictManagementFields.CONFLICT_NAME] = item?.value;
    }
    if (
      item.field == BaseConflictManagementFields.EMPLOYEE_INFO_IDS &&
      item?.value
    ) {
      params[BaseConflictManagementFields.EMPLOYEE_INFO_IDS] = item?.value;
    }
    if (item.field == BaseConflictManagementFields.STATUS_CONFIRM) {
      params[BaseConflictManagementFields.STATUS_CONFIRM] = (item?.value ?? [])
        .map((item: StatusDTO) => item?.id ?? item)
        .join(",");
    }
    if (item.field == BaseConflictManagementFields.STATUS_EVALUATED) {
      params[BaseConflictManagementFields.STATUS_EVALUATED] = (
        item?.value ?? []
      )
        .map((item: StatusDTO) => item?.id ?? item)
        .join(",");
    }
    if (
      item.field == BaseConflictManagementFields.EMPLOYEE_POSITION &&
      item?.value
    ) {
      params[BaseConflictManagementFields.EMPLOYEE_POSITION] = item?.value;
    }
    if (
      item.field == BaseConflictManagementFields.EMPLOYEE_DEPARTMENT &&
      item?.value
    ) {
      params[BaseConflictManagementFields.EMPLOYEE_DEPARTMENT] = item?.value;
    }
    if (
      item.field == BaseConflictManagementFields.CONFLICT_OBJECT_NAME &&
      item?.value
    ) {
      params[BaseConflictManagementFields.CONFLICT_OBJECT_NAME] = item?.value;
    }
    if (
      item.field == BaseConflictManagementFields.CONFLICT_OBJECT_AGENCY &&
      item?.value
    ) {
      params[BaseConflictManagementFields.CONFLICT_OBJECT_AGENCY] = item?.value;
    }
    if (item.field == BaseConflictManagementFields.CONFIRMATION_DEADLINE) {
      params[BaseConflictManagementFields.CONFIRMATION_DEADLINE_FROM] = (
        item?.value as DateRange
      ).startDate?.toISOString();

      params[BaseConflictManagementFields.CONFIRMATION_DEADLINE_TO] = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }
    if (item.field == BaseConflictManagementFields.LC_REVIEW_DEADLINE) {
      params[BaseConflictManagementFields.LC_REVIEW_DEADLINE_FROM] = (
        item?.value as DateRange
      )?.startDate?.toISOString();

      params[BaseConflictManagementFields.LC_REVIEW_DEADLINE_TO] = endOfDay(
        new Date((item.value as DateRange)?.endDate as Date)
      )?.toISOString();
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};

const ConflictManagementTable = () => {
  const { t, i18n } = useTranslation();
  const [activeTab, setActiveTab] = useState<number>(0);
  const router = useRouter();
  const appContext = useContext(AppContext);

  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });
  const [initialConflictManagement, setInitialConflictManagement] =
    useState<any>(undefined);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialConflictManagement(row);
      changePopupVisible(type, true);
    }
  };
  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload: boolean = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state) {
      setInitialConflictManagement(undefined);
    }
    if (reload) {
      getAllConflictManagementQuery
        .refetch()
      getPersonalConflictManagementQuery
        .refetch()
    }
  };
  const { mutateAsync: recallConflictMutationFn } = useRecallConflict({
    config: {
      onSuccess: () => {
        toast.success(
          t("CONFLICT_MANAGEMENT.recallConflict.message.recall_success")
        );
        // getLegalAdviceQuery.refetch().then((response) => {
        //   setInitialLegalAdvice(response.data);
        // });
      },
    },
  });
  const [conflictManagementTableColumns] = useState<
    MultipleFilterTableColumn[]
  >([
    {
      key: BaseConflictManagementFields.ID,
      label: BaseConflictManagementFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: "center",
    },
    {
      key: BaseConflictManagementFields.CONFLICT_NAME,
      label: BaseConflictManagementFields.CONFLICT_NAME,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => (
        // <ConflictManagementTableTooltip
        //   adviceId={params.id}
        //   adviceName={params?.row?.conflictName}
        // >
        <span>{params.value}</span>
        // </ConflictManagementTableTooltip>
      ),
    },
    {
      key: BaseConflictManagementFields.EMPLOYEE_INFO_IDS,
      label: BaseConflictManagementFields.EMPLOYEE_CODE,
      filterLabel: "CONFLICT_MANAGEMENT.label.employeeInfo",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 200,
      renderCell: (params) => params?.row?.employeeInfo?.employee?.employeeCode ?? "",
      filterOperators: getAsyncSelectOperators(
        {
          getOptions: async (keyword) => {
            if (typeof keyword == "string") {
              const params: GetUsersParams = {
                searchTerm: keyword as string,
                page: 0,
                size: 100,
                sortBy: "name",
                sortOrder: "ASC",
              };
              const response = await getUsers(params);

              return response?.users ?? [];
            } else if (keyword?.length && keyword.length > 0) {
              return getUser(keyword[0])
                .then((response) => (response ? [response] : []))
                .catch(() => []);
            }
            return [];
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) =>
            `${item?.name} - ${item?.position?.name ? `${item?.position?.name}.` : ""
            }${item?.department?.name ?? ""}`,
          keyQuery: BaseConflictManagementFields.EMPLOYEE_INFO_IDS,
        },
        t
      ),
    },
    {
      key: BaseConflictManagementFields.EMPLOYEE_NAME,
      label: BaseConflictManagementFields.EMPLOYEE_NAME,
      type: undefined,
      quickFilter: false,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => {
        return params?.row?.employeeInfo?.employee?.name ?? "";
      },
    },
    {
      key: BaseConflictManagementFields.EMPLOYEE_POSITION,
      label: BaseConflictManagementFields.POSITION,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) =>
        params?.row?.employeeInfo?.positionNameCustom ?? "",
    },
    {
      key: BaseConflictManagementFields.EMPLOYEE_DEPARTMENT,
      label: BaseConflictManagementFields.DEPARTMENT,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) =>
        params?.row?.employeeInfo?.departmentNameCustom ?? "",
    },
    {
      key: BaseConflictManagementFields.CONFLICT_OBJECT_NAME,
      label: BaseConflictManagementFields.NAME,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.conflictObject?.name ?? "",
    },
    {
      key: BaseConflictManagementFields.CONFLICT_OBJECT_AGENCY,
      label: BaseConflictManagementFields.AGENCY,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.conflictObject?.agency ?? "",
    },
    {
      key: BaseConflictManagementFields.STATUS_CONFIRM,
      label: BaseConflictManagementFields.STATUS_CONFIRM,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        return (
          params.value?.name ? <Button
            variant="outlined"
            style={{
              background:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params.value?.name}
          </Button> : <></>
        );
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusListNames({
              names: listStatusConfirmConflict,
              modules: [Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!],
            });
            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) => item?.name,
          keyQuery: `conflict-management-${BaseConflictManagementFields.STATUS_CONFIRM}`,
        },
        t
      ),
    },
    {
      key: BaseConflictManagementFields.STATUS_EVALUATED,
      label: BaseConflictManagementFields.STATUS_EVALUATED,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        return (
          params.value?.name ? <Button
            variant="outlined"
            style={{
              background:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params.value?.name}
          </Button> : <></>
        );
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusListNames({
              names: listStatusEvaluateConflict,
              modules: [Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!],
            });
            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) => item?.name,
          keyQuery: `conflict-management-${BaseConflictManagementFields.STATUS_EVALUATED}`,
        },
        t
      ),
    },
    {
      key: BaseConflictManagementFields.CONFIRMATION_DEADLINE,
      label: BaseConflictManagementFields.CONFIRMATION_DEADLINE,
      filterLabel: `CONFLICT_MANAGEMENT.label.${BaseConflictManagementFields.CONFIRMATION_DEADLINE}`,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
    },
    {
      key: BaseConflictManagementFields.LC_REVIEW_DEADLINE,
      label: BaseConflictManagementFields.LC_REVIEW_DEADLINE,
      filterLabel: `CONFLICT_MANAGEMENT.label.${BaseConflictManagementFields.LC_REVIEW_DEADLINE}`,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
    },
    {
      key: BaseConflictManagementFields.ACTION,
      label: BaseConflictManagementFields.ACTION,
      type: undefined,
      // renderCell: (params) => "Action",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      renderCell: (params) =>
        !params?.row?.isDraft &&
        params?.row?.status?.name !==
        ConflictManagementStatusContent.get(
          ConflictManagementStatusKey.COMPLETED
        ) &&
        ConflictMngActions({
          actionButtonItemValidate: Object.entries(params?.row.buttonAction)
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            .filter(([_, value]) => value !== 3)
            .map(([key, value]) => ({
              typeBtn: key,
              disable: value === 2,
            })),
          params: params,
          handleClickRecall: async () =>
            recallConflictMutationFn(Number(params?.row.id)),
          handleClickForWard: () =>
            handleClick(ConflictActionsBtnKey.FORWARD, params.row),
          handleClickExtendTime: () =>
            handleClick(
              ConflictActionsBtnKey.REQUEST_TIME_EXTENSION,
              params.row
            ),
          handleClickConfirm: () =>
            handleClick(ConflictActionsBtnKey.CONFIRM, params.row),
          handleClickRequestAdditional: () =>
            handleClick(ConflictActionsBtnKey.REQUEST_ADDITIONAL, params.row),
          handleClickRequestEvaluate: () =>
            handleClick(ConflictActionsBtnKey.REQUEST_EVALUATE, params.row),
          handleClickDone: () =>
            handleClick(ConflictActionsBtnKey.DONE, params.row),
          handleClickRequestConfirm: () =>
            handleClick(ConflictActionsBtnKey.REQUEST_CONFIRM, params.row),
          handleClickConflictMonitor: () =>
            handleClick(ConflictActionsBtnKey.CONFLICT_MONITORING, params.row),
          handleClickSendMail: () =>
            handleClick(ConflictActionsBtnKey.SEND_MAIL),
          handleClickFeedBack: () =>
            handleClick(ConflictActionsBtnKey.FEEDBACK, params.row),
          handleClickExtendTimeConfirm: () =>
            handleClick(
              ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
              params.row
            ),
          handleClickEvaluate: () =>
            handleClick(ConflictActionsBtnKey.EVALUATE, params.row),
          handleClickSignApprove: () =>
            handleClick(ConflictActionsBtnKey.APPROVE, params.row),
          handleClickShare: () =>
            handleClick(ConflictActionsBtnKey.SHARE, params.row),
        }),
      cellClassName: "last-column-sticky",
      headerClassName: "last-column-sticky-header",
    },
  ]);

  /** Get all conflict management */
  const getAllConflictManagementQuery = useQuery({
    queryKey: [ConflictManagementTableConst.GET_ALL_QUERY_KEY],
    queryFn: () =>
      getListConflictManagementQueryFn({
        ...castTableStateToParams(generalTableState),
        tab: 0,
      }),
    enabled: false,
  });
  /** Get personal conflict management request */
  const getPersonalConflictManagementQuery = useQuery({
    queryKey: [ConflictManagementTableConst.GET_PERSONAL_QUERY_KEY],
    queryFn: () =>
      getListConflictManagementQueryFn({
        ...castTableStateToParams(personalTableState),
        tab: 1,
      }),
    enabled: false,
  });

  /** Get excel file */
  const getConflictManagementQuery = useQuery({
    queryKey: [ConflictManagementTableConst.GET_CONFLICT_MANAGEMENT_EXCEL],
    queryFn: () =>
      getConflictManagementExcel({
        ...castTableStateToParams(
          activeTab === 0 ? generalTableState : personalTableState
        ),
        tab: activeTab,
        size: 9999,
        isEnglish: i18n.language === "en",
      }),
    enabled: false,
  });

  useEffect(() => {
    generalTableState &&
      activeTab === 0 &&
      getAllConflictManagementQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  }, [generalTableState, activeTab]);

  useEffect(() => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalConflictManagementQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  }, [personalTableState, activeTab]);

  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getConflictManagementQuery.refetch().then((response: any) => {
              const fileName = `${i18n.language === "en"
                ? "ConflictManagement"
                : "Xung đột lợi ích"
                }_${format(new Date(), "ddMMyyyy")}`;
              response?.data &&
                downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getAllConflictManagementQuery.isFetching ||
            getPersonalConflictManagementQuery.isFetching ||
            getConflictManagementQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };

  const shareMutation = useMutation({
    mutationFn: shareConflictFn,
    onSuccess: () => {
      toast.success(
        t(`CONFLICT_MANAGEMENT.messages.shareSuccess`)
      );
    },
  });

  return (
    <>
      <MultipleTabsTable
        tableTabs={[
          {
            tabName: t("CONFLICT_MANAGEMENT.label.allConflictInterest"),
            tabKey: ConflictManagementTableConst.GENERAL_TABLE,
            data: getAllConflictManagementQuery?.data?.data ?? [],
            loading: getAllConflictManagementQuery?.isFetching,
            rowCount: getAllConflictManagementQuery?.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t("CONFLICT_MANAGEMENT.label.myConflictInterest"),
            tabKey: ConflictManagementTableConst.PERSONAL_TABLE,
            data: getPersonalConflictManagementQuery?.data?.data ?? [],
            loading: getPersonalConflictManagementQuery?.isFetching,
            rowCount: getPersonalConflictManagementQuery?.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={conflictManagementTableColumns.map((column) => ({
          ...column,
          label: column.label ? getFieldLabel(column.label) : "",
        }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        quickFilterProps={{
          defaultSelectedOptionKey: BaseConflictManagementFields.CONFLICT_NAME,
          placeHolder: () =>
            t("CONFLICT_MANAGEMENT.placeholder.enterAdviceName"),
        }}
        onRowClick={(params) =>
          router.push(
            `/${CONFLICT_MANAGEMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
          )
        }
        exportFile={renderExportButton()}
        onTabChange={setActiveTab}
      />

      {popupVisibleState?.[ConflictActionsBtnKey.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialConflictManagement?.pic}
          pics={initialConflictManagement?.responsibleUsers}
          onSubmit={async (data: any) => {
            const params = {
              id: initialConflictManagement?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
          initialValue={{
            legalAccessType: initialConflictManagement?.legalAccessType,
            sharedDepartments: initialConflictManagement?.sharedDepartments,
            sharedUsers: initialConflictManagement?.sharedUsers,
          }}
        />
      )}

      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAdditionalForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_ADDITIONAL,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL]}
          conflictId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialConflictManagement?.pic],
          }}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FORWARD] && (
        <ForwardConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FORWARD, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FORWARD]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {initialConflictManagement &&
        popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION] && (
          <TimeExtensionConflictMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.REQUEST_TIME_EXTENSION,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION]
            }
            ciId={initialConflictManagement?.id}
            name={initialConflictManagement?.conflictName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialConflictManagement?.pic],
              timeExtensionType: 1,
            }}
            deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}
          />
        )}
      {initialConflictManagement &&
        popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM] && (
          <TimeExtensionConflictMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM]
            }
            ciId={initialConflictManagement?.id}
            name={initialConflictManagement?.conflictName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialConflictManagement?.pic],
              timeExtensionType: 2,
            }}
            deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}

          />
        )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE] && (
        <RequestEvaluateConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_EVALUATE,
              state,
              reload
            )
          }
          ciId={initialConflictManagement?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE]}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
          deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}
          evaluater={
            initialConflictManagement?.[
              ConflictManagementDetailFields.LC_EMPLOYEES
            ]?.[0]
          }
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM] && (
        <RequestApprovalConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_CONFIRM,
              state,
              reload
            )
          }
          ciId={initialConflictManagement?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM]}
          name={initialConflictManagement?.conflictName}
          initialValue={{
            deadline: initialConflictManagement.lcReviewDeadline,
          }}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFIRM] && (
        <ConfirmConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.CONFIRM, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.CONFIRM]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.DONE] && (
        <FinishConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.DONE]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL] && (
        <SendMailConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.SEND_MAIL, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL]}
          conflictId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          legalAdvice={initialConflictManagement}
          senderDocumentManagement ={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFLICT_MONITORING] && (
        <FollowConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.CONFLICT_MONITORING,
              state,
              reload
            )
          }
          isOpen={true}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK] && (
        <FeedbackConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FEEDBACK, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {/* Ký duyệt */}
      {popupVisibleState?.[ConflictActionsBtnKey.APPROVE] && (
        <SignApprovalConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.APPROVE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.APPROVE]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}

      {/* Đánh giá nhận xét */}
      {popupVisibleState?.[ConflictActionsBtnKey.EVALUATE] && (
        <EvaluateConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.EVALUATE, state, reload)
          }
          isOpen={true}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
          deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}
          evaluater={initialConflictManagement?.pic}
        />
      )}
    </>
  );
};

export default ConflictManagementTable;
