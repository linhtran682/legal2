export type TypeActionRole = {
    typeBtn: string;
    disable: boolean;
  };
