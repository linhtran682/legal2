import { uploadDocumentTabAttachments } from "@/apis/service/files_upload/files";
import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { TabNav } from "@/components/commons/tab-nav/TabNav";
import { UploadPanel } from "@/components/commons/upload/upload_panel/UploadPanel";
import { COLOR_TYPE } from "@/constants/color";
import { AppContext } from "@/context/AppContext";
import { GenericContentPanel } from "@/features/metadata_tab_panel/generic_content_panel/GenericContentPanel";
import { InformationRequestPanel } from "@/features/metadata_tab_panel/information_request_panel/InformationRequestPanel";
import { LANGUAGES } from "@/locales/config-translation";
import {
  AdviceRequestFeedback,
  LegalAdviceForward,
} from "@/models/legal-advice/LegalAdviceList";
import { getUserLabel } from "@/utils";
import { FC, useContext } from "react";
import { useTranslation } from "react-i18next";
import { ConflictManagementExtendPanel } from "../metadata_tab_panel/conflict-management-extend-panel/ConflictManagementExtendPanel";
import { ConflictManagementFeedbackPanel } from "../metadata_tab_panel/conflict-management-feedback-panel/ConflictManagementFeedbackPanel";
import { ConflictManagementHistoryPanel } from "../metadata_tab_panel/conflict-management-history-panel/ConflictManagementHistoryPanel";
import { ConflictManagementBodyReceive } from "@/models/conflict_management/ConflictManagementDetail";
import {
  getConflictManagementApproval,
  getConflictManagementAttachment,
  getConflictManagementEvaluateTab,
  getConflictManagementExtensions,
  getConflictManagementForwards,
  getConflictManagementHistory,
  getConflictManagementInformationRequests,
  getConflictManagementRequestFeedback,
} from "@/apis/service/conflict_management/conflictManagementForm";
import { ConflictManagementEvaluationPanel } from "../metadata_tab_panel/conflict-management-evaluation_panel/ConflictManagementEvaluationPanel";
import { ConflictManagementConfirmPanel } from "../metadata_tab_panel/conflict-management-confirm_panel/ConflictManagementConfirmPanel";

export interface LegalAdviceTabsProps {
  conflictManagementId: number;
  conflictManagement?: ConflictManagementBodyReceive;
  loading?: boolean;
}

const ConflictManagementTabs: FC<LegalAdviceTabsProps> = (props) => {
  const { conflictManagementId, conflictManagement } = props;
  const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const { loading } = props;
  const isEnglish = i18n.language === LANGUAGES.ENGLISH;

  return (
    <LoadingWrapper loading={loading || appContext.loading}>
      <div style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
        <TabNav
          tabItems={[
            // 1. Yêu cầu bổ sung thông tin
            {
              key: "information-request",
              label: t("metadata.informationRequest.title"),
              content: (
                <InformationRequestPanel
                  queryKey="conflict-management-information-request"
                  getInformationRequests={async () => {
                    return (
                      (
                        await getConflictManagementInformationRequests(
                          conflictManagementId
                        )
                      )?.detailInformationRequestResponses?.map(
                        (ele, index: number) => ({
                          ...ele,
                          id: index + 1,
                        })
                      ) ?? []
                    );
                  }}
                />
              ),
            },
            // 2. Đánh giá
            {
              key: "evaluation",
              label: t("metadata.evaluation.title"),
              content: (
                <ConflictManagementEvaluationPanel
                  queryKey="conflict-management-evaluation"
                  getEvaluations={async () =>
                    (await getConflictManagementEvaluateTab(conflictManagementId))
                      .result?.responses ?? []
                  }
                />
              ),
            },
            // 3. Duyệt
            {
              key: "confirm",
              label: t("metadata.confirm.title"),
              content: (
                <ConflictManagementConfirmPanel
                  queryKey="legal-document-confirm"
                  getConfirmRecords={async () =>
                    (await getConflictManagementApproval(conflictManagementId))
                      .result?.requestApproveResponses ?? []
                  }
                />
              ),
            },
            // 4. Đính kèm
            {
              key: "attachment",
              label: t("metadata.attachment.title"),
              content: (
                <UploadPanel
                  queryKey="conflict-management-upload"
                  onGetFiles={async () =>
                    (
                      (await getConflictManagementAttachment(conflictManagementId,24))
                        ?.data || []
                    ).map((legalDocumentAttachment) => ({
                      fileId: legalDocumentAttachment.fileId,
                      fileName: legalDocumentAttachment.fileName,
                      storagePath: legalDocumentAttachment.filePath,
                      uploadDate: legalDocumentAttachment.uploadDate,
                    }))
                  }
                  onDelete={() => Promise.resolve()}
                  onUpload={async (files) => {
                    await uploadDocumentTabAttachments({
                      files: files,
                      id: conflictManagementId,
                      reference_file_type: 24,
                    });
                  }}
                  disabled
                />
              ),
            },
            // 5. Chuyển tiếp
            {
              key: "forward",
              label: t("metadata.forward.title"),
              content: (
                <GenericContentPanel<LegalAdviceForward>
                  getData={async () => {
                    return (
                      (
                        await getConflictManagementForwards(
                          conflictManagementId
                        )
                      )?.forwardResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) => getUserLabel(item.forwardUser, isEnglish)}
                  getDisplayDate={(item) => item.forwardDate}
                  getSubtitle={(item) =>
                    `${t("legalAdvice.tabs.forwardedTo")}:  ${item?.receiveUsers
                      ?.map((user) => getUserLabel(user, isEnglish))
                      .join(", ")}`
                  }
                  contentHeader="legalAdvice.forwardLegalAdvice.title.content"
                  getContent={(item) => item.content}
                  queryKey="conflict-management-forward"
                />
              ),
            },
            // 6. Gia hạn thời gian
            {
              key: "extend",
              label: t("metadata.extend.title"),
              content: (
                <ConflictManagementExtendPanel
                  conflictManagementId={conflictManagementId}
                  conflictManagement={conflictManagement}
                  getExtendRecords={async () => {
                    return (
                      (
                        await getConflictManagementExtensions(
                          conflictManagementId
                        )
                      )?.timeExtensionResponseDetails ?? []
                    );
                  }}
                  queryKey="conflict-management-extend-tab"
                />
              ),
            },
            // 7. Phản hồi văn bản
            {
              key: "request-feedback",
              label: t("legalAdvice.tabs.documentFeedback"),
              content: (
                <ConflictManagementFeedbackPanel<AdviceRequestFeedback>
                  getData={async () => {
                    return (
                      (
                        await getConflictManagementRequestFeedback(
                          conflictManagementId
                        )
                      )?.feedbackResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) =>
                    getUserLabel(item.feedbackUser, isEnglish)
                  }
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) =>
                    `${t("legalAdvice.tabs.feedbackTo")}: ${item.receiveUsers
                      .map((user) => getUserLabel(user, isEnglish))
                      .join(", ")}`
                  }
                  contentHeader="legalAdvice.tabs.feedbackContent"
                  getContent={(item) => item.content}
                  queryKey="conflict-management-request-feedback"
                />
              ),
            },
            // 9. Lịch sửa
            {
              key: "history",
              label: t("metadata.history.title"),
              content: (
                <ConflictManagementHistoryPanel
                  queryKey="conflict-management-history"
                  getHistoryRecords={async () => {
                    return (
                      (await getConflictManagementHistory(conflictManagementId))
                        .result?.data ?? []
                    );
                  }}
                />
              ),
            },
          ]}
        />
      </div>
    </LoadingWrapper>
  );
};

export default ConflictManagementTabs;
