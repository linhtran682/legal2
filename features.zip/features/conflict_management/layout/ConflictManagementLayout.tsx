import { Grid } from "@mui/material";
import { ReactNode, useState } from "react";
import { GenericSearchPanel } from "@/components/commons/search_panel/GenericSearchPanel";
import { conflictManagementSearchPanelConfig } from "@/models/conflict_management/ConflictManagementDetail";
import { EmptyIndicator } from "@/components/commons/empty_idicator/EmptyIndicator";

export interface LegalDocumentLayoutProps {
  children: ReactNode | ReactNode[];
}

export const ConflictManagementLayout = (props: LegalDocumentLayoutProps) => {
  const [isResultSearchPanel, setIsResultSearchPanel] = useState(true);
  const handleSetResultSearchPanel = (value: boolean) => {
    setIsResultSearchPanel(value);
  };
  return (
    <Grid
      direction={"row"}
      wrap="nowrap"
      sx={{ display: "flex", overflow: "hidden", height: "100%" }}
    >
      <Grid
        item
        sx={{ overflow: "auto", height: "100%", position: "relative" }}
      >
        <GenericSearchPanel<any>
          {...conflictManagementSearchPanelConfig}
          setIsResultSearchPanel={handleSetResultSearchPanel}
        />
      </Grid>
      <Grid
        item
        flex={1}
        style={{
          maxWidth: "100%",
          transition: "max-width 0.2s ease",
          height: "calc(100vh - 200px)",
          overflow: "auto",
          position: "relative",
        }}
      >
        {!isResultSearchPanel ? (
          <EmptyIndicator bgColor="white" />
        ) : (
          props.children
        )}
      </Grid>
    </Grid>
  );
};
