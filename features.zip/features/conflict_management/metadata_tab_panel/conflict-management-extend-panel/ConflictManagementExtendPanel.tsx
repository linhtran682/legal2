import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { ConflictManagementBodyReceive } from "@/models/conflict_management/ConflictManagementDetail";
import { AdviceExtension } from "@/models/legal-advice/LegalAdviceList";
import { Button } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import { TimeExtensionConflictMngForm } from "../../conflict _management_dialog/time_extension_conflict_mng_form";
import { AppContext } from "@/context/AppContext";

export interface ConflictManagementExtendPanelProps {
  queryKey: string;
  getExtendRecords: () => Promise<AdviceExtension[]>;
  conflictManagementId?: number;
  conflictManagement?: ConflictManagementBodyReceive;
}

export const ConflictManagementExtendPanel = (
  props: ConflictManagementExtendPanelProps
) => {
  const {
    queryKey,
    getExtendRecords,
    conflictManagementId,
    conflictManagement,
  } = props;
  const { i18n, t } = useTranslation();
  const appContext = useContext(AppContext);
  const [extendDeadlineId, setExtendDeadlineId] = useState<number>();
  const [isOpenTimeExtension, setIsOpenTimeExtension] =
    useState<boolean>(false);
  const getExtendRecordsQuery = useQuery({
    queryKey: [queryKey],
    queryFn: () => getExtendRecords(),
  });

  const handleClickExtend = (params: AdviceExtension) => {
    setIsOpenTimeExtension(true);
    setExtendDeadlineId(params?.id);
  };

  const ExtendTableColumns: StandardSimpleTableColumn<AdviceExtension>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +params?.id + 1,
    },
    {
      key: "department",
      label: "metadata.extend.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.department?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.extend.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "reason",
      label: "timeExtension.title.reason",
      type: "string",
      flex: 1,
    },
    {
      key: "requestDeadline",
      label: "legalAdvice.tabs.requestDeadline",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row.requestDeadline
          ? format(new Date(params.row.requestDeadline), "dd/MM/yyyy")
          : "",
    },
    {
      key: "acceptDeadline",
      label: "legalAdvice.tabs.acceptDeadline",
      type: "date",
      flex: 1,
      renderCell: (params) =>
        params.row.acceptDeadline
          ? format(new Date(params.row.acceptDeadline), "dd/MM/yyyy")
          : "",
    },
    {
      key: "timeExtensionType",
      label: "metadata.extend.column.type",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row.timeExtensionType
          ? t(
              `CONFLICT_MANAGEMENT.timeExtensionType.${params.row.timeExtensionType}`
            )
          : "",
    },
    {
      key: "status",
      label: "metadata.extend.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row.type ? t(`legalAdvice.extendType.${params.row.type}`) : "",
    },
    {
      key: "actionType",
      label: "Action",
      type: "string",
      flex: 1,
      renderCell: (params) => {
        return params.row?.showExtension ? (
          <Button
            disabled={!params.row?.enableExtension}
            onClick={() => handleClickExtend(params?.row)}
          >
            Gia hạn
          </Button>
        ) : (
          <></>
        );
      },
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={ExtendTableColumns}
        data={getExtendRecordsQuery?.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
      {isOpenTimeExtension && extendDeadlineId && conflictManagementId && (
        <TimeExtensionConflictMngForm
          setIsOpen={(state) => setIsOpenTimeExtension(state)}
          timeExtensionRequestId={extendDeadlineId}
          isConfirmExtension
          isOpen={isOpenTimeExtension}
          ciId={conflictManagementId}
          name={conflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
    </div>
  );
};
