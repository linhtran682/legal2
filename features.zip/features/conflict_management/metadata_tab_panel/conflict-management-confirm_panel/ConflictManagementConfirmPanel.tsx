import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { ConflictApproval } from "@/models/conflict_management/ConflictManagementDetail";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

export interface ConfirmPanelProps {
  queryKey: string;
  getConfirmRecords: () => Promise<ConflictApproval[]>;
}

export const ConflictManagementConfirmPanel = (props: ConfirmPanelProps) => {
  const { i18n, t } = useTranslation();

  const getConfirmRecordsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getConfirmRecords(),
  });

  const ConfirmTableColumns: StandardSimpleTableColumn<ConflictApproval>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +(params?.id ?? 0) + 1,
    },
    {
      key: "department",
      label: "metadata.confirm.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.confirm.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "content",
      label: "metadata.confirm.column.content",
      type: "string",
      flex: 1,
    },
    {
      key: "deadline",
      label: "metadata.confirm.column.date",
      type: "date",
      flex: 1,
    },
    {
      key: "evaluateUsers",
      label: "metadata.confirm.column.evaluateUsers",
      type: "string",
      flex: 1,
      renderCell: (params) => {
        const evaluateUsers =
          params.row?.user?.[
            i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
          ];
        return evaluateUsers;
      },
    },
    {
      key: "status",
      label: "metadata.confirm.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        t(`CONFLICT_MANAGEMENT.typeConfirmTab.${params.row.status}`),
    },
  ];
  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={ConfirmTableColumns}
        data={getConfirmRecordsQuery.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
    </div>
  );
};
