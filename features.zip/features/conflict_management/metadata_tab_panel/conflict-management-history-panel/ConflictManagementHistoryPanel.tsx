import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { HistoryRecord } from "@/models/metadata/Metadata";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

export interface ConflictManagementHistoryPanelProps {
  queryKey: string;
  getHistoryRecords: () => Promise<HistoryRecord[]>;
}

export const ConflictManagementHistoryPanel = (
  props: ConflictManagementHistoryPanelProps
) => {
  const { t } = useTranslation();
  const getHistoryRecordsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getHistoryRecords(),
  });

  const getUserAction = (history: HistoryRecord) => {
    if (history.action === 10 || history.action === 16) {
      return (
        <>
          <p>
            {t(`CONFLICT_MANAGEMENT.actionHistoryContent.${history.action}`, {
              username: history.actionOwner.name,
            })}
          </p>
          <p>
            {t(`CONFLICT_MANAGEMENT.label.content`)}: {history.content}
          </p>
        </>
      );
    }

    return t(`CONFLICT_MANAGEMENT.actionHistoryContent.${history.action}`, {
      username: history.actionOwner.name,
    });
  };

  const HistoryTableColumns: StandardSimpleTableColumn<HistoryRecord>[] = [
    {
      key: "date",
      label: "metadata.history.column.date",
      type: "date",
      flex: 1,
    },
    {
      key: "user",
      label: "metadata.history.column.user",
      type: "string",
      flex: 1,
      renderCell: (params) => getUserAction(params.row),
    },
    {
      key: "action",
      label: "Action",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        t(`CONFLICT_MANAGEMENT.typeHistoryTab.${params.row.action}`),
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={HistoryTableColumns}
        data={getHistoryRecordsQuery.data ?? []}
        getRowId={(row) => row.date}
      />
    </div>
  );
};
