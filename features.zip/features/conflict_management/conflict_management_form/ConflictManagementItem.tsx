import { IconDelete } from "@/assets/iconMenu/iconDelete";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { LegalAdviceDetailFields } from "@/models/legal-advice/LegalAdviceDetail";
import EditNoteRoundedIcon from "@mui/icons-material/EditNoteRounded";
import { Box, Grid, IconButton, Typography } from "@mui/material";
import { FC, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

interface ConflictListItemProps {
  conflictItem: any;
  label?: string;
  indexConflictItem: number;
  labelContent?: string;
  onDeleteClick?: () => void;
  onEditClick?: () => void;
  backgroundColor?: string;
  isActiveAction?: boolean;
}
const ConflictManagementItem: FC<ConflictListItemProps> = (props) => {
  const [t] = useTranslation();
  const {
    conflictItem,
    indexConflictItem,
    onEditClick,
    label,
    onDeleteClick,
    backgroundColor = COLOR_TYPE.BLUE.BLUE06,
    labelContent = `CONFLICT_MANAGEMENT.label.content`,
    isActiveAction = true,
  } = props;
  const form = useForm();
  const [files, setFiles] = useState<any>([]);
  const resetForm = (newAdvise: any) => {
    if (newAdvise?.attachments?.length) {
      setFiles(
        newAdvise.attachments?.map((item: any) => {
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        })
      );
    }
    form?.reset?.({
      advisor: newAdvise.user.id,
      content: newAdvise.content,
    });
  };

  useEffect(() => {
    resetForm(conflictItem);
  }, [conflictItem]);

  return (
    <Grid
      item
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
      sx={{
        backgroundColor,
      }}
    >
      <Grid item xs={12} display={"flex"}>
        <Box flex={1}>
          {label && <label style={{ padding: 0 }}>{t(label)}</label>}
          <Typography>
            {conflictItem.user.name} ({conflictItem.user.email}) -{" "}
            {conflictItem.user.department?.name}
          </Typography>
        </Box>
        {isActiveAction && indexConflictItem === 0 && (
          <Box>
            <IconButton onClick={onDeleteClick} sx={{ height: "fit-content" }}>
              <IconDelete />
            </IconButton>
            <IconButton onClick={onEditClick} sx={{ height: "fit-content" }}>
              <EditNoteRoundedIcon />
            </IconButton>
          </Box>
        )}
      </Grid>
      <Grid item width={"100%"}>
        <FormTextArea
          control={form.control}
          name="content"
          label={t(labelContent)}
          placeHolder={t(labelContent)}
          required
          minRows={2}
          disabled
        />
      </Grid>
      <Grid item width={"100%"}>
        <DropPreviewFileUploadComponent
          preview
          disabled
          inputId={`file-input-${conflictItem.id}-${label}`}
          files={files}
          setFiles={setFiles}
          title={t(`legalAdvice.label.${LegalAdviceDetailFields.ATTACHMENTS}`)}
        />
      </Grid>
    </Grid>
  );
};

export default ConflictManagementItem;
