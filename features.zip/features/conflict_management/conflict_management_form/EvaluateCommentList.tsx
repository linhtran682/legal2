import { GLOBAL_SPACING } from "@/constants/format";
import {  Grid, Typography } from "@mui/material";
import { FC, useContext, useEffect, useState } from "react";
import ConflictManagementItem from "./ConflictManagementItem";
import { ConflictInformation } from "@/models/conflict_management/ConfirmConflict";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import {
  GET_EVALUATE_COMMENT_LIST,
  getListConflictManagementEvaluate,
  useDeleteEvaluateMng,
} from "@/apis/service/conflict_management/conflictManagementForm";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import {
  ConflictManagementRole,
  ConflictManagementRoleKey,
} from "@/constants/general";
import { EvaluateConflictMngForm } from "../conflict _management_dialog/evaluate_form";
import { AppContext } from "@/context/AppContext";

interface EvaluateCommentListProps {
  conflictManagementId: number;
  conflictName?: string;
  initialValue?: any;
  ownRole?: number[];
}

const EvaluateCommentList: FC<EvaluateCommentListProps> = (props) => {
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const { conflictManagementId, ownRole, initialValue } = props;
  const queryClient = useQueryClient();
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedEvaluate, setSelectedEvaluate] = useState<
    ConflictInformation | undefined
  >(undefined);
  const [evaluatePopupState, setEvaluatePopupState] =
    useState<ConfirmPopupProps>(() => DefaultConfirmPopupState);
  const getEvaluateCommentListQuery = useQuery({
    queryKey: [GET_EVALUATE_COMMENT_LIST, conflictManagementId],
    queryFn: () => getListConflictManagementEvaluate(conflictManagementId),
    enabled: !!conflictManagementId,
  });
  const { mutateAsync: deleteEvaluateMutationFn } = useDeleteEvaluateMng({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t("Đánh giá/Nhận xét"),
          })
        );
        setEvaluatePopupState(DefaultConfirmPopupState);
        queryClient.invalidateQueries({
          queryKey: [GET_EVALUATE_COMMENT_LIST],
        });
      },
    },
  });
  const handleEditClick = (conflictItem: ConflictInformation) => {
    setSelectedEvaluate(conflictItem);
    setPopupVisible(true);
  };

  const handleDeleteClick = (conflictItem: ConflictInformation) => {
    setEvaluatePopupState({
      open: true,
      icon: <DeleteRecordDialogIcon />,
      title: "Bạn có chắc chắn muốn xóa không ?",
      handleConfirm: async () => {
        await deleteEvaluateMutationFn({
          ciId: conflictManagementId,
          evaluateId: conflictItem.id,
        });
      },
      handleCancel: () => setEvaluatePopupState(DefaultConfirmPopupState),
    });
  };
  const onPopupClose = async () => {
    setPopupVisible(false);
    setSelectedEvaluate(undefined);
  };
  useEffect(() => {
    conflictManagementId && getEvaluateCommentListQuery.refetch();
  }, [conflictManagementId]);

  return getEvaluateCommentListQuery?.data?.result?.responses?.length ? (
    <Grid
      container
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
    >
      <Typography fontWeight="bold">
        {t("CONFLICT_MANAGEMENT.label.evaluateConflict")}
      </Typography>
      {(getEvaluateCommentListQuery?.data?.result?.responses ?? [])?.map(
        (conflictItem: ConflictInformation, index: number) => (
          <ConflictManagementItem
            key={conflictItem?.id?.toString()}
            indexConflictItem={index}
            isActiveAction={ownRole?.includes(
              ConflictManagementRole.get(ConflictManagementRoleKey.LC)!
            )}
            label={`CONFLICT_MANAGEMENT.label.reviewer`}
            onDeleteClick={() => handleDeleteClick(conflictItem)}
            onEditClick={() => handleEditClick(conflictItem)}
            conflictItem={{
              ...conflictItem,
              user: conflictItem?.userResponse,
              attachments: conflictItem?.attachmentResponses,
            }}
          />
        )
      )}
      <ConfirmPopup {...evaluatePopupState} />
      {popupVisible && (
        <>
          <EvaluateConflictMngForm
            setIsOpen={onPopupClose}
            isOpen={popupVisible}
            ciId={conflictManagementId}
            evaluateId={selectedEvaluate?.id}
            name={initialValue?.conflictName}
            senderDocumentManagement={appContext?.me}
          />
        </>
      )}
    </Grid>
  ) : null;
};

export default EvaluateCommentList;
