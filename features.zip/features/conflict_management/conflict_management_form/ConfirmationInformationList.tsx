import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import { FC, useContext, useState } from "react";
import ConflictManagementItem from "./ConflictManagementItem";
import {
  useDeleteConfirmInformation,
  useGetConfirmInformation,
} from "@/apis/service/conflict_management/conflictMngFormPopup";
import { ConflictInformation } from "@/models/conflict_management/ConfirmConflict";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import { useQueryClient } from "@tanstack/react-query";
import { ConflictManagementRole, ConflictManagementRoleKey } from "@/constants/general";
import { GET_CONFIRM_INFORMATION_MANAGEMENT } from "@/apis/service/conflict_management/conflictManagementForm";
import { ConfirmConflictMngForm } from "../conflict _management_dialog/confirm_conflict_mng_form";
import { AppContext } from "@/context/AppContext";

interface ConfirmListProps {
  conflictManagementId: number;
  conflictName?: string;
  initialValue?: any;
  ownRole?: number[]
}

const ConfirmationInformationList: FC<ConfirmListProps> = (props) => {
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const { conflictManagementId, ownRole, initialValue } = props;
  const queryClient = useQueryClient();
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedConfirm, setSelectedConfirm] = useState<ConflictInformation | undefined>(
    undefined
  );
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const { data: getConfirmationInformationListQuery } =
    useGetConfirmInformation({
      request: { ciId: conflictManagementId },
      config: {
        enabled: !!conflictManagementId,
      },
    });
  const { mutateAsync: deleteConfirmInformationMutationFn } =
    useDeleteConfirmInformation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("Xác nhận"),
            })
          );
          setConfirmPopupState(DefaultConfirmPopupState);
          queryClient.invalidateQueries({
            queryKey: [GET_CONFIRM_INFORMATION_MANAGEMENT],
          });
        },
      },
    });
  const handleEditClick = (conflictItem: ConflictInformation) => {
    setSelectedConfirm(conflictItem);
    setPopupVisible(true);
  };

  const handleDeleteClick = (conflictItem: ConflictInformation) => {
    setConfirmPopupState({
      open: true,
      icon: <DeleteRecordDialogIcon />,
      title: "Bạn có chắc chắn muốn xóa không ?",
      handleConfirm: async () => {
        await deleteConfirmInformationMutationFn({
          ciId: conflictManagementId,
          confirmId: conflictItem.id,
        });
        setConfirmPopupState(DefaultConfirmPopupState);
      },
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
    });
  };
  const onPopupClose = async () => {
    setPopupVisible(false);
    setSelectedConfirm(undefined);
  };
  return getConfirmationInformationListQuery?.responses?.length ? (
    <Grid
      container
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
    >
      <Typography fontWeight="bold">
        {t("CONFLICT_MANAGEMENT.label.informationConfirm")}
      </Typography>
      {(getConfirmationInformationListQuery?.responses ?? [])?.map(
        (conflictItem: ConflictInformation, index: number) => (
          <ConflictManagementItem
            key={conflictItem.id.toString()}
            indexConflictItem={index}
            isActiveAction={ownRole?.includes(
              ConflictManagementRole.get(
                ConflictManagementRoleKey.DEPT_HEAD_EMPLOYEE_CONFLICT
              )!
            )}
            label={`CONFLICT_MANAGEMENT.label.approver`}
            onDeleteClick={() => handleDeleteClick(conflictItem)}
            onEditClick={() => handleEditClick(conflictItem)}
            conflictItem={{
              ...conflictItem,
              user: conflictItem?.userResponse,
              attachments: conflictItem?.attachmentResponses,
            }}
          />
        )
      )}
      <ConfirmPopup {...confirmPopupState} />
      {popupVisible && (
        <>
          <ConfirmConflictMngForm
            setIsOpen={onPopupClose}
            isOpen={popupVisible}
            ciId={conflictManagementId}
            confirmId={selectedConfirm?.id}
            name={initialValue?.conflictName}
            senderDocumentManagement={appContext?.me}
          />
        </>
      )}
    </Grid>
  ) : null;
};

export default ConfirmationInformationList;
