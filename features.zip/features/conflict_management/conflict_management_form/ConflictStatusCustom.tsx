import React from "react";
import { Button, Tooltip } from "@mui/material";
import HelpIcon from "@mui/icons-material/Help";
import { StatusDTO } from "@/models/status/Status";
export interface FormAsyncSelectProps {
  label?: string;
  variant?: "filled" | "outlined" | "standard";
  required?: boolean;
  explanation?: string;
  optionItem?: StatusDTO;
}
export const ConflictStatusCustom = ({
  label,
  required,
  explanation,
  optionItem,
}: FormAsyncSelectProps) => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "row",
        width: "100%",
        alignItems: "center",
        gap: 8
      }}
    >
      {label && (
        <label className={label ?? "no-label"}>
          {label}
          {explanation && (
            <Tooltip title={explanation} placement="top-start">
              <HelpIcon fontSize={"small"} />
            </Tooltip>
          )}
          {required && <span style={{ color: "red" }}>*</span>}
        </label>
      )}
      <Button
        variant="outlined"
        style={{
          background:
            optionItem?.name === "Hoàn thành" ? "#E7F4EE" : "#D781001A",
          borderRadius: "100px",
          color: optionItem?.name === "Hoàn thành" ? "#0D894F" : "#D78100",
          border: "none",
          padding: "4px 12px",
        }}
      >
        {optionItem?.name}
      </Button>
    </div>
  );
};
