import {
  getDepartmentHeads,
  getLegalDepartments,
} from "@/apis/service/department/department";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { getUser, getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { CheckBoxGroupField } from "@/components/commons/form_inputs/CheckBoxGroupFiled";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys, NatureConflict, NatureConflictKey } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { LANGUAGES } from "@/locales/config-translation";
import {
  TypeConflictManagementForm,
  ConflictManagementBodySend,
  ConflictManagementDetailFields,
  SaveConflictManagementRequestSchema,
  SaveConflictManagementRequestCreateSchema,
} from "@/models/conflict_management/ConflictManagementDetail";
import { FileInfo } from "@/models/law_document/LawDocument";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { GetUsersParams, UserProfileDTO } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  FormHelperText,
  Grid,
  Stack,
  Typography,
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { FC, ReactNode, useContext, useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import ConfirmationInformationList from "./ConfirmationInformationList";
import FollowConflictList from "./FollowConflictList";
import EvaluateCommentList from "./EvaluateCommentList";
import { getAssignedPerson } from "@/apis/service/assignment/Assignment";
import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";
import { toast } from "react-toastify";

export interface ConflictManagementFormProps {
  formMode?: "create" | "update";
  onSubmit: (data: ConflictManagementBodySend) => void;
  onSubmitDraft?: (data: ConflictManagementBodySend) => void;
  initialValue?: any;
  onCancel: () => void;
  loading?: boolean;
  defaultValues?: TypeConflictManagementForm;
  children?: ReactNode;
}

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}

const ConflictManagementForm: FC<ConflictManagementFormProps> = (props) => {
  const {
    formMode,
    onSubmit,
    onSubmitDraft,
    onCancel,
    loading,
    defaultValues,
    initialValue,
  } = props;
  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);
  const { i18n, t } = useTranslation();
  const appContext = useContext(AppContext);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const [employeeInfo, setEmployeeInfo] = useState<UserProfileDTO>()
  // TypeConflictManagementForm
  const form = useForm<any>({
    resolver: yupResolver(
      formMode === "update"
        ? SaveConflictManagementRequestSchema
        : SaveConflictManagementRequestSchema.concat(
            SaveConflictManagementRequestCreateSchema
          )
    ),
    defaultValues,
    mode: "onBlur",
    disabled:
      !appContext.meCanWrite ||
      (formMode === "update" && !ownRole?.includes(1)),
  });
  
  useEffect(() => {
    if (initialValue) {
      let attachments: any[] = [];
      if (initialValue?.employeeAttachments.length) {
        attachments = initialValue?.employeeAttachments?.map((item: any) => {
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        });
      }
      setFiles(attachments);
      setOwnRole(initialValue?.ownerRoles);
    }
  }, [initialValue]);
  
  useEffect(()=>{
    if (defaultValues) {
      form.reset(defaultValues);
    }
  },[defaultValues])
  
  const getLegalDepartmentQuery = useQuery({
    queryKey: ["conflict-management/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });
  
  const getDepartmentHeadQuery = useQuery({
    queryKey: ["conflict-management/get-department-heads"],
    queryFn: async () => {
      const departmentHeadResponse = await getDepartmentHeads(
        initialValue?.pic?.departmentResponse?.id ?? appContext?.me?.department?.id as string
      );
      return departmentHeadResponse;
    },
    placeholderData: (prev) => prev,
    enabled: !!initialValue?.pic || !!appContext?.me,
  });
  
  const checkDeptHeadFlag = form.watch(
    ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG
  );
  const checkDivisionFlag = form.watch(
    ConflictManagementDetailFields.CHECK_DIVISION_FLAG
  );
  const sendToError = !checkDeptHeadFlag && !checkDivisionFlag;

  const handleSaveParams = async () => {
    let attachments: number[] = [];
    if (files.length > 0) {
      const filterFile: any = [];
      const filterFileId: number[] = [];

      files.filter((item: any) => {
        if (item?.id === undefined) {
          filterFile.push(item);
        } else {
          filterFileId.push(item?.id);
        }
      });
      if (filterFile.length > 0) {
        const response = await GetListIdFile(filterFile);
        const formatResponse: number[] = response.fileUploadResponses.map(
          (item: FileInfo) => item.fileId
        );
        attachments = [...formatResponse, ...filterFileId];
      } else {
        attachments = [...filterFileId];
      }
    }
    
    const formValues = form.getValues();
    const params: ConflictManagementBodySend = {} as ConflictManagementBodySend;
    params[ConflictManagementDetailFields.CONFLICT_NAME] =
      formValues[ConflictManagementDetailFields.CONFLICT_NAME];
    if(formValues[ConflictManagementDetailFields.STATUS_CONFIRM]){
      params[ConflictManagementDetailFields.STATUS_CONFIRM] = Number(
        formValues[ConflictManagementDetailFields.STATUS_CONFIRM]
      );
    }
    if(formValues[ConflictManagementDetailFields.STATUS_EVALUATED]){
      params[ConflictManagementDetailFields.STATUS_EVALUATED] = Number(
        formValues[ConflictManagementDetailFields.STATUS_EVALUATED]
      );
    }
    params.employeeInfo = {
      employeeId: formValues[ConflictManagementDetailFields.EMPLOYEE_NAME] ?? "",
      [ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM]:
        formValues[ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM] ?? "",
      [ConflictManagementDetailFields.DEPARTMENT]:
        employeeInfo?.department?.id ??
        formValues?.employeeInfo?.employee?.departmentResponse?.id,
      [ConflictManagementDetailFields.POSITION_NAME_CUSTOM]:
        formValues[ConflictManagementDetailFields.POSITION_NAME_CUSTOM] ?? "",
      [ConflictManagementDetailFields.MANAGER_ID]:
        formValues[ConflictManagementDetailFields.MANAGER_ID],
    };
    params[ConflictManagementDetailFields.ATTACHMENTS] = attachments,
    params.conflictObject = {
      name: formValues[ConflictManagementDetailFields.CONFLICT_OBJECT_NAME],
      agency: formValues[ConflictManagementDetailFields.CONFLICT_OBJECT_AGENCY],
      position:
        formValues[ConflictManagementDetailFields.CONFLICT_OBJECT_POSITION],
      relation:
        formValues[ConflictManagementDetailFields.CONFLICT_OBJECT_RELATION],
    };
    params[ConflictManagementDetailFields.NATURE_CONFLICT] =
      formValues[ConflictManagementDetailFields.NATURE_CONFLICT] ?? [];
    params[ConflictManagementDetailFields.REASON_CONFLICT] =
      formValues?.[ConflictManagementDetailFields.REASON_CONFLICT] ?? "";
    params[ConflictManagementDetailFields.CONFLICT_DETAIL] =
      formValues[ConflictManagementDetailFields.CONFLICT_DETAIL];
    params[ConflictManagementDetailFields.CONFLICT_RESOLUTION] =
      formValues[ConflictManagementDetailFields.CONFLICT_RESOLUTION];
    params[ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG] = Number(
      formValues[ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG]
    );
    params[ConflictManagementDetailFields.EMPLOYEE_IDS] = formValues?.[
      ConflictManagementDetailFields.EMPLOYEE_IDS
    ]
      ? [formValues?.[ConflictManagementDetailFields.EMPLOYEE_IDS]]
      : [];
    params[ConflictManagementDetailFields.CONFIRMATION_DEADLINE] = new Date(
      formValues[ConflictManagementDetailFields.CONFIRMATION_DEADLINE]
    ).toISOString();
    params[ConflictManagementDetailFields.LC_EMPLOYEES] =
      formValues?.[ConflictManagementDetailFields.LC_EMPLOYEES] ? [formValues?.[ConflictManagementDetailFields.LC_EMPLOYEES]] : [];
    params[ConflictManagementDetailFields.LC_REVIEW_DEADLINE] = new Date(
      formValues[ConflictManagementDetailFields.LC_REVIEW_DEADLINE]
    ).toISOString();
    params[ConflictManagementDetailFields.REMIND] =
      (formMode === "create" &&
        !!formValues[ConflictManagementDetailFields.REMIND]?.id) ||
      (formMode === "update" &&
        !!formValues[ConflictManagementDetailFields.REMIND]?.title)
        ? {
            ...castReminderSchemaToSaveReminderDTO(
              formValues[ConflictManagementDetailFields.REMIND]!
            ),
          }
        : {
            title: "",
            description: "",
            module: 2,
            receivedTitle: [],
            receivingDepartment: [],
            remindContents: [],
            relatedUsers: [],
          };
    params[ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG] = formValues?.[
      ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG
    ]
      ? 1
      : 0;
    params[ConflictManagementDetailFields.CHECK_DIVISION_FLAG] = formValues?.[
      ConflictManagementDetailFields.CHECK_DIVISION_FLAG
    ]
      ? 1
      : 0;

    return params;
  };
  
  const handleChangeCode = async(EmployeeCode?: UserProfileDTO | null) => {
    if (!EmployeeCode) return;
    const departmentId = EmployeeCode?.department?.id
    if (departmentId) {
      const deptHead = await getDepartmentHeads(departmentId);
      deptHead?.deptHead?.id && form.setValue(
        ConflictManagementDetailFields.MANAGER_ID,
        deptHead?.deptHead?.id
      );
    }
    setEmployeeInfo(EmployeeCode)
    form.setValue(
      ConflictManagementDetailFields.EMPLOYEE_NAME,
      EmployeeCode.id
    );
    form.setValue(
      ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM,
      EmployeeCode?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
    form.setValue(
      ConflictManagementDetailFields.POSITION_NAME_CUSTOM,
      EmployeeCode?.position?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
  };
  
  const handleChangeEmployee = async(EmployeeName?: UserProfileDTO | null) => {
    if (!EmployeeName) return;
    const departmentId = EmployeeName?.department?.id
    if (departmentId) {
      const deptHead = await getDepartmentHeads(departmentId);
      deptHead?.deptHead?.id && form.setValue(
        ConflictManagementDetailFields.MANAGER_ID,
        deptHead?.deptHead?.id
      );
    }
    setEmployeeInfo(EmployeeName)
    form.setValue(
      ConflictManagementDetailFields.EMPLOYEE_CODE,
      EmployeeName.id
    );
    form.setValue(
      ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM,
      EmployeeName?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
    form.setValue(
      ConflictManagementDetailFields.POSITION_NAME_CUSTOM,
      EmployeeName?.position?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
  };

  const getAssignedPersonQuery = useQuery({
    queryKey: ['coonflict/get-legal-assigned-person'],
    queryFn: () => getAssignedPerson(),
    placeholderData: prev => prev,
    enabled: false
  })

  const disableCheckbox =
    !appContext.meCanWrite || (formMode === "update" && !ownRole?.includes(1));

  return (
    <>
      <Grid
        container
        className="form-wrapper"
        style={{ marginTop: formMode === "update" ? 24 : 0 }}
      >
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              {formMode !== "update" && (
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={ConflictManagementDetailFields.CONFLICT_NAME}
                    label={t(
                      `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_NAME}`
                    )}
                    placeHolder={t(
                      `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_NAME}`
                    )}
                    required
                    minRows={2}
                    disabled={!appContext.meCanWrite}
                  />
                </Grid>
              )}
              {/* {formMode === "update" && (
                <>
                  <Grid item width={"100%"}>
                    <FormSelectButton
                      control={form.control}
                      name={ConflictManagementDetailFields.STATUS_CONFIRM}
                      label={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.STATUS_CONFIRM}`
                      )}
                      placeholder={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.STATUS_CONFIRM}`
                      )}
                      keyQuery={`${ConflictManagementDetailFields.STATUS_CONFIRM}-query-conflict-management-form`}
                      getOptions={async (keyword) => {
                        if (typeof keyword == "string") {
                          const response = await getStatusListNames({
                            names: [...listStatusConfirmConflict, keyword],
                            modules: [
                              Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!,
                            ],
                          });
                          return response?.statusResponses || [];
                        } else {
                          if (keyword?.length && keyword.length > 0) {
                            return getStatus(Number(keyword[0])).then((value) =>
                              value ? [value] : []
                            );
                          }
                        }

                        return [] as StatusDTO[];
                      }}
                      getOptionKey={(option) => option.id.toString()}
                      getOptionLabel={(option) => option.name}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                  <Grid item width={"100%"}>
                    <FormSelectButton
                      control={form.control}
                      name={ConflictManagementDetailFields.STATUS_EVALUATED}
                      label={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.STATUS_EVALUATED}`
                      )}
                      placeholder={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.STATUS_EVALUATED}`
                      )}
                      keyQuery={`${ConflictManagementDetailFields.STATUS_EVALUATED}-query-conflict-management-form`}
                      getOptions={async (keyword) => {
                        if (typeof keyword == "string") {
                          const response = await getStatusListNames({
                            names: [...listStatusEvaluateConflict, keyword],
                            modules: [
                              Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!,
                            ],
                          });
                          return response?.statusResponses || [];
                        } else {
                          if (keyword?.length && keyword.length > 0) {
                            return getStatus(Number(keyword[0])).then((value) =>
                              value ? [value] : []
                            );
                          }
                        }

                        return [] as StatusDTO[];
                      }}
                      getOptionKey={(option) => option.id.toString()}
                      getOptionLabel={(option) => option.name}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                </>
              )} */}
              <Grid item width={"100%"}>
                <Grid
                  container
                  className="form-sub-section-wrapper"
                  position={"relative"}
                  rowGap={GLOBAL_SPACING}
                >
                  <Grid item width={"100%"}>
                    <Typography fontWeight="bold">
                      {t("CONFLICT_MANAGEMENT.label.information")}
                    </Typography>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        name={ConflictManagementDetailFields.EMPLOYEE_CODE}
                        minCharLength={1}
                        label={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.EMPLOYEE_CODE}`
                        )}
                        placeholder={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.EMPLOYEE_CODE}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return (
                              response?.users?.filter(
                                (user) => user?.employeeCode
                              ) ?? []
                            );
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option.employeeCode ?? ""}`
                        }
                        getOptionKey={(option) => option.id}
                        keyQuery={"employeesCode/queryUser"}
                        onChange={(_, option) => handleChangeCode(option)}
                        isFocus
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        minCharLength={1}
                        name={ConflictManagementDetailFields.EMPLOYEE_NAME}
                        label={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.EMPLOYEE_NAME}`
                        )}
                        placeholder={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.EMPLOYEE_NAME}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return response?.users ?? [];
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option.name ?? ""} - ${option.employeeCode ?? ""}`
                        }
                        onChange={(_, option) => handleChangeEmployee(option)}
                        getOptionKey={(option) => option.id}
                        keyQuery={"employeesName/queryUser"}
                        isFocus
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={
                          ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM
                        }
                        label={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM}`
                        )}
                        placeHolder={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={
                          ConflictManagementDetailFields.POSITION_NAME_CUSTOM
                        }
                        label={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.POSITION_NAME_CUSTOM}`
                        )}
                        placeHolder={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.POSITION_NAME_CUSTOM}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={12}>
                    <Grid item width="100%">
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        minCharLength={1}
                        name={ConflictManagementDetailFields.MANAGER_ID}
                        label={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.MANAGER_ID}`
                        )}
                        placeholder={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.MANAGER_ID}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return response?.users ?? [];
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option?.name} - ${
                            option?.position?.name
                              ? `${option?.position?.name}.`
                              : ""
                          }${option?.department?.name ?? ""}`
                        }
                        getOptionKey={(option) => option.id}
                        keyQuery={"managerId/queryUser"}
                        isFocus
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={12} mt="10px">
                      <DropPreviewFileUploadComponent
                        dropView={formMode === "create"}
                        preview={formMode === "update"}
                        name={ConflictManagementDetailFields.FILES}
                        control={form.control}
                        files={files}
                        setFiles={setFiles}
                        title={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.ATTACHMENTS}`
                        )}
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                        required
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <Grid
                  container
                  className="form-sub-section-wrapper"
                  position={"relative"}
                  rowGap={GLOBAL_SPACING}
                >
                  <Grid item width={"100%"}>
                    <Typography fontWeight="bold">
                      {t("CONFLICT_MANAGEMENT.label.conflictInterestEntity")}
                    </Typography>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={
                          ConflictManagementDetailFields.CONFLICT_OBJECT_NAME
                        }
                        label={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_NAME}`
                        )}
                        placeHolder={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_NAME}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={
                          ConflictManagementDetailFields.CONFLICT_OBJECT_AGENCY
                        }
                        label={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_AGENCY}`
                        )}
                        placeHolder={t(
                          `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_AGENCY}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={5.9}>
                    <FormTextField
                      control={form.control}
                      name={
                        ConflictManagementDetailFields.CONFLICT_OBJECT_POSITION
                      }
                      label={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_POSITION}`
                      )}
                      placeHolder={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_POSITION}`
                      )}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                  <Grid container xs={12}>
                    <FormTextArea
                      control={form.control}
                      name={
                        ConflictManagementDetailFields.CONFLICT_OBJECT_RELATION
                      }
                      label={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_RELATION}`
                      )}
                      placeHolder={t(
                        `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_OBJECT_RELATION}`
                      )}
                      required
                      minRows={2}
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                </Grid>
              </Grid>
              <Grid item width="100%">
                <CheckBoxGroupField
                  label={t(
                    `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.NATURE_CONFLICT}`
                  )}
                  errors={
                    form.formState.errors?.[
                      ConflictManagementDetailFields.NATURE_CONFLICT
                    ]
                  }
                  items={[
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.natureConflict.${NatureConflict.get(
                          NatureConflictKey.OWNER_SHIP
                        )!}`
                      ),
                      value: NatureConflict.get(NatureConflictKey.OWNER_SHIP)!,
                    },
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.natureConflict.${NatureConflict.get(
                          NatureConflictKey.PARTICIPATION
                        )!}`
                      ),
                      value: NatureConflict.get(
                        NatureConflictKey.PARTICIPATION
                      )!,
                    },
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.natureConflict.${NatureConflict.get(
                          NatureConflictKey.EXECUTION
                        )!}`
                      ),
                      value: NatureConflict.get(NatureConflictKey.EXECUTION)!,
                    },
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.natureConflict.${NatureConflict.get(
                          NatureConflictKey.PROVIDING_TMV
                        )!}`
                      ),
                      value: NatureConflict.get(
                        NatureConflictKey.PROVIDING_TMV
                      )!,
                    },
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.natureConflict.${NatureConflict.get(
                          NatureConflictKey.PERFORMING_ANOTHER
                        )!}`
                      ),
                      value: NatureConflict.get(
                        NatureConflictKey.PERFORMING_ANOTHER
                      )!,
                    },
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.natureConflict.${NatureConflict.get(
                          NatureConflictKey.ORTHER
                        )!}`
                      ),
                      value: NatureConflict.get(NatureConflictKey.ORTHER)!,
                    },
                  ]}
                  required
                  name={ConflictManagementDetailFields.NATURE_CONFLICT}
                  isDisabled={!appContext.meCanWrite}
                />
                {form
                  .watch(ConflictManagementDetailFields.NATURE_CONFLICT)
                  ?.includes(NatureConflict.get(NatureConflictKey.ORTHER)!) && (
                  <FormTextArea
                    control={form.control}
                    name={ConflictManagementDetailFields.REASON_CONFLICT}
                    placeHolder={t(
                      `CONFLICT_MANAGEMENT.placeholder.${ConflictManagementDetailFields.REASON_CONFLICT}`
                    )}
                    minRows={2}
                    disabled={
                      !appContext.meCanWrite ||
                      (formMode === "update" && !ownRole?.includes(1))
                    }
                  />
                )}
              </Grid>
              <Grid item width="100%">
                <FormTextArea
                  control={form.control}
                  name={ConflictManagementDetailFields.CONFLICT_DETAIL}
                  label={t(
                    `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_DETAIL}`
                  )}
                  placeHolder={t(
                    `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_DETAIL}`
                  )}
                  required
                  minRows={2}
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              <Grid item width="100%">
                <FormTextArea
                  control={form.control}
                  name={ConflictManagementDetailFields.CONFLICT_RESOLUTION}
                  label={t(
                    `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFLICT_RESOLUTION}`
                  )}
                  placeHolder={t(
                    `CONFLICT_MANAGEMENT.placeholder.${ConflictManagementDetailFields.CONFLICT_RESOLUTION}`
                  )}
                  required
                  minRows={2}
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect<any, UserProfileDTO>
                  control={form.control}
                  name={ConflictManagementDetailFields.EMPLOYEE_IDS}
                  label={t(`CONFLICT_MANAGEMENT.fields.approver`)}
                  placeholder={t(`CONFLICT_MANAGEMENT.fields.approver`)}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return response?.users ?? [];
                    } else if (keyword?.length && keyword.length > 0) {
                      return getUser(keyword[0])
                        .then((response) => (response ? [response] : []))
                        .catch(() => []);
                    }

                    return [];
                  }}
                  getOptionLabel={(option) =>
                    `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                      option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryRelatedUser"
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              {getDepartmentHeadQuery?.data && (
                <Stack direction={"row"} width={"100%"} mt={0.5} gap={2}>
                  <Typography
                    sx={{
                      fontSize: "14px",
                      color: COLOR_TYPE.TOYOTA.TOYOTA1,
                      fontStyle: "italic",
                    }}
                  >
                    {t(`legalAdvice.label.requiredToBeSentTo`)}*:
                  </Typography>
                  <Stack gap={"1rem"}>
                    {getDepartmentHeadQuery?.data?.deptHead && (
                      <CheckboxInput
                        fontSize={"1rem"}
                        checked={form.watch(
                          ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG
                        )}
                        borderColor={
                          disableCheckbox
                            ? COLOR_TYPE.TOYOTA.TOYOTA5
                            : COLOR_TYPE.TOYOTA.TOYOTA1
                        }
                        checkboxBg={
                          disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"
                        }
                        onChange={(value) => {
                          form.setValue(
                            ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG,
                            value
                          );
                        }}
                        label={
                          getDepartmentHeadQuery?.data?.deptHead
                            ? `${
                                getDepartmentHeadQuery?.data?.deptHead?.name
                              } - ${
                                getDepartmentHeadQuery?.data?.deptHead
                                  ?.position?.[
                                  i18n.language == LANGUAGES.VIETNAMESE
                                    ? "name"
                                    : "nameEnglish"
                                ]
                              }.${
                                getDepartmentHeadQuery?.data?.deptHead
                                  ?.department?.name
                              }`
                            : t(
                                "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={disableCheckbox}
                      />
                    )}
                    {getDepartmentHeadQuery?.data?.division && (
                      <CheckboxInput
                        fontSize={"1rem"}
                        checked={form.watch(
                          ConflictManagementDetailFields.CHECK_DIVISION_FLAG
                        )}
                        borderColor={
                          disableCheckbox
                            ? COLOR_TYPE.TOYOTA.TOYOTA5
                            : COLOR_TYPE.TOYOTA.TOYOTA1
                        }
                        checkboxBg={
                          disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"
                        }
                        onChange={(value) => {
                          form.setValue(
                            ConflictManagementDetailFields.CHECK_DIVISION_FLAG,
                            value
                          );
                        }}
                        label={
                          getDepartmentHeadQuery?.data?.division
                            ? `${getDepartmentHeadQuery?.data?.division?.name} - Division Head.${getDepartmentHeadQuery?.data?.division?.department?.name}`
                            : t(
                                "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={disableCheckbox}
                      />
                    )}
                    {/* <Grid container direction={"row"} rowGap={"0.5rem"}>
                      {getDepartmentHeadQuery?.data?.deptHead && (
                        <Grid item xs={6}>
                          <FormControlLabel
                            name={
                              ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG
                            }
                            control={
                              <Checkbox
                                checked={checkDeptHeadFlag}
                                onChange={(e) => {
                                  form.setValue(
                                    ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG,
                                    e.target.checked
                                  );
                                }}
                              />
                            }
                            label={
                              getDepartmentHeadQuery?.data?.deptHead
                                ? `${
                                    getDepartmentHeadQuery?.data?.deptHead?.name
                                  } - ${
                                    getDepartmentHeadQuery?.data?.deptHead
                                      ?.position?.[
                                      i18n.language == LANGUAGES.VIETNAMESE
                                        ? "name"
                                        : "nameEnglish"
                                    ]
                                  }.${
                                    getDepartmentHeadQuery?.data?.deptHead
                                      ?.department?.name
                                  }`
                                : t(
                                    "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                                  )
                            }
                            disabled={
                              !appContext.meCanWrite ||
                              (formMode === "update" && !ownRole?.includes(1))
                            }
                          />
                        </Grid>
                      )}
                      {getDepartmentHeadQuery?.data?.division && (
                        <Grid item xs={6}>
                          <FormControlLabel
                            name={
                              ConflictManagementDetailFields.CHECK_DIVISION_FLAG
                            }
                            control={
                              <Checkbox
                                checked={checkDivisionFlag}
                                onChange={(e) => {
                                  form.setValue(
                                    ConflictManagementDetailFields.CHECK_DIVISION_FLAG,
                                    e.target.checked
                                  );
                                }}
                              />
                            }
                            label={
                              getDepartmentHeadQuery?.data?.division
                                ? `${
                                    getDepartmentHeadQuery?.data?.division?.name
                                  } - ${
                                    getDepartmentHeadQuery?.data?.division
                                      ?.position?.[
                                      i18n.language == LANGUAGES.VIETNAMESE
                                        ? "name"
                                        : "nameEnglish"
                                    ]
                                  }.${
                                    getDepartmentHeadQuery?.data?.division
                                      ?.department?.name
                                  }`
                                : t(
                                    "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                                  )
                            }
                            disabled={
                              !appContext.meCanWrite ||
                              (formMode === "update" && !ownRole?.includes(1))
                            }
                          />
                        </Grid>
                      )}
                    </Grid> */}
                  </Stack>
                  {sendToError ? (
                    <FormHelperText error>
                      {t("legalAdvice.messages.requiredToBeSentTo")}
                    </FormHelperText>
                  ) : null}
                </Stack>
              )}
              <Grid item width={"100%"}>
                <DateTimeInput
                  control={form.control}
                  name={ConflictManagementDetailFields.CONFIRMATION_DEADLINE}
                  required
                  label={t(
                    `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.CONFIRMATION_DEADLINE}`
                  )}
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormAsyncSelect<any, UserProfileDTO>
                    control={form.control}
                    name={ConflictManagementDetailFields.LC_EMPLOYEES}
                    label={t(
                      `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.LC_EMPLOYEES}`
                    )}
                    placeholder={t(
                      `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.LC_EMPLOYEES}`
                    )}
                    getOptions={async (keyword) => {
                      if (!getLegalDepartmentQuery.data) return [];
                      const advisorIds =
                        getAssignedPersonQuery?.data?.users?.map(
                          (user) => user.id
                        ) ?? [];
                      if (typeof keyword == "string") {
                        const params: GetUsersParams = {
                          searchTerm: keyword,
                          page: 0,
                          size: 100,
                          sortBy: "name",
                          sortOrder: "ASC",
                          departmentIds: getLegalDepartmentQuery.data
                            ? [getLegalDepartmentQuery.data]
                            : [],
                        };
                        const response = await getUsers(params);

                        return (
                          response?.users
                            ?.map((user, index) => ({
                              ...user,
                              rank: advisorIds?.includes(user?.id)
                                ? index
                                : 99999,
                            }))
                            ?.sort(
                              (first, second) => first?.rank - second?.rank
                            ) ?? []
                        );
                      } else if (keyword?.length && keyword.length > 0) {
                        return getUser(keyword[0])
                          .then((response) => (response ? [response] : []))
                          .catch(() => []);
                      }
                      return [];
                    }}
                    getOptionLabel={(option) =>
                      `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                        option?.department?.name ?? option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    onChange={(_selectedKey, option) => {
                      if (initialValue?.isWarningUpdateLC) {
                        toast.warning(
                          t(
                            "CONFLICT_MANAGEMENT.messages.confirmReviewerChange",
                            { name: option?.name }
                          )
                        );
                      }
                    }}
                    keyQuery={"lcOfficersConflict/queryUser"}
                    isFocus
                    disabled={
                      !appContext.meCanWrite ||
                      (formMode === "update" && !ownRole?.includes(1))
                    }
                  />
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <DateTimeInput
                  control={form.control}
                  name={ConflictManagementDetailFields.LC_REVIEW_DEADLINE}
                  label={t(
                    `CONFLICT_MANAGEMENT.label.${ConflictManagementDetailFields.LC_REVIEW_DEADLINE}`
                  )}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              {formMode === "update" && initialValue?.id && (
                <Grid width={"100%"} container gap={2}>
                  <ConfirmationInformationList
                    ownRole={ownRole}
                    conflictManagementId={initialValue?.id}
                    initialValue={initialValue}
                  />
                  <EvaluateCommentList
                    ownRole={ownRole}
                    conflictManagementId={initialValue?.id}
                    initialValue={initialValue}
                  />
                  <FollowConflictList
                    ownRole={ownRole}
                    conflictManagementId={initialValue?.id}
                    initialValue={initialValue}
                  />
                </Grid>
              )}
            </Grid>
            <ReminderPickerSubForm
              name={"remind"}
              module={Module.get(ModuleKeys.CONFLICT_MANAGEMENT)}
              placeholder={t("menu.reminder")}
            />
            <FormActionButtons
              formMode={formMode}
              loading={loading}
              onCancel={onCancel}
              allowDraft={formMode === "create" || defaultValues?.isDraft}
              onSaveDraft={async () => {
                try {
                  const params = await handleSaveParams();
                  params[ConflictManagementDetailFields.IS_DRAFT] = true;
                  onSubmitDraft?.(params);
                } catch (error) {}
              }}
              onSave={async () => {
                try {
                  const params = await handleSaveParams();
                  params[ConflictManagementDetailFields.IS_DRAFT] = false;
                  onSubmit?.(params);
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </>
  );
};

export default ConflictManagementForm;
