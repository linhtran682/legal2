import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import { FC, useContext, useState } from "react";
import ConflictManagementItem from "./ConflictManagementItem";
import {
  useDeleteFollowMng,
  useGetFollowMng,
} from "@/apis/service/conflict_management/conflictMngFormPopup";
import { ConflictInformation } from "@/models/conflict_management/ConfirmConflict";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import { useQueryClient } from "@tanstack/react-query";
import {
  ConflictManagementRole,
  ConflictManagementRoleKey,
} from "@/constants/general";
import { GET_FOLLOW_MANAGEMENT } from "@/apis/service/conflict_management/conflictManagementForm";
import { FollowConflictForm } from "../conflict _management_dialog/follow_conflict_mng_form";
import { AppContext } from "@/context/AppContext";

interface ConfirmListProps {
  conflictManagementId: number;
  conflictName?: string;
  initialValue?: any;
  ownRole?: number[];
}

const FollowConflictList: FC<ConfirmListProps> = (props) => {
  const { conflictManagementId, ownRole, initialValue } = props;
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedFollow, setSelectedFollow] = useState<
    ConflictInformation | undefined
  >(undefined);
  const [followPopupState, setFollowPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const { data: getFollowListQuery } = useGetFollowMng({
    request: { ciId: conflictManagementId },
    config: {
      enabled: !!conflictManagementId,
    },
  });
  const { mutateAsync: deleteFollowMutationFn } = useDeleteFollowMng({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t("Thông tin theo dõi"),
          })
        );
        setFollowPopupState(DefaultConfirmPopupState);
        queryClient.invalidateQueries({
          queryKey: [GET_FOLLOW_MANAGEMENT],
        });
      },
    },
  });
  const handleEditClick = (conflictItem: ConflictInformation) => {
    setSelectedFollow(conflictItem);
    setPopupVisible(true);
  };

  const handleDeleteClick = (conflictItem: ConflictInformation) => {
    setFollowPopupState({
      open: true,
      icon: <DeleteRecordDialogIcon />,
      title: "Bạn có chắc chắn muốn xóa không ?",
      handleConfirm: async () => {
        await deleteFollowMutationFn({
          ciId: conflictManagementId,
          followId: conflictItem.id,
        });
        setFollowPopupState(DefaultConfirmPopupState);
      },
      handleCancel: () => setFollowPopupState(DefaultConfirmPopupState),
    });
  };
  const onPopupClose = async () => {
    setPopupVisible(false);
    setSelectedFollow(undefined);
  };
  return getFollowListQuery?.responses?.length ? (
    <Grid
      container
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
    >
      <Typography fontWeight="bold">
        {t("CONFLICT_MANAGEMENT.label.informationFollow")}
      </Typography>
      {(getFollowListQuery?.responses ?? [])?.map(
        (conflictItem: ConflictInformation, index: number) => (
          <ConflictManagementItem
            key={conflictItem.id.toString()}
            indexConflictItem={index}
            isActiveAction={
              ownRole?.includes(
                ConflictManagementRole.get(
                  ConflictManagementRoleKey.EMPLOYEE_CONFLICT
                )!
              ) ||
              ownRole?.includes(
                ConflictManagementRole.get(
                  ConflictManagementRoleKey.DEPT_HEAD_EMPLOYEE_CONFLICT
                )!
              ) ||
              ownRole?.includes(
                ConflictManagementRole.get(ConflictManagementRoleKey.LC)!
              )
            }
            label={`CONFLICT_MANAGEMENT.label.requester`}
            onDeleteClick={() => handleDeleteClick(conflictItem)}
            onEditClick={() => handleEditClick(conflictItem)}
            conflictItem={{
              ...conflictItem,
              user: conflictItem?.userResponse,
              attachments: conflictItem?.attachmentResponses,
            }}
          />
        )
      )}
      <ConfirmPopup {...followPopupState} />
      {popupVisible && (
        <>
          <FollowConflictForm
            setIsOpen={onPopupClose}
            isOpen={popupVisible}
            ciId={conflictManagementId}
            followId={selectedFollow?.id}
            name={initialValue?.conflictName}
            senderConflict={appContext?.me}
          />
        </>
      )}
    </Grid>
  ) : null;
};

export default FollowConflictList;
