import { useCreateRequestInformation } from "@/apis/service/conflict_management/conflictMngFormPopup";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import {
  RequestAdditionalFieldNames,
  RequestAdditionalSchema,
  RequestAdditionalSchemaI,
} from "@/models/conflict_management/RequestAdditional";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Grid, Typography } from "@mui/material";
import { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestAdditionalSchemaI;
  conflictId: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  defaultStatus?: string;
}
const initialEmptyValue: RequestAdditionalSchemaI = {
  [RequestAdditionalFieldNames.DEADLINE]: "",
  [RequestAdditionalFieldNames.CONTENT]: "",
  [RequestAdditionalFieldNames.REMIND]: undefined,
};
export const RequestAdditionalForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.requestAdditional.title.titlePopup",
    initialValue = initialEmptyValue,
    conflictId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.CONFLICT_MANAGEMENT),
    senderDocumentManagement,
    defaultStatus = ConflictManagementStatusContent.get(
      ConflictManagementStatusKey.REQUEST_ADDITIONAL
    )!,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(RequestAdditionalSchema),
    defaultValues: initialValue,
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: defaultStatus,
    form,
    modules: ModuleFields.CONFLICT_MANAGEMENT.module,
    queryKey: "CONFLICT_REQUEST_ADDITIONAL",
  });

  const { mutateAsync: createRequestInformationMutationFn, isPending } =
    useCreateRequestInformation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    const { ...restData } = data;
    await createRequestInformationMutationFn({
      ciId: conflictId,
      data: { ...restData, status: +data?.status },
    });
  };

  // useEffect(() => {
  //   if (getDataRequestAdditional) {
  //     form.reset({
  //       ...getDataRequestAdditional,
  //       status: LegalAdviceStatus.get(LegalAdviceStatusKey.REQUEST_ADDITIONAL),
  //       users: [getDataRequestAdditional?.user],
  //       departments: [getDataRequestAdditional?.department?.id],
  //     });
  //   }
  // }, [getDataRequestAdditional]);

  useEffect(() => {
    if (initialValue?.users) {
      form.reset({
        ...initialEmptyValue,
        ...(getSearchStatusQuery?.data && {
          [RequestAdditionalFieldNames.STATUS]:
            getSearchStatusQuery?.data?.find(
              (status) => status?.name === defaultStatus
            )?.id,
        }),
        userIds: initialValue?.users,
      });
    }
  }, [initialValue?.users]);

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: "1rem" }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("CONFLICT_MANAGEMENT.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`CONFLICT_MANAGEMENT.requestAdditional.title.requester`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"} style={{display: 'none'}}>
                <FormAsyncSelect
                  control={form.control}
                  name={RequestAdditionalFieldNames.STATUS}
                  label={t(
                    `CONFLICT_MANAGEMENT.requestAdditional.title.status`
                  )}
                  keyQuery={"status-query-requestAdditional"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.CONFLICT_MANAGEMENT.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestAdditionalFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.requestAdditional.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestAdditionalFieldNames.CONTENT}
                  label={t(
                    `CONFLICT_MANAGEMENT.requestAdditional.title.${RequestAdditionalFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.requestAdditional.placeHolder.${RequestAdditionalFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <Box display={"flex"} flexDirection={"row"} gap={2}>
                    <Box flex={1} width={"50%"}>
                      <div style={{ visibility: "hidden" }}>check</div>
                      <FormMultipleSelect<any, BasedUser>
                        control={form.control}
                        name={RequestAdditionalFieldNames.USERID}
                        label={t(
                          "CONFLICT_MANAGEMENT.requestAdditional.title.personResponsible"
                        )}
                        placeholder={t(
                          "CONFLICT_MANAGEMENT.requestAdditional.title.personResponsible"
                        )}
                        getOptions={async (keyword) => {
                          const params: GetUsersParams = {
                            searchTerm: keyword,
                            page: 0,
                            size: 100,
                            sortBy: "name",
                            sortOrder: "ASC",
                          };
                          const selectedDepartments =
                            form.getValues("departments");
                          if (selectedDepartments?.length) {
                            params.departmentIds = selectedDepartments;
                          }
                          const response = await getUsers(params);

                          return (response?.users ?? []).map((user) => ({
                            id: user.id,
                            name: user.name ?? "",
                            departmentName: user.department?.name,
                            email: user.email,
                          }));
                        }}
                        getOptionLabel={(option) =>
                          `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                            option?.departmentName ?? ""
                          }`
                        }
                        getOptionKey={(option) => option?.id}
                        keyQuery={"requestAdditional/queryUser"}
                        isFocus
                        required
                      />
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={RequestAdditionalFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                    userIds : form.getValues('userIds')?.map((ele: BasedUser) => ele.id) || []
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
