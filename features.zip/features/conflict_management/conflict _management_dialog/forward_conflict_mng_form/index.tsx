import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  castForwardLegalAdviceRequestSchemaToDTO,
  ForwardLegalAdviceFieldNames,
  ForwardLegalAdviceSchema,
  ForwardLegalAdviceSchemaI,
} from "@/models/legal-advice/ForwardLegalAdvice";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { Module, ModuleKeys } from "@/constants/general";
import { ForwardConflictMngFieldNames, ForwardConflictMngSchemaI } from "@/models/conflict_management/ForwardConflict";
import { useCreateForwardConflictMng } from "@/apis/service/conflict_management/conflictMngFormPopup";

const initialEmptyValue: ForwardLegalAdviceSchemaI = {
  [ForwardLegalAdviceFieldNames.USERS_IDS]: [],
  [ForwardLegalAdviceFieldNames.DEADLINE]: "",
  [ForwardLegalAdviceFieldNames.CONTENT]: "",
  [ForwardLegalAdviceFieldNames.REMIND]: undefined,
};

export interface ForwardConflictMngTypeFormProps {
  titlePopup?: string;
  initialValue?: ForwardConflictMngSchemaI;
  ciId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
}

export const ForwardConflictMngForm = (
  props: ForwardConflictMngTypeFormProps
) => {
  const {
    titlePopup = "CONFLICT_MANAGEMENT.forwardConflict.title",
    initialValue = initialEmptyValue,
    ciId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.CONFLICT_MANAGEMENT),
    senderDocumentManagement,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(ForwardLegalAdviceSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createForwardConflictMngMutationFn, isPending } =
    useCreateForwardConflictMng({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload:boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;
    await createForwardConflictMngMutationFn({
      lcsId: ciId,
      data: restData,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("CONFLICT_MANAGEMENT.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {/* {t(`legalAdvice.forwardLegalAdvice.title.sender`)} */}
                  {t('CONFLICT_MANAGEMENT.forwardConflict.transitioner')}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} ({senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={ForwardConflictMngFieldNames.USERS_IDS}
                    label={t("legalAdvice.forwardLegalAdvice.title.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"forwardLegalAdvice/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={ForwardConflictMngFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.forwardLegalAdvice.title.deadline`)}
                  minDate={new Date()}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ForwardConflictMngFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.forwardLegalAdvice.title.${ForwardLegalAdviceFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.forwardLegalAdvice.placeHolder.${ForwardLegalAdviceFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={ForwardConflictMngFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castForwardLegalAdviceRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
