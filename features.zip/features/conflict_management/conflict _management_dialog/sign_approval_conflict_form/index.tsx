import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ConflictManagementStatusContent, ConflictManagementStatusKey, Module, ModuleKeys } from "@/constants/general";
// import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import {
  castConfirmRequestSchemaToDTO,
  ConfirmConflictFieldNames,
  ConfirmConflictSchema,
  ConfirmConflictSchemaI,
} from "@/models/conflict_management/ConfirmConflict";
import {
  useCreateSignApproveConflictConflict,
  useGetRecordSignApproval,
} from "@/apis/service/conflict_management/conflictMngFormPopup";
import { ListRecordUserRequest } from "./ListRecordUserRequest";
import { ApproveConflictFieldNames, AproveConflictOptions } from "@/models/conflict_management/SignApproval";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusListNames } from "@/apis/service/status/Status";
import { StatusDTO } from "@/models/status/Status";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";

const initialEmptyValue: ConfirmConflictSchemaI = {
  [ConfirmConflictFieldNames.USERS_IDS]: [],
  [ConfirmConflictFieldNames.DEADLINE]: "",
  [ConfirmConflictFieldNames.CONTENT]: "",
  [ConfirmConflictFieldNames.REMIND]: undefined,
  [ConfirmConflictFieldNames.STATUS]: 0,
  [ConfirmConflictFieldNames.ACCEPT]: 0,
};

export interface ForwardLegalAdviceTypeFormProps {
  titlePopup?: string;
  initialValue?: ConfirmConflictSchemaI;
  ciId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  defaultStatus?: string;
}

export const SignApprovalConflictMngForm = (
  props: ForwardLegalAdviceTypeFormProps
) => {
  const {
    titlePopup = "CONFLICT_MANAGEMENT.signApproval.title",
    initialValue = initialEmptyValue,
    ciId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.CONFLICT_MANAGEMENT),
    senderDocumentManagement,
    defaultStatus=ConflictManagementStatusContent.get(
      ConflictManagementStatusKey.APPROVAL_REQUEST_FOLLOW
    )!,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(ConfirmConflictSchema),
    defaultValues: initialValue,
  });

  const {
    data: getSignApprovalQueryFn,
    isLoading: isLoadingRecordRequestList,
  } = useGetRecordSignApproval({
    request: { ciId },
    config: {
      enabled: !!ciId,
    },
  });
  const { mutateAsync: createSignApproveConflictMutationFn, isPending } =
    useCreateSignApproveConflictConflict({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });
    const getSearchStatusQuery = useSearchStatus({
      keyword: !ciId ? defaultStatus : undefined,
      modules: Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!,
      queryKey: "APPROVE_CONFLICT_MNG",
    });
  useEffect(()=> {
    form.reset({
      ...initialValue,
      ...(getSearchStatusQuery?.data && {
        [ConfirmConflictFieldNames.STATUS]: getSearchStatusQuery?.data?.find(
          (status: any) => status?.name === defaultStatus
        )?.id,
      }),
    });
  }, [getSearchStatusQuery?.data])
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };
  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;
    await createSignApproveConflictMutationFn({
      ciId,
      data: restData,
    });
  };

  const handleChangeRadioType = (
    _event: React.ChangeEvent<HTMLInputElement>,
    value: string | number | boolean
  ) => {
    if(value === 0){
      form.setValue('status',  getSearchStatusQuery?.data?.find(
        (status) => status?.name === defaultStatus
      )?.id)
    }else{
      form.setValue('status', getSearchStatusQuery?.data?.find(
        (status) => status?.name ===  ConflictManagementStatusContent.get(
          ConflictManagementStatusKey.APPROVAL_REJECTED
        )!
      )?.id)
    }
  };
  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("CONFLICT_MANAGEMENT.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {/* {t(`legalAdvice.forwardLegalAdvice.title.sender`)} */}
                  {t("CONFLICT_MANAGEMENT.signApproval.signer")}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <ListRecordUserRequest
                  data={
                    getSignApprovalQueryFn && getSignApprovalQueryFn?.length > 0
                      ? getSignApprovalQueryFn
                      : []
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <RadioGroupField
                  isNumber
                  items={AproveConflictOptions}
                  name={ConfirmConflictFieldNames.ACCEPT}
                  error={
                    form.formState.errors[
                      ConfirmConflictFieldNames.ACCEPT
                    ] as FieldError
                  }
                  onChangeRadioGroup={handleChangeRadioType}
                  defaultValue={AproveConflictOptions?.[0]?.value as number}
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={ApproveConflictFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`CONFLICT_MANAGEMENT.signApproval.deadline`)}
                  minDate={new Date()}
                  required
                />
              </Grid>
              <Grid item width={"100%"} style={{display:"none"}}>
              <FormAsyncSelect
                  control={form.control}
                  name={ApproveConflictFieldNames.STATUS}
                  label={t(`approvalNextActionForm.title.status`)}
                  keyQuery={"status-query-APPROVE-conflict"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusListNames({
                        names: [
                          ConflictManagementStatusContent.get(
                            ConflictManagementStatusKey.APPROVAL_REQUEST_FOLLOW
                          )!,
                          ConflictManagementStatusContent.get(
                            ConflictManagementStatusKey.APPROVAL_REJECTED
                          )!,
                          keyword,
                        ],
                        modules: [Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!],
                      });
                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option?.name}
                  required
                />
                {/* <FormSelect
                  control={form.control}
                  name={ApproveConflictFieldNames.STATUS}
                  options={[
                    {
                      label: t(`CONFLICT_MANAGEMENT.signApproval.signed`),
                      value: 0,
                    },
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.signApproval.signedRequested`
                      ),
                      value: 1,
                    },
                  ]}
                  label={t(`approvalNextActionForm.title.status`)}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  isClearIcon
                  required
                  disabled={true}
                /> */}
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ApproveConflictFieldNames.CONTENT}
                  label={t(`CONFLICT_MANAGEMENT.signApproval.content`)}
                  placeHolder={t(`CONFLICT_MANAGEMENT.signApproval.content`)}
                  minRows={5}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ApproveConflictFieldNames.USERS_IDS}
                  label={t("legalAdvice.forwardLegalAdvice.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {  
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"forwardLegalAdvice/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ApproveConflictFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isLoadingRecordRequestList}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castConfirmRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
