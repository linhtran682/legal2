import { GLOBAL_SPACING } from "@/constants/format";
import { ResponsesRecordSignApprovalDTO } from "@/models/conflict_management/SignApproval";
import { Grid, TextField, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";

type TypePropsListAdvisorLegal = {
  data?: ResponsesRecordSignApprovalDTO[];
};

export const ListRecordUserRequest = (props: TypePropsListAdvisorLegal) => {
  const { data } = props;
  const { t } = useTranslation();
  return (
    <>
      {data?.map((item) => {
        return (
          <Grid
            container
            className="form-sub-section-wrapper"
            position={"relative"}
            rowGap={GLOBAL_SPACING}
            key={item?.user?.id}
          >
            <Grid item width={"100%"}>
              <label style={{ padding: 0 }}>
                {t("CONFLICT_MANAGEMENT.signApproval.requester")}
              </label>
              <Typography>{`${item?.user?.name} (${item?.user?.email}) - ${item?.user?.department?.name}`}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <label style={{ padding: 0 }}>
                {t(`CONFLICT_MANAGEMENT.confirm_conflict.content`)}
              </label>
              <TextField
                value={item?.content}
                label={""}
                placeholder={t(`CONFLICT_MANAGEMENT.confirm_conflict.content`)}
                minRows={2}
                size="small"
                InputLabelProps={{
                  shrink: true,
                }}
                multiline
                fullWidth
                disabled
              />
            </Grid>
          </Grid>
        );
      })}
    </>
  );
};
