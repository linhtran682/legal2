import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, {  useRef } from "react";
import {  FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import {
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import {
  RequestApprovalRequestFieldNames,
} from "@/models/law_document/RequestApproval";

import { GetUsersParams, UserProfileDTO } from "@/models/user/User";
import { getUser, getUsers } from "@/apis/service/user/User";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import {
  castRequestApprovalConflictSchemaToDTO,
  ConfirmRequestApprovalSchema,
  RequestApprovalConflictFieldNames,
  RequestApprovalConflictSchemaI,
} from "@/models/conflict_management/RequestApproval";
import { useCreateRequestApprovalConflict } from "@/apis/service/conflict_management/conflictMngFormPopup";

const initialEmptyValue: RequestApprovalConflictSchemaI = {
  [RequestApprovalConflictFieldNames.DEADLINE]: "",
  [RequestApprovalConflictFieldNames.REMIND]: undefined,
};

export interface RequestApprovalTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestApprovalConflictSchemaI;
  ciId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  isDisabledStatus?: boolean;
  defaultStatus?: string;
  requestApprovalId?: number;
  senderDocumentManagement?: any;
}

export const RequestApprovalConflictForm = (
  props: RequestApprovalTypeFormProps
) => {
  const {
    titlePopup = "requestApproval.title.titlePopup",
    initialValue = initialEmptyValue,
    ciId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.CONFLICT_MANAGEMENT),
    isDisabledStatus = false,
    defaultStatus = ConflictManagementStatusContent.get(
      ConflictManagementStatusKey.REQUEST_APPROVAL
    )!,
    senderDocumentManagement
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(ConfirmRequestApprovalSchema),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    queryKey: "CONFLICT_REQUEST_APPROVAL",
  });

  const { mutateAsync: createRequestApproveConflictMutationFn, isPending } =
    useCreateRequestApprovalConflict({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };
  const onSubmit = async (data: any) => {
    await createRequestApproveConflictMutationFn({
      ciId,
      data: { ...data, status: +data?.status },
    });
  };

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("CONFLICT_MANAGEMENT.requestConfirm.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`CONFLICT_MANAGEMENT.requestConfirm.requester`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
             
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestApprovalConflictFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`requestApproval.title.newDeadline`)}
                  placeholder="dd/mm/yyyy"
                  required
                />
              </Grid>
              <Grid item width={"100%"} style={{display: 'none'}}>
                <FormAsyncSelect
                  control={form.control}
                  name={RequestApprovalConflictFieldNames.STATUS}
                  label={t(`requestApproval.title.status`)}
                  keyQuery={"status-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.CONFLICT_MANAGEMENT.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled={isDisabledStatus}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestApprovalConflictFieldNames.CONTENT}
                  label={t(`requestApproval.title.content`)}
                  placeHolder={t(`requestApproval.placeHolder.content`)}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormAsyncSelect<any, UserProfileDTO>
                    control={form.control}
                    name={RequestApprovalConflictFieldNames.USERS_IDS}
                    label={t(
                      "CONFLICT_MANAGEMENT.requestConfirm.responsiblePerson"
                    )}
                    minCharLength={1}
                    placeholder={t("assignment.column.user")}
                    getOptions={async (keyword) => {
                      if (typeof keyword == "string") {
                        const params: GetUsersParams = {
                          searchTerm: keyword,
                          page: 0,
                          size: 100,
                          sortBy: "name",
                          sortOrder: "ASC",
                        };
                        const response = await getUsers(params);

                        return response?.users ?? [];
                      } else if (keyword?.length && keyword.length > 0) {
                        return getUser(keyword[0])
                          .then((response) => (response ? [response] : []))
                          .catch(() => []);
                      }

                      return [];
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.department?.name ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"requestApproval/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={RequestApprovalRequestFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castRequestApprovalConflictSchemaToDTO({
                      ...form.getValues(),
                      remind: form.getValues().remind
                        ? castReminderSchemaToSaveReminderDTO(
                            form.getValues().remind
                          )
                        : undefined,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
