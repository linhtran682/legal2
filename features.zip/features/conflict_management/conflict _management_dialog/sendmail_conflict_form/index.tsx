import { sendMailConflict } from "@/apis/service/conflict_management/conflictMngFormPopup";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { EditorField } from "@/components/commons/EditorField/EditorField";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { LegalAdviceBodyReceive } from "@/models/legal-advice/LegalAdviceDetail";
import { SendMailRequestSchema } from "@/models/legal-advice/SendMail";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { FC, useContext } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export interface SendMailFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  conflictId ?: number;
  legalAdvice?: LegalAdviceBodyReceive;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  senderDocumentManagement?: any
}

const SendMailConflictForm: FC<SendMailFormProps> = (props) => {
  const {
    titlePopup = "legalAdvice.sendMail.title.titlePopup",
    isOpen = false,
    setIsOpen,
    conflictId,
    senderDocumentManagement
  } = props;
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm({
    resolver: yupResolver(SendMailRequestSchema),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const sendMailQuery = useMutation({
    mutationFn: sendMailConflict,
    onSuccess: () => {
      toast.success(t("legalAdvice.messages.sendMailSuccess"));
      onCloseForm(true);
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };
  
  const onSave = () => {
    conflictId  &&
      sendMailQuery.mutate({
        id: conflictId ,
        request: {
          ...form.getValues(),
          receivers: form
            .getValues("receivers")
            ?.map((user: BasedUser) => user.id),
        },
      });
  };
  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm(false)}
    >
      <Grid container className="form-wrapper">
        <FormProvider {...form}>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <Typography fontWeight="bold">
                  {t("CONFLICT_MANAGEMENT.requestAdditional.title.textName")}
                  </Typography>
                  <Typography>{props.name}</Typography>
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name="subject"
                  label={t("visitation.label.subject")}
                  placeHolder={t("visitation.label.subject")}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <EditorField
                  control={form.control}
                  name="content"
                  label={t("legalAdvice.sendMail.title.content")}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={"receivers"}
                    label={t("legalAdvice.label.receiver")}
                    placeholder={t("legalAdvice.label.receiver")}
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return response?.users ?? [];
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.department?.name ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery="queryUser"
                    minCharLength={1}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={sendMailQuery.isPending}
            onCancel={() => onCloseForm()}
            cancelConfirm={form.formState.isDirty}
            onSave={onSave}
          />
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};

export default SendMailConflictForm;
