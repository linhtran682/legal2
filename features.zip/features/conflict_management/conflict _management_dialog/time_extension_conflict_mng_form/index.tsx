import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { castFeedbackLegalDocumentRequestSchemaToDTO } from "@/models/law_document/FeedbackLegalDocument";
import { Module, ModuleKeys } from "@/constants/general";
import {
  useCreateTimeExtension,
  useGetTimeExtension,
  useUpdateTimeExtension,
} from "@/apis/service/conflict_management/conflictMngFormPopup";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { ConfirmExtensionRequestSchema, ExtensionOptions, TimeExtensionRequestFieldNames, TimeExtensionRequestSchema, TimeExtensionRequestSchemaI } from "@/models/conflict_management/TimeExtensionConflict";

const initialEmptyValue: TimeExtensionRequestSchemaI = {
  [TimeExtensionRequestFieldNames.DEADLINE]: "",
  [TimeExtensionRequestFieldNames.REASON]: "",
  [TimeExtensionRequestFieldNames.USERS]: [],
  [TimeExtensionRequestFieldNames.REMIND]: undefined,
  [TimeExtensionRequestFieldNames.TINMEEXTENTIONTYPE]: 1,
};

export interface TimeExtensionTypeFormProps {
  titlePopup?: string;
  initialValue?: TimeExtensionRequestSchemaI;
  ciId?: number;
  timeExtensionRequestId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  isConfirmExtension?: boolean;
  name?: string;
  handleSubmit?: any;
  module?: number;
  senderDocumentManagement?: any;
  deadlineEvaluate?: string;

}

export const TimeExtensionConflictMngForm = (
  props: TimeExtensionTypeFormProps
) => {
  const {
    titlePopup,
    initialValue = initialEmptyValue,
    ciId,
    timeExtensionRequestId,
    isOpen = false,
    setIsOpen,
    isConfirmExtension = false,
    name,
    handleSubmit,
    module = Module.get(ModuleKeys.CONFLICT_MANAGEMENT),
    senderDocumentManagement,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const { data: getDataTimeExtension, isLoading } = useGetTimeExtension({
    request: { ciId, timeExtensionRequestId },
    config: {
      enabled: !!ciId && !!timeExtensionRequestId && isConfirmExtension,
    },
  });
  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmExtension
        ? TimeExtensionRequestSchema.concat(ConfirmExtensionRequestSchema)
        : TimeExtensionRequestSchema
    ),
    defaultValues: initialValue,
  });
  const { mutateAsync: createTimeExtension, isPending } =
    useCreateTimeExtension({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(
                titlePopup ??
                  `legalAdvice.timeExtension.title.${
                    isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                  }`
              ),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const {
    mutateAsync: updateTimeExtension,
    isPending: isLoadingUpdateTimeExtension,
  } = useUpdateTimeExtension({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(
              titlePopup ??
                `legalAdvice.timeExtension.title.${
                  isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                }`
            ),
          })
        );
        onCloseForm();
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };
  const onSubmit = async (data: any) => {
    if (isConfirmExtension) {
      await updateTimeExtension({
        ciId,
        timeExtensionRequestId,
        data: {
          remind: data?.remind,
          users: data?.users,
          type: data?.confirm,
          ...(!data?.confirm && {
            deadlineAccept: data?.acceptableDeadline,
            reason: data?.acceptableReason,
          }),
        },
      });
      handleSubmit && handleSubmit();
      return;
    }
    await createTimeExtension({
      ciId,
      data,
    });
  };
  useEffect(() => {
    form.setValue('LCdeadline',props.deadlineEvaluate )
    if (getDataTimeExtension) {
      const { user, ...restGetDataTimeExtension } = getDataTimeExtension;

      form.reset({
        ...restGetDataTimeExtension,
        [TimeExtensionRequestFieldNames.CONFIRM]: 1,
        users: [user],
        LCdeadline: props.deadlineEvaluate
      });
    }
  }, [getDataTimeExtension]);

  if (isLoading) return;
  
  return (
    <ModalCommon
      title={t(
        titlePopup ??
          `legalAdvice.timeExtension.title.${
            isConfirmExtension ? "titlePopup" : "titlePopupRequest"
          }`
      )}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("CONFLICT_MANAGEMENT.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`CONFLICT_MANAGEMENT.timeExtension.title.requester`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              {isConfirmExtension && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={ExtensionOptions}
                    name={TimeExtensionRequestFieldNames.CONFIRM}
                    error={
                      form.formState.errors[
                        TimeExtensionRequestFieldNames.CONFIRM
                      ] as FieldError
                    }
                  />
                </Grid>
              )}
               <Grid item width={"100%"}>
                <DateInput
                  name={TimeExtensionRequestFieldNames.LC_DEADLINE}
                  control={form.control}
                  label={t(
                    `CONFLICT_MANAGEMENT.requestEvaluate.lcReviewDeadline`
                  )}
                  placeholder="dd/mm/yyyy"
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={TimeExtensionRequestFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.timeExtension.title.newDeadline`)}
                  placeholder={t(
                    `legalAdvice.timeExtension.placeHolder.newDeadline`
                  )}
                  minDate={new Date()}
                  required
                  disabled={isConfirmExtension}
                />
              </Grid>
              <Grid item width={"100%"} style={{display: 'none'}}>
                <FormSelect
                  control={form.control}
                  name={TimeExtensionRequestFieldNames.TINMEEXTENTIONTYPE}
                  options={[
                    {
                      label: t(`CONFLICT_MANAGEMENT.timeExtension.optionExtentionType.confirmationPeriod`),
                      value: 1,
                    },
                    {
                      label: t(
                        `CONFLICT_MANAGEMENT.timeExtension.optionExtentionType.evaluationPeriod`
                      ),
                      value: 2,
                    }
                  ]}
                  label={t(`approvalNextActionForm.title.status`)}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  isClearIcon
                  required
                  disabled ={true}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={TimeExtensionRequestFieldNames.REASON}
                  label={t(`legalAdvice.timeExtension.title.reason`)}
                  placeHolder={t(
                    `legalAdvice.timeExtension.placeHolder.reason`
                  )}
                  minRows={5}
                  required
                  disabled={isConfirmExtension}
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={TimeExtensionRequestFieldNames.USERS}
                    label={t("assignment.column.assignedPerson")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"timeExtensionLegalAdvice/queryUser"}
                    isFocus
                    disabled={!isConfirmExtension}
                  />
                </Grid>
              </Grid>
              {isConfirmExtension && (
                <>
                  <Grid item width={"100%"}>
                    <DateInput
                      name={TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE}
                      control={form.control}
                      label={t(
                        `legalAdvice.timeExtension.title.newDeadlineAccept`
                      )}
                      placeholder={t(
                        `legalAdvice.timeExtension.placeHolder.newDeadlineAccept`
                      )}
                      required
                      disabled={form?.watch(
                        TimeExtensionRequestFieldNames.CONFIRM
                      )}
                    />
                  </Grid>
                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={
                        TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON
                      }
                      label={t(`legalAdvice.timeExtension.title.reason`)}
                      placeHolder={t(
                        `legalAdvice.timeExtension.placeHolder.reason`
                      )}
                      minRows={5}
                      required
                      disabled={form?.watch(
                        TimeExtensionRequestFieldNames.CONFIRM
                      )}
                    />
                  </Grid>
                </>
              )}
            </Grid>
            <ReminderPickerSubForm
              name={TimeExtensionRequestFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave={`common.button.${
                isConfirmExtension ? "confirm" : "send"
              }`}
              loading={isPending || isLoadingUpdateTimeExtension || isLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...castFeedbackLegalDocumentRequestSchemaToDTO({
                      ...form.getValues(),
                    }),
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
