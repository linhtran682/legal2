import { getViolationStatisticChartFn } from '@/apis/service/follow_violation/followViolationAPI'
import { PieChartCommon } from '@/components/commons/chart/PieChartCommon'
import { Button, Stack } from '@mui/material'
import { useQuery } from '@tanstack/react-query'
import { useRouter } from 'next/router'
import React, { useMemo } from 'react'
import { useTranslation } from 'react-i18next'

const ViolationTrackingOverview = () => {
  const router = useRouter();
  const { t } = useTranslation();

  const getStatisticChartQuery = useQuery({
    queryKey: ['violation/statistic/chart'],
    queryFn: getViolationStatisticChartFn
  });

  const pieChartData = useMemo(() => {
    const data = getStatisticChartQuery?.data?.pieChart?.data ?? [];
    const total = data?.reduce((sum, item) => sum + item.value, 0);
    // Convert values to percentages
    const dataWithPercentages = data.map(item => ({
      ...item,
      fill: item.name === 'Hoàn thành'
        ? '#3B00ED'
        : (item.name === 'Chưa hoàn thành'
          ? '#D81B60'
          : '#FF9800'),
      value: total > 0 ? Number(((item.value / total) * 100).toFixed(2)) : 0 // Rounded to 2 decimal places
    }));
    return dataWithPercentages
  }, [getStatisticChartQuery?.data?.pieChart])

  return (
    <Stack height={"100%"} >
      <Stack bgcolor={"white"} flexShrink={1} overflow={'auto'} p={3} direction={'column'} alignItems={"center"}>
        <PieChartCommon
          width={450}
          height={280}
          data={pieChartData}
        />
      </Stack>
      <Stack direction={'row'} gap={2} mt={2}>
        <Button
          onClick={() => router.push('/statistics-violation-tracking/report')}
          variant='contained' className='confirm' >
            {t('menu.statisticViolationTrackingReport')}
          </Button>
        <Button
          onClick={() => router.push('/statistics-violation-tracking/report-next-action')}
          variant='contained' className='confirm' >
          {t('menu.statisticViolationNextActionLateReport')}
        </Button>
        <Button
          onClick={() => router.push('/statistics-violation-tracking/report-done')}
          variant='contained' className='confirm' >
          {t('menu.statisticViolationTrackingReportDone')}
        </Button>
        <Button
          onClick={() => router.push('/statistics-violation-tracking/report-following')}
          variant='contained' className='confirm' >
          {t('menu.statisticViolationTrackingReportFollowing')}
        </Button>
      </Stack>

    </Stack >
  )
}

export default ViolationTrackingOverview