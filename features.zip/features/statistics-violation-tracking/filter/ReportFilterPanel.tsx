import { getViolationStatusList } from '@/apis/service/follow_violation/followViolationAPI';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import ReportTypeSelect from '@/components/commons/report_type_select/ReportTypeSelect';
import { ModuleFields } from '@/constants/general';
import { formInputSxProps } from '@/constants/theme';
import { StatusFieldNames } from '@/models/status/Status';
import { toIsoEndOfDay, toIsoStartOfDay } from '@/utils';
import { Box, Button, Grid, Stack } from '@mui/material';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

interface ReportFilterPanelProps {
  onSearch?: (data: any) => void;
  onExport?: (data: any) => void;
  loading?: boolean;
  noStatus?: boolean;
}
const ViolationReportFilterPanel = (props: ReportFilterPanelProps) => {
  const { onExport, onSearch, loading, noStatus } = props;
  const form = useForm();
  const { t } = useTranslation();

  const getParams = () => {
    const data = form.getValues();
    const params = {
      startDate: toIsoStartOfDay(data?.from as Date),
      endDate: toIsoEndOfDay(data?.to as Date),
      departments: data?.departments,
      status: data?.status?.map((ele: any) => ele?.id)
    }
    return params;
  }

  const handleSearch = () => {
    const params = getParams();
    onSearch?.(params);
  }
  const handleExport = () => {
    const params = getParams();
    onExport?.(params);
  }

  return (
    <FormProvider {...form}>
      <Box
        sx={{
          backgroundColor: "white",
          p: 1,
          ...formInputSxProps
        }}
      >
        <Grid
          container
          spacing={1}
        >
          <ReportTypeSelect />


          {noStatus ? null : <Grid item xs={12} md={6}>
            <FormMultipleSelect
              control={form.control}
              name={'status'}
              label={t(`followViolation.label.status`)}
              placeholder={t(`followViolation.label.status`)}
              keyQuery={"follow-violation-report-status-query"}
              getOptions={async () => {
                const response = await getViolationStatusList({
                        modules: [ModuleFields.VIOLATE_NAME.module],
                        page: 0,
                        size: 100,
                        tab: 0,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });
                return response?.statusResponses || [];
              }}
              showAllSelected={false}
              getOptionKey={(option) => option.id.toString()}
              getOptionLabel={(option) => option?.name}
              isFocus
            />
          </Grid>}
        </Grid>
      </Box>
      <Stack
        sx={{
          backgroundColor: "white",
        }}
        p={1.5} direction={'row'} mt={1.5} gap={1.5} width={'100%'} justifyContent={'flex-end'}>
        <Button
          variant='contained'
          className='confirm'
          disabled={loading}
          sx={{ minWidth: 128 }}
          onClick={form.handleSubmit(handleSearch)}>
          {t('report.search')}</Button>
        {onExport ? <Button
          variant='contained'
          className='confirm'
          disabled={loading}
          sx={{ minWidth: 128 }}
          onClick={form.handleSubmit(handleExport)}>Export</Button> : null}

      </Stack>
    </FormProvider>
  )
}

export default ViolationReportFilterPanel