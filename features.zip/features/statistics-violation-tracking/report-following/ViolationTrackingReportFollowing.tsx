
import { getViolationStatisticTableFn } from '@/apis/service/follow_violation/followViolationAPI';
import HierarchyToolTip from '@/components/commons/hierarchy-tooltip/HierarchyTooltip';
import { MultipleFilterTableColumn } from '@/components/commons/tables/multiple_filter_table/MultipleFilterTable';
import StandardTable, { DEFAULT_PAGE_MODAL, StandardTableState } from '@/components/commons/tables/standard_table/StandardTable';
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH, UI_PATH } from '@/constants/paths';
import { FollowViolationFields } from '@/models/follow_violation/FollowViolationType';
import { violationSearchPanelConfig } from '@/models/follow_violation/FormType';
import { formatDate } from '@/utils';
import { Button, Stack, Tooltip } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import ViolationReportFilterPanel from '../filter/ReportFilterPanel';
import { FollowViolationListParams } from '@/models/follow_violation/apiType';

interface IReportFilters {
  startDate?: string;
  endDate?: string;
  department?: string;
  status?: number[];
}

const ViolationTrackingReportFollowing = () => {
  const { t } = useTranslation();
  const router = useRouter();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [reportFilters, setReportFilters] = useState<IReportFilters>({});

  const violationTableColumns: MultipleFilterTableColumn[] = useMemo(() => [
    {
      key: FollowViolationFields.ID,
      label: FollowViolationFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: "center",
    },
    {
      key: FollowViolationFields.REQUEST_NAME,
      label: FollowViolationFields.REQUEST_NAME,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: false,
      filterRank: 2,
      minWidth: 240,
      renderCell: (params) => (
        <HierarchyToolTip
          {...violationSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.name}
          openNewTab
        >
          <span>{params.value}</span>
        </HierarchyToolTip>
      ),
    },
    {
      key: FollowViolationFields.FIELD,
      label: FollowViolationFields.FIELD,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      filterRank: 1,
      minWidth: 180,
      renderCell: (params) => <span>{params.value?.name}</span>,
    },
    {
      key: FollowViolationFields.PURPOSE,
      label: FollowViolationFields.PURPOSE,
      type: undefined,
      quickFilter: false,
      // filterable: true,
      sortable: true,
      minWidth: 200,
      // hideable: true,
    },
    {
      key: FollowViolationFields.STATUS,
      label: "statusViolation",
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        const status = params?.row?.isDraft ? t("common.label.draft") : params.value?.name
        return <Button
          variant="outlined"
          style={{
            background: status === "Hoàn thành" ? "#E7F4EE" : "#D781001A",
            borderRadius: "100px",
            color: status === "Hoàn thành" ? "#0D894F" : "#D78100",
            border: "none",
            padding: "4px 12px",
          }}
        >
          {status}
        </Button>
      },
    },
    {
      key: FollowViolationFields.DEADLINE_TYPE,
      label: FollowViolationFields.DEADLINE,
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 150,
      renderCell: (params) =>
        params.value === 1 ? t("followViolation.label.SOP") : "Urgent",
    },
    {
      key: FollowViolationFields.RESPONSE_DATE,
      label: FollowViolationFields.RETURN_DATE_ALL,
      filterLabel: "followViolation.label.responseDeadline",
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 250,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy HH:mm"),
    },
    {
      key: FollowViolationFields.SENDER,
      label: FollowViolationFields.SENDER,
      filterLabel: "followViolation.label.creator",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 250,
      renderCell: (params) => (
        <Tooltip
          placement="bottom-start"
          title={
            params.row?.createBy
              ? `${params.row?.createBy?.name} - ${params.row?.createBy?.department?.name}`
              : ""
          }
        >
          <span>
            {params.row?.createBy
              ? `${params.row?.createBy?.name} - ${params.row?.createBy?.department?.name}`
              : ""}
          </span>
        </Tooltip>
      ),
    },
    {
      key: FollowViolationFields.RECEIVER,
      label: FollowViolationFields.RECEIVER,
      type: "string",
      quickFilter: false,
      // filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => (
        <Tooltip
          placement="bottom-start"
          title={
            <>
              {params.row?.receiverUsers?.map((user: any) => (
                <p key={user?.id}>
                  {user.name} - {user?.department?.name}
                </p>
              ))}
            </>
          }
        >
          {params.row?.receiverUsers
            ?.map((user: any) => `${user.name} - ${user?.department?.name}`)
            .join(", ")}
        </Tooltip>
      ),
    },
  ], [t]);

  const getTableQuery = useQuery({
    queryKey: ['violation/statistics/table'],
    queryFn: async () =>
      await getViolationStatisticTableFn(castTableStateToParams(tableState, reportFilters)),
    enabled: false,
  });

  useEffect(() => {
    tableState && getTableQuery.refetch();
  }, [tableState, reportFilters])

  const onSearchClick = (data: any) => {
    setReportFilters({
      ...data
    })
  }

  return (
    <Stack direction={'column'} height={'100%'}>
      <ViolationReportFilterPanel onSearch={onSearchClick} noStatus />
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.data ?? []}
          columns={violationTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabel(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          onRowClick={(params) =>
            router.push(
              `/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            )
          }
          hideRowCheckbox
        />
      </div>
    </Stack>
  )
}

export default ViolationTrackingReportFollowing;


const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: IReportFilters
): FollowViolationListParams => {
  const params: FollowViolationListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: FollowViolationFields.ID,
    orderBy: "DESC",
  };
  if (filters?.status?.length) {
    params.status = filters.status?.join(',');
  }
  if (filters?.department) {
    params.department = filters.department;
  }
  if (filters?.startDate) {
    params.from = filters?.startDate;
  }
  if (filters?.endDate) {
    params.to = filters?.endDate;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  params.tab = 3;
  return params;
};

const getFieldLabel = (key: string) => {
  return `followViolation.fields.${key}`;
};