import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { GridRenderCellParams } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import { useRouter } from "next/navigation";
import { FIELD_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useTranslation } from "react-i18next";
import DeleteIcon from "@mui/icons-material/Delete";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { FieldTableConst } from "../FieldTable";
import { deleteFields } from "@/apis/service/field/Field";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";

export const FieldTableAtions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  const queryClient = useQueryClient();

  const deleteFieldsQuery = useMutation({
    mutationFn: deleteFields,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.field"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [FieldTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_field",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(`/${FIELD_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`),
          tooltipTitle: t("common.button.update"),
        },
        {
          key: "delete_field",
          icon: <DeleteIcon color='primary' />,
          onClick: (params) =>
            params.id && deleteFieldsQuery.mutate([Number(params.id)]),
          tooltipTitle: t("common.button.delete"),
          confirmPopupProps: {
            icon: <DeleteRecordDialogIcon />,
            title: t("common.message.confirm_delete"),
          },
        },
      ]}
    />
  );
};
