import MultipleFilterTable, {
  MultipleFilterTableColumn,
} from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import { FieldFieldNames, GetFieldsParams } from "@/models/field/Field";
import { FieldTableAtions } from "./field_table_actions/FieldTableActions";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { GridFilterItem } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { deleteFields, getFields } from "@/apis/service/field/Field";
import { useRouter } from "next/navigation";
import { FIELD_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useTranslation } from "react-i18next";
import { TableGroupedActionButtons } from "@/components/commons/action_button/TableGroupedActionButtons";

export const FieldTableConst = {
  TABLE_NAME: "FieldTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getFields",
};

const fieldTableColumns: MultipleFilterTableColumn[] = [
  {
    key: FieldFieldNames.ID,
    label: FieldFieldNames.ID,
    type: "number",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
  },
  {
    key: FieldFieldNames.NAME,
    label: FieldFieldNames.NAME,
    type: "string",
    quickFilter: true,
    filterable: true,
    sortable: true,
    hideable: false,
    flex: 1,
  },
  {
    key: FieldFieldNames.CREATED_BY,
    label: FieldFieldNames.CREATED_BY,
    type: "string",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
    flex: 1,
  },
  {
    key: FieldFieldNames.CREATED_AT,
    label: FieldFieldNames.CREATED_AT,
    type: "date",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
    flex: 1,
  },
  {
    key: "action",
    label: "",
    type: undefined,
    renderCell: FieldTableAtions,
    quickFilter: false,
    filterable: false,
    sortable: false,
    hideable: false,
    cellClassName: "stickyRight",
  },
];

const castTableStateToParams = (
  tableState: StandardTableState
): GetFieldsParams => {
  const params: GetFieldsParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: FieldFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == FieldFieldNames.NAME) {
      params.name = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() || "";
  }

  return params;
};

export const FieldTable = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getFieldsQuery = useQuery({
    queryKey: [FieldTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getFields(castTableStateToParams(tableState)),
  });

  const deleteFieldsQuery = useMutation({
    mutationFn: deleteFields,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.field"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [FieldTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  // Watch table state then refetch new data for the table
  useEffect(() => {
    tableState &&
      getFieldsQuery.refetch().catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  return (
    <MultipleFilterTable
      data={getFieldsQuery.data?.fieldResponses || []}
      columns={fieldTableColumns
        // .filter((column) => appContext.meCanWrite || column.key != "action")
        .map((column) => ({
          ...column,
          label: column.label && `field.column.${column.label}`,
        }))}
      getRowId={(item) => item.id.toString()}
      loading={getFieldsQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getFieldsQuery.data?.total}
      onRowClick={(params) => {
        router.push(`/${FIELD_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`);
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: FieldFieldNames.NAME,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(`field.column.${fieldKey}`).toLocaleLowerCase(),
          }),
      }}
      groupedActions={(model) => (
        <TableGroupedActionButtons
          selectModel={model}
          onDelete={deleteFieldsQuery.mutate}
        />
      )}
    />
  );
};
