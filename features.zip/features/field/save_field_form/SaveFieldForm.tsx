import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import {
  SaveFieldDTO,
  SaveFieldRequestFieldNames,
  SaveFieldRequestSchema,
  SaveFieldRequestSchemaI,
} from "@/models/field/Field";
import { BasicSaveForm } from "@/models/ui/form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveFieldFormProps
  extends BasicSaveForm<SaveFieldDTO, SaveFieldDTO> {}

const initialEmptyValue: SaveFieldDTO = {
  name: "",
  description: "",
};

export const SaveFieldForm = (props: SaveFieldFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<SaveFieldRequestSchemaI>({
    resolver: yupResolver(SaveFieldRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue && form.reset(props.initialValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <Grid container direction={"column"} spacing={GLOBAL_SPACING}>
              <Grid item>
                <FormTextField
                  control={form.control}
                  name={SaveFieldRequestFieldNames.NAME}
                  label={t(
                    `field.field_name.${SaveFieldRequestFieldNames.NAME}`
                  )}
                  placeHolder={t(
                    `field.field_name.${SaveFieldRequestFieldNames.NAME}`
                  )}
                  required
                />
              </Grid>
              <Grid item>
                <FormTextArea
                  control={form.control}
                  name={SaveFieldRequestFieldNames.DESCRIPTION}
                  label={t(
                    `field.field_name.${SaveFieldRequestFieldNames.DESCRIPTION}`
                  )}
                  placeHolder={t(
                    `field.field_name.${SaveFieldRequestFieldNames.DESCRIPTION}`
                  )}
                  minRows={3}
                />
              </Grid>
            </Grid>
          </Grid>
        </Grid>

        <FormActionButtons
          formMode={props.formMode}
          loading={props.loading}
          onCancel={props.onCancel}
          cancelConfirm={form.formState.isDirty}
          onDelete={props.onDelete}
          onSave={props.onSubmit}
        />
      </FormProvider>
    </Grid>
  );
};
