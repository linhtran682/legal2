import { useGetLogSetting, useUpdateLogSetting } from "@/apis/service/setting/LogApi";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";

import { SettingLogSchema, SettingLogSchemaI } from "@/models/setting/Log";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button, Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export const SettingLogForm = () => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<SettingLogSchemaI>({
    resolver: yupResolver(SettingLogSchema),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const {data: logSettingData} = useGetLogSetting();
    const { mutateAsync: mutateAsyncSetting } = useUpdateLogSetting();

  useEffect(() => {
    if (logSettingData) {
      form.reset(logSettingData);
    }
  }, [form, logSettingData]);

  const handleSaveData = async(params: SettingLogSchemaI) => {
    const res = await mutateAsyncSetting(params);
    if (res) {
      toast.success(t("common.message.update_success", { recordName: t("menu.settingLog") }));
    }
  }

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <FormTextField
              control={form.control}
              name={"limitNotificationAlive"}
              label={t(
                `setting.log.label.limitNotificationAlive`
              )}
              placeHolder={t(
                `setting.log.label.limitNotificationAlive`
              )}
              required
            />
          </Grid>
          <Grid item width={"100%"}>
            <FormTextField
              control={form.control}
              name={"limitApiLogAlive"}
              label={t(
                `setting.log.label.limitApiLogAlive`
              )}
              placeHolder={t(
                `setting.log.label.limitApiLogAlive`
              )}
              required
            />
          </Grid>
          
        </Grid>

        <Grid
            container
            justifyContent={"end"}
            style={{ position: "fixed", bottom: 0 }}
          >
            <Grid item sx={{ position: "sticky", right: 0, px: 4, py: 1 }}>
              <Button
                onClick={form.handleSubmit((data) => handleSaveData(data))}
                variant="contained"
                className="confirm"
                sx={{ px: 6 }}
              >
                {t("common.button.save")}
              </Button>
            </Grid>
          </Grid>
      </FormProvider>
    </Grid>
  );
};
