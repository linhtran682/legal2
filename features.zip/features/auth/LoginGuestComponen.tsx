"use client";
import React, { useState } from "react";
import { COLOR_TYPE } from "@/constants/color";
import { LogoToWhite } from "@/assets/images/logoWhite";
import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Link,
  Typography,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { IconMessage } from "@/assets/images/icons/iconMessage";
import { IconLock } from "@/assets/images/icons/iconLock";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { authApi } from "@/apis";
import { cookieSetting } from "@/utils";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import Head from "next/head";

type LoginType = {
  email: string;
  password: string;
};

const loginSchema = Yup.object().shape({
  email: Yup.string()
    .email("email không hợp lệ ")
    .required("email là trường bắt yêu cầu"),
  password: Yup.string().required("password là trường bắt buộc."),
});
const LoginGuestComponent = () => {
  const router = useRouter();
  const [textWarning, setTextWarning] = useState("");
  const backgroundImageUrl = "/img/BackgroundImg.png";
  const { control, getValues } = useForm<LoginType>({
    resolver: yupResolver(loginSchema),
  });

  const handleLogin = async () => {
    const { email, password } = getValues();
    if (
      email === "" ||
      password == "" ||
      email === undefined ||
      password == undefined
    ) {
      setTextWarning("Không được để trống email, password");
      return;
    }
    const bodySend = {
      email,
      password,
    };
    try {
      const response = await authApi.post(`auth-temporary`, bodySend);
      cookieSetting.set("token", response.data.result.jwtToken);
      cookieSetting.set("TYPE", "TEMP");

      setTextWarning("");
      toast.success("Đăng nhập thành công", {
        autoClose: 2000,
      });

      router.push("/");
    } catch (e) {
      setTextWarning("email hoặc password không hợp lệ.");
      toast.error("Đăng nhập thất bại", {
        autoClose: 2000,
      });
    }
  };

  return (
    <div
      className="relative flex flex-col items-center justify-center h-screen"
      style={{
        backgroundImage: `url(${backgroundImageUrl})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <Head>
      <title>Legal & Compliance System</title>
      </Head>
      <div className="flex justify-center mb-6">
        <LogoToWhite />
      </div>
      <div
        className="relative flex flex-col  sm:p-8 shadow-lg w-full  bg-opacity-80"
        style={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
          height: 450,
          maxWidth: 450,
          padding: 42,
          gap: 70,
        }}
      >
        <div>
          <h2
            style={{
              fontSize: 33,
              color: COLOR_TYPE.TOYOTA.TOYOTA8,
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            Welcome
          </h2>
          <Typography
            style={{
              textAlign: "center",
              color: `${COLOR_TYPE.TOYOTA.TOYOTA8}`,
              fontWeight: "600",
              marginBottom: -17,
            }}
            component="h3"
            variant="subtitle1"
          >
            {textWarning}
          </Typography>
        </div>

        <div
          className="flex flex-col gap-x-6"
          style={{ height: 264, width: 366 }}
        >
          <form onSubmit={handleLogin}>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              <FormTextField
                name="email"
                control={control}
                label=""
                rules={{
                  required: "Email is required",
                  pattern: {
                    value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    message: "Invalid email address",
                  },
                }}
                startIcon={<IconMessage />}
                placeHolder="Enter your email"
                sx={{
                  height: 54,
                  "& .MuiInputBase-input::placeholder": {
                    color: `${COLOR_TYPE.TOYOTA.TOYOTA8} !important`,
                    opacity: 1,
                  },
                  "& .MuiOutlinedInput-root": {
                    color: COLOR_TYPE.TOYOTA.TOYOTA8,
                    "& fieldset": {
                      borderColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    },
                    "&:hover fieldset": {
                      borderColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    },
                  },
                }}
              />
              <FormTextField
                type="password"
                name="password"
                control={control}
                label=""
                rules={{ required: "Password is required" }}
                placeHolder="Password"
                startIcon={<IconLock />}
                sx={{
                  height: 54,
                  "& .MuiInputBase-input::placeholder": {
                    color: `${COLOR_TYPE.TOYOTA.TOYOTA8} !important`,
                    opacity: 1,
                  },
                  "& .MuiOutlinedInput-root": {
                    color: COLOR_TYPE.TOYOTA.TOYOTA8,
                    "& fieldset": {
                      borderColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    },
                    "&:hover fieldset": {
                      borderColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    },
                  },
                }}
              />
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <FormControlLabel
                  sx={{
                    color: COLOR_TYPE.TOYOTA.TOYOTA8,
                    "& .MuiFormControlLabel-label": {
                      fontSize: 14,
                      fontWeight: "none",
                      color: '#fff'
                    },
                  }}
                  control={
                    <Checkbox
                      sx={{
                        color: COLOR_TYPE.TOYOTA.TOYOTA8,
                        "&.Mui-checked": {
                          color: "white",
                        },
                        "& .MuiSvgIcon-root": {
                          fill: "white",
                        },
                      }}
                      //   checked={rememberMe}
                      //   onChange={(e) => setRememberMe(e.target.checked)}
                      color="primary"
                    />
                  }
                  label="Remember me"
                />
                <Link
                  href="#"
                  variant="body2"
                  sx={{
                    color: COLOR_TYPE.TOYOTA.TOYOTA8,
                  }}
                >
                  Forgot password?
                </Link>
              </Box>
            </div>
            <div style={{ width: "100%" }}>
              <Button
                onClick={handleLogin}
                // type="submit"
                variant="contained"
                color="inherit"
                style={{
                  width: "100%",
                  height: 54,
                  color: COLOR_TYPE.TOYOTA.TOYOTA1,
                  fontSize: 16,
                  fontWeight: 700,
                }}
                className="w-full bg-white gap-6"
              >
                <span>LOGIN</span>
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
export default LoginGuestComponent;
