"use client";
import React from "react";
import { COLOR_TYPE } from "@/constants/color";
import { LogoToWhite } from "@/assets/images/logoWhite";
import { useRouter } from "next/navigation";
import { IconToyota } from "@/assets/images/icons/iconToyota";
import { cookieSetting } from "@/utils";
import { useMsal } from "@azure/msal-react";
import { loginRequest } from "@/authAccess/auth-config";
// import { IconGoogle } from "@/assets/images/icons/iconGoogle";
import Head from "next/head";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
const LoginComponent = () => {
  const router = useRouter();
  const backgroundImageUrl = "/img/BackgroundImg.png";
  const { instance } = useMsal();
  // const isAuthenticated = useIsAuthenticated();

  const handleLogin = (e: any) => {
    e.preventDefault();
    router.push("/auth/login_guest");
    cookieSetting.set("TYPE", "TEMP");
  };
  const handleLogin365 = async (e: any) => {
    e.preventDefault();
    cookieSetting.set("TYPE", "MS365");
    instance
      .loginRedirect({
        ...loginRequest,
        prompt: "select_account",
      })
      .then(() => {});
  };

  return (
    <div
      className="relative flex flex-col items-center justify-center h-screen "
      style={{
        backgroundImage: `url(${backgroundImageUrl})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {" "}
      <Head>
        <title>Legal & Compliance System</title>
      </Head>
      <div className="flex justify-center mb-6">
        <LogoToWhite />
      </div>
      <div
        className="relative flex flex-col sm:p-8 shadow-lg w-full"
        style={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
          height: 450,
          maxWidth: 459,
          padding: 42,
          gap: 64,
        }}
      >
        <h2
          style={{
            fontSize: 33,
            color: COLOR_TYPE.TOYOTA.TOYOTA8,
            textAlign: "center",
            fontWeight: "bold",
          }}
        >
          Welcome
        </h2>
        <form style={{ display: "flex", flexDirection: "column", gap: 32 }}>
          <button
            onClick={handleLogin365}
            style={{
              height: 54,
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
              paddingLeft: 50,
              fontSize: 16,
              display: "flex",
              alignItems: "center",
              gap: 4,
            }}
            className="w-full text-dark  hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300"
          >
            <div
              style={{
                width: 16,
                height: 16,
                backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
                borderRadius: 4,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <IconToyota />
            </div>
            <span className="inline">Login with TMV</span>
          </button>
          <button
            onClick={handleLogin}
            style={{
              height: 54,
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
              paddingLeft: 47,
              fontSize: 16,
            }}
            className="w-full text-dark flex items-center  hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300"
          >
            <div
              style={{
                width: 24,
                height: 24,
                borderRadius: 4,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <div
                style={{
                  width: 16,
                  height: 16,
                  color: COLOR_TYPE.TOYOTA.TOYOTA1,
                  borderRadius: 4,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <AccountCircleIcon/>
              </div>
            </div>
            <span className="inline">Login as Guest</span>
          </button>

          <div>
            <p
              className="text-xs sm:text-sm font-normal mx-auto"
              style={{
                fontSize: 10,
                color: COLOR_TYPE.TOYOTA.TOYOTA8,
                textAlign: "center",
                width: 319,
                padding: "32px 0px 0px 0px",
              }}
            >
              Not a member? To request an account, please contact your
              administrators
            </p>
          </div>
        </form>
        {/* <div className="absolute bottom-3 left-0 right-0 text-center py-2"> */}
      </div>
    </div>
  );
};
export default LoginComponent;
