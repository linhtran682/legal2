import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { AdviceExtension } from "@/models/legal-advice/LegalAdviceList";
import { VisitationBodyReceive } from "@/models/visitation/VisitationDetail";
import { Button } from "@mui/material";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { useTranslation } from "react-i18next";
import { TimeExtensionVisitationForm } from "../../action-popup/time_extension_form/TimeExtensionVisitationForm";
import { useContext, useState } from "react";
import { AppContext } from "@/context/AppContext";

interface Props {
  queryKey: string;
  getExtendRecords: () => Promise<AdviceExtension[]>;
  visitationId?: number;
  visitation?: VisitationBodyReceive;
}

export const VisitationExtendPanel = (props: Props) => {
  const { queryKey, getExtendRecords, visitationId, visitation } = props;
  const { i18n, t } = useTranslation();
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();
  const getExtendRecordsQuery = useQuery({
    queryKey: [queryKey],
    queryFn: () => getExtendRecords(),
  });
  const [extendDeadlineId, setExtendDeadlineId] = useState<number>();
  const [isOpenTimeExtension, setIsOpenTimeExtension] =
    useState<boolean>(false);

  const handleClickExtend = (params: AdviceExtension) => {
    setIsOpenTimeExtension(true);
    setExtendDeadlineId(params?.id);
  };

  const ExtendTableColumns: StandardSimpleTableColumn<AdviceExtension>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +params?.id + 1,
    },
    {
      key: "department",
      label: "metadata.extend.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.department?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.extend.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "reason",
      label: "timeExtension.title.reason",
      type: "string",
      flex: 1,
    },
    {
      key: "requestDeadline",
      label: "visitation.tabs.requestDeadline",
      type: "date",
      flex: 1,
      renderCell: (params) =>
        params.row.requestDeadline
          ? format(new Date(params.row.requestDeadline), "dd/MM/yyyy")
          : "",
    },
    {
      key: "acceptDeadline",
      label: "visitation.tabs.acceptDeadline",
      type: "date",
      flex: 1,
      renderCell: (params) =>
        params.row.acceptDeadline
          ? format(new Date(params.row.acceptDeadline), "dd/MM/yyyy")
          : "",
    },
    {
      key: "timeExtensionType",
      label: "visitation.tabs.type",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row.timeExtensionType
          ? t(`visitation.timeExtensionType.${params.row.timeExtensionType}`)
          : "",
    },
    {
      key: "status",
      label: "visitation.tabs.status",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row.type ? t(`visitation.status.${params.row.type}`) : "",
    },
    {
      key: "actionType",
      label: "Action",
      type: "string",
      flex: 1,
      renderCell: (params) => {
        return params.row?.showExtension ? (
          <Button
            disabled={!params.row?.enableExtension}
            onClick={() => handleClickExtend(params?.row)}
          >
            {t("followViolation.action.extend")}
          </Button>
        ) : (
          <></>
        );
      },
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={ExtendTableColumns}
        data={getExtendRecordsQuery?.data ?? []}
        getRowId={(_, index) => index.toString()}
      />

      {isOpenTimeExtension &&
        extendDeadlineId &&
        visitationId &&
        visitation?.name && (
          <TimeExtensionVisitationForm
            isConfirmExtension
            setIsOpen={(state) => setIsOpenTimeExtension(state)}
            isOpen={isOpenTimeExtension}
            visitationId={visitationId}
            visitation={visitation}
            timeExtensionRequestId={extendDeadlineId}
            name={visitation?.name}
            sender={appContext?.me}
            createdBy={visitation?.createdBy}
            handleSubmit={() => {
              queryClient.invalidateQueries({
                queryKey: ["get_sign_approve_tab"],
              });
              queryClient.invalidateQueries({
                queryKey: ["get_initial_visitation_detail"],
              });
            }}
          />
        )}
    </div>
  );
};
