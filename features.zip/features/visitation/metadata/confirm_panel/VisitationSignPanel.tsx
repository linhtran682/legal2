import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { StatusTabConfirmR } from "@/constants/general";
import { LANGUAGES } from "@/locales/config-translation";
import { VisitationSign } from "@/models/visitation/VisitationDetail";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

export interface ConfirmPanelProps {
  queryKey: string;
  getConfirmRecords: () => Promise<VisitationSign[]>;
}

export const VisitationSignPanel = (props: ConfirmPanelProps) => {
  const { i18n, t } = useTranslation();

  const getConfirmRecordsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getConfirmRecords(),
  });

  const signTableColumns: StandardSimpleTableColumn<VisitationSign>[] = [
    {
      key: "id",
      label: "document_type.column.id",
      type: "number",
      flex: 1,
      renderCell: (params) => +(params?.id ?? 0) + 1,
    },
    {
      key: "department",
      label: "metadata.confirm.column.departmentName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "user",
      label: "metadata.confirm.column.employeeName",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        params.row?.user?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ],
    },
    {
      key: "content",
      label: "metadata.confirm.column.content",
      type: "string",
      flex: 1,
    },
    {
      key: "deadline",
      label: "metadata.confirm.column.date",
      type: "date",
      flex: 1,
    },
    {
      key: "evaluateUsers",
      label: "metadata.confirm.column.evaluateUsers",
      type: "string",
      flex: 1,
      renderCell: (params) => {
        const evaluateUsers =
          params.row?.user?.[
            i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
          ];
        return evaluateUsers;
      },
    },
    {
      key: "approvalStatus",
      label: "metadata.confirm.column.status",
      type: "string",
      flex: 1,
      renderCell: (params) =>
        t(
          `metadata.confirm.status.${StatusTabConfirmR.get(
            params.row.status as number
          )}`
        ),
    },
  ];
  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={signTableColumns}
        data={getConfirmRecordsQuery.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
    </div>
  );
};
