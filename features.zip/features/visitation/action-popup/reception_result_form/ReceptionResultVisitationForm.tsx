import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useEffect, useMemo, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  useCreateReceptionResultVisitation,
  useGetReceptionResultVisitationList,
  useUpdateReceptionResultVisitation,
} from "@/apis/service/visitation/receptionResultVisitation";
import {
  ReceptionResultVisitationFieldNames,
  ReceptionResultVisitationSchemaI,
  ReceptionResultSchemaVisitation,
} from "@/models/visitation/ReceptionResultVisitation";
import { useQueryClient } from "@tanstack/react-query";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useGetConfirmVisitationList } from "@/apis/service/visitation/confirmVisitation";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: ReceptionResultVisitationSchemaI = {
  [ReceptionResultVisitationFieldNames.CONTENT]: "",
  [ReceptionResultVisitationFieldNames.USER_IDS]: [],
  [ReceptionResultVisitationFieldNames.REMIND]: undefined,
};

export interface ReceptionResultVisitationFormProps {
  titlePopup?: string;
  initialValue?: ReceptionResultVisitationSchemaI;
  visitationId?: number;
  visitation?: any;
  receptionResultVisitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
}

export const ReceptionResultVisitationForm = (
  props: ReceptionResultVisitationFormProps
) => {
  const {
    titlePopup = "visitation.receptionResult.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    receptionResultVisitation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(ReceptionResultSchemaVisitation),
    defaultValues: initialValue,
  });

  const {
    data: getReceptionResultVisitationList,
    isLoading: isLoadingGetReceptionResultVisitationList,
  } = useGetReceptionResultVisitationList({
    request: { visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  const {
    data: getConfirmVisitationList,
    isLoading: isLoadingGetConfirmVisitationList,
  } = useGetConfirmVisitationList({
    request: { visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  /**
   * Current receptionResult visitation
   */
  const currentReceptionResultVisitation = useMemo(() => {
    // When click to edit button, on detail page
    if (receptionResultVisitation?.id) {
      return receptionResultVisitation;
    }

    // When click button: "Kết quả tiếp đón"
    else {
      let receptionResultList = getReceptionResultVisitationList?.data;
      receptionResultList =
        Array.isArray(receptionResultList) && receptionResultList.length
          ? [...receptionResultList]
          : [];

      const reversedReceptionResultList = receptionResultList.reverse();
      const foundReceptionResult = reversedReceptionResultList.find(
        (item) => item?.createBy?.id === sender?.id
      );

      if (foundReceptionResult) {
        return foundReceptionResult;
      }
    }
  }, [sender, receptionResultVisitation, getReceptionResultVisitationList]);

  /**
   * Set values to form
   */
  useEffect(() => {
    if (currentReceptionResultVisitation?.id && visitation?.id) {
      let receiverUsers = currentReceptionResultVisitation?.receiverUsers;
      receiverUsers =
        Array.isArray(receiverUsers) && receiverUsers.length
          ? [...receiverUsers]
          : [];

      form.reset({
        [ReceptionResultVisitationFieldNames.CONTENT]:
          currentReceptionResultVisitation?.content,
        [ReceptionResultVisitationFieldNames.USER_IDS]: receiverUsers,
      });
    }
  }, [
    form,
    visitation,
    currentReceptionResultVisitation,
    getConfirmVisitationList,
  ]);

  const {
    mutateAsync: createReceptionResultVisitation,
    isPending: isCreatePending,
  } = useCreateReceptionResultVisitation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t(titlePopup),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_sign_approve_tab"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_visitation_detail"],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
        });
        onCloseForm();
      },
    },
  });

  const {
    mutateAsync: updateReceptionResultVisitation,
    isPending: isUpdateLoading,
  } = useUpdateReceptionResultVisitation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(titlePopup),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_sign_approve_tab"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_visitation_detail"],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
        });
        onCloseForm();
      },
    },
  });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const userIds =
      Array.isArray(values?.userIds) && values?.userIds.length
        ? [...values?.userIds].map((item) => item?.id)
        : [];

    const data = {
      ...values,
      userIds,
    };

    // Update receptionResult
    if (currentReceptionResultVisitation?.id) {
      await updateReceptionResultVisitation({
        visitationId,
        receptionResultId: currentReceptionResultVisitation?.id,
        data: {
          content: data.content,
        },
      });
    }

    // Update receptionResult
    else {
      await createReceptionResultVisitation({
        visitationId,
        data,
      });
    }
  };

  if (
    isLoadingGetReceptionResultVisitationList ||
    isLoadingGetConfirmVisitationList
  ) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.receptionResult.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.receptionResult.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ReceptionResultVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.receptionResult.title.${ReceptionResultVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.receptionResult.placeHolder.${ReceptionResultVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ReceptionResultVisitationFieldNames.USER_IDS}
                  label={t("visitation.receptionResult.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"receptionResultVisitation/queryUser"}
                  isFocus
                  required
                  disabled={currentReceptionResultVisitation?.id}
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ReceptionResultVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isCreatePending || isUpdateLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
