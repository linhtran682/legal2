import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { useCreateReceptionVisitation } from "@/apis/service/visitation/receptionVisitation";
import {
  ReceptionFieldNames,
  ReceptionSchemaI,
  ReceptionSchemaVisitation,
} from "@/models/visitation/ReceptionVisitation";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQueryClient } from "@tanstack/react-query";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: ReceptionSchemaI = {
  [ReceptionFieldNames.USER_IDS]: [],
  [ReceptionFieldNames.REMIND]: undefined,
};

export interface ReceptionVisitationFormProps {
  titlePopup?: string;
  initialValue?: ReceptionSchemaI;
  visitationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
}

export const ReceptionVisitationForm = (
  props: ReceptionVisitationFormProps
) => {
  const {
    titlePopup = "visitation.receptionVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(ReceptionSchemaVisitation),
    defaultValues: initialValue,
  });

  const { mutateAsync: createReceptionVisitation, isPending } =
    useCreateReceptionVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const userIds =
      Array.isArray(values?.userIds) && values?.userIds.length
        ? [...values?.userIds].map((item) => item?.id)
        : [];

    const data = {
      ...values,
      userIds,
    };

    await createReceptionVisitation({
      visitationId,
      data,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.receptionVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.receptionVisitation.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ReceptionFieldNames.USER_IDS}
                  label={t("visitation.receptionVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"receptionVisitation/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ReceptionFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
