import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useRef, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { useCreateShareInfoVisitation } from "@/apis/service/visitation/shareInfoVisitation";
import {
  ShareInfoVisitationFieldNames,
  ShareInfoVisitationSchemaI,
  ShareInfoSchemaVisitation,
} from "@/models/visitation/ShareInfoVisitation";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQueryClient } from "@tanstack/react-query";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { getDepartments } from "@/apis/service/department/department";
import { Department } from "@/models/department/Department";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: ShareInfoVisitationSchemaI = {
  [ShareInfoVisitationFieldNames.DEADLINE]: "",
  [ShareInfoVisitationFieldNames.CONTENT]: "",
  [ShareInfoVisitationFieldNames.DEPARTMENTS]: [],
  [ShareInfoVisitationFieldNames.REMIND]: undefined,
};

export interface ShareInfoVisitationFormProps {
  titlePopup?: string;
  initialValue?: ShareInfoVisitationSchemaI;
  visitationId?: number;
  visitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  deadline?: Date;
  module?: number;
  sender?: any;
}

export const ShareInfoVisitationForm = (
  props: ShareInfoVisitationFormProps
) => {
  const {
    titlePopup = "visitation.shareInfo.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    isOpen = false,
    setIsOpen,
    name,
    deadline,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(ShareInfoSchemaVisitation),
    defaultValues: initialValue,
  });

  useEffect(() => {
    if (!visitationId) {
      return;
    }

    let departments = visitation?.shareInformationDepartments;
    departments =
      Array.isArray(departments) && departments.length ? [...departments] : [];

    form.reset({
      [ShareInfoVisitationFieldNames.DEADLINE]: deadline,
      [ShareInfoVisitationFieldNames.DEPARTMENTS]: departments,
    });
  }, [form, visitationId, visitation, deadline]);

  const { mutateAsync: createShareInfoVisitation, isPending } =
    useCreateShareInfoVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const departmentIds =
      Array.isArray(values?.departments) && values?.departments.length
        ? [...values?.departments].map((item) => item?.id)
        : [];

    const data = { ...values, departmentIds };
    delete data.departments;

    await createShareInfoVisitation({
      visitationId,
      data,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.shareInfo.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.shareInfo.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateTimeInput
                  name={ShareInfoVisitationFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`visitation.shareInfo.title.deadline`)}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ShareInfoVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.shareInfo.title.${ShareInfoVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.shareInfo.placeHolder.${ShareInfoVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormSelectTreeView
                  name={ShareInfoVisitationFieldNames.DEPARTMENTS}
                  control={form.control}
                  label={t("visitation.shareInfo.title.department")}
                  placeholder={t("visitation.shareInfo.placeHolder.department")}
                  getOptions={async (keyword) => {
                    try {
                      const response = await getDepartments({
                        searchTerm: keyword,
                      });
                      const first100Departments: Department[] = (
                        response?.departments ?? []
                      ).slice(0, 150);
                      return first100Departments;
                    } catch (e) {
                      return [];
                    }
                  }}
                  getOptionLabel={(option) => option.name ?? ""}
                  getOptionKey={(option) => option.id ?? ""}
                  getOptionChildren={(option) => option.children}
                  selectedItemsProp={
                    visitation?.shareInformationDepartments ?? undefined
                  }
                  variant="outlined"
                  debounceMs={FILTER_DEBOUNCE_MS}
                  onChange={(value: Department[]) => {
                    form.setValue(
                      ShareInfoVisitationFieldNames.DEPARTMENTS,
                      value
                    );
                  }}
                  rules={{ required: "This field is required" }}
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ShareInfoVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
