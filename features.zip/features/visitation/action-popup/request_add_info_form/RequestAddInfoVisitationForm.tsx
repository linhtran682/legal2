import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import moment from "moment";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { useCreateRequestAddInfoVisitation } from "@/apis/service/visitation/requestAddInfoVisitation";
import {
  RequestAddInfoVisitationFieldNames,
  RequestAddInfoVisitationSchemaI,
  RequestAddInfoSchemaVisitation,
} from "@/models/visitation/RequestAddInfoVisitation";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQueryClient } from "@tanstack/react-query";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: RequestAddInfoVisitationSchemaI = {
  [RequestAddInfoVisitationFieldNames.DEADLINE]: "",
  [RequestAddInfoVisitationFieldNames.CONTENT]: "",
  [RequestAddInfoVisitationFieldNames.REMIND]: undefined,
};

export interface RequestAddInfoVisitationFormProps {
  titlePopup?: string;
  initialValue?: RequestAddInfoVisitationSchemaI;
  visitationId?: number;
  visitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  createdBy?: any;
}

export const RequestAddInfoVisitationForm = (
  props: RequestAddInfoVisitationFormProps
) => {
  const {
    titlePopup = "visitation.requestAdditional.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
    createdBy,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(RequestAddInfoSchemaVisitation),
    defaultValues: initialValue,
  });

  useEffect(() => {
    form.reset({
      [RequestAddInfoVisitationFieldNames.USERS]: [createdBy],
    });
  }, [form, createdBy]);

  const { mutateAsync: createRequestAddInfoVisitation, isPending } =
    useCreateRequestAddInfoVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    await createRequestAddInfoVisitation({
      visitationId,
      data: {
        deadline: values?.deadline,
        content: values?.content,
      },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.requestAdditional.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={RequestAddInfoVisitationFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`visitation.requestAdditional.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  maxDate={moment
                    .utc(visitation?.responseLCDeadline)
                    .local()
                    .toDate()}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestAddInfoVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.requestAdditional.title.${RequestAddInfoVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.requestAdditional.placeHolder.${RequestAddInfoVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={RequestAddInfoVisitationFieldNames.USERS}
                  label={t("visitation.requestAdditional.title.personInCharge")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"requestAdditional/queryUser"}
                  isFocus
                  disabled
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={RequestAddInfoVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
