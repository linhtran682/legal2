import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import moment from "moment";
import { useGetEvaluateVisitationList } from "@/apis/service/visitation/evaluateVisitation";
import { useCreateRequestEvaluateVisitation } from "@/apis/service/visitation/requestEvaluateVisitation";
import {
  RequestEvaluateFieldNames,
  RequestEvaluateSchemaI,
  RequestEvaluateSchemaVisitation,
} from "@/models/visitation/RequestEvaluateVisitation";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { GetUsersParams, UserProfileDTO } from "@/models/user/User";
import { getUser, getUsers } from "@/apis/service/user/User";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { VisitationTableConst } from "../../table/VisitationTable";
import { findDeepestId } from "@/utils";
import { getLegalDepartments } from "@/apis/service/department/department";

const initialEmptyValue: RequestEvaluateSchemaI = {
  [RequestEvaluateFieldNames.DEADLINE]: "",
  [RequestEvaluateFieldNames.CONTENT]: "",
  [RequestEvaluateFieldNames.RECEIVER_USERS]: [],
  [RequestEvaluateFieldNames.REMIND]: undefined,
};

export interface RequestEvaluateVisitationFormProps {
  titlePopup?: string;
  initialValue?: RequestEvaluateSchemaI;
  visitationId?: number;
  visitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  staffLCUsers?: any;
  sender?: any;
}

export const RequestEvaluateVisitationForm = (
  props: RequestEvaluateVisitationFormProps
) => {
  const {
    titlePopup = "visitation.requestEvaluateVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    staffLCUsers,
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(RequestEvaluateSchemaVisitation),
    defaultValues: initialValue,
  });

  const {
    data: getEvaluateVisitationList,
    isLoading: isLoadingGetEvaluateVisitationList,
  } = useGetEvaluateVisitationList({
    request: { visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["visitation/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  useEffect(() => {
    if (!visitation?.id) {
      return;
    }

    const deadline = visitation?.responseLCDeadline
      ? moment.utc(visitation?.responseLCDeadline).local().toDate()
      : moment(new Date())
          .add(3 * 24, "hours")
          .toDate();
    const newStaffLCUsers =
      Array.isArray(staffLCUsers) && staffLCUsers.length
        ? [...staffLCUsers]
        : [];

    form.reset({
      [RequestEvaluateFieldNames.DEADLINE]: deadline,
      [RequestEvaluateFieldNames.RECEIVER_USERS]: newStaffLCUsers[0]?.id,
    });
  }, [form, visitation, staffLCUsers]);

  const { mutateAsync: createRequestEvaluateVisitation, isPending } =
    useCreateRequestEvaluateVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const data = {
      ...values,
      receiverUsers: [values?.receiverUsers],
    };

    await createRequestEvaluateVisitation({
      visitationId,
      data,
    });
  };

  if (isLoadingGetEvaluateVisitationList || !getLegalDepartmentQuery?.data) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.requestEvaluateVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.requestEvaluateVisitation.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateTimeInput
                  name={RequestEvaluateFieldNames.DEADLINE}
                  control={form.control}
                  label={t(
                    `visitation.requestEvaluateVisitation.title.deadline`
                  )}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestEvaluateFieldNames.CONTENT}
                  label={t(
                    `visitation.requestEvaluateVisitation.title.${RequestEvaluateFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.requestEvaluateVisitation.placeHolder.${RequestEvaluateFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormAsyncSelect<any, UserProfileDTO>
                  control={form.control}
                  name={RequestEvaluateFieldNames.RECEIVER_USERS}
                  minCharLength={1}
                  label={t(
                    "visitation.requestEvaluateVisitation.title.receiver"
                  )}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                        departmentIds: getLegalDepartmentQuery?.data
                          ? [getLegalDepartmentQuery?.data]
                          : [],
                      };
                      const response = (await getUsers(params)) as any;
                      const result = (response?.users).filter(
                        (item: UserProfileDTO) => item?.id !== sender?.id
                      );

                      return result;
                    } else if (keyword?.length && keyword.length > 0) {
                      return getUser(keyword[0])
                        .then((response) => (response ? [response] : []))
                        .catch(() => []);
                    } else {
                      return [];
                    }
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""})`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"requestEvaluateVisitation/queryUser"}
                  isFocus
                  required
                  disabled={
                    Array.isArray(visitation?.staffLCUsers) &&
                    visitation?.staffLCUsers.length &&
                    Array.isArray(getEvaluateVisitationList?.data) &&
                    getEvaluateVisitationList?.data.length
                  }
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={RequestEvaluateFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
