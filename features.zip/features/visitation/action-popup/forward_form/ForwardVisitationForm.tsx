import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  castForwardVisitationRequestSchemaToDTO,
  ForwardVisitationFieldNames,
  ForwardVisitationSchema,
  ForwardVisitationSchemaI,
} from "@/models/visitation/ForwardVisitation";
import { useCreateForwardForwardFollow } from "@/apis/service/visitation/forwardVisitation";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { Module, ModuleKeys } from "@/constants/general";
import { useQueryClient } from "@tanstack/react-query";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: ForwardVisitationSchemaI = {
  [ForwardVisitationFieldNames.USERS_IDS]: [],
  [ForwardVisitationFieldNames.DEADLINE]: "",
  [ForwardVisitationFieldNames.CONTENT]: "",
  [ForwardVisitationFieldNames.REMIND]: undefined,
};

export interface ForwardVisitationFormProps {
  titlePopup?: string;
  initialValue?: ForwardVisitationSchemaI;
  visitationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
}

export const ForwardVisitationForm = (props: ForwardVisitationFormProps) => {
  const {
    titlePopup = "visitation.forwardVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(ForwardVisitationSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createForward, isPending } =
    useCreateForwardForwardFollow({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { ...restData } = data;

    await createForward({
      visitationId,
      data: restData,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.forwardVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`response_to_lc_form.field_name.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={ForwardVisitationFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`visitation.forwardVisitation.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  minDate={new Date()}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ForwardVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.forwardVisitation.title.${ForwardVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.forwardVisitation.placeHolder.${ForwardVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ForwardVisitationFieldNames.USERS_IDS}
                  label={t("visitation.forwardVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"forwardVisitation/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ForwardVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castForwardVisitationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
