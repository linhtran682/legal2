import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { getLegalDepartments } from "@/apis/service/department/department";
import { getUser, getUsers } from "@/apis/service/user/User";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AssignmentVisitationFieldNames,
  AssignmentVisitationSchema,
  AssignmentVisitationSchemaI,
  castAssignmentVisitationRequestSchemaToDTO,
} from "@/models/visitation/AssignmentVisitation";
import { useCreateAssignmentVisitation } from "@/apis/service/visitation/assignmentVisitation";
import { Module, ModuleKeys } from "@/constants/general";
import { VisitationTableConst } from "../../table/VisitationTable";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { GetUsersParams, UserProfileDTO } from "@/models/user/User";

const initialEmptyValue: AssignmentVisitationSchemaI = {
  [AssignmentVisitationFieldNames.CONTENT]: "",
  [AssignmentVisitationFieldNames.USERS_ID]: [],
  [AssignmentVisitationFieldNames.REMIND]: undefined,
};

export interface AssignmentVisitationFormProps {
  titlePopup?: string;
  initialValue?: AssignmentVisitationSchemaI;
  visitationId?: number;
  visitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  createBy?: any;
}

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}

export const AssignmentVisitationForm = (
  props: AssignmentVisitationFormProps
) => {
  const {
    titlePopup = "visitation.assignment.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VIOLATE),
    sender,
    createBy,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(AssignmentVisitationSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createAssignmentVisitation, isPending } =
    useCreateAssignmentVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("visitation.assignment.title.titlePopup"),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["visitation/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createAssignmentVisitation({
      visitationId,
      data,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.assignment.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`visitation.assignment.title.sender`)}
                </label>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AssignmentVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.assignment.title.${AssignmentVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.assignment.placeHolder.${AssignmentVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormAsyncSelect<any, UserProfileDTO>
                  control={form.control}
                  name={AssignmentVisitationFieldNames.USERS_ID}
                  minCharLength={1}
                  label={t(
                    "visitation.assignment.title.receiver"
                  )}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      let staffLCUsers = visitation?.staffLCUsers;
                      staffLCUsers =
                        Array.isArray(staffLCUsers) && staffLCUsers.length
                          ? [...staffLCUsers]
                          : [];

                      let assignmentUsers = visitation?.assignmentUsers;
                      assignmentUsers =
                        Array.isArray(assignmentUsers) && assignmentUsers.length
                          ? [...assignmentUsers]
                          : [];

                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                        departmentIds: getLegalDepartmentQuery?.data
                          ? [getLegalDepartmentQuery?.data]
                          : [],
                      };
                      const response = (await getUsers(params)) as any;
                      const result = (response?.users).filter((user: any) => {
                        return (
                          user?.id !== createBy?.id &&
                          user?.id !== sender?.id &&
                          // !advisorList.some(
                          //   (u: any) => user?.id === u?.createBy?.id
                          // ) &&
                          ![...staffLCUsers, ...assignmentUsers].some(
                            (u: any) => user?.id === u?.id
                          )
                        );
                      });

                      return result;
                    } else if (keyword?.length && keyword.length > 0) {
                      const res = await getUser(keyword[0])
                        .then((response) => (response ? [response] : []))
                        .catch(() => []);

                      return res;
                    } else {
                      return [];
                    }
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""})`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"assignmentVisitation/queryUser"}
                  noShowErrorNotification
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={AssignmentVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castAssignmentVisitationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
