import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import moment from "moment";
import {
  Grid,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  useCreateEvaluateVisitation,
  useGetEvaluateVisitationList,
  useUpdateEvaluateVisitation,
} from "@/apis/service/visitation/evaluateVisitation";
import {
  EvaluateVisitationFieldNames,
  EvaluateVisitationSchemaI,
  ConfirmSchemaVisitation,
  FileInfo,
  castEvaluateVisitationSchemaToDTO,
  EvaluateVisitationOptions,
} from "@/models/visitation/EvaluateVisitation";
import { useQueryClient } from "@tanstack/react-query";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { DateRangeIcon } from "@mui/x-date-pickers";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { VisitationStatusCode } from "@/constants/visitation";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: EvaluateVisitationSchemaI = {
  [EvaluateVisitationFieldNames.IS_CONFIRM]: true,
  [EvaluateVisitationFieldNames.CONTENT]: "",
  [EvaluateVisitationFieldNames.RECEIVER_USERS]: [],
  [EvaluateVisitationFieldNames.REMIND]: undefined,
};

export interface EvaluateVisitationFormProps {
  titlePopup?: string;
  initialValue?: EvaluateVisitationSchemaI;
  visitationId?: number;
  visitation?: any;
  evaluateVisitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
  createdBy?: any;
}

export const EvaluateVisitationForm = (props: EvaluateVisitationFormProps) => {
  const {
    titlePopup = "visitation.evaluateVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    evaluateVisitation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
    createdBy,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(ConfirmSchemaVisitation),
    defaultValues: initialValue,
  });
  const [files, setFiles] = useState<any>([]);

  const {
    data: getEvaluateVisitationList,
    isLoading: isLoadingGetEvaluateVisitationList,
  } = useGetEvaluateVisitationList({
    request: { visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  /**
   * Current confirm visitation
   */
  const currentEvaluateVisitation = useMemo(() => {
    // When click to edit button, on detail page
    if (evaluateVisitation?.id) {
      return evaluateVisitation;
    }

    // When click button: "Đánh giá"
    else {
      let evaluateList = getEvaluateVisitationList?.data;
      evaluateList =
        Array.isArray(evaluateList) && evaluateList.length
          ? [...evaluateList]
          : [];

      const reversedEvaluateList = evaluateList.reverse();
      const foundEvaluate = reversedEvaluateList.find(
        (item) => item?.createBy?.id === sender?.id
      );

      if (foundEvaluate) {
        return foundEvaluate;
      }
    }
  }, [sender, evaluateVisitation, getEvaluateVisitationList]);

  /**
   * Is updating
   */
  const isUpdating = useMemo(() => {
    return (
      currentEvaluateVisitation?.id &&
      visitation?.id &&
      visitation?.status?.code !== VisitationStatusCode.EVALUATE_REQUEST
    );
  }, [currentEvaluateVisitation, visitation]);

  /**
   * Set values to form
   */
  useEffect(() => {
    if (isUpdating) {
      let receiverUsers = currentEvaluateVisitation?.receiverUsers;
      receiverUsers =
        Array.isArray(receiverUsers) && receiverUsers.length
          ? [...receiverUsers]
          : [];

      form.reset({
        [EvaluateVisitationFieldNames.IS_CONFIRM]:
          visitation?.status?.code !==
          VisitationStatusCode.EVALUATE_FEEDBACK_REJECT,
        [EvaluateVisitationFieldNames.CONTENT]:
          currentEvaluateVisitation?.content,
        [EvaluateVisitationFieldNames.RECEIVER_USERS]: receiverUsers,
      });

      if (
        Array.isArray(currentEvaluateVisitation?.attachments) &&
        currentEvaluateVisitation?.attachments.length
      ) {
        setFiles(
          currentEvaluateVisitation.attachments?.map((item: any) => {
            return {
              name: item?.fileName,
              path: item?.filePath,
              id: item?.fileId,
              uploadDate: item?.uploadDate,
            };
          })
        );
      }
    } else {
      form.reset({
        [EvaluateVisitationFieldNames.IS_CONFIRM]: true,
        [EvaluateVisitationFieldNames.RECEIVER_USERS]: [createdBy],
      });
    }
  }, [form, createdBy, visitation, currentEvaluateVisitation, isUpdating]);

  const { mutateAsync: createEvaluateVisitation, isPending: isCreatePending } =
    useCreateEvaluateVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("visitation.evaluateVisitation.message.create_success")
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const { mutateAsync: updateEvaluateVisitation, isPending: isUpdateLoading } =
    useUpdateEvaluateVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("visitation.evaluateVisitation.message.update_success")
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const receiverUsers =
      Array.isArray(values?.receiverUsers) && values?.receiverUsers.length
        ? [...values?.receiverUsers].map((item) => item?.id)
        : [];

    const data = {
      ...values,
      isConfirm: values?.isConfirm === "true" || values?.isConfirm === true,
      receiverUsers,
    };

    // Update
    if (isUpdating) {
      await updateEvaluateVisitation({
        visitationId,
        feedbackId: currentEvaluateVisitation?.id,
        data: {
          content: data.content,
          attachmentIds: data.attachmentIds,
        },
      });
    }

    // Create
    else {
      await createEvaluateVisitation({
        visitationId,
        data,
      });
    }
  };

  if (isLoadingGetEvaluateVisitationList) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.evaluateVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.evaluateVisitation.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <RadioGroupField
                  name={EvaluateVisitationFieldNames.IS_CONFIRM}
                  control={form.control}
                  items={EvaluateVisitationOptions.map((item) => {
                    return {
                      label: t(`${item?.label}`),
                      value: item?.value,
                    };
                  })}
                  error={
                    form.formState.errors[
                      EvaluateVisitationFieldNames.IS_CONFIRM
                    ] as FieldError
                  }
                  isDisabled={isUpdating}
                />
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`visitation.evaluateVisitation.title.responseLCDeadline`)}
                </InputLabel>

                <TextField
                  value={
                    visitation?.responseLCDeadline
                      ? moment
                          .utc(visitation?.responseLCDeadline)
                          .local()
                          .format("DD/MM/YYYY hh:mm")
                      : ""
                  }
                  minRows={3}
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <DateRangeIcon />
                      </InputAdornment>
                    ),
                  }}
                  fullWidth
                  disabled
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={EvaluateVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.evaluateVisitation.title.${EvaluateVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.evaluateVisitation.placeHolder.${EvaluateVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView
                  preview={false}
                  files={files}
                  setFiles={setFiles}
                  title={t(`visitation.evaluateVisitation.title.attachments`)}
                  inputId="advisorFollowVisitation"
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={EvaluateVisitationFieldNames.RECEIVER_USERS}
                  label={t("visitation.evaluateVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"evaluateVisitation/queryUser"}
                  isFocus
                  required
                  disabled={isUpdating}
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={EvaluateVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isCreatePending || isUpdateLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit(
                    castEvaluateVisitationSchemaToDTO({
                      ...form.getValues(),
                      attachmentIds: attachments,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
