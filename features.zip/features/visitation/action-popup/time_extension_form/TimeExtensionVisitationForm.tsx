import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING, VIVN_INTL_LOCALE } from "@/constants/format";
import {
  Card,
  Grid,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import { DateRangeIcon } from "@mui/x-date-pickers";
import React, { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import moment from "moment";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import {
  ConfirmExtensionRequestVisitationSchema,
  ExtensionVisitationOptions,
  ConfirmExtensionVisitationType,
  TimeExtensionRequestVisitationFieldNames,
  TimeExtensionRequestVisitationSchema,
  TimeExtensionRequestVisitationSchemaI,
  TimeExtensionVisitationType,
} from "@/models/visitation/TimeExtensionVisitation";
import {
  useCreateTimeExtensionVisitation,
  useGetTimeExtensionVisitation,
  useUpdateTimeExtensionVisitation,
} from "@/apis/service/visitation/timeExtensionVisitation";
import { useQueryClient } from "@tanstack/react-query";
import { VisitationTableConst } from "../../table/VisitationTable";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";

const initialEmptyValue: TimeExtensionRequestVisitationSchemaI = {
  [TimeExtensionRequestVisitationFieldNames.DEADLINE]: "",
  [TimeExtensionRequestVisitationFieldNames.REASON]: "",
  [TimeExtensionRequestVisitationFieldNames.RECEIVER_USERS]: [],
  [TimeExtensionRequestVisitationFieldNames.REMIND]: undefined,
};

export interface TimeExtensionVisitationFormProps {
  titlePopup?: string;
  initialValue?: TimeExtensionRequestVisitationSchemaI;
  timeExtensionVisitationType?: number;
  visitationId?: number;
  visitation?: any;
  timeExtensionRequestId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  isConfirmExtension?: boolean;
  name?: string;
  handleSubmit?: any;
  module?: number;
  sender?: any;
  createdBy?: any;
}

export const TimeExtensionVisitationForm = (
  props: TimeExtensionVisitationFormProps
) => {
  const {
    titlePopup,
    initialValue = initialEmptyValue,
    timeExtensionVisitationType,
    visitationId,
    visitation,
    timeExtensionRequestId,
    isOpen = false,
    setIsOpen,
    isConfirmExtension = false,
    name,
    handleSubmit,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
    createdBy,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const {
    data: getDataTimeExtensionVisitation,
    isLoading: isLoadingGetExtensionVisitation,
  } = useGetTimeExtensionVisitation({
    request: { visitationId, timeExtensionRequestId },
    config: {
      enabled: !!visitationId && !!timeExtensionRequestId && isConfirmExtension,
    },
  });

  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmExtension
        ? TimeExtensionRequestVisitationSchema.concat(
            ConfirmExtensionRequestVisitationSchema
          )
        : TimeExtensionRequestVisitationSchema
    ),
    defaultValues: initialValue,
  });

  const {
    mutateAsync: createTimeExtensionVisitation,
    isPending: isLoadingCreate,
  } = useCreateTimeExtensionVisitation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t(
              titlePopup ??
                `visitation.timeExtension.title.${
                  isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                }`
            ),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_sign_approve_tab"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_visitation_detail"],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
        });
        onCloseForm();
      },
    },
  });

  const {
    mutateAsync: updateTimeExtensionVisitation,
    isPending: isLoadingUpdateTimeExtension,
  } = useUpdateTimeExtensionVisitation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(
              titlePopup ??
                `visitation.timeExtension.title.${
                  isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                }`
            ),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_sign_approve_tab"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_visitation_detail"],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
        });
        onCloseForm();
      },
    },
  });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  useEffect(() => {
    if (isConfirmExtension && getDataTimeExtensionVisitation) {
      const { user, deadline, reason } = getDataTimeExtensionVisitation;

      form.reset({
        [TimeExtensionRequestVisitationFieldNames.CONFIRM]:
          ConfirmExtensionVisitationType.APPROVE,
        [TimeExtensionRequestVisitationFieldNames.DEADLINE]: moment
          .utc(deadline)
          .local()
          .toDate(),
        [TimeExtensionRequestVisitationFieldNames.REASON]: reason,
        [TimeExtensionRequestVisitationFieldNames.RECEIVER_USERS]: [user],
      });
    } else if (!isConfirmExtension) {
      form.reset({
        [TimeExtensionRequestVisitationFieldNames.RECEIVER_USERS]: [createdBy],
      });
    } else {
    }
  }, [form, isConfirmExtension, createdBy, getDataTimeExtensionVisitation]);

  const onSubmit = async (values: any) => {
    const receiverUsers =
      Array.isArray(values?.receiverUsers) && values?.receiverUsers.length
        ? [...values?.receiverUsers].map((item) => item?.id)
        : [];
    const isNewDeadline =
      values?.confirm === ConfirmExtensionVisitationType.NEW_DEADLINE;

    if (isConfirmExtension) {
      await updateTimeExtensionVisitation({
        visitationId,
        timeExtensionRequestId,
        data: {
          remind: values?.remind,
          receiverUsers,
          type: values?.confirm,
          ...(isNewDeadline && {
            deadlineAccept: values?.acceptableDeadline,
            reason: values?.acceptableReason,
          }),
        },
      });

      handleSubmit && handleSubmit();
      return;
    } else {
      await createTimeExtensionVisitation({
        visitationId,
        data: {
          type: timeExtensionVisitationType,
          deadline: values?.deadline,
          reason: values?.reason,
          remind: values?.remind,
        },
      });
    }
  };

  if (isLoadingGetExtensionVisitation) {
    return;
  }

  return (
    <ModalCommon
      title={t(
        titlePopup ??
          `visitation.timeExtension.title.${
            isConfirmExtension ? "titlePopup" : "titlePopupRequest"
          }`
      )}
      open={isOpen}
      onClose={onCloseForm}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.timeExtension.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.timeExtension.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              {isConfirmExtension && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    name={TimeExtensionRequestVisitationFieldNames.CONFIRM}
                    control={form.control}
                    items={ExtensionVisitationOptions.map((item) => {
                      return {
                        label: t(`${item?.label}`),
                        value: item?.value,
                      };
                    })}
                    error={
                      form.formState.errors[
                        TimeExtensionRequestVisitationFieldNames.CONFIRM
                      ] as FieldError
                    }
                    isNumber
                  />
                </Grid>
              )}

              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`visitation.timeExtension.title.confirmDeadline`)}
                </InputLabel>

                <TextField
                  value={
                    visitation?.confirmDeadline
                      ? new Date(
                          visitation?.confirmDeadline
                        ).toLocaleDateString(VIVN_INTL_LOCALE)
                      : ""
                  }
                  minRows={3}
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <DateRangeIcon />
                      </InputAdornment>
                    ),
                  }}
                  fullWidth
                  disabled
                />
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={TimeExtensionRequestVisitationFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`visitation.timeExtension.title.newDeadline2`)}
                  placeholder="dd/mm/yyyy"
                  minDate={new Date()}
                  maxDate={
                    (timeExtensionVisitationType ===
                      TimeExtensionVisitationType.CONFIRM_DEADLINE ||
                      timeExtensionVisitationType ===
                        TimeExtensionVisitationType.RESPONSE_LC_DEADLINE) &&
                    visitation?.receptionTimeFrom
                      ? moment(visitation?.receptionTimeFrom)
                          .subtract(1, "days")
                          .toDate()
                      : undefined
                  }
                  disabled={isConfirmExtension}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={TimeExtensionRequestVisitationFieldNames.REASON}
                  label={t(`visitation.timeExtension.title.reason`)}
                  placeHolder={t(`visitation.timeExtension.placeHolder.reason`)}
                  minRows={3}
                  disabled={isConfirmExtension}
                />
              </Grid>

              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={
                      TimeExtensionRequestVisitationFieldNames.RECEIVER_USERS
                    }
                    label={t("visitation.timeExtension.title.personDocument")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"timeExtensionDocumentManagement/queryUser"}
                    isFocus
                    required
                    disabled={!isConfirmExtension}
                  />
                </Grid>
              </Grid>

              {isConfirmExtension && (
                <Card
                  style={{
                    width: "100%",
                    padding: 15,
                    marginTop: 10,
                    marginBottom: 15,
                  }}
                >
                  <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                    <DateInput
                      name={
                        TimeExtensionRequestVisitationFieldNames.ACCEPTABLE_DEADLINE
                      }
                      control={form.control}
                      label={t(
                        `visitation.timeExtension.title.newDeadlineAccept`
                      )}
                      placeholder="dd/mm/yyyy"
                      required
                      disabled={
                        form?.watch(
                          TimeExtensionRequestVisitationFieldNames.CONFIRM
                        ) !== ConfirmExtensionVisitationType.NEW_DEADLINE
                      }
                    />
                  </Grid>

                  <Grid item width={"100%"} sx={{ mb: 1 }}>
                    <FormTextArea
                      control={form.control}
                      name={
                        TimeExtensionRequestVisitationFieldNames.ACCEPTABLE_DEADLINE_REASON
                      }
                      label={t(`visitation.timeExtension.title.reason`)}
                      placeHolder={t(
                        `visitation.timeExtension.placeHolder.reason`
                      )}
                      minRows={3}
                      required
                      disabled={
                        form?.watch(
                          TimeExtensionRequestVisitationFieldNames.CONFIRM
                        ) !== ConfirmExtensionVisitationType.NEW_DEADLINE
                      }
                    />
                  </Grid>
                </Card>
              )}
            </Grid>

            <ReminderPickerSubForm
              name={TimeExtensionRequestVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave={`common.button.${
                isConfirmExtension ? "confirm" : "send"
              }`}
              loading={
                isLoadingCreate ||
                isLoadingUpdateTimeExtension ||
                isLoadingGetExtensionVisitation
              }
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
