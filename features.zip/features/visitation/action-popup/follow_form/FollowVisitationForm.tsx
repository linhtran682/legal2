import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useEffect, useMemo, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  useCreateFollowVisitation,
  useGetFollowVisitationList,
  useUpdateFollowVisitation,
} from "@/apis/service/visitation/followVisitation";
import {
  FollowVisitationFieldNames,
  FollowVisitationSchemaI,
  FollowSchemaVisitation,
} from "@/models/visitation/FollowVisitation";
import { useQueryClient } from "@tanstack/react-query";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: FollowVisitationSchemaI = {
  [FollowVisitationFieldNames.DEADLINE]: "",
  [FollowVisitationFieldNames.CONTENT]: "",
  [FollowVisitationFieldNames.USER_IDS]: [],
  [FollowVisitationFieldNames.REMIND]: undefined,
};

export interface FollowVisitationFormProps {
  titlePopup?: string;
  initialValue?: FollowVisitationSchemaI;
  visitationId?: number;
  visitation?: any;
  followVisitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  createdBy?: any;
  sender?: any;
}

export const FollowVisitationForm = (props: FollowVisitationFormProps) => {
  const {
    titlePopup = "visitation.followVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    followVisitation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    createdBy,
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(FollowSchemaVisitation),
    defaultValues: initialValue,
  });

  const {
    data: getFollowVisitationList,
    isLoading: isLoadingGetFollowVisitationList,
  } = useGetFollowVisitationList({
    request: { visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  /**
   * Current follow visitation
   */
  const currentFollowVisitation = useMemo(() => {
    // When click to edit button, on detail page
    if (followVisitation?.id) {
      return followVisitation;
    }

    // When click button: "Kết quả tiếp đón"
    else {
      let followList = getFollowVisitationList?.data;
      followList =
        Array.isArray(followList) && followList.length ? [...followList] : [];

      const reversedFollowList = followList.reverse();
      const foundFollow = reversedFollowList.find(
        (item) => item?.createBy?.id === sender?.id
      );

      if (foundFollow) {
        return foundFollow;
      }
    }
  }, [sender, followVisitation, getFollowVisitationList]);

  /**
   * Set values to form
   */
  useEffect(() => {
    if (currentFollowVisitation?.id && visitation?.id) {
      let receiverUsers = currentFollowVisitation?.receiverUsers;
      receiverUsers =
        Array.isArray(receiverUsers) && receiverUsers.length
          ? [...receiverUsers]
          : [];

      form.reset({
        [FollowVisitationFieldNames.DEADLINE]:
          currentFollowVisitation?.deadline,
        [FollowVisitationFieldNames.CONTENT]: currentFollowVisitation?.content,
        [FollowVisitationFieldNames.USER_IDS]: receiverUsers,
      });
    }
  }, [form, createdBy, visitation, currentFollowVisitation]);

  const { mutateAsync: createFollowVisitation, isPending: isCreatePending } =
    useCreateFollowVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const { mutateAsync: updateFollowVisitation, isPending: isUpdateLoading } =
    useUpdateFollowVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const userIds =
      Array.isArray(values?.userIds) && values?.userIds.length
        ? [...values?.userIds].map((item) => item?.id)
        : [];

    const data = {
      ...values,
      userIds,
    };

    // Update follow
    if (currentFollowVisitation?.id) {
      await updateFollowVisitation({
        visitationId,
        followId: currentFollowVisitation?.id,
        data: {
          content: data.content,
        },
      });
    }

    // Update follow
    else {
      await createFollowVisitation({
        visitationId,
        data,
      });
    }
  };

  if (isLoadingGetFollowVisitationList) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.followVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.followVisitation.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={FollowVisitationFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`visitation.followVisitation.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  required
                  disabled={currentFollowVisitation?.id}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FollowVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.followVisitation.title.${FollowVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.followVisitation.placeHolder.${FollowVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={FollowVisitationFieldNames.USER_IDS}
                  label={t("visitation.followVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"followVisitation/queryUser"}
                  isFocus
                  required
                  disabled={currentFollowVisitation?.id}
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={FollowVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isCreatePending || isUpdateLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
