import { getUsers } from "@/apis/service/user/User";
import { sendMailVisitation } from "@/apis/service/visitation/sendMailVisitation";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { BasedUser } from "@/models/user/User";
import {
  SendMailVisitationFieldNames,
  SendMailVisitationRequestSchema,
} from "@/models/visitation/SendMailVisitation";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, InputLabel, Typography } from "@mui/material";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { FC, useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { VisitationTableConst } from "../../table/VisitationTable";
import { useGetEmailTemplate } from "@/apis/service/email_template/EmailTemplate";
import { Module, ModuleKeys } from "@/constants/general";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { EditorField } from "@/components/commons/EditorField/EditorField";

export interface SendMailVisitationFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  visitationId?: number;
  module?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  sender?: any;
}

const SendMailVisitationForm: FC<SendMailVisitationFormProps> = (props) => {
  const {
    titlePopup = "visitation.sendMail.title.titlePopup",
    isOpen = false,
    setIsOpen,
    name,
    visitationId,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
  } = props;
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: yupResolver(SendMailVisitationRequestSchema),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const { data: getEmailTemplate, isLoading: isLoadingGetEmailTemplate } =
    useGetEmailTemplate({
      request: {
        module,
        id: visitationId,
      },
      config: {
        enabled: !!visitationId,
      },
    });

  const sendMailQuery = useMutation({
    mutationFn: sendMailVisitation,
    onSuccess: () => {
      toast.success(t("visitation.messages.sendMailSuccess"));
      queryClient.invalidateQueries({
        queryKey: ["get_sign_approve_tab"],
      });
      queryClient.invalidateQueries({
        queryKey: ["get_initial_visitation_detail"],
      });
      queryClient.invalidateQueries({
        queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
      });
      queryClient.invalidateQueries({
        queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
      });
      onCloseForm(true);
    },
  });

  useEffect(() => {
    if (!getEmailTemplate) {
      return;
    }

    form.reset({
      [SendMailVisitationFieldNames.SUBJECT]: getEmailTemplate?.title,
      [SendMailVisitationFieldNames.CONTENT]: getEmailTemplate?.content,
    });
  }, [form, getEmailTemplate]);

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSave = () => {
    visitationId &&
      sendMailQuery.mutate({
        id: visitationId,
        request: {
          ...form.getValues(),
          receivers: form
            .getValues("receivers")
            ?.map((user: BasedUser) => user?.id),
        },
      });
  };

  if (isLoadingGetEmailTemplate) {
    return;
  }

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm(false)}
    >
      <Grid container className="form-wrapper">
        <FormProvider {...form}>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <Typography fontWeight="bold">
                    {t("visitation.label.requestName")}
                  </Typography>
                  <Typography>{name}</Typography>
                </FormControl>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t("visitation.label.sender")}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={SendMailVisitationFieldNames.SUBJECT}
                  label={t("visitation.label.subject")}
                  placeHolder={t("visitation.label.subject")}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <EditorField
                  control={form.control}
                  name="content"
                  label={t("visitation.label.contentMail")}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={SendMailVisitationFieldNames.RECEIVERS}
                  label={t("visitation.label.receiver")}
                  placeholder={t("visitation.label.receiver")}
                  getOptions={async (keyword) => {
                    const params: any = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);
                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option.department?.name ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryUser"
                  minCharLength={1}
                  isFocus
                  required
                />
              </Grid>
            </Grid>
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={sendMailQuery.isPending}
            onCancel={() => onCloseForm()}
            cancelConfirm={form.formState.isDirty}
            onSave={onSave}
          />
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};

export default SendMailVisitationForm;
