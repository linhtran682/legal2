import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import moment from "moment";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { useCreateRequestSignVisitation } from "@/apis/service/visitation/requestSignVisitation";
import {
  RequestSignFieldNames,
  RequestSignSchemaI,
  RequestSignSchemaVisitation,
} from "@/models/visitation/RequestSignVisitation";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQueryClient } from "@tanstack/react-query";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { VisitationTableConst } from "../../table/VisitationTable";
import { useGetSignApproveTab } from "@/apis/service/visitation/visitationApi";

const initialEmptyValue: RequestSignSchemaI = {
  [RequestSignFieldNames.DEADLINE]: "",
  [RequestSignFieldNames.CONTENT]: "",
  [RequestSignFieldNames.RECEIVER_USERS]: [],
  [RequestSignFieldNames.REMIND]: undefined,
};

export interface RequestSignVisitationFormProps {
  titlePopup?: string;
  initialValue?: RequestSignSchemaI;
  visitationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
}

export const RequestSignVisitationForm = (
  props: RequestSignVisitationFormProps
) => {
  const {
    titlePopup = "visitation.requestSignVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(RequestSignSchemaVisitation),
    defaultValues: initialValue,
  });

  const { data: signApproveData } = useGetSignApproveTab({
    request: { id: visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  /**
   * Set values to form
   */
  useEffect(() => {
    form.reset({
      [RequestSignFieldNames.DEADLINE]: signApproveData?.deadline
        ? moment.utc(signApproveData?.deadline).local().toDate()
        : null,
    });
  }, [form, signApproveData]);

  const { mutateAsync: createRequestSignVisitation, isPending } =
    useCreateRequestSignVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const receiverUsers =
      Array.isArray(values?.receiverUsers) && values?.receiverUsers.length
        ? [...values?.receiverUsers].map((item) => item?.id)
        : [];

    const data = {
      ...values,
      receiverUsers,
    };

    await createRequestSignVisitation({
      visitationId,
      data,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.requestSignVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.requestSignVisitation.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={RequestSignFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`visitation.requestSignVisitation.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestSignFieldNames.CONTENT}
                  label={t(
                    `visitation.requestSignVisitation.title.${RequestSignFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.requestSignVisitation.placeHolder.${RequestSignFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={RequestSignFieldNames.RECEIVER_USERS}
                  label={t("visitation.requestSignVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"requestSignVisitation/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={RequestSignFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
