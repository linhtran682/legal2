import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING, VIVN_INTL_LOCALE } from "@/constants/format";
import {
  Grid,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import { DateRangeIcon } from "@mui/x-date-pickers";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQueryClient } from "@tanstack/react-query";
import {
  SignSchemaVisitation,
  SignVisitationFieldNames,
  SignVisitationSchemaI,
} from "@/models/visitation/SignVisitation";
import { useCreateSignVisitation } from "@/apis/service/visitation/signVisitation";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { VisitationTableConst } from "../../table/VisitationTable";
import { useGetSignApproveTab } from "@/apis/service/visitation/visitationApi";

const initialEmptyValue: SignVisitationSchemaI = {
  [SignVisitationFieldNames.CONTENT]: "",
  [SignVisitationFieldNames.RECEIVER_USERS]: [],
  [SignVisitationFieldNames.REMIND]: undefined,
};

export interface SignVisitationFormProps {
  titlePopup?: string;
  initialValue?: SignVisitationSchemaI;
  visitationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  createdBy?: any;
}

export const SignVisitationForm = (props: SignVisitationFormProps) => {
  const {
    titlePopup = "visitation.signVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    createdBy,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(SignSchemaVisitation),
    defaultValues: initialValue,
  });

  const { data: signApproveData } = useGetSignApproveTab({
    request: { id: visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  const { mutateAsync: createSignVisitation, isPending: isCreateLoading } =
    useCreateSignVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  useEffect(() => {
    form.reset({
      [SignVisitationFieldNames.RECEIVER_USERS]: [createdBy],
    });
  }, [form, createdBy]);

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const receiverUsers =
      Array.isArray(values?.receiverUsers) && values?.receiverUsers.length
        ? [...values?.receiverUsers].map((item) => item?.id)
        : [];

    const data = { ...values, receiverUsers };

    await createSignVisitation({
      visitationId,
      data,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.signVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              {/* <Grid item width={"100%"}>
                <Typography fontWeight="bold" sx={{ mb: 1 }}>
                  {t(`visitation.signVisitation.title.informationRequired`)}
                </Typography>

                <Card
                  style={{
                    width: "100%",
                    padding: 15,
                    marginBottom: 15,
                  }}
                >
                  <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                    <InputLabel required>
                      {t(`visitation.signVisitation.title.requester`)}
                    </InputLabel>
                    <Typography>{`${requestSignVisitation?.createBy?.name} (${requestSignVisitation?.createBy?.email}) - ${requestSignVisitation?.createBy?.department?.name}`}</Typography>
                  </Grid>

                  <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                    <InputLabel required>
                      {t(`visitation.signVisitation.title.content`)}
                    </InputLabel>

                    <TextField
                      value={requestSignVisitation?.content}
                      minRows={3}
                      size="small"
                      InputLabelProps={{
                        shrink: true,
                      }}
                      multiline
                      fullWidth
                      disabled
                    />
                  </Grid>

                  <Grid item width={"100%"} sx={{ mb: 1 }}>
                    <InputLabel required>
                      {t(`visitation.signVisitation.title.deadline`)}
                    </InputLabel>

                    <TextField
                      value={
                        requestSignVisitation?.deadline
                          ? new Date(
                              requestSignVisitation?.deadline
                            ).toLocaleDateString(VIVN_INTL_LOCALE)
                          : ""
                      }
                      minRows={3}
                      size="small"
                      InputLabelProps={{
                        shrink: true,
                      }}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <DateRangeIcon />
                          </InputAdornment>
                        ),
                      }}
                      fullWidth
                      disabled
                    />
                  </Grid>
                </Card>
              </Grid> */}

              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`visitation.signVisitation.title.deadline`)}
                </InputLabel>

                <TextField
                  value={
                    signApproveData?.deadline
                      ? new Date(signApproveData?.deadline).toLocaleDateString(
                          VIVN_INTL_LOCALE
                        )
                      : ""
                  }
                  placeholder="dd/mm/yyyy"
                  minRows={3}
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <DateRangeIcon />
                      </InputAdornment>
                    ),
                  }}
                  fullWidth
                  disabled
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={SignVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.signVisitation.title.${SignVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.signVisitation.placeHolder.${SignVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={SignVisitationFieldNames.RECEIVER_USERS}
                  label={t("visitation.signVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"feedbackVisitation/queryUser"}
                  isFocus
                  required
                  disabled
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={SignVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isCreateLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
