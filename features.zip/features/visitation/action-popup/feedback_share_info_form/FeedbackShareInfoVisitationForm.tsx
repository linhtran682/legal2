import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import moment from "moment";
import {
  Card,
  Grid,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useMemo, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateRangeIcon from "@mui/icons-material/DateRange";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useQueryClient } from "@tanstack/react-query";
import {
  FeedbackShareInfoSchemaVisitation,
  FeedbackShareInfoVisitationFieldNames,
  FeedbackShareInfoVisitationSchemaI,
} from "@/models/visitation/FeedbackShareInfoVisitation";
import {
  useCreateFeedbackShareInfoVisitation,
  useGetFeedbackShareInfoList,
  useGetShareInfoRequest,
  useUpdateFeedbackShareInfoVisitation,
} from "@/apis/service/visitation/feedbackShareInfoVisitation";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: FeedbackShareInfoVisitationSchemaI = {
  [FeedbackShareInfoVisitationFieldNames.CONTENT]: "",
  [FeedbackShareInfoVisitationFieldNames.RECEIVER_USERS]: [],
  [FeedbackShareInfoVisitationFieldNames.REMIND]: undefined,
};

export interface FeedbackShareInfoVisitationFormProps {
  titlePopup?: string;
  initialValue?: FeedbackShareInfoVisitationSchemaI;
  visitationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  sender?: any;
}

export const FeedbackShareInfoVisitationForm = (
  props: FeedbackShareInfoVisitationFormProps
) => {
  const {
    titlePopup = "visitation.feedbackShareInfo.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(FeedbackShareInfoSchemaVisitation),
    defaultValues: initialValue,
  });

  const { data: getShareInfoRequest, isLoading: isLoadingGetShareInfoRequest } =
    useGetShareInfoRequest({
      request: { visitationId },
      config: {
        enabled: !!visitationId,
      },
    });

  const {
    data: getFeedbackShareInfoList,
    isLoading: isLoadingGetFeedbackShareInfoList,
  } = useGetFeedbackShareInfoList({
    request: { visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  /**
   * Current feedback share info
   */
  const currentFeedbackShareInfo = useMemo(() => {
    // When click button: "Phản hồi chia sẻ"
    let feedbackShareInfoList = getFeedbackShareInfoList?.data;
    feedbackShareInfoList =
      Array.isArray(feedbackShareInfoList) && feedbackShareInfoList.length
        ? [...feedbackShareInfoList]
        : [];

    const reversedFeedbackShareInfoList = feedbackShareInfoList.reverse();
    const foundFeedback = reversedFeedbackShareInfoList.find(
      (item) => item?.createBy?.id === sender?.id
    );

    if (foundFeedback) {
      return foundFeedback;
    }
  }, [sender, getFeedbackShareInfoList]);

  useEffect(() => {
    if (currentFeedbackShareInfo?.createBy?.id) {
      let newUsers = currentFeedbackShareInfo?.receiverUsers;
      newUsers =
        Array.isArray(newUsers) && newUsers.length ? [...newUsers] : [];

      form.reset({
        [FeedbackShareInfoVisitationFieldNames.CONTENT]:
          currentFeedbackShareInfo?.content,
        [FeedbackShareInfoVisitationFieldNames.RECEIVER_USERS]: newUsers,
      });
    } else if (getShareInfoRequest?.createBy?.id) {
      const createBy = getShareInfoRequest?.createBy;

      form.reset({
        [FeedbackShareInfoVisitationFieldNames.RECEIVER_USERS]: [createBy],
      });
    } else {
    }
  }, [form, currentFeedbackShareInfo, getShareInfoRequest]);

  const {
    mutateAsync: createFeedbackShareInfoVisitation,
    isPending: isCreateLoading,
  } = useCreateFeedbackShareInfoVisitation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t(titlePopup),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_sign_approve_tab"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_visitation_detail"],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
        });
        onCloseForm();
      },
    },
  });

  const {
    mutateAsync: updateFeedbackShareInfoVisitation,
    isPending: isUpdateLoading,
  } = useUpdateFeedbackShareInfoVisitation({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(titlePopup),
          })
        );
        queryClient.invalidateQueries({
          queryKey: ["get_sign_approve_tab"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_visitation_detail"],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
        });
        onCloseForm();
      },
    },
  });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const receiverUsers =
      Array.isArray(values?.receiverUsers) && values?.receiverUsers.length
        ? [...values?.receiverUsers].map((item) => item?.id)
        : [];

    const data = { ...values, receiverUsers };

    // Update
    if (currentFeedbackShareInfo?.createBy?.id) {
      await updateFeedbackShareInfoVisitation({
        visitationId,
        shareId: currentFeedbackShareInfo?.id,
        data,
      });
    }

    // Create
    else {
      await createFeedbackShareInfoVisitation({
        visitationId,
        data,
      });
    }
  };

  if (isLoadingGetShareInfoRequest || isLoadingGetFeedbackShareInfoList) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.feedbackShareInfo.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.feedbackShareInfo.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              {getShareInfoRequest?.createBy?.id && (
                <Grid item width={"100%"}>
                  <Typography fontWeight="bold" sx={{ mb: 1 }}>
                    {t(
                      `visitation.feedbackShareInfo.title.informationRequired`
                    )}
                  </Typography>

                  <Card
                    style={{ width: "100%", padding: 15, marginBottom: 15 }}
                  >
                    <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                      <InputLabel>
                        {t(`visitation.feedbackShareInfo.title.requester`)}
                      </InputLabel>
                      <Typography>{`${getShareInfoRequest?.createBy?.name} (${getShareInfoRequest?.createBy?.email}) - ${getShareInfoRequest?.createBy?.department?.name}`}</Typography>
                    </Grid>

                    <Grid item width={"100%"} sx={{ mb: 2.5 }}>
                      <InputLabel>
                        {t(`visitation.feedbackShareInfo.title.content2`)}
                      </InputLabel>

                      <TextField
                        value={getShareInfoRequest?.content}
                        minRows={3}
                        size="small"
                        InputLabelProps={{
                          shrink: true,
                        }}
                        multiline
                        fullWidth
                        disabled
                      />
                    </Grid>

                    <Grid item width={"100%"} sx={{ mb: 1 }}>
                      <InputLabel>
                        {t(`visitation.feedbackShareInfo.title.deadline`)}
                      </InputLabel>

                      <TextField
                        value={
                          getShareInfoRequest?.deadline
                            ? moment
                                .utc(getShareInfoRequest?.deadline)
                                .local()
                                .format("DD/MM/YYYY hh:mm")
                            : ""
                        }
                        minRows={3}
                        size="small"
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <DateRangeIcon />
                            </InputAdornment>
                          ),
                        }}
                        fullWidth
                        disabled
                      />
                    </Grid>
                  </Card>
                </Grid>
              )}

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedbackShareInfoVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.feedbackShareInfo.title.${FeedbackShareInfoVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.feedbackShareInfo.placeHolder.${FeedbackShareInfoVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={FeedbackShareInfoVisitationFieldNames.RECEIVER_USERS}
                  label={t("visitation.feedbackShareInfo.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"feedbackVisitation/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={FeedbackShareInfoVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isCreateLoading || isUpdateLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
