import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, InputLabel, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { Module, ModuleKeys } from "@/constants/general";
import {
  castFeedBackVisitationRequestSchemaToDTO,
  FeedbackVisitationFieldNames,
  FeedbackVisitationSchema,
  FeedbackVisitationSchemaI,
} from "@/models/visitation/FeedBackVisitation";
import { useCreateFeedbackVisitation } from "@/apis/service/visitation/feedbackVisitation";
import { useQueryClient } from "@tanstack/react-query";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: FeedbackVisitationSchemaI = {
  [FeedbackVisitationFieldNames.USERS]: [],
  [FeedbackVisitationFieldNames.DEADLINE]: "",
  [FeedbackVisitationFieldNames.CONTENT]: "",
  [FeedbackVisitationFieldNames.REMIND]: undefined,
};

export interface FeedBackVisitationFormProps {
  titlePopup?: string;
  initialValue?: FeedbackVisitationSchemaI;
  visitationId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  minDateReturnAdvice?: Date | undefined;
  sender?: any;
}

export const FeedBackVisitationForm = (props: FeedBackVisitationFormProps) => {
  const {
    titlePopup = "visitation.feedbackVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    minDateReturnAdvice = undefined,
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(FeedbackVisitationSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createFeedbackVisitation, isPending } =
    useCreateFeedbackVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { ...restData } = data;
    await createFeedbackVisitation({
      visitationId,
      data: restData,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.feedbackVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.feedbackVisitation.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={FeedbackVisitationFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`visitation.feedbackVisitation.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  minDate={minDateReturnAdvice}
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedbackVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.feedbackVisitation.title.${FeedbackVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.feedbackVisitation.placeHolder.${FeedbackVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={FeedbackVisitationFieldNames.USERS}
                  label={t("visitation.feedbackVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"feedbackVisitation/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={FeedbackVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedBackVisitationRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
