import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import moment from "moment";
import {
  Grid,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { Module, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  useCreateConfirmVisitation,
  useGetConfirmVisitationList,
  useUpdateConfirmVisitation,
} from "@/apis/service/visitation/confirmVisitation";
import {
  ConfirmVisitationFieldNames,
  ConfirmVisitationSchemaI,
  ConfirmSchemaVisitation,
  FileInfo,
  castConfirmVisitationSchemaToDTO,
  ConfirmVisitationOptions,
} from "@/models/visitation/ConfirmVisitation";
import { useQueryClient } from "@tanstack/react-query";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { DateRangeIcon } from "@mui/x-date-pickers";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { VisitationStatusCode } from "@/constants/visitation";
import { VisitationTableConst } from "../../table/VisitationTable";

const initialEmptyValue: ConfirmVisitationSchemaI = {
  [ConfirmVisitationFieldNames.IS_CONFIRM]: true,
  [ConfirmVisitationFieldNames.CONTENT]: "",
  [ConfirmVisitationFieldNames.RECEIVER_USERS]: [],
  [ConfirmVisitationFieldNames.REMIND]: undefined,
};

export interface ConfirmVisitationFormProps {
  titlePopup?: string;
  initialValue?: ConfirmVisitationSchemaI;
  visitationId?: number;
  visitation?: any;
  confirmVisitation?: any;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  name?: string;
  module?: number;
  createdBy?: any;
  sender?: any;
}

export const ConfirmVisitationForm = (props: ConfirmVisitationFormProps) => {
  const {
    titlePopup = "visitation.confirmVisitation.title.titlePopup",
    initialValue = initialEmptyValue,
    visitationId,
    visitation,
    confirmVisitation,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.VISITATION),
    createdBy,
    sender,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();

  const form = useForm<any>({
    resolver: yupResolver(ConfirmSchemaVisitation),
    defaultValues: initialValue,
  });
  const [files, setFiles] = useState<any>([]);

  const {
    data: getConfirmVisitationList,
    isLoading: isLoadingGetConfirmVisitationList,
  } = useGetConfirmVisitationList({
    request: { visitationId },
    config: {
      enabled: !!visitationId,
    },
  });

  /**
   * Current confirm visitation
   */
  const currentConfirmVisitation = useMemo(() => {
    // When click to edit button, on detail page
    if (confirmVisitation?.id) {
      return confirmVisitation;
    }

    // When click button: "Xác nhận"
    else {
      let confirmList = getConfirmVisitationList?.data;
      confirmList =
        Array.isArray(confirmList) && confirmList.length
          ? [...confirmList]
          : [];

      const reversedConfirmList = confirmList.reverse();
      const foundConfirm = reversedConfirmList.find(
        (item) => item?.createBy?.id === sender?.id
      );

      if (foundConfirm) {
        return foundConfirm;
      }
    }
  }, [sender, confirmVisitation, getConfirmVisitationList]);

  /**
   * Is updating
   */
  const isUpdating = useMemo(() => {
    return currentConfirmVisitation?.id && visitation?.id;
  }, [currentConfirmVisitation, visitation]);

  /**
   * Set values to form
   */
  useEffect(() => {
    if (isUpdating) {
      let receiverUsers = currentConfirmVisitation?.receiverUsers;
      receiverUsers =
        Array.isArray(receiverUsers) && receiverUsers.length
          ? [...receiverUsers]
          : [];

      form.reset({
        [ConfirmVisitationFieldNames.IS_CONFIRM]:
          visitation?.status?.code !== VisitationStatusCode.CONFIRM_REJECT,
        [ConfirmVisitationFieldNames.CONTENT]:
          currentConfirmVisitation?.content,
        [ConfirmVisitationFieldNames.RECEIVER_USERS]: receiverUsers,
      });

      if (
        Array.isArray(currentConfirmVisitation?.attachments) &&
        currentConfirmVisitation?.attachments.length
      ) {
        setFiles(
          currentConfirmVisitation.attachments?.map((item: any) => {
            return {
              name: item?.fileName,
              path: item?.filePath,
              id: item?.fileId,
              uploadDate: item?.uploadDate,
            };
          })
        );
      }
    } else {
      form.reset({
        [ConfirmVisitationFieldNames.IS_CONFIRM]: true,
        [ConfirmVisitationFieldNames.RECEIVER_USERS]: [createdBy],
      });
    }
  }, [
    form,
    sender,
    createdBy,
    visitation,
    currentConfirmVisitation,
    isUpdating,
  ]);

  const { mutateAsync: createConfirmVisitation, isPending: isCreatePending } =
    useCreateConfirmVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const { mutateAsync: updateConfirmVisitation, isPending: isUpdateLoading } =
    useUpdateConfirmVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
          onCloseForm();
        },
      },
    });

  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({});
  };

  const onSubmit = async (values: any) => {
    const receiverUsers =
      Array.isArray(values?.receiverUsers) && values?.receiverUsers.length
        ? [...values?.receiverUsers].map((item) => item?.id)
        : [];

    const data = {
      ...values,
      isConfirm: values?.isConfirm === "true" || values?.isConfirm === true,
      receiverUsers,
    };

    // Update
    if (isUpdating) {
      await updateConfirmVisitation({
        visitationId,
        confirmId: currentConfirmVisitation?.id,
        data: {
          content: data.content,
          attachmentIds: data.attachmentIds,
        },
      });
    }

    // Update
    else {
      await createConfirmVisitation({
        visitationId,
        data,
      });
    }
  };

  if (isLoadingGetConfirmVisitationList) {
    return;
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("visitation.confirmVisitation.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel sx={{ padding: 0 }}>
                  {t(`visitation.confirmVisitation.title.sender`)}
                </InputLabel>
                {sender && (
                  <Typography>
                    {sender?.name} ({sender?.email}) -{" "}
                    {sender?.department?.name}
                  </Typography>
                )}
              </Grid>

              <Grid item width={"100%"}>
                <RadioGroupField
                  name={ConfirmVisitationFieldNames.IS_CONFIRM}
                  control={form.control}
                  items={ConfirmVisitationOptions.map((item) => {
                    return {
                      label: t(`${item?.label}`),
                      value: item?.value,
                    };
                  })}
                  error={
                    form.formState.errors[
                      ConfirmVisitationFieldNames.IS_CONFIRM
                    ] as FieldError
                  }
                  isDisabled={isUpdating}
                />
              </Grid>

              <Grid item width={"100%"}>
                <InputLabel>
                  {t(`visitation.confirmVisitation.title.confirmDeadline`)}
                </InputLabel>

                <TextField
                  value={
                    visitation?.confirmDeadline
                      ? moment
                          .utc(visitation?.confirmDeadline)
                          .local()
                          .format("DD/MM/YYYY hh:mm")
                      : ""
                  }
                  minRows={3}
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <DateRangeIcon />
                      </InputAdornment>
                    ),
                  }}
                  fullWidth
                  disabled
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ConfirmVisitationFieldNames.CONTENT}
                  label={t(
                    `visitation.confirmVisitation.title.${ConfirmVisitationFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `visitation.confirmVisitation.placeHolder.${ConfirmVisitationFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView
                  preview={false}
                  files={files}
                  setFiles={setFiles}
                  title={t(`visitation.confirmVisitation.title.attachments`)}
                  inputId="advisorFollowVisitation"
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ConfirmVisitationFieldNames.RECEIVER_USERS}
                  label={t("visitation.confirmVisitation.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"confirmVisitation/queryUser"}
                  isFocus
                  required
                  disabled={isUpdating}
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ConfirmVisitationFieldNames.REMIND}
              module={module}
            />

            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isCreatePending || isUpdateLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit(
                    castConfirmVisitationSchemaToDTO({
                      ...form.getValues(),
                      attachmentIds: attachments,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
