import { Grid } from "@mui/material";
import { ReactNode, useState } from "react";
import { GenericSearchPanel } from "@/components/commons/search_panel/GenericSearchPanel";
import { EmptyIndicator } from "@/components/commons/empty_idicator/EmptyIndicator";
import { visitationSearchPanelConfig } from "@/models/visitation/VisitationDetail";

export interface LegalDocumentLayoutProps {
  children: ReactNode | ReactNode[];
}

export const VisitationLayout = (props: LegalDocumentLayoutProps) => {
  const [isResultSearchPanel, setIsResultSearchPanel] = useState(true);
  const handleSetResultSearchPanel = (value: boolean) => {
    setIsResultSearchPanel(value);
  };
  return (
    <Grid
      direction={"row"}
      wrap="nowrap"
      sx={{ display: "flex", overflow: "hidden", height: "100%" }}
    >
      <Grid
        item
        sx={{ overflow: "auto", height: "100%", position: "relative" }}
      >
        <GenericSearchPanel<any>
          {...visitationSearchPanelConfig}
          setIsResultSearchPanel={handleSetResultSearchPanel}
        />
      </Grid>
      <Grid
        item
        flex={1}
        style={{
          maxWidth: "100%",
          transition: "max-width 0.2s ease",
          overflow: "auto",
          position: "relative",
        }}
      >
        {!isResultSearchPanel ? (
          <EmptyIndicator bgColor="white" />
        ) : (
          props.children
        )}
      </Grid>
    </Grid>
  );
};
