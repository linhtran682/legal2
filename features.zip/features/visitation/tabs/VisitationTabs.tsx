import { uploadDocumentTabAttachments } from "@/apis/service/files_upload/files";
import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { TabNav } from "@/components/commons/tab-nav/TabNav";
import { UploadPanel } from "@/components/commons/upload/upload_panel/UploadPanel";
import { COLOR_TYPE } from "@/constants/color";
import { AppContext } from "@/context/AppContext";
import { GenericContentPanel } from "@/features/metadata_tab_panel/generic_content_panel/GenericContentPanel";
import { InformationRequestPanel } from "@/features/metadata_tab_panel/information_request_panel/InformationRequestPanel";
import { LANGUAGES } from "@/locales/config-translation";
import { getUserLabel } from "@/utils";
import { ForwardedRef, forwardRef, useContext, useImperativeHandle, useState } from "react";
import { useTranslation } from "react-i18next";

import { VisitationEvaluationPanel } from "../metadata/evaluation_panel/VisitationEvaluationPanel";
import { VisitationSignPanel } from "../metadata/confirm_panel/VisitationSignPanel";
import { VisitationExtendPanel } from "../metadata/extend-panel/VisitationExtendPanel";
import { VisitationFeedbackPanel } from "../metadata/feedback-panel/VisitationFeedbackPanel";
import { VisitationAssignment, VisitationBodyReceive, VisitationForward, VisitationRequestFeedback, VisitationRoles, VisitationTabsRef } from "@/models/visitation/VisitationDetail";
import {
  getVisitationInformationRequests,
  getVisitationEvaluate,
  getVisitationForwards,
  getVisitationExtensions,
  getVisitationRequestFeedback,
  getVisitationHistory,
  getVisitationSignTab,
  getVisitationShareInformationTab,
  getVisitationAttachmentsTab,
  getVisitationCommentTab,
  commentVisitation,
  createVisitationMeeting,
  deleteVisitationMeeting,
  getVisitationMeeting,
  updateVisitationMeeting,
  getVisitationAssignments
} from "@/apis/service/visitation/visitationApi";
import { VisitationHistoryPanel } from "../metadata/history-panel/VisitationHistoryPanel";
import { VisitationShareInformationPanel } from "../metadata/share-information-panel/VisitationShareInformationPanel";
import { CommentPanel } from "@/features/metadata_tab_panel/comment_panel/CommentPanel";
import { MeetingPanel } from "@/features/metadata_tab_panel/meeting_panel/MeetingPanel";
import { useQueryClient } from "@tanstack/react-query";


export interface Props {
  visitationId: number;
  visitation?: VisitationBodyReceive;
  loading?: boolean;
  containerHeight: number;
  ownRole?: number[];
}

const VIEW_ID = "visitation-tabs";

const VisitationTabs = forwardRef(function VisitationTabs(
  props: Props,
  ref: ForwardedRef<VisitationTabsRef>
) {
  const { visitationId, visitation, containerHeight, ownRole = [] } = props;
  const { t, i18n } = useTranslation();
  const [activeIndex, setActiveIndex] = useState(0);
  const appContext = useContext(AppContext);
  const { loading } = props;
  const isEnglish = i18n.language === LANGUAGES.ENGLISH;
  const queryClient = useQueryClient();
  
  const reloadDetail = () => queryClient.invalidateQueries({
    queryKey: ["get_initial_visitation_detail"],
  })

  const scrollToTab = (tab: number) => {
    setActiveIndex(tab);
    const tabElement = document.getElementById(VIEW_ID);
    setTimeout(() => tabElement?.scrollIntoView({
      behavior: 'smooth',
    }), 400)
  }

  useImperativeHandle(ref, () => ({
    scrollToTab: (tab: number) => scrollToTab(tab)
  }))
  
  return (
    <LoadingWrapper loading={loading || appContext.loading}>
      <div id={VIEW_ID} style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
        <TabNav
          index={activeIndex}
          onChangeTabIndex={setActiveIndex}
          tabItems={[
            // 1. Yêu cầu bổ sung thông tin
            {
              key: "information-request",
              label: t("metadata.informationRequest.title"),
              content: (
                <InformationRequestPanel
                  queryKey="visitation-information-request"
                  getInformationRequests={async () => {
                    return (
                      (
                        await getVisitationInformationRequests(
                          visitationId
                        )
                      )?.result?.data?.map(
                        (ele, index: number) => ({
                          ...ele,
                          id: index + 1,
                        })
                      ) ?? []
                    );
                  }}
                />
              ),
            },

            // 2. Phân công
            {
              key: 'assignment',
              label: t('visitation.tabs.assignment'),
              content: (
                <GenericContentPanel<VisitationAssignment>
                  getData={async () => {
                    return (
                      (await getVisitationAssignments(props.visitationId))
                        ?.assignmentResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) => getUserLabel(item.assignUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('visitation.tabs.assignTo')}:  ${item?.receiveUsers?.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='visitation.tabs.assignmentContent'
                  getContent={(item) => item.content}
                  queryKey={`visitation-assignment-${props.visitationId}`}
                />
              )
            },
            // 2. Gia hạn thời gian
            {
              key: "extend",
              label: t("metadata.extend.title"),
              content: (
                <VisitationExtendPanel
                  visitationId={visitationId}
                  visitation={visitation}
                  getExtendRecords={async () => {
                    return (
                      (
                        await getVisitationExtensions(
                          visitationId
                        )
                      )?.timeExtensionResponseDetails ?? []
                    );
                  }}
                  queryKey="visitation-extend-tab"
                />
              ),
            },

            // 3. Đánh giá
            {
              key: "evaluation",
              label: t("metadata.evaluation.title"),
              content: (
                <VisitationEvaluationPanel
                  queryKey="visitation-evaluation"
                  getEvaluations={async () =>
                    (await getVisitationEvaluate(visitationId)).result?.data ?? []
                  }
                />
              ),
            },
            // 4. Ký Duyệt
            {
              key: "sign",
              label: t("metadata.confirm.title"),
              content: (
                <VisitationSignPanel
                  queryKey="visitation-sign"
                  getConfirmRecords={async () =>
                    (await getVisitationSignTab(visitationId))
                      .result?.data ?? []
                  }
                />
              ),
            },
            // 5. Chia sẻ
            {
              key: "sign",
              label: t("visitation.label.share"),
              content: (
                <VisitationShareInformationPanel
                  queryKey="visitation-share-information"
                  getShareInformation={async () =>
                    (await getVisitationShareInformationTab(visitationId))
                      .result?.data ?? []
                  }
                />
              ),
            },
            // 6. Đính kèm
            {
              key: "attachment",
              label: t("metadata.attachment.title"),
              content: (
                <UploadPanel
                  queryKey="visitation-upload"
                  onGetFiles={async () =>
                    (
                      (await getVisitationAttachmentsTab(visitationId))
                        ?.data || []
                    ).map((attachment) => ({
                      fileId: attachment.fileId,
                      fileName: attachment.fileName,
                      storagePath: attachment.filePath,
                      uploadDate: attachment.uploadDate,
                    }))
                  }
                  onDelete={() => Promise.resolve()}
                  onUpload={async (files) => {
                    await uploadDocumentTabAttachments({
                      files: files,
                      id: visitationId,
                      reference_file_type: 4,
                    });
                  }}
                  disabled
                />
              ),
            },
            // 7. Chuyển tiếp
            {
              key: "forward",
              label: t("metadata.forward.title"),
              content: (
                <GenericContentPanel<VisitationForward>
                  getData={async () => {
                    return (
                      (
                        await getVisitationForwards(
                          visitationId
                        )
                      )?.forwardResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) => getUserLabel(item.forwardUser, isEnglish)}
                  getDisplayDate={(item) => item.forwardDate}
                  getSubtitle={(item) =>
                    `${t("visitation.tabs.forwardedTo")}:  ${item?.receiveUsers
                      ?.map((user) => getUserLabel(user, isEnglish))
                      .join(", ")}`
                  }
                  contentHeader="visitation.forward.title.content"
                  getContent={(item) => item.content}
                  queryKey="visitation-forward"
                />
              ),
            },
            
            // 8. Phản hồi văn bản
            {
              key: "visitation-request-feedback",
              label: t("visitation.tabs.documentFeedback"),
              content: (
                <VisitationFeedbackPanel<VisitationRequestFeedback>
                  getData={async () => {
                    return (
                      (
                        await getVisitationRequestFeedback(
                          visitationId
                        )
                      )?.feedbackResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) =>
                    getUserLabel(item.feedbackUser, isEnglish)
                  }
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) =>
                    `${t("visitation.tabs.feedbackTo")}: ${item.receiveUsers
                      .map((user) => getUserLabel(user, isEnglish))
                      .join(", ")}`
                  }
                  contentHeader="visitation.tabs.feedbackContent"
                  getContent={(item) => item.content}
                  queryKey="visitation-request-feedback"
                />
              ),
            },
            // 8. Book lịch họp
            {
              key: "meeting",
              label: t("metadata.meeting.tab"),
              content: (
                <MeetingPanel
                  containerHeight={containerHeight}
                  queryKey={`visitation-meeting-${visitationId}`}
                  reloadDetail={reloadDetail}
                  updateMeeting={(data) => updateVisitationMeeting({
                    id: visitationId,
                    content: data.content,
                    meetingId: data.meetingId
                  })
                  }
                  deleteMeeting={(meetingId) => deleteVisitationMeeting({
                    id: visitationId,
                    meetingId: meetingId
                  })}
                  getMeetings={async () => {
                    return (
                      (await getVisitationMeeting(visitationId))
                        .result?.meetingResponses ?? []
                    );
                  }}
                  addMeeting={(content) =>
                    createVisitationMeeting({
                      id: visitationId,
                      content: content,
                    })
                  }
                  disabled={
                    !appContext.meCanRead
                    || (!ownRole.includes(VisitationRoles.PIC)
                      && !ownRole.includes(VisitationRoles.LC)
                      && !ownRole.includes(VisitationRoles.EVALUATION))
                  }
                />
              ),
            },
            // 10. Bình luận
            {
              key: "comment",
              label: t("metadata.comment.title"),
              content: (
                <CommentPanel
                  queryKey="violation-comment"
                  getComments={async () => {
                    return (
                      (await getVisitationCommentTab(visitationId))
                        .result?.data ?? []
                    );
                  }}
                  addComment={(comment) =>
                    commentVisitation({
                      id: visitationId,
                      content: comment,
                    })
                  }
                  disabled={
                    !appContext.meCanRead ||
                    visitation?.actionAvailableAndRole.roles.length === 0
                  }
                />
              ),
            },
            // 9. Lịch sử
            {
              key: "history",
              label: t("metadata.history.title"),
              content: (
                <VisitationHistoryPanel
                  queryKey="visitation-history"
                  getHistoryRecords={async () => {
                    return (
                      (await getVisitationHistory(visitationId))
                        .result?.data ?? []
                    );
                  }}
                />
              ),
            },
          ]}
        />
      </div>
    </LoadingWrapper>
  );
});

export default VisitationTabs;
