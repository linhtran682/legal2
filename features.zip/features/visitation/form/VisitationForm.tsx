import {
  getDepartmentHeads,
  getDepartments,
  getLegalDepartments,
} from "@/apis/service/department/department";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { getUser, getUsers } from "@/apis/service/user/User";
import { getDepartmentHeadsVisitation, uploadCurrentFileToSharepoint, uploadFileToVisitationSign, useGetVisitationStatus } from "@/apis/service/visitation/visitationApi";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import DropPreviewFileUploadComponent, { FileDetails } from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { COLOR_TYPE } from "@/constants/color";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { GLOBAL_SPACING } from "@/constants/format";
import { ModuleFields } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { VisitationStatusCode } from "@/constants/visitation";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { LANGUAGES } from "@/locales/config-translation";
import { Department } from "@/models/department/Department";
import { FileInfo } from "@/models/law_document/LawDocument";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { StatusFieldNames } from "@/models/status/Status";
import { GetUsersParams, UserProfileDTO } from "@/models/user/User";
import {
  SaveVisitationSchema,
  SpPermissionVisitationTypes,
  TypeVisitationForm,
  VisitationBodyReceive,
  VisitationBodySend,
  VisitationDetailFields,
} from "@/models/visitation/VisitationDetail";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  FormHelperText,
  Grid,
  Stack,
  Typography,
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import {
  FC,
  ReactNode,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import EvaluatedFeedback from "./block/EvaluatedFeedback";
import ReceptionResult from "./block/ReceptionResult";
import ConfirmInfomation from "./block/ConfirmInfomation";
import EvaluatedLegalDepartment from "./block/EvaluatedLegalDepartment";
import FollowInformation from "./block/FollowInformation";
import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";
import { toast } from "react-toastify";
import { getAssignedPerson } from "@/apis/service/assignment/Assignment";
import { cookieSetting } from "@/utils";

export interface Props {
  formMode?: "create" | "update";
  onSubmit: (data: VisitationBodySend) => void;
  onSubmitDraft?: (data: VisitationBodySend) => void;
  initialValue?: VisitationBodyReceive;
  checkSharepointPermission?: SpPermissionVisitationTypes;
  onCancel: () => void;
  loading?: boolean;
  defaultValues?: TypeVisitationForm;
  children?: ReactNode;
  ownRole?: number[];
  visitationId?: string;
}

const initialEmptyValue = {
  legalAccessType: 2,
  checkDeptHeadFlag: true,
  checkDivisionFlag: true,
};

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}
const VisitationForm: FC<Props> = (props) => {
  const {
    formMode,
    onSubmit,
    onSubmitDraft,
    onCancel,
    loading,
    defaultValues,
    initialValue,
    ownRole = [],
    checkSharepointPermission,
    visitationId = "",
  } = props;

  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);
  const { i18n, t } = useTranslation();
  const appContext = useContext(AppContext);
  const [selectionSharePoint, setSelectionSharePoint] = useState<number[]>([]);
  const [selectionFilesSharePoint, setSelectionFilesSharePoint] = useState<FileDetails[]>([]);
  const [originalSharepointFileIds, setOriginalSharepointFileIds] = useState<number[]>([]);
  const accessToken = cookieSetting.get("ACCESS_TOKEN");

  const enabledEdit = useMemo(
    () =>
      (appContext.meCanWrite && formMode === "create") ||
      (ownRole.includes(1) &&
        (initialValue?.isDraft ||
          initialValue?.status?.code ===
            VisitationStatusCode.INFORMATION_REQUEST ||
          initialValue?.status?.code === VisitationStatusCode.CONFIRM_REJECT ||
          initialValue?.status?.code ===
            VisitationStatusCode.EVALUATE_FEEDBACK_REJECT)),
    [
      appContext.meCanWrite,
      formMode,
      initialValue?.isDraft,
      initialValue?.status?.code,
      ownRole,
    ]
  );


  const form = useForm<any>({
    resolver: yupResolver(SaveVisitationSchema),
    defaultValues: { ...defaultValues, ...initialEmptyValue },
    mode: "onBlur",
    disabled: !enabledEdit,
  });

  useEffect(() => {
    let attachmentFiles: any[] = [];
    let sharePointFiles: FileDetails[] = [];
    
    if (initialValue?.attachmentFiles) {

      if (initialValue?.attachmentFiles.length) {
        attachmentFiles = initialValue?.attachmentFiles?.map((item: any) => {
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        });
      }
      
    }

    if (initialValue?.sharePointAttachmentFiles?.length) {
      sharePointFiles = [...(initialValue?.sharePointAttachmentFiles ?? [])?.map((item) => {
        return {
          ...item,
          name: item.fileName,
          path: item.sharePointLink,
          id: item.id,
          // uploadDate: item.uploadDate,
        };
      })];
      attachmentFiles = [...attachmentFiles, ...sharePointFiles];

      const sharePointIds = initialValue?.sharePointAttachmentFiles?.map(file => file.id) ?? [];
      setOriginalSharepointFileIds(sharePointIds);
      setSelectionSharePoint(sharePointIds);
    } else {
      setOriginalSharepointFileIds([]);
      setSelectionSharePoint([]);
    }

    setFiles(attachmentFiles);
  }, [initialValue]);

  useEffect(() => {
    defaultValues && form.reset(defaultValues);
  }, [defaultValues, form])
  

  const { data: statusList } = useGetVisitationStatus({
    request: {
      modules: [ModuleFields.VISITATION_NAME.module],
      page: 0,
      size: 100,
      tab: 0,
      sortBy: StatusFieldNames.NAME,
      orderBy: "ASC",
      active: 1,
    },
  });

  const handleUploadSharePointFiles = async(uploadIds: number[]) => {
    try {
      if (!uploadIds.length) {
        return [];
      }
      let allRequestUpload = [];
      if (formMode === "create") {
        const sharePointFiles = await uploadFileToVisitationSign(selectionFilesSharePoint);
        return sharePointFiles;
      }

      allRequestUpload = uploadIds.map(fileId => uploadCurrentFileToSharepoint({
        fileId: fileId,
        visitationId: +(visitationId ?? 0)
      }))
      const sharePointFiles = await Promise.all(allRequestUpload);
      return sharePointFiles.flat(1);
      
    } catch (error) {
      return [];
    }
  }

  const handleUploadCreateSharePointFiles = async(files: FileDetails[]) => {
    try {
      if (!files.length) {
        return [];
      }
      const sharePointFiles = await uploadFileToVisitationSign(files);
      return sharePointFiles;
    } catch (error) {
      return [];
    }
  }

  const getDepartmentHeadQuery = useQuery({
    queryKey: ["visitation/get-department-heads"],
    queryFn: async () => {
      const departmentHeadResponse = await getDepartmentHeadsVisitation(
        visitationId ?? ""
      );

      return departmentHeadResponse;
    },
    placeholderData: (prev) => prev,
    enabled: !!initialValue?.createdBy || !!appContext?.me,
  });

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["visitation/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const getAssignedPersonQuery = useQuery({
    queryKey: ["visitation/get-legal-assigned-person"],
    queryFn: () => getAssignedPerson(),
    placeholderData: (prev) => prev,
    enabled: false,
  });

  useEffect(() => {
    const statusOptions = statusList?.statusResponses ?? [];
    if (statusOptions.length > 0) {
      if (formMode === "create") {
        if (statusOptions.length > 0) {
          const requestVisitationStatus = statusOptions.find(
            (item) => item.code === VisitationStatusCode.REQUEST_CONFIRMATION
          );
          form.setValue(
            VisitationDetailFields.VISITATION_STATUS,
            requestVisitationStatus?.id
          );
        }
      }
    }
  }, [form, formMode, statusList]);

  const checkDeptHeadFlag = form.watch(
    VisitationDetailFields.CHECK_DEPT_HEAD_FLAG
  );
  const checkDivisionFlag = form.watch(
    VisitationDetailFields.CHECK_DIVISION_FLAG
  );

  useEffect(() => {
    setTimeout(() => {
      const sendToRequireError = !checkDeptHeadFlag && !checkDivisionFlag;
      if (sendToRequireError) {
        form.setValue("checkSentTo", "")
      } else {
        form.setValue("checkSentTo", "checked")
      }

      form.setValue(
        "hasDepartmentHead",
        !!getDepartmentHeadQuery?.data?.deptHead?.id
      );
    }, 200);
  }, [checkDivisionFlag, checkDeptHeadFlag, form, initialValue, getDepartmentHeadQuery?.data?.deptHead])
  

  const sendToError = !checkDeptHeadFlag && !checkDivisionFlag;

  const handleSaveParams = async () => {
    const formValues = form.getValues();
    const params: VisitationBodySend = {} as VisitationBodySend;

    params[VisitationDetailFields.NAME] =
      formValues[VisitationDetailFields.NAME];

    params[VisitationDetailFields.RECEPTION_ID] =
      formValues[VisitationDetailFields.RECEPTION_ID];
    params[VisitationDetailFields.DEPARTMENT] =
      formValues[VisitationDetailFields.DEPARTMENT];

    params[VisitationDetailFields.POSITION] =
      formValues[VisitationDetailFields.POSITION];
    params[VisitationDetailFields.GROUP] =
      formValues[VisitationDetailFields.GROUP];
    params[VisitationDetailFields.SUPERVISOR_ID] =
      formValues[VisitationDetailFields.SUPERVISOR_ID];

    params[VisitationDetailFields.FIELD] =
      formValues[VisitationDetailFields.FIELD];
    params[VisitationDetailFields.ORGANIZATION_NAME] =
      formValues[VisitationDetailFields.ORGANIZATION_NAME];

    if (formValues[VisitationDetailFields.RECEPTION_TIME_FROM]) {
      params[VisitationDetailFields.RECEPTION_TIME_FROM] = new Date(
        formValues[VisitationDetailFields.RECEPTION_TIME_FROM]
      ).toISOString();
    }

    if (formValues[VisitationDetailFields.RECEPTION_TIME_TO]) {
      params[VisitationDetailFields.RECEPTION_TIME_TO] = new Date(
        formValues[VisitationDetailFields.RECEPTION_TIME_TO]
      ).toISOString();
    }

    params[VisitationDetailFields.PURPOSE] =
      formValues[VisitationDetailFields.PURPOSE];
    params[VisitationDetailFields.REQUEST_SUMARY] =
      formValues[VisitationDetailFields.REQUEST_SUMARY];
    params[VisitationDetailFields.DEPARTMENT_FEEDBACK] =
      formValues[VisitationDetailFields.DEPARTMENT_FEEDBACK];
    params[VisitationDetailFields.PARTICIPANTS] =
      formValues[VisitationDetailFields.PARTICIPANTS];
    params[VisitationDetailFields.CHECK_DEPT_HEAD_FLAG] =
      !!formValues?.[VisitationDetailFields.CHECK_DEPT_HEAD_FLAG];
    params[VisitationDetailFields.CHECK_DIVISION_FLAG] =
      !!formValues?.[VisitationDetailFields.CHECK_DIVISION_FLAG];

    if (formValues[VisitationDetailFields.CONFIRM_DEADLINE]) {
      params[VisitationDetailFields.CONFIRM_DEADLINE] = new Date(
        formValues[VisitationDetailFields.CONFIRM_DEADLINE]
      ).toISOString();
    }

    const receivedUsers = (formValues[VisitationDetailFields.RECEIVED_USERS]?? []).map(
      (user: UserProfileDTO) => user.id
    );

    params[VisitationDetailFields.RECEIVED_USERS] = Array.from(
      new Set(receivedUsers)
    );

    if (formValues[VisitationDetailFields.STAFF_LC_USERS]) {
      params[VisitationDetailFields.STAFF_LC_USERS] = [formValues[VisitationDetailFields.STAFF_LC_USERS]];
    }
    
    // const staffLCUsers = formValues[VisitationDetailFields.STAFF_LC_USERS].map(
    //   (user: UserProfileDTO) => user.id
    // );


    // params[VisitationDetailFields.STAFF_LC_USERS] = Array.from(
    //   new Set(staffLCUsers)
    // );

    if (formValues[VisitationDetailFields.RESPONSE_LC_DEADLINE]) {
      params[VisitationDetailFields.RESPONSE_LC_DEADLINE] = new Date(
        formValues[VisitationDetailFields.RESPONSE_LC_DEADLINE]
      ).toISOString();
    }

    if (formValues[VisitationDetailFields.SHARE_INFORMATION_DEADLINE]) {
      params[VisitationDetailFields.SHARE_INFORMATION_DEADLINE] = new Date(
        formValues[VisitationDetailFields.SHARE_INFORMATION_DEADLINE]
      ).toISOString();
    }

    params[VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT] =
      formValues[VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT]?.map(
        (item: any) => item?.id
      ) ?? [];

    params[VisitationDetailFields.REMIND] =
      (formMode === "create" &&
        !!formValues[VisitationDetailFields.REMIND]?.id) ||
      (formMode === "update" &&
        !!formValues[VisitationDetailFields.REMIND]?.title)
        ? {
            ...castReminderSchemaToSaveReminderDTO(
              formValues[VisitationDetailFields.REMIND]!
            ),
          }
        : {
            title: "",
            description: "",
            module: 2,
            receivedTitle: [],
            receivingDepartment: [],
            remindContents: [],
            relatedUsers: [],
          };

    const sharePointUpload = handleFilterSharePointFiles();
    let sharePointFiles = [];
    if (formMode === "update") {
      sharePointFiles = await handleUploadSharePointFiles(sharePointUpload.new);
    } else {
      sharePointFiles = await handleUploadCreateSharePointFiles(selectionFilesSharePoint);
    }

    params.sharePointAttachmentFiles = [...sharePointUpload.old, ...sharePointFiles.map((file: any) => file.id)];

    let attachments: number[] = [];
    if (files.length > 0) {
      const filterFile: any = [];
      const filterFileId: number[] = [];
      const selectionSharePointIds = selectionFilesSharePoint.map(item => item.id);
      files.forEach((item: any) => {
        if (item?.id === undefined || item?.id === null) {
          filterFile.push(item);
        } else if (!selectionSharePointIds.includes(item.id)) {
          filterFileId.push(item.id);
        }
      });

      if (filterFile.length > 0) {
        const response = await GetListIdFile(filterFile);
        const formatResponse: number[] = response.fileUploadResponses.map(
          (item: FileInfo) => item.fileId
        );
        attachments = [...formatResponse, ...filterFileId];
      } else {
        attachments = [...filterFileId];
      }
    }

    params[VisitationDetailFields.ATTACHMENTS] = attachments;
    return params;
  };

  const handleFilterSharePointFiles = () => {
    const newFilesToUploadSharepoint = selectionSharePoint?.filter((file: any) => !originalSharepointFileIds?.includes(file)) ?? [];
    const oldFilesToUploadSharepoint = selectionSharePoint?.filter((file: any) => originalSharepointFileIds?.includes(file)) ?? [];
    return {
      new: newFilesToUploadSharepoint,
      old: oldFilesToUploadSharepoint,
    }
  }

  const handleChangeCode = async (employeeCode?: UserProfileDTO | null) => {
    if (!employeeCode) return;

    const departmentId = employeeCode?.department?.id;

    if (departmentId) {
      const deptHead = await getDepartmentHeads(departmentId);
      deptHead?.deptHead?.id &&
        form.setValue(
          VisitationDetailFields.SUPERVISOR_ID,
          deptHead?.deptHead?.id
        );
    }

    form.setValue(VisitationDetailFields.RECEPTION_NAME, employeeCode.id);
    form.setValue(
      VisitationDetailFields.DEPARTMENT,
      employeeCode?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
    form.setValue(
      VisitationDetailFields.POSITION,
      employeeCode?.position?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
  };

  const handleChangeEmployee = async (employeeName?: UserProfileDTO | null) => {
    if (!employeeName) return;
    const departmentId = employeeName?.department?.id;
    if (departmentId) {
      const deptHead = await getDepartmentHeads(departmentId);
      deptHead?.deptHead?.id &&
        form.setValue(
          VisitationDetailFields.SUPERVISOR_ID,
          deptHead?.deptHead?.id
        );
    }

    form.setValue(VisitationDetailFields.RECEPTION_ID, employeeName.id);
    form.setValue(
      VisitationDetailFields.DEPARTMENT,
      employeeName?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
    form.setValue(
      VisitationDetailFields.POSITION,
      employeeName?.position?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
  };

  const disableCheckbox =
    !appContext.meCanWrite || (formMode === "update" && !ownRole?.includes(1));

  return (
    <>
      <Grid
        container
        className="form-wrapper"
        style={{ marginTop: formMode === "update" ? 24 : 0 }}
      >
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{...formInputSxProps, pb: 0}}
            >
              <Grid
                item
                width={"100%"}
                sx={{
                  display:
                    formMode === "create"
                      ? "initial"
                      : "none",
                }}
              >
                <FormTextField
                  control={form.control}
                  name={VisitationDetailFields.NAME}
                  label={t(`visitation.label.name`)}
                  placeHolder={t(`visitation.label.name`)}
                  required
                  disabled={!enabledEdit}
                  inputProps={{ maxLength: 255 }}
                />
              </Grid>
              <Grid item width={"100%"}>
                <Grid
                  container
                  className="form-sub-section-wrapper"
                  position={"relative"}
                  rowGap={GLOBAL_SPACING}
                >
                  <Grid item width={"100%"}>
                    <Typography fontWeight="bold">
                      {t("visitation.label.information")}
                    </Typography>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        name={VisitationDetailFields.RECEPTION_ID}
                        minCharLength={1}
                        label={t(
                          `visitation.label.${VisitationDetailFields.RECEPTION_ID}`
                        )}
                        placeholder={t(
                          `visitation.label.${VisitationDetailFields.RECEPTION_ID}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return (
                              response?.users?.filter(
                                (item) => item.employeeCode
                              ) ?? []
                            );
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option.employeeCode ?? ""}`
                        }
                        getOptionKey={(option) => option.id}
                        keyQuery={"reception/queryUser"}
                        onChange={(_, option) => handleChangeCode(option)}
                        isFocus
                        disabled={!enabledEdit}
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        name={VisitationDetailFields.RECEPTION_NAME}
                        required
                        label={t(
                          `visitation.label.${VisitationDetailFields.RECEPTION_NAME}`
                        )}
                        placeholder={t(
                          `visitation.label.${VisitationDetailFields.RECEPTION_NAME}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return response?.users ?? [];
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option.name ?? ""} - ${option.employeeCode ?? ""}`
                        }
                        onChange={(_, option) => handleChangeEmployee(option)}
                        getOptionKey={(option) => option.id}
                        keyQuery={"employeesName/queryUser"}
                        isFocus
                        disabled={!enabledEdit}
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={VisitationDetailFields.DEPARTMENT}
                        label={t(
                          `visitation.label.${VisitationDetailFields.DEPARTMENT}`
                        )}
                        placeHolder={t(
                          `visitation.label.${VisitationDetailFields.DEPARTMENT}`
                        )}
                        required
                        disabled={!enabledEdit}
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={VisitationDetailFields.POSITION}
                        label={t(
                          `visitation.label.${VisitationDetailFields.POSITION}`
                        )}
                        placeHolder={t(
                          `visitation.label.${VisitationDetailFields.POSITION}`
                        )}
                        required
                        disabled={!enabledEdit}
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={VisitationDetailFields.GROUP}
                        label={t(
                          `visitation.label.${VisitationDetailFields.GROUP}`
                        )}
                        placeHolder={t(
                          `visitation.label.${VisitationDetailFields.GROUP}`
                        )}
                        disabled={!enabledEdit}
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={VisitationDetailFields.AREA}
                        label={t(
                          `visitation.label.${VisitationDetailFields.AREA}`
                        )}
                        placeHolder={t(
                          `visitation.label.${VisitationDetailFields.AREA}`
                        )}
                        disabled={!enabledEdit}
                      />
                    </Grid>
                  </Grid>

                  <Grid item xs={12}>
                    <FormAsyncSelect<any, UserProfileDTO>
                      control={form.control}
                      minCharLength={1}
                      name={VisitationDetailFields.SUPERVISOR_ID}
                      label={t(
                        `visitation.label.${VisitationDetailFields.SUPERVISOR_ID}`
                      )}
                      placeholder={t(
                        `visitation.label.${VisitationDetailFields.SUPERVISOR_ID}`
                      )}
                      getOptions={async (keyword) => {
                        if (typeof keyword == "string") {
                          const params: GetUsersParams = {
                            searchTerm: keyword,
                            page: 0,
                            size: 100,
                            sortBy: "name",
                            sortOrder: "ASC",
                          };
                          const response = await getUsers(params);

                          return response?.users ?? [];
                        } else if (keyword?.length && keyword.length > 0) {
                          return getUser(keyword[0])
                            .then((response) => (response ? [response] : []))
                            .catch(() => []);
                        }

                        return [];
                      }}
                      getOptionLabel={(option) =>
                        `${option?.name} - ${
                          option?.position?.name
                            ? `${option?.position?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"]}.`
                            : ""
                        }${option?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"] ?? ""}`
                      }
                      // getOptionLabel={(option) =>
                      //   `${option.name ?? ""} - ${option.employeeCode ?? ""}`
                      // }
                      // onChange={(_, option) => handleChangeEmployee(option)}
                      getOptionKey={(option) => option.id}
                      keyQuery={"supervisor/queryUser"}
                      isFocus
                      required
                      disabled={!enabledEdit}
                    />
                    <Grid item xs={12} mt="10px">
                      <DropPreviewFileUploadComponent
                        dropView={formMode === "create"}
                        preview={formMode === "update"}
                        name={VisitationDetailFields.ATTACHMENTS}
                        control={form.control}
                        files={files}
                        setFiles={(files) => {
                          setFiles(files);
                          form.setValue(VisitationDetailFields.ATTACHMENTS, files ?? []);
                          form.trigger(VisitationDetailFields.ATTACHMENTS)
                        }}
                        title={t(
                          `visitation.label.${VisitationDetailFields.ATTACHMENTS}`
                        )}
                        checkSelected={(file: any) => {
                          const selectionFilesSharePointIds = selectionFilesSharePoint.map(item => item.id);
                          return formMode === "update" ? !!selectionSharePoint?.includes(file?.id) : !!selectionFilesSharePointIds?.includes(file?.id)
                        }}
                        onItemCheck={(file: any) => {
                          if (formMode === "update") {
                            let checkedValues = [...selectionSharePoint];
                            if (selectionSharePoint?.includes(file?.id)) {
                              checkedValues = checkedValues?.filter((ele: any) => ele !== file?.id)
                            } else {
                              checkedValues.push(file?.id)
                            }
                            setSelectionSharePoint(checkedValues);

                            return;
                          }

                          let checkedValues = [...selectionFilesSharePoint];
                          if (selectionFilesSharePoint?.map(item => item.id).includes(file?.id)) {
                            checkedValues = checkedValues?.filter((ele) => ele.id !== file?.id)
                          } else {
                            checkedValues.push(file)
                          }
                          
                          setSelectionFilesSharePoint(checkedValues)
                        }}
                        disableCheckbox={!accessToken}
                        disabled={!enabledEdit}
                        required
                        hasRadio={false}
                        spPermission={checkSharepointPermission}
                        spFolder={"Site Visit Management"}
                        typeUpload="visitation-sharepoint"
                        hasCheckBox
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>

              <Grid item width={"100%"}>
                <Grid
                  container
                  className="form-sub-section-wrapper"
                  position={"relative"}
                  rowGap={GLOBAL_SPACING}
                >
                  <Grid item width={"100%"}>
                    <Typography fontWeight="bold">
                      {t("visitation.label.informationInspectionTeam")}
                    </Typography>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={VisitationDetailFields.FIELD}
                        label={t(
                          `visitation.label.${VisitationDetailFields.FIELD}`
                        )}
                        placeHolder={t(
                          `visitation.label.${VisitationDetailFields.FIELD}`
                        )}
                        required
                        disabled={!enabledEdit}
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={VisitationDetailFields.ORGANIZATION_NAME}
                        label={t(
                          `visitation.label.${VisitationDetailFields.ORGANIZATION_NAME}`
                        )}
                        placeHolder={t(
                          `visitation.label.${VisitationDetailFields.ORGANIZATION_NAME}`
                        )}
                        required
                        disabled={!enabledEdit}
                      />
                    </Grid>
                  </Grid>
                  <Grid
                    container
                    rowSpacing={1}
                    columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                    sx={formInputSxProps}
                  >
                    <Grid item xs={6}>
                      <DateInput
                        name={VisitationDetailFields.RECEPTION_TIME_FROM}
                        control={form.control}
                        label={t(`visitation.label.receptionTimeFrom`)}
                        placeholder={"dd/mm/yyyy"}
                        required
                        disabled={!enabledEdit}
                        maxDate={form.watch(
                          VisitationDetailFields.RECEPTION_TIME_TO
                        )}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <DateInput
                        name={VisitationDetailFields.RECEPTION_TIME_TO}
                        control={form.control}
                        label={t(`visitation.label.receptionTimeTo`)}
                        placeholder={"dd/mm/yyyy"}
                        required
                        disabled={!enabledEdit}
                        minDate={form.watch(
                          VisitationDetailFields.RECEPTION_TIME_FROM
                        )}
                      />
                    </Grid>
                  </Grid>

                  <Grid container xs={12}>
                    <FormTextArea
                      control={form.control}
                      name={VisitationDetailFields.PURPOSE}
                      label={t(
                        `visitation.label.${VisitationDetailFields.PURPOSE}`
                      )}
                      placeHolder={t(
                        `visitation.label.${VisitationDetailFields.PURPOSE}`
                      )}
                      required
                      minRows={2}
                      disabled={!enabledEdit}
                    />
                  </Grid>
                </Grid>
              </Grid>

              <Grid item width="100%">
                <FormTextArea
                  control={form.control}
                  name={VisitationDetailFields.REQUEST_SUMARY}
                  label={t(
                    `visitation.label.${VisitationDetailFields.REQUEST_SUMARY}`
                  )}
                  placeHolder={t(
                    `visitation.label.${VisitationDetailFields.REQUEST_SUMARY}`
                  )}
                  required
                  minRows={2}
                  disabled={!enabledEdit}
                />
              </Grid>
              <Grid item width="100%">
                <FormTextArea
                  control={form.control}
                  name={VisitationDetailFields.DEPARTMENT_FEEDBACK}
                  label={t(
                    `visitation.label.${VisitationDetailFields.DEPARTMENT_FEEDBACK}`
                  )}
                  placeHolder={t(
                    `visitation.label.${VisitationDetailFields.DEPARTMENT_FEEDBACK}`
                  )}
                  required
                  minRows={2}
                  disabled={!enabledEdit}
                />
              </Grid>
              <Grid item width="100%">
                <FormTextArea
                  control={form.control}
                  name={VisitationDetailFields.PARTICIPANTS}
                  label={t(
                    `visitation.label.${VisitationDetailFields.PARTICIPANTS}`
                  )}
                  placeHolder={t(
                    `visitation.label.${VisitationDetailFields.PARTICIPANTS}`
                  )}
                  required
                  minRows={2}
                  disabled={!enabledEdit}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={VisitationDetailFields.RECEIVED_USERS}
                  label={t(`visitation.fields.approver`)}
                  placeholder={t(`visitation.fields.approver`)}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });

                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"] ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryRelatedUser"
                  disabled={!enabledEdit}
                  required={!getDepartmentHeadQuery?.data}
                />
              </Grid>
              {getDepartmentHeadQuery?.data && (
                <Stack direction={"row"} width={"100%"} mt={0.5} gap={2}>
                  <Typography
                    sx={{
                      fontSize: "14px",
                      color: COLOR_TYPE.TOYOTA.TOYOTA1,
                      fontStyle: "italic",
                    }}
                  >
                    {t(`legalAdvice.label.requiredToBeSentTo`)}*:
                  </Typography>
                  <Stack gap={"1rem"}>
                    {getDepartmentHeadQuery?.data?.deptHead && (
                      <CheckboxInput
                        fontSize={"1rem"}
                        checked={form.watch(
                          VisitationDetailFields.CHECK_DEPT_HEAD_FLAG
                        )}
                        borderColor={
                          disableCheckbox
                            ? COLOR_TYPE.TOYOTA.TOYOTA5
                            : COLOR_TYPE.TOYOTA.TOYOTA1
                        }
                        checkboxBg={
                          disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"
                        }
                        onChange={(value) => {
                          form.setValue(
                            VisitationDetailFields.CHECK_DEPT_HEAD_FLAG,
                            value
                          );
                        }}
                        label={
                          getDepartmentHeadQuery?.data?.deptHead
                            ? `${
                                getDepartmentHeadQuery?.data?.deptHead?.name
                              } - ${
                                getDepartmentHeadQuery?.data?.deptHead
                                  ?.position?.[
                                  i18n.language == LANGUAGES.VIETNAMESE
                                    ? "name"
                                    : "nameEnglish"
                                ]
                              }.${
                                getDepartmentHeadQuery?.data?.deptHead
                                  ?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"]
                              }`
                            : t(
                                "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={disableCheckbox}
                      />
                    )}
                    {getDepartmentHeadQuery?.data?.division && (
                      <CheckboxInput
                        fontSize={"1rem"}
                        checked={form.watch(
                          VisitationDetailFields.CHECK_DIVISION_FLAG
                        )}
                        borderColor={
                          disableCheckbox
                            ? COLOR_TYPE.TOYOTA.TOYOTA5
                            : COLOR_TYPE.TOYOTA.TOYOTA1
                        }
                        checkboxBg={
                          disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"
                        }
                        onChange={(value) => {
                          form.setValue(
                            VisitationDetailFields.CHECK_DIVISION_FLAG,
                            value
                          );
                        }}
                        label={
                          getDepartmentHeadQuery?.data?.division
                            ? `${getDepartmentHeadQuery?.data?.division?.name} - Division Head.${getDepartmentHeadQuery?.data?.division?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"]}`
                            : t(
                                "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={disableCheckbox}
                      />
                    )}
                  </Stack>
                  {sendToError ? (
                    <FormHelperText error>
                      {t("legalAdvice.messages.requiredToBeSentTo")}
                    </FormHelperText>
                  ) : null}
                </Stack>
              )}
              <Grid item width={"100%"}>
                <DateTimeInput
                  control={form.control}
                  name={VisitationDetailFields.CONFIRM_DEADLINE}
                  placeholder="dd/mm/yyyy hh:mm"
                  required
                  label={t(
                    `visitation.label.${VisitationDetailFields.CONFIRM_DEADLINE}`
                  )}
                  disabled={!enabledEdit}
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormAsyncSelect<any, UserProfileDTO>
                    control={form.control}
                    placeholderFull={t(`visitation.placeholder.selectLC`).replace(/&amp;/g, "&").replace(/&#x2F;/g, "/")}
                    name={VisitationDetailFields.STAFF_LC_USERS}
                    label={t(
                      `visitation.label.${VisitationDetailFields.STAFF_LC_USERS}`
                    )}
                    placeholder={t(
                      `visitation.label.${VisitationDetailFields.STAFF_LC_USERS}`
                    )}
                    initialValue={initialValue?.staffLCUsers?.[0] ?? undefined}
                    getOptions={async (keyword) => {
                      if (!getLegalDepartmentQuery.data) return [];
                      const advisorIds =
                        getAssignedPersonQuery?.data?.users?.map(
                          (user) => user.id
                        ) ?? [];
                      if (typeof keyword == "string") {
                        const params: GetUsersParams = {
                          searchTerm: keyword,
                          page: 0,
                          size: 100,
                          sortBy: "name",
                          sortOrder: "ASC",
                          departmentIds: getLegalDepartmentQuery.data
                            ? [getLegalDepartmentQuery.data]
                            : [],
                        };

                        const response = await getUsers(params);
                        const assignedList = initialValue?.assignmentUsers?.map(item => item.id) ?? [];
                        const userList = response?.users?.filter(item => item.id !== initialValue?.createdBy?.id && !assignedList.some(assignedId => assignedId === item.id)) ?? [];

                        return (
                          userList.map((user, index) => ({
                              ...user,
                              rank: advisorIds?.includes(user.id)
                                ? index
                                : 99999,
                            }))
                            ?.sort(
                              (first, second) => first.rank - second.rank
                            ) ?? []
                        );
                      } else if (keyword?.length && keyword.length > 0) {
                        return getUser(keyword[0])
                          .then((response) => (response ? [response] : []))
                          .catch(() => []);
                      }
                      return [];
                    }}
                    getOptionLabel={(option) =>
                      `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                        option?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"] ?? option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    onChange={(_selectedKey, option) => {
                      if (initialValue?.isLCEvaluateFlag) {
                        toast.warning(
                          t(
                            "CONFLICT_MANAGEMENT.messages.confirmReviewerChange",
                            { name: option?.name }
                          )
                        );
                      }
                    }}
                    keyQuery={"lcOfficersVisitation/queryUser"}
                    isFocus
                    disabled={!enabledEdit || formMode === "create"}
                  />
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <DateTimeInput
                  control={form.control}
                  name={VisitationDetailFields.RESPONSE_LC_DEADLINE}
                  label={t(
                    `visitation.label.${VisitationDetailFields.RESPONSE_LC_DEADLINE}`
                  )}
                  placeholder="dd/mm/yyyy hh:mm"
                  disabled={!enabledEdit || formMode === "create"}
                  helperText={t(
                    `visitation.messages.enterResponseLC`
                  )}
                />
              </Grid>
              {initialValue?.assignmentUsers && initialValue.assignmentUsers.length > 0 && <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={VisitationDetailFields.ASSIGNMENT_USERS}
                  label={t(`visitation.fields.assignment`)}
                  placeholder={t(`visitation.fields.assignment`)}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });

                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"] ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryRelatedUser"
                  disabled={!enabledEdit}
                  required={!getDepartmentHeadQuery?.data}
                />
              </Grid>}
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormSelectTreeView
                    name={VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT}
                    control={form.control}
                    label={t(
                      `visitation.label.${VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT}`
                    )}
                    getOptions={async (keyword) => {
                      try {
                        const response = await getDepartments({
                          searchTerm: keyword,
                        });
                        const first100Departments: Department[] = (
                          response?.departments ?? []
                        ).slice(0, 150);
                        return first100Departments; // Assuming the data is in response.data
                      } catch (e) {
                        return [];
                      }
                    }}
                    getOptionLabel={(option) => option.name ?? ""}
                    getOptionKey={(option) => option.id ?? ""}
                    getOptionChildren={(option) => option.children}
                    variant="outlined"
                    debounceMs={FILTER_DEBOUNCE_MS}
                    onChange={(value: Department[]) => {
                      const mappedValue: string[] =
                        value.map((item) => item.id ?? "") || [];
                      form.setValue(
                        VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT,
                        mappedValue
                      );
                    }}
                    rules={{ required: "This field is required" }}
                    selectedItemsProp={
                      props?.initialValue?.shareInformationDepartments
                    }
                    ignoreChildren
                    disabled={!enabledEdit}
                  />
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <DateTimeInput
                  control={form.control}
                  name={VisitationDetailFields.SHARE_INFORMATION_DEADLINE}
                  label={t(
                    `visitation.label.${VisitationDetailFields.SHARE_INFORMATION_DEADLINE}`
                  )}
                  placeholder="dd/mm/yyyy hh:mm"
                  disabled={!enabledEdit}
                />
              </Grid>
              {/* Thông tin xác nhận */}
              {initialValue?.id && (
                <ConfirmInfomation
                  visitationId={initialValue.id}
                  visitation={initialValue}
                />
              )}
              {/* Đánh giá nhận xét của phòng pháp chế/ bộ phận tuân thủ */}
              {initialValue?.id && (
                <EvaluatedLegalDepartment
                  visitationId={initialValue.id}
                  visitation={initialValue}
                />
              )}
              {/* Đánh giá nhận xét của phòng ban được chia sẻ */}
              {initialValue?.id && (
                <EvaluatedFeedback visitationId={initialValue.id} />
              )}
              {/* kết quả tiếp đón */}
              {initialValue?.id && (
                <ReceptionResult
                  visitationId={initialValue.id}
                  visitation={initialValue}
                />
              )}
              {/* Các thông tin cần theo dõi thêm */}
              {initialValue?.id && (
                <FollowInformation
                  visitationId={initialValue.id}
                  visitation={initialValue}
                />
              )}
            </Grid>

            <ReminderPickerSubForm
              name={"remind"}
              module={ModuleFields.ADVISE_NAME.module}
              placeholder={t("menu.reminder")}
            />
            <FormActionButtons
              formMode={formMode}
              loading={loading}
              onCancel={onCancel}
              isDisableButonSave={!enabledEdit}
              allowDraft={formMode === "create" || defaultValues?.isDraft}
              onSaveDraft={async () => {
                try {
                  const params = await handleSaveParams();
                  params[VisitationDetailFields.IS_DRAFT] = true;
                  onSubmitDraft?.(params);
                } catch (error) {}
              }}
              onSave={async () => {
                try {
                  const params = await handleSaveParams();
                  params[VisitationDetailFields.IS_DRAFT] = false;
                  onSubmit?.(params);
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </>
  );
};

export default VisitationForm;
