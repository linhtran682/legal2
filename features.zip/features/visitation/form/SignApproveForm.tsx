import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import DateInput from '@/components/commons/inputs/date_input/DateInput';
import DropPreviewFileUploadComponent, { ALLOWED_DOCUMENT_TYPE, FileDetails } from '@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload';
import { GLOBAL_SPACING } from '@/constants/format';
import { formInputSxProps } from '@/constants/theme';
import { AppContext } from '@/context/AppContext';
import { cookieSetting, getUserLabel } from '@/utils';
import { yupResolver } from '@hookform/resolvers/yup';
import ExpandLessRoundedIcon from '@mui/icons-material/ExpandLessRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import { Backdrop, Button, CircularProgress, Grid, InputLabel, Stack, Typography } from '@mui/material';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { uniqueId } from 'lodash';
import { FC, ReactNode, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { FormProvider, useFieldArray, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import { useRouter } from 'next/router';
import { createSignApprove, uploadCurrentFileToSharepoint,
  visitationCallToEsign,
  visitationRecallTobeSign,
  visitationRevokeTobeSign } from '@/apis/service/visitation/visitationApi';
import { ApproverVisitationStatus, ConvertPdfEnum, SignApproveBodyReceived,
  SignApproveBodySend, SignApproveFields, SignApproveSchema,
  SignDefaultReceive,
  VisitationBodyReceive, VisitationConfirmForm, VisitationRoles, VisitationSignInformation } from '@/models/visitation/VisitationDetail';
import ApproversTableForm from './signApproveTab/ApproversTableForm';
import FilesToApproveTableForm from './signApproveTab/FilesToApproveTableForm';
import { ConfirmPopupProps, DefaultConfirmPopupState } from '@/components/commons/popups/confirm_popup/ConfirmPopup';
import { VisitationStatusCode } from '@/constants/visitation';
import FilesLatestTable from './signApproveTab/FilesLatestTable';
import { ConfirmPopupWithTextarea, ConfirmPopupWithTextareaProps } from '@/features/visitation/form/signApproveTab/ConfirmPopupWithTextarea';
import { DefaultWarningPopupState, WarningSignPopup, WarningSignPopupProps } from './signApproveTab/WarningSignPopup';

export interface Props {
  formMode?: "create" | "update";
  initialValue?: any;
  loading?: boolean;
  initialValueReceive?: VisitationBodyReceive;
  visitationId?: number;
  children?: ReactNode;
  initialSignApprove?: SignApproveBodyReceived;
  onCallToEsign?: (data: any) => void;
  onRecallCheckSheet?: (data: any) => void;
  canCreate?: boolean;
  // setUploadId: (id: number) => void;
  ownRole?: number[];
  checkSharepointPermission?: number;
  activeTab?: number;
  signDefault?: SignDefaultReceive[];
}

const LABEL_PATH = "visitation.label"

const SignApproveForm: FC<Props> = (
  {
    formMode = 'create',
    ownRole = [],
    initialSignApprove,
    initialValueReceive,
    visitationId,
    checkSharepointPermission,
    signDefault,
    activeTab,
  }
) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const formRef = useRef<HTMLFormElement>(null);
  const [originalSharepointFileIds, setOriginalSharepointFileIds] = useState<number[]>([]);
  const [selectionSignId, setSelectionSignId] = useState<number | undefined>(undefined);
  const [selectionSharePoint, setSelectionSharePoint] = useState<number[]>([]);
  const accessToken = cookieSetting.get("ACCESS_TOKEN");
  const [visitationSignedTemplate, setVisitationSignedTemplate] = useState<VisitationSignInformation>()
  const router = useRouter();
  const queryClient = useQueryClient();
  const [defaultConfirmPopupState, setDefaultConfirmPopupState] =
    useState<ConfirmPopupProps>();
  const [isLoadingFull, setIsLoadingFull] = useState(false)
    
  const [confirmEsignPopupState, setConfirmEsignPopupState] = useState<ConfirmPopupWithTextareaProps>(
    () => DefaultConfirmPopupState
  );
    const [warningSignedPopupState, setWarningSignedPopupState] = useState<WarningSignPopupProps>(DefaultWarningPopupState);
    
  const form = useForm({
    resolver: yupResolver(SignApproveSchema),
    mode: 'onSubmit'
  });

  useEffect(() => {
    if (initialSignApprove?.reason
      && activeTab === 1
      && ownRole.includes(VisitationRoles.SIGN)
      && initialValueReceive?.status?.code === VisitationStatusCode.REQUEST_SIGN
      && appContext.me?.id !== initialSignApprove.createBy?.id
    ) {
      setWarningSignedPopupState({
        open: true,
        title: t("visitation.label.callEsign"),
        reason: initialSignApprove?.reason,
        onClose: () => {
          setWarningSignedPopupState(pre => ({...pre, open: false}));
        },
      })
    }
  }, [activeTab, appContext.me?.id, initialSignApprove?.createBy?.id, initialSignApprove?.reason, initialValueReceive?.status?.code, ownRole, t])

  const evaluationRoleEnabledSaveBtn = useMemo(() => 
    ownRole.includes(VisitationRoles.EVALUATION) && (
      initialValueReceive?.status?.code === VisitationStatusCode.REQUEST_SIGN
      || initialValueReceive?.status?.code === VisitationStatusCode.CALL_ESIGN
      || initialValueReceive?.status?.code === VisitationStatusCode.APPROVAL_FINISHED
      || initialValueReceive?.status?.code === VisitationStatusCode.APPROVAL_RECALLED
      || initialValueReceive?.status?.code === VisitationStatusCode.SIGN_REJECT
    ), [initialValueReceive?.status?.code, ownRole])
  const enabledEdit = useMemo(() => 
    appContext.meCanWrite && ownRole.includes(1) && (
      formMode === "create" ||
      initialValueReceive?.status?.code !== VisitationStatusCode.RECEPTION
    ), [appContext.meCanWrite, formMode, initialValueReceive?.status?.code, ownRole])

  const checkSheetFields = useFieldArray({
    name: 'visitationSignInformationRequestList',
    control: form.control,
    keyName: 'rowId'
  });

  useEffect(() => {
    if (initialSignApprove && signDefault) {
      let attachmentFiles: FileDetails[] = [];
      let sharePointFiles: FileDetails[] = [];
      if (initialSignApprove?.attachmentFiles?.length) {
        attachmentFiles = [...(initialSignApprove?.attachmentFiles ?? [])?.map((item) => {
          return {
            name: item.fileName,
            path: item.filePath,
            id: item.fileId,
            uploadDate: item.uploadDate,
          };
        })];
      }
      if (initialSignApprove?.sharePointAttachmentFiles?.length) {
        sharePointFiles = [...(initialSignApprove?.sharePointAttachmentFiles ?? [])?.map((item) => {
          return {
            ...item,
            name: item.fileName,
            path: item.sharePointLink,
            id: item.id,
            // uploadDate: item.uploadDate,
          };
        })];
        attachmentFiles = [...attachmentFiles, ...sharePointFiles];

        const sharePointIds = initialSignApprove?.sharePointAttachmentFiles?.map(file => file.id) ?? [];
        setOriginalSharepointFileIds(sharePointIds);
        setSelectionSharePoint(sharePointIds);
      } else {
        setOriginalSharepointFileIds([]);
        setSelectionSharePoint([]);
      }
      

      const rowsConvert: any[] = signDefault.map(item => ({
        userId: item?.user?.id ?? null,
        name: item?.user?.name,
        department: item?.user?.department,
        position: item?.user?.position,
        order: item.order,
        processDate: ""
      }))
      
      const signedTemplate: VisitationSignInformation = {
        attachment: [],
        visitationSignUserApprovedList: rowsConvert
      }
      setVisitationSignedTemplate(signedTemplate)


      let visitationSignInformationRequestList: any[] = [signedTemplate];

      if (initialSignApprove?.visitationSignInformationList && initialSignApprove?.visitationSignInformationList?.length > 0) {
        visitationSignInformationRequestList = initialSignApprove?.visitationSignInformationList?.map((signInformation: VisitationSignInformation) => {
          const attachment = signInformation.attachment.map(item => ({
            ...item,
            // id: item?.id,
            // statusId: item.status?.id,
            // order: item.order ?? 1,
            fileType: ConvertPdfEnum.LOCAL,
            fileName: item?.fileName,
            fileId: item?.fileId
          }))

          const fileId = attachment?.[0]?.fileId;

          const visitationSignUserApprovedList = signInformation?.visitationSignUserApprovedList?.map((item: any) => ({
            ...item,
            id: item?.id,
            userId: item?.user?.id,
            name: item?.user?.name,
            department: item?.user?.department,
            position: item?.user?.position,
            order: item?.user?.order,
            processDate: item?.processDate ? new Date(item?.processDate) : null
          })) ?? [];

          return {
            ...signInformation,
            attachment,
            fileId,
            visitationSignUserApprovedList,
          }

        })
      }

      const initialFormValues = {
        ...initialSignApprove,
        deadline: initialSignApprove?.deadline ? new Date(initialSignApprove?.deadline) : undefined,
        visitationSignInformationRequestList,
        attachmentIds: attachmentFiles,
        statusId: initialSignApprove?.status?.id ?? 0
      }
      form.reset(
        initialFormValues
      )
    }

  }, [form, initialSignApprove, signDefault])
  
  const invalidateQueriesDetail = () => {
    queryClient.invalidateQueries({
      queryKey: ["get_initial_visitation_detail"],
    });
    queryClient.invalidateQueries({
      queryKey: ["get_sign_approve_tab"],
    });
  }
  
  const createSignApproveQuery = useMutation({
    mutationFn: createSignApprove,
    onSuccess: async () => {
      // upload current
      setDefaultConfirmPopupState({ ...DefaultConfirmPopupState });
      invalidateQueriesDetail();
      toast.success(
        t("common.message.create_success", {
          recordName: t("visitation.tabs.sign"),
        })
      );
    },
  });

  const callToEsignMutation = useMutation({
    mutationFn: visitationCallToEsign,
    onSuccess: () => {
      toast.success(
        t("visitation.messages.createEsignSuccess")
      );
      invalidateQueriesDetail();
    },
  });

  const recallTobeSignMutation = useMutation({
    mutationFn: visitationRecallTobeSign,
    onSuccess: () => {
      toast.success(
        t("visitation.messages.recallSignSuccess")
      );
      invalidateQueriesDetail();
    },
  });

  const deleteSignBlockMutation = useMutation({
    mutationFn: visitationRevokeTobeSign,
    onSuccess: () => {
      toast.success(
        t("visitation.messages.revokeSignSuccess")
      );
      invalidateQueriesDetail();
    },
  });

  const appendCheckSheet = () => {
    checkSheetFields?.append?.({
      ...visitationSignedTemplate,

    });
    setTimeout(() => document?.getElementById?.('add-check-sheet-item')?.scrollIntoView({
      behavior: 'smooth',
    }), 100);
  }

  const handleSaveParams = async() => {
    const values = form.getValues();
    const params: SignApproveBodySend = {} as SignApproveBodySend;
    params.deadline = (values?.deadline as any).toISOString();
    params.statusId = Number(values.statusId);
    params.content = values.content ?? "";
    params.attachmentIds = values?.attachmentIds?.map((a: any) => a.id) ?? [];

    const visitationSignInformationRequestList = values.visitationSignInformationRequestList?.map((item: any, index: number) => ({
      position: index + 1,
      id: item.id,
      fileId: item.fileId,
      visitationSignUserApprovedList: item?.visitationSignUserApprovedList?.map((signUser: any, signUserIndex: number) => ({
        id: signUser?.id,
        order: signUserIndex,
        processDate: signUser?.processDate ? signUser?.processDate?.toISOString?.() : undefined,
        comment: signUser.comment,
        userId: signUser.userId,
      }))?? []
    }));
    
    params.visitationSignInformationRequestList = visitationSignInformationRequestList;
    
    const sharePointUpload = handleFilterSharePointFiles();
    const sharePointFiles = await handleUploadSharePointFiles(sharePointUpload.new);

    params.sharePointAttachmentFiles = [...sharePointUpload.old, ...sharePointFiles.map(file => file.id)];
    return params;
  }

  const handleFilterSharePointFiles = () => {
    const newFilesToUploadSharepoint = selectionSharePoint?.filter((file: any) => !originalSharepointFileIds?.includes(file)) ?? [];
    const oldFilesToUploadSharepoint = selectionSharePoint?.filter((file: any) => originalSharepointFileIds?.includes(file)) ?? [];
    return {
      new: newFilesToUploadSharepoint,
      old: oldFilesToUploadSharepoint,
    }
  }

  const handleRecallCheckSheet = async (signIndex: number) => {
    try {
      recallTobeSignMutation.mutateAsync({
        id: initialValueReceive?.id ?? 0,
        position: signIndex + 1
      })
      
    } catch (error) {
    }
  }

  const handleCallEsign = async (signIndex: any) => {
    try {
      // condition validate call esign
      form.setValue("isCallEsign", true);
      const hasPendingItem = checkSheetFields.fields.some((ele: any, index: number) => {
        const isOtherItem = signIndex !== index;
        // const calledEsign = ele?.status === VisitationStatusCode.REQUEST_SIGNING;
        const hasRejection = ele?.visitationSignUserApprovedList?.some((s: any) => s?.status === ApproverVisitationStatus.REJECT);
        const hasNotSigned = ele?.visitationSignUserApprovedList?.some((s: any) => s?.status === ApproverVisitationStatus.NEW);
        return isOtherItem && hasNotSigned && !hasRejection;
      })

      if (hasPendingItem) {
        toast.error(t('visitation.messages.esignPending'));
        return;
      }

      const noError = await form.trigger();
      form.setValue("isCallEsign", false);
      if (!noError) return;


      setConfirmEsignPopupState({
        open: true,
        title: t("visitation.label.callEsign"),
        handleConfirm: (formConfirm: VisitationConfirmForm) => callEsignConfirmed(formConfirm, signIndex),
        handleCancel: () =>
          setConfirmEsignPopupState(DefaultConfirmPopupState),
      })
    } catch (error) {
    }
  }

  const callEsignConfirmed = async(formConfirm: VisitationConfirmForm, signIndex: number) => {
    try {
      setIsLoadingFull(true);
      setConfirmEsignPopupState(DefaultConfirmPopupState);
      const params = await handleSaveParams();
      params.content = formConfirm.content;
      params.reason = formConfirm.reason;
      await callToEsignMutation.mutateAsync({
        id: initialValueReceive?.id ?? 0,
        position: signIndex + 1,
        request: params
      })
    } catch {

    } finally {
      setIsLoadingFull(false)
    }
  }

  const isStatusDone = initialValueReceive?.status?.code === VisitationStatusCode.FINISH;
  const isStatusReception = initialValueReceive?.status?.code === VisitationStatusCode.RECEPTION;
  const enabledSignButtons = appContext.meCanWrite && ownRole.includes(VisitationRoles.PIC) && !isStatusDone && !isStatusReception;

  const handleUpdate = (params: any) => {
    (createSignApproveQuery.mutate({id: visitationId ?? 0, request: params}));
  }

  const handleDeleteSignBlock = (signIndex: number) => {
    if (visitationId) {
      deleteSignBlockMutation.mutate({id: visitationId, position: signIndex + 1});
    }

    checkSheetFields.remove(signIndex);
  }

  const handleUploadSharePointFiles = async(uploadIds: number[]) => {
    try {
      if (!uploadIds.length) {
        return [];
      }
      const allRequestUpload = uploadIds.map(fileId => uploadCurrentFileToSharepoint({
        fileId: fileId,
        visitationId: visitationId ?? 0
      }))

      const sharePointFiles = await Promise.all(allRequestUpload);
      return sharePointFiles.flat(1);
    } catch (error) {
      return [];
    }
  }

  const signStatus = initialSignApprove?.status;

  return (
    <>
    <FormProvider {...form}>
      <form ref={formRef}>
        <Grid
          container
          className="form-wrapper"
          minWidth={'100%'}
        >
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={formInputSxProps}
            width={'100%'}
          >
            <Grid item width={"100%"} >
              <InputLabel>{t(`${LABEL_PATH}.sender`)}</InputLabel>
              {initialSignApprove?.createBy && <Typography>{getUserLabel(initialSignApprove?.createBy)}</Typography>}
            </Grid>

            {/* Thời hạn */}
            <Grid item width={"100%"}>
              <DateInput
                name={SignApproveFields.DEADLINE}
                control={form.control}
                label={t(`${LABEL_PATH}.${SignApproveFields.DEADLINE}`)}
                placeholder={'dd/mm/yyyy'}
                required
                disabled={!enabledEdit}
              />
            </Grid>
            <Grid item width={"100%"}>
              {/* Tài liệu đính kèm */}
              <DropPreviewFileUploadComponent
                // dropView={formMode === 'create'}
                preview={formMode === 'update'}
                inputId={'attachmentIds'}
                title={t(`${LABEL_PATH}.attachmentIds`)}
                name={'attachmentIds'}
                files={form.watch('attachmentIds') ?? []}
                setFiles={(files) => {
                  form.setValue(SignApproveFields.ATTACHMENTS, files);
                  form.trigger('attachmentIds')
                }}
                preventOnchange
                disabled={!(enabledEdit || ownRole.includes(VisitationRoles.EVALUATION)) && !evaluationRoleEnabledSaveBtn}
                required
                hasCheckBox
                checkSelected={(file: any) => !!selectionSharePoint?.includes(file?.id)}
                onItemCheck={(file: any) => {
                  let checkedValues = [...selectionSharePoint];
                  if (selectionSharePoint?.includes(file?.id)) {
                    checkedValues = checkedValues?.filter((ele: any) => ele !== file?.id)
                  } else {
                    checkedValues.push(file?.id)
                  }
                  setSelectionSharePoint(checkedValues);
                }}
                selectionId={selectionSignId}
                setSelectedId={(id) => setSelectionSignId(prev => id === prev ? undefined : id)}
                // isSharepoint
                hasRadio
                disableCheckbox={!accessToken}
                maxNumFiles={10}
                accept={ALLOWED_DOCUMENT_TYPE}
                spPermission={checkSharepointPermission}
                spFolder={"Site Visit Management"}
                radioPurpose="DOCUMENT_REVIEW.labels.toAddFileSign"
              />
            </Grid>

            {formMode === 'update'
              && enabledEdit
              && <Grid item width={"100%"}>
                <Button
                  sx={styleBtn}
                  className="confirm"
                  variant="contained"
                  onClick={appendCheckSheet}
                  color="primary">{t('visitation.buttons.addInforSign')}</Button>
              </Grid>}
            {
              checkSheetFields?.fields?.map((checkSheet: any, signIndex) => {
                const isDisableActionSign = checkSheet?.status?.code === VisitationStatusCode.APPROVAL_FINISHED;
                const lastAttachments = checkSheet?.esignFile ?? [];
                return <Grid key={checkSheet?.rowId ?? uniqueId('check_sheet_')} item width={"100%"} sx={{ backgroundColor: 'white' }}>
                  <Grid
                    container
                    direction={"column"}
                    className='form-sub-section-wrapper'
                    rowGap={"0.5rem"}
                    width={'100%'}
                    overflow={'hidden'}
                    sx={{ p: 0, gap: 0 }}
                  >
                    <DropDownItem>
                      <Grid container sx={{ p: 2, pt: 0 }} width={"100%"}>
                        <Grid item width={"100%"} mt={1.5}>
                          <Typography variant='h5'>{t(`${LABEL_PATH}.finalDocuments`)}</Typography>
                          <FilesLatestTable
                            lastAttachments={lastAttachments}
                          />
                        </Grid>
                        <Grid item width={"100%"} mt={1}>
                          <FilesToApproveTableForm
                            control={form?.control}
                            signIndex={signIndex}
                            isShowSignedButton={!evaluationRoleEnabledSaveBtn}
                            disabled={isDisableActionSign || !enabledEdit}
                            selectionId={selectionSignId}
                            signStatus={initialSignApprove?.status}
                            blockSignStatus={checkSheet?.status}
                          />
                        </Grid>
                        <Grid item width={"100%"} mt={1.5}>
                          <Typography variant='h5' sx={{ mb: 1 }}>{t(`visitation.fields.signer`)}</Typography>
                          <ApproversTableForm
                            control={form?.control}
                            signIndex={signIndex}
                            disabled={isDisableActionSign || !enabledEdit}
                          />
                          
                        </Grid>
                        {enabledSignButtons && <Grid
                          item
                          width={"100%"}
                          display={'flex'}
                          justifyContent={'flex-end'}
                          mt={2}
                          flexDirection={'row'} gap={1}>
                          <Button
                            className="cancel"
                            disabled={
                              isDisableActionSign || signStatus?.code === VisitationStatusCode.CALL_ESIGN
                            }
                            variant="contained"
                            onClick={() => handleDeleteSignBlock(signIndex)}
                            color="primary" sx={styleBtn}>{t('common.button.delete')}</Button>
                          <Button
                            variant="contained"
                            className="saveDraft"
                            onClick={() => handleRecallCheckSheet(signIndex)}
                            disabled={
                              isDisableActionSign || signStatus?.code !== VisitationStatusCode.CALL_ESIGN
                            }
                            sx={{ ...styleBtn, backgroundColor: '#E8AE00' }}>{t('visitation.buttons.recall')}</Button>
                          <Button
                            sx={styleBtn}
                            className="confirm"
                            disabled={
                              isDisableActionSign || signStatus?.code === VisitationStatusCode.CALL_ESIGN
                            }
                            variant="contained"
                            onClick={() => handleCallEsign(signIndex)}
                            color="primary">{t('visitation.buttons.callEsign')}</Button>
                        </Grid>}
                      </Grid>
                    </DropDownItem>

                  </Grid>
                  
            
                </Grid>
              })}
          </Grid>
        </Grid >
        {<FormActionButtons
          formMode={formMode}
          onCancel={() => router.back()}
          defaultConfirmPopupState={defaultConfirmPopupState}
          isDisableButonSave={!enabledEdit && !evaluationRoleEnabledSaveBtn}
          onSave={async () => {
            try {
              const params: any = await handleSaveParams();
              handleUpdate(params);
            } catch (error) {}
          }}
        />}
      </form>
    </FormProvider>
    {confirmEsignPopupState.open && <ConfirmPopupWithTextarea {...confirmEsignPopupState} receptionTime={initialValueReceive?.receptionTimeFrom} />}
    {warningSignedPopupState?.open && <WarningSignPopup {...warningSignedPopupState} />}
    <Backdrop
      sx={(theme) => ({ zIndex: theme.zIndex.drawer + 1 })}
      open={isLoadingFull}
    >
      <CircularProgress />
    </Backdrop>
    </>
  )
}

export default SignApproveForm

const styleBtn = { minWidth: "168px" };


interface DropDownItemProps {
  children: ReactNode;
}

const DropDownItem = (props: DropDownItemProps) => {
  const { t } = useTranslation();
  const { children } = props;
  const [visible, setVisible] = useState(true);
  return <>
    <Stack
      onClick={() => setVisible(prev => !prev)}
      direction={'row'} justifyContent={'space-between'} alignItems={'center'} sx={{ mb: 0, padding: '8px 16px', backgroundColor: '#FFE5E5', cursor: 'pointer' }}>
      <Typography variant='h5'>{t(`${LABEL_PATH}.signInformation`)}</Typography>
      {visible ? <ExpandLessRoundedIcon sx={{ color: '#808080' }} />
        : <ExpandMoreRoundedIcon sx={{ color: '#808080' }} />}
    </Stack>
    {visible && children}
  </>
}
