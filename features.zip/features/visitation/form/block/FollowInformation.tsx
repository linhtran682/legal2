import { useGetVisitationFollowList } from "@/apis/service/visitation/visitationApi";
import TextFieldInput from "@/components/commons/inputs/field/TextFieldInput";
import { GLOBAL_SPACING } from "@/constants/format";
import { Box, Grid, IconButton, InputLabel, Typography } from "@mui/material";
import EditNoteRoundedIcon from "@mui/icons-material/EditNoteRounded";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import React, { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import { AppContext } from "@/context/AppContext";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { FollowVisitationForm } from "../../action-popup/follow_form/FollowVisitationForm";
import { VisitationStatusCode } from "@/constants/visitation";
import { useQueryClient } from "@tanstack/react-query";
import { VisitationFollowReceived } from "@/models/visitation/VisitationDetail";
import { toast } from "react-toastify";
import { useDeleteFollowVisitation } from "@/apis/service/visitation/followVisitation";

const actionButtonStyle = {
  position: "absolute",
  right: "9px",
  top: "0",
  zIndex: 10,
};

interface Props {
  form?: any;
  visitationId: number;
  visitation: any;
}

function FollowInformation({ visitationId, visitation }: Props) {
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();
  const { data } = useGetVisitationFollowList(visitationId);
  const [selectedItem, setSelectedItem] = useState<
    VisitationFollowReceived | undefined
  >(undefined);
  const [followPopupVisible, setFollowPopupVisible] = useState(false);
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const checkIsMine = (
    confirmation: VisitationFollowReceived,
    visitation: any
  ) => {
    const isMine = confirmation?.createBy?.id === appContext?.me?.id;
    const code = visitation?.status?.code;

    return isMine && code !== VisitationStatusCode.FINISH;
  };

  const { mutateAsync: deleteFollowVisitationMutationFn } =
    useDeleteFollowVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.delete_success", {
              recordName: t("visitation.followVisitation.title.titlePopup"),
            })
          );
          setConfirmPopupState(DefaultConfirmPopupState);
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
        },
      },
    });

  const onDeleteFollowItem = (item: VisitationFollowReceived) => {
    setConfirmPopupState({
      open: true,
      icon: <DeleteRecordDialogIcon />,
      title: t("common.message.confirm_delete"),
      handleConfirm: async () => {
        await deleteFollowVisitationMutationFn({
          visitationId: visitationId,
          resultId: item?.id,
        });
        setConfirmPopupState(DefaultConfirmPopupState);
      },
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
    });
  };

  return (
    <>
      {data && data.length > 0 && (
        <Grid item width={"100%"}>
          <Grid
            container
            width={"100%"}
            sx={{ backgroundColor: "white" }}
            rowGap={GLOBAL_SPACING}
          >
            <Box sx={{ fontWeight: 700, fontSize: 16 }}>
              {t("visitation.label.inforFollow")}
            </Box>
            {data?.map((item) => (
              <Grid
                key={item.id}
                container
                className="form-sub-section-wrapper"
                rowGap={GLOBAL_SPACING}
                sx={{ position: "relative" }}
              >
                {checkIsMine(item, visitation) && (
                  <Box sx={actionButtonStyle}>
                    <IconButton
                      color="error"
                      size="small"
                      onClick={() => onDeleteFollowItem(item)}
                    >
                      <DeleteOutlineIcon style={{ fontSize: "21px" }} />
                    </IconButton>

                    <IconButton
                      color="primary"
                      size="small"
                      onClick={() => {
                        setFollowPopupVisible(true);
                        setSelectedItem(item);
                      }}
                    >
                      <EditNoteRoundedIcon />
                    </IconButton>
                  </Box>
                )}

                <Grid item xs={12}>
                  <InputLabel sx={{ padding: 0 }}>
                    {t("visitation.label.requestor")}
                  </InputLabel>
                  {item?.createBy && (
                    <Typography>
                      {item?.createBy?.name} ({item?.createBy?.email}) -{" "}
                      {item?.createBy?.department?.name}
                    </Typography>
                  )}
                </Grid>

                <Grid item xs={12}>
                  <TextFieldInput
                    label={t("visitation.label.content")}
                    disabled
                    multiline
                    minRows={3}
                    value={item.content}
                  />
                </Grid>
              </Grid>
            ))}
          </Grid>
        </Grid>
      )}
      {followPopupVisible && (
        <FollowVisitationForm
          setIsOpen={setFollowPopupVisible}
          isOpen={followPopupVisible}
          visitationId={visitationId}
          visitation={visitation}
          followVisitation={selectedItem}
          name={visitation?.name}
          sender={appContext?.me}
        />
      )}

      <ConfirmPopup {...confirmPopupState} />
    </>
  );
}

export default FollowInformation;
