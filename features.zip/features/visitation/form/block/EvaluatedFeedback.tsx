import { useGetVisitationShareInfomation } from '@/apis/service/visitation/visitationApi';
import { COLOR_TYPE } from '@/constants/color';
import { formatDate } from '@/utils';
import { Box, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { ReactNode, useState } from 'react';
import { useTranslation } from 'react-i18next';
// import AddItemButton from './AddItemButton';

interface EvaluatedFeedbackTableColumn {
  key: string;
  label: string;
  width?: string;
  align?: 'left' | 'center' | 'right';
  renderCell?: (params?: any, index?: number) => ReactNode;
}

interface Props {
  visitationId: number;
}
const EvaluatedFeedback = (props: Props) => {
  const { visitationId } = props;
  const { t } = useTranslation();
  const {data} = useGetVisitationShareInfomation(visitationId);

  const [columns] = useState<EvaluatedFeedbackTableColumn[]>([
    {
      key: "no",
      label: "visitation.fields.id",
      width: '50px',
      align: 'center',
      renderCell: (params) => {
        return <span>{params.index + 1}</span>
      }
    },
    {
      key: "department",
      label: "visitation.fields.departmentName",
      // width: '240px',
      renderCell: (params) => {
        return <span>{params.department?.name}</span>
      }
    },
    {
      key: "createBy",
      label: "visitation.fields.receptionName",
      // width: '200px',
      renderCell: (params) => {
        return <span>{params.createBy?.name}</span>
      }
    },
    {
      key: "content",
      label: "visitation.label.content",
      // width: '180px',
    },
    {
      key: "createTime",
      label: "visitation.fields.shareDate",
      // width: '300px',
      renderCell: (params) => {
        return <span>{params?.createTime
          ? formatDate(params?.createTime, "dd/MM/yyyy HH:mm")
          : ""}</span>
      },
    },
  ])

  return (
    <>
      {data && data.length > 0 && (
        <Grid item width={"100%"}>
          <Box sx={{ fontWeight: 700, fontSize: 16, mb: 2 }}>
            {t("visitation.label.reviewOfShareDepartment")}
          </Box>
          <TableContainer
            sx={{
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
              // overflowX: "auto",
              "& .MuiTableCell-root.MuiTableCell-head": {
                backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
                fontFamily:
                  "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
                "&:focus-within": {
                  outline: "none",
                },
                fontWeight: 700,
                border: "1px solid #ccc",
              },
            }}
          >
            <Table size="small">
              <TableHead>
                {columns.map((col, colIndex) => (
                  <TableCell
                    key={`approver_tbl_col_header_${colIndex}`}
                    sx={{
                      width: col?.width,
                      padding: "6px 10px",
                      textAlign: col?.align ?? "left",
                    }}
                  >
                    {t(col.label)}
                  </TableCell>
                ))}
              </TableHead>

              <TableBody>
                {data?.map((row: any, rowIndex: number) => (
                  <TableRow
                    key={row.id}
                    sx={{
                      backgroundColor: "white",
                    }}
                  >
                    {columns.map((col, colIndex) => (
                      <TableCell
                        key={`approver_tbl_col_${colIndex}_row_${rowIndex}`}
                        sx={{
                          padding: "6px 10px",
                          border: "1px solid #e0e0e0", // Add borders for all cells
                          textAlign: col?.align ?? "left",
                        }}
                      >
                        {col?.renderCell
                          ? col?.renderCell?.({ ...row, index: rowIndex })
                          : row?.[col?.key]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      )}
    </>
  );
}

export default EvaluatedFeedback