import { useGetVisitationEvaluatedFeedback } from "@/apis/service/visitation/visitationApi";
import TextFieldInput from "@/components/commons/inputs/field/TextFieldInput";
import { GLOBAL_SPACING } from "@/constants/format";
import { Box, Grid, IconButton, InputLabel, Typography } from "@mui/material";
import EditNoteRoundedIcon from "@mui/icons-material/EditNoteRounded";
import React, { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import PreviewFiles from "@/components/commons/preview/PreviewFiles";
import { EvaluateVisitationForm } from "../../action-popup/evaluate_form/EvaluateVisitationForm";
import { AppContext } from "@/context/AppContext";
import { VisitationEvaluatedFeedBackReceived } from "@/models/visitation/VisitationDetail";
import { VisitationStatusCode } from "@/constants/visitation";

const actionButtonStyle = {
  position: "absolute",
  right: "9px",
  top: "0",
  zIndex: 10,
};

interface Props {
  form?: any;
  visitationId: number;
  visitation: any;
}

function EvaluatedLegalDepartment({ visitationId, visitation }: Props) {
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const { data } = useGetVisitationEvaluatedFeedback({
    request: { id: visitationId },
  });
  const [selectedItem, setSelectedItem] = useState<
    VisitationEvaluatedFeedBackReceived | undefined
  >(undefined);
  const [evaluatePopupVisible, setEvaluatePopupVisible] = useState(false);

  const convertFilesResponse = (attachmentFiles: any[]) => {
    let attachments: any[] = [];
    if (attachmentFiles.length) {
      attachments = attachmentFiles?.map((item: any) => {
        return {
          name: item.fileName,
          path: item.filePath,
          id: item.fileId,
          uploadDate: item.uploadDate,
        };
      });
    }
    return attachments;
  };

  const checkIsMine = (
    evaluatedFeedBack: VisitationEvaluatedFeedBackReceived,
    visitation: any
  ) => {
    const isMine = evaluatedFeedBack?.createBy?.id === appContext?.me?.id;
    const code = visitation?.status?.code;

    return isMine && code !== VisitationStatusCode.FINISH;
  };

  return (
    <>
      {data && data.length > 0 && (
        <Grid item width={"100%"}>
          <Grid
            container
            width={"100%"}
            sx={{ backgroundColor: "white" }}
            rowGap={GLOBAL_SPACING}
          >
            <Box sx={{ fontWeight: 700, fontSize: 16 }}>
              {t("visitation.label.reviewOfLegal")}
            </Box>
            {data?.map((item) => (
              <Grid
                key={item.id}
                container
                className="form-sub-section-wrapper"
                rowGap={GLOBAL_SPACING}
                sx={{ position: "relative" }}
              >
                {checkIsMine(item, visitation) && (
                  <Box sx={actionButtonStyle}>
                    <IconButton
                      color="primary"
                      size="small"
                      onClick={() => {
                        setEvaluatePopupVisible(true);
                        setSelectedItem(item);
                      }}
                    >
                      <EditNoteRoundedIcon />
                    </IconButton>
                  </Box>
                )}

                <Grid item xs={12}>
                  <InputLabel sx={{ padding: 0 }}>
                    {t("visitation.label.reviewer")}{" "}
                  </InputLabel>
                  {item?.createBy && (
                    <Typography>
                      {item?.createBy?.name} ({item?.createBy?.email}) -{" "}
                      {item?.createBy?.department?.name}
                    </Typography>
                  )}
                </Grid>

                <Grid item xs={12}>
                  <TextFieldInput
                    label={t("visitation.label.content")}
                    disabled
                    multiline
                    minRows={3}
                    value={item.content}
                  />
                </Grid>

                <Grid item xs={12}>
                  <PreviewFiles
                    files={convertFilesResponse(item.attachments)}
                  />
                </Grid>
              </Grid>
            ))}
          </Grid>
        </Grid>
      )}

      {evaluatePopupVisible && (
        <EvaluateVisitationForm
          setIsOpen={setEvaluatePopupVisible}
          isOpen={evaluatePopupVisible}
          visitationId={visitationId}
          visitation={visitation}
          name={visitation?.name}
          evaluateVisitation={selectedItem}
          sender={appContext?.me}
          createdBy={visitation?.createdBy}
        />
      )}
    </>
  );
}

export default EvaluatedLegalDepartment;
