import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { GLOBAL_SPACING } from "@/constants/format";
import { Button, Dialog, Grid, Typography } from "@mui/material";
import { ReactNode, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import WarningRoundedIcon from "@mui/icons-material/WarningRounded";

export interface WarningSignPopupProps {
  icon?: ReactNode;
  title?: string;
  open: boolean;
  onClose: () => void;
  reason?: string;
}

export const DefaultWarningPopupState: WarningSignPopupProps = {
  open: false,
  onClose: () => {},
  icon: <></>,
  title: "",
  reason: "",
};

export const WarningSignPopup = ({
  onClose,
  open,
  title,
  reason,
}: WarningSignPopupProps) => {
  const [t] = useTranslation();
  const form = useForm();

  useEffect(() => {
    if (reason) {
      form.reset({
        reason,
      });
    }
  }, [form, reason]);

  return (
    <Dialog open={open}>
      <FormProvider {...form}>
        <form>
          <Grid
            container
            direction={"column"}
            alignItems={"center"}
            spacing={GLOBAL_SPACING}
            padding={"2rem"}
          >
            <Grid item>
              <Typography variant="h5">{title}</Typography>
            </Grid>
            <Grid
              item
              color={"red"}
              width={"100%"}
              sx={{ display: "flex", flex: 1, alignItems: "center" }}
              columnGap={0.5}
            >
              <WarningRoundedIcon sx={{ color: "#FCCA59" }} />
              <Typography component={"span"}>
                {t("visitation.messages.reasonSigned")}
              </Typography>
              <Typography component={"span"} sx={{ fontWeight: 700 }}>
                {t("visitation.messages.equalAfter")}
              </Typography>
              <Typography component={"span"}>
                {t("visitation.messages.visitationDate")}
              </Typography>
            </Grid>
            <Grid item width={"100%"}>
              <Grid
                container
                direction={"row"}
                spacing={GLOBAL_SPACING}
                justifyContent={"center"}
              >
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={"reason"}
                    label={t(`visitation.label.reason`)}
                    placeHolder={""}
                    disabled
                  />
                </Grid>
                <Grid item flex={1}>
                  <Button
                    variant="contained"
                    color="primary"
                    className="close"
                    onClick={onClose}
                    fullWidth
                  >
                    {t("common.button.close")}
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </form>
      </FormProvider>
    </Dialog>
  );
};
