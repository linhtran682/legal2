import { getUser, getUsers } from '@/apis/service/user/User';
import { FormAsyncSelect } from '@/components/commons/form_inputs/FormAsyncSelect';
import { FormTextField } from '@/components/commons/form_inputs/FormTextField';
import { COLOR_TYPE } from '@/constants/color';
import { AppContext } from '@/context/AppContext';
import { LANGUAGES } from '@/locales/config-translation';
import { GetUsersParams, UserProfileDTO } from '@/models/user/User';
import { formatDate } from '@/utils';
import ArrowDownwardRounded from '@mui/icons-material/ArrowDownwardRounded';
import ArrowUpwardRoundedIcon from '@mui/icons-material/ArrowUpwardRounded';
import CheckRoundedIcon from '@mui/icons-material/CheckRounded';
import DragHandleIcon from '@mui/icons-material/DragHandle';
import EditNoteRoundedIcon from '@mui/icons-material/EditNoteRounded';
import { Box, FormHelperText, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { ReactNode, useContext, useEffect, useState } from 'react';
import { useFieldArray, useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
// import AddItemButton from './AddItemButton';

interface LCSApproverTableColumn {
  key: string;
  label: string;
  type: "string" | "number" | "date" | "bool" | "action" | "select";
  width?: string;
  align?: 'left' | 'center' | 'right';
  renderCell?: (params?: any, index?: number) => ReactNode;
  editable?: boolean;
}

interface Props {
  control: any;
  signIndex: number;
  disabled?: boolean;
}
const ApproversTableForm = (props: Props) => {
  const { signIndex, control, disabled } = props;
  const { t, i18n } = useTranslation();
  const [editRowId, setEditRowId] = useState<number>(-1);
  const appContext = useContext(AppContext);
  const [isMeFirstApprover, setIsMeFirstApprover] = useState(false);
  const { getValues, formState, watch } = useFormContext()
  const parentName = `visitationSignInformationRequestList.${signIndex}.visitationSignUserApprovedList`;
  const signerFields = useFieldArray({
    name: parentName,
    control: control,
    keyName: "rowId",
  });
  // const appendApprover = () => {
  //   signerFields.append({ approverId: null, department: '', position: '', note: '', status: 0 })
  // }

  const firstApproverWatch = watch(`${parentName}.0.userId`);

  useEffect(() => {
    if (appContext?.me?.id === firstApproverWatch) {
      setIsMeFirstApprover(true);
    } else {
      setIsMeFirstApprover(false);
    }
  }, [appContext?.me?.id, firstApproverWatch])


  useEffect(() => {
    if (!isMeFirstApprover) {
      const approvers: any[] = getValues(parentName);
      approvers.forEach((approver, index) => {
        if (index !== 0) {
          if (approver?.userId === appContext?.me?.id) {
            signerFields.update(index, {userId: null, department: null, position: null})
          }
        }
      })
    }
  }, [appContext?.me?.id, getValues, isMeFirstApprover, parentName, signerFields])
  
  
  const [columns] = useState<LCSApproverTableColumn[]>([
    {
      key: "move",
      label: "visitation.label.move",
      type: "string",
      width: '90px',
      align: 'center',
    },
    {
      key: "id",
      label: "visitation.label.step",
      type: "string",
      width: '50px',
      align: 'center',
      renderCell: (params) => {
        return <span>{params.index + 1}</span>
      }
    },
    {
      key: "name",
      label: "visitation.label.approvers",
      type: "string",
      width: '300px',
      editable: true
    },
    {
      key: "department",
      label: "visitation.label.department",
      type: "string",
      width: '240px',
    },
    {
      key: "position",
      label: "visitation.label.position",
      type: "string",
      width: '150px',
    },
    {
      key: "processDate",
      label: "visitation.label.processDate",
      type: "string",
      width: '200px',
    },
    {
      key: "status",
      label: "visitation.label.statusId",
      type: "string",
      width: '180px',
    },
    {
      key: "comment",
      label: "visitation.label.comment",
      type: "string",
      width: '300px',
      editable: true
    },
    {
      key: "action",
      label: "",
      type: "string",
      width: '70px',
      renderCell: () => <Box sx={{
        width: '100%',
        height: "100%",
        display: 'flex',
        alignItems: 'center'
      }}>
        <IconButton>
          <EditNoteRoundedIcon fontSize="small" />
        </IconButton>
      </Box>

    },
  ])

  const handleMoveRow = (rowIndex: number, dir: 'up' | 'down') => {

    if ((rowIndex === 0 && dir === 'up')
      || (rowIndex === signerFields.fields.length - 1 && dir === 'down')) {
      return;
    }
    setEditRowId(-1);
    if (dir === 'up') {
      signerFields.swap(rowIndex, rowIndex - 1)
    }
    if (dir === 'down') {
      signerFields.swap(rowIndex, rowIndex + 1)
    }

  }

  const renderRowCell = (column: LCSApproverTableColumn, rowIndex: number) => {

    const currentField: any = signerFields?.fields?.[rowIndex];
    if (column.key === 'dragHandler') {
      return <DragHandleIcon fontSize='small' sx={{ cursor: 'move' }} />
    }
    if (column.key === 'id') {
      return rowIndex + 1
    }
    if (column.key === 'name') {
      return editRowId === rowIndex ?
        (<FormAsyncSelect<any, UserProfileDTO>
          control={control}
          name={`${parentName}.${rowIndex}.userId`}
          label={""}
          minCharLength={1}
          placeholder={t("DOCUMENT_REVIEW.field_name.approvers")}
          getOptions={async (keyword) => {
            if (typeof keyword == "string") {
              const params: GetUsersParams = {
                searchTerm: keyword,
                page: 0,
                size: 100,
                sortBy: "name",
                sortOrder: "ASC",
              };
              const response = await getUsers(params);
              const userList = response?.users ?? [];
              if (!isMeFirstApprover && rowIndex !== 0) {
                return userList.filter(user => user.id !== appContext?.me?.id)
              }
              
              return userList;
            } else if (keyword?.length && keyword.length > 0) {
              return getUser(keyword[0])
                .then((response) => (response ? [response] : []))
                .catch(() => []);
            }

            return [];
          }}
          getOptionLabel={(option) =>
            `${option.name ?? ""} (${option.email ?? ""}) - ${ option?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"] ?? ""
            }`
          }
          onChange={(selectedKey, option) => {
            signerFields.update(
              rowIndex,
              {
                ...signerFields.fields[rowIndex],
                userId: selectedKey ?? null,
                name: option?.name ?? '',
                department: option?.department,
                position: option?.position,
              }
            )
          }}
          getOptionKey={(option) => option.id}
          keyQuery={`lcs/approver/queryUser-${currentField?.rowId}`}
          isFocus={true}
          disabled={editRowId !== rowIndex}
        />)
        : currentField?.name
    }
    if (column.key === 'comment') {
      return editRowId === rowIndex ? (
        <FormTextField
          control={control}
          name={`${parentName}.${rowIndex}.comment`}
          label={""}
          placeHolder={t('DOCUMENT_REVIEW.field_name.comment')}
          disabled={editRowId !== rowIndex}
        />
      )
        : getValues(`${parentName}.${rowIndex}.comment`)
    }
    if (column.key === 'processDate') {
      return !!currentField?.processDate
          ? formatDate(currentField.processDate) : ""
    }
    if (column.key === 'department') {
      return currentField?.department?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"]
    }
    if (column.key === 'position') {
      return currentField?.position?.[i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"]
    }
    if (column.key === 'status') {
      return t(`visitation.signerStatus.${currentField?.status ?? 0}`)
    }
    if (column.key == 'action') {
      return <Box sx={{
        width: '100%',
        height: "100%",
        display: 'flex',
        justifyContent: "center",
        alignItems: 'center'
      }}>
        <IconButton disabled={disabled} onClick={() => setEditRowId(
          editRowId === rowIndex
            ? -1
            : rowIndex
        )}>
          {editRowId === rowIndex
            ? <CheckRoundedIcon fontSize="small" />
            : <EditNoteRoundedIcon fontSize="small" />
          }
        </IconButton>
      </Box>
    }
    if (column.key == 'move') {
      return <Box sx={{
        width: '100%',
        height: "100%",
        display: 'flex',
        justifyContent: "center",
        alignItems: 'center'
      }}>
        <IconButton disabled={disabled} size='small' onClick={() => handleMoveRow(rowIndex, 'up')}>
          <ArrowUpwardRoundedIcon fontSize="small" />
        </IconButton>
        <IconButton disabled={disabled} size='small' onClick={() => handleMoveRow(rowIndex, 'down')}>
          <ArrowDownwardRounded fontSize="small" />
        </IconButton >
      </Box>
    }

    return ''
  }

  const [draggedId, setDraggedId] = useState<any>(null);
  const onDragStart = (e: any, index: number) => {
    setDraggedId(index);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/html", e.target.parentNode);
    e.dataTransfer.setDragImage(e.target.parentNode, 20, 20);
  }

  const onDragOver = (index: number) => {
    if (draggedId === index) {
      return;
    }
    signerFields.swap(draggedId, index)
  }
  const error = (formState.errors as any)
    ?.['visitationSignInformationRequestList']
    ?.[`${signIndex}`]?.["visitationSignUserApprovedList"]

  return (
    <Box
      sx={{ backgroundColor: "white", maxWidth: "100%" }}
    >
      <TableContainer
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          overflowX: "auto",
          "& .MuiTableCell-root.MuiTableCell-head": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
            fontFamily:
              "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
            "&:focus-within": {
              outline: "none",
            },
            fontWeight: 700,
            border: "1px solid #ccc",
          },
        }}
      >
        <Table sx={{ minWidth: '1600px', overflowX: 'auto' }} size="small">
          <TableHead>
            {
              columns.map((col, colIndex) => (
                <TableCell
                  key={`approver_tbl_col_header_${colIndex}`}
                  sx={{
                    width: col?.width,
                    padding: '6px 10px',
                    textAlign: col?.align ?? 'left'
                  }}>{t(col.label)}</TableCell>
              ))
            }
          </TableHead>

          <TableBody>
            {
              signerFields.fields.map((row: any, rowIndex: number) => (
                <TableRow
                  key={row.rowId!}
                  sx={{
                    backgroundColor: 'white',
                  }}
                  onDragOver={() => onDragOver(rowIndex)}

                >
                  {columns.map((col, colIndex) => (
                    <TableCell
                      key={`approver_tbl_col_${colIndex}_row_${rowIndex}`}
                      draggable={col.key === 'dragHandler'}
                      onDragStart={(e) => onDragStart(e, rowIndex)}
                      onClick={() => {
                        if (col?.editable && !disabled) {
                          setEditRowId(rowIndex)
                        }
                      }}
                      sx={{
                        cursor: col?.editable && !disabled ? 'pointer' : 'default',
                        padding: '6px 10px',
                        border: "1px solid #e0e0e0", // Add borders for all cells
                        textAlign: col?.align ?? 'left'
                      }}
                    >
                      {renderRowCell(col, rowIndex)}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            }
          </TableBody>
        </Table>
      </TableContainer>
      {error?.message ? <FormHelperText sx={{ color: "#d32f2f", marginLeft: "14px" }}>
        {t(error?.message as string)}
      </FormHelperText> : null}
    </Box>
  )
}

export default ApproversTableForm