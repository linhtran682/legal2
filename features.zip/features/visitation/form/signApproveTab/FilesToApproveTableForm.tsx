import { visitationConvertPDFServer } from "@/apis/service/visitation/visitationApi";
import { COLOR_TYPE } from "@/constants/color";
import { VisitationStatusCode } from "@/constants/visitation";
import { StatusDTO } from "@/models/status/Status";
import {
  ConvertPdfEnum,
  visitationSignFile,
} from "@/models/visitation/VisitationDetail";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import {
  Box,
  Button,
  CircularProgress,
  FormHelperText,
  IconButton,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { uniqueId } from "lodash";
import { ReactNode, useState } from "react";
import { useFieldArray, useFormContext } from "react-hook-form";
import { useTranslation } from "react-i18next";

interface FileTableColumn {
  key: string;
  label: string;
  type: "string" | "number" | "date" | "bool" | "action" | "select";
  width?: string;
  renderCell?: (params?: any) => ReactNode;
}
interface Props {
  control: any;
  signIndex: number;
  disabled?: boolean;
  selectionId?: number;
  signStatus?: StatusDTO;
  blockSignStatus?: StatusDTO;
  isShowSignedButton?: boolean;
}

const FilesToApproveTableForm = ({
  control,
  signIndex,
  selectionId,
  signStatus,
  blockSignStatus,
  isShowSignedButton = true,
}: Props) => {
  const { t } = useTranslation();
  const [processing, setProcessing] = useState(false);
  const { formState, setValue } = useFormContext();
  const fileFields = useFieldArray({
    name: `visitationSignInformationRequestList.${signIndex}.attachment`,
    control: control,
  });

  const fileIdName = `visitationSignInformationRequestList.${signIndex}.fileId`;

  const { isPending, mutateAsync: convertPDFServerMutateAsync } = useMutation({
    mutationFn: visitationConvertPDFServer,
  });

  const addFileApprove = async () => {
    if (!selectionId) {
      return;
    }
    try {
      setProcessing(true);
      const res = await convertPDFServerMutateAsync({
        id: selectionId,
        type: ConvertPdfEnum.LOCAL,
      });
      if (res) {
        const approveFileItem: visitationSignFile = {
          fileId: res.fileId,
          order: 1,
          fileType: ConvertPdfEnum.LOCAL,
          fileName: res.fileName,
          storagePath: res.storagePath,
        };
        setValue(fileIdName, res.fileId);
        if (fileFields.fields.length === 0) {
          fileFields.append(approveFileItem);
        } else {
          fileFields.update(0, approveFileItem);
        }
      }
    } catch (error) {

    } finally {
      setProcessing(false);
    }
  };

  const onDownloadClick = (e: any, file: any) => {
    e.stopPropagation();
    const a = document.createElement("a");
    a.href = file?.filePath ?? file?.storagePath;
    a.download = file.name;
    a.click();
  };

  const columns: FileTableColumn[] = [
    {
      key: "order",
      label: "LEGISLATION.column.id",
      type: "string",
      width: "52px",
    },
    {
      key: "fileType",
      label: "visitation.label.fileType",
      type: "string",
      width: "150px",
      renderCell: () =>  "Sign",
    },
    {
      key: "fileName",
      label: "visitation.label.file",
      type: "string",
    },
    {
      key: "action",
      label: "",
      type: "string",
      width: "150px",
      renderCell: (params: any) => (
        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <IconButton onClick={(e) => onDownloadClick(e, params)}>
            <FileDownloadOutlinedIcon fontSize="small" />
          </IconButton>
        </Box>
      ),
    },
  ];

  const error = (formState.errors as any)?.["visitationSignInformationRequestList"]?.[
    `${signIndex}`
  ]?.["fileId"];

  return (
    <Box
      sx={{
        backgroundColor: "white",
        maxWidth: "100%",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Stack
        display={"flex"}
        direction={"row"}
        flexWrap={"wrap"}
        alignItems={"center"}
        justifyContent={"space-between"}
        mb={1}
      >
        <Typography variant="h5">
          {t(`visitation.label.filesToApprove`)}
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center" }}>
          {processing ? <CircularProgress size={16} sx={{ mx: 2 }} /> : null}
          {isShowSignedButton && <Button
            sx={{
              minWidth: 168,
            }}
            className="confirm"
            variant="contained"
            onClick={addFileApprove}
            disabled={
              !selectionId ||
              isPending ||
              signStatus?.code === VisitationStatusCode.CALL_ESIGN ||
              blockSignStatus?.code ===
                VisitationStatusCode.APPROVAL_FINISHED ||
              processing
            }
            color="primary"
          >
            {fileFields.fields?.length > 0
              ? t(`visitation.label.updateApproveFile`)
              : t(`visitation.label.addApproveFile`)}
          </Button>}
        </Box>
      </Stack>

      <TableContainer
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          overflowX: "auto",
          "& .MuiTableCell-root.MuiTableCell-head": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
            fontFamily:
              "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
            "&:focus-within": {
              outline: "none",
            },
            fontWeight: 700,
            border: "1px solid #ccc",
          },
        }}
      >
        <Table
          sx={{ width: "100%", minWidth: "850px", overflowX: "auto" }}
          size="small"
        >
          <TableHead>
            {columns.map((col) => (
              <TableCell
                key={uniqueId("col_header_")}
                sx={{ width: col?.width }}
              >
                {t(col.label)}
              </TableCell>
            ))}
          </TableHead>
          <TableBody>
            {fileFields.fields
              ?.filter((item: any) => !item.toBeSigned)
              ?.map((row: any, rowIndex: number) => (
                <TableRow key={uniqueId("row_")}>
                  {columns.map((col) => (
                    <TableCell
                      key={uniqueId("cell_")}
                      sx={{
                        border: "1px solid #e0e0e0", // Add borders for all cells
                      }}
                    >
                      {col?.renderCell
                        ? col?.renderCell?.({ ...row, index: rowIndex })
                        : row?.[col?.key]}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>

      {error?.message ? (
        <FormHelperText sx={{ color: "#d32f2f", marginLeft: "14px" }}>
          {t(error?.message as string, {
            fieldName: t("visitation.label.filesToApprove")?.toLowerCase(),
          })}
        </FormHelperText>
      ) : null}
    </Box>
  );
};

export default FilesToApproveTableForm;
