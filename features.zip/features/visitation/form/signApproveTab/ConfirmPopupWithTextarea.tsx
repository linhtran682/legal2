import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { GLOBAL_SPACING } from "@/constants/format";
import { VALIDATION_MSG } from "@/constants/message";
import { VisitationConfirmForm } from "@/models/visitation/VisitationDetail";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Dialog,
  Grid,
  Typography,
} from "@mui/material";
import { ReactNode, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import * as Yup from "yup";
import WarningRoundedIcon from "@mui/icons-material/WarningRounded";
import moment from "moment";

export interface ConfirmPopupWithTextareaProps {
  icon?: ReactNode;
  title?: string;
  open: boolean;
  handleCancel: () => void;
  handleConfirm?: (formData: VisitationConfirmForm) => void;
  loading?: boolean;
  receptionTime?: string;
}

export const DefaultConfirmPopupState: ConfirmPopupWithTextareaProps = {
  open: false,
  handleConfirm: () => {},
  handleCancel: () => {},
  icon: <></>,
  title: "",
};

export const ConfirmPopupWithTextarea = ({
  handleCancel,
  handleConfirm,
  open,
  title,
  receptionTime = "",
  loading,
}: ConfirmPopupWithTextareaProps) => {
  const [t] = useTranslation();
  // const [content, setContent] = useState("");

  const form = useForm({
    resolver: yupResolver(
      Yup.object().shape({
        isWarning: Yup.boolean(),
        reason: Yup.string().when("isWarning", {
          is: (isWarning: boolean) => isWarning,
          then: () => Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
          otherwise: () => Yup.string().optional(),
        }),
        content: Yup.string().optional(),
      })
    ),
    mode: "onSubmit",
  });
  const isWarningWatch = form.watch("isWarning");

  useEffect(() => {
    if (receptionTime) {
      const currentDate = moment().format("yyyy-MM-DD");
      const diff = moment(currentDate).isSameOrAfter(receptionTime, "day");
      form.reset({
        isWarning: diff,
      });
    } else {
      form.reset({
        isWarning: false,
      });
    }
  }, [form, receptionTime]);

  const handleSubmit = async() => {
    const noError = await form.trigger();
    if (!noError) return;

    const formData = form.getValues();
    handleConfirm?.({
      reason: formData.reason,
      content: formData.content,
    })
    form.reset({
      reason: "",
      content: "",
    });
  };

  return (
    <Dialog open={open}>
      <FormProvider {...form}>
        <form>
          <Grid
            container
            direction={"column"}
            alignItems={"center"}
            spacing={GLOBAL_SPACING}
            padding={"2rem"}
          >
            <Grid item>
              <Typography variant="h5">{title}</Typography>
            </Grid>
            {isWarningWatch && (
              <Grid
                item
                color={"red"}
                width={"100%"}
                sx={{ display: "flex", flex: 1, alignItems: "center" }}
                columnGap={0.5}
              >
                <WarningRoundedIcon sx={{ color: "#FCCA59" }} />
                <Typography component={"span"}>
                  {t("visitation.messages.reasonSigned")}
                </Typography>
                <Typography component={"span"} sx={{ fontWeight: 700 }}>
                  {t("visitation.messages.equalAfter")}
                </Typography>
                <Typography component={"span"}>
                  {t("visitation.messages.visitationDate")}
                </Typography>
              </Grid>
            )}
            <Grid item width={"100%"}>
              <Grid
                container
                direction={"row"}
                spacing={GLOBAL_SPACING}
                justifyContent={"center"}
              >
                {isWarningWatch && (
                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={"reason"}
                      label={t(`visitation.label.reason`)}
                      placeHolder={t(`visitation.label.reason`)}
                      required
                    />
                  </Grid>
                )}
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={"content"}
                    label={t(`visitation.label.contentCallEsign`)}
                    placeHolder={t(`visitation.label.contentCallEsign`)}
                    // required
                  />
                </Grid>
                <Grid item flex={1}>
                  <Button
                    variant="contained"
                    color="primary"
                    className="cancel"
                    onClick={handleCancel}
                    fullWidth
                  >
                    {t("common.button.cancel")}
                  </Button>
                </Grid>
                <Grid item flex={1}>
                  <Button
                    onClick={handleSubmit}
                    variant="contained"
                    className="confirm"
                    fullWidth
                    disabled={loading}
                  >
                    {t("common.button.send")}
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </form>
      </FormProvider>
    </Dialog>
  );
};
