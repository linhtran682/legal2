import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import { COLOR_TYPE } from '@/constants/color';
import useObserveElementSize from '@/hooks/useObserveElementSize';
import { VisitationBodyReceive } from '@/models/visitation/VisitationDetail';
import { Box } from '@mui/material';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface OverviewHeaderProps {
  initialValueReceive?: VisitationBodyReceive;
  isMeeting?: boolean;
  disabled?: boolean;
  handleUpdateBookMeeting?: (params: any) => void;
  isLoading?: boolean;
  scrollToTab: (tab: number) => void;
}
const OverviewHeader = (props: OverviewHeaderProps) => {
  const { t } = useTranslation();
  const [isBooked, setIsBooked] = useState(false);
  const {scrollToTab} = props;

  useEffect(() => {
    if (props.initialValueReceive) {
      setIsBooked(!!props?.initialValueReceive?.isBookingFlag);
    }
  }, [props.initialValueReceive]);

  const { elementRef, size } = useObserveElementSize();

  const responsiveSx = {
    minWidth: 170,
    flex: 1
  }

  const renderCheckboxConfirm = () => {
    switch (props.initialValueReceive?.isConfirmAll) {
      case null:
        return <CheckboxInput
        borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
        checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
        disabled
        checked={false}
        label={`${t("visitation.label.confirm")}
        ${(props.initialValueReceive?.totalConfirm ?? 0) > 0
            ? ` (${props.initialValueReceive?.totalUserConfirm ?? 0}/${props.initialValueReceive?.totalConfirm ?? 0})`
            : ""
          }`}
      /> 
      case true:
        return <CheckboxInput
        borderColor={COLOR_TYPE.SUCCESS.GREEN11}
        checkboxBg={COLOR_TYPE.SUCCESS.GREEN11}
        disabled
        checked
        label={`${t("visitation.label.confirm")}
        ${(props.initialValueReceive?.totalConfirm ?? 0) > 0
            ? ` (${props.initialValueReceive?.totalUserConfirm ?? 0}/${props.initialValueReceive?.totalConfirm ?? 0})`
            : ""
          }`}
      />;
      case false:
        return <CheckboxInput
        borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
        checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA1}
        disabled
        isSuccess={false}
        checked
        label={`${t("visitation.label.confirm")}
        ${(props.initialValueReceive?.totalConfirm ?? 0) > 0
            ? ` (${props.initialValueReceive?.totalUserConfirm ?? 0}/${props.initialValueReceive?.totalConfirm ?? 0})`
            : ""
          }`}
      /> 
      default:
        return ""
    }
  }

  return (
    <Box
      ref={elementRef}
      sx={{
        display: size.width <= 880 ? 'grid' : 'flex',
        p: 2, backgroundColor: 'white',
        mb: 2,
        gridTemplateColumns: `repeat(auto-fill, minmax(170px, 1fr))`
      }}
    >
      {/* <Stack sx={{ p: 2, backgroundColor: 'white', mb: 2, flexWrap: "wrap" }} direction={"row"} columnGap={3}> */}
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          labelColor={COLOR_TYPE.BLUE.BLUE6}
          checked={isBooked}
          disabled
          // label={t("visitation.label.meeting")}
          label={`${t("visitation.label.meeting")}
          ${(props.initialValueReceive?.totalBooking ?? 0) > 0
              ? ` (${props.initialValueReceive?.totalBooking})`
              : ""
            }`}
          onLabelClick={() => scrollToTab(9)}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        {renderCheckboxConfirm()}
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          disabled
          checked={!!props.initialValueReceive?.isLCEvaluateFlag}
          label={t('visitation.label.lcEvaluate')}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.isFinishSignFlag}
          disabled
          label={t('visitation.label.finishedSign')}
        />
      </Box>
      {/* </Stack > */}
    </Box>
  )
}

export default OverviewHeader