import { getUser, getUsers } from "@/apis/service/user/User";
import { getAsyncSelectOperators } from "@/components/commons/filters/AsyncSelectFilter";
import { getMultipleAsyncChoosingOperators } from "@/components/commons/filters/MultipleAsyncChoosingFilter";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import MultipleTabsTable from "@/components/commons/tables/multiple_tabs_table/MultipleTabsTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import { MIME_TYPES } from "@/constants/general";
import { UI_PATH, VISITATION_ROOT_PATH } from "@/constants/paths";
import { StatusDTO } from "@/models/status/Status";
import { GetUsersParams } from "@/models/user/User";
import { downloadFile, formatDate } from "@/utils";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { Button, Grid, IconButton } from "@mui/material";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { endOfDay, format } from "date-fns";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { Range as DateRange } from "react-date-range";
import moment from "moment";
import {
  getListVisitationQueryFn,
  getStatusVisitationQueryFn,
  getVisitationExcel,
  shareVisitationFn,
} from "@/apis/service/visitation/visitationApi";
import { GetVisitationListParams } from "@/models/visitation/VisitationList";
import {
  VisitationDetailFields,
  VisitationStatusEnum,
} from "@/models/visitation/VisitationDetail";
import { VisitationTableActions } from "./VisitationTableActions";
import { URL_OUTLOOK } from "@/constants/constraint";
import SendMailVisitationForm from "../action-popup/send_mail_form/SendMailVisitationForm";
import { ForwardVisitationForm } from "../action-popup/forward_form/ForwardVisitationForm";
import { FeedBackVisitationForm } from "../action-popup/feedback_form/FeedBackVisitationForm";
import { AppContext } from "@/context/AppContext";
import { useRecallVisitation } from "@/apis/service/visitation/recallVisitation";
import { ShareInfoVisitationForm } from "../action-popup/share_info_form/ShareInfoVisitationForm";
import { FeedbackShareInfoVisitationForm } from "../action-popup/feedback_share_info_form/FeedbackShareInfoVisitationForm";
import { VisitationActionsBtnKey } from "@/constants/visitation";
import { ConfirmVisitationForm } from "../action-popup/confirm_form/ConfirmVisitationForm";
import { RequestEvaluateVisitationForm } from "../action-popup/request_evaluate_form/RequestEvaluateVisitationForm";
import { EvaluateVisitationForm } from "../action-popup/evaluate_form/EvaluateVisitationForm";
import { RequestSignVisitationForm } from "../action-popup/request_sign_form/RequestSignVisitationForm";
import { SignVisitationForm } from "../action-popup/sign_form/SignVisitationForm";
import { ReceptionVisitationForm } from "../action-popup/reception_form/ReceptionVisitationForm";
import { ReceptionResultVisitationForm } from "../action-popup/reception_result_form/ReceptionResultVisitationForm";
import { FollowVisitationForm } from "../action-popup/follow_form/FollowVisitationForm";
import { FinishVisitationForm } from "../action-popup/finish_form/FinishVisitationForm";
import { RequestAddInfoVisitationForm } from "../action-popup/request_add_info_form/RequestAddInfoVisitationForm";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import { TimeExtensionVisitationForm } from "../action-popup/time_extension_form/TimeExtensionVisitationForm";
import { TimeExtensionVisitationType } from "@/models/visitation/TimeExtensionVisitation";
import { useAdditionalInformationVisitation } from "@/apis/service/visitation/additionalInformationVisitation";
import { AssignmentVisitationForm } from "../action-popup/assignment_form/AssignmentVisitationForm";

export const VisitationTableConst = {
  GENERAL_TABLE: "visitation.title.general_table",
  GET_ALL_QUERY_KEY: "getAllVisitation",
  PERSONAL_TABLE: "visitation.title.personal_table",
  GET_PERSONAL_QUERY_KEY: "getPersonalVisitation",
  GET_visitation_EXCEL: "getVisitationExcel",
};

const getFieldLabel = (key: string) => {
  return `visitation.fields.${key}`;
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetVisitationListParams => {
  const params: GetVisitationListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 10,
    sortBy: VisitationDetailFields.ID,
    orderBy: "DESC",
  };
  (tableState.filterModel?.items || []).forEach((item: any) => {
    if (item.field == VisitationDetailFields.RECEPTION_IDS && item?.value) {
      params[VisitationDetailFields.RECEPTION_IDS] = item?.value;
    }
    if (item.field == VisitationDetailFields.POSITION) {
      params[VisitationDetailFields.POSITION] = item?.value;
    }
    if (item.field == VisitationDetailFields.DEPARTMENT) {
      params[VisitationDetailFields.DEPARTMENT] = item?.value;
    }

    if (item.field == VisitationDetailFields.VISITATION_STATUS) {
      params.status = (item?.value ?? [])
        .map((item: StatusDTO) => item?.id ?? item)
        .join(",");
    }
    if (item.field == VisitationDetailFields.CONFIRM_DEADLINE) {
      params[VisitationDetailFields.CONFIRM_DEADLINE_FROM] = (
        item?.value as DateRange
      ).startDate?.toISOString();

      params[VisitationDetailFields.CONFIRM_DEADLINE_TO] = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }

    if (item.field == VisitationDetailFields.RESPONSE_LC_DEADLINE) {
      params.evaluationDeadlineFrom = (
        item?.value as DateRange
      )?.startDate?.toISOString();

      params.evaluationDeadlineTo = endOfDay(
        new Date((item.value as DateRange)?.endDate as Date)
      )?.toISOString();
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};

const VisitationTable = () => {
  const { t, i18n } = useTranslation();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<number>(0);
  const router = useRouter();
  const appContext = useContext(AppContext);
  const [initialVisitation, setInitialVisitation] = useState<any>(undefined);
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload: boolean = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));

    if (!state) {
      setInitialVisitation(undefined);
    }

    if (reload) {
      queryClient.invalidateQueries({
        queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
      });
      queryClient.invalidateQueries({
        queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
      });
    }
  };

  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialVisitation(row);
      changePopupVisible(type, true);
    }
  };

  const { mutateAsync: recallVisitation } = useRecallVisitation({
    config: {
      onSuccess: () => {
        toast.success(t("visitation.recallVisitation.message.recall_success"));
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
        });
        queryClient.invalidateQueries({
          queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
        });
      },
    },
  });

  const { mutateAsync: additionalInformationVisitation } =
    useAdditionalInformationVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t(
              "visitation.additionalInformationVisitation.message.additionalInformationSuccess"
            )
          );
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
          });
          queryClient.invalidateQueries({
            queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
          });
        },
      },
    });

  const shareMutation = useMutation({
    mutationFn: shareVisitationFn,
    onSuccess: () => {
      toast.success(t(`visitation.messages.shareSuccess`));
    },
  });

  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [conflictManagementTableColumns] = useState<
    MultipleFilterTableColumn[]
  >([
    {
      key: VisitationDetailFields.ID,
      label: VisitationDetailFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: "center",
    },
    {
      key: VisitationDetailFields.NAME,
      label: VisitationDetailFields.NAME,
      type: "string",
      quickFilter: false,
      sortable: false,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => (
        // <VisitationTableTooltip
        //   adviceId={params.id}
        //   adviceName={params?.row?.conflictName}
        // >
        <span>{params.value}</span>
        // </VisitationTableTooltip>
      ),
    },
    {
      key: VisitationDetailFields.RECEPTION_IDS,
      label: VisitationDetailFields.RECEPTION_ID,
      filterLabel: "visitation.label.reception",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => {
        return params?.row?.receptionUser?.employeeCode;
      },
      filterOperators: getAsyncSelectOperators(
        {
          getOptions: async (keyword) => {
            if (typeof keyword == "string") {
              const params: GetUsersParams = {
                searchTerm: keyword as string,
                page: 0,
                size: 100,
                sortBy: "name",
                sortOrder: "ASC",
              };
              const response = await getUsers(params);

              return response?.users ?? [];
            } else if (keyword?.length && keyword.length > 0) {
              return getUser(keyword[0])
                .then((response) => (response ? [response] : []))
                .catch(() => []);
            }
            return [];
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) =>
            `${item?.name} - ${
              item?.position?.name ? `${item?.position?.name}.` : ""
            }${item?.department?.name ?? ""}`,
          keyQuery: VisitationDetailFields.RECEPTION_ID,
        },
        t
      ),
    },
    {
      key: VisitationDetailFields.RECEPTION_NAME,
      label: VisitationDetailFields.RECEPTION_NAME,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => {
        return params?.row?.receptionUser?.name ?? "";
      },
    },
    {
      key: VisitationDetailFields.POSITION,
      label: VisitationDetailFields.POSITION,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.position,
    },
    {
      key: VisitationDetailFields.DEPARTMENT,
      label: VisitationDetailFields.DEPARTMENT,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.department,
    },
    {
      key: VisitationDetailFields.FIELD,
      label: VisitationDetailFields.FIELD,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.field ?? "",
    },
    {
      key: VisitationDetailFields.ORGANIZATION_NAME,
      label: VisitationDetailFields.ORGANIZATION_NAME,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.organizationName ?? "",
    },
    {
      key: VisitationDetailFields.VISITATION_STATUS,
      label: VisitationDetailFields.VISITATION_STATUS,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: false,
      minWidth: 240,
      renderCell: (params) => {
        const status = params?.row?.isDraft ? t("common.label.draft") : params.value?.name
        return (
          <Button
            variant="outlined"
            style={{
              background:
              status === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
              status === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {status}
          </Button>
        );
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusVisitationQueryFn();
            const status = response?.statusResponses || [];
            const options = status.filter((option) =>
              option.tab?.includes(VisitationStatusEnum.VISITATION)
            );
            return options;
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) => item?.name,
          keyQuery: `visitation-management-${VisitationDetailFields.VISITATION_STATUS}`,
        },
        t
      ),
    },
    {
      key: VisitationDetailFields.RECEPTION_TIME,
      label: VisitationDetailFields.RECEPTION_TIME,
      filterLabel: `visitation.label.${VisitationDetailFields.RECEPTION_TIME}`,
      type: "date",
      quickFilter: false,
      filterable: false,
      sortable: false,
      minWidth: 220,
      renderCell: (params) =>
        params.row.receptionTimeFrom
          ? `${formatDate(params.row.receptionTimeFrom)} - ${formatDate(
              params.row.receptionTimeTo
            )}`
          : "",
    },
    {
      key: VisitationDetailFields.CONFIRM_DEADLINE,
      label: VisitationDetailFields.CONFIRM_DEADLINE,
      filterLabel: `visitation.label.${VisitationDetailFields.CONFIRM_DEADLINE}`,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: false,
      minWidth: 160,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
    },
    {
      key: VisitationDetailFields.RESPONSE_LC_DEADLINE,
      label: VisitationDetailFields.RESPONSE_LC_DEADLINE,
      filterLabel: `visitation.label.${VisitationDetailFields.RESPONSE_LC_DEADLINE}`,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: false,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
    },
    {
      key: VisitationDetailFields.CREATED_BY,
      label: VisitationDetailFields.CREATED_BY,
      filterLabel: `visitation.label.${VisitationDetailFields.CREATED_BY}`,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: true,
      minWidth: 270,
      renderCell: (params) =>
        params.row?.createdBy
          ? `${params.row?.createdBy?.name} - ${params.row?.createdBy?.department?.name}`
          : "",
    },
    {
      key: VisitationDetailFields.ACTION,
      label: VisitationDetailFields.ACTION,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "last-column-sticky",
      headerClassName: "last-column-sticky-header",
      renderCell: (params) => {
        return VisitationTableActions({
          params,
          handleClickRecall: async () => {
            await recallVisitation(Number(params?.id));
          },
          handleClickSendMail: () =>
            handleClick(VisitationActionsBtnKey.SEND_MAIL, params?.row),
          handleClickForWard: () =>
            handleClick(VisitationActionsBtnKey.FORWARD, params?.row),
          handleClickFeedBack: () =>
            handleClick(VisitationActionsBtnKey.FEEDBACK, params?.row),
          handleClickRequestMeeting: () => {
            window.open(URL_OUTLOOK, "_blank");
          },
          handleClickRequestInformation: () =>
            handleClick(
              VisitationActionsBtnKey.INFORMATION_REQUEST,
              params?.row
            ),
          handleClickAdditionalInformation: async () => {
            await additionalInformationVisitation(Number(params?.id));
          },
          handleClickRequestShareInfo: () =>
            handleClick(
              VisitationActionsBtnKey.SHARE_INFO_REQUEST,
              params?.row
            ),
          handleClickFeedbackShareInfo: () =>
            handleClick(
              VisitationActionsBtnKey.SHARE_INFO_FEEDBACK,
              params?.row
            ),
          handleClickShare: () =>
            handleClick(VisitationActionsBtnKey.SHARE, params?.row),
          handleClickConfirm: () =>
            handleClick(VisitationActionsBtnKey.CONFIRM_APPROVED, params?.row),
          handleClickRequestEvaluate: () =>
            handleClick(VisitationActionsBtnKey.EVALUATE_REQUEST, params?.row),
          handleClickAssignment: () =>
            handleClick(VisitationActionsBtnKey.ASSIGNMENT, params?.row),
          handleClickConfirmEvaluateFeedback: () =>
            handleClick(
              VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
              params?.row
            ),
          handleClickRequestSign: () =>
            handleClick(VisitationActionsBtnKey.REQUEST_SIGN, params?.row),
          handleClickSign: () =>
            handleClick(VisitationActionsBtnKey.SIGN, params?.row),
          handleClickRejectSign: () =>
            handleClick(VisitationActionsBtnKey.SIGN_REJECT, params?.row),
          handleClickReception: () =>
            handleClick(VisitationActionsBtnKey.RECEPTION, params?.row),
          handleClickReceptionResult: () =>
            handleClick(VisitationActionsBtnKey.RECEPTION_RESULT, params?.row),
          handleClickExtendTime: () =>
            handleClick(
              VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
              params?.row
            ),
          handleClickExtendTimeShareInfo: () =>
            handleClick(
              VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
              params?.row
            ),
          handleClickExtendTimeResponseLc: () =>
            handleClick(
              VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
              params?.row
            ),
          handleClickFollow: () =>
            handleClick(VisitationActionsBtnKey.FOLLOW, params?.row),
          handleClickFinish: () =>
            handleClick(VisitationActionsBtnKey.FINISH, params?.row),
        });
      },
    },
  ]);

  /** Get all visitation */
  const getAllVisitationQuery = useQuery({
    queryKey: [VisitationTableConst.GET_ALL_QUERY_KEY],
    queryFn: () =>
      getListVisitationQueryFn({
        ...castTableStateToParams(generalTableState),
        tab: 0,
      }),
    enabled: false,
  });

  /** Get personal visitation request */
  const getPersonalVisitationQuery = useQuery({
    queryKey: [VisitationTableConst.GET_PERSONAL_QUERY_KEY],
    queryFn: () =>
      getListVisitationQueryFn({
        ...castTableStateToParams(personalTableState),
        tab: 1,
      }),
    enabled: false,
  });

  useEffect(() => {
    generalTableState &&
      activeTab === 0 &&
      getAllVisitationQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  }, [generalTableState, activeTab]);

  useEffect(() => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalVisitationQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  }, [personalTableState, activeTab]);

  /** Get excel file */
  const getVisitationQuery = useQuery({
    queryKey: [VisitationTableConst.GET_visitation_EXCEL],
    queryFn: () =>
      getVisitationExcel({
        ...castTableStateToParams(
          activeTab === 0 ? generalTableState : personalTableState
        ),
        tab: activeTab,
        size: 9999,
        isEnglish: i18n.language === "en",
      }),
    enabled: false,
  });

  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getVisitationQuery.refetch().then((response: any) => {
              const fileName = `${
                i18n.language === "en" ? "ReceptionManager" : "Quản lý tiếp đón"
              }_${format(new Date(), "ddMMyyyy")}`;
              response?.data &&
                downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getAllVisitationQuery.isFetching ||
            getPersonalVisitationQuery.isFetching ||
            getVisitationQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };

  return (
    <>
      <MultipleTabsTable
        tableTabs={[
          {
            tabName: t("visitation.label.allVisitation"),
            tabKey: VisitationTableConst.GENERAL_TABLE,
            data: getAllVisitationQuery?.data?.data ?? [],
            loading: getAllVisitationQuery?.isFetching,
            rowCount: getAllVisitationQuery?.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t("visitation.label.myVisitation"),
            tabKey: VisitationTableConst.PERSONAL_TABLE,
            data: getPersonalVisitationQuery?.data?.data ?? [],
            loading: getPersonalVisitationQuery?.isFetching,
            rowCount: getPersonalVisitationQuery?.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={conflictManagementTableColumns.map((column) => ({
          ...column,
          label: column.label ? getFieldLabel(column.label) : "",
        }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        quickFilterProps={{
          defaultSelectedOptionKey: VisitationDetailFields.NAME,
          placeHolder: () => t("visitation.placeholder.enterVisitationName"),
        }}
        onRowClick={(params) =>
          router.push(`/${VISITATION_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`)
        }
        exportFile={renderExportButton()}
        onTabChange={setActiveTab}
      />

      {popupVisibleState?.[VisitationActionsBtnKey.SEND_MAIL] && (
        <SendMailVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.SEND_MAIL, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.SEND_MAIL]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FORWARD] && (
        <ForwardVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FORWARD, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FORWARD]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FEEDBACK] && (
        <FeedBackVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FEEDBACK, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FEEDBACK]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.INFORMATION_REQUEST] && (
        <RequestAddInfoVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.INFORMATION_REQUEST,
              state
            )
          }
          isOpen={
            popupVisibleState?.[VisitationActionsBtnKey.INFORMATION_REQUEST]
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_REQUEST] && (
        <ShareInfoVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.SHARE_INFO_REQUEST,
              state
            )
          }
          isOpen={
            popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_REQUEST]
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          deadline={
            initialVisitation?.shareInformationDeadline
              ? moment
                  .utc(initialVisitation?.shareInformationDeadline)
                  .local()
                  .toDate()
              : moment(new Date())
                  .add(3 * 24, "hours")
                  .toDate()
          }
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_FEEDBACK] && (
        <FeedbackShareInfoVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.SHARE_INFO_FEEDBACK,
              state
            )
          }
          isOpen={
            popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_FEEDBACK]
          }
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(VisitationActionsBtnKey.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialVisitation?.createdBy}
          onSubmit={async (data: any) => {
            const params = {
              id: initialVisitation?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.CONFIRM_APPROVED] && (
        <ConfirmVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.CONFIRM_APPROVED, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.CONFIRM_APPROVED]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          createdBy={initialVisitation?.createdBy}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.EVALUATE_REQUEST] && (
        <RequestEvaluateVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.EVALUATE_REQUEST, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.EVALUATE_REQUEST]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          staffLCUsers={initialVisitation?.staffLCUsers}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.ASSIGNMENT] && (
        <AssignmentVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.ASSIGNMENT, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.ASSIGNMENT]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM
      ] && (
        <EvaluateVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM
            ]
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.REQUEST_SIGN] && (
        <RequestSignVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.REQUEST_SIGN, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.REQUEST_SIGN]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SIGN] && (
        <SignVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.SIGN, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.SIGN]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.RECEPTION] && (
        <ReceptionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.RECEPTION, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.RECEPTION]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.RECEPTION_RESULT] && (
        <ReceptionResultVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.RECEPTION_RESULT, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.RECEPTION_RESULT]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE
      ] && (
        <TimeExtensionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE
            ]
          }
          timeExtensionVisitationType={
            TimeExtensionVisitationType.CONFIRM_DEADLINE
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE
      ] && (
        <TimeExtensionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey
                .REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE
            ]
          }
          timeExtensionVisitationType={
            TimeExtensionVisitationType.SHARE_INFORMATION_DEADLINE
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE
      ] && (
        <TimeExtensionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE
            ]
          }
          timeExtensionVisitationType={
            TimeExtensionVisitationType.RESPONSE_LC_DEADLINE
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FOLLOW] && (
        <FollowVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FOLLOW, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FOLLOW]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FINISH] && (
        <FinishVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FINISH, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FINISH]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}
    </>
  );
};

export default VisitationTable;
