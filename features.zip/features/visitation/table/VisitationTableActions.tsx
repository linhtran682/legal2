import React, { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";
import { IconFeedback } from "@/assets/iconMenu/IconFeedback";
import { IconForward } from "@/assets/iconMenu/IconForward";
import { IconRequestMeeting } from "@/assets/iconMenu/IconRequestMeeting";
import { IconSendMail } from "@/assets/iconMenu/IconSendMail";
import { IconRecall } from "@/assets/iconMenu/IconRecall";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";
import {
  ActionButtonCustom,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButtonCustom";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { COLOR_TYPE } from "@/constants/color";
import { TypeActionRole } from "@/constants/general";
import { IconRequestAdditional } from "@/assets/iconMenu/IconRequestAdditional";
import { IconRequestEvaluate } from "@/assets/iconMenu/IconRequestEvaluate";
import IconShare from "@/assets/iconMenu/IconShare";
import { IconDone } from "@/assets/iconMenu/IconDone";
import { IconNextAction } from "@/assets/iconMenu/IconNextAction";
import { IconRequestConfirm } from "@/assets/iconMenu/IconRequestConfirm";
import { IconFeedbackAdvise } from "@/assets/iconMenu/IconFeedbackAdvise";
import {
  authorizedActionMapCallBackListVisitation,
  authorizedInforVisitationActionMapCallBack,
  authorizedSignActionMapCallBack,
  VisitationActionsBtnKey,
  VisitationStatusCode,
  VisitationUserRole,
  VisitationUserRoleKey,
} from "@/constants/visitation";
import { useMutation } from "@tanstack/react-query";
import {
  requestReviewAgain,
  requestSignAgain,
} from "@/apis/service/visitation/visitationApi";
import { toast } from "react-toastify";
import router from "next/router";
import { VISITATION_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { IconAssignment } from "@/assets/iconMenu/IconAssignment";

const BUTTONS_ORDER_BY: string[] = [
  VisitationActionsBtnKey.RECALL,
  VisitationActionsBtnKey.SEND_MAIL,
  VisitationActionsBtnKey.FORWARD,
  VisitationActionsBtnKey.FEEDBACK,
  VisitationActionsBtnKey.MEETING,
  VisitationActionsBtnKey.SHARE,
  VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
  VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
  VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
  VisitationActionsBtnKey.SHARE_INFO_REQUEST,
  VisitationActionsBtnKey.SHARE_INFO_FEEDBACK,
  VisitationActionsBtnKey.ADDITIONAL_INFORMATION,
  VisitationActionsBtnKey.CONFIRM_APPROVED,
  VisitationActionsBtnKey.ASSIGNMENT,
  VisitationActionsBtnKey.INFORMATION_REQUEST,
  VisitationActionsBtnKey.REQUEST_SIGN,
  VisitationActionsBtnKey.SIGN,
  VisitationActionsBtnKey.SIGN_REJECT,
  VisitationActionsBtnKey.EVALUATE_REQUEST,
  VisitationActionsBtnKey.ASSIGNMENT,
  VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
  VisitationActionsBtnKey.RECEPTION,
  VisitationActionsBtnKey.RECEPTION_RESULT,
  VisitationActionsBtnKey.FOLLOW,
  VisitationActionsBtnKey.FINISH,
  VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN,
  VisitationActionsBtnKey.REQUEST_SIGN_AGAIN,
];

const BASIC_ACTIONS = [
  VisitationActionsBtnKey.RECALL,
  VisitationActionsBtnKey.SEND_MAIL,
  VisitationActionsBtnKey.FORWARD,
  VisitationActionsBtnKey.FEEDBACK,
  VisitationActionsBtnKey.SHARE,
  VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
  VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
  VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
];

type TypePropsVisitationTableActions = {
  params: any;
  activeTab?: number;
  isEditSignTab?: boolean;
  isActionDetail?: boolean;
  handleClickRecall?: () => void;
  handleClickSendMail?: () => void;
  handleClickForWard?: () => void;
  handleClickFeedBack?: () => void;
  handleClickRequestMeeting?: () => void;
  handleClickRequestInformation?: () => void;
  handleClickAdditionalInformation?: () => void;
  handleClickRequestShareInfo?: () => void;
  handleClickFeedbackShareInfo?: () => void;
  handleClickShare?: () => void;
  handleClickConfirm?: () => void;
  handleClickRequestEvaluate?: () => void;
  handleClickAssignment?: () => void;
  handleClickConfirmEvaluateFeedback?: () => void;
  handleClickRequestSign?: () => void;
  handleClickSign?: () => void;
  handleClickRejectSign?: () => void;
  handleClickReception?: () => void;
  handleClickReceptionResult?: () => void;
  handleClickExtendTime?: () => void;
  handleClickExtendTimeShareInfo?: () => void;
  handleClickExtendTimeResponseLc?: () => void;
  handleClickFollow?: () => void;
  handleClickFinish?: () => void;
};

export const VisitationTableActions = (
  props: TypePropsVisitationTableActions
) => {
  const {
    params,
    isActionDetail = false,
    handleClickRecall = () => {},
    handleClickSendMail = () => {},
    handleClickForWard = () => {},
    handleClickFeedBack = () => {},
    handleClickRequestMeeting = () => {},
    handleClickRequestInformation = () => {},
    handleClickAdditionalInformation = () => {},
    handleClickRequestShareInfo = () => {},
    handleClickFeedbackShareInfo = () => {},
    handleClickShare = () => {},
    handleClickConfirm = () => {},
    handleClickRequestEvaluate = () => {},
    handleClickAssignment = () => {},
    handleClickConfirmEvaluateFeedback = () => {},
    handleClickRequestSign = () => {},
    handleClickSign = () => {},
    handleClickRejectSign = () => {},
    handleClickReception = () => {},
    handleClickReceptionResult = () => {},
    handleClickExtendTime = () => {},
    handleClickExtendTimeShareInfo = () => {},
    handleClickExtendTimeResponseLc = () => {},
    handleClickFollow = () => {},
    handleClickFinish = () => {},
  } = props;

  const [t] = useTranslation();

  const styleBtn = {
    background: COLOR_TYPE.TOYOTA.TOYOTA1,
    color: COLOR_TYPE.TOYOTA.TOYOTA8,
  };

  const reOrderButtons = (buttonList: any[]) => {
    if (!(Array.isArray(buttonList) && buttonList.length)) {
      return [];
    }

    const sortedButton = buttonList.sort((a, b) => {
      return (
        BUTTONS_ORDER_BY.indexOf(a?.key) - BUTTONS_ORDER_BY.indexOf(b?.key)
      );
    });

    return sortedButton;
  };

  const requestReviewAgainQuery = useMutation({
    mutationFn: requestReviewAgain,
    onSuccess: () => {
      toast.success(
        t("followViolation.requestRecheck.message.success", {
          recordName: t("menu.visitation"),
        })
      );
      router.push(`/${VISITATION_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const requestSignAgainQuery = useMutation({
    mutationFn: requestSignAgain,
    onSuccess: () => {
      toast.success(
        t("followViolation.requestRecheck.message.success", {
          recordName: t("menu.visitation"),
        })
      );
      router.push(`/${VISITATION_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const handleClickRequestReviewAgain = () => {
    requestReviewAgainQuery.mutate({ id: +(params?.row?.id ?? 0) });
  };

  const handleClickRequestSignAgain = () => {
    requestSignAgainQuery.mutate({ id: +(params?.row?.id ?? 0) });
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const buttonMap = new Map<string, ActionButtonItem>([
    [
      VisitationActionsBtnKey.RECALL,
      {
        key: VisitationActionsBtnKey.RECALL,
        icon: <IconRecall />,
        iconDisable: <IconRecall color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.RECALL}`),
        onClick: handleClickRecall,
        tooltipTitle: t(`visitation.button.${VisitationActionsBtnKey.RECALL}`),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `visitation.recallVisitation.message.confirm_${VisitationActionsBtnKey.RECALL}`
          ),
        },
        styleBtn,
        secondaryBtn: 1,
      },
    ],
    [
      VisitationActionsBtnKey.SEND_MAIL,
      {
        key: VisitationActionsBtnKey.SEND_MAIL,
        icon: <IconSendMail />,
        iconDisable: <IconSendMail color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.SEND_MAIL}`),
        onClick: handleClickSendMail,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.SEND_MAIL}`
        ),
        styleBtn,
        secondaryBtn: 2,
      },
    ],
    [
      VisitationActionsBtnKey.FORWARD,
      {
        key: VisitationActionsBtnKey.FORWARD,
        icon: <IconForward />,
        iconDisable: <IconForward color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.FORWARD}`),
        onClick: handleClickForWard,
        tooltipTitle: t(`visitation.button.${VisitationActionsBtnKey.FORWARD}`),
        styleBtn,
        secondaryBtn: 3,
      },
    ],
    [
      VisitationActionsBtnKey.FEEDBACK,
      {
        key: VisitationActionsBtnKey.FEEDBACK,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.FEEDBACK}`),
        onClick: handleClickFeedBack,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.FEEDBACK}`
        ),
        styleBtn,
        secondaryBtn: 4,
      },
    ],
    [
      VisitationActionsBtnKey.MEETING,
      {
        key: VisitationActionsBtnKey.MEETING,
        icon: <IconRequestMeeting />,
        iconDisable: <IconRequestMeeting color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.MEETING}`),
        onClick: handleClickRequestMeeting,
        tooltipTitle: t(`visitation.button.${VisitationActionsBtnKey.MEETING}`),
        styleBtn,
        secondaryBtn: 5,
      },
    ],
    [
      VisitationActionsBtnKey.SHARE,
      {
        key: VisitationActionsBtnKey.SHARE,
        icon: <IconShare />,
        iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.SHARE}`),
        onClick: handleClickShare,
        tooltipTitle: t(`visitation.button.${VisitationActionsBtnKey.SHARE}`),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      VisitationActionsBtnKey.INFORMATION_REQUEST,
      {
        key: VisitationActionsBtnKey.INFORMATION_REQUEST,
        icon: <IconRequestAdditional />,
        iconDisable: (
          <IconRequestAdditional color={COLOR_TYPE.TOYOTA.TOYOTA5} />
        ),
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.INFORMATION_REQUEST}`
        ),
        onClick: handleClickRequestInformation,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.INFORMATION_REQUEST}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.ADDITIONAL_INFORMATION,
      {
        key: VisitationActionsBtnKey.ADDITIONAL_INFORMATION,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.ADDITIONAL_INFORMATION}`
        ),
        onClick: handleClickAdditionalInformation,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.ADDITIONAL_INFORMATION}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `visitation.additionalInformationVisitation.message.confirm_${VisitationActionsBtnKey.ADDITIONAL_INFORMATION}`
          ),
        },
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.SHARE_INFO_REQUEST,
      {
        key: VisitationActionsBtnKey.SHARE_INFO_REQUEST,
        icon: <IconShare />,
        iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.SHARE_INFO_REQUEST}`
        ),
        onClick: handleClickRequestShareInfo,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.SHARE_INFO_REQUEST}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.SHARE_INFO_FEEDBACK,
      {
        key: VisitationActionsBtnKey.SHARE_INFO_FEEDBACK,
        icon: <IconFeedbackAdvise />,
        iconDisable: <IconFeedbackAdvise color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.SHARE_INFO_FEEDBACK}`
        ),
        onClick: handleClickFeedbackShareInfo,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.SHARE_INFO_FEEDBACK}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.CONFIRM_APPROVED,
      {
        key: VisitationActionsBtnKey.CONFIRM_APPROVED,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.CONFIRM_APPROVED}`
        ),
        onClick: handleClickConfirm,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.CONFIRM_APPROVED}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.EVALUATE_REQUEST,
      {
        key: VisitationActionsBtnKey.EVALUATE_REQUEST,
        icon: <IconRequestEvaluate />,
        iconDisable: <IconRequestEvaluate color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.EVALUATE_REQUEST}`
        ),
        onClick: handleClickRequestEvaluate,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.EVALUATE_REQUEST}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.ASSIGNMENT,
      {
        key: VisitationActionsBtnKey.ASSIGNMENT,
        icon: <IconAssignment />,
        iconDisable: <IconAssignment color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.ASSIGNMENT}`),
        onClick: handleClickAssignment,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.ASSIGNMENT}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
      {
        key: VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM}`
        ),
        onClick: handleClickConfirmEvaluateFeedback,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.REQUEST_SIGN,
      {
        key: VisitationActionsBtnKey.REQUEST_SIGN,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.REQUEST_SIGN}`),
        onClick: handleClickRequestSign,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_SIGN}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.SIGN,
      {
        key: VisitationActionsBtnKey.SIGN,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.SIGN}`),
        onClick: handleClickSign,
        tooltipTitle: t(`visitation.button.${VisitationActionsBtnKey.SIGN}`),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.SIGN_REJECT,
      {
        key: VisitationActionsBtnKey.SIGN_REJECT,
        icon: <IconRequestConfirm />,
        iconDisable: <IconRequestConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.SIGN_REJECT}`),
        onClick: handleClickRejectSign,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.SIGN_REJECT}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.RECEPTION,
      {
        key: VisitationActionsBtnKey.RECEPTION,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.RECEPTION}`),
        onClick: handleClickReception,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.RECEPTION}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.RECEPTION_RESULT,
      {
        key: VisitationActionsBtnKey.RECEPTION_RESULT,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.RECEPTION_RESULT}`
        ),
        onClick: handleClickReceptionResult,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.RECEPTION_RESULT}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
      {
        key: VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
        icon: <IconExtendDeadline />,
        iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE}`
        ),
        onClick: handleClickExtendTime,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE}`
        ),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
      {
        key: VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
        icon: <IconExtendDeadline />,
        iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE}`
        ),
        onClick: handleClickExtendTimeShareInfo,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE}`
        ),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
      {
        key: VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
        icon: <IconExtendDeadline />,
        iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE}`
        ),
        onClick: handleClickExtendTimeResponseLc,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE}`
        ),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      VisitationActionsBtnKey.FOLLOW,
      {
        key: VisitationActionsBtnKey.FOLLOW,
        icon: <IconNextAction />,
        iconDisable: <IconNextAction color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.FOLLOW}`),
        onClick: handleClickFollow,
        tooltipTitle: t(`visitation.button.${VisitationActionsBtnKey.FOLLOW}`),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.FINISH,
      {
        key: VisitationActionsBtnKey.FINISH,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`visitation.button.${VisitationActionsBtnKey.FINISH}`),
        onClick: handleClickFinish,
        tooltipTitle: t(`visitation.button.${VisitationActionsBtnKey.FINISH}`),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN,
      {
        key: VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN}`
        ),
        onClick: handleClickRequestReviewAgain,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN}`
        ),
        styleBtn,
      },
    ],
    [
      VisitationActionsBtnKey.REQUEST_SIGN_AGAIN,
      {
        key: VisitationActionsBtnKey.REQUEST_SIGN_AGAIN,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_SIGN_AGAIN}`
        ),
        onClick: handleClickRequestSignAgain,
        tooltipTitle: t(
          `visitation.button.${VisitationActionsBtnKey.REQUEST_SIGN_AGAIN}`
        ),
        styleBtn,
      },
    ],
  ]);

  const visitationStatusCode = useMemo(() => {
    return params?.row?.status?.code;
  }, [params?.row?.status?.code]);

  const roles = useMemo(() => {
    const newRoles = params?.row?.actionAvailableAndRole?.roles;

    return Array.isArray(newRoles) && newRoles.length ? [...newRoles] : [];
  }, [params?.row?.actionAvailableAndRole?.roles]);

  const getActionButtonItems = useMemo(() => {
    if (props.activeTab === 0) {
      let detailButtons = authorizedInforVisitationActionMapCallBack(
        params?.row?.actionAvailableAndRole?.roles ?? [],
        params
      )?.map((buttons: TypeActionRole) => ({
        ...buttonMap.get(buttons?.typeBtn)!,
        disable: buttons?.disable,
      }));

      if (visitationStatusCode === VisitationStatusCode.FINISH) {
        detailButtons = detailButtons.filter(
          (button) =>
            button.key === VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN
        );
      } else {
        detailButtons = detailButtons.filter(
          (button) =>
            button.key !== VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN &&
            button.key !== VisitationActionsBtnKey.REQUEST_SIGN_AGAIN
        );
      }

      if (visitationStatusCode !== VisitationStatusCode.INFORMATION_REQUEST) {
        detailButtons = detailButtons.filter(
          (button) =>
            button.key !== VisitationActionsBtnKey.ADDITIONAL_INFORMATION
        );
      }

      // Là người đánh giá, những đã Phân công cho người khác, thì chỉ enable những action cơ bản
      if (
        visitationStatusCode === VisitationStatusCode.ASSIGNMENT &&
        roles.includes(VisitationUserRole.get(VisitationUserRoleKey.EVALUATION))
      ) {
        detailButtons = detailButtons.map((button) => {
          const newButton = { ...button };

          if (BASIC_ACTIONS.includes(button.key)) {
            return newButton;
          } else {
            return {
              ...button,
              disable: true,
            };
          }
        });
      }

      return detailButtons;
    }

    if (!props.isEditSignTab) {
      return [];
    }

    let signButtons = authorizedSignActionMapCallBack(
      params?.row?.actionAvailableAndRole?.roles ?? [],
      params
    )?.map((buttons: TypeActionRole) => {
      const disabled = buttons?.disable;

      return {
        ...buttonMap.get(buttons?.typeBtn)!,
        disable: disabled,
      };
    });

    if (visitationStatusCode === VisitationStatusCode.FINISH) {
      signButtons = signButtons.filter(
        (button) => button.key === VisitationActionsBtnKey.REQUEST_SIGN_AGAIN
      );
    } else {
      signButtons = signButtons.filter(
        (button) =>
          button.key !== VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN &&
          button.key !== VisitationActionsBtnKey.REQUEST_SIGN_AGAIN
      );
    }

    return signButtons;
  }, [
    buttonMap,
    params,
    props.activeTab,
    props.isEditSignTab,
    visitationStatusCode,
    roles,
  ]);

  if (isActionDetail) {
    return (
      <ActionButtonDetail
        params={params}
        actionButtonItems={reOrderButtons(getActionButtonItems)}
      />
    );
  }

  let listButtons = authorizedActionMapCallBackListVisitation(
    params?.row?.actionAvailableAndRole?.roles ?? [],
    params
  )?.map((buttons: TypeActionRole) => ({
    ...buttonMap.get(buttons?.typeBtn)!,
    disable: buttons?.disable,
  }));

  if (visitationStatusCode === VisitationStatusCode.FINISH) {
    listButtons = listButtons.filter(
      (button) =>
        button.key === VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN ||
        button.key === VisitationActionsBtnKey.REQUEST_SIGN_AGAIN
    );
  } else {
    listButtons = listButtons.filter(
      (button) =>
        button.key !== VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN &&
        button.key !== VisitationActionsBtnKey.REQUEST_SIGN_AGAIN
    );
  }

  // Là người đánh giá, những đã Phân công cho người khác, thì chỉ enable những action cơ bản
  if (
    visitationStatusCode === VisitationStatusCode.ASSIGNMENT &&
    roles.includes(VisitationUserRole.get(VisitationUserRoleKey.EVALUATION))
  ) {
    listButtons = listButtons.map((button) => {
      const newButton = { ...button };

      if (BASIC_ACTIONS.includes(button.key)) {
        return newButton;
      } else {
        return {
          ...button,
          disable: true,
        };
      }
    });
  }

  return (
    <ActionButtonCustom
      params={params}
      actionButtonItems={reOrderButtons(listButtons)}
      listActions={params?.row?.actionAvailableAndRole?.roles ?? []}
    />
  );
};
