import MultipleFilterTable, {
  MultipleFilterTableColumn,
} from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { GridFilterItem } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { GetHelpListParams, HelpFieldNames } from "@/models/help/Help";
import { useTranslation } from "react-i18next";
import { Checkbox } from "@mui/material";
import { HelpTableAtions } from "./help_table_actions/HelperTableActions";
import { deleteHelps, getHelpList } from "@/apis/service/help/Help";
import { Module, ModuleFieldsPaths, ModuleR } from "@/constants/general";
import { useRouter } from "next/navigation";
import { HELP_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { TableGroupedActionButtons } from "@/components/commons/action_button/TableGroupedActionButtons";
import { getMultipleChoosingOperators } from "@/components/commons/filters/MultipleChoosingFilter";

export const HelpTableConst = {
  TABLE_NAME: "HelpTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getHelpList",
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetHelpListParams => {
  const params: GetHelpListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: HelpFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == HelpFieldNames.NAME) {
      params.name = item.value;
    }
    if (item.field == HelpFieldNames.MODULE) {
      params.modules = item.value;
    }
    if (item.field == HelpFieldNames.HELP_NAME) {
      params.helpName = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() || "";
  }

  return params;
};

export const HelpTable = () => {
  const router = useRouter();
  const [t] = useTranslation();
  const queryClient = useQueryClient();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [helpTableColumns] = useState<MultipleFilterTableColumn[]>(() => [
    {
      key: HelpFieldNames.ID,
      label: HelpFieldNames.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
    },
    {
      key: HelpFieldNames.MODULE,
      label: HelpFieldNames.MODULE,
      type: undefined,
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 230,
      filterOperators: getMultipleChoosingOperators(
        {
          options: Array.from(Module.keys()).map((key) => ({
            label: t(`common.option.${HelpFieldNames.MODULE}.${key}`),
            value: Module.get(key)!,
          })),
          getOptionKey: (option) => option.value,
          getOptionLabel: (option) => option.label,
        },
        t
      ),
      renderCell: (params) => (
        <>
          {t(
            `common.option.${HelpFieldNames.MODULE}.${ModuleR.get(
              Number(params.value)
            )!}`
          )}
        </>
      ),
    },
    {
      key: HelpFieldNames.HELP_NAME,
      label: HelpFieldNames.HELP_NAME,
      type: "string",
      quickFilter: true,
      filterable: false,
      sortable: true,
      hideable: false,
      renderCell: (params) => <>{t(ModuleFieldsPaths[params.value])}</>,
      minWidth: 250,
      flex: 1,
    },
    {
      key: HelpFieldNames.NAME,
      label: HelpFieldNames.NAME,
      type: "string",
      quickFilter: true,
      filterable: false,
      sortable: true,
      hideable: false,
      minWidth: 250,
      flex: 1,
    },
    {
      key: HelpFieldNames.DESCRIPTION,
      label: HelpFieldNames.DESCRIPTION,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      minWidth: 360,
      flex: 2
    },
    {
      key: HelpFieldNames.ACTIVE,
      label: HelpFieldNames.ACTIVE,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      renderCell: (params) => <Checkbox checked={params.value == 1} />,
    },
    {
      key: HelpFieldNames.CREATED_AT,
      label: HelpFieldNames.CREATED_AT,
      type: "date",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      minWidth: 230,
    },
    {
      key: "action",
      label: "",
      type: undefined,
      renderCell: HelpTableAtions,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "last-column-sticky",
      headerClassName: 'last-column-sticky-header',
    },
  ]);

  const getHelpListQuery = useQuery({
    queryKey: [HelpTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getHelpList(castTableStateToParams(tableState)),
  });

  const deleteHelpsQuery = useMutation({
    mutationFn: deleteHelps,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.help"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [HelpTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  // Watch table state then refetch new data for the table
  useEffect(() => {
    tableState &&
      getHelpListQuery.refetch().catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  return (
    <MultipleFilterTable
      data={getHelpListQuery.data?.fieldResponses || []}
      columns={helpTableColumns
        // .filter((column) => appContext.meCanWrite || column.key != "action")
        .map((column) => ({
          ...column,
          label: column.label && `help.column.${column.label}`,
        }))}
      getRowId={(item) => item.id.toString()}
      loading={getHelpListQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getHelpListQuery.data?.total}
      multipleFilter
      onRowClick={(params) => {
        router.push(`/${HELP_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`);
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: HelpFieldNames.NAME,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(`help.column.${fieldKey}`).toLocaleLowerCase(),
          }),
      }}
      groupedActions={(model) => (
        <TableGroupedActionButtons
          selectModel={model}
          onDelete={deleteHelpsQuery.mutate}
        />
      )}
    />
  );
};
