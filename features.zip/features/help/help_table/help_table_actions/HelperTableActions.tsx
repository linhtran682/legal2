import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { GridRenderCellParams } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import DeleteIcon from "@mui/icons-material/Delete";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { HELP_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { deleteHelps } from "@/apis/service/help/Help";
import { HelpTableConst } from "../HelperTable";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";

export const HelpTableAtions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  const queryClient = useQueryClient();

  const deleteHelpsQuery = useMutation({
    mutationFn: deleteHelps,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.help"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [HelpTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_help",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(`/${HELP_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`),
          tooltipTitle: t("common.button.update"),
        },
        {
          key: "delete_help",
          icon: <DeleteIcon color='primary' />,
          onClick: (params) =>
            params.id && deleteHelpsQuery.mutate([Number(params.id)]),
          tooltipTitle: t("common.button.delete"),
          confirmPopupProps: {
            icon: <DeleteRecordDialogIcon />,
            title: t("common.message.confirm_delete"),
          },
        },
      ]}
    />
  );
};
