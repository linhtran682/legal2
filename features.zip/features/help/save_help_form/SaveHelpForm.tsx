import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormCheckbox } from "@/components/commons/form_inputs/FormCheckbox";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  ModuleFieldItem,
  ModuleFieldsHelp,
  ModuleFieldsPaths,
  ModuleR,
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import {
  HelpFieldNames,
  SaveHelpDTO,
  SaveHelpRequestFieldNames,
  SaveHelpRequestSchema,
  SaveHelpRequestSchemaI,
} from "@/models/help/Help";
import { BasicSaveForm } from "@/models/ui/form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveHelpFormProps
  extends BasicSaveForm<SaveHelpDTO, SaveHelpDTO> {}

const initialEmptyValue: SaveHelpRequestSchemaI = {
  name: "",
  helpName: "",
  description: "",
  active: 0,
};

export const SaveHelpForm = (props: SaveHelpFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<SaveHelpRequestSchemaI>({
    resolver: yupResolver(SaveHelpRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue &&
      form.reset(props.initialValue as SaveHelpRequestSchemaI);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  const onSubmit = (formValue: SaveHelpRequestSchemaI) => {
    const moduleKey = +formValue.helpName.split('_')[0];
    props.onSubmit({
      ...formValue,
      module: moduleKey,
    });
  };

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <Grid container direction={"column"} spacing={GLOBAL_SPACING}>
              <Grid item>
                <FormTextField
                  control={form.control}
                  name={SaveHelpRequestFieldNames.NAME}
                  label={t(`help.field_name.${SaveHelpRequestFieldNames.NAME}`)}
                  placeHolder={t(
                    `help.field_name.${SaveHelpRequestFieldNames.NAME}`
                  )}
                  required
                />
              </Grid>

              <Grid item>
                <FormAsyncSelect<SaveHelpRequestSchemaI, ModuleFieldItem>
                  keyQuery='help-query'
                  control={form.control}
                  name={SaveHelpRequestFieldNames.HELP_NAME}
                  label={t(
                    `help.field_name.${SaveHelpRequestFieldNames.HELP_NAME}`
                  )}
                  getOptions={async (keyword) =>
                    Promise.resolve(
                      Object.values(ModuleFieldsHelp)
                        .map(
                          (field) =>
                            ({
                              fieldName: field.fieldName,
                              module: field.module,
                            } as ModuleFieldItem)
                        )
                        .filter(({ fieldName }) => {
                          return !Boolean(keyword)
                            ? true
                            : typeof keyword == "string"
                            ? t(ModuleFieldsPaths[fieldName]).includes(keyword)
                            : keyword.includes(fieldName);
                        })
                    )
                  }
                  getOptionKey={(item) => item.fieldName}
                  getOptionLabel={(item) => t(ModuleFieldsPaths[item.fieldName])}
                  groupBy={(item) =>
                    t(
                      `common.option.${HelpFieldNames.MODULE}.${ModuleR.get(
                        item.module
                      )!}`
                    )
                  }
                  required
                  debounceMs={0}
                  minCharLength={0}
                  isOptionEqualToValue={(option, value) =>
                    option.fieldName == value.fieldName
                  }
                />
              </Grid>

              <Grid item>
                <FormCheckbox
                  control={form.control}
                  name={SaveHelpRequestFieldNames.ACTIVE}
                  label={t(
                    `help.field_name.${SaveHelpRequestFieldNames.ACTIVE}`
                  )}
                  inputTransform={(value: number) => value != 0}
                  outputTransform={(bool) => (bool ? 1 : 0)}
                />
              </Grid>

              <Grid item>
                <FormTextArea
                  control={form.control}
                  name={SaveHelpRequestFieldNames.DESCRIPTION}
                  label={t(
                    `help.field_name.${SaveHelpRequestFieldNames.DESCRIPTION}`
                  )}
                  placeHolder={t(
                    `help.field_name.${SaveHelpRequestFieldNames.DESCRIPTION}`
                  )}
                  minRows={3}
                />
              </Grid>
            </Grid>
          </Grid>
        </Grid>

        <FormActionButtons
          formMode={props.formMode}
          loading={props.loading}
          onCancel={props.onCancel}
          cancelConfirm={form.formState.isDirty}
          onDelete={props.onDelete}
          onSave={onSubmit}
        />
      </FormProvider>
    </Grid>
  );
};
