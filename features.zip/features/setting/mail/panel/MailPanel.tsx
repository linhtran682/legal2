import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Box, List, ListItemButton } from "@mui/material";
import { useListMailTemplate } from "@/apis/service/setting/SettingApi";
import { MailItem } from "@/models/setting/Mail";

export interface Props {
  onSelect: (mail: any) => void;
}

export enum MAIL_TYPE {
  LEGAL_ADVISE = "LEGAL_ADVISE",
  REQUEST_REVIEW_DOCUMENT = "REQUEST_REVIEW_DOCUMENT",
  CONFLICT_INTEREST_MANAGEMENT = "CONFLICT_INTEREST_MANAGEMENT",
  VIOLATION_TRACKING = "VIOLATION_TRACKING",
  VISITATION_MANAGEMENT = "VISITATION_MANAGEMENT",
  DECLARE_RELATIONSHIP_MANAGEMENT = "DECLARE_RELATIONSHIP_MANAGEMENT",
  SHARE_REQUEST = "SHARE_REQUEST",
}

export const MAIL_LABEL: any = {
  "LEGAL_ADVISE": "setting.mail.label.legalAdvise",
  "REQUEST_REVIEW_DOCUMENT": "setting.mail.label.requestReviewDocument",
  "CONFLICT_INTEREST_MANAGEMENT": "setting.mail.label.conflictInterestManagement",
  "VIOLATION_TRACKING": "setting.mail.label.violationTracking",
  "VISITATION_MANAGEMENT": "setting.mail.label.visitationManagement",
  "DECLARE_RELATIONSHIP_MANAGEMENT": "setting.mail.label.declareRelationship",
  "SHARE_REQUEST": "setting.mail.label.shareRequest",
}

export const MailPanel = ({onSelect}: Props) => {
  const { t } = useTranslation();
  const [selectedItem, setSelectedItem] = useState<MailItem>();
  const {data} = useListMailTemplate({});

  const handleClickItem = (item: any) => {
    setSelectedItem(item);
    onSelect(item)
  }

  useEffect(() => {
    if (data?.emailTemplates && data.emailTemplates.length > 0) {
      setSelectedItem(data.emailTemplates[0])
      onSelect(data.emailTemplates[0])
    }
  }, [data, onSelect])

  return (
    <Box sx={{backgroundColor: "#ffffff"}}>
      <List component="nav" aria-label="main mailbox folders">
        {data?.emailTemplates.map((item) => (
          <ListItemButton
            key={item.id}
            sx={{
              backgroundColor: selectedItem?.id === item.id
                ? "rgba(255, 0, 0, 0.1)"
                : "transparent",
              paddingLeft: 4,
              color: selectedItem?.id === item.id
                ? "red"
                : "black",
            }}
            onClick={() => handleClickItem(item)}
            >
            {t(MAIL_LABEL[item.emailType])}
          </ListItemButton>
        ))}
      </List>
    </Box>
  );
};
