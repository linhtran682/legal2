import { useTranslation } from "react-i18next";
import { Box, Button, Grid, Typography } from "@mui/material";
import { GLOBAL_LARGE_SPACING, GLOBAL_SPACING } from "@/constants/format";
import { MailItem, MailTemplateBodySend } from "@/models/setting/Mail";
import {
  useMailTemplateDetail,
  useUpdateMailTemplate,
} from "@/apis/service/setting/SettingApi";
import * as Yup from "yup";
import { MAIL_LABEL, MAIL_TYPE } from "../panel/MailPanel";
import { useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { VALIDATION_MSG } from "@/constants/message";
import { toast } from "react-toastify";
import { EditorField } from "@/components/commons/EditorField/EditorField";
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';

export interface Props {
  mail: MailItem;
}

export const MailDetail = ({ mail }: Props) => {
  const [t] = useTranslation();
  const { data } = useMailTemplateDetail({ params: { id: mail.id } });
  const { mutateAsync: mutateAsyncTemplate } = useUpdateMailTemplate();

  const form = useForm({
    resolver: yupResolver(
      Yup.object().shape({
        title: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
        content: Yup.string()
          .required(VALIDATION_MSG.REQUIRED_FIELD)
          .test("non-empty", VALIDATION_MSG.REQUIRED_FIELD, (value) => {
            const strippedValue = value?.replace(/<[^>]+>/g, "").trim();
            return strippedValue !== "";
          }),
      })
    ),
    mode: "onSubmit",
  });

  useEffect(() => {
    if (data) {
      form.reset({
        title: data.title,
        content: data.content,
      });
    }
  }, [data, form]);

  const handleSaveData = async (dataForm: MailTemplateBodySend) => {
    const params = {
      templateId: data?.id ?? "",
      title: dataForm.title,
      content: dataForm.content,
    };
    const res = await mutateAsyncTemplate(params);
    if (res) {
      toast.success(
        t("common.message.update_success", {
          recordName: t(MAIL_LABEL[mail.emailType]),
        })
      );
    }
  };

  return (
    <>
      <FormProvider {...form}>
        <form style={{ height: "100%" }}>
          {data && (
            <Grid
              container
              className="form-wrapper"
              height={"100%"}
              sx={{ overflow: "hidden" }}
            >
              <Grid
                container
                direction={"column"}
                wrap="nowrap"
                rowGap={GLOBAL_SPACING}
                alignItems={"flex-start"}
                className="form-section-wrapper"
                height={"100%"}
                padding={GLOBAL_LARGE_SPACING}
                sx={{
                  height: "100%",
                  overflowY: "auto",
                  contain: "strict",
                  position: "relative",
                }}
              >
                <Grid item>
                  <Typography variant="h2" sx={{marginBottom: GLOBAL_SPACING}}>
                    {t(MAIL_LABEL[mail.emailType])}
                  </Typography>
                  <Typography columnGap={0.5} sx={{display: "flex", alignItems: "center"}}>
                    <HelpOutlineIcon />
                    {t("setting.mail.label.description")}
                  </Typography>
                  <Box ml={3.5}>
                    <Typography>
                      {t("setting.mail.label.senderDescription")}
                    </Typography>
                    <Typography>
                      {t("setting.mail.label.receiverDescription")}
                    </Typography>
                    <Typography>
                      {t("setting.mail.label.documentDescription")}
                    </Typography>
                    <Typography>
                      {t("setting.mail.label.urlDescription")}
                    </Typography>
                    {mail.emailType !== MAIL_TYPE.SHARE_REQUEST && <Typography>
                      {mail.emailType === MAIL_TYPE.CONFLICT_INTEREST_MANAGEMENT
                      || mail.emailType === MAIL_TYPE.DECLARE_RELATIONSHIP_MANAGEMENT
                      || mail.emailType === MAIL_TYPE.VISITATION_MANAGEMENT
                      ? t("setting.mail.label.timeDescription2") : t("setting.mail.label.timeDescription1")}
                    </Typography>}
                    {mail.emailType === MAIL_TYPE.SHARE_REQUEST && <Typography>
                      {t("setting.mail.label.moduleDescription")}
                    </Typography>}
                  </Box>
                </Grid>
                <Grid item width={"100%"}>
                  <FormTextField
                    control={form.control}
                    name={"title"}
                    label={t(`setting.mail.label.title`)}
                    placeHolder={t(`setting.mail.label.title`)}
                    required
                  />
                </Grid>
                <Grid item width={"100%"}>
                  <EditorField
                    control={form.control}
                    name="content"
                    label={t("setting.mail.label.content")}
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
          )}
          <Grid
            container
            justifyContent={"end"}
            style={{ position: "fixed", bottom: 0 }}
          >
            <Grid item sx={{ position: "sticky", right: 0, px: 4, py: 1 }}>
              <Button
                onClick={form.handleSubmit((data) => handleSaveData(data))}
                variant="contained"
                className="confirm"
                sx={{ px: 6, width: 168 }}
              >
                {t("common.button.save")}
              </Button>
            </Grid>
          </Grid>
        </form>
      </FormProvider>
    </>
  );
};
