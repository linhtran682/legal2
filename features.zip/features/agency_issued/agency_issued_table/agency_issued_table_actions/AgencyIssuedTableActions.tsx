import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { GridRenderCellParams } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import DeleteIcon from "@mui/icons-material/Delete";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { deleteAgencyIssueds } from "@/apis/service/agency_issued/AgencyIssued";
import { AgencyIssuedTableConst } from "../AgencyIssuedTable";
import { AGENCY_ISSUED_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";

export const AgencyIssuedTableAtions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  const queryClient = useQueryClient();

  const deleteAgencyIssuedsQuery = useMutation({
    mutationFn: deleteAgencyIssueds,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.agencyIssued"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [AgencyIssuedTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_agency_issued",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(
              `/${AGENCY_ISSUED_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            ),
          tooltipTitle: t("common.button.update"),
        },
        {
          key: "delete_agency_issued",
          icon: <DeleteIcon color='primary' />,
          onClick: (params) =>
            params.id && deleteAgencyIssuedsQuery.mutate([Number(params.id)]),
          tooltipTitle: t("common.button.delete"),
          confirmPopupProps: {
            icon: <DeleteRecordDialogIcon />,
            title: t("common.message.confirm_delete"),
          },
        },
      ]}
    />
  );
};
