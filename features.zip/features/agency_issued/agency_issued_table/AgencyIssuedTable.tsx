import MultipleFilterTable, {
  MultipleFilterTableColumn,
} from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { GridFilterItem } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import {
  AgencyIssuedFieldNames,
  GetAgencyIssuedsParams,
} from "@/models/agency_issued/AgencyIssued";
import { AgencyIssuedTableAtions } from "./agency_issued_table_actions/AgencyIssuedTableActions";
import {
  deleteAgencyIssueds,
  getAgencyIssueds,
} from "@/apis/service/agency_issued/AgencyIssued";
import { useRouter } from "next/navigation";
import { AGENCY_ISSUED_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useTranslation } from "react-i18next";
import { TableGroupedActionButtons } from "@/components/commons/action_button/TableGroupedActionButtons";

export const AgencyIssuedTableConst = {
  TABLE_NAME: "AgencyIssuedTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getAgencyIssueds",
};

const AgencyIssuedTableColumns: MultipleFilterTableColumn[] = [
  {
    key: AgencyIssuedFieldNames.ID,
    label: AgencyIssuedFieldNames.ID,
    type: "number",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
  },
  {
    key: AgencyIssuedFieldNames.NAME,
    label: AgencyIssuedFieldNames.NAME,
    type: "string",
    quickFilter: true,
    filterable: true,
    sortable: true,
    hideable: false,
    flex: 1,
  },
  {
    key: AgencyIssuedFieldNames.CREATED_BY,
    label: AgencyIssuedFieldNames.CREATED_BY,
    type: "string",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
    flex: 1,
  },
  {
    key: AgencyIssuedFieldNames.CREATED_AT,
    label: AgencyIssuedFieldNames.CREATED_AT,
    type: "date",
    quickFilter: false,
    filterable: false,
    sortable: true,
    hideable: true,
    flex: 1,
  },
  {
    key: "action",
    label: "",
    type: undefined,
    renderCell: AgencyIssuedTableAtions,
    quickFilter: false,
    filterable: false,
    sortable: false,
    hideable: false,
    cellClassName: "stickyRight",
  },
];

const castTableStateToParams = (
  tableState: StandardTableState
): GetAgencyIssuedsParams => {
  const params: GetAgencyIssuedsParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: AgencyIssuedFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == AgencyIssuedFieldNames.NAME) {
      params.name = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() || "";
  }

  return params;
};

export const AgencyIssuedTable = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getAgencyIssuedsQuery = useQuery({
    queryKey: [AgencyIssuedTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getAgencyIssueds(castTableStateToParams(tableState)),
  });

  const deleteAgencyIssuedsQuery = useMutation({
    mutationFn: deleteAgencyIssueds,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.agencyIssued"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [AgencyIssuedTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  // Watch table state then refetch new data for the table
  useEffect(() => {
    tableState &&
      getAgencyIssuedsQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  return (
    <MultipleFilterTable
      data={getAgencyIssuedsQuery.data?.agencyIssuedResponses || []}
      columns={AgencyIssuedTableColumns
      // .filter((column) => appContext.meCanWrite || column.key != "action")
      .map((column) => ({
        ...column,
        label: column.label && `agency_issued.column.${column.label}`,
      }))}
      getRowId={(item) => item.id.toString()}
      loading={getAgencyIssuedsQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getAgencyIssuedsQuery.data?.total}
      onRowClick={(params) => {
        router.push(
          `/${AGENCY_ISSUED_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
        );
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: AgencyIssuedFieldNames.NAME,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(
              `agency_issued.column.${fieldKey}`
            ).toLocaleLowerCase(),
          }),
      }}
      groupedActions={(model) => (
        <TableGroupedActionButtons
          selectModel={model}
          onDelete={deleteAgencyIssuedsQuery.mutate}
        />
      )}
    />
  );
};
