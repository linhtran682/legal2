import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import {
  SaveAgencyIssuedDTO,
  SaveAgencyIssuedRequestFieldNames,
  SaveAgencyIssuedRequestSchema,
  SaveAgencyIssuedRequestSchemaI,
} from "@/models/agency_issued/AgencyIssued";
import { BasicSaveForm } from "@/models/ui/form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveAgencyIssuedFormProps
  extends BasicSaveForm<SaveAgencyIssuedDTO, SaveAgencyIssuedDTO> {}

const initialEmptyValue: SaveAgencyIssuedDTO = {
  name: "",
  description: "",
};

export const SaveAgencyIssuedForm = (props: SaveAgencyIssuedFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<SaveAgencyIssuedRequestSchemaI>({
    resolver: yupResolver(SaveAgencyIssuedRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue && form.reset(props.initialValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <FormTextField
              control={form.control}
              name={SaveAgencyIssuedRequestFieldNames.NAME}
              label={t(
                `agency_issued.field_name.${SaveAgencyIssuedRequestFieldNames.NAME}`
              )}
              placeHolder={t(
                `agency_issued.field_name.${SaveAgencyIssuedRequestFieldNames.NAME}`
              )}
              required
            />
          </Grid>

          <Grid item width={"100%"}>
            <FormTextArea
              control={form.control}
              name={SaveAgencyIssuedRequestFieldNames.DESCRIPTION}
              label={t(
                `agency_issued.field_name.${SaveAgencyIssuedRequestFieldNames.DESCRIPTION}`
              )}
              placeHolder={t(
                `agency_issued.field_name.${SaveAgencyIssuedRequestFieldNames.DESCRIPTION}`
              )}
              minRows={3}
            />
          </Grid>
        </Grid>

        <FormActionButtons
          formMode={props.formMode}
          loading={props.loading}
          onCancel={props.onCancel}
          cancelConfirm={form.formState.isDirty}
          onDelete={props.onDelete}
          onSave={props.onSubmit}
        />
      </FormProvider>
    </Grid>
  );
};
