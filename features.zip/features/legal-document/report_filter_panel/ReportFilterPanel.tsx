import { getDepartments } from "@/apis/service/department/department";
import { getDocumentTypes } from "@/apis/service/document_type/DocumentType";
import { getStatusList } from "@/apis/service/status/Status";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import ReportTypeSelect from "@/components/commons/report_type_select/ReportTypeSelect";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { ModuleFields } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { Department } from "@/models/department/Department";
import { FieldFieldNames } from "@/models/field/Field";
import { FeedbackTypeOptions, SaveLawDocumentRequestFieldNames } from "@/models/law_document/LawDocument";
import { StatusFieldNames } from "@/models/status/Status";
import { toIsoEndOfDay, toIsoStartOfDay } from "@/utils";
import { Box, Button, Grid, Stack } from "@mui/material";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

interface ReportFilterPanelProps {
  onSearch?: (data: any) => void;
  onExport?: (data: any) => void;
  loading?: boolean;
  noStatus?: boolean;
  isDocumentType?: boolean;
  isDepartments?: boolean;
  isFeedbackType?: boolean;
}
const ReportFilterPanel = (props: ReportFilterPanelProps) => {
  const {
    onExport,
    onSearch,
    loading,
    noStatus,
    isDocumentType = true,
    isDepartments = false,
    isFeedbackType= false
  } = props;
  const form = useForm();
  const { t } = useTranslation();

  const getParams = () => {
    const data = form.getValues();
    const params = {
      startDate: toIsoStartOfDay(data?.from as Date),
      endDate: toIsoEndOfDay(data?.to as Date),
      status: data?.status?.map((ele: any) => ele?.id),
      documentTypes: data?.documentTypes?.map((ele: any) => ele?.id),
      departments: data?.departments,
      feedbackType: data?.feedbackType
    };
    return params;
  };

  const handleSearch = () => {
    const params = getParams();
    onSearch?.(params);
  };
  const handleExport = () => {
    const params = getParams();
    onExport?.(params);
  };

  return (
    <FormProvider {...form}>
      <Box
        sx={{
          backgroundColor: "white",
          p: 1,
          ...formInputSxProps,
        }}
      >
        <Grid container spacing={1}>
          {isFeedbackType ?
            <Grid item xs={12} md={12}>
              <RadioGroupField
                label="Không phản hồi"
                isNumber
                items={FeedbackTypeOptions}
                name={"feedbackType"}
                error={form.formState.errors["feedbackType"] as FieldError}
              />
            </Grid> : null
          }
          <ReportTypeSelect />
          {isDocumentType ? (
            <Grid item xs={12} md={6}>
              <FormMultipleSelect
                control={form.control}
                name={"documentTypes"}
                label={t(
                  `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DOCUMENT_TYPE}`
                )}
                placeholder={t(
                  `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DOCUMENT_TYPE}`
                )}
                keyQuery={"document-type-query"}
                getOptions={async (keyword) => {
                  const response = await getDocumentTypes({
                    name: keyword,
                    page: 0,
                    size: 100,
                    sortBy: StatusFieldNames.NAME,
                    orderBy: "ASC",
                  });
                  return response?.documentTypes ?? [];
                  // return [] as DocumentTypeDTO[];
                }}
                getOptionKey={(option) => option.id.toString()}
                getOptionLabel={(option) => option.name}
                isFocus
              />
            </Grid>
          ) : null}
          {noStatus ? null : (
            <Grid item xs={12} md={6}>
              <FormMultipleSelect
                control={form.control}
                name={"status"}
                label={t(`report.status`)}
                placeholder={t(`report.status`)}
                keyQuery={"legal-advice-report-status-query"}
                getOptions={async () => {
                  const response = await getStatusList({
                    page: 0,
                    size: 100,
                    sortBy: FieldFieldNames.NAME,
                    orderBy: "ASC",
                    modules: [ModuleFields.LEGISLATION_NAME.module],
                    active: 1,
                  });
                  return response?.statusResponses || [];
                }}
                showAllSelected={false}
                getOptionKey={(option) => option.id.toString()}
                getOptionLabel={(option) => option?.name}
                isFocus
              />
            </Grid>
          )}
          {isDepartments ? (
            <Grid item xs={12} md={6}>
              <FormSelectTreeView
                name={"departments"}
                control={form.control}
                label={t("report.department")}
                getOptions={async (keyword) => {
                  try {
                    const response = await getDepartments({
                      searchTerm: keyword,
                    });
                    const first100Departments: Department[] = (
                      response?.departments ?? []
                    ).slice(0, 150);
                    return first100Departments;
                  } catch (e) {
                    return [];
                  }
                }}
                getOptionLabel={(option) => option.name ?? ""}
                getOptionKey={(option) => option.id ?? ""}
                getOptionChildren={(option) => option.children}
                variant="outlined"
                debounceMs={FILTER_DEBOUNCE_MS}
                onChange={(value: Department[]) => {
                  const mappedValue: string[] = value.map(
                    (item) => item.id ?? ""
                  );
                  form.setValue("departments", mappedValue);
                }}
                showAllSelected={false}
                ignoreChildren
              />
            </Grid>
          ) : null}
        </Grid>
      </Box>
      <Stack
        sx={{
          backgroundColor: "white",
        }}
        p={1.5}
        direction={"row"}
        mt={1.5}
        gap={1.5}
        width={"100%"}
        justifyContent={"flex-end"}
      >
        <Button
          variant="contained"
          className="confirm"
          disabled={loading}
          sx={{ minWidth: 128 }}
          onClick={form.handleSubmit(handleSearch)}
        >
          {t("report.search")}
        </Button>
        {onExport ? (
          <Button
            variant="contained"
            className="confirm"
            disabled={loading}
            sx={{ minWidth: 128 }}
            onClick={form.handleSubmit(handleExport)}
          >
            Export
          </Button>
        ) : null}
      </Stack>
    </FormProvider>
  );
};

export default ReportFilterPanel;
