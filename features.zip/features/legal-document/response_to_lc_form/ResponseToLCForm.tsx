import { useCreateFeedBackLc } from "@/apis/service/law_document/feedbackLc";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys, StatusNextActions } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  castResponseToLCFormSchemaToOutput,
  ResponseToLCFormSchema,
  ResponseToLCFormSchemaFieldNames,
  ResponseToLCFormSchemaI,
} from "@/models/law_document/ResponseToLCForm";
import { BasedUser } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, Typography } from "@mui/material";
import { useContext } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export interface ResponseToLCFormProps {
  titlePopup?: string;
  initialValue?: any;
  legalDocumentId: number;
  nextActionId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderLegalDocument?: any;
}

const initialEmptyValue = {
  status: 8,
  users: [],
};

export const ResponseToLCForm = (props: ResponseToLCFormProps) => {
  const {
    titlePopup = "response_to_lc_form.title",
    initialValue = initialEmptyValue,
    legalDocumentId,
    nextActionId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.LEGISLATION),
    senderLegalDocument,
  } = props;
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<ResponseToLCFormSchemaI>({
    resolver: yupResolver(ResponseToLCFormSchema as any),
    defaultValues: JSON.parse(JSON.stringify(initialValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const { mutateAsync: createFeedBackLc, isPending } = useCreateFeedBackLc({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t(titlePopup),
          }).replace(/&amp;/g, "&")
        );
        onCloseForm(true);
      },
    },
  });

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { status, ...restData } = data;
    await createFeedBackLc({
      legalDocumentId,
      data: { ...restData, nextActionId },
    });
  };

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <Grid container className="form-wrapper" spacing={GLOBAL_SPACING}>
            <Grid item>
              <Grid
                container
                direction={"column"}
                rowGap={GLOBAL_SPACING}
                alignItems={"center"}
                className="form-section-wrapper"
                sx={formInputSxProps}
              >
                <Grid item width={"100%"}>
                  <Typography fontWeight="bold">
                    {t("feedbackLc.title.textName")}
                  </Typography>
                  <Typography>{name}</Typography>
                </Grid>
                <Grid item width={"100%"}>
                  <label style={{ padding: 0 }}>
                    {t(`feedbackLc.title.responder`)}
                  </label>
                  <Typography>
                    {senderLegalDocument?.name} ({senderLegalDocument?.email}) -{" "}
                    {senderLegalDocument?.departmentName ??
                      senderLegalDocument?.department?.name}
                  </Typography>
                </Grid>

                <Grid item width={"100%"}>
                  <FormSelect
                    control={form.control}
                    name={ResponseToLCFormSchemaFieldNames.STATUS}
                    label={t("next_action.field_name.status")}
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    options={Array.from(StatusNextActions.keys()).map(
                      (key) => ({
                        label: t(`next_action.option.${key}`),
                        value: StatusNextActions.get(key)!,
                      })
                    )}
                    getOptionKey={(option) => option.value}
                    getOptionLabel={(option) => option.label}
                    required
                    disabled
                  />
                </Grid>

                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={ResponseToLCFormSchemaFieldNames.CONTENT}
                    label={t(
                      `response_to_lc_form.field_name.${ResponseToLCFormSchemaFieldNames.CONTENT}`
                    )}
                    placeHolder={t(
                      `response_to_lc_form.field_name.${ResponseToLCFormSchemaFieldNames.CONTENT}`
                    )}
                    minRows={5}
                    required
                  />
                </Grid>
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={`${ResponseToLCFormSchemaFieldNames.USERS}`}
                    label={t(
                      `response_to_lc_form.field_name.${ResponseToLCFormSchemaFieldNames.USERS}`
                    )}
                    placeholder={t(
                      `response_to_lc_form.field_name.${ResponseToLCFormSchemaFieldNames.USERS}`
                    )}
                    getOptions={async (keyword) => {
                      const response = await getUsers({
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      });

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery="queryUser"
                    required
                    isFocus
                  />
                </Grid>
              </Grid>
            </Grid>

            <Grid item>
              <ReminderPickerSubForm
                name={ResponseToLCFormSchemaFieldNames.REMIND}
                module={module}
              />
            </Grid>

            <FormActionButtons
              formMode={"create"}
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              cancelConfirm={form.formState.isDirty}
              onSave={async () => {
                try {
                  onSubmit(
                    castResponseToLCFormSchemaToOutput({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </Grid>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
