import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { castFeedbackLegalDocumentRequestSchemaToDTO } from "@/models/law_document/FeedbackLegalDocument";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { useCreateAssignment } from "@/apis/service/law_document/assignment";
import {
  AssignmentFieldNames,
  AssignmentSchema,
  AssignmentSchemaI,
} from "@/models/law_document/Assignment";
import { getLegalDepartments } from "@/apis/service/department/department";
import { findDeepestId } from "@/utils";
import { useQuery, useQueryClient } from "@tanstack/react-query";

const initialEmptyValue: AssignmentSchemaI = {
  [AssignmentFieldNames.CONTENT]: "",
  [AssignmentFieldNames.USERS]: [],
  [AssignmentFieldNames.REMIND]: undefined,
};

export interface AssignmentTypeFormProps {
  titlePopup?: string;
  initialValue?: AssignmentSchemaI;
  legalDocumentId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  defaultStatus?: string;
  senderLegalDocument?: any;
  initialLegalDocument?: any;
}

export const AssignmentForm = (props: AssignmentTypeFormProps) => {
  const {
    titlePopup = "assignmentResponsibilities.title.titlePopup",
    initialValue = initialEmptyValue,
    legalDocumentId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.LEGISLATION),
    defaultStatus = LegalDocumentStatusContent.get(
      LegalDocumentUserStatusKey.ASSIGNMENT_RESPONSIBILITIES
    )!,
    senderLegalDocument,
    initialLegalDocument,
  } = props;
  const queryClient = useQueryClient();
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(AssignmentSchema),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    modules: ModuleFields.LEGISLATION_NAME.module,
    queryKey: "LEGAL_DOCUMENT_ASSIGNMENT",
  });

  const { mutateAsync: createAssignment, isPending } = useCreateAssignment({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t(titlePopup),
          })
        );
        onCloseForm(true);
        queryClient.invalidateQueries({
          queryKey: [`document-assignment-${legalDocumentId}`],
        });
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createAssignment({
      legalDocumentId,
      data,
    });
  };

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["legal-document/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const handleGetOptions = async (keyword: any) => {
    if (!getLegalDepartmentQuery.data) return [];
    const response = await getUsers({
      searchTerm: keyword,
      page: 0,
      size: 100,
      sortBy: "name",
      sortOrder: "ASC",
      departmentIds: getLegalDepartmentQuery.data
        ? [getLegalDepartmentQuery.data]
        : [],
    });
    const listAssignmentUsers = [initialLegalDocument?.pic?.id].concat(
      initialLegalDocument?.assignmentUsers?.map((law: any) => law?.id) ?? []
    );
    return (response?.users ?? [])
      ?.filter((user) => !listAssignmentUsers?.includes(user?.id))
      .map((user) => ({
        id: user.id,
        name: user.name ?? "",
        departmentName: user.department?.name,
        email: user.email,
      }));
  };
  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("assignmentResponsibilities.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`assignmentResponsibilities.title.responder`)}
                </label>
                <Typography>
                  {senderLegalDocument?.name} ({senderLegalDocument?.email}) -{" "}
                  {senderLegalDocument?.departmentName ??
                    senderLegalDocument?.department?.name}
                </Typography>
              </Grid>
              <Grid item width={"100%"} sx={{ display: "none" }}>
                <FormAsyncSelect
                  control={form.control}
                  name={AssignmentFieldNames.STATUS}
                  label={t(`assignmentResponsibilities.title.status`)}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery="status-query-assignment"
                  placeholder={t(
                    `assignmentResponsibilities.placeHolder.status`
                  )}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AssignmentFieldNames.CONTENT}
                  label={t(`assignmentResponsibilities.title.${"content"}`)}
                  placeHolder={t(
                    `assignmentResponsibilities.placeHolder.${"content"}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AssignmentFieldNames.USERS}
                    label={t("LEGISLATION.field_name.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={handleGetOptions}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"assignment/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={AssignmentFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedbackLegalDocumentRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
