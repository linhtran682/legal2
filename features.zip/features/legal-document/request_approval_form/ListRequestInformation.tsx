import { GLOBAL_SPACING } from "@/constants/format";
import { Box, Grid, Typography } from "@mui/material";
import React from "react";
import { useTranslation } from "react-i18next";

type TypePropsListAdvisorLegal = {
  data?: any;
};

export const ListRequestInformation = (props: TypePropsListAdvisorLegal) => {
  const { data } = props;
  const { t } = useTranslation();
  return (
    <Box
      display={"flex"}
      flexDirection={"column"}
      gap={GLOBAL_SPACING}
      width="100%"
    >
      {data?.map((item: any) => {
        return (
          <Grid
            key={item?.user?.id ?? item?.createdUser?.id}
            container
            direction={"column"}
            className="form-sub-section-wrapper"
            rowGap={GLOBAL_SPACING}
            position={"relative"}
          >
            <Grid item width={"100%"}>
              <label style={{padding:0}}>
                {t("approvalNextActionForm.title.userRequest")}
              </label>
              <Typography>{`${item?.user?.name ?? item?.createdUser?.name} (${
                item?.user?.email ?? item?.createdUser?.email
              }) - ${
                item?.user?.department?.name ??
                item?.createdUser?.departmentName
              }`}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <label style={{padding:0}}>
                {t(`next_action.follow_form.field_name.content`)}
              </label>
              <Typography>{item?.reason}</Typography>
            </Grid>
          </Grid>
        );
      })}
    </Box>
  );
};
