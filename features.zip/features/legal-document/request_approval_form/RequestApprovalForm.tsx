import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { LegalDocumentStatusContent, LegalDocumentUserStatusKey, Module, ModuleFields, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import {
  ApprovalConfirmRequestSchema,
  ExtensionOptions,
  RequestApprovalProps,
  RequestApprovalRequestFieldNames,
  RequestApprovalRequestSchema,
} from "@/models/law_document/RequestApproval";
import {
  useCreateRequestApproval,
  useGetRequestApproval,
  useUpdateMultipleRequestApproval,
} from "@/apis/service/law_document/requestApproval";
import { GetUsersParams, UserProfileDTO } from "@/models/user/User";
import { getUser, getUsers } from "@/apis/service/user/User";
import { castReminderInputToReminderSchema, castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { useSearchStatus } from "@/hooks/useSearchStatus";

const initialEmptyValue: RequestApprovalProps = {
  [RequestApprovalRequestFieldNames.DEADLINE]: "",
  [RequestApprovalRequestFieldNames.REASON]: "",
  [RequestApprovalRequestFieldNames.REMIND]: undefined,
};

export interface RequestApprovalTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestApprovalProps;
  legalDocumentId?: number;
  requestApprovalId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  isConfirmRequestApproval?: boolean;
  name?: string;
  selectedRequest?: any;
  module?: number;
  isDisabledStatus?: boolean;
  defaultStatus?: string;
}

export const RequestApprovalForm = (props: RequestApprovalTypeFormProps) => {
  const {
    titlePopup = "requestApproval.title.titlePopup",
    initialValue = initialEmptyValue,
    legalDocumentId,
    requestApprovalId,
    isOpen = false,
    setIsOpen,
    isConfirmRequestApproval = false,
    name,
    selectedRequest,
    module = Module.get(ModuleKeys.LEGISLATION),
    isDisabledStatus = false,
    defaultStatus = LegalDocumentStatusContent.get(
      LegalDocumentUserStatusKey.EVALUATE_REQUEST_APPROVAL
    )!
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const { data: dataRequestApproval } = useGetRequestApproval({
    request: { legalDocumentId, requestApprovalId },
    config: {
      enabled: !!legalDocumentId && !!requestApprovalId,
    },
  });

  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmRequestApproval
        ? (ApprovalConfirmRequestSchema as any)
        : RequestApprovalRequestSchema
    ),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    queryKey: "LEGAL_DOCUMENT_REQUEST_APPROVAL",
  });

  const { mutateAsync: createRequestApproval, isPending } =
    useCreateRequestApproval({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const {
    mutateAsync: updateMultipleRequestApproval,
    isPending: isLoadingUpdateRequestApproval,
  } = useUpdateMultipleRequestApproval({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(titlePopup),
          })
        );
        onCloseForm(true);
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    if (isConfirmRequestApproval) {
      await updateMultipleRequestApproval({
        legalDocumentId,
        data: {
          ...data,
          requestApprovalIds: selectedRequest?.requestApprovalIds ?? [],
        },
      });
      return;
    }

    await createRequestApproval({
      legalDocumentId,
      data: { ...data, status: +data?.status },
    });
  };

  useEffect(() => {
    if (dataRequestApproval) {
      form.reset({
        [RequestApprovalRequestFieldNames.APPROVAL_STATUS]: 1,
        ...dataRequestApproval,
        status: dataRequestApproval?.status?.id,
        departments: dataRequestApproval?.departments?.map((el: any) => el?.id),
        remind: dataRequestApproval.remind
          ? castReminderInputToReminderSchema(
              dataRequestApproval?.remind as any
            )
          : undefined,
      });
    }
  }, [dataRequestApproval]);

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("requestApproval.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              {isConfirmRequestApproval && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={ExtensionOptions}
                    name={RequestApprovalRequestFieldNames.APPROVAL_STATUS}
                    error={
                      form.formState.errors[
                        RequestApprovalRequestFieldNames.APPROVAL_STATUS
                      ] as FieldError
                    }
                  />
                </Grid>
              )}
              {!isConfirmRequestApproval && (
                <Grid item width={"100%"}>
                  <DateInput
                    name={RequestApprovalRequestFieldNames.DEADLINE}
                    control={form.control}
                    label={t(`requestApproval.title.newDeadline`)}
                    placeholder="dd/mm/yyyy"
                    required
                  />
                </Grid>
              )}
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={RequestApprovalRequestFieldNames.STATUS}
                  label={t(`requestApproval.title.status`)}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled={isDisabledStatus}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestApprovalRequestFieldNames.REASON}
                  label={t(`requestApproval.title.${"content"}`)}
                  placeHolder={t(`requestApproval.placeHolder.${"content"}`)}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormAsyncSelect<any, UserProfileDTO>
                    control={form.control}
                    name={RequestApprovalRequestFieldNames.USERS}
                    label={t("approvalNextActionForm.title.receiver")}
                    minCharLength={1}
                    placeholder={t("assignment.column.user")}
                    getOptions={async (keyword) => {
                      if (typeof keyword == "string") {
                        const params: GetUsersParams = {
                          searchTerm: keyword,
                          page: 0,
                          size: 100,
                          sortBy: "name",
                          sortOrder: "ASC",
                        };
                        const response = await getUsers(params);

                        return response?.users ?? [];
                      } else if (keyword?.length && keyword.length > 0) {
                        return getUser(keyword[0])
                          .then((response) => (response ? [response] : []))
                          .catch(() => []);
                      }

                      return [];
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.department?.name ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"requestApproval/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={RequestApprovalRequestFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isLoadingUpdateRequestApproval}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    users: form.getValues().users ? [form.getValues().users] : [],
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(form.getValues().remind)
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
