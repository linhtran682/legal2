import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import {
  Module,
  ModuleKeys,
  StatusNextActions,
  StatusNextActionsKey,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import {
  ApprovalNextActionFormOutput,
  ApprovalNextActionFormSchema,
  ApprovalNextActionFormSchemaFieldNames,
} from "@/models/law_document/ApprovalNextAction";
import {
  useCreateApprovalNextAction,
  useGetListApprovalNextAction,
} from "@/apis/service/law_document/approvalNextAction";
import { ListRequestInformation } from "./ListRequestInformation";
import {
  useCreateReviewApproval,
  useGetRequestApproval,
} from "@/apis/service/law_document/requestApproval";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";

const initialEmptyValue: ApprovalNextActionFormOutput = {
  [ApprovalNextActionFormSchemaFieldNames.STATUS]: 3,
  [ApprovalNextActionFormSchemaFieldNames.REASON]: "",
  [ApprovalNextActionFormSchemaFieldNames.USERS]: [],
  [ApprovalNextActionFormSchemaFieldNames.REMIND]: undefined,
};

type TypeRequestSelectData = {
  nextActionItems?: any;
  nextActionIds?: number[];
};

type TypeOptionsStatus = {
  label: string;
  value: number;
};
export interface ApprovalNextActionTypeFormProps {
  titlePopup?: string;
  initialValue?: ApprovalNextActionFormOutput;
  legalDocumentId?: number;
  nextActionId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  isDisabledStatus?: boolean;
  requestSelectData?: TypeRequestSelectData;
  isApproveReview?: boolean;
  requestApprovalId?: number;
  optionsStatus?: TypeOptionsStatus[];
}

export const ApprovalNextActionForm = (
  props: ApprovalNextActionTypeFormProps
) => {
  const {
    titlePopup = "approvalNextActionForm.title.titlePopup",
    initialValue = initialEmptyValue,
    legalDocumentId,
    nextActionId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.LEGISLATION),
    isDisabledStatus = false,
    requestSelectData,
    isApproveReview = false,
    requestApprovalId,
    optionsStatus,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const form = useForm<any>({
    resolver: yupResolver(ApprovalNextActionFormSchema),
    defaultValues: initialValue,
  });

  const { data: listApprovalNextAction } = useGetListApprovalNextAction({
    request: { legalDocumentId, nextActionId },
    config: {
      enabled: !!legalDocumentId && !!nextActionId,
    },
  });

  const { data: listApprovalReview } = useGetRequestApproval({
    request: { legalDocumentId, requestApprovalId },
    config: {
      enabled: !!legalDocumentId && !!isApproveReview && !!requestApprovalId,
    },
  });

  const { mutateAsync: createApprovalNextAction, isPending } =
    useCreateApprovalNextAction({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("requestApproval.title.titlePopup"),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const {
    mutateAsync: createReviewApproval,
    isPending: isPendingReviewApproval,
  } = useCreateReviewApproval({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t("requestApproval.title.titlePopup"),
          })
        );
        onCloseForm(true);
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    if (isApproveReview) {
      await createReviewApproval({
        legalDocumentId,
        requestApprovalId,
        data: {
          ...data,
          status: +data?.status,
          approvalStatus: +data?.status,
          ...requestSelectData,
        },
      });
      return;
    }
    await createApprovalNextAction({
      legalDocumentId,
      nextActionId,
      data: { ...data, status: +data?.status, ...requestSelectData },
    });
  };

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("approvalNextActionForm.title.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              {(listApprovalNextAction?.length || listApprovalReview) && (
                <ListRequestInformation
                  data={listApprovalNextAction || [listApprovalReview ?? {}]}
                />
              )}
              <Grid item width={"100%"}>
                <FormSelect
                  control={form.control}
                  name={ApprovalNextActionFormSchemaFieldNames.STATUS}
                  options={
                    optionsStatus ?? [
                      {
                        label: t(
                          `next_action.option.${StatusNextActionsKey.NEXT_ACTION_APPROVAL}`
                        ),
                        value: StatusNextActions.get(
                          StatusNextActionsKey.NEXT_ACTION_APPROVAL
                        ),
                      },
                      {
                        label: t(
                          `next_action.option.${StatusNextActionsKey.NEXT_ACTION_REJECT}`
                        ),
                        value: StatusNextActions.get(
                          StatusNextActionsKey.NEXT_ACTION_REJECT
                        ),
                      },
                    ]
                  }
                  label={t(`approvalNextActionForm.title.status`)}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  isClearIcon
                  required
                  disabled={isDisabledStatus}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ApprovalNextActionFormSchemaFieldNames.REASON}
                  label={t(`approvalNextActionForm.title.reason`)}
                  placeHolder={t(`approvalNextActionForm.title.reason`)}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}> 
                <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={ApprovalNextActionFormSchemaFieldNames.USERS}
                    label={t("approvalNextActionForm.title.receiver")}
                    placeholder={t('assignment.column.user')}
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"approvalNextAction/queryUser"}
                    required
                    isFocus
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={ApprovalNextActionFormSchemaFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isPendingReviewApproval}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    users:
                      form.getValues().users?.map((ele: BasedUser) => ele.id) ||
                      [],
                    remind: form.getValues()?.remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
