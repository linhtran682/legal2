import { uploadLegalDocumentTabAttachments } from "@/apis/service/files_upload/files";
import {
  commentLegalDocument,
  getLegalDocumentAssignments,
  getLegalDocumentComments,
  getLegalDocumentEvaluation,
  getLegalDocumentExtend,
  getLegalDocumentFeedbacks,
  getLegalDocumentForwards,
  getLegalDocumentHistory,
  getLegalDocumentRequestApproval,
  getLegalDocumentTabAttachments,
} from "@/apis/service/law_document/law_document";
import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { TabNav } from "@/components/commons/tab-nav/TabNav";
import { UploadPanel } from "@/components/commons/upload/upload_panel/UploadPanel";
import { COLOR_TYPE } from "@/constants/color";
import { AppContext } from "@/context/AppContext";
import { CommentPanel } from "@/features/metadata_tab_panel/comment_panel/CommentPanel";
import { ConfirmPanel } from "@/features/metadata_tab_panel/confirm_panel/ConfirmPanel";
import { EvaluationPanel } from "@/features/metadata_tab_panel/evaluation_panel/EvaluationPanel";
import { ExtendPanel } from "@/features/metadata_tab_panel/extend_panel/ExtendPanel";
import { GenericContentPanel } from "@/features/metadata_tab_panel/generic_content_panel/GenericContentPanel";
import { HistoryPanel } from "@/features/metadata_tab_panel/history_panel/HistoryPanel";
import { LANGUAGES } from "@/locales/config-translation";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import { AdviceAssignment } from "@/models/legal-advice/LegalAdviceList";
import { Feedback, Forward } from "@/models/metadata/Metadata";
import { getUserLabel } from "@/utils";
import { useContext } from "react";
import { useTranslation } from "react-i18next";

export interface LegalMetadataTabPanelProps {
  documentId: number;
  legalDocument?: LawDocumentBodyReceive;
  loading?: boolean;
}

export const LegalMetadataTabPanel = (props: LegalMetadataTabPanelProps) => {
  const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const isEnglish = i18n.language === LANGUAGES.ENGLISH

  return (
    <LoadingWrapper loading={props.loading || appContext.loading}>
      {props.legalDocument && (
        <div style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
          <TabNav
            tabItems={[
              {
                key: "attachment",
                label: t("metadata.attachment.title"),
                content: (
                  <UploadPanel
                    queryKey="legal-document-upload"
                    onGetFiles={async () =>
                      (
                        (await getLegalDocumentTabAttachments(props.documentId))
                          ?.data || []
                      ).map((legalDocumentAttachment) => ({
                        fileId: legalDocumentAttachment.fileId,
                        fileName: legalDocumentAttachment.fileName,
                        storagePath: legalDocumentAttachment.filePath,
                        uploadDate: legalDocumentAttachment.uploadDate,
                      }))
                    }
                    onDelete={() => Promise.resolve()}
                    onUpload={async (files) => {
                      await uploadLegalDocumentTabAttachments({
                        files: files,
                        id: props.documentId,
                      });
                    }}
                    disabled={
                      !appContext.meCanRead ||
                      props.legalDocument?.legalDocumentActions?.length === 0
                    }
                  />
                ),
              },
              {
                key: "assignment",
                label: t("legalAdvice.tabs.assignment"),
                content: (
                  <GenericContentPanel<AdviceAssignment>
                    getData={async () => {
                      return (
                        (await getLegalDocumentAssignments(props.documentId))
                          ?.assignmentResponseDetails ?? []
                      );
                    }}
                    getTitle={(item) =>
                      getUserLabel(item.assignUser, isEnglish)
                    }
                    getDisplayDate={(item) => item.date}
                    getSubtitle={(item) =>
                      `${t("assignmentResponsibilities.title.assignTo")}:  ${item?.receiveUsers
                        ?.map((user) => getUserLabel(user, isEnglish))
                        .join(", ")}`
                    }
                    contentHeader="legalAdvice.tabs.assignmentContent"
                    getContent={(item) => item.content}
                    queryKey={`document-assignment-${props.documentId}`}
                  />
                ),
              },
              {
                key: "feedback",
                label: t("metadata.feedback.title"),
                content: (
                  <GenericContentPanel<Feedback>
                    queryKey="legal-document-feedback"
                    getData={async () =>
                      (await getLegalDocumentFeedbacks(props.documentId)).result
                        ?.feedbackResponseDetails ?? []
                    }
                    getTitle={(item) =>
                      getUserLabel(item?.feedbackUser, isEnglish)
                    }
                    getDisplayDate={(item) => item.feedbackDate}
                    getSubtitle={(item) =>
                      t("metadata.feedback.subject", {
                        value: getUserLabel(item.receiverUser, isEnglish),
                      })
                    }
                    contentHeader="metadata.feedback.content"
                    getContent={(item) => item?.content}
                  />
                ),
              },
              {
                key: "forward",
                label: t("metadata.forward.title"),
                content: (
                  <GenericContentPanel<Forward>
                    queryKey="legal-document-forward"
                    getData={async () =>
                      (await getLegalDocumentForwards(props.documentId)).result
                        ?.forwardResponseDetails ?? []
                    }
                    getTitle={(item) =>
                      getUserLabel(item?.forwardUser, isEnglish)
                    }
                    getDisplayDate={(item) => item.forwardDate}
                    getSubtitle={(item) =>
                      t("metadata.forward.forwardedTo", {
                        value: getUserLabel(item.receiveUser, isEnglish),
                      })
                    }
                    contentHeader="legalAdvice.forwardLegalAdvice.title.content"
                    getContent={(item) => item?.content}
                  />
                ),
              },
              {
                key: "evaluation",
                label: t("metadata.evaluation.title"),
                content: (
                  <EvaluationPanel
                    queryKey="legal-document-evaluation"
                    getEvaluations={async () =>
                      (await getLegalDocumentEvaluation(props.documentId))
                        .result?.responses ?? []
                    }
                  />
                ),
              },
              {
                key: "history",
                label: t("metadata.history.title"),
                content: (
                  <HistoryPanel
                    queryKey="legal-document-history"
                    getHistoryRecords={async () =>
                      (await getLegalDocumentHistory(props?.documentId)).result
                        ?.data ?? []
                    }
                  />
                ),
              },
              {
                key: "extend",
                label: t("metadata.extend.title"),
                content: (
                  <ExtendPanel
                    queryKey="legal-document-extend"
                    getExtendRecords={async () =>
                      (await getLegalDocumentExtend(props?.documentId)).result
                        ?.deadlineResponses ?? []
                    }
                    documentId={props?.documentId}
                    legalDocument={props?.legalDocument}
                  />
                ),
              },
              {
                key: "confirm",
                label: t("metadata.confirm.title"),
                content: (
                  <ConfirmPanel
                    queryKey="legal-document-confirm"
                    getConfirmRecords={async () =>
                      (await getLegalDocumentRequestApproval(props?.documentId))
                        .result?.requestApprovalResponses ?? []
                    }
                  />
                ),
              },
              {
                key: "comment",
                label: t("metadata.comment.title"),
                content: (
                  <CommentPanel
                    queryKey="legal-document-comment"
                    getComments={async () => {
                      return (
                        (await getLegalDocumentComments(props.documentId))
                          .result?.data ?? []
                      );
                    }}
                    addComment={(comment) =>
                      commentLegalDocument({
                        id: props.documentId,
                        content: comment,
                      })
                    }
                    disabled={
                      !appContext.meCanRead ||
                      props.legalDocument?.legalDocumentActions?.length === 0
                    }
                  />
                ),
              },
            ]}
          />
        </div>
      )}
    </LoadingWrapper>
  );
};
