import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { castFeedbackLegalDocumentRequestSchemaToDTO } from "@/models/law_document/FeedbackLegalDocument";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import {
  RequestVendorFieldNames,
  RequestVendorSchema,
  RequestVendorSchemaI,
} from "@/models/law_document/RequestVendor";
import { useCreateRequestVendor } from "@/apis/service/law_document/request_vendor";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { useQuery } from "@tanstack/react-query";
import { getLegalDepartments } from "@/apis/service/department/department";
import { findDeepestId } from "@/utils";

const initialEmptyValue: RequestVendorSchemaI = {
  [RequestVendorFieldNames.TIME_VENDOR_RESPONSE]: "",
  [RequestVendorFieldNames.USERS]: [],
  [RequestVendorFieldNames.REMIND]: undefined,
};

export interface RequestVendorTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestVendorSchemaI;
  legalDocumentId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  defaultStatus?: string;
  senderLegalDocument?: any;
}

export const RequestVendorForm = (props: RequestVendorTypeFormProps) => {
  const {
    titlePopup = "requestVendor.title.titlePopup",
    initialValue = initialEmptyValue,
    legalDocumentId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.LEGISLATION),
    defaultStatus = LegalDocumentStatusContent.get(
      LegalDocumentUserStatusKey.REQUEST_VENDOR
    )!,
    senderLegalDocument,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(RequestVendorSchema),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    modules: ModuleFields.LEGISLATION_NAME.module,
    queryKey: "LEGAL_DOCUMENT_REQUEST_VENDOR",
  });

  const { mutateAsync: createRequestVendor, isPending } =
    useCreateRequestVendor({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createRequestVendor({
      legalDocumentId,
      data,
    });
  };

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["legal-document/get-legal-department-vendor"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("requestVendor.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`requestVendor.title.responder`)}
                </label>
                <Typography>
                  {senderLegalDocument?.name} ({senderLegalDocument?.email}) -{" "}
                  {senderLegalDocument?.departmentName ??
                    senderLegalDocument?.department?.name}
                </Typography>
              </Grid>
              <Grid item width={"100%"} sx={{ display: "none" }}>
                <FormAsyncSelect
                  control={form.control}
                  name={RequestVendorFieldNames.STATUS}
                  label={t(`requestVendor.title.status`)}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery="status-query-assignment"
                  placeholder={t(`requestVendor.placeHolder.status`)}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestVendorFieldNames.TIME_VENDOR_RESPONSE}
                  control={form.control}
                  placeholder={"dd/mm/yyyy"}
                  label={t(`requestVendor.title.date`)}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={RequestVendorFieldNames.USERS}
                    label={t("LEGISLATION.field_name.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      if (!getLegalDepartmentQuery.data) return [];
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                        departmentIds: getLegalDepartmentQuery.data
                          ? [getLegalDepartmentQuery.data]
                          : [],
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"assignment/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={RequestVendorFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedbackLegalDocumentRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
