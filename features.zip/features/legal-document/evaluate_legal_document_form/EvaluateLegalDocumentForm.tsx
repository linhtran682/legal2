import { evaluateLegalDocument } from "@/apis/service/law_document/law_document";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  LawDocumentBodyReceive,
  SaveLawDocumentRequestFieldNames,
} from "@/models/law_document/LawDocument";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import {
  castEvaluateLegalDocumentRequestSchemaToDTO,
  EvaluateLegalDocumentRequestFieldNames,
  EvaluateLegalDocumentRequestSchema,
  EvaluateLegalDocumentRequestSchemaI,
} from "../../../models/law_document/EvaluateLegalDocument";
import { useSearchStatus } from "@/hooks/useSearchStatus";

export interface EvaluateLegalDocumentFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  legalDocumentId?: number;
  extendDeadlineId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  initialValues?: LawDocumentBodyReceive;
  requestEvaluateId?: number;
  module?: number;
  defaultStatus?: string;
  senderLegalDocument?: any
}

const initialEmptyValue: EvaluateLegalDocumentRequestSchemaI = {
  users: [],
};

export const EvaluateLegalDocumentForm = (
  props: EvaluateLegalDocumentFormProps
) => {
  const {
    titlePopup = "evaluate.title.titlePopup",
    isOpen = false,
    setIsOpen,
    initialValues,
    legalDocumentId,
    module = Module.get(ModuleKeys.LEGISLATION),
    defaultStatus = LegalDocumentStatusContent.get(
      LegalDocumentUserStatusKey.EVALUATE
    )!,
    senderLegalDocument
  } = props;
  const [t] = useTranslation();
  const queryClient = useQueryClient();
  const appContext = useContext(AppContext);
  const form = useForm<any>({
    resolver: yupResolver(EvaluateLegalDocumentRequestSchema as any),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const querySearchStatus = useSearchStatus({
    keyword: defaultStatus,
    form,
    queryKey: "LEGAL_DOCUMENT_EVALUATE",
  });
  // const getEvaluateRequest = useQuery({
  //   queryKey: ['evaluate-form/get-request', legalDocumentId],
  //   queryFn: () => getLegalDocumentEvaluation(legalDocumentId),
  //   enabled: false
  // });
  const evaluateLegalDocumentQuery = useMutation({
    mutationFn: evaluateLegalDocument,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm(true);
      queryClient.invalidateQueries({
        queryKey: ["legal-document-evaluation"],
      });
    },
  });

  useEffect(() => {
    if (querySearchStatus?.data?.[0]?.id && initialValues) {
      form.reset({
        status: querySearchStatus?.data?.[0]?.id,
        users: initialValues?.users,
      });
    }
  }, [querySearchStatus?.data?.[0]?.id, initialValues]);

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <FormProvider {...form}>
        <Grid container className="form-wrapper" spacing={GLOBAL_SPACING}>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <Typography fontWeight="bold">
                    {t("LEGISLATION.title.comparedDocumentName")}
                  </Typography>
                  <Typography>
                    {initialValues?.attachmentsSharepoint?.length
                      ? initialValues?.attachmentsSharepoint
                          ?.filter((attachments) => attachments?.isEvaluateFile)
                          ?.map((ele, index) => (
                            <Typography
                              key={ele.id.toString() + index.toString()}
                            >
                              {ele.fileName}
                            </Typography>
                          ))
                      : null}
                  </Typography>
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {t(`LEGISLATION.field_name.sender`)}
                </label>
                {senderLegalDocument && (
                  <Typography>
                    {senderLegalDocument?.name} ({senderLegalDocument?.email}) -{" "}
                    {senderLegalDocument?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={SaveLawDocumentRequestFieldNames.STATUS}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.STATUS}`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query-evaluate"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12} sx={{marginTop:"24px"}}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={"users"}
                    label={t(`LEGISLATION.field_name.receiver`)}
                    placeholder={t(
                      `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.PERSON_RESPONSIBLE}`
                    )?.toLocaleLowerCase()}
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option.department?.name ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery="queryUser/Evaluate"
                    minCharLength={1}
                    required
                    isFocus
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>

          <Grid item>
            <ReminderPickerSubForm
              name={EvaluateLegalDocumentRequestFieldNames.REMIND}
              module={module}
            />
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={false}
            onCancel={onCloseForm}
            cancelConfirm={form.formState.isDirty}
            textSave="common.button.send"
            onSave={() =>
              legalDocumentId &&
              evaluateLegalDocumentQuery.mutate({
                id: legalDocumentId,
                request: castEvaluateLegalDocumentRequestSchemaToDTO({
                  ...form.getValues(),
                }),
              })
            }
          />
        </Grid>
      </FormProvider>
    </ModalCommon>
  );
};
