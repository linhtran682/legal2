import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { FormControl, Grid, Typography } from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import {
  castSendLegalDocumentRequestSchemaToDTO,
  SendLegalDocumentRequestFieldNames,
  SendLegalDocumentRequestSchema,
  SendLegalDocumentRequestSchemaI,
} from "../../../models/law_document/SendLegalDocument";
import { yupResolver } from "@hookform/resolvers/yup";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { useTranslation } from "react-i18next";
import { useRouter } from "next/router";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { useMutation } from "@tanstack/react-query";
import { sendLegalDocument } from "@/apis/service/law_document/law_document";
import { toast } from "react-toastify";
import { SaveLawDocumentRequestFieldNames } from "@/models/law_document/LawDocument";
import { useContext } from "react";
import { AppContext } from "@/context/AppContext";
import { Module, ModuleKeys } from "@/constants/general";

export interface SendLegalDocumentFormProps {
  id: number;
  name: string;
}

const initialEmptyValue: SendLegalDocumentRequestSchemaI = {
  userIds: [],
  status: -1,
};

export const SendLegalDocumentForm = (props: SendLegalDocumentFormProps) => {
  const [t] = useTranslation();
  const router = useRouter();
  const appContext = useContext(AppContext);

  //fix build SendLegalDocumentRequestSchemaI
  const form = useForm<any>({
    resolver: yupResolver(SendLegalDocumentRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const sendLegalDocumentQuery = useMutation({
    mutationFn: sendLegalDocument,
    onSuccess: () => {
      toast.success(t("LEGISLATION.message.send_success"));
      router.back();
    },
  });

  return (
    <FormProvider {...form}>
      <Grid container className='form-wrapper' spacing={GLOBAL_SPACING}>
        <Grid item>
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className='form-section-wrapper'
            sx={formInputSxProps}
          >
            <Grid item width={"100%"}>
              <FormControl size='small' fullWidth>
                <label style={{padding:0}}>
                  {t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DOCUMENT_NAME}`
                  )}
                </label>
                <Typography paddingLeft={GLOBAL_SPACING}>
                  {props.name}
                </Typography>
              </FormControl>
            </Grid>

            <Grid item width={"100%"}>
              <DateInput
                name={SendLegalDocumentRequestFieldNames.DEADLINE}
                control={form.control}
                label={t(
                  `LEGISLATION.field_name.${SendLegalDocumentRequestFieldNames.DEADLINE}`
                )}
                placeholder={t(
                  `LEGISLATION.field_name.${SendLegalDocumentRequestFieldNames.DEADLINE}`
                )}
                required
              />
            </Grid>
            <Grid item width={"100%"}>
              <FormTextArea
                control={form.control}
                name={SendLegalDocumentRequestFieldNames.CONTENT}
                label={t(
                  `LEGISLATION.field_name.${SendLegalDocumentRequestFieldNames.CONTENT}`
                )}
                placeHolder={t(
                  `LEGISLATION.field_name.${SendLegalDocumentRequestFieldNames.CONTENT}`
                )}
                minRows={5}
                required
              />
            </Grid>
          </Grid>
        </Grid>

        <Grid item>
          <ReminderPickerSubForm
            name={SendLegalDocumentRequestFieldNames.REMIND}
            module ={Module.get(ModuleKeys.LEGISLATION)}
          />
        </Grid>

        <FormActionButtons
          formMode={"update"}
          loading={false}
          onCancel={() => router.back()}
          cancelConfirm={form.formState.isDirty}
          onSave={() =>
            props.id &&
            sendLegalDocumentQuery.mutate({
              id: props.id,
              request: castSendLegalDocumentRequestSchemaToDTO(
                form.getValues()
              ),
            })
          }
        />
      </Grid>
    </FormProvider>
  );
};
