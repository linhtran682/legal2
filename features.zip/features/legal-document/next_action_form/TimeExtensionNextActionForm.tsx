import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  ConfirmExtensionRequestSchema,
  ExtensionOptions,
  TimeExtensionRequestFieldNames,
  TimeExtensionRequestSchema,
  TimeExtensionRequestSchemaI,
} from "@/models/law_document/TimeExtension";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import {
  useCreateTimeExtensionNextAction,
  useGetTimeExtension,
  useUpdateTimeExtension,
} from "@/apis/service/law_document/time_extension";
import { toast } from "react-toastify";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { getDepartments } from "@/apis/service/department/department";
import { Department } from "@/models/department/Department";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { useQueryClient } from "@tanstack/react-query";
import { castFeedbackLegalDocumentRequestSchemaToDTO } from "@/models/law_document/FeedbackLegalDocument";
import { castReminderInputToReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import moment from "moment";

const initialEmptyValue: TimeExtensionRequestSchemaI = {
  [TimeExtensionRequestFieldNames.NEW_DEADLINE]: "",
  [TimeExtensionRequestFieldNames.REASON]: "",
  [TimeExtensionRequestFieldNames.USERS]: [],
  [TimeExtensionRequestFieldNames.REMIND]: undefined,
};

export interface TimeExtensionTypeFormProps {
  titlePopup?: string;
  initialValue?: TimeExtensionRequestSchemaI;
  legalDocumentId?: number;
  nextActionId?: number;
  extendDeadlineId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  isConfirmExtension?: boolean;
  name?: string;
  handleSubmit?: any;
  maxDate?: string;
  module?: number;
}

export const TimeExtensionNextActionForm = (props: TimeExtensionTypeFormProps) => {
  const {
    titlePopup = "timeExtension.title.titlePopup",
    initialValue = initialEmptyValue,
    legalDocumentId,
    nextActionId,
    extendDeadlineId,
    isOpen = false,
    setIsOpen,
    isConfirmExtension = false,
    name,
    handleSubmit,
    maxDate = undefined,
    module = Module.get(ModuleKeys.LEGISLATION)
  } = props;
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const formRef = useRef<HTMLFormElement>(null);
  const { data: getDataTimeExtension } = useGetTimeExtension({
    request: { legalDocumentId, extendDeadlineId },
    config: {
      enabled: !!legalDocumentId && !!extendDeadlineId && isConfirmExtension,
    },
  });

  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmExtension
        ? TimeExtensionRequestSchema.concat(ConfirmExtensionRequestSchema)
        : TimeExtensionRequestSchema
    ),
    defaultValues: initialValue,
  });

  const { mutateAsync: createTimeExtension, isPending } =
    useCreateTimeExtensionNextAction({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("timeExtension.title.titlePopup"),
            })
          );
          onCloseForm(true);
          queryClient.invalidateQueries({
            queryKey: ["legal-document-extend"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get-department-status"],
          });
        },
      },
    });

  const {
    mutateAsync: updateTimeExtension,
    isPending: isLoadingUpdateTimeExtension,
  } = useUpdateTimeExtension({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t("timeExtension.title.titlePopup"),
          })
        );
        onCloseForm();
        queryClient.invalidateQueries({
          queryKey: ["legal-document-extend"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get-department-status"],
        });
      },
    },
  });

  const onCloseForm = (reload: boolean= false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    if (isConfirmExtension) {
      await updateTimeExtension({
        legalDocumentId,
        extendDeadlineId,
        data: {
          remind: data?.remind,
          departments: data?.departments,
          users: data?.users,
          ...(!data?.confirm && {
            acceptableDeadline: data?.acceptableDeadline,
            acceptableReason: data?.acceptableReason,
          }),
        },
      });
      handleSubmit && handleSubmit();
      return;
    }
    await createTimeExtension({
      legalDocumentId,
      nextActionId,
      data,
    });
  };

  useEffect(() => {
    if (getDataTimeExtension) {
      form.reset({
        ...getDataTimeExtension,
        [TimeExtensionRequestFieldNames.CONFIRM]: 1,
        users: getDataTimeExtension?.responsibleUsers,
        departments: getDataTimeExtension?.departments?.map((el: any)=>el?.id),
        remind: getDataTimeExtension?.detailRemindNonTemplateResponse
          ? castReminderInputToReminderSchema(
              getDataTimeExtension?.detailRemindNonTemplateResponse as any
            )
          : undefined,
      });
    }
  }, [getDataTimeExtension]);

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("timeExtension.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              {isConfirmExtension && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={ExtensionOptions}
                    name={TimeExtensionRequestFieldNames.CONFIRM}
                    error={
                      form.formState.errors[
                        TimeExtensionRequestFieldNames.CONFIRM
                      ] as FieldError
                    }
                  />
                </Grid>
              )}
              <Grid item width={"100%"}>
                <DateInput
                  name={TimeExtensionRequestFieldNames.NEW_DEADLINE}
                  control={form.control}
                  label={t(`timeExtension.title.newDeadline`)}
                  placeholder={t(`timeExtension.placeHolder.newDeadline`)}
                  minDate={moment(new Date()).subtract(1, 'days').toDate()}
                  maxDate={maxDate}
                  required
                  disabled={isConfirmExtension}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={TimeExtensionRequestFieldNames.REASON}
                  label={t(`timeExtension.title.reason`)}
                  placeHolder={t(`timeExtension.placeHolder.reason`)}
                  minRows={5}
                  required
                  disabled={isConfirmExtension}
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={6}>
                  <FormSelectTreeView
                    name={TimeExtensionRequestFieldNames.DEPARTMENTS}
                    control={form.control}
                    label={t("assignment.column.assignedPerson")}
                    getOptions={async (keyword) => {
                      try {
                        const response = await getDepartments({
                          searchTerm: keyword,
                        });
                        const first100Departments: Department[] = (
                          response?.departments ?? []
                        ).slice(0, 150);
                        return first100Departments; // Assuming the data is in response.data
                      } catch (e) {
                        return [];
                      }
                    }}
                    getOptionLabel={(option) => option.name ?? ""}
                    getOptionKey={(option) => option.id ?? ""}
                    getOptionChildren={(option) => option.children}
                    variant="outlined"
                    debounceMs={FILTER_DEBOUNCE_MS}
                    onChange={(value: Department[]) => {
                      const mappedValue: string[] = value.map(
                        (item) => item.id ?? ""
                      );
                      form.setValue("departments", mappedValue);
                      queryClient.invalidateQueries({
                        queryKey: ["timeExtension/queryUser"],
                      });
                    }}
                    rules={{ required: "This field is required" }}
                    selectedItemsProp={
                      getDataTimeExtension?.departments ?? undefined
                    }
                  />
                </Grid>
                <Grid item xs={6} sx={{marginTop:"24px"}}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={TimeExtensionRequestFieldNames.USERS}
                    label={""}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const selectedDepartments = form.getValues("departments");
                      if (selectedDepartments?.length) {
                        params.departmentIds = selectedDepartments;
                      }
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"timeExtension/queryUser"}
                    isFocus
                  />
                </Grid>
              </Grid>
              {isConfirmExtension && (
                <>
                  <Grid item width={"100%"}>
                    <DateInput
                      name={TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE}
                      control={form.control}
                      label={t(`timeExtension.title.newDeadlineAccept`)}
                      placeholder={t(
                        `timeExtension.placeHolder.newDeadlineAccept`
                      )}
                      required
                      disabled={form?.watch(
                        TimeExtensionRequestFieldNames.CONFIRM
                      )}
                    />
                  </Grid>
                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={
                        TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON
                      }
                      label={t(`timeExtension.title.reason`)}
                      placeHolder={t(`timeExtension.placeHolder.reason`)}
                      minRows={5}
                      required
                      disabled={form?.watch(
                        TimeExtensionRequestFieldNames.CONFIRM
                      )}
                    />
                  </Grid>
                </>
              )}
            </Grid>
            <ReminderPickerSubForm
              name={TimeExtensionRequestFieldNames.REMIND}
              module ={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isLoadingUpdateTimeExtension}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...castFeedbackLegalDocumentRequestSchemaToDTO({...form.getValues()}),
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
