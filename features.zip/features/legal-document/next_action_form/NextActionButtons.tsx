import { IconAssignment } from "@/assets/iconMenu/IconAssignment";
import { IconConfirm } from "@/assets/iconMenu/IconConfirm";
import { IconDone } from "@/assets/iconMenu/IconDone";
import { IconFeedback } from "@/assets/iconMenu/IconFeedback";
import { ActionButtonItem } from "@/components/commons/action_button/ActionButtonCustom";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { COLOR_TYPE } from "@/constants/color";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserRole,
  LegalDocumentUserRoleKey,
  LegalDocumentUserStatusKey,
  StatusNextActions,
  StatusNextActionsKey,
} from "@/constants/general";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { statusButtonActionLaw } from "../legal_document_table/legal_document_table_actions/LegalDocumentTableActionsText";
import { NextActionInputReceive } from "@/models/law_document/NextActionLegalDocument";
import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";

type TypeActionRole = {
  typeBtn: string;
  disable?: boolean;
};
const btnActionKeyV2NextAction: any = {
  feedbackLC: "feedbackLc",
  nextActionRequestApprove: "requestApproval",
  nextActionApprove: "approval",
  timeExtensionRequest: "timeExtensionRequest ",
}
export const ButtonNextActionLegal = {
  CREATE_NEW: "create", // Tạo mới
  REQUEST_APPROVAL: "requestApproval", // Yêu cầu duyệt
  APPROVAL: "approval", // Duyệt
  MONITOR_NEXT_ACTION: "monitorNextAction", // Theo dõi Next action
  FEEDBACK_LC: "feedbackLc", // Phản hồi L&C
  FEEDBACK_EVALUATED: "feedbackEvaluated", // Phản hồi đánh giá
  COMPLETE_EVALUATED: "completeEvaluated", // Hoàn thành đánh giá
  TIME_EXTENSION_REQUEST : "timeExtensionRequest ", // Yêu cầu gia hạn thời gian
};

type TypePropsLegalDocumentNextAction = {
  legalDocumentRoles?: number[];
  status?: number;
  initialLawDocument?: LawDocumentBodyReceive,
  initialLawNextAction?: any,
  isDisableApproval?: boolean;
  handleClickRequestApproval?: () => void;
  handleClickApproval?: () => void;
  handleClickAssessmentFeedback?: () => void;
  handleClickFollowNextAction?: () => void;
  handleClickResponseLc?: () => void;
  handleClickFinishEvaluate?: () => void;
  handleClickTimeExtendRequest?: () => void;
};

const uniqueCheck = (checkData: TypeActionRole[]) => {
  return checkData.reduce(
    (accumulator: TypeActionRole[], currentValue: TypeActionRole) => {
      const existing = accumulator.find(
        (item) => item.typeBtn === currentValue.typeBtn
      );

      if (existing) {
        if (Boolean(existing?.disable) === Boolean(currentValue?.disable)) {
          accumulator = accumulator.filter(
            (item) => item.typeBtn !== currentValue.typeBtn
          );
          accumulator.push(currentValue);
        } else {
          const indexAcc = accumulator.findIndex(
            (item: TypeActionRole) => item.typeBtn === currentValue.typeBtn
          );
          accumulator.splice(indexAcc, 1, { ...currentValue, disable: false });
        }
      } else {
        accumulator.push(currentValue);
      }

      return accumulator;
    },
    []
  );
};

const authorizedActionMapCallBack = (
  legalDocumentRoles: number[] = [],
  status?: number,
  initialLawDocument?: LawDocumentBodyReceive,
  initialLawNextAction?: NextActionInputReceive,
  // isDisableApproval?: boolean
) => {
  const isStatusLegalDocumentDone = initialLawDocument?.status?.name === LegalDocumentStatusContent.get(
    LegalDocumentUserStatusKey.DONE
  )!
  const listNextActions = new Map<number, any>([
    [
      LegalDocumentUserRole.get(LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT)!,
      [
        // {
        //   typeBtn: ButtonNextActionLegal.REQUEST_APPROVAL,
        //   disable: isStatusLegalDocumentDone || ![
        //     StatusNextActions.get(StatusNextActionsKey.GENERATE_NEXT_ACTION),
        //     StatusNextActions.get(StatusNextActionsKey.REQUEST_APPROVAL),
        //     StatusNextActions.get(StatusNextActionsKey.NEXT_ACTION_REJECT),
        //     StatusNextActions.get(StatusNextActionsKey.FEEDBACK_EVALUATED),
        //   ].includes(status),
        // },
        // {
        //   typeBtn: ButtonNextActionLegal.FEEDBACK_LC,
        //   disable: isStatusLegalDocumentDone || ![
        //     StatusNextActions.get(StatusNextActionsKey.FEEDBACK_LC),
        //     StatusNextActions.get(StatusNextActionsKey.NEXT_ACTION_APPROVAL),
        //     StatusNextActions.get(StatusNextActionsKey.FEEDBACK_EVALUATED),
        //   ].includes(status),
        // },
      ],
    ],
    [
      LegalDocumentUserRole.get(
        LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT
      )!,
      [
        // {
        //   typeBtn: ButtonNextActionLegal.APPROVAL,
        //   disable: isStatusLegalDocumentDone || ![
        //     StatusNextActions.get(StatusNextActionsKey.REQUEST_APPROVAL),
        //     StatusNextActions.get(StatusNextActionsKey.NEXT_ACTION_APPROVAL),
        //     StatusNextActions.get(StatusNextActionsKey.NEXT_ACTION_REJECT),
        //   ].includes(status) || isDisableApproval,
        // },
      ],
    ],
    [
      LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC)!,
      [
        {
          typeBtn: ButtonNextActionLegal.MONITOR_NEXT_ACTION,
          disable: isStatusLegalDocumentDone || ![
            StatusNextActions.get(StatusNextActionsKey.FEEDBACK_LC),
            StatusNextActions.get(StatusNextActionsKey.MONITOR_NEXT_ACTION),
            StatusNextActions.get(StatusNextActionsKey.COMPLETE_EVALUATED),
          ].includes(status),
        },
        {
          typeBtn: ButtonNextActionLegal.FEEDBACK_EVALUATED,
          disable: isStatusLegalDocumentDone || ![
            StatusNextActions.get(StatusNextActionsKey.FEEDBACK_LC),
            StatusNextActions.get(StatusNextActionsKey.FEEDBACK_EVALUATED),
            StatusNextActions.get(StatusNextActionsKey.MONITOR_NEXT_ACTION),
            StatusNextActions.get(StatusNextActionsKey.COMPLETE_EVALUATED),
          ].includes(status),
        },
        {
          typeBtn: ButtonNextActionLegal.COMPLETE_EVALUATED,
          disable: isStatusLegalDocumentDone || ![
            StatusNextActions.get(StatusNextActionsKey.FEEDBACK_LC),
            StatusNextActions.get(StatusNextActionsKey.MONITOR_NEXT_ACTION),
            StatusNextActions.get(StatusNextActionsKey.COMPLETE_EVALUATED),
          ].includes(status),
        },
      ],
    ],
  ]);
  const buttonActionNew = initialLawNextAction?.buttonActionNew as any
  let listActionAuthorizedMap: TypeActionRole[] = [];
  Object?.keys(buttonActionNew)?.forEach((actionNewKey: string) => {
    if (buttonActionNew?.[actionNewKey] !== statusButtonActionLaw.hidden) {
      listActionAuthorizedMap = listActionAuthorizedMap.concat({
        typeBtn: btnActionKeyV2NextAction[actionNewKey],
        disable:
          buttonActionNew?.[actionNewKey] === statusButtonActionLaw.disable,
      });
    }
  });
  if (
    !legalDocumentRoles?.length
  )
    return listActionAuthorizedMap;
    
  
  legalDocumentRoles.forEach((legalDocumentItemAction: any) => {
    const authorizedAction =
      listNextActions?.get(legalDocumentItemAction) || [];
    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });
  return uniqueCheck(listActionAuthorizedMap);
};

export const NextActionButtons = (props: TypePropsLegalDocumentNextAction) => {
  const {
    legalDocumentRoles,
    status,
    initialLawDocument,
    initialLawNextAction,
    // isDisableApproval = false,
    handleClickRequestApproval = () => {},
    handleClickApproval = () => {},
    handleClickAssessmentFeedback = () => {},
    handleClickFollowNextAction = () => {},
    handleClickResponseLc = () => {},
    handleClickFinishEvaluate = () => {},
    handleClickTimeExtendRequest = () => {},
  } = props;
  const [t] = useTranslation();
  const styleBtn = {
    background: COLOR_TYPE.TOYOTA.TOYOTA1,
    color: COLOR_TYPE.TOYOTA.TOYOTA8,
  };
  
  const [buttonMap] = useState(
    new Map<string, ActionButtonItem>([
      [
        ButtonNextActionLegal.FEEDBACK_LC,
        {
          key: ButtonNextActionLegal.FEEDBACK_LC,
          icon: <IconFeedback />,
          textBtn: t(`next_action.button.${ButtonNextActionLegal.FEEDBACK_LC}`),
          onClick: handleClickResponseLc,
          tooltipTitle: t(
            `next_action.button.${ButtonNextActionLegal.FEEDBACK_LC}`
          ),
          styleBtn,
          order: 2,
        },
      ],
      [
        ButtonNextActionLegal.APPROVAL,
        {
          key: ButtonNextActionLegal.APPROVAL,
          icon: <IconConfirm />,
          textBtn: t(`next_action.button.${ButtonNextActionLegal.APPROVAL}`),
          onClick: handleClickApproval,
          tooltipTitle: t(
            `next_action.button.${ButtonNextActionLegal.APPROVAL}`
          ),
          styleBtn,
          order: 3,
        },
      ],
      [
        ButtonNextActionLegal.REQUEST_APPROVAL,
        {
          key: ButtonNextActionLegal.REQUEST_APPROVAL,
          icon: <IconAssignment />,
          textBtn: t(
            `next_action.button.${ButtonNextActionLegal.REQUEST_APPROVAL}`
          ),
          onClick: handleClickRequestApproval,
          tooltipTitle: t(
            `next_action.button.${ButtonNextActionLegal.REQUEST_APPROVAL}`
          ),
          styleBtn,
          order: 1,
        },
      ],
      [
        ButtonNextActionLegal.FEEDBACK_EVALUATED,
        {
          key: ButtonNextActionLegal.FEEDBACK_EVALUATED,
          icon: <IconAssignment />,
          textBtn: t(
            `next_action.button.${ButtonNextActionLegal.FEEDBACK_EVALUATED}`
          ),
          onClick: handleClickAssessmentFeedback,
          tooltipTitle: t(
            `next_action.button.${ButtonNextActionLegal.FEEDBACK_EVALUATED}`
          ),
          styleBtn,
          order: 4,
        },
      ],
      [
        ButtonNextActionLegal.MONITOR_NEXT_ACTION,
        {
          key: ButtonNextActionLegal.MONITOR_NEXT_ACTION,
          icon: <IconDone />,
          textBtn: t(
            `next_action.button.${ButtonNextActionLegal.MONITOR_NEXT_ACTION}`
          ),
          onClick: handleClickFollowNextAction,
          tooltipTitle: t(
            `next_action.button.${ButtonNextActionLegal.MONITOR_NEXT_ACTION}`
          ),
          styleBtn,
          order: 5,
        },
      ],
      [
        ButtonNextActionLegal.COMPLETE_EVALUATED,
        {
          key: ButtonNextActionLegal.COMPLETE_EVALUATED,
          icon: <IconDone />,
          textBtn: t(
            `next_action.button.${ButtonNextActionLegal.COMPLETE_EVALUATED}`
          ),
          onClick: handleClickFinishEvaluate,
          tooltipTitle: t(
            `next_action.button.${ButtonNextActionLegal.COMPLETE_EVALUATED}`
          ),
          styleBtn,
          order: 6,
        },
      ],
      [
        ButtonNextActionLegal.TIME_EXTENSION_REQUEST,
        {
          key: ButtonNextActionLegal.TIME_EXTENSION_REQUEST,
          icon: <IconExtendDeadline />,
          iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(
            `LEGISLATION.button.extendDeadline`
          ),
          onClick: handleClickTimeExtendRequest,
          tooltipTitle: t(
            `LEGISLATION.button.extendDeadline`
          ),
          styleBtn,
          order: 7,
        },
      ],
    ])
  );

  return (
    <ActionButtonDetail
      params={{}}
      actionButtonItems={authorizedActionMapCallBack(
        legalDocumentRoles,
        status,
        initialLawDocument,
        initialLawNextAction,
        // isDisableApproval
      )?.map((buttons: TypeActionRole) => ({
        disable: buttons?.disable,
        ...buttonMap.get(buttons?.typeBtn)!,
      }))}
      listActions={legalDocumentRoles ?? ([] as any)}
    />
  );
};
