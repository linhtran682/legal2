import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import {
  Module,
  ModuleKeys,
  StatusEvaluatedTable,
  StatusEvaluatedTableKey,
  StatusNextActions,
  StatusNextActionsKey,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { useMutation } from "@tanstack/react-query";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import {
  AssessmentFeedbackFormOutput,
  AssessmentFeedbackFormSchema,
  AssessmentFeedbackFormSchemaFieldNames,
} from "@/models/law_document/NextActionLegalDocument";
import { requestAssessmentFeedback } from "@/apis/service/law_document/law_document";
import { FormSelectDefaultOption } from "@/components/commons/form_inputs/FormSelectDefaultOption";

const initialEmptyValue: AssessmentFeedbackFormOutput = {
  [AssessmentFeedbackFormSchemaFieldNames.CONTENT]: "",
  [AssessmentFeedbackFormSchemaFieldNames.USERS]: [],
  [AssessmentFeedbackFormSchemaFieldNames.REMIND]: undefined,
};

type TypeRequestSelectData = {
  nextActionId?: number;
  evaluateDepartmentId?: string;
  evaluateUserId?: string;
};

export interface AssessmentFeedbackTypeFormProps {
  titlePopup?: string;
  initialValue?: AssessmentFeedbackFormOutput;
  legalDocumentId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  requestSelectData?: TypeRequestSelectData;
  isAssessmentFeedbackNextAction?: boolean;
}

export const AssessmentFeedbackForm = (
  props: AssessmentFeedbackTypeFormProps
) => {
  const {
    titlePopup = "next_action.assessment_feedback_form.title",
    initialValue = initialEmptyValue,
    legalDocumentId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.LEGISLATION),
    requestSelectData = {},
    isAssessmentFeedbackNextAction = false,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const form = useForm<any>({
    resolver: yupResolver(AssessmentFeedbackFormSchema),
    defaultValues: {
      ...initialValue,
      [AssessmentFeedbackFormSchemaFieldNames.STATUS]:
        isAssessmentFeedbackNextAction
          ? StatusNextActions.get(StatusNextActionsKey.FEEDBACK_EVALUATED)
          : StatusEvaluatedTable.get(StatusEvaluatedTableKey.FEEDBACK_EVALUATE),
    },
  });

  const requestAssessmentFeedbackMuation = useMutation({
    mutationFn: requestAssessmentFeedback,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm(true);
    },
  });
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await requestAssessmentFeedbackMuation.mutate({
      legalDocumentId,
      request: { ...data, status: +data?.status, ...requestSelectData },
    });
  };

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t(
                    "next_action.assessment_feedback_form.field_name.documentName"
                  )}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <FormSelectDefaultOption
                  control={form.control}
                  name={AssessmentFeedbackFormSchemaFieldNames.STATUS}
                  options={[
                    {
                      label: t(
                        `next_action.option.${StatusNextActionsKey.FEEDBACK_EVALUATED}`
                      ),
                      value: isAssessmentFeedbackNextAction
                        ? StatusNextActions.get(
                            StatusNextActionsKey.FEEDBACK_EVALUATED
                          )
                        : StatusEvaluatedTable.get(
                            StatusEvaluatedTableKey.FEEDBACK_EVALUATE
                          ),
                    },
                  ]}
                  label={t(
                    `next_action.assessment_feedback_form.field_name.status`
                  )}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  isClearIcon
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AssessmentFeedbackFormSchemaFieldNames.CONTENT}
                  label={t(
                    `next_action.assessment_feedback_form.field_name.content`
                  )}
                  placeHolder={t(
                    `next_action.assessment_feedback_form.field_name.content`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AssessmentFeedbackFormSchemaFieldNames.USERS}
                    label={t(
                      "next_action.assessment_feedback_form.field_name.receiver"
                    )}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"followNextAction/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={AssessmentFeedbackFormSchemaFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={requestAssessmentFeedbackMuation.isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    users:
                      form.getValues().users?.map((ele: BasedUser) => ele.id) ||
                      [],
                    remind: form.getValues()?.remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
