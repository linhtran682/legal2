import { getDepartments } from "@/apis/service/department/department";
import {
  approveLegalDocumentNextAction,
  getLegalDocumentNextAction,
} from "@/apis/service/law_document/law_document";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { GLOBAL_SPACING } from "@/constants/format";
import { ModuleFields } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { Department } from "@/models/department/Department";
import {
  ApproveNextActionFormSchema,
  ApproveNextActionFormSchemaFieldNames,
  ApproveNextActionFormSchemaI,
  castApproveNextActionFormSchemaToOutput,
  castNextActionInputToApproveNextActionFormSchema,
} from "@/models/law_document/NextActionLegalDocument";
import { StatusFieldNames } from "@/models/status/Status";
import { BasedUser } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext, useEffect } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { NextActionTable } from "./NextActionTable";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { EmptyIndicator } from "@/components/commons/empty_idicator/EmptyIndicator";
import { FormSelectButton } from "@/components/commons/form_inputs/FormSelectButton";

export interface ApproveNextActionFormProps {
  documentId: number;
  requestApprovalId: number;
  nextActionCreatorId: string;
}

const defaultEmptyValue: ApproveNextActionFormSchemaI = {
  departments: [],
  users: [],
  approvalStatus: false,
  nextActionItems: [],
  status: -1,
};

export const ApproveNextActionForm = (props: ApproveNextActionFormProps) => {
  const [t] = useTranslation();
  const router = useRouter();
  const appContext = useContext(AppContext);

  // const form = useForm<ApproveNextActionFormSchemaI>({
  const form = useForm<any>({

    resolver: yupResolver(ApproveNextActionFormSchema),
    defaultValues: JSON.parse(JSON.stringify(defaultEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const getNextActionQuery = useQuery({
    queryKey: ["get_initial_next_action"],
    queryFn: () =>
      getLegalDocumentNextAction({
        documentId: props.documentId,
        userId: props.nextActionCreatorId ?? "",
      }).then((nextAction) => {
        if (nextAction) {
          form.reset(
            castNextActionInputToApproveNextActionFormSchema(nextAction)
          );
          return nextAction;
        }
      }),
    enabled: false,
  });

  useEffect(() => {
    getNextActionQuery.refetch();
  }, []);

  const approveQuery = useMutation({
    mutationFn: approveLegalDocumentNextAction,
    onSuccess: () => {
      toast.success(t("next_action.message.approve_success"));
      router.back();
    },
  });

  return (
    <>
      {getNextActionQuery.error || !getNextActionQuery.data ? (
        <EmptyIndicator />
      ) : (
        <FormProvider {...form}>
          <Grid container className='form-wrapper' spacing={GLOBAL_SPACING}>
            <Grid item>
              <Grid
                container
                direction={"column"}
                rowGap={GLOBAL_SPACING}
                alignItems={"center"}
                className='form-section-wrapper'
                sx={formInputSxProps}
              >
                <Grid item width={"100%"}>
                  <FormControl size='small' fullWidth>
                    <label style={{padding:0}}>
                      {t(`next_action.field_name.documentName`)}
                    </label>
                    <Typography>
                      {getNextActionQuery.data?.legalDocumentName}
                    </Typography>
                  </FormControl>
                </Grid>

                <Grid item width={"100%"}>
                  <RadioGroupField
                    isBoolean
                    items={[
                      {
                        label: t("next_action.approve_form.option.turn_down"),
                        value: false,
                      },
                      {
                        label: t("next_action.approve_form.option.approve"),
                        value: true,
                      },
                    ]}
                    name={ApproveNextActionFormSchemaFieldNames.APPROVE_STATUS}
                    error={
                      form.formState.errors[
                      ApproveNextActionFormSchemaFieldNames.APPROVE_STATUS
                      ] as FieldError
                    }
                  />
                </Grid>

                <Grid item width={"100%"}>
                  <FormSelectButton
                    control={form.control}
                    name={ApproveNextActionFormSchemaFieldNames.STATUS}
                    label={t(
                      `next_action.approve_form.field_name.${ApproveNextActionFormSchemaFieldNames.STATUS}`
                    )}
                    keyQuery={"status-query"}
                    getOptions={async (keyword) => {
                      if (typeof keyword == "string") {
                        const response = await getStatusList({
                          name: keyword,
                          modules: [ModuleFields.LEGISLATION_NAME.module],
                          page: 0,
                          size: 100,
                          sortBy: StatusFieldNames.NAME,
                          orderBy: "ASC",
                          active: 1
                        });

                        return response?.statusResponses || [];
                      } else {
                        if (
                          keyword?.length &&
                          keyword.length > 0 &&
                          Number(keyword[0]) !== -1
                        ) {
                          return getStatus(Number(keyword[0])).then((value) =>
                            value ? [value] : []
                          );
                        }
                      }

                      return [];
                    }}
                    getOptionKey={(option) => option.id.toString()}
                    getOptionLabel={(option) => option.name}
                    required
                  />
                </Grid>

                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={ApproveNextActionFormSchemaFieldNames.REASON}
                    label={t(
                      `next_action.approve_form.field_name.${ApproveNextActionFormSchemaFieldNames.REASON}`
                    )}
                    placeHolder={t(
                      `next_action.approve_form.field_name.${ApproveNextActionFormSchemaFieldNames.REASON}`
                    )}
                    minRows={5}
                    required
                  />
                </Grid>

                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                  sx={formInputSxProps}
                >
                  <Grid item xs={6}>
                    <FormSelectTreeView
                      name={ApproveNextActionFormSchemaFieldNames.DEPARTMENTS}
                      control={form.control}
                      label={t(
                        `next_action.approve_form.field_name.${ApproveNextActionFormSchemaFieldNames.DEPARTMENTS}`
                      )}
                      placeholder={t(
                        `next_action.approve_form.field_name.${ApproveNextActionFormSchemaFieldNames.DEPARTMENTS}`
                      )}
                      getOptions={async (keyword) => {
                        try {
                          const response = await getDepartments({
                            searchTerm: keyword,
                          });
                          const first100Departments: Department[] = (
                            response?.departments ?? []
                          ).slice(0, 150);
                          return first100Departments;
                        } catch (e) {
                          return [];
                        }
                      }}
                      getOptionLabel={(option) => option.name ?? ""}
                      getOptionKey={(option) => option.id ?? ""}
                      getOptionChildren={(option) => option.children}
                      variant='outlined'
                      debounceMs={FILTER_DEBOUNCE_MS}
                      onChange={(value: Department[]) => {
                        form.setValue("departments", value);
                        const departmentNames = value.map((item) => item.name);
                        if (
                          form.getValues("users") &&
                          form.getValues("users")?.length > 0
                        ) {
                          const filteredUsers = form
                            .getValues()
                            .users.filter((user:any) =>
                              departmentNames?.includes(user.departmentName)
                            );
                          form.setValue("users", filteredUsers);
                        }
                      }}
                      rules={{ required: "This field is required" }}
                      required
                      disabled={!appContext.meCanWrite}
                    />
                  </Grid>
                  <Grid item xs={6} sx={{marginTop:"24px"}}>
                    <FormMultipleSelect<any, BasedUser>
                      control={form.control}
                      name={`${ApproveNextActionFormSchemaFieldNames.USERS}`}
                      label={t(
                        `next_action.approve_form.field_name.${ApproveNextActionFormSchemaFieldNames.USERS}`
                      )}
                      placeholder={t(
                        `next_action.approve_form.field_name.${ApproveNextActionFormSchemaFieldNames.USERS}`
                      )}
                      getOptions={async (keyword) => {
                        const response = await getUsers({
                          searchTerm: keyword,
                          page: 0,
                          size: 100,
                          sortBy: "name",
                          sortOrder: "ASC",
                          departmentIds: form
                            .getValues(
                              ApproveNextActionFormSchemaFieldNames.DEPARTMENTS
                            )
                            .map((el:any) => el.id),
                        });

                        return (response?.users ?? []).map((user) => ({
                          id: user.id,
                          name: user.name ?? "",
                          departmentName: user.department?.name,
                          email: user.email,
                        }));
                      }}
                      getOptionLabel={(option) =>
                        `${option.name ?? ""} (${option.email ?? ""}) - ${option.departmentName ?? ""
                        }`
                      }
                      getOptionKey={(option) => option.id}
                      keyQuery='queryUser'
                      required
                    />
                  </Grid>
                </Grid>
              </Grid>
            </Grid>

            <Grid item>
              <NextActionTable
                control={form.control}
                name={ApproveNextActionFormSchemaFieldNames.NEXT_ACTION_ITEM_ID}
                isDeptHead={true}
                status={1}
              />
            </Grid>

            <Grid item>
              <ReminderPickerSubForm
                name={ApproveNextActionFormSchemaFieldNames.REMIND}
              />
            </Grid>

            <FormActionButtons
              formMode={"create"}
              textSave='common.button.send'
              loading={approveQuery.isPending}
              onCancel={() => router.back()}
              cancelConfirm={form.formState.isDirty}
              onSave={() => {
                props.documentId &&
                  approveQuery.mutate({
                    documentId: props.documentId,
                    requestApprovalId: props.requestApprovalId,
                    request: castApproveNextActionFormSchemaToOutput(
                      form.getValues()
                    ),
                  });
              }}
            />
          </Grid>
        </FormProvider>
      )}
    </>
  );
};
