import { FormCheckbox } from "@/components/commons/form_inputs/FormCheckbox";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { formInputSxProps } from "@/constants/theme";
import {
  Box,
  Checkbox,
  FormHelperText,
  Grid,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import { Control, useFieldArray } from "react-hook-form";
import { useTranslation } from "react-i18next";
import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  NextActionItemSchemaI,
  NextActionSchemaFieldNames,
} from "@/models/law_document/NextActionLegalDocument";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { formatSingleDigitNumber } from "@/utils";
import { useState } from "react";
import { getUsers } from "@/apis/service/user/User";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { LANGUAGES } from "@/locales/config-translation";
import { COLOR_TYPE } from "@/constants/color";
import HighlightOffOutlinedIcon from "@mui/icons-material/HighlightOffOutlined";
import CheckCircleOutlineOutlinedIcon from "@mui/icons-material/CheckCircleOutlineOutlined";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
export interface NextActionTableProps {
  name: string;
  control: Control<any, any>;
  isDeptHead?: boolean;
  dataNextAction?: any;
  status: number;
  err?: any;
}

interface NextActionTableColumn {
  key?: keyof NextActionItemSchemaI;
  label: string;
  type: "string" | "number" | "date" | "bool" | "action" | "select";
  width?: string;
}
const statusList = [3, 8, 10, 6];
export const NextActionTable = (props: NextActionTableProps) => {
  const [t, i18n] = useTranslation();
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const isallowAction = statusList.includes(props.status);
  const handleCheckboxChange = (index: number) => {
    setSelectedRows((prevSelectedRows) => {
      if (prevSelectedRows.includes(index)) {
        return prevSelectedRows.filter((i) => i !== index);
      } else {
        return [...prevSelectedRows, index];
      }
    });
  };

  const isCheckboxDisabled = (indexs: number) => {
    if (nextActionItemController.fields.length > 0) {
      const checkBoxDisable = nextActionItemController.fields.find(
        (item, index) => index === indexs
      ) as any;
      if (
        checkBoxDisable?.deptHeadApprove == "0" ||
        checkBoxDisable?.deptHeadApprove == "1"
      ) {
        return true;
      }
    }
    return false;
  };

  const handleDeleteSelectedRows = () => {
    const sortedSelectedRows = [...selectedRows].sort((a, b) => b - a);
    sortedSelectedRows.forEach((rowIndex) => {
      nextActionItemController.remove(rowIndex);
    });
    setSelectedRows([]);
  };
  const [columns] = useState<NextActionTableColumn[]>([
    {
      label: "",
      type: "select",
      width: "50px",
    },
    {
      key: "nextActionItemId",
      label: "nextActionId",
      type: "number",
      width: "50px",
    },
    {
      key: "category",
      label: "category",
      type: "string",
      width: "180px",
    },
    {
      key: "legalRequirements",
      label: "legalRequirements",
      type: "string",
      width: "180px",
    },
    {
      key: "complianceAssessment",
      label: "complianceAssessment",
      type: "string",
      width: "180px",
    },
    {
      key: "currentStatusTMV",
      label: "currentStatusTMV",
      type: "string",
      width: "180px",
    },
    {
      key: "workNeed",
      label: "workNeed",
      type: "string",
      width: "180px",
    },
    {
      key: "pics",
      label: "pic",
      type: "string",
      width: "250px",
    },
    {
      key: "deadline",
      label: "deadline",
      type: "date",
      width: "150px",
      // width: "10%",
    },
    // {
    //   key: "deptHeadApprove",
    //   label: t("next_action.column.deptHeadApprove"),
    //   type: "bool",
    //   width: "1%",
    // },
    {
      label: "deptHeadApprove",
      type: "action",
      // width: "1%",
      width: "90px",
    },
  ]);

  const nextActionItemController = useFieldArray({
    keyName: "itemId",
    control: props.control,
    name: NextActionSchemaFieldNames.NEXT_ACTION_ITEMS,
  });

  const handleSelectAllRows = async (event: any) => {
    const isChecked = event.target.checked;
    if (isChecked) {
      const allIndexes = nextActionItemController.fields.map(
        (_, index) => index
      );
      await setSelectedRows(allIndexes);
    } else {
      await setSelectedRows([]);
    }
  };
  const renderTableInputCell = (
    column: NextActionTableColumn,
    index: number
  ) => {
    const placeholder = t(`next_action.column.${column.label}`);

    if (column.key == "nextActionItemId") {
      return formatSingleDigitNumber(index + 1);
    }

    if (column.key == "pics") {
      return (
        <FormMultipleSelect<any, BasedUser>
          label=""
          control={props.control}
          name={`${NextActionSchemaFieldNames.NEXT_ACTION_ITEMS}.${index}.pics`}
          keyQuery={`${NextActionSchemaFieldNames.NEXT_ACTION_ITEMS}.${index}.pics`}
          placeholder={column.label}
          getOptions={async (keyword) => {
            // if (typeof keyword == "string") {
            //   const response = await getUsers({
            //     searchTerm: keyword,
            //     page: 0,
            //     size: 100,
            //     sortBy: "name",
            //     sortOrder: "ASC",
            //   });

            //   return (response?.users ?? []).map(
            //     (user) =>
            //       ({
            //         id: user.id,
            //         name: user.name ?? "",
            //         departmentName: user.department?.name,
            //         email: user.email,
            //       } as BasedUser)
            //   );
            // } else if (keyword?.length && keyword.length > 0) {
            //   return getUser(keyword[0])
            //     .then((response) =>
            //       response
            //         ? [
            //             {
            //               id: response.id,
            //               name: response.name ?? "",
            //               nameEnglish: response.nameEnglish,
            //               departmentName: response.department?.name,
            //               email: response.email,
            //             } as BasedUser,
            //           ]
            //         : []
            //     )
            //     .catch(() => []);
            // }
              const params: GetUsersParams = {
                searchTerm: keyword,
                page: 0,
                size: 100,
                sortBy: "name",
                sortOrder: "ASC",
              };
              const response = await getUsers(params);

              return (response?.users ?? []).map((user) => ({
                    id: user.id,
                    name: user.name ?? "",
                    departmentName: user.department?.name,
                    email: user.email,
              }));
            return [];
          }}
          getOptionKey={(option) => option.id}
          getOptionLabel={(option) =>
            `${
              i18n.language == LANGUAGES.VIETNAMESE
                ? option.name ?? ""
                : option.nameEnglish ?? ""
            } (${option.email ?? ""}) - ${option.departmentName ?? ""}`
          }
          disabled={props.isDeptHead}
        />
      );
    }

    if (!column.key) {
      if (column.type == "action") {
        return (
          <Box display={"flex"}>
            <IconButton
              onClick={() => {
                if (props.isDeptHead) {
                  nextActionItemController.update(index, {
                    ...nextActionItemController.fields[index],
                    deptHeadApprove: "1",
                  });
                }
              }}
            >
              <CheckCircleOutlineOutlinedIcon
                sx={{
                  color:
                    (nextActionItemController.fields[index] as any)
                      ?.deptHeadApprove &&
                    (nextActionItemController.fields[index] as any)
                      ?.deptHeadApprove === "1"
                      ? COLOR_TYPE.SUCCESS.GREEN7
                      : COLOR_TYPE.TOYOTA.TOYOTA5,
                }}
              />
            </IconButton>
            <IconButton
              onClick={() => {
                if (props.isDeptHead) {
                  nextActionItemController.update(index, {
                    ...nextActionItemController.fields[index],
                    deptHeadApprove: "0",
                  });
                }
              }}
            >
              <HighlightOffOutlinedIcon
                sx={{
                  color:
                    (nextActionItemController.fields[index] as any)
                      ?.deptHeadApprove === "0"
                      ? COLOR_TYPE.TOYOTA.TOYOTA1
                      : COLOR_TYPE.TOYOTA.TOYOTA5,
                }}
              />
            </IconButton>
          </Box>
        );
      }
      if (column.type == "select" && !isallowAction) {
        return (
          <Checkbox
            checked={selectedRows.includes(index)}
            onChange={() => handleCheckboxChange(index)}
            disabled={isCheckboxDisabled(index)}
          />
        );
      }
      return null;
    }

    if (column.type == "string") {
      return (
        <FormTextField
          control={props.control}
          name={`${NextActionSchemaFieldNames.NEXT_ACTION_ITEMS}.${index}.${column.key}`}
          placeHolder={placeholder}
          disabled={props.isDeptHead}
        />
      );
    }

    if (column.type == "number") {
      return (
        <FormTextField
          type="number"
          control={props.control}
          name={`${NextActionSchemaFieldNames.NEXT_ACTION_ITEMS}.${index}.${column.key}`}
          placeHolder={placeholder}
          emptyIsZero
          disabled={props.isDeptHead}
        />
      );
    }

    if (column.type == "date") {
      return (
        <div style={{ marginTop: -20 }}>
          <DateInput
            control={props.control}
            placeholder={placeholder}
            name={`${NextActionSchemaFieldNames.NEXT_ACTION_ITEMS}.${index}.${column.key}`}
            disabled={props.isDeptHead}
          />
        </div>
      );
    }

    if (column.type == "bool") {
      return (
        <FormCheckbox
          control={props.control}
          name={`${NextActionSchemaFieldNames.NEXT_ACTION_ITEMS}.${index}.${column.key}`}
          noInline
          disabled={!props.isDeptHead}
        />
      );
    }
  };

  return (
    <Grid
      container
      direction={"column"}
      alignItems={"center"}
      className="form-section-wrapper"
      sx={{ ...formInputSxProps, height: "100%" }}
    >
      {selectedRows.length > 0 && !isallowAction && (
        <Box
          width={"100%"}
          alignContent={"flex-start"}
          marginBottom={1}
          display={"flex"}
          gap={2}
        >
          {/* <Button variant="contained" onClick={handleDeleteSelectedRows}>
            {t("common.button.delete")}
          </Button> */}
          <IconButton
            onClick={handleDeleteSelectedRows}
            style={{ marginLeft: 20 }}
          >
            <DeleteIcon
              sx={{
                color: COLOR_TYPE.TOYOTA.TOYOTA1,
              }}
            />
          </IconButton>

          {props.isDeptHead && (
            <>
              <IconButton
                onClick={async () => {
                  const updatedFields = nextActionItemController.fields.map(
                    (field, index) => {
                      return nextActionItemController.update(index, {
                        ...field,
                        deptHeadApprove: "1",
                      });
                    }
                  );
                  await Promise.all(updatedFields);
                }}
              >
                <CheckCircleOutlineOutlinedIcon
                  sx={{
                    color:
                      nextActionItemController.fields.length > 0 &&
                      nextActionItemController.fields.every(
                        (item) => (item as any)?.deptHeadApprove === "1"
                      )
                        ? COLOR_TYPE.SUCCESS.GREEN7
                        : COLOR_TYPE.TOYOTA.TOYOTA5,
                  }}
                />
              </IconButton>
              <IconButton
                onClick={async () => {
                  const updatedFields = nextActionItemController.fields.map(
                    (field, index) => {
                      return nextActionItemController.update(index, {
                        ...field,
                        deptHeadApprove: "0",
                      });
                    }
                  );
                  await Promise.all(updatedFields);
                }}
              >
                <HighlightOffOutlinedIcon
                  sx={{
                    color:
                      nextActionItemController.fields.length > 0 &&
                      nextActionItemController.fields.every(
                        (item) => (item as any)?.deptHeadApprove === "0"
                      )
                        ? COLOR_TYPE.TOYOTA.TOYOTA1
                        : COLOR_TYPE.TOYOTA.TOYOTA5,
                  }}
                />
              </IconButton>
            </>
          )}
          <Typography
            variant="subtitle2"
            style={{ display: "flex", alignItems: "center" }}
          >
            <span
              style={{ color: "black", fontWeight: "bold", paddingRight: 5 }}
            >
              {selectedRows.length}
            </span>
            {t(`next_action.title.record_number`)}
          </Typography>
        </Box>
      )}
      <TableContainer
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          overflowX: "auto",
          "& .MuiTableCell-root.MuiTableCell-head": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
            fontFamily:
              "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
            "&:focus-within": {
              outline: "none",
            },
            fontWeight: 700,
            border: "1px solid #ccc",
          },
        }}
      >
        <Table
          stickyHeader
          aria-label="sticky table"
          sx={{
            tableLayout: "auto",
            width: "100%",
            minWidth: "2000px",
          }}
        >
          <TableHead>
            <TableRow>
              {columns
                .filter(
                  (column) =>
                    !props.isDeptHead ||
                    props.isDeptHead ||
                    column.type != "action"
                )
                .map((column) => (
                  <>
                    {column.type === "select" ? (
                      <TableCell
                        key={column.label}
                        padding="checkbox"
                        sx={{
                          width: column.width || "auto",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          textAlign: "center",
                          border: "1px solid #e0e0e0", // Add borders for all cells
                          padding: "8px",
                        }}
                      >
                        <Checkbox
                          checked={
                            selectedRows.length ===
                            nextActionItemController.fields.length
                          }
                          indeterminate={
                            selectedRows.length > 0 &&
                            selectedRows.length <
                              nextActionItemController.fields.length
                          }
                          sx={{
                            paddingLeft: "0px !important",
                            minWidth: column.width,
                          }}
                          onChange={handleSelectAllRows}
                        />
                      </TableCell>
                    ) : (
                      <TableCell
                        key={column.label}
                        sx={{
                          width: column.width || "auto",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          padding: "4px",
                          textAlign: "center",
                          border: "1px solid #e0e0e0", // Add borders for all cells
                          minWidth: column.width,
                        }}
                      >
                        {t(`next_action.column.${column.label}`)}
                      </TableCell>
                    )}
                  </>
                ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {nextActionItemController.fields.map((item, index) => (
              <TableRow key={item.itemId}>
                {columns
                  .filter(
                    (column) =>
                      !props.isDeptHead ||
                      props.isDeptHead ||
                      column.type != "action"
                  )
                  .map((column, columnIndex) => (
                    <>
                      <TableCell
                        key={`${item.itemId}_${columnIndex}`}
                        align={
                          ["date", "number"].includes(column.type ?? "")
                            ? "center"
                            : "center"
                        }
                        sx={{
                          //  width: column.width || "150px",
                          padding: "8px", // Add padding to match the image
                          border: "1px solid #e0e0e0", // Add borders for all cells
                          minWidth: column.width || "100px", // Đặt minWidth cho cột
                        }}
                      >
                        {renderTableInputCell(column, index)}
                      </TableCell>
                    </>
                  ))}
              </TableRow>
            ))}
            {!props.isDeptHead && !isallowAction && (
              <TableRow>
                <TableCell colSpan={columns.length}>
                  <IconButton
                    sx={{
                      backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
                      color: "white",
                      borderRadius: "50%",
                      "&:hover": {
                        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
                      },
                      "&:focus, &:focus-visible": {
                        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
                      },
                    }}
                    onClick={() => {
                      nextActionItemController.append({
                        nextActionId: -1,
                        deptHeadApprove: "",
                      });
                    }}
                  >
                    <AddIcon
                      sx={{
                        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
                        color: "white",
                        borderRadius: "50%",
                      }}
                    />
                  </IconButton>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <div style={{ width: "100%" }}>
        {props.err?.nextActionItems?.message && (
          <FormHelperText sx={{ color: "#d32f2f", marginLeft: 2 }}>
            {t("next_action.message.next_action_table")}
          </FormHelperText>
        )}
      </div>
    </Grid>
  );
};
