import {
  createLegalDocumentNextAction,
  getLawDocument,
  getLegalDocumentNextActionBaseId,
  getRoleLegalDocumentNextActionBaseId,
  updateLegalDocumentNextAction,
} from "@/apis/service/law_document/law_document";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import {
  convertNextActionInputToSchema,
  convertNextActionSchemaToOutput,
  NextActionSchema,
  NextActionSchemaFieldNames,
  // NextActionSchemaI,
} from "@/models/law_document/NextActionLegalDocument";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button, FormControl, Grid, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext, useEffect, useMemo, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { ResponseToLCForm } from "../response_to_lc_form/ResponseToLCForm";
import { RequestNextActionApprovalForm } from "./RequestNextActionApprovalForm";
import { NextActionTable } from "./NextActionTable";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { processFileAttachments } from "../form-legal-document/LegalDocumentForm";
import { LEGAL_DOCUMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { LegalDocumentStatusContent, LegalDocumentUserStatusKey, Module, ModuleKeys, StatusNextActions, StatusNextActionsKey } from "@/constants/general";
import { ApprovalNextActionForm } from "../request_approval_form/ApprovalNextActionForm";
import { ButtonNextActionLegal, NextActionButtons } from "./NextActionButtons";
import { AssessmentFeedbackForm } from "./AssessmentFeedbackForm";
import { FollowNextActionForm } from "./FollowNextActionForm";
import { FinishEvaluateForm } from "./FinishEvaluateForm";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { TimeExtensionNextActionForm } from "./TimeExtensionNextActionForm";
// import { FormSelectDefaultOption } from "@/components/commons/form_inputs/FormSelectDefaultOption";
export interface NextActionFormProps {
  documentId: number;
  documentName?: string;
  userId?: string;
  nextActionId: number;
  module: number;
  formMode: string;
}

const defaultEmptyValue: any = {
  deadline: "",
  nextActionItems: [],
  status: 4,
  name: "",
};

export const NextActionForm = (props: NextActionFormProps) => {
  const [t] = useTranslation();
  const router = useRouter();
  const documentId = router.query.documentId;
  const appContext = useContext(AppContext);
  const [isNew, setIsNew] = useState(true);
  const [legalDocumentOwnerRoles, setLegalDocumentOwnerRoles] = useState<
    number[]
  >([]);
  const [files, setFiles] = useState<any>([]);
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});
  const form = useForm<any>({
    resolver: yupResolver(NextActionSchema),
    defaultValues: JSON.parse(JSON.stringify(defaultEmptyValue)),
    mode: "onBlur",
    // disabled:
    //   !appContext.meCanWrite ||
    //   !legalDocumentOwnerRoles.includes(2) ||
    //   !legalDocumentOwnerRoles.includes(4),
  });
  
  const getLawDocumentQuery = useQuery({
    queryKey: ["get_initial_law_next_action"],
    queryFn: () =>
      getLawDocument(
        typeof documentId == "string"
          ? Number(documentId)
          : Number((documentId || [])[0])
      ),
    enabled: !!documentId && props?.formMode === "update",
  });
  const getNextActionQuery = useQuery({
    queryKey: ["get_initial_next_action"],
    queryFn: () =>
      getLegalDocumentNextActionBaseId({
        documentId: props.documentId,
        id: props.nextActionId,
      })
        .then((nextAction) => {
          if (nextAction) {
            setIsNew(false);
            form.reset(convertNextActionInputToSchema(nextAction));
            setFiles(
              nextAction.files?.map((item) => {
                return {
                  name: item?.fileName,
                  path: item?.filePath,
                  id: item?.fileId,
                  uploadDate: item?.uploadDate,
                };
              })
            );
            return nextAction;
          }
          return null;
        })
        .catch(() => null),
    enabled: !!props.nextActionId,
  });
  const getRoleNextActionQuery = useQuery({
    queryKey: ["get_role_next_action"],
    queryFn: () =>
      getRoleLegalDocumentNextActionBaseId({
        documentId: props.documentId,
      })
        .then((listId) => {
          if (listId) {
            setLegalDocumentOwnerRoles(listId.legalDocumentOwnerRoles);
            props.nextActionId && getNextActionQuery.refetch();

            return listId;
          }
          return null;
        })
        .catch(() => null),
    enabled: false,
  });

  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (reload) {
      props.documentId && getRoleNextActionQuery.refetch();
    }
  };

  const handleClick = (type: any) => {
    if (type) {
      changePopupVisible(type, true);
    }
  };
      
  useEffect(() => {
    props.documentId && getRoleNextActionQuery.refetch();
    // props.nextActionId && getNextActionQuery.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.nextActionId, props.documentId]);

  const saveNextActionQuery = useMutation({
    mutationFn: isNew
      ? createLegalDocumentNextAction
      : updateLegalDocumentNextAction,
    onSuccess: () => {
      toast.success(
        t(
          isNew
            ? "common.message.create_success"
            : "common.message.update_success",
          {
            recordName: "next action",
          }
        )
      );
      router.push(
        `/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${props.documentId}`
      );
    },
  });
   
  const statusActionsApproval = useMemo(() => {
    const activeDeptHeadApprove = !!form
      .watch(NextActionSchemaFieldNames.NEXT_ACTION_ITEMS)
      ?.find((actionItem: { deptHeadApprove: string; }) => actionItem?.deptHeadApprove === "1");
    const inActiveDeptHeadApprove = !!form
      .watch(NextActionSchemaFieldNames.NEXT_ACTION_ITEMS)
      ?.find((actionItem: { deptHeadApprove: string; }) => actionItem?.deptHeadApprove === "0");
    const notActiveDeptHeadApprove = !!form
      .watch(NextActionSchemaFieldNames.NEXT_ACTION_ITEMS)
      ?.find((actionItem: { deptHeadApprove: any; }) => !actionItem?.deptHeadApprove);
    return {
      activeDeptHeadApprove,
      inActiveDeptHeadApprove,
      notActiveDeptHeadApprove,
    };
  }, [form.watch(NextActionSchemaFieldNames.NEXT_ACTION_ITEMS)]);
  return (
    <>
      {!isNew &&
        appContext.meCanWrite &&
        getLawDocumentQuery?.data?.status?.name !==
          LegalDocumentStatusContent.get(LegalDocumentUserStatusKey.DONE)! && (
          <NextActionButtons
            legalDocumentRoles={legalDocumentOwnerRoles}
            status={getNextActionQuery?.data?.status}
            initialLawDocument={getLawDocumentQuery?.data}
            initialLawNextAction={getNextActionQuery?.data}
            isDisableApproval={statusActionsApproval?.notActiveDeptHeadApprove}
            handleClickRequestApproval={() =>
              handleClick(ButtonNextActionLegal.REQUEST_APPROVAL)
            }
            handleClickApproval={() =>
              handleClick(ButtonNextActionLegal.APPROVAL)
            }
            handleClickAssessmentFeedback={() =>
              handleClick(ButtonNextActionLegal.FEEDBACK_EVALUATED)
            }
            handleClickFollowNextAction={() =>
              handleClick(ButtonNextActionLegal.MONITOR_NEXT_ACTION)
            }
            handleClickResponseLc={() =>
              handleClick(ButtonNextActionLegal.FEEDBACK_LC)
            }
            handleClickFinishEvaluate={() =>
              handleClick(ButtonNextActionLegal.COMPLETE_EVALUATED)
            }
            handleClickTimeExtendRequest={() =>
              handleClick(ButtonNextActionLegal.TIME_EXTENSION_REQUEST)
            }
          />
        )}
      <FormProvider {...form}>
        <Grid
          container
          className="form-wrapper"
          spacing={GLOBAL_SPACING}
          sx={{ minWidth: "100%" }}
        >
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <label>{t(`next_action.field_name.documentName`)}</label>
                  <Typography>
                    {getNextActionQuery.data?.legalDocumentName ??
                      props.documentName}
                  </Typography>
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <label>{t(`next_action.field_name.user`)}</label>
                  {getNextActionQuery.data?.createBy ? (
                    <Typography>
                      {`${getNextActionQuery.data?.createBy?.name} (${getNextActionQuery.data?.createBy?.email}) - ${getNextActionQuery.data?.createBy?.departmentName}`}
                    </Typography>
                  ) : (
                    <Typography>
                      {`${appContext.me?.name} (${appContext.me?.email}) - ${appContext.me?.department?.name}`}
                    </Typography>
                  )}
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={props.formMode === "create"}
                  preview={props.formMode === "update"}
                  title={t(`next_action.field_name.report`)}
                  disabled={
                    legalDocumentOwnerRoles.includes(2) &&
                    props.formMode === "update"
                      ? false
                      : legalDocumentOwnerRoles.includes(4)
                      ? false
                      : legalDocumentOwnerRoles.includes(5)
                      ? false
                      : true
                  }
                  files={files}
                  setFiles={setFiles}
                  control={form.control}
                  name={NextActionSchemaFieldNames.FILE}
                  required
                />
              </Grid>
              {props.formMode === "update" &&
              appContext?.me?.id === getNextActionQuery?.data?.createBy?.id ? (
                <Grid item width={"100%"}>
                  <FormTextField
                    control={form.control}
                    name={NextActionSchemaFieldNames.NAME}
                    label={t(
                      `next_action.field_name.${NextActionSchemaFieldNames.NAME}`
                    )}
                    placeHolder={t(
                      `next_action.field_name.${NextActionSchemaFieldNames.NAME}`
                    )}
                    required
                    disabled={
                      // !appContext.meCanWrite ||
                      legalDocumentOwnerRoles.includes(2) &&
                      props.formMode === "update"
                        ? false
                        : legalDocumentOwnerRoles.includes(4)
                        ? false
                        : true
                    }
                  />
                </Grid>
              ) : (
                <></>
              )}
              {props.formMode !== "update" && (
                <Grid item width={"100%"}>
                  <FormTextField
                    control={form.control}
                    name={NextActionSchemaFieldNames.NAME}
                    label={t(
                      `next_action.field_name.${NextActionSchemaFieldNames.NAME}`
                    )}
                    placeHolder={t(
                      `next_action.field_name.${NextActionSchemaFieldNames.NAME}`
                    )}
                    required
                    disabled={
                      // !appContext.meCanWrite ||
                      legalDocumentOwnerRoles.includes(2) &&
                      props.formMode === "update"
                        ? false
                        : legalDocumentOwnerRoles.includes(4)
                        ? false
                        : true
                    }
                  />
                </Grid>
              )}

              <Grid item width={"100%"}>
                <DateInput
                  control={form.control}
                  name={NextActionSchemaFieldNames.DEADLINE}
                  label={t("next_action.field_name.deadline")}
                  placeholder={t("next_action.field_name.deadline")}
                  disabled={
                    // !appContext.meCanWrite ||
                    legalDocumentOwnerRoles.includes(2) &&
                    props.formMode === "update"
                      ? false
                      : legalDocumentOwnerRoles.includes(4)
                      ? false
                      : true
                  }
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                {/* <FormSelectDefaultOption
                  control={form.control}
                  name={NextActionSchemaFieldNames.STATUS}
                  label={t("next_action.field_name.status")}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  options={Array.from(StatusNextActions.keys()).map((key) => ({
                    label: t(`next_action.option.${key}`),
                    value: StatusNextActions.get(key)!,
                  }))}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  required
                  disabled={true}
                /> */}
                <label
                  className={t("next_action.field_name.status") ?? "no-label"}
                >
                  {t("next_action.field_name.status")}
                  <span style={{ color: "red" }}>*</span>
                </label>
                <Button
                  sx={{
                    background:
                      form.getValues().status === 9 ? "#E7F4EE" : "#D781001A",
                    borderRadius: "100px",
                    color:
                      form.getValues().status === 9 ? "#0D894F" : "#D78100",
                    border: "none",
                    padding: "4px 12px",
                    marginLeft: "10px",
                  }}
                >
                  {t(`departmentStatus.${form.getValues().status}`)}
                </Button>
              </Grid>
            </Grid>
            <Grid item width={"100%"}>
              <ReminderPickerSubForm
                name={NextActionSchemaFieldNames.REMIND}
                module={Module.get(ModuleKeys.LEGISLATION)}
              />
            </Grid>
          </Grid>

          <Grid
            item
            width={"100%"}
            container
            className="form-wrapper"
            sx={{ minWidth: "100%" }}
          >
            <NextActionTable
              control={form.control}
              name={NextActionSchemaFieldNames.NEXT_ACTION_ITEMS}
              status={form.watch("status")}
              err={form.formState.errors}
              isDeptHead={
                legalDocumentOwnerRoles.includes(4) && isNew
                  ? false
                  : legalDocumentOwnerRoles.includes(5) && isNew
                  ? false
                  : legalDocumentOwnerRoles.includes(5) && !isNew
                  ? true
                  : false
              }
            />
          </Grid>
          <FormActionButtons
            formMode={isNew ? "create" : "update"}
            loading={
              getNextActionQuery.isLoading || saveNextActionQuery.isPending
            }
            onCancel={() =>
              router.push(
                `/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${props.documentId}`
              )
            }
            cancelConfirm={form.formState.isDirty}
            onSave={async () => {
              const fileIds = await processFileAttachments(files);
              props.documentId &&
                saveNextActionQuery.mutate({
                  id: props.nextActionId,
                  documentId: props.documentId,
                  nextAction: convertNextActionSchemaToOutput(
                    form.getValues(),
                    fileIds
                  ),
                });
            }}
          />
        </Grid>
      </FormProvider>
      {popupVisibleState?.[ButtonNextActionLegal.FEEDBACK_LC] && (
        <ResponseToLCForm
          name={getNextActionQuery.data?.legalDocumentName ?? ""}
          legalDocumentId={props.documentId}
          nextActionId={props.nextActionId}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonNextActionLegal.FEEDBACK_LC, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonNextActionLegal.FEEDBACK_LC]}
          senderLegalDocument={appContext?.me}
        />
      )}
      {popupVisibleState?.[ButtonNextActionLegal.APPROVAL] && (
        <ApprovalNextActionForm
          name={getNextActionQuery.data?.legalDocumentName ?? ""}
          legalDocumentId={props.documentId}
          nextActionId={props.nextActionId}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonNextActionLegal.APPROVAL, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonNextActionLegal.APPROVAL]}
          isDisabledStatus
          initialValue={{
            status: statusActionsApproval?.inActiveDeptHeadApprove
              ? StatusNextActions.get(StatusNextActionsKey.NEXT_ACTION_REJECT)
              : StatusNextActions.get(
                  StatusNextActionsKey.NEXT_ACTION_APPROVAL
                ),
          }}
          requestSelectData={{
            nextActionItems: getNextActionQuery?.data?.nextActionItems?.map(
              (nextActionItem) => ({
                ...nextActionItem,
                pics: nextActionItem?.pics,
              })
            ),
          }}
        />
      )}
      {popupVisibleState?.[ButtonNextActionLegal.REQUEST_APPROVAL] && (
        <RequestNextActionApprovalForm
          name={getNextActionQuery.data?.legalDocumentName ?? ""}
          legalDocumentId={props.documentId}
          nextActionId={props.nextActionId}
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ButtonNextActionLegal.REQUEST_APPROVAL,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[ButtonNextActionLegal.REQUEST_APPROVAL]}
          isDisabledStatus
        />
      )}
      {popupVisibleState?.[ButtonNextActionLegal.FEEDBACK_EVALUATED] && (
        <AssessmentFeedbackForm
          name={getNextActionQuery.data?.legalDocumentName ?? ""}
          legalDocumentId={props.documentId}
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ButtonNextActionLegal.FEEDBACK_EVALUATED,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[ButtonNextActionLegal.FEEDBACK_EVALUATED]}
          requestSelectData={{ nextActionId: props.nextActionId }}
          isAssessmentFeedbackNextAction
        />
      )}
      {popupVisibleState?.[ButtonNextActionLegal.MONITOR_NEXT_ACTION] && (
        <FollowNextActionForm
          name={getNextActionQuery.data?.legalDocumentName ?? ""}
          legalDocumentId={props.documentId}
          nextActionId={props.nextActionId}
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ButtonNextActionLegal.MONITOR_NEXT_ACTION,
              state,
              reload
            )
          }
          isOpen={
            popupVisibleState?.[ButtonNextActionLegal.MONITOR_NEXT_ACTION]
          }
        />
      )}
      {popupVisibleState?.[ButtonNextActionLegal.COMPLETE_EVALUATED] && (
        <FinishEvaluateForm
          name={getNextActionQuery.data?.legalDocumentName ?? ""}
          legalDocumentId={props.documentId}
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ButtonNextActionLegal.COMPLETE_EVALUATED,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[ButtonNextActionLegal.COMPLETE_EVALUATED]}
          requestSelectData={{ nextActionId: props.nextActionId }}
          isFinishEvaluateNextAction
        />
      )}
      {popupVisibleState?.[ButtonNextActionLegal.TIME_EXTENSION_REQUEST] && (
        <TimeExtensionNextActionForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ButtonNextActionLegal.TIME_EXTENSION_REQUEST,
              state,
              reload
            )
          }
          legalDocumentId={props.documentId}
          nextActionId={props?.nextActionId}
          initialValue={{}}
          isOpen={
            popupVisibleState?.[ButtonNextActionLegal.TIME_EXTENSION_REQUEST]
          }
          name={getNextActionQuery.data?.legalDocumentName ?? ""}
        />
      )}
    </>
  );
};
