import { requestApprovalLegalDocumentNextAction } from "@/apis/service/law_document/law_document";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelectDefaultOption } from "@/components/commons/form_inputs/FormSelectDefaultOption";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys, StatusNextActions } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  castRequestNextActionApprovalFormSchemaToOutput,
  RequestNextActionApprovalFormSchema,
  RequestNextActionApprovalFormSchemaFieldNames,
  RequestNextActionApprovalFormSchemaI,
} from "@/models/law_document/NextActionLegalDocument";
import { BasedUser } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const initialEmptyValue = {
  [RequestNextActionApprovalFormSchemaFieldNames.STATUS]: 5,
  [RequestNextActionApprovalFormSchemaFieldNames.DEADLINE]: "",
  [RequestNextActionApprovalFormSchemaFieldNames.REASON]: "",
  [RequestNextActionApprovalFormSchemaFieldNames.USERS]: [],
  [RequestNextActionApprovalFormSchemaFieldNames.REMIND]: undefined,
};

export interface RequestNextActionApprovalFormProps {
  titlePopup?: string;
  initialValue?: any;
  legalDocumentId: number;
  nextActionId: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  isDisabledStatus?: boolean;
}

export const RequestNextActionApprovalForm = ({
  titlePopup = "next_action.request_approval.title",
  initialValue = initialEmptyValue,
  legalDocumentId,
  nextActionId,
  isOpen = false,
  setIsOpen,
  name,
  module = Module.get(ModuleKeys.LEGISLATION),
  isDisabledStatus = false,
}: RequestNextActionApprovalFormProps) => {
  const [t] = useTranslation();
  const router = useRouter();
  const appContext = useContext(AppContext);

  const form = useForm<RequestNextActionApprovalFormSchemaI>({
    resolver: yupResolver(RequestNextActionApprovalFormSchema as any),
    defaultValues: JSON.parse(JSON.stringify(initialValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const requestApprovalQuery = useMutation({
    mutationFn: requestApprovalLegalDocumentNextAction,
    onSuccess: () => {
      toast.success(t("next_action.message.request_approval_success"));
      onCloseForm(true);
      router.back();
    },
  });

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <Grid container className="form-wrapper" spacing={GLOBAL_SPACING}>
            <Grid item>
              <Grid
                container
                direction={"column"}
                rowGap={GLOBAL_SPACING}
                alignItems={"center"}
                className="form-section-wrapper"
                sx={formInputSxProps}
              >
                <Grid item width={"100%"}>
                  <Typography fontWeight="bold">
                    {t(
                      "next_action.finish_evaluate_form.field_name.documentName"
                    )}
                  </Typography>
                  <Typography>{name}</Typography>
                </Grid>

                <Grid item width={"100%"}>
                  <DateInput
                    control={form.control}
                    name={
                      RequestNextActionApprovalFormSchemaFieldNames.DEADLINE
                    }
                    label={t(
                      "next_action.request_approval.field_name.deadline"
                    )}
                    placeholder={t(
                      "next_action.request_approval.field_name.deadline"
                    )}
                    disabled={form.formState.disabled}
                    required
                  />
                </Grid>

                <Grid item width={"100%"}>
                  <FormSelectDefaultOption
                    control={form.control}
                    name={RequestNextActionApprovalFormSchemaFieldNames.STATUS}
                    label={t("next_action.field_name.status")}
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    options={Array.from(StatusNextActions.keys()).map(
                      (key) => ({
                        label: t(`next_action.option.${key}`),
                        value: StatusNextActions.get(key)!,
                      })
                    )}
                    getOptionKey={(option) => option.value}
                    getOptionLabel={(option) => option.label}
                    required
                    disabled={isDisabledStatus}
                  />
                </Grid>

                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={RequestNextActionApprovalFormSchemaFieldNames.REASON}
                    label={t(
                      `next_action.request_approval.field_name.${RequestNextActionApprovalFormSchemaFieldNames.REASON}`
                    )}
                    placeHolder={t(
                      `next_action.request_approval.field_name.${RequestNextActionApprovalFormSchemaFieldNames.REASON}`
                    )}
                    minRows={5}
                    required
                  />
                </Grid>

                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                  sx={formInputSxProps}
                >
                  <Grid item xs={12}>
                    <FormMultipleSelect<any, BasedUser>
                      control={form.control}
                      name={`${RequestNextActionApprovalFormSchemaFieldNames.USERS}`}
                      label={t(
                        `next_action.request_approval.field_name.personCharge`
                      )}
                      placeholder={t(
                        `next_action.request_approval.field_name.personCharge`
                      )}
                      getOptions={async (keyword) => {
                        const response = await getUsers({
                          searchTerm: keyword,
                          page: 0,
                          size: 100,
                          sortBy: "name",
                          sortOrder: "ASC",
                        });

                        return (response?.users ?? []).map((user) => ({
                          id: user.id,
                          name: user.name ?? "",
                          departmentName: user.department?.name,
                          email: user.email,
                        }));
                      }}
                      getOptionLabel={(option) =>
                        `${option.name ?? ""} (${option.email ?? ""}) - ${
                          option.departmentName ?? ""
                        }`
                      }
                      getOptionKey={(option) => option.id}
                      keyQuery="requestNextAction/queryUser"
                      required
                      isFocus
                    />
                  </Grid>
                </Grid>
              </Grid>
            </Grid>

            <Grid item>
              <ReminderPickerSubForm
                name={RequestNextActionApprovalFormSchemaFieldNames.REMIND}
                module={module}
              />
            </Grid>

            <FormActionButtons
              formMode={"create"}
              textSave="common.button.send"
              loading={requestApprovalQuery.isPending}
              onCancel={() => onCloseForm()}
              cancelConfirm={form.formState.isDirty}
              onSave={() => {
                legalDocumentId &&
                  requestApprovalQuery.mutate({
                    legalDocumentId,
                    nextActionId,
                    request: castRequestNextActionApprovalFormSchemaToOutput(
                      form.getValues()
                    ),
                  });
              }}
            />
          </Grid>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
