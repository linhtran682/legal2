"use client";
import { authApi, ResponseWrapper } from "@/apis";
import { getAgencyIssueds } from "@/apis/service/agency_issued/AgencyIssued";
import { getDepartments } from "@/apis/service/department/department";
import { getDocumentTypes } from "@/apis/service/document_type/DocumentType";
import { getFields } from "@/apis/service/field/Field";
import {
  cloneLegalDocumentFn,
  getLegalDocumentExcel,
  recallLegalDocument,
  shareLegalDocumentFn,
} from "@/apis/service/law_document/law_document";
import { getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { getMultipleAsyncChoosingOperators } from "@/components/commons/filters/MultipleAsyncChoosingFilter";
import { getMultipleSelectOperators } from "@/components/commons/filters/MultipleSelectFilter";
import { getMultipleTreeSelectOperators } from "@/components/commons/filters/MultipleTreeSelectFilter";
import HierarchyToolTip from "@/components/commons/hierarchy-tooltip/HierarchyTooltip";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import MultipleTabsTable from "@/components/commons/tables/multiple_tabs_table/MultipleTabsTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import { URL_OUTLOOK } from "@/constants/constraint";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserRole,
  LegalDocumentUserRoleKey,
  LegalDocumentUserStatus,
  LegalDocumentUserStatusKey,
  MIME_TYPES,
  ModuleFields,
} from "@/constants/general";
import { LEGAL_DOCUMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import {
  AgencyIssuedDTO,
  AgencyIssuedFieldNames,
} from "@/models/agency_issued/AgencyIssued";
import { Department } from "@/models/department/Department";
import {
  DocumentTypeDTO,
  DocumentTypeFieldNames,
} from "@/models/document_type/DocumentType";
import { FieldDTO, FieldFieldNames } from "@/models/field/Field";
import {
  BasedLegalDocument,
  BasedLegalDocumentFieldNames,
  GetBasedLegalDocumentsParams,
  GetBasedLegalDocumentsResponse,
} from "@/models/law_document/BasedLegalDocument";
import {
  LawDocumentBodyReceive,
  legalDocumentSearchPanelConfig,
  SaveLawDocumentRequestFieldNames,
} from "@/models/law_document/LawDocument";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser } from "@/models/user/User";
import { downloadFile, formatDate } from "@/utils";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { Box, Button, Grid, IconButton, Tooltip } from "@mui/material";
import { GridFilterItem } from "@mui/x-data-grid";
import { useMutation, useQuery } from "@tanstack/react-query";
import { endOfDay, format } from "date-fns";
import { uniqueId } from "lodash";
import moment from "moment";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { Range as DateRange } from "react-date-range";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { EvaluateLegalDocumentForm } from "../evaluate_legal_document_form/EvaluateLegalDocumentForm";
import { FeedBackLcForm } from "../feedback_lc_form/FeedBackLcForm";
import { FeedbackLegalDocumentForm } from "../feedback_legal_document_form/FeedbackLegalDocumentForm";
import { FinishLegalDocumentForm } from "../finish_legal_document_form/FinishLegalDocumentForm";
import { ForwardLegalDocumentForm } from "../forward_legal_document_form/ForwardLegalDocumentForm";
import { RequestApprovalForm } from "../request_approval_form/RequestApprovalForm";
import { RequestReviewLegalDocumentForm } from "../request_review_legal_document_form/RequestReviewLegalDocumentForm";
import { TimeExtensionForm } from "../time_extension_form/TimeExtensionForm";
import {
  ButtonAction,
  LegalDocumentTableActionsText,
} from "./legal_document_table_actions/LegalDocumentTableActionsText";
import { AssignmentForm } from "../assignment_form/AssignmentForm";
import { RequestVendorForm } from "../request_vendor_form/RequestVendorForm";
import { RequestVendorFieldNames } from "@/models/law_document/RequestVendor";
import { AssignmentFieldNames } from "@/models/law_document/Assignment";

const LEGAL_DOCUMENT_PATH = "legal-document";

export const getBasedLegalDocuments = async (
  params: GetBasedLegalDocumentsParams
) => {
  const response = await authApi.get<
    ResponseWrapper<GetBasedLegalDocumentsResponse>
  >(LEGAL_DOCUMENT_PATH, {
    params: params,
  });
  return response.data.result;
};

export const deleteLegalDocument = async (id: number) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const response = await authApi.delete<any>(`${LEGAL_DOCUMENT_PATH}/${id}`);
  return response.data;
};

export const LegalDocumentTableConst = {
  GENERAL_TABLE: "LEGISLATION.title.general_table",
  GET_GENERAL_TABLE_ITEM_QUERY_KEY: "getGeneralBasedLegalDocuments",
  PERSONAL_TABLE: "LEGISLATION.title.personal_table",
  GET_PERSONAL_TABLE_ITEM_QUERY_KEY: "getPersonalBasedLegalDocuments",
  GET_LEGAL_DOCUMENT_EXCEL: "getLegalDocumentExcel",
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetBasedLegalDocumentsParams => {
  const params: GetBasedLegalDocumentsParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: BasedLegalDocumentFieldNames.ID,
    orderBy: "DESC",
  };
  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == BasedLegalDocumentFieldNames.DOCUMENT_TYPE) {
      params.documentTypes = (item.value ?? [])
        .map((item: DocumentTypeDTO) => item.id ?? item)
        .join(",");
    }

    if (item.field == BasedLegalDocumentFieldNames.FIELD) {
      params.fields = (item.value ?? [])
        .map((item: FieldDTO) => item.id ?? item)
        .join(",");
    }

    if (item.field == BasedLegalDocumentFieldNames.AGENCY_ISSUES) {
      params.agencyIssued = (item.value ?? [])
        .map((item: AgencyIssuedDTO) => item.id ?? item)
        .join(",");
    }

    if (item.field == BasedLegalDocumentFieldNames.TEXT_NUMBER) {
      params.textNumber = item.value;
    }
    if (item.field == BasedLegalDocumentFieldNames.DOCUMENT_NAME) {
      params.documentName = item.value;
    }
    if (item.field == BasedLegalDocumentFieldNames.CREATED_BY) {
      params.createdUsers = (item.value ?? [])
        .map((item: BasedUser) => item.id ?? item)
        .join(",");
    }

    if (item.field == BasedLegalDocumentFieldNames.DEPARTMENTS) {
      params.departments = (item.value || [])
        .map((department: Department) => department.id)
        .join(",");
    }

    if (item.field == BasedLegalDocumentFieldNames.STATUS) {
      params.status = (item.value ?? [])
        .map((item: StatusDTO) => item.id ?? item)
        .join(",");
    }

    if (item.field == BasedLegalDocumentFieldNames.RECEIVE_FROM_VENDOR_DATE) {
      params.receiveFromVendorDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();
      params.receiveFromVendorDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }

    if (item.field == BasedLegalDocumentFieldNames.VENDOR_RESPONSE_DATE) {
      params.vendorResponseDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();
      params.vendorResponseDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }

    if (item.field == BasedLegalDocumentFieldNames.SUBMISSION_DEADLINE) {
      params.submissionDeadlineFrom = (
        item.value as DateRange
      ).startDate?.toISOString();
      params.submissionDeadlineTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }

    if (item.field == BasedLegalDocumentFieldNames.DEPARTMENT_RESPONSE_DATE) {
      params.departmentResponseDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();
      params.departmentResponseDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }

    if (item.field == BasedLegalDocumentFieldNames.PUBLISH_DATE) {
      params.publishDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();
      params.publishDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }

    if (item.field == BasedLegalDocumentFieldNames.EFFECTIVE_DATE) {
      params.effectiveDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();
      params.effectiveDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    if (
      tableState.sorterModel![0].field === BasedLegalDocumentFieldNames.STATUS
    ) {
      params.sortBy = "legalStatus.status.name";
    }
    if (
      tableState.sorterModel![0].field ===
      BasedLegalDocumentFieldNames.DOCUMENT_TYPE
    ) {
      params.sortBy = "documentType.name";
    }
    if (
      tableState.sorterModel![0].field ===
      BasedLegalDocumentFieldNames.AGENCY_ISSUES
    ) {
      params.sortBy = "agencyIssued.name";
    }
    if (
      tableState.sorterModel![0].field === BasedLegalDocumentFieldNames.FIELD
    ) {
      params.sortBy = "field.name";
    }
    if (
      tableState.sorterModel![0].field ===
      BasedLegalDocumentFieldNames.RECEIVE_FROM_VENDOR_DATE
    ) {
      params.sortBy = "legalStatus.receiveFromVendorDate";
    }
    if (
      tableState.sorterModel![0].field ===
      BasedLegalDocumentFieldNames.VENDOR_RESPONSE_DATE
    ) {
      params.sortBy = "legalStatus.vendorResponseDate";
    }
    if (
      tableState.sorterModel![0].field ===
      BasedLegalDocumentFieldNames.SUBMISSION_DEADLINE
    ) {
      params.sortBy = "legalStatus.submissionDeadline";
    }
    if (
      tableState.sorterModel![0].field ===
      BasedLegalDocumentFieldNames.DEPARTMENT_RESPONSE_DATE
    ) {
      params.sortBy = "legalStatus.departmentResponseDate";
    }
    if (
      tableState.sorterModel![0].field ===
      BasedLegalDocumentFieldNames.DEPARTMENTS
    ) {
      params.sortBy = "departments.name";
    }
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  return params;
};

export const LegalDocumentTable = () => {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const appContext = useContext(AppContext);
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});
  const [initialLawDocument, setInitialLawDocument] = useState<
    LawDocumentBodyReceive | undefined
  >(undefined);
  const [selectedDocuments, setSelectedDocuments] = useState<
    BasedLegalDocument[] | undefined
  >([]);
  const [activeTab, setActiveTab] = useState<number>(0);

  const getStatusListQuery = useQuery({
    queryKey: ['legal-document/get-status-list-all'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.LEGISLATION_NAME.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.NAME,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: true
  });

  const shareMutation = useMutation({
    mutationFn: shareLegalDocumentFn,
    onSuccess: () => {
      toast.success(
        t(`LEGISLATION.message.shareSuccess`)
      );
    },
  });
  const cloneMutation = useMutation({
    mutationFn: cloneLegalDocumentFn,
    onSuccess: () => {
      toast.success(
        t(`LEGISLATION.message.recheckSuccess`)
      );
      getGeneralBasedLegalDocumentsQuery.refetch();
      getPersonalBasedLegalDocumentsQuery.refetch();
    },
  });

  const handleRecheck = (document: any) => {
    const requestAdviceStatus = getStatusListQuery?.data
      ?.find((ele: StatusDTO) => ele.name === LegalDocumentStatusContent.get(
        LegalDocumentUserStatusKey.SENT
      )!)

    document?.id && cloneMutation.mutate({
      id: document?.id as number,
      data: {
        childStatus: requestAdviceStatus?.id as number,
        status: document?.status?.id as number
      }
    })
  }

  const [legalDocumentTableColumns] = useState<MultipleFilterTableColumn[]>(
    () => [
      {
        key: BasedLegalDocumentFieldNames.ID,
        label: BasedLegalDocumentFieldNames.ID,
        type: "number",
        quickFilter: false,
        filterable: false,
        sortable: false,
        hideable: false,
        maxWidth: 52,
      },
      {
        key: BasedLegalDocumentFieldNames.DOCUMENT_TYPE,
        label: BasedLegalDocumentFieldNames.DOCUMENT_TYPE,
        type: undefined,
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 150,
        filterOperators: getMultipleAsyncChoosingOperators(
          {
            getOptions: async () => {
              const response = await getDocumentTypes({
                // name: keyword,
                page: 0,
                size: 100,
                sortBy: DocumentTypeFieldNames.NAME,
                orderBy: "ASC",
              });

              return response?.documentTypes || [];
            },
            getOptionKey: (item) => item.id.toString(),
            getOptionLabel: (item) => item.name,
            keyQuery: BasedLegalDocumentFieldNames.DOCUMENT_TYPE,
          },
          t
        ),
        filterRank: 1,
        flex: 1,
      },
      {
        key: BasedLegalDocumentFieldNames.DOCUMENT_NAME,
        label: BasedLegalDocumentFieldNames.DOCUMENT_NAME,
        type: "string",
        quickFilter: true,
        filterable: false,
        sortable: true,
        hideable: false,
        minWidth: 240,
        flex: 2,
        renderCell: (params) => (
          <HierarchyToolTip
            {...legalDocumentSearchPanelConfig}
            targetId={params.id as number}
            previewTitle={params?.row?.documentName}
            openNewTab
          >
            <span>{params.value}</span>
          </HierarchyToolTip>
        ),
      },
      {
        key: BasedLegalDocumentFieldNames.AGENCY_ISSUES,
        label: BasedLegalDocumentFieldNames.AGENCY_ISSUES,
        type: undefined,
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 240,
        filterOperators: getMultipleAsyncChoosingOperators(
          {
            getOptions: async () => {
              const response = await getAgencyIssueds({
                // name: keyword,
                page: 0,
                size: 100,
                sortBy: AgencyIssuedFieldNames.NAME,
                orderBy: "ASC",
              });

              return response?.agencyIssuedResponses || [];
            },
            getOptionKey: (item) => item.id.toString(),
            getOptionLabel: (item) => item.name,
            keyQuery: BasedLegalDocumentFieldNames.AGENCY_ISSUES,
          },
          t
        ),
        renderCell: (params) => params.value?.name,
        filterRank: 3,
      },
      {
        key: BasedLegalDocumentFieldNames.TEXT_NUMBER,
        label: BasedLegalDocumentFieldNames.TEXT_NUMBER,
        type: "string",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 240,
        filterRank: 4,
      },
      {
        key: BasedLegalDocumentFieldNames.FIELD,
        label: BasedLegalDocumentFieldNames.FIELD,
        type: undefined,
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 240,
        filterRank: 2,
        filterOperators: getMultipleAsyncChoosingOperators(
          {
            getOptions: async () => {
              const response = await getFields({
                // name: keyword,
                page: 0,
                size: 100,
                sortBy: FieldFieldNames.NAME,
                orderBy: "ASC",
              });

              return response?.fieldResponses || [];
            },
            getOptionKey: (item) => item.id.toString(),
            getOptionLabel: (item) => item.name,
            keyQuery: BasedLegalDocumentFieldNames.FIELD,
          },
          t
        ),
      },
      {
        key: BasedLegalDocumentFieldNames.STATUS,
        label: BasedLegalDocumentFieldNames.STATUS,
        type: undefined,
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 240,
        renderCell: (params) => {
          return (
            <Button
              variant="outlined"
              style={{
                background:
                  params?.row?.status?.name &&
                    params?.row?.status?.name === "Hoàn thành"
                    ? "#E7F4EE"
                    : "#D781001A",
                borderRadius: "100px",
                color:
                  params?.row?.status?.name &&
                    params?.row?.status?.name === "Hoàn thành"
                    ? "#0D894F"
                    : "#D78100",
                border: "none",
                padding: "4px 12px",
              }}
            >
              {params?.row?.status?.name}
            </Button>
          );
        },
        filterOperators: getMultipleAsyncChoosingOperators(
          {
            getOptions: async () => {
              const response = await getStatusList({
                // name: keyword,
                page: 0,
                size: 100,
                sortBy: FieldFieldNames.NAME,
                orderBy: "ASC",
                modules: [ModuleFields.LEGISLATION_NAME.module],
                active: 1,
              });

              return response?.statusResponses || [];
            },
            getOptionKey: (item) => item.id.toString(),
            getOptionLabel: (item) => item.name,
            keyQuery: `legal-document-${BasedLegalDocumentFieldNames.STATUS}`,
          },
          t
        ),
        filterRank: 6,
      },
      {
        key: BasedLegalDocumentFieldNames.RECEIVE_FROM_VENDOR_DATE,
        label: BasedLegalDocumentFieldNames.RECEIVE_FROM_VENDOR_DATE,
        type: "date",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 160,
        renderCell: (params) => formatDate(params.value),
      },
      {
        key: BasedLegalDocumentFieldNames.VENDOR_RESPONSE_DATE,
        label: BasedLegalDocumentFieldNames.VENDOR_RESPONSE_DATE,
        type: "date",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 160,
        renderCell: (params) => formatDate(params.value),
      },
      {
        key: BasedLegalDocumentFieldNames.SUBMISSION_DEADLINE,
        label: BasedLegalDocumentFieldNames.SUBMISSION_DEADLINE,
        type: "date",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 120,
        renderCell: (params) => formatDate(params.value),
      },
      {
        key: BasedLegalDocumentFieldNames.DEPARTMENT_RESPONSE_DATE,
        label: BasedLegalDocumentFieldNames.DEPARTMENT_RESPONSE_DATE,
        type: "date",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 240,
        renderCell: (params) => formatDate(params.value),
      },
      {
        key: BasedLegalDocumentFieldNames.PUBLISH_DATE,
        label: BasedLegalDocumentFieldNames.PUBLISH_DATE,
        type: "date",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 140,
        renderCell: (params) => formatDate(params.value),
      },
      {
        key: BasedLegalDocumentFieldNames.EFFECTIVE_DATE,
        label: BasedLegalDocumentFieldNames.EFFECTIVE_DATE,
        type: "date",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 140,
        renderCell: (params) => formatDate(params.value),
      },
      {
        key: BasedLegalDocumentFieldNames.DEPARTMENTS,
        label: BasedLegalDocumentFieldNames.RELATED_DEPARTMENTS,
        type: "string",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 240,
        filterRank: 5,
        flex: 1,
        renderCell: (params) => (
          <Tooltip
            placement="bottom-start"
            title={(params.value || [])?.map((departmentName: any) => (
              <p key={uniqueId("dept_")}>{departmentName}</p>
            ))}
          >
            {(params.value || []).join(",")}
          </Tooltip>
        ),
        filterOperators: getMultipleTreeSelectOperators<Department>(
          {
            getOptions: async (keyword) => {
              try {
                const response = await getDepartments({
                  searchTerm: keyword,
                });
                const first10Departments: Department[] = (
                  response?.departments ?? []
                ).slice(0, 10);
                return first10Departments;
              } catch (e) {
                return [];
              }
            },
            getOptionChildren: (item) => item.children,
            getOptionKey: (item) => item.id.toString(),
            getOptionLabel: (item) => item.name ?? "",
            keyQuery: BasedLegalDocumentFieldNames.DEPARTMENTS,
          },
          t
        ),
      },
      {
        key: BasedLegalDocumentFieldNames.CREATED_BY,
        label: BasedLegalDocumentFieldNames.CREATED_BY,
        type: "string",
        quickFilter: false,
        filterable: true,
        sortable: true,
        hideable: true,
        minWidth: 240,
        filterRank: 7,
        renderCell: (params) => params?.row?.createdBy?.name,
        filterOperators: getMultipleSelectOperators(
          {
            getOptions: async (keyword) => {
              const response = await getUsers({
                searchTerm: keyword,
                page: 0,
                size: 100,
                sortBy: "name",
                sortOrder: "ASC",
              });

              return response?.users ?? [];
            },
            getOptionKey: (item) => item.id.toString(),
            getOptionLabel: (item) =>
              `${item?.name} - ${item?.position?.name ? `${item?.position?.name}.` : ""
              }${item?.department?.name ?? ""}`,
            keyQuery: BasedLegalDocumentFieldNames.CREATED_BY,
          },
          t
        ),
      },
      {
        key: "action",
        label: "action",
        type: undefined,
        renderCell: (params) =>
          (!params?.row?.isDraft
            // && params?.row?.status?.name !== LegalDocumentStatusContent.get(
            //   LegalDocumentUserStatusKey.DONE)
          )
          &&
          LegalDocumentTableActionsText({
            params,
            activeAction: params.row?.isCanFinish ? [ButtonAction.DONE] : [],
            handleClickRequestEvaluate: () =>
              handleClick(ButtonAction.REQUEST_EVALUATE, params.row),
            handleClickResponse: () =>
              handleClick(ButtonAction.RESPONSE, params.row),
            handleClickForWard: () =>
              handleClick(ButtonAction.FORWARD, params.row),
            handleClickEvaluate: () =>
              handleClick(ButtonAction.EVALUATE, params.row),
            handleClickExtendDeadline: () =>
              handleClick(ButtonAction.EXTEND_DEADLINE, params.row),
            handleClickRequestConfirm: () =>
              handleClick(ButtonAction.REQUEST_CONFIRM, params.row),
            handleClickResponseLc: () =>
              handleClick(ButtonAction.RESPONSE_LC, params.row),
            handleClickRequestVendor: () =>
              handleClick(ButtonAction.REQUEST_VENDOR, params.row),
            handleClickAssignment: () =>
              handleClick(ButtonAction.ASSIGNMENT, params.row),
            handleClickFinish: () => handleClick(ButtonAction.DONE, params.row),
            handleClickNext: () =>
              window.open(
                `/${LEGAL_DOCUMENT_ROOT_PATH}/${params.id}/${params.row?.nextActionId
                  ? "update-next-action"
                  : "request-next-action"
                }/${params.row?.nextActionId ??
                encodeURIComponent(params.row?.documentName)
                }`,
                "_blank"
              ),
            handleClickRecall: () => {
              recallQuery.mutate(Number(params.id));
            },
            handleClickRequestMeeting: () => window.open(URL_OUTLOOK, "_blank"),
            handleClickRecheck: () => { handleRecheck(params.row) },
            handleClickShare: () =>
              handleClick(ButtonAction.SHARE, params.row),

          }),
        quickFilter: false,
        filterable: false,
        sortable: false,
        hideable: false,
        cellClassName: "last-column-sticky",
        headerClassName: "last-column-sticky-header",
      },
    ]
  );

  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const getGeneralBasedLegalDocumentsQuery = useQuery({
    queryKey: [LegalDocumentTableConst.GET_GENERAL_TABLE_ITEM_QUERY_KEY],
    queryFn: () =>
      getBasedLegalDocuments(castTableStateToParams(generalTableState)),
  });

  const getPersonalBasedLegalDocumentsQuery = useQuery({
    queryKey: [LegalDocumentTableConst.GET_PERSONAL_TABLE_ITEM_QUERY_KEY],
    queryFn: () =>
      getBasedLegalDocuments({
        ...castTableStateToParams(personalTableState),
        tab: 1,
      }),
  });

  const getLegalDocumentExcelQuery = useQuery({
    queryKey: [LegalDocumentTableConst.GET_LEGAL_DOCUMENT_EXCEL],
    queryFn: () =>
      getLegalDocumentExcel({
        ...castTableStateToParams(
          activeTab === 0 ? generalTableState : personalTableState
        ),
        tab: activeTab,
        isEnglish: i18n.language === "en",
        size: 9999,
      }),
    enabled: false,
  });

  const refetchGeneralTab = () => {
    generalTableState &&
      activeTab === 0 &&
      getGeneralBasedLegalDocumentsQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  };
  const refetchPersonalTab = () => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalBasedLegalDocumentsQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  };

  const recallQuery = useMutation({
    mutationFn: recallLegalDocument,
    onSuccess: () => {
      toast.success(t("LEGISLATION.message.recall_success"));
      refetchGeneralTab();
      refetchPersonalTab();
    },
  });

  useEffect(() => {
    generalTableState &&
      activeTab === 0 &&
      getGeneralBasedLegalDocumentsQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generalTableState, activeTab]);

  useEffect(() => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalBasedLegalDocumentsQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [personalTableState, activeTab]);

  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialLawDocument(row);
      changePopupVisible(type, true);
    }
  };

  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload: boolean = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state) {
      setInitialLawDocument(undefined);
      setSelectedDocuments([]);
    }
    if (reload) {
      refetchGeneralTab();
      refetchPersonalTab();
    }
  };
  const handleGroupActionClick = (
    type: "forward_multiple" | "evaluate_multiple",
    selectedItems: any
  ) => {
    setSelectedDocuments(selectedItems);
    if (type === "forward_multiple") {
      handleClick(ButtonAction.FORWARD);
    } else {
      handleClick(ButtonAction.REQUEST_EVALUATE);
    }
  };

  const renderGroupActions = (props: any) => {
    const selectedItems =
      getPersonalBasedLegalDocumentsQuery.data?.data?.filter((ele) =>
        props?.includes(ele?.id?.toString())
      );
    const enableRequestButton = selectedItems?.every((item) => {
      const isPicLC = item?.legalDocumentActions?.some(
        (ele) =>
          ele.ownerRole ===
          LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC)
      );
      const isSending =
        item?.status?.id ===
        LegalDocumentUserStatus.get(LegalDocumentUserStatusKey.SENT);
      const isVendor =
        item?.status?.id ===
        LegalDocumentUserStatus.get(LegalDocumentUserStatusKey.VENDOR);
      return isPicLC && (isSending || isVendor);
    });
    return (
      <Box
        sx={{
          display: "flex",
          width: "100%",
          gap: 1,
          justifyContent: "flex-end",
          visibility: activeTab === 0 || !props?.length ? "hidden" : "visible",
        }}
      >
        <Button
          className="confirm"
          onClick={() =>
            handleGroupActionClick("forward_multiple", selectedItems)
          }
          variant="contained"
        >
          {t("LEGISLATION.button.forward")}
        </Button>
        <Button
          className="confirm"
          disabled={!enableRequestButton}
          onClick={() =>
            handleGroupActionClick("evaluate_multiple", selectedItems)
          }
          variant="contained"
          sx={{ mr: 1 }}
        >
          {t("LEGISLATION.button.requestEvaluate")}
        </Button>
      </Box>
    );
  };
  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getLegalDocumentExcelQuery.refetch().then((response: any) => {
              const fileName = `${i18n.language === "en" ? "LegalDocument" : "Văn bản pháp luật"
                }_${format(new Date(), "ddMMyyyy")}`;
              downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getGeneralBasedLegalDocumentsQuery.isFetching ||
            getPersonalBasedLegalDocumentsQuery.isFetching ||
            getLegalDocumentExcelQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };

  return (
    <>
      <MultipleTabsTable
        groupedActions={renderGroupActions}
        tableTabs={[
          {
            tabName: t(LegalDocumentTableConst.GENERAL_TABLE),
            tabKey: LegalDocumentTableConst.GENERAL_TABLE,
            data: getGeneralBasedLegalDocumentsQuery.data?.data || [],
            loading: getGeneralBasedLegalDocumentsQuery.isFetching,
            rowCount: getGeneralBasedLegalDocumentsQuery.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t(LegalDocumentTableConst.PERSONAL_TABLE),
            tabKey: LegalDocumentTableConst.PERSONAL_TABLE,
            data: getPersonalBasedLegalDocumentsQuery.data?.data || [],
            loading: getPersonalBasedLegalDocumentsQuery.isFetching,
            rowCount: getPersonalBasedLegalDocumentsQuery.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={legalDocumentTableColumns
          // .filter((column) => appContext.meCanWrite || column.key != "action")
          .map((column) => ({
            ...column,
            label: column.label && `LEGISLATION.column.${column.label}`,
          }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        exportFile={renderExportButton()}
        quickFilterProps={{
          defaultSelectedOptionKey: BasedLegalDocumentFieldNames.DOCUMENT_NAME,
          // quickFilterMode: "multiple",
          placeHolder: () =>
            t(`common.place_holder.search`, {
              fieldName: t(
                `LEGISLATION.field_name.documentName`
              ).toLocaleLowerCase(),
            }),
        }}
        onRowClick={(params) =>
          router.push(
            `/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
          )
        }
        onTabChange={setActiveTab}
      />

      {popupVisibleState?.[ButtonAction.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.SHARE, state, reload)
          }
          isOpen={true}
          owner={
            initialLawDocument?.createdBy ?? initialLawDocument?.createdUser
          }
          pics={initialLawDocument?.users}
          onSubmit={async (data: any) => {
            const params = {
              id: initialLawDocument?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
          initialValue={{
            legalAccessType: initialLawDocument?.legalAccessType,
            sharedDepartments: initialLawDocument?.sharedDepartments,
            sharedUsers: initialLawDocument?.sharedUsers,
          }}
        />
      )}

      {popupVisibleState?.[ButtonAction.FORWARD] && (
        <ForwardLegalDocumentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.FORWARD, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValues={initialLawDocument}
          isOpen={popupVisibleState?.[ButtonAction.FORWARD]}
          name={initialLawDocument?.documentName}
          selectedDocuments={selectedDocuments}
        />
      )}
      {popupVisibleState?.[ButtonAction.RESPONSE] && (
        <FeedbackLegalDocumentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.RESPONSE, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValues={initialLawDocument}
          isOpen={popupVisibleState?.[ButtonAction.RESPONSE]}
          name={initialLawDocument?.documentName}
          sender={appContext.me}
        />
      )}
      {popupVisibleState?.[ButtonAction.REQUEST_EVALUATE] && (
        <RequestReviewLegalDocumentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.REQUEST_EVALUATE, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValues={initialLawDocument}
          isOpen={popupVisibleState?.[ButtonAction.REQUEST_EVALUATE]}
          name={initialLawDocument?.documentName}
          selectedDocuments={selectedDocuments}
        />
      )}
      {popupVisibleState?.[ButtonAction.EVALUATE] && (
        <EvaluateLegalDocumentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.EVALUATE, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValues={initialLawDocument}
          isOpen={popupVisibleState?.[ButtonAction.EVALUATE]}
          name={initialLawDocument?.documentName}
          requestEvaluateId={initialLawDocument?.requestEvaluateId}
        />
      )}
      {popupVisibleState?.[ButtonAction.EXTEND_DEADLINE] && (
        <TimeExtensionForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.EXTEND_DEADLINE, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValue={{}}
          isOpen={popupVisibleState?.[ButtonAction.EXTEND_DEADLINE]}
          extendDeadlineId={initialLawDocument?.extendDeadlineId}
          name={initialLawDocument?.documentName}
          maxDate={moment(initialLawDocument?.departmentResponseDate)
            .add(
              initialLawDocument?.extendDateAllowDeadline,
              !initialLawDocument?.extendDateAllowDeadlineNumberType
                ? "days"
                : "months"
            )
            .toISOString()}
        />
      )}
      {popupVisibleState?.[ButtonAction.REQUEST_CONFIRM] && (
        <RequestApprovalForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.REQUEST_CONFIRM, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          isOpen={popupVisibleState?.[ButtonAction.REQUEST_CONFIRM]}
          name={initialLawDocument?.documentName}
          isDisabledStatus
        />
      )}
      {popupVisibleState?.[ButtonAction.RESPONSE_LC] && (
        <FeedBackLcForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.RESPONSE_LC, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValue={{}}
          isOpen={popupVisibleState?.[ButtonAction.RESPONSE_LC]}
          name={initialLawDocument?.documentName}
          senderLegalDocument={appContext?.me}
        />
      )}
      {popupVisibleState?.[ButtonAction.DONE] && (
        <FinishLegalDocumentForm
          name={initialLawDocument?.documentName ?? ""}
          legalDocumentId={initialLawDocument?.id}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonAction.DONE]}
        />
      )}
      {popupVisibleState?.[ButtonAction.ASSIGNMENT] && (
        <AssignmentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.ASSIGNMENT, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          isOpen={popupVisibleState?.[ButtonAction.ASSIGNMENT]}
          name={initialLawDocument?.documentName}
          senderLegalDocument={appContext?.me}
          initialValue={{
            [AssignmentFieldNames.USERS]: initialLawDocument?.users ?? [],
          }}
          initialLegalDocument={initialLawDocument}
        />
      )}
      {popupVisibleState?.[ButtonAction.REQUEST_VENDOR] && (
        <RequestVendorForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.REQUEST_VENDOR, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          isOpen={popupVisibleState?.[ButtonAction.REQUEST_VENDOR]}
          initialValue={{
            [RequestVendorFieldNames.USERS]: [initialLawDocument?.pic]?.concat(
              initialLawDocument?.assignmentUsers || []
            ),
            [RequestVendorFieldNames.TIME_VENDOR_RESPONSE]:
              initialLawDocument?.[
                SaveLawDocumentRequestFieldNames.VENDOR_RESPONSE_DATE
              ]
                ? new Date(
                    initialLawDocument?.[
                      SaveLawDocumentRequestFieldNames.VENDOR_RESPONSE_DATE
                    ]
                  )
                : null,
          }}
          name={initialLawDocument?.documentName}
          senderLegalDocument={appContext?.me}
        />
      )}
    </>
  );
};
