'use client'
import { getAllHierarchyById } from '@/apis/service/law_document/law_document';
import { SearchResultItem } from '@/components/commons/search_panel/SearchResultItem';
import { COLOR_TYPE } from '@/constants/color';
import { LegalAdviceStatusContent, LegalAdviceStatusKey } from '@/constants/general';
import { LEGAL_DOCUMENT_ROOT_PATH } from '@/constants/paths';
import { formatDate } from '@/utils';
import { styled, Tooltip, tooltipClasses, TooltipProps } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { FC, ReactElement, useCallback } from 'react';

const CustomizedTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 430,
    minWidth: 400,
    fontSize: theme.typography.pxToRem(12),
    border: `1px solid ${COLOR_TYPE.TOYOTA.TOYOTA7}`,
    padding: 0
  },
}));


interface LegalDocumentTableTooltipProps {
  children: ReactElement;
  documentId: string | number;
  documentName: string;
}
const LegalDocumentTableTooltip: FC<LegalDocumentTableTooltipProps> = (props) => {
  const { children, documentId, documentName } = props;
  const { isFetching, data, refetch } = useQuery({
    queryKey: ['legal-document/getHierarchy', documentId],
    queryFn: () => getAllHierarchyById({ id: documentId }),
    enabled: false
  })
  const handleOpen = () => {
    refetch();
  };
  const renderTooltipContent = useCallback(() => {
    if (isFetching || !data?.children?.length) return null;
    return <SearchResultItem<any>
      item={data}
      completeStatusName={LegalAdviceStatusContent.get(LegalAdviceStatusKey.DONE)!}
      getItemKey={(item) => item.documentId ?? item?.id}
      getChildKey={(child) => child?.documentId ?? child?.id}
      getItemName={(item) => item.documentName}
      getCreator={(item) => (item?.createdUser ?? item?.createdBy)}
      getParentTimeLabel={(item) => item?.createdDate
        ? formatDate(item?.createdDate, 'dd/MM/yyyy HH:mm')
        : ""
      }
      getParentUsersList={(item) => item?.personResponsible ?? item?.users}
      getParentStatus={(item) => item?.status?.name ?? item?.status ?? ""}
      getChildStatus={(child) => child?.status?.name ?? child?.status ?? ""}
      getChildTimeLabel={(child) => child?.createdDate
        ? formatDate(child?.createdDate, 'dd/MM/yyyy HH:mm')
        : ""
      }
      getChildUsersList={(child) => child?.personResponsible ?? child?.users}
      getChildren={(item) => item?.children ?? []}
      getItemLink={(item) => `/${LEGAL_DOCUMENT_ROOT_PATH}/update/${item?.documentId ?? item?.id
        }`}
      openNewTab
    />
  }, [isFetching, data])
  return (
    <CustomizedTooltip
      title={renderTooltipContent()}
      placement={'left'}
      onOpen={handleOpen}
    >
      <Tooltip title={data?.children?.length ? null : documentName} placement='bottom-start'>
        {children}
      </Tooltip>
    </CustomizedTooltip>
  )
}

export default LegalDocumentTableTooltip