import {
  ActionButton,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButton";
import { BasedLegalDocument } from "@/models/law_document/BasedLegalDocument";
import { GridRenderCellParams } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import { useState } from "react";
import {
  LEGAL_DOCUMENT_PATH,
  LEGAL_DOCUMENT_ROOT_PATH,
  UI_PATH,
} from "@/constants/paths";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import {
  LegalDocumentUserRole,
  LegalDocumentUserRoleKey,
} from "@/constants/general";
import SendIcon from "@mui/icons-material/Send";
import UndoIcon from "@mui/icons-material/Undo";
import PreviewIcon from "@mui/icons-material/Preview";
import ContactPhoneIcon from "@mui/icons-material/ContactPhone";
import WysiwygIcon from "@mui/icons-material/Wysiwyg";
import CheckIcon from "@mui/icons-material/Check";
import PostAddIcon from "@mui/icons-material/PostAdd";
import MoreTimeIcon from "@mui/icons-material/MoreTime";
import PlaylistAddCheckIcon from "@mui/icons-material/PlaylistAddCheck";
import GradingIcon from "@mui/icons-material/Grading";
import RedoIcon from "@mui/icons-material/Redo";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";

const ButtonAction = {
  EDIT: "EDIT",
  SEND: "send",
  FOWARD: "forward",
  RECALL: "RECALL",
  REQUEST_REVIEW: "REQUEST_REVIEW",
  REQUEST_MEETING: "REQUEST_MEETING",
  RESPONSE: "RESPONSE",
  EVALUATE: "EVALUATE",
  REQUEST_CONFIRM: "REQUEST_CONFIRM",
  CONFIRM: "CONFIRM",
  EXTEND_DEADLINE: "EXTEND_DEADLINE",
  NEXT_ACTION: "NEXT_ACTION",
};

const authorizedActionMap = new Map<number, string[]>([
  [
    LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC)!,
    [
      ButtonAction.EDIT,
      ButtonAction.SEND,
      ButtonAction.FOWARD,
      ButtonAction.RECALL,
      ButtonAction.RESPONSE,
      ButtonAction.REQUEST_REVIEW,
      ButtonAction.REQUEST_MEETING,
    ],
  ],
  [
    LegalDocumentUserRole.get(LegalDocumentUserRoleKey.RELATED_DEPARTMENT)!,
    [ButtonAction.FOWARD, ButtonAction.RECALL, ButtonAction.RESPONSE],
  ],
  [
    LegalDocumentUserRole.get(LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT)!,
    [
      ButtonAction.FOWARD,
      ButtonAction.RECALL,
      ButtonAction.EVALUATE,
      ButtonAction.REQUEST_MEETING,
      ButtonAction.EXTEND_DEADLINE,
      ButtonAction.REQUEST_CONFIRM,
      ButtonAction.NEXT_ACTION,
    ],
  ],
  [
    LegalDocumentUserRole.get(
      LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT
    )!,
    [ButtonAction.FOWARD, ButtonAction.RECALL, ButtonAction.CONFIRM],
  ],
]);

export const LegalDocumentTableActions = (
  params: GridRenderCellParams<BasedLegalDocument>
) => {
  const router = useRouter();
  const [t] = useTranslation();

  const [buttonMap] = useState(
    new Map<string, ActionButtonItem>([
      [
        ButtonAction.EDIT,
        {
          key: ButtonAction.EDIT,
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(
              `/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            ),
          tooltipTitle: t("common.button.edit"),
        },
      ],
      [
        ButtonAction.FOWARD,
        {
          key: ButtonAction.FOWARD,
          icon: <RedoIcon />,
          onClick: () =>
            router.push(
              `/${LEGAL_DOCUMENT_ROOT_PATH}/${LEGAL_DOCUMENT_PATH.FORWARD}/${params.id}/${params.row.documentName}`
            ),
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.FOWARD}`),
        },
      ],
      [
        ButtonAction.SEND,
        {
          key: ButtonAction.SEND,
          icon: <SendIcon />,
          onClick: () =>
            router.push(
              `/${LEGAL_DOCUMENT_ROOT_PATH}/${LEGAL_DOCUMENT_PATH.SEND}/${params.id}/${params.row.documentName}`
            ),
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.SEND}`),
        },
      ],
      [
        ButtonAction.RECALL,
        {
          key: ButtonAction.RECALL,
          icon: <UndoIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.RECALL}`),
          confirmPopupProps: {
            icon: <SaveRecordDialogIcon />,
            title: t(`LEGISLATION.message.confirm_${ButtonAction.RECALL}`),
          },
        },
      ],
      [
        ButtonAction.REQUEST_REVIEW,
        {
          key: ButtonAction.REQUEST_REVIEW,
          icon: <PreviewIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.REQUEST_REVIEW}`),
        },
      ],
      [
        ButtonAction.REQUEST_MEETING,
        {
          key: ButtonAction.REQUEST_MEETING,
          icon: <ContactPhoneIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.REQUEST_MEETING}`),
        },
      ],
      [
        ButtonAction.RESPONSE,
        {
          key: ButtonAction.RESPONSE,
          icon: <WysiwygIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.RESPONSE}`),
        },
      ],
      [
        ButtonAction.EVALUATE,
        {
          key: ButtonAction.EVALUATE,
          icon: <PlaylistAddCheckIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.EVALUATE}`),
        },
      ],
      [
        ButtonAction.REQUEST_CONFIRM,
        {
          key: ButtonAction.REQUEST_CONFIRM,
          icon: <GradingIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.REQUEST_CONFIRM}`),
        },
      ],
      [
        ButtonAction.CONFIRM,
        {
          key: ButtonAction.CONFIRM,
          icon: <CheckIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.CONFIRM}`),
        },
      ],
      [
        ButtonAction.EXTEND_DEADLINE,
        {
          key: ButtonAction.EXTEND_DEADLINE,
          icon: <MoreTimeIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.EXTEND_DEADLINE}`),
        },
      ],
      [
        ButtonAction.NEXT_ACTION,
        {
          key: ButtonAction.NEXT_ACTION,
          icon: <PostAddIcon />,
          onClick: () => {},
          tooltipTitle: t(`LEGISLATION.button.${ButtonAction.NEXT_ACTION}`),
        },
      ],
    ])
  );

  return (
    <ActionButton
      params={params}
      actionButtomItems={(authorizedActionMap.get(0) ?? []).map(
        (buttonKey) => buttonMap.get(buttonKey)!
      )}
    />
  );
};
