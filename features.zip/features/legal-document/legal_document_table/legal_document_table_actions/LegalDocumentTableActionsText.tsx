import { IconAssignment } from "@/assets/iconMenu/IconAssignment";
import IconCopy from "@/assets/iconMenu/IconCopy";
import { IconDone } from "@/assets/iconMenu/IconDone";
import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";
import { IconFeedback } from "@/assets/iconMenu/IconFeedback";
import { IconForward } from "@/assets/iconMenu/IconForward";
import { IconNextAction } from "@/assets/iconMenu/IconNextAction";
import { IconRecall } from "@/assets/iconMenu/IconRecall";
import IconRecheck from "@/assets/iconMenu/IconRecheck";
import { IconRequestConfirm } from "@/assets/iconMenu/IconRequestConfirm";
import { IconRequestEvaluate } from "@/assets/iconMenu/IconRequestEvaluate";
import { IconRequestMeeting } from "@/assets/iconMenu/IconRequestMeeting";
import { IconRequestVendor } from "@/assets/iconMenu/IconRequestVendor";
import { IconResponseLc } from "@/assets/iconMenu/IconResponseLc";
import { IconSendMail } from "@/assets/iconMenu/IconSendMail";
import IconShare from "@/assets/iconMenu/IconShare";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";
import {
  ActionButtonCustom,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButtonCustom";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { COLOR_TYPE } from "@/constants/color";
import {
  ActionButtonKey,
  ActionButtonR,
  ButtonCondition,
  ButtonConditionKey,
  LegalDocumentStatusContent,
  LegalDocumentUserRole,
  LegalDocumentUserRoleKey,
  LegalDocumentUserStatusKey,
} from "@/constants/general";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import RuleIcon from "@mui/icons-material/Rule";
import { useTranslation } from "react-i18next";
export const statusButtonActionLaw = {
  enable: 1,
  disable: 2,
  hidden: 3
}
const btnActionKeyV2Law: any = {
  requestApprove: "requestConfirm",
  remindEvaluate: "evaluate",
  nextAction: "nextAction",
  feedbackLC: "responseLC",
  requestVendor: "requestVendor", // Yêu cầu vendor làm bảng khuyến nghị 
  assigment: "assigment" // Phân công trách nhiệm
}
// const btnActionKeyV2NextAction = {
//   feedbackLC: "responseLC",
//   nextActionRequestApprove: "REQUEST_CONFIRM_NEXT_ACTION",
//   nextActionApprove: "CONFIRM"
// }
export const ButtonAction = {
  SEND: "send", // outlook
  FORWARD: "forward", // Chuyển tiếp
  RECALL: "recall", // Thu hồi
  RESPONSE: "response", // Phản hồi
  REQUEST_MEETING: "requestMeeting", // Yêu cầu họp
  REQUEST_EVALUATE: "requestEvaluate", // Yêu cầu đánh giá
  EVALUATE: "evaluate", // Đánh giá,
  SEND_REMINDERS: "sendReminders", // Gửi lời nhắc nhở
  REQUEST_CONFIRM: "requestConfirm", // Yêu cầu xác nhận ( Yêu cầu Duyệt )
  CONFIRM: "confirm", // Xác nhận ( Duyệt )
  EXTEND_DEADLINE: "extendDeadline", // Gia hạn thời gian
  NEXT_ACTION: "nextAction",
  RESPONSE_LC: "responseLC", // Phản hồi L&C
  REVIEW_APPROVAL: "reviewApproval", // Duyệt đánh giá
  APPROVAL_NEXT_ACTION: "approvalNextAction", // Duyệt next action
  FEEDBACK_EVALUATED: "feedbackEvaluated", // Phản hồi đánh giá
  COMPLETE_EVALUATED: "completeEvaluated", // Hoàn thành đánh giá
  DONE: "done", // Hoàn thành
  SHARE: "share",
  RECHECK: "recheck",
  ASSIGNMENT: "assigment", // Phân công trách nhiệm
  REQUEST_VENDOR: "requestVendor" // Yêu cầu vendor làm bảng khuyến nghị
};
type TypeActionRole = {
  typeBtn: string;
  disable?: boolean;
};

const listActionDefaultNotOwnerAction = new Map<number, TypeActionRole[]>([
  [
    LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC)!,
    [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      { typeBtn: ButtonAction.RESPONSE },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
  ],
  [
    LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PERSON_CHARGE)!,
    [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      { typeBtn: ButtonAction.RESPONSE },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
  ],
  [
    LegalDocumentUserRole.get(LegalDocumentUserRoleKey.RELATED_DEPARTMENT)!,
    [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
      },
    ],
  ],
  [
    LegalDocumentUserRole.get(LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT)!,
    [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      { typeBtn: ButtonAction.EVALUATE },
      { typeBtn: ButtonAction.EXTEND_DEADLINE },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
    ],
  ],
  [
    LegalDocumentUserRole.get(
      LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT
    )!,
    [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
    ],
  ],
  [
    LegalDocumentUserRole.get(
      LegalDocumentUserRoleKey.PERSON_RESPONSIBLE_FORWARD
    )!,
    [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
      },
    ],
  ],
  [LegalDocumentUserRole.get(LegalDocumentUserRoleKey.RELATED_PERSON)!, []],
]);

const uniqueCheck = (checkData: TypeActionRole[]) => {
  return checkData.reduce(
    (accumulator: TypeActionRole[], currentValue: TypeActionRole) => {
      const existing = accumulator.find(
        (item) => item.typeBtn === currentValue.typeBtn
      );

      if (existing) {
        if (Boolean(existing?.disable) === Boolean(currentValue?.disable)) {
          accumulator = accumulator.filter(
            (item) => item.typeBtn !== currentValue.typeBtn
          );
          accumulator.push(currentValue);
        } else {
          const indexAcc = accumulator.findIndex(
            (item: TypeActionRole) => item.typeBtn === currentValue.typeBtn
          );
          accumulator.splice(indexAcc, 1, { ...currentValue, disable: false });
        }
      } else {
        accumulator.push(currentValue);
      }

      return accumulator;
    },
    []
  );
};

const authorizedActionMapCallBack = (
  params: any,
  legalDocumentActions: any,
  btnCondition?: number[]
) => {
  const listItemActionPicDone = [
    {
      typeBtn: ButtonAction.RECHECK,
    },
    {
      typeBtn: ButtonAction.SHARE,
    },
  ];

  let roleList: any = [];
  if (
    params?.row &&
    params?.row?.legalDocumentActions
  ) {
    roleList =
      (params?.row?.legalDocumentActions?.map(
        (legalDocumentActionItem: any) =>
          legalDocumentActionItem?.ownerRole
      ) as number[]) || []
      ;
  }

  if (params?.row?.status?.name === LegalDocumentStatusContent.get(
    LegalDocumentUserStatusKey.DONE
  )!) {
    return roleList.includes(1) ? listItemActionPicDone : [];
  }

  const listActionPIC_LC = {
    [ActionButtonKey.CREATE_NEW]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      ...(btnCondition?.includes(
        ButtonCondition.get(ButtonConditionKey.FEEDBACK_NO_RESPONSE)!
      )
        ? [{ typeBtn: ButtonAction.RESPONSE, disable: true }]
        : []),
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
    [ActionButtonKey.FORWARD]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
        disable: btnCondition?.includes(
          ButtonCondition.get(ButtonConditionKey.FEEDBACK_RESPONSE)!
        ),
      },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
    [ActionButtonKey.REVOKE]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
        disable: btnCondition?.includes(
          ButtonCondition.get(ButtonConditionKey.FEEDBACK_RESPONSE)!
        ),
      },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
    [ActionButtonKey.FEEDBACK]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      ...(btnCondition?.includes(
        ButtonCondition.get(ButtonConditionKey.FEEDBACK_RESPONSE)!
      )
        ? [{ typeBtn: ButtonAction.RESPONSE }]
        : []),
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
    [ActionButtonKey.REQUEST_MEETING]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
        disable: btnCondition?.includes(
          ButtonCondition.get(ButtonConditionKey.FEEDBACK_RESPONSE)!
        ),
      },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
    [ActionButtonKey.REQUEST_EVALUATION]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
        disable: btnCondition?.includes(
          ButtonCondition.get(ButtonConditionKey.FEEDBACK_RESPONSE)!
        ),
      },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
    [ActionButtonKey.DEPARTMENT_EVALUATION_UPDATE]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
        disable: btnCondition?.includes(
          ButtonCondition.get(ButtonConditionKey.FEEDBACK_RESPONSE)!
        ),
      },
      // { typeBtn: ButtonAction.REQUEST_MEETING },
      { typeBtn: ButtonAction.REQUEST_EVALUATE },
      { typeBtn: ButtonAction.SHARE },
    ],
    [ActionButtonKey.DONE]: listActionDefaultNotOwnerAction
      ?.get(
        LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC)!
      )
      ?.map((listActionDefault) => ({
        ...listActionDefault,
        disable: listActionDefault.typeBtn !== ButtonAction.SHARE,
      })),
  };
  const listActionRelatedDepartment = {
    [ActionButtonKey.FORWARD]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
      },
    ],
    [ActionButtonKey.REVOKE]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
        disable: btnCondition?.includes(
          ButtonCondition.get(ButtonConditionKey.FEEDBACK_RESPONSE)!
        ),
      },
    ],
    [ActionButtonKey.FEEDBACK]: [
      { typeBtn: ButtonAction.FORWARD },
      { typeBtn: ButtonAction.RECALL },
      {
        typeBtn: ButtonAction.RESPONSE,
      },
    ],
    [ActionButtonKey.DONE]: listActionDefaultNotOwnerAction
      ?.get(
        LegalDocumentUserRole.get(
          LegalDocumentUserRoleKey.RELATED_DEPARTMENT
        )!
      )
      ?.map((listActionDefault) => ({
        ...listActionDefault,
        disable: true,
      })),
  };
  const listActionItemHeadEvaluated = [
    { typeBtn: ButtonAction.FORWARD },
    { typeBtn: ButtonAction.RECALL },
  ];

  const authorizedActionMap = new Map<number | string, any>([
    [
      LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC)!,
      listActionPIC_LC,
    ],
    [
      LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PERSON_CHARGE)!,
      listActionPIC_LC,
    ],
    [
      LegalDocumentUserRole.get(LegalDocumentUserRoleKey.RELATED_DEPARTMENT)!,
      listActionRelatedDepartment,
    ],
    [
      LegalDocumentUserRole.get(LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT)!,
      {
        [ActionButtonKey.LEGAL_REQUEST_EVALUATION]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.FORWARD]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          {
            typeBtn: ButtonAction.RESPONSE,
            disable: btnCondition?.includes(
              ButtonCondition.get(ButtonConditionKey.FEEDBACK_NO_RESPONSE)!
            ),
          },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.REVOKE]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.EVALUATION]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.REQUEST_APPROVAL]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.EXTEND_TIME]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.GENERATE_NEXT_ACTION]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
        ],
        [ActionButtonKey.LC_FEEDBACK]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        // [ActionButtonKey.REQUEST_MEETING]: [
        //   { typeBtn: ButtonAction.FORWARD },
        //   { typeBtn: ButtonAction.RECALL },
        //   { typeBtn: ButtonAction.REQUEST_MEETING },
        //   { typeBtn: ButtonAction.EVALUATE },
        //   { typeBtn: ButtonAction.EXTEND_DEADLINE },
        // ],
        [ActionButtonKey.HEAD_UPDATE_STATUS]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.LC_PIC_UPDATE_STATUS]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          // { typeBtn: ButtonAction.REQUEST_MEETING },
          { typeBtn: ButtonAction.EVALUATE },
          { typeBtn: ButtonAction.EXTEND_DEADLINE },
        ],
        [ActionButtonKey.DONE]: listActionDefaultNotOwnerAction
          ?.get(
            LegalDocumentUserRole.get(
              LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT
            )!
          )
          ?.map((listActionDefault) => ({
            ...listActionDefault,
            disable: true,
          })),
      },
    ],
    [
      LegalDocumentUserRole.get(
        LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT
      )!,
      {
        [ActionButtonKey.FORWARD]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
          {
            typeBtn: ButtonAction.RESPONSE,
            disable: btnCondition?.includes(
              ButtonCondition.get(ButtonConditionKey.FEEDBACK_NO_RESPONSE)!
            ),
          },
        ],
        [ActionButtonKey.REVOKE]: listActionItemHeadEvaluated,
        [ActionButtonKey.APPROVAL]: listActionItemHeadEvaluated,
        [ActionButtonKey.LC_FEEDBACK]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
        ],
        [ActionButtonKey.LC_PIC_UPDATE_STATUS]: [
          { typeBtn: ButtonAction.FORWARD },
          { typeBtn: ButtonAction.RECALL },
        ],
        [ActionButtonKey.DONE]: listActionDefaultNotOwnerAction
          ?.get(
            LegalDocumentUserRole.get(
              LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT
            )!
          )
          ?.map((listActionDefault) => ({
            ...listActionDefault,
            disable: true,
          })),
      },
    ],
    [
      LegalDocumentUserRole.get(
        LegalDocumentUserRoleKey.PERSON_RESPONSIBLE_FORWARD
      )!,
      listActionRelatedDepartment,
    ],
    [LegalDocumentUserRole.get(LegalDocumentUserRoleKey.RELATED_PERSON)!, {}],
  ]);
  const buttonActionNew = params?.row?.buttonActionNew
  let listActionAuthorizedMap: TypeActionRole[] = [];
  Object?.keys(buttonActionNew)?.forEach((actionNewKey: string) => {
    if (buttonActionNew?.[actionNewKey] !== statusButtonActionLaw.hidden) {
      listActionAuthorizedMap = listActionAuthorizedMap.concat({
        typeBtn: btnActionKeyV2Law[actionNewKey],
        disable:
          buttonActionNew?.[actionNewKey] === statusButtonActionLaw.disable,
      });
    }
  });

  legalDocumentActions.forEach((legalDocumentItemAction: any) => {
    if (!legalDocumentItemAction?.ownerAction) {
      listActionAuthorizedMap = listActionAuthorizedMap.concat(
        listActionDefaultNotOwnerAction?.get(
          legalDocumentItemAction?.ownerRole
        ) as TypeActionRole[]
      );
    } else {
      const authorizedAction =
        authorizedActionMap?.get(legalDocumentItemAction?.ownerRole)?.[
        ActionButtonR.get(legalDocumentItemAction?.ownerAction) as string
        ] || [];
      listActionAuthorizedMap = listActionAuthorizedMap.concat(
        authorizedAction?.length
          ? authorizedAction
          : listActionDefaultNotOwnerAction?.get(
            legalDocumentItemAction?.ownerRole
          )
      );
    }
  });

  return uniqueCheck(listActionAuthorizedMap);
};

type TypePropsLegalDocumentTableActions = {
  params: { row: LawDocumentBodyReceive };
  activeAction?: any;
  isActionDetail?: boolean;
  handleClickSend?: () => void;
  handleClickForWard?: () => void;
  handleClickRecall?: () => void;
  handleClickResponse?: () => void;
  handleClickRequestMeeting?: () => void;
  handleClickRequestEvaluate?: () => void;
  handleClickEvaluate?: () => void;
  handleClickSendReminders?: () => void;
  handleClickRequestConfirm?: () => void;
  handleClickConfirm?: () => void;
  handleClickExtendDeadline?: () => void;
  handleClickNext?: () => void;
  handleClickResponseLc?: () => void;
  handleClickFinish?: () => void;
  handleClickShare?: () => void;
  handleClickRecheck?: () => void;
  handleClickAssignment?: () => void;
  handleClickRequestVendor?: () => void
};

export const LegalDocumentTableActionsText = (
  props: TypePropsLegalDocumentTableActions
) => {
  const {
    params,
    isActionDetail = false,
    handleClickSend = () => { },
    handleClickForWard = () => { },
    handleClickRecall = () => { },
    handleClickResponse = () => { },
    handleClickRequestMeeting = () => { },
    handleClickRequestEvaluate = () => { },
    handleClickEvaluate = () => { },
    handleClickSendReminders = () => { },
    handleClickRequestConfirm = () => { },
    handleClickConfirm = () => { },
    handleClickExtendDeadline = () => { },
    handleClickNext,
    handleClickResponseLc = () => { },
    handleClickFinish = () => { },
    handleClickShare = () => { },
    handleClickRecheck = () => { },
    handleClickAssignment = () => {},
    handleClickRequestVendor = () => {},
    activeAction = [],
  } = props;
  const [t] = useTranslation();
  const styleBtn = {
    background: COLOR_TYPE.TOYOTA.TOYOTA1,
    color: COLOR_TYPE.TOYOTA.TOYOTA8,
  };
  const buttonMap = new Map<string, ActionButtonItem>([
    [
      ButtonAction.SEND,
      {
        key: ButtonAction.SEND,
        icon: <IconSendMail />,
        iconDisable: <IconSendMail color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: "Send Mail",
        onClick: handleClickSend,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.SEND}`),
        secondaryBtn: 2,
        styleBtn,
      },
    ],
    [
      ButtonAction.FORWARD,
      {
        key: ButtonAction.FORWARD,
        icon: <IconForward />,
        iconDisable: <IconForward color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.FORWARD}`),
        onClick: handleClickForWard,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.FORWARD}`),
        secondaryBtn: 3,
        styleBtn,
      },
    ],
    [
      ButtonAction.RECALL,
      {
        key: ButtonAction.RECALL,
        icon: <IconRecall />,
        iconDisable: <IconRecall color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.RECALL}`),
        onClick: handleClickRecall,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.RECALL}`),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(`LEGISLATION.message.confirm_${ButtonAction.RECALL}`),
        },
        secondaryBtn: 1,
        styleBtn,
      },
    ],
    [
      ButtonAction.RESPONSE,
      {
        key: ButtonAction.RESPONSE,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.RESPONSE}`),
        onClick: handleClickResponse,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.RESPONSE}`),
        styleBtn,
        secondaryBtn: 4,
      },
    ],
    [
      ButtonAction.REQUEST_MEETING,
      {
        key: ButtonAction.REQUEST_MEETING,
        icon: <IconRequestMeeting />,
        iconDisable: <IconRequestMeeting color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.REQUEST_MEETING}`),
        onClick: handleClickRequestMeeting,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.REQUEST_MEETING}`),
        styleBtn,
        secondaryBtn: 5,
      },
    ],
    [
      ButtonAction.REQUEST_EVALUATE,
      {
        key: ButtonAction.REQUEST_EVALUATE,
        icon: <IconRequestEvaluate />,
        iconDisable: <IconRequestEvaluate color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.REQUEST_EVALUATE}`),
        onClick: handleClickRequestEvaluate,
        tooltipTitle: t(
          `LEGISLATION.button.${ButtonAction.REQUEST_EVALUATE}`
        ),
        styleBtn,
        order: 5,
      },
    ],
    [
      ButtonAction.EVALUATE,
      {
        key: ButtonAction.EVALUATE,
        icon: <RuleIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA1 }} />,
        iconDisable: <RuleIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA5 }} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.EVALUATE}`),
        children: [
          {
            key: ButtonAction.EVALUATE,
            icon: t(`LEGISLATION.button.${ButtonAction.EVALUATE}`),
            textBtn: t(`LEGISLATION.button.${ButtonAction.EVALUATE}`),
            onClick: handleClickEvaluate,
            tooltipTitle: t(`LEGISLATION.button.${ButtonAction.EVALUATE}`),
            styleBtn: "",
          },
          {
            key: ButtonAction.SEND_REMINDERS,
            icon: t(`LEGISLATION.button.${ButtonAction.SEND_REMINDERS}`),
            textBtn: t(`LEGISLATION.button.${ButtonAction.SEND_REMINDERS}`),
            onClick: handleClickSendReminders,
            tooltipTitle: t(
              `LEGISLATION.button.${ButtonAction.SEND_REMINDERS}`
            ),
            styleBtn: "",
          },
        ],
        onClick: handleClickEvaluate,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.EVALUATE}`),
        styleBtn,
        order: 1,
      },
    ],
    [
      ButtonAction.REQUEST_CONFIRM,
      {
        key: ButtonAction.REQUEST_CONFIRM,
        icon: <IconRequestConfirm />,
        iconDisable: <IconRequestConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.REQUEST_CONFIRM}`),
        onClick: handleClickRequestConfirm,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.REQUEST_CONFIRM}`),
        styleBtn,
        order: 2,
      },
    ],
    [
      ButtonAction.CONFIRM,
      {
        key: ButtonAction.CONFIRM,
        icon: t(`LEGISLATION.button.${ButtonAction.CONFIRM}`),
        textBtn: t(`LEGISLATION.button.${ButtonAction.CONFIRM}`),
        onClick: handleClickConfirm,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.CONFIRM}`),
        styleBtn,
      },
    ],
    [
      ButtonAction.EXTEND_DEADLINE,
      {
        key: ButtonAction.EXTEND_DEADLINE,
        icon: <IconExtendDeadline />,
        iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.EXTEND_DEADLINE}`),
        onClick: handleClickExtendDeadline,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.EXTEND_DEADLINE}`),
        secondaryBtn: 6,
        styleBtn,
      },
    ],
    [
      ButtonAction.NEXT_ACTION,
      {
        key: ButtonAction.NEXT_ACTION,
        icon: <IconNextAction />,
        iconDisable: <IconNextAction color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.NEXT_ACTION}`),
        onClick: handleClickNext,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.NEXT_ACTION}`),
        styleBtn,
        order: 3,
      },
    ],
    [
      ButtonAction.RESPONSE_LC,
      {
        key: ButtonAction.RESPONSE_LC,
        icon: <IconResponseLc />,
        iconDisable: <IconResponseLc color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.RESPONSE_LC}`),
        onClick: handleClickResponseLc,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.RESPONSE_LC}`),
        styleBtn,
        order: 4,
      },
    ],
    [
      ButtonAction.DONE,
      {
        key: ButtonAction.DONE,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.DONE}`),
        onClick: handleClickFinish,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.DONE}`),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        order: 6,
      },
    ],
    [
      ButtonAction.SHARE,
      {
        key: ButtonAction.SHARE,
        icon: <IconShare />,
        iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${ButtonAction.SHARE}`),
        onClick: handleClickShare,
        tooltipTitle: t(
          `legalAdvice.button.${ButtonAction.SHARE}`
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        secondaryBtn: 7,
      },
    ],
    [
      ButtonAction.RECHECK,
      {
        key: ButtonAction.RECHECK,
        icon: <IconCopy />,
        iconDisable: <IconCopy color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`DOCUMENT_REVIEW.button.${ButtonAction.RECHECK}Review`),
        onClick: handleClickRecheck,
        tooltipTitle: t(
          `DOCUMENT_REVIEW.button.${ButtonAction.RECHECK}Review`
        ),
        confirmPopupProps: {
          icon: <IconRecheck />,
          title: t(
            `LEGISLATION.message.confirmRecheck`
          ),
        },
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        order: 7,
      },
    ],
    [
      ButtonAction.ASSIGNMENT,
      {
        key: ButtonAction.ASSIGNMENT,
        icon: <IconAssignment />,
        iconDisable: <IconAssignment color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.ASSIGNMENT}`),
        onClick: handleClickAssignment,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.ASSIGNMENT}`),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        order: 8,
      },
    ],
    [
      ButtonAction.REQUEST_VENDOR,
      {
        key: ButtonAction.REQUEST_VENDOR,
        icon: <IconRequestVendor />,
        iconDisable: <IconRequestVendor color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`LEGISLATION.button.${ButtonAction.REQUEST_VENDOR}`),
        onClick: handleClickRequestVendor,
        tooltipTitle: t(`LEGISLATION.button.${ButtonAction.REQUEST_VENDOR}`),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        order: 9,
      },
    ],
  ])
  if (isActionDetail)
    return (
      <ActionButtonDetail
        params={params}
        actionButtonItems={authorizedActionMapCallBack(
          params,
          params?.row?.legalDocumentActions ?? [],
          params?.row?.btnConditions ?? []
        )
          ?.map((buttons: TypeActionRole) => ({
            ...buttonMap.get(buttons?.typeBtn)!,
            disable: buttons?.disable,
          }))
          .concat(
            activeAction?.length
              ? activeAction?.map((action: string) => buttonMap.get(action))
              : []
          )}
      />
    );

  return (
    <ActionButtonCustom
      params={params}
      actionButtonItems={authorizedActionMapCallBack(
        params,
        params?.row?.legalDocumentActions ?? [],
        params?.row?.btnConditions ?? []
      )
        ?.map((buttons: TypeActionRole) => ({
          ...buttonMap.get(buttons?.typeBtn)!,
          disable: buttons?.disable,
        }))
        .concat(
          activeAction?.length
            ? activeAction?.map((action: string) => buttonMap.get(action))
            : []
        )}
      listActions={props?.params?.row?.legalDocumentActions ?? []}
    />
  );
};
