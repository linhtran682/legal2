import { forwardLegalDocument, forwardMultiple } from "@/apis/service/law_document/law_document";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { BasedLegalDocument } from "@/models/law_document/BasedLegalDocument";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useContext } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import {
  castForwardLegalDocumentRequestSchemaToDTO,
  ForwardLegalDocumentRequestFieldNames,
  ForwardLegalDocumentRequestSchema,
  ForwardLegalDocumentRequestSchemaI,
} from "../../../models/law_document/ForwardLegalDocument";

export interface ForwardLegalDocumentFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  legalDocumentId?: number;
  extendDeadlineId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  initialValues?: LawDocumentBodyReceive;
  selectedDocuments?: BasedLegalDocument[];
  module?: number;
}

const initialEmptyValue: ForwardLegalDocumentRequestSchemaI = {
  users: [],
};

export const ForwardLegalDocumentForm = (
  props: ForwardLegalDocumentFormProps
) => {
  const {
    titlePopup = "forward.title.titlePopup",
    isOpen = false,
    setIsOpen,
    selectedDocuments,
    module = Module.get(ModuleKeys.LEGISLATION)
  } = props;
  const [t] = useTranslation();
  const queryClient = useQueryClient();
  const appContext = useContext(AppContext);

  // fix build: ForwardLegalDocumentRequestSchemaI
  const form = useForm<any>({
    resolver: yupResolver(ForwardLegalDocumentRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onSubmit",
    disabled: !appContext.meCanWrite,
  });

  const forwardLegalDocumentQuery = useMutation({
    mutationFn: forwardLegalDocument,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t("forward.title.titlePopup"),
      }));
      onCloseForm(true)
      queryClient.invalidateQueries({
        queryKey: ["legal-document-forward"],
      });
    },
  });
  const forwardMultipleLegalDocumentQuery = useMutation({
    mutationFn: forwardMultiple,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t("forward.title.titlePopup"),
      }));
      onCloseForm(true)
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({})
  };

  const onSave = () => {
    props.legalDocumentId &&
      forwardLegalDocumentQuery.mutate({
        id: props.legalDocumentId,
        request: castForwardLegalDocumentRequestSchemaToDTO({
          ...form.getValues(),
        }),
      })
    selectedDocuments?.length &&
      forwardMultipleLegalDocumentQuery.mutate({
        request: castForwardLegalDocumentRequestSchemaToDTO({
          ...form.getValues(),
          legalDocumentIds: selectedDocuments?.map((ele) => ele.id),
        }),
      })
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm(false)}>
      <Grid container className="form-wrapper">
        <FormProvider {...form}>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className='form-section-wrapper'
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size='small' fullWidth>
                  <Typography fontWeight="bold">
                    {t("timeExtension.title.textName")}
                  </Typography>
                  {selectedDocuments?.length ?
                    selectedDocuments?.map((ele, index) => (
                      <Typography key={ele.id.toString()}>
                        {index + 1}.  {ele.documentName}
                      </Typography>
                    ))
                    : <Typography>
                      {props.name}
                    </Typography>}
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ForwardLegalDocumentRequestFieldNames.CONTENT}
                  label={t(
                    `LEGISLATION.field_name.${ForwardLegalDocumentRequestFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `LEGISLATION.field_name.${ForwardLegalDocumentRequestFieldNames.CONTENT}`
                  )}
                  minRows={5}
                // required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12} sx={{marginTop:"24px"}}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={'users'}
                    label={t("LEGISLATION.field_name.receiver")}
                    placeholder={t("LEGISLATION.field_name.receiver")}
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"forwardLegalDocument/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>

          <Grid item>
            <ReminderPickerSubForm
              name={ForwardLegalDocumentRequestFieldNames.REMIND}
              module={module}
            />
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={false}
            onCancel={() => onCloseForm()}
            cancelConfirm={form.formState.isDirty}
            onSave={onSave}
          />
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
