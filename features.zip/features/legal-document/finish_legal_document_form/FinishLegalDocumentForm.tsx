import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserStatusKey,
  Module,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { useMutation } from "@tanstack/react-query";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import {
  FinishLegalDocumentFormOutput,
  FinishLegalDocumentFormSchema,
  FinishLegalDocumentFormSchemaFieldNames,
} from "@/models/law_document/FinishLegalDocument";
import { requestFinishLegalDocument } from "@/apis/service/law_document/law_document";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { useSearchStatus } from "@/hooks/useSearchStatus";

const initialEmptyValue: FinishLegalDocumentFormOutput = {
  [FinishLegalDocumentFormSchemaFieldNames.CONTENT]: "",
  [FinishLegalDocumentFormSchemaFieldNames.USERS]: [],
  [FinishLegalDocumentFormSchemaFieldNames.REMIND]: undefined,
};

export interface FinishLegalDocumentTypeFormProps {
  titlePopup?: string;
  initialValue?: FinishLegalDocumentFormOutput;
  legalDocumentId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  defaultStatus?: string;
}

export const FinishLegalDocumentForm = (
  props: FinishLegalDocumentTypeFormProps
) => {
  const {
    titlePopup = "finishLegalDocumentForm.title",
    initialValue = initialEmptyValue,
    legalDocumentId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.LEGISLATION),
    defaultStatus = LegalDocumentStatusContent.get(
      LegalDocumentUserStatusKey.DONE
    )!,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const form = useForm<any>({
    resolver: yupResolver(FinishLegalDocumentFormSchema),
    defaultValues: initialValue,
  });

  const querySearchStatus = useSearchStatus({
    keyword: defaultStatus,
    form,
    queryKey: "LEGAL_DOCUMENT_FINISH",
  });

  const requestFinishLegalDocumentMuation = useMutation({
    mutationFn: requestFinishLegalDocument,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t(titlePopup),
        })
      );
      onCloseForm(true);
    },
  });
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await requestFinishLegalDocumentMuation.mutate({
      legalDocumentId,
      request: { ...data, status: +data?.status },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("finishLegalDocumentForm.field_name.documentName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <FormSelect
                  control={form.control}
                  name={FinishLegalDocumentFormSchemaFieldNames.STATUS}
                  options={[
                    {
                      label: t(
                        `LEGISLATION.option.${LegalDocumentUserStatusKey.DONE}`
                      ),
                      value: querySearchStatus?.data?.[0]?.id,
                    },
                  ]}
                  label={t(
                    `next_action.assessment_feedback_form.field_name.status`
                  )}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  isClearIcon
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FinishLegalDocumentFormSchemaFieldNames.CONTENT}
                  label={t(`finishLegalDocumentForm.field_name.content`)}
                  placeHolder={t(`finishLegalDocumentForm.field_name.content`)}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={FinishLegalDocumentFormSchemaFieldNames.USERS}
                    label={t("finishLegalDocumentForm.field_name.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);
                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"followNextAction/queryUser"}
                    required
                    isFocus
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={FinishLegalDocumentFormSchemaFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={requestFinishLegalDocumentMuation.isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    users:
                      form.getValues().users?.map((ele: BasedUser) => ele.id) ||
                      [],
                    remind: form.getValues()?.remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
