import { EmptyIndicator } from "@/components/commons/empty_idicator/EmptyIndicator";
import { GenericSearchPanel } from "@/components/commons/search_panel/GenericSearchPanel";
import { legalDocumentSearchPanelConfig } from "@/models/law_document/LawDocument";
import { Grid, Stack } from "@mui/material";
import { ReactNode, useState } from "react";

export interface LegalDocumentLayoutProps {
  children: ReactNode | ReactNode[];
  documentName?: string;
}

export const LegalDocumentLayout = (props: LegalDocumentLayoutProps) => {
  const [isResultSearchPanel, setIsResultSearchPanel] = useState(true);

  const handleSetResultSearchPanel = (value: boolean) => {
    setIsResultSearchPanel(value)
  }
  return (
    <Stack sx={{ height: "100%" }}>
      <Grid
        direction={"row"}
        wrap="nowrap"
        sx={{ display: "flex", overflow: "hidden", height: "100%" }}
      >
        <Grid
          item
          sx={{ overflow: "auto", height: "100%", position: "relative" }}
        >
          <GenericSearchPanel<any>
            {...legalDocumentSearchPanelConfig}
            setIsResultSearchPanel={handleSetResultSearchPanel}
          />
        </Grid>
        <Grid
          item
          flex={1}
          style={{
            maxWidth: "100%",
            transition: "max-width 0.2s ease",
            // height: "calc(100vh - 200px)",
            height: "100%",
            overflow: "hidden",
            position: "relative",
          }}
        >
          {!isResultSearchPanel
            ? <EmptyIndicator bgColor="white" />
            : props.children
          }
        </Grid>
      </Grid>
    </Stack >
  );
};
