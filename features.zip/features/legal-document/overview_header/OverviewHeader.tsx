import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import { COLOR_TYPE } from '@/constants/color';
import { LegalDocumentUserRole, LegalDocumentUserRoleKey } from '@/constants/general';
import { AppContext } from '@/context/AppContext';
import useObserveElementSize from '@/hooks/useObserveElementSize';
import { DONE_STATUS } from '@/models/document-review/DocumentReviewDetail';
import { LawDocumentBodyReceive, TypeActionsRole } from '@/models/law_document/LawDocument';
import { Box } from '@mui/material';
import { useContext, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface OverviewHeaderProps {
  initialValueReceive?: LawDocumentBodyReceive;
  isMeeting?: boolean | null;
  disabled?: boolean;
  isLoading?: boolean;
  handleUpdateBookMeeting?: (params: any) => void;
}

const OverviewHeader = (props: OverviewHeaderProps) => {
  const { t } = useTranslation();
  const [isBooked, setIsBooked] = useState(false);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const appContext = useContext(AppContext);
  useEffect(() => {
    if (props.initialValueReceive) {
      setIsBooked(!!props?.initialValueReceive?.isBookMeeting);
    }
    if (
      props.initialValueReceive &&
      props.initialValueReceive?.legalDocumentActions
    ) {
      setOwnRole(
        (props.initialValueReceive?.legalDocumentActions?.map(
          (legalDocumentActionItem: TypeActionsRole) =>
            legalDocumentActionItem?.ownerRole
        ) as number[]) || []
      );
    }
  }, [props.initialValueReceive]);
  const isStatusDone = props?.initialValueReceive?.status?.name === DONE_STATUS;

  const canBookMeeting = (ownRole.includes(
    LegalDocumentUserRole.get(
      LegalDocumentUserRoleKey.PIC_LC
    ) as number
  )
    || ownRole.includes(
      LegalDocumentUserRole.get(
        LegalDocumentUserRoleKey.PERSON_CHARGE
      ) as number
    )
    || ownRole.includes(
      LegalDocumentUserRole.get(
        LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT
      ) as number
    )) && !isStatusDone;

  const disableBookMeeting = !!props.isLoading ||
    !appContext.meCanWrite ||
    (!canBookMeeting)

  const { elementRef, size } = useObserveElementSize();
  const responsiveSx = {
    minWidth: 200,
    flex: 1
  }

  return (
    <Box
      ref={elementRef}
      sx={{
        display: size.width <= 1140 ? 'grid' : 'flex',
        justifyContent: 'space-between',
        p: 2, backgroundColor: 'white',
        mb: 2,
        gridTemplateColumns: `repeat(auto-fill, minmax(200px, 1fr))`
      }}
    >
      {/* <Stack sx={{ p: 2, backgroundColor: 'white', mb: 2, flexWrap: "wrap" }} direction={"row"}  > */}
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx, }}>
        <CheckboxInput
          borderColor={!canBookMeeting ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
          checkboxBg={!canBookMeeting ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"}
          labelVariant={canBookMeeting ? 'subtitle1' : undefined}
          checked={isBooked}
          disabled={disableBookMeeting}
          onChange={async (e) => {
            if (disableBookMeeting) return;
            await props?.handleUpdateBookMeeting?.({
              legalDocumentId: props?.initialValueReceive?.id,
              request: {
                isBookMeeting: e
              }
            })
            setIsBooked(e)
          }}
          label={t("LEGISLATION.evaluateField.meeting")}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={false}
          disabled={true}
          label={t("LEGISLATION.evaluateField.response")}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={
            props?.initialValueReceive &&
              props?.initialValueReceive?.evaluateApprovalDepartment > 0 &&
              props?.initialValueReceive?.evaluateTotalDepartment > 0
              ? true
              : false
          }
          disabled={true}
          label={`${t("LEGISLATION.evaluateField.evaluate")} ${props?.initialValueReceive &&
            props.initialValueReceive.evaluateTotalDepartment > 0
            ? `(${props.initialValueReceive.evaluateApprovalDepartment ??
            "0"
            }/${props.initialValueReceive.evaluateTotalDepartment})`
            : ""
            }`}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={
            props?.initialValueReceive &&
              props?.initialValueReceive?.evaluateApproval > 0 &&
              props?.initialValueReceive?.evaluateTotal > 0
              ? true
              : false
          }
          disabled={true}
          label={`${t("LEGISLATION.evaluateField.evaluateApproval")} ${props?.initialValueReceive &&
            props?.initialValueReceive?.evaluateTotal > 0
            ? ` (${props?.initialValueReceive?.evaluateApproval}/${props.initialValueReceive?.evaluateTotal})`
            : ""
            }`}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={
            props?.initialValueReceive &&
              props?.initialValueReceive?.nextActionTotal > 0
              ? true
              : false
          }
          disabled={true}
          label={`${t("LEGISLATION.evaluateField.nextAction")} ${props?.initialValueReceive &&
            props?.initialValueReceive?.nextActionTotal > 0
            ? ` (${props.initialValueReceive?.nextActionTotal})`
            : ""
            }`}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={
            props?.initialValueReceive &&
              props?.initialValueReceive?.nextActionApproval > 0 &&
              props?.initialValueReceive?.nextActionTotal > 0
              ? true
              : false
          }
          disabled={true}
          label={`${t("LEGISLATION.evaluateField.nextActionApproval")} ${props?.initialValueReceive &&
            props?.initialValueReceive?.nextActionTotal > 0
            ? ` (${props?.initialValueReceive?.nextActionApproval ?? "0"
            }/${props.initialValueReceive?.nextActionTotal})`
            : ""
            }`}
        />
      </Box>
      {/* </Stack > */}
    </Box>
  )
}

export default OverviewHeader