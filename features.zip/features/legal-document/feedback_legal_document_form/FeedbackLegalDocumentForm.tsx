import { feedbackLegalDocument } from "@/apis/service/law_document/law_document";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { LANGUAGES } from "@/locales/config-translation";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import { BasedUser, UserProfileDTO } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useContext } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import {
  castFeedbackLegalDocumentRequestSchemaToDTO,
  FeedbackLegalDocumentRequestFieldNames,
  FeedbackLegalDocumentRequestSchema,
  FeedbackLegalDocumentRequestSchemaI,
} from "../../../models/law_document/FeedbackLegalDocument";

export interface SendLegalDocumentFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  legalDocumentId?: number;
  extendDeadlineId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  initialValues?: LawDocumentBodyReceive;
  module?: number;
  sender?: UserProfileDTO;
}

const initialEmptyValue: FeedbackLegalDocumentRequestSchemaI = {
  users: [],
  deadline: new Date().toISOString(),
  departments: [],
  content: ''
};

export const FeedbackLegalDocumentForm = (
  props: SendLegalDocumentFormProps
) => {
  const {
    titlePopup = "feedback.title.titlePopup",
    isOpen = false,
    setIsOpen,
    module = Module.get(ModuleKeys.LEGISLATION),
    sender
  } = props
  const queryClient = useQueryClient();
  const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const isEnglish = i18n.language === LANGUAGES.ENGLISH

  // fix build: FeedbackLegalDocumentRequestSchemaI
  const form = useForm<any>({
    resolver: yupResolver(FeedbackLegalDocumentRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onSubmit",
    disabled: !appContext.meCanWrite,
  });

  const feedbackLegalDocumentQuery = useMutation({
    mutationFn: feedbackLegalDocument,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t("feedback.title.titlePopup"),
      }));
      onCloseForm(true)
      queryClient.invalidateQueries({
        queryKey: [`legal-document-feedback`],
      });
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({})
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <FormProvider {...form}>
        <Grid container className='form-wrapper' spacing={GLOBAL_SPACING}>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className='form-section-wrapper'
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size='small' fullWidth>
                  <Typography fontWeight="bold">
                    {t("timeExtension.title.textName")}
                  </Typography>
                  <Typography>
                    {props.name}
                  </Typography>
                </FormControl>
              </Grid>

              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {t(`legalAdvice.feedbackAdvice.title.sender`)}
                </label>
                {sender && <Typography>
                  {getUserLabel(sender, isEnglish)}
                </Typography>}
              </Grid>

              <Grid item width={"100%"}>
                <DateInput
                  name={FeedbackLegalDocumentRequestFieldNames.DEADLINE}
                  control={form.control}
                  label={t(
                    `feedback.title.${FeedbackLegalDocumentRequestFieldNames.DEADLINE}`
                  )}
                  placeholder={t(
                    `feedback.title.${FeedbackLegalDocumentRequestFieldNames.DEADLINE}`
                  )}
                // required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedbackLegalDocumentRequestFieldNames.CONTENT}
                  label={t(
                    `LEGISLATION.field_name.${FeedbackLegalDocumentRequestFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `LEGISLATION.field_name.${FeedbackLegalDocumentRequestFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={'users'}
                  label={t("LEGISLATION.field_name.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });

                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery='queryUser'
                  isFocus
                  required
                  minCharLength={1}
                />
              </Grid>
            </Grid>
          </Grid>

          <Grid item>
            <ReminderPickerSubForm
              name={FeedbackLegalDocumentRequestFieldNames.REMIND}
              module={module}
            />
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={false}
            onCancel={() => onCloseForm()}
            cancelConfirm={form.formState.isDirty}
            onSave={() =>
              props.legalDocumentId &&
              feedbackLegalDocumentQuery.mutate({
                id: props.legalDocumentId,
                request: castFeedbackLegalDocumentRequestSchemaToDTO(
                  {
                    ...form.getValues(),
                    departments: []
                  }
                ),
              })
            }
          />
        </Grid>
      </FormProvider>
    </ModalCommon>
  );
};
