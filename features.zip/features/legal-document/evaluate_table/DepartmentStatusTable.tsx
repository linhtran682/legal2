import { approveMultipleLegalDocumentNextAction } from "@/apis/service/law_document/law_document";
import { useUpdateMultipleRequestApproval } from "@/apis/service/law_document/requestApproval";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import StandardTable, {
  StandardTableColumn,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserRole,
  LegalDocumentUserRoleKey,
  LegalDocumentUserStatusKey,
  StatusEvaluatedTable,
  StatusEvaluatedTableKey,
} from "@/constants/general";
import { LEGAL_DOCUMENT_ROOT_PATH } from "@/constants/paths";
import { DepartmentStatusDTO } from "@/models/law_document/DepartmentStatus";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import { formatDate } from "@/utils";
import InfoIcon from "@mui/icons-material/Info";
import { Box, Button, Tooltip, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { uniqueId } from "lodash";
import { FC, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

interface DepartmentStatusTableProps {
  legalDocument: LawDocumentBodyReceive;
  getDepartmentStatusQuery?: any;
  handleClickApprove: (request: any) => void;
  handleClickApproveNextAction: (request: any) => void;
  handleClickRequestApproval: () => void;
  handleClickFeedbackEvaluated: (request: any) => void;
  handleClickCompleteEvaluated: (request: any) => void;
}
const DepartmentStatusTable: FC<DepartmentStatusTableProps> = (props) => {
  const {
    legalDocument,
    getDepartmentStatusQuery,
    handleClickApprove,
    // handleClickRequestApproval,
    handleClickApproveNextAction,
    handleClickFeedbackEvaluated,
    handleClickCompleteEvaluated,
  } = props;
  const { t } = useTranslation();
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const isHeadEvaluatedDepartment = legalDocument?.legalDocumentActions?.some(
    (ele) =>
      ele.ownerRole ===
      LegalDocumentUserRole.get(
        LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT
      )
  );
  // const isEvaluatedDepartment = legalDocument?.legalDocumentActions?.some(
  //   (ele) =>
  //     ele.ownerRole ===
  //     LegalDocumentUserRole.get(LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT)
  // );
  const isEvaluatedPicLc = legalDocument?.legalDocumentActions?.some(
    (ele) =>
      ele.ownerRole ===
      LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC)
  );

  const columns: StandardTableColumn[] = [
    {
      key: "id",
      label: "LEGISLATION.column.id",
      type: "string",
      filterable: false,
      sortable: false,
      hideable: false,
    },
    {
      key: "department",
      label: "metadata.confirm.column.departmentName",
      type: "string",
      flex: 1,
      minWidth: 240,
      renderCell: (params) => <span>{params.row?.department?.name}</span>,
    },
    {
      key: "employeeName",
      label: "metadata.confirm.column.employeeName",
      type: "string",
      minWidth: 200,
      flex: 2,
      renderCell: (params) => (
        <Tooltip
          title={
            <>
              {params?.row?.users.map((u: any) => (
                <p key={uniqueId("name_")}>{u?.name}</p>
              ))}
            </>
          }
        >
          <span>{params?.row?.users?.map((u: any) => u?.name).join(", ")}</span>
        </Tooltip>
      ),
    },
    {
      key: "evaluate",
      label: "departmentStatus.evaluateContent",
      type: "string",
      flex: 1,
      minWidth: 240,
      renderCell: (params) =>
        params?.row?.requestApprovalIds?.length ? (
          <span>{params?.row?.evaluate}</span>
        ) : (
          params?.row?.evaluate
        ),
    },
    {
      key: "deadline",
      label: "legalAdvice.label.responseDeadlineEva",
      type: "string",
      minWidth: 160,
      align: "center",
      renderCell: (params) => (
        <span>
          {params?.row?.deadline
            ? formatDate(params?.row?.deadline, "dd/MM/yyyy")
            : ""}
        </span>
      ),
    },
    {
      key: "nextAction",
      label: "Next Action",
      type: "string",
      flex: 1,
      minWidth: 240,
      renderCell: (params) =>
        params?.row?.nextActionId ? (
          <span
            onClick={() => onNextActionCellClick(params?.row)}
            style={{
              textAlign: "right",
              color: COLOR_TYPE.BLUE.BLUE6,
              textDecorationLine: "underline",
              cursor: "pointer",
            }}
          >
            {params?.row?.nextActionName ?? "Next Action"}
          </span>
        ) : null,
    },
    {
      key: "nextActionDeadline",
      label: "next_action.field_name.deadline",
      type: "string",
      minWidth: 160,
      align: "center",
      renderCell: (params) => (
        <span>
          {params?.row?.nextActionDeadline
            ? formatDate(params?.row?.nextActionDeadline, "dd/MM/yyyy")
            : ""}
        </span>
      ),
    },
    {
      key: "status",
      label: "metadata.confirm.column.status",
      type: "string",
      minWidth: 260,
      renderCell: (params) =>
        params?.row?.status >= 0 ? (
          <Button
            sx={{
              background: params?.row?.status === 9 ? "#E7F4EE" : "#D781001A",
              borderRadius: "100px",
              color: params?.row?.status === 9 ? "#0D894F" : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {t(`departmentStatus.${params?.row?.status}`)}
          </Button>
        ) : (
          ""
        ),
    },
    {
      key: "action",
      label: "Action",
      type: undefined,
      filterable: false,
      sortable: false,
      hideable: false,
      flex: 1,
      minWidth: 380,
      renderCell: (params) => {
        return isEvaluatedPicLc ? (
          <div>
            <Button
              onClick={() => handleClickFeedbackEvaluated(params.row)}
              variant="outlined"
              sx={{ marginRight: "8px" }}
              disabled={
                legalDocument?.status?.name ===
                LegalDocumentStatusContent.get(
                  LegalDocumentUserStatusKey.DONE
                )! ||
                ![
                  StatusEvaluatedTable.get(StatusEvaluatedTableKey.FEEDBACK_LC),
                  StatusEvaluatedTable.get(
                    StatusEvaluatedTableKey.FEEDBACK_EVALUATE
                  ),
                  StatusEvaluatedTable.get(
                    StatusEvaluatedTableKey.FINISH_EVALUATE
                  ),
                  StatusEvaluatedTable.get(
                    StatusEvaluatedTableKey.FOLLOW_NEXT_ACTION
                  ),
                ].includes(params.row?.status)
              }
            >
              {t("next_action.button.feedbackEvaluated")}
            </Button>
            <Button
              onClick={() => handleClickCompleteEvaluated(params.row)}
              variant="outlined"
              disabled={
                legalDocument?.status?.name ===
                LegalDocumentStatusContent.get(
                  LegalDocumentUserStatusKey.DONE
                )! ||
                ![
                  StatusEvaluatedTable.get(StatusEvaluatedTableKey.FEEDBACK_LC),
                  StatusEvaluatedTable.get(
                    StatusEvaluatedTableKey.FINISH_EVALUATE
                  ),
                  StatusEvaluatedTable.get(
                    StatusEvaluatedTableKey.FOLLOW_NEXT_ACTION
                  ),
                ].includes(params.row?.status)
              }
            >
              {t("next_action.button.completeEvaluated")}
            </Button>
          </div>
        ) : (
          <div>
            <Button
              onClick={() => handleClickApprove(params.row)}
              variant="outlined"
              sx={{ marginRight: "8px" }}
              disabled={
                legalDocument?.status?.name ===
                LegalDocumentStatusContent.get(
                  LegalDocumentUserStatusKey.DONE
                )! || ![
                  StatusEvaluatedTable.get(
                    StatusEvaluatedTableKey.REQUEST_APPROVAL
                  )].includes(params.row?.status) || !params.row?.requestApprovalIds?.length
              }
            >
              {t("LEGISLATION.evaluateField.evaluateApproval")}
            </Button>
            <Button
              onClick={() => handleClickApproveNextAction(params.row)}
              variant="outlined"
              disabled={
                legalDocument?.status?.name ===
                LegalDocumentStatusContent.get(
                  LegalDocumentUserStatusKey.DONE
                )! ||
                !params.row?.nextActionId ||
                ![
                  StatusEvaluatedTable.get(
                    StatusEvaluatedTableKey.REQUEST_APPROVAL_NEXT_ACTION
                  ),
                  // StatusEvaluatedTable.get(
                  //   StatusEvaluatedTableKey.APPROVAL_NEXT_ACTION
                  // ),
                  // StatusEvaluatedTable.get(
                  //   StatusEvaluatedTableKey.NEXT_ACTION_REJECT
                  // ),
                  // StatusEvaluatedTable.get(StatusEvaluatedTableKey.FEEDBACK_LC),
                ].includes(params.row?.status)
              }
              className="confirm"
            >
              {t("LEGISLATION.evaluateField.nextActionApproval")}
            </Button>
          </div>
        );
      },
    },
  ];

  // const onEvaluateCellClick = (row: any) => {
  //   if (isHeadEvaluatedDepartment) {
  //     handleClickApprove(row);
  //     return;
  //   }
  //   if (isEvaluatedDepartment) {
  //     handleClickRequestApproval();

  //     return;
  //   }
  // };

  const onNextActionCellClick = (row: any) => {
    window.open(
      `/${LEGAL_DOCUMENT_ROOT_PATH}/${legalDocument.id}/update-next-action/${row?.nextActionId}`
    );
  };
  // const handleApproveNextAction = (row: any) => {
  //   window.open(`/${LEGAL_DOCUMENT_ROOT_PATH}/${legalDocument.id}/update-next-action/${row?.nextActionId}`)
  // }
  const { mutateAsync: updateMultipleRequestApproval } =
    useUpdateMultipleRequestApproval({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t("requestApproval.title.titlePopup"),
            })
          );
        },
      },
    });

  const approveMultipleNextActionQuery = useMutation({
    mutationFn: approveMultipleLegalDocumentNextAction,
    onSuccess: () => {
      toast.success(t("next_action.message.approve_success"));
    },
  });

  const handleApproveMultipleEvaluations = async (items: any) => {
    const requestApprovalIds = items?.reduce(
      (prev: number[], curr: DepartmentStatusDTO) => {
        const idList = [...prev];
        if (curr?.requestApprovalIds?.length) {
          idList.push(...curr?.requestApprovalIds);
        }
        return idList;
      },
      []
    );
    await updateMultipleRequestApproval({
      legalDocumentId: legalDocument.id,
      data: {
        requestApprovalIds,
        approvalStatus: 1, // Đồng ý
        status: 11, // Đánh giá: Duyệt
      },
    });
  };
  const handleApproveMultipleNextActions = async (items: any) => {
    const nextActionIds = items?.reduce(
      (prev: number[], curr: DepartmentStatusDTO) => {
        const idList = [...prev];
        if (curr?.nextActionId) {
          idList.push(curr?.nextActionId);
        }
        return idList;
      },
      []
    );
    approveMultipleNextActionQuery.mutate({
      documentId: legalDocument.id,
      request: {
        nextActionIds,
        approvalStatus: 1, // Đồng ý
        status: 13, // Next action: Duyệt
      },
    });
  };

  const handleApproveMultiple = (
    items: any,
    type: "approve_multiple" | "approve_multiple_action"
  ) => {
    setConfirmPopupState({
      open: true,
      handleConfirm: () => {
        if (type === "approve_multiple") {
          handleApproveMultipleEvaluations(items);
        } else {
          handleApproveMultipleNextActions(items);
        }
        setConfirmPopupState(DefaultConfirmPopupState);
      },
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
      icon: <InfoIcon />,
      title: t(`LEGISLATION.message.${type}`),
    });
  };

  const renderGroupActions = (props: any) => {
    const selectedItems =
      getDepartmentStatusQuery?.data?.departmentStatusList?.filter(
        (ele: any, index: number) => props?.includes(index?.toString())
      );

    return (
      <Box sx={{ display: "flex", width: "100%", gap: 0.5 }}>
        <Button
          className="confirm"
          onClick={() =>
            handleApproveMultiple(selectedItems, "approve_multiple")
          }
          variant="contained"
          sx={{ mr: 1 }}
        >
          {t("LEGISLATION.evaluateField.evaluateApproval")}
        </Button>
        <Button
          className="confirm"
          onClick={() =>
            handleApproveMultiple(selectedItems, "approve_multiple_action")
          }
          variant="contained"
          sx={{ mr: 1 }}
        >
          {t("LEGISLATION.evaluateField.nextActionApproval")}
        </Button>
      </Box>
    );
  };

  return !getDepartmentStatusQuery?.data?.departmentStatusList
    ?.length ? null : (
    <Box
      sx={{ padding: GLOBAL_SPACING, backgroundColor: "white", width: "100%" }}
    >
      <ConfirmPopup {...confirmPopupState} />
      <Typography
        sx={{
          mb: 2,
          color: "#00000099",
          fontSize: "14.5px",
          fontWeight: "600",
        }}
      >
        {t("evaluate.title.titlePopup")}
      </Typography>
      <Box style={{ width: "100%", overflow: "auto" }}>
        <Box style={{ minWidth: "1800px", width: "100%" }}>
          <Box style={{ overflow: "auto", width: "100%" }}>
            <StandardTable
              data={
                getDepartmentStatusQuery?.data?.departmentStatusList?.map(
                  (ele: any, index: number) => ({
                    ...ele,
                    id: index.toString(),
                  })
                ) ?? []
              }
              columns={
                isHeadEvaluatedDepartment || isEvaluatedPicLc
                  ? columns
                  : columns.filter((c) => c.key !== "action")
              }
              getRowId={(row: any) => row?.id}
              hideFooter
              hideRowCheckbox={!isHeadEvaluatedDepartment}
              groupedActions={(props) => renderGroupActions(props)}
              styleDataGridSxProps={{
                "& .MuiDataGrid-scrollbar": {
                  display:"none",
                  overflow:"hidden"
                },
                "& .MuiDataGrid-filler": {
                  display:"none",
                  overflow:"hidden"
                },
                "& .MuiDataGrid-virtualScroller":{
                  overflow:"hidden"
                }
              }}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default DepartmentStatusTable;
