import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { castFeedbackLegalDocumentRequestSchemaToDTO } from "@/models/law_document/FeedbackLegalDocument";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { useCreateFeedBackLc } from "@/apis/service/law_document/feedbackLc";
import {
  FeedBackLcRequestFieldNames,
  RequestFeedBackLcSchema,
  RequestFeedBackLcSchemaI,
} from "@/models/law_document/FeedBackLc";
import { useSearchStatus } from "@/hooks/useSearchStatus";

const initialEmptyValue: RequestFeedBackLcSchemaI = {
  [FeedBackLcRequestFieldNames.CONTENT]: "",
  [FeedBackLcRequestFieldNames.USERS]: [],
  [FeedBackLcRequestFieldNames.REMIND]: undefined,
};

export interface FeedBackLcTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestFeedBackLcSchemaI;
  legalDocumentId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  defaultStatus?: string;
  senderLegalDocument?: any;
}

export const FeedBackLcForm = (props: FeedBackLcTypeFormProps) => {
  const {
    titlePopup = "feedbackLc.title.titlePopup",
    initialValue = initialEmptyValue,
    legalDocumentId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.LEGISLATION),
    defaultStatus = LegalDocumentStatusContent.get(
      LegalDocumentUserStatusKey.RESPONSE_LC
    )!,
    senderLegalDocument,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(RequestFeedBackLcSchema),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    modules: ModuleFields.LEGISLATION_NAME.module,
    queryKey: "LEGAL_DOCUMENT_FEED_BACK_LC",
  });

  const { mutateAsync: createFeedBackLc, isPending } = useCreateFeedBackLc({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t(titlePopup),
          }).replace(/&amp;/g, "&")
        );
        onCloseForm(true);
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createFeedBackLc({
      legalDocumentId,
      data: { ...data, status: data?.status && +data?.status },
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("feedbackLc.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {t(`feedbackLc.title.responder`)}
                </label>
                <Typography>
                  {senderLegalDocument?.name} ({senderLegalDocument?.email}) -{" "}
                  {senderLegalDocument?.departmentName ??
                    senderLegalDocument?.department?.name}
                </Typography>
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={FeedBackLcRequestFieldNames.STATUS}
                  label={t(`feedbackLc.title.status`)}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query-feed-back-lc"}
                  placeholder={t(`feedbackLc.placeHolder.status`)}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedBackLcRequestFieldNames.CONTENT}
                  label={t(`feedbackLc.title.${"content"}`)}
                  placeHolder={t(`feedbackLc.placeHolder.${"content"}`)}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={FeedBackLcRequestFieldNames.USERS}
                    label={t("LEGISLATION.field_name.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"feedbackkLc/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={FeedBackLcRequestFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedbackLegalDocumentRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
