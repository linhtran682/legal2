import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { LawDocumentBodyReceive } from "@/models/law_document/LawDocument";
import { Box, Grid } from "@mui/material";
import { useTranslation } from "react-i18next";

interface EvaluateProps {
  initialValueReceive?: LawDocumentBodyReceive;
  onChangeMeeting: (isMeeting: boolean) => void;
  isMeeting?: boolean | null;
  disabled?: boolean;
}
const EvaluateInformation = (props: EvaluateProps) => {
  const [t] = useTranslation();

  return (
    <Grid container className="form-wrapper">
      <Grid
        container
        direction={"column"}
        rowGap={GLOBAL_SPACING}
        alignItems={"center"}
        className="form-section-wrapper"
        sx={formInputSxProps}
      >
        <Grid item container direction="row" spacing={2}>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.SUCCESS.GREEN7}
                labelColor={COLOR_TYPE.SUCCESS.GREEN7}
                checked={props.isMeeting ? props.isMeeting : false}
                disabled={props?.disabled}
                onChange={(e) => props?.onChangeMeeting(e)}
                label={t("LEGISLATION.evaluateField.meeting")}
              />
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                checked={false}
                disabled={true}
                label={t("LEGISLATION.evaluateField.response")}
              />
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                checked={
                  props?.initialValueReceive &&
                  props?.initialValueReceive?.evaluateApprovalDepartment > 0 &&
                  props?.initialValueReceive?.evaluateTotalDepartment > 0
                    ? true
                    : false
                }
                disabled={true}
                label={`${t("LEGISLATION.evaluateField.evaluate")} ${
                  props?.initialValueReceive &&
                  props.initialValueReceive.evaluateTotalDepartment > 0
                    ? `(${
                        props.initialValueReceive.evaluateApprovalDepartment ??
                        "0"
                      }/${props.initialValueReceive.evaluateTotalDepartment})`
                    : ""
                }`}
              />
            </Box>
          </Grid>
        </Grid>
        <Grid item container direction="row" spacing={2}>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                checked={
                  props?.initialValueReceive &&
                  props?.initialValueReceive?.evaluateApproval > 0 &&
                  props?.initialValueReceive?.evaluateTotal > 0
                    ? true
                    : false
                }
                disabled={true}
                label={`${t("LEGISLATION.evaluateField.evaluateApproval")} ${
                  props?.initialValueReceive &&
                  props?.initialValueReceive?.evaluateTotal > 0
                    ? ` (${props?.initialValueReceive?.evaluateApproval}/${props.initialValueReceive?.evaluateTotal})`
                    : ""
                }`}
              />
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                checked={
                  props?.initialValueReceive &&
                  props?.initialValueReceive?.nextActionTotal > 0
                    ? true
                    : false
                }
                disabled={true}
                label={`${t("LEGISLATION.evaluateField.nextAction")} ${
                  props?.initialValueReceive &&
                  props?.initialValueReceive?.nextActionTotal > 0
                    ? ` (${props.initialValueReceive?.nextActionTotal})`
                    : ""
                }`}
              />
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                checked={
                  props?.initialValueReceive &&
                  props?.initialValueReceive?.nextActionApproval > 0 &&
                  props?.initialValueReceive?.nextActionTotal > 0
                    ? true
                    : false
                }
                disabled={true}
                label={`${t("LEGISLATION.evaluateField.nextActionApproval")} ${
                  props?.initialValueReceive &&
                  props?.initialValueReceive?.nextActionTotal > 0
                    ? ` (${
                        props?.initialValueReceive?.nextActionApproval ?? "0"
                      }/${props.initialValueReceive?.nextActionTotal})`
                    : ""
                }`}
              />
            </Box>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default EvaluateInformation;
