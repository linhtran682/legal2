import { getStatus } from "@/apis/service/status/Status";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserStatusKey,
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { SaveLawDocumentRequestFieldNames } from "@/models/law_document/LawDocument";
import { Grid } from "@mui/material";
import { useEffect, useState } from "react";
import { useFormContext } from "react-hook-form";
import { useTranslation } from "react-i18next";

interface StatusFormConditionProps {
  meCanWrite: boolean;
  statusId: number;
  formMode?: "create" | "update";
  ownRole: number[];
}
const StatusFormCondition = (props: StatusFormConditionProps) => {
  const { meCanWrite, statusId, ownRole } = props;
  const [statusName, setStatusName] = useState<string>();
  const formContext = useFormContext();
  const [t] = useTranslation();

  useEffect(() => {
    if (!statusId) return;
    getStatus(Number(statusId)).then((value) => setStatusName(value?.name));
  }, [statusId]);

  return (
    <Grid
      container
      rowSpacing={1}
      columnSpacing={{ xs: 1, sm: 2, md: 3 }}
      sx={formInputSxProps}
    >
      <Grid item xs={6}>
        <DateInput
          name={SaveLawDocumentRequestFieldNames.RECEIVE_FROM_VENDOR_DATE}
          control={formContext.control}
          label={t(
            `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.RECEIVE_FROM_VENDOR_DATE}`
          )}
          placeholder={"dd/mm/yyyy"}
          required
          disabled={
            !meCanWrite || (props.formMode === "update" && !ownRole.includes(1))
          }
        />
      </Grid>
      <Grid item xs={6}>
        <DateInput
          name={SaveLawDocumentRequestFieldNames.VENDOR_RESPONSE_DATE}
          control={formContext.control}
          label={t(
            `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.VENDOR_RESPONSE_DATE}`
          )}
          placeholder={"dd/mm/yyyy"}
          required
          disabled={
            statusName !==
              LegalDocumentStatusContent.get(
                LegalDocumentUserStatusKey.VENDOR
              ) ||
            !meCanWrite ||
            (props.formMode === "update" && !ownRole.includes(1))
          }
        />
      </Grid>

      <Grid item xs={6}>
        <DateInput
          name={SaveLawDocumentRequestFieldNames.SUBMMISSION_DEADLINE}
          control={formContext.control}
          label={t(
            `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.SUBMMISSION_DEADLINE}`
          )}
          placeholder={"dd/mm/yyyy"}
          required
          disabled={
            statusName !==
              LegalDocumentStatusContent.get(LegalDocumentUserStatusKey.SENT) ||
            !meCanWrite ||
            (props.formMode === "update" && !ownRole.includes(1))
          }
        />
      </Grid>

      <Grid item xs={6}>
        <DateInput
          name={SaveLawDocumentRequestFieldNames.DEPARTMENT_RESPONSE_DATE}
          control={formContext.control}
          label={t(
            `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DEPARTMENT_RESPONSE_DATE}`
          )}
          placeholder={"dd/mm/yyyy"}
          required
          disabled={
            statusName !==
              LegalDocumentStatusContent.get(
                LegalDocumentUserStatusKey.REQUEST_REVIEW
              ) ||
            !meCanWrite ||
            (props.formMode === "update" && !ownRole.includes(1))
          }
        />
      </Grid>
    </Grid>
  );
};

export default StatusFormCondition;
