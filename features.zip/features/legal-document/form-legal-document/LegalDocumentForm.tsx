import {
  getDocumentType,
  getDocumentTypes,
} from "@/apis/service/document_type/DocumentType";
import { getField, getFields } from "@/apis/service/field/Field";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { DocumentTypeDTO } from "@/models/document_type/DocumentType";
import { FieldDTO } from "@/models/field/Field";

import {
  getAgencyIssued,
  getAgencyIssueds,
} from "@/apis/service/agency_issued/AgencyIssued";
import {
  getDepartments,
  getLegalDepartments,
} from "@/apis/service/department/department";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { getHelpList } from "@/apis/service/help/Help";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserRole,
  LegalDocumentUserRoleKey,
  LegalDocumentUserStatusKey,
  LegalTimeUnit,
  ModuleFields,
  ModuleFieldsPaths,
  TimeUnitKeys,
} from "@/constants/general";
import { AppContext } from "@/context/AppContext";
import { HelpTableConst } from "@/features/help/help_table/HelperTable";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import {
  AgencyIssuedDTO,
  AgencyIssuedFieldNames,
} from "@/models/agency_issued/AgencyIssued";
import {
  castDepartmentToSchema,
  Department,
} from "@/models/department/Department";
import { SaveHelpRequestSchemaI } from "@/models/help/Help";
import {
  FileInfo,
  LawDocumentBodyReceive,
  LawDocumentBodySend,
  SaveLawDocumentRequestFieldNames,
  SaveLawDocumentRequestSchema,
  TypeActionsRole,
} from "@/models/law_document/LawDocument";
import {
  castReminderInputToReminderSchema,
  castReminderSchemaToSaveReminderDTO,
} from "@/models/reminder_template/ReminderDTO";
import { ReminderTemplateContentFieldNames } from "@/models/reminder_template/ReminderTemplateDTO";
import { StatusFieldNames } from "@/models/status/Status";
import { UserProfileDTO } from "@/models/user/User";
import { cookieSetting } from "@/utils";
import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Divider, Grid } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { isAfter, isValid, startOfDay } from "date-fns";
import {
  ReactNode,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import StatusFormCondition from "./StatusFormCondition";
import { getAssignedPerson } from "@/apis/service/assignment/Assignment";
import { DONE_STATUS } from "@/models/document-review/DocumentReviewDetail";
// import { toast } from "react-toastify";

export interface SaveDocumentTypeFormProps {
  formMode?: "create" | "update";
  initialValue?: LawDocumentBodyReceive;
  onSubmit: (data: LawDocumentBodySend) => void;
  onSubmitDraft?: (data: LawDocumentBodySend) => void;
  onCancel: () => void;
  loading?: boolean;
  initialValueReceive?: LawDocumentBodyReceive;
  children?: ReactNode;
  setFileSharePoint?: (arr: any) => void;
}

const initialEmptyValue: LawDocumentBodySend = {
  textNumber: "",
  attachments: [],
  receiveFromVendorDate: undefined,
  vendorResponseDate: undefined,
  submissionDeadline: undefined,
  departmentResponseDate: undefined,
  publishDate: undefined,
  effectiveDate: undefined,
  content: "",
  users: [],
  remind: undefined,
  extendDateAllowDeadlineNumberType: LegalTimeUnit.get(TimeUnitKeys.DAY),
};

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}
export const LegalDocumentForm = (props: SaveDocumentTypeFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);
  const [selectionId, setSelectionId] = useState<number | undefined>(undefined);

  const [departmentList, setDepartmentList] = useState<Department[]>([]);
  // const [keyword, setKeyword] = useState<string>("");
  const [listFileSharepoint, setListFileSharepoint] = useState<any>([]);
  const accessToken = cookieSetting.get("ACCESS_TOKEN");
  const isStatusDone = props?.initialValueReceive?.status?.name === DONE_STATUS;

  const getAssignedPersonQuery = useQuery({
    queryKey: ["legal-document/get-legal-assigned-person"],
    queryFn: () => getAssignedPerson(),
    placeholderData: (prev) => prev,
    enabled: false,
  });
  const getLegalDepartmentQuery = useQuery({
    queryKey: ["legal-document/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        // setDepartmentId(deepestId?.id ?? '')
        return deepestId?.id ?? null;
      } catch (error) { }
      return null;
    },
    placeholderData: (prev) => prev,
  });
  const form = useForm<any>({
    resolver: yupResolver(SaveLawDocumentRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    disabled:
      !appContext.meCanWrite ||
      (props.formMode === "update" &&
        !ownRole.includes(
          LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC) as number
        ) &&
        !ownRole.includes(
          LegalDocumentUserRole.get(
            LegalDocumentUserRoleKey.PERSON_CHARGE
          ) as number
        )) || isStatusDone,
  });
  const getHelpListQuery = useQuery({
    queryKey: [HelpTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () =>
      getHelpList({
        page: 0,
        size: 999,
        sortBy: "id",
        orderBy: "DESC",
        modules: [1],
      }),
  });

  const querySearchStatus = useSearchStatus({
    keyword: LegalDocumentStatusContent.get(LegalDocumentUserStatusKey.SENT)!,
    queryKey: "LEGAL_DOCUMENT_FORM",
  });

  const publishDate = form.watch("publishDate");
  const effectiveDate = form.watch("effectiveDate");
  useEffect(() => {
    if (
      isValid(new Date(publishDate)) &&
      isValid(new Date(effectiveDate)) &&
      isAfter(
        startOfDay(new Date(publishDate)),
        startOfDay(new Date(effectiveDate))
      )
    ) {
      form.setError("publishDate", {
        message: t("LEGISLATION.message.publishDateError"),
      });
    }
    if (
      isValid(new Date(publishDate)) &&
      isValid(new Date(effectiveDate)) &&
      !isAfter(
        startOfDay(new Date(publishDate)),
        startOfDay(new Date(effectiveDate))
      )
    ) {
      form.clearErrors("publishDate");
    }
  }, [publishDate, effectiveDate]);

  // const { data: users = [], refetch } = useQuery({
  //   queryKey: ["get_users", departmentList, keyword],
  //   queryFn: async () => {
  //     if (!departmentList.length) return [];

  //     const response = await getUsers({
  //       searchTerm: keyword,
  //       page: 0,
  //       size: 100,
  //       sortBy: "name",
  //       sortOrder: "ASC",
  //       departmentIds: departmentList.map((el) => el.id),
  //     });

  //     return (response?.users ?? []).map((user) => ({
  //       id: user.id,
  //       name: user.name ?? "",
  //       departmentName: user.department?.name ?? "",
  //       email: user.email ?? "",
  //     })) as BasedUser[];
  //   },
  //   enabled: departmentList.length > 0,
  // });

  useEffect(() => {
    if (querySearchStatus?.data?.[0]?.id && props.formMode === "create") {
      form.reset({
        status: querySearchStatus?.data?.[0]?.id,
      });
    }
  }, [querySearchStatus?.data?.[0]?.id, props.formMode]);

  // useEffect(() => {
  //   if (departmentList.length) {
  //     refetch();
  //   }
  //   getHelpListQuery.refetch();
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [departmentList]);

  // const getOptions = useMemo(
  //   () => async (searchKeyword: string) => {
  //     setKeyword(searchKeyword);
  //     await refetch();
  //     return users || [];
  //   },
  //   [users, refetch]
  // );
  useEffect(() => {
    if (props.initialValueReceive) {
      const attachments: any[] = [];
      const listFileSharepoint: any[] = [];
      if (
        props?.initialValueReceive?.attachmentsSharepoint &&
        props?.initialValueReceive?.attachmentsSharepoint.length > 0
      ) {
        props?.initialValueReceive?.attachmentsSharepoint.map((e) => {
          attachments.push({
            id: e.id,
            name: e.fileName,
            uploadDate: e.uploadDate,
            accessLink: e.accessLink,
            isEvaluateFile: e.isEvaluateFile,
          });
          listFileSharepoint.push({
            id: e.id,
            name: e.fileName,
            isEvaluateFile: e.isEvaluateFile,
          });
          if (e.isEvaluateFile) {
            setSelectionId(e.id);
          }
        });
        setListFileSharepoint([...listFileSharepoint]);
      }
      if (props?.initialValueReceive?.attachments) {
        if (props?.initialValueReceive?.attachments.length) {
          props.initialValueReceive.attachments?.map((item) => {
            attachments.push({
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
              isEvaluateFile: false,
            });
          });
        }

        setFiles([...attachments]);
      }
      const files =
        !appContext.meCanWrite ||
          (props.formMode === "update" &&
            !ownRole.includes(
              LegalDocumentUserRole.get(LegalDocumentUserRoleKey.PIC_LC) as number
            ) &&
            !ownRole.includes(
              LegalDocumentUserRole.get(
                LegalDocumentUserRoleKey.PERSON_CHARGE
              ) as number
            ))
          ? props.initialValueReceive?.attachments
          : props.initialValueReceive?.attachments?.length
            ? props.initialValueReceive?.attachments
            : null;
      props.initialValueReceive &&
        form.reset({
          ...props.initialValueReceive,
          files,
          field: props.initialValueReceive?.field?.id,
          status: props.initialValueReceive?.status?.id,
          documentType: props.initialValueReceive?.documentType?.id,
          agencyIssued: props.initialValueReceive?.agencyIssued?.id,
          departments: props.initialValueReceive.departments,
          users: props?.initialValueReceive?.users,
          attachments: props?.initialValueReceive?.attachments?.map(
            (ele: any) => ele?.fileId
          ),
          remind: props.initialValueReceive.remind
            ? castReminderInputToReminderSchema(
              props.initialValueReceive!.remind!
            )
            : undefined,
          legalDocumentDraftId:
            props?.initialValueReceive?.legalDocumentDraftId,
          isBookMeeting: props?.initialValueReceive?.isBookMeeting,
        });
    }
    if (
      props.initialValueReceive &&
      props.initialValueReceive?.legalDocumentActions
    ) {
      setOwnRole(
        (props.initialValueReceive?.legalDocumentActions?.map(
          (legalDocumentActionItem: TypeActionsRole) =>
            legalDocumentActionItem?.ownerRole
        ) as number[]) || []
      );
      setDepartmentList(
        props?.initialValueReceive?.departmentsResponsible || []
      );
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValueReceive]);
  const getExplanation = (fieldName: string) => {
    const helpList = ConvertDataCodetoNameHelp(
      fieldName,
      getHelpListQuery.data?.fieldResponses
    );

    return helpList.length > 0 && helpList[0].active === 1
      ? helpList[0].description
      : "";
  };
  const statusId = form.watch("status");
  return (
    <>
      {/* {props.formMode === "update" && (
        <EvaluateInformation
          isMeeting={
            form.watch("isBookMeeting") &&
            form.watch("isBookMeeting") !== null &&
            form.watch("isBookMeeting")
          }
          initialValueReceive={props.initialValueReceive}
          onChangeMeeting={(value: boolean) =>
            form.setValue("isBookMeeting", value)
          }
          disabled={
            !appContext.meCanWrite ||
            (props.formMode === "update" &&
              !ownRole.includes(
                LegalDocumentUserRole.get(
                  LegalDocumentUserRoleKey.PIC_LC
                ) as number
              ) &&
              !ownRole.includes(
                LegalDocumentUserRole.get(
                  LegalDocumentUserRoleKey.PERSON_CHARGE
                ) as number
              ) &&
              !ownRole.includes(
                LegalDocumentUserRole.get(
                  LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT
                ) as number
              ))
          }
        />
      )} */}
      <Grid
        container
        className="form-wrapper"
        style={{
          // marginTop: props.formMode === "update" ? 10 : 0,
          minWidth: "100%",
        }}
      >
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  explanation={getExplanation(
                    SaveLawDocumentRequestFieldNames.DOCUMENT_TYPE
                  )}
                  name={SaveLawDocumentRequestFieldNames.DOCUMENT_TYPE}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DOCUMENT_TYPE}`
                  )}
                  placeholder={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DOCUMENT_TYPE}`
                  )}
                  keyQuery={"document-type-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getDocumentTypes({
                        name: keyword,
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                      });
                      return response?.documentTypes ?? [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getDocumentType(Number(keyword[0]))
                          .then((value) => (value ? [value] : []))
                          .catch(() => []);
                      }
                    }

                    return [] as DocumentTypeDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      ))
                  }
                  isFocus
                />
              </Grid>
              {!appContext.meCanWrite ||
                (props.formMode === "update" &&
                  !ownRole.includes(
                    LegalDocumentUserRole.get(
                      LegalDocumentUserRoleKey.PIC_LC
                    ) as number
                  ) &&
                  !ownRole.includes(
                    LegalDocumentUserRole.get(
                      LegalDocumentUserRoleKey.PERSON_CHARGE
                    ) as number
                  )) ? null : (
                <Grid item width={"100%"}>
                  <FormTextField
                    control={form.control}
                    explanation={getExplanation(
                      SaveLawDocumentRequestFieldNames.DOCUMENT_NAME
                    )}
                    name={SaveLawDocumentRequestFieldNames.DOCUMENT_NAME}
                    label={t(
                      `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DOCUMENT_NAME}`
                    )}
                    placeHolder={t(
                      `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DOCUMENT_NAME}`
                    )}
                    required
                    disabled={
                      !appContext.meCanWrite ||
                      (props.formMode === "update" &&
                        !ownRole.includes(
                          LegalDocumentUserRole.get(
                            LegalDocumentUserRoleKey.PIC_LC
                          ) as number
                        ) &&
                        !ownRole.includes(
                          LegalDocumentUserRole.get(
                            LegalDocumentUserRoleKey.PERSON_CHARGE
                          ) as number
                        ))
                    }
                  />
                </Grid>
              )}
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={SaveLawDocumentRequestFieldNames.CONTENT}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.CONTENT}`
                  )}
                  minRows={3}
                  required
                  explanation={getExplanation(
                    SaveLawDocumentRequestFieldNames.CONTENT
                  )}
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={props.formMode === "create"}
                  preview={props.formMode === "update"}
                  name={SaveLawDocumentRequestFieldNames.FILES}
                  control={form.control}
                  title={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.FILES}`
                  )}
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      )) || isStatusDone
                  }
                  files={files}
                  preventOnchange
                  setFiles={(files) => {
                    setFiles(files);
                    form.setValue(SaveLawDocumentRequestFieldNames.FILES, files ?? []);
                    form.trigger(SaveLawDocumentRequestFieldNames.FILES)
                  }}
                  selectionId={selectionId}
                  setSelectedId={setSelectionId}
                  hasRadio={true}
                  disableRadio={!accessToken}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  explanation={getExplanation(
                    SaveLawDocumentRequestFieldNames.AGENCY_ISSUED
                  )}
                  control={form.control}
                  name={SaveLawDocumentRequestFieldNames.AGENCY_ISSUED}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.AGENCY_ISSUED}`
                  )}
                  placeholder={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.AGENCY_ISSUED}`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"agency-issued-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getAgencyIssueds({
                        name: keyword,
                        page: 0,
                        size: 100,
                        sortBy: AgencyIssuedFieldNames.NAME,
                        orderBy: "ASC",
                      });

                      return response?.agencyIssuedResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getAgencyIssued(Number(keyword[0])).then(
                          (value) => (value ? [value] : [])
                        );
                      }
                    }

                    return [] as AgencyIssuedDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      ))
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  explanation={getExplanation(
                    SaveLawDocumentRequestFieldNames.TEXT_NUMBER
                  )}
                  name={SaveLawDocumentRequestFieldNames.TEXT_NUMBER}
                  control={form.control}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.TEXT_NUMBER}`
                  )}
                  placeHolder={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.TEXT_NUMBER}`
                  )}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      ))
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  explanation={getExplanation(
                    SaveLawDocumentRequestFieldNames.FIELD
                  )}
                  control={form.control}
                  name={SaveLawDocumentRequestFieldNames.FIELD}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.FIELD}`
                  )}
                  placeholder={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.FIELD}`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"field-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getFields({
                        name: keyword,
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                      });

                      return response?.fieldResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getField(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as FieldDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      ))
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <Divider />
              </Grid>
              {/* <Grid item width={"100%"}>
                <FormSelectButton
                  explanation={getExplanation(
                    SaveLawDocumentRequestFieldNames.STATUS
                  )}
                  control={form.control}
                  name={SaveLawDocumentRequestFieldNames.STATUS}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.STATUS}`
                  )}
                  keyQuery={"status-query-legal-document"}
                  getOptions={async (keyword) => {
                    if (
                      typeof keyword == "string" &&
                      props.formMode === "update"
                    ) {
                      if (
                        props?.initialValueReceive?.status?.name ===
                        LegalDocumentStatusContent.get(
                          LegalDocumentUserStatusKey.DONE
                        )
                      ) {
                        const response = await getStatusListNames({
                          names: [
                            LegalDocumentStatusContent.get(
                              LegalDocumentUserStatusKey.ASSIGNMENT
                            )!,
                            LegalDocumentStatusContent.get(
                              LegalDocumentUserStatusKey.VENDOR
                            )!,
                            LegalDocumentStatusContent.get(
                              LegalDocumentUserStatusKey.SENT
                            )!,
                            LegalDocumentStatusContent.get(
                              LegalDocumentUserStatusKey.DONE
                            )!,
                            keyword,
                          ],
                          modules: [ModuleFields.LEGISLATION_NAME.module],
                        });
                        return response?.statusResponses || [];
                      }
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else if (
                      typeof keyword == "string" &&
                      props.formMode === "create"
                    ) {
                      const response = await getStatusListNames({
                        names: [
                          LegalDocumentStatusContent.get(
                            LegalDocumentUserStatusKey.ASSIGNMENT
                          )!,
                          LegalDocumentStatusContent.get(
                            LegalDocumentUserStatusKey.VENDOR
                          )!,
                          LegalDocumentStatusContent.get(
                            LegalDocumentUserStatusKey.SENT
                          )!,
                          keyword,
                        ],
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                      });
                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option?.id.toString()}
                  getOptionLabel={(option) => option?.name}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      ))
                    || isStatusDone
                  }
                />
              </Grid> */}
              <StatusFormCondition
                meCanWrite={appContext.meCanWrite}
                statusId={statusId}
                formMode={props.formMode}
                ownRole={ownRole}
              />
              <Grid item width={"100%"}>
                <Divider />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={6}>
                  <DateInput
                    explanation={getExplanation(
                      SaveLawDocumentRequestFieldNames.PUBLISH_DATE
                    )}
                    name={SaveLawDocumentRequestFieldNames.PUBLISH_DATE}
                    control={form.control}
                    label={t(
                      `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.PUBLISH_DATE}`
                    )}
                    placeholder={"dd/mm/yyyy"}
                    required
                    disabled={
                      !appContext.meCanWrite ||
                      (props.formMode === "update" &&
                        !ownRole.includes(
                          LegalDocumentUserRole.get(
                            LegalDocumentUserRoleKey.PIC_LC
                          ) as number
                        ) &&
                        !ownRole.includes(
                          LegalDocumentUserRole.get(
                            LegalDocumentUserRoleKey.PERSON_CHARGE
                          ) as number
                        ))
                    }
                    maxDate={form.watch(
                      SaveLawDocumentRequestFieldNames.EFFECTIVE_DATE
                    )}
                  />
                </Grid>
                <Grid item xs={6}>
                  <DateInput
                    explanation={getExplanation(
                      SaveLawDocumentRequestFieldNames.EFFECTIVE_DATE
                    )}
                    name={SaveLawDocumentRequestFieldNames.EFFECTIVE_DATE}
                    control={form.control}
                    label={t(
                      `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.EFFECTIVE_DATE}`
                    )}
                    placeholder={"dd/mm/yyyy"}
                    required
                    disabled={
                      !appContext.meCanWrite ||
                      (props.formMode === "update" &&
                        !ownRole.includes(
                          LegalDocumentUserRole.get(
                            LegalDocumentUserRoleKey.PIC_LC
                          ) as number
                        ) &&
                        !ownRole.includes(
                          LegalDocumentUserRole.get(
                            LegalDocumentUserRoleKey.PERSON_CHARGE
                          ) as number
                        ))
                    }
                    minDate={form.watch(
                      SaveLawDocumentRequestFieldNames.PUBLISH_DATE
                    )}
                  />
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <FormSelectTreeView
                  explanation={getExplanation(
                    SaveLawDocumentRequestFieldNames.DEPARTMENT
                  )}
                  name={SaveLawDocumentRequestFieldNames.DEPARTMENT}
                  control={form.control}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DEPARTMENT}`
                  )}
                  placeholder={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DEPARTMENT}`
                  )}
                  getOptions={async (keyword) => {
                    try {
                      const response = await getDepartments({
                        searchTerm: keyword,
                      });
                      const first100Departments: Department[] = (
                        response?.departments ?? []
                      ).slice(0, 150);
                      return first100Departments;
                    } catch (e) {
                      return [];
                    }
                  }}
                  getOptionLabel={(option) => option.name ?? ""}
                  getOptionKey={(option) => option.id ?? ""}
                  getOptionChildren={(option) => option.children}
                  variant="outlined"
                  debounceMs={FILTER_DEBOUNCE_MS}
                  onChange={(value: Department[]) => {
                    form.setValue(
                      "departments",
                      (value ?? []).map((department) =>
                        castDepartmentToSchema(department)
                      )
                    );
                  }}
                  rules={{ required: "This field is required" }}
                  selectedItemsProp={
                    props.initialValueReceive
                      ? props.initialValueReceive?.departments
                      : undefined
                  }
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      )) || isStatusDone
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                {/* <Box flex={1} mr={2} width={"50%"}>
                    <FormSelectTreeView
                      explanation={getExplanation(
                        SaveLawDocumentRequestFieldNames.PERSON_RESPONSIBLE
                      )}
                      name={
                        SaveLawDocumentRequestFieldNames.DEPARTMENTS_RESPONSIBLE
                      }
                      control={form.control}
                      label={t(
                        `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.PERSON_RESPONSIBLE}`
                      )}
                      getOptions={async (keyword) => {
                        try {
                          const response = await getDepartments({
                            searchTerm: keyword,
                          });
                          const first100Departments: Department[] = (
                            response?.departments ?? []
                          ).slice(0, 150);
                          return first100Departments;
                        } catch (e) {
                          return [];
                        }
                      }}
                      getOptionLabel={(option) => option.name ?? ""}
                      getOptionKey={(option) => option.id ?? ""}
                      getOptionChildren={(option) => option.children}
                      variant="outlined"
                      debounceMs={FILTER_DEBOUNCE_MS}
                      onChange={(value: Department[]) => {
                        const mappedValue: string[] = value.map(
                          (item) => item.id ?? ""
                        );
                        form.setValue(
                          SaveLawDocumentRequestFieldNames.DEPARTMENTS_RESPONSIBLE,
                          mappedValue
                        );
                        form.trigger(
                          SaveLawDocumentRequestFieldNames.DEPARTMENTS_RESPONSIBLE
                        );
                        setDepartmentList(
                          (value ?? []).map((department) =>
                            castDepartmentToSchema(department)
                          )
                        );
                        const departmentNames = value.map((item) => item.name);
                        if (
                          form.getValues("users") &&
                          form.getValues("users")?.length > 0
                        ) {
                          const filteredUsers = form
                            .getValues("users")
                            .filter((user: any) =>
                              departmentNames?.includes(user.departmentName)
                            );
                          form.setValue("users", filteredUsers);
                        }
                      }}
                      rules={{ required: "This field is required" }}
                      selectedItemsProp={
                        props.initialValueReceive
                          ? props.initialValueReceive?.departmentsResponsible
                          : undefined
                      }
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (props.formMode === "update" &&
                          !ownRole.includes(
                            LegalDocumentUserRole.get(
                              LegalDocumentUserRoleKey.PIC_LC
                            ) as number
                          ) &&
                          !ownRole.includes(
                            LegalDocumentUserRole.get(
                              LegalDocumentUserRoleKey.PERSON_CHARGE
                            ) as number
                          ))
                      }
                    />
                  </Box> */}
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={`${SaveLawDocumentRequestFieldNames.USER}`}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.PERSON_RESPONSIBLE}`
                  )}
                  placeholder={t(`common.place_holder.enter_value`, {
                    fieldName: t(
                      `LEGISLATION.field_name.employeeName`
                    ),
                  })}
                  getOptions={async (keyword) => {
                    if (!getLegalDepartmentQuery.data) return [];
                    const advisorIds =
                      getAssignedPersonQuery?.data?.users?.map(
                        (user) => user.id
                      ) ?? [];
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                      departmentIds: getLegalDepartmentQuery.data
                        ? [getLegalDepartmentQuery.data]
                        : [],
                    });
                    return (
                      response?.users
                        ?.map((user, index) => ({
                          ...user,
                          rank: advisorIds?.includes(user.id)
                            ? index
                            : 99999,
                        }))
                        ?.sort(
                          (first, second) => first.rank - second.rank
                        ) ?? []
                    );
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryUser"
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PIC_LC
                        ) as number
                      ) &&
                      !ownRole.includes(
                        LegalDocumentUserRole.get(
                          LegalDocumentUserRoleKey.PERSON_CHARGE
                        ) as number
                      ))
                  }
                  isFocus
                  required
                />
              </Grid>
              <Grid item width="100%">
                <Box
                  width="49%"
                  display={"flex"}
                  flexDirection={"row"}
                  justifyContent={"flex-start"}
                  alignItems={
                    form.formState.errors?.[
                      SaveLawDocumentRequestFieldNames.EXTENDDATEALLOWDEADLINE
                    ]
                      ? "center"
                      : "flex-end"
                  }
                  gap={2}
                >
                  <Box flex={1} mr={2}>
                    <FormTextField
                      explanation={getExplanation(
                        SaveLawDocumentRequestFieldNames.EXTENDDATEALLOWDEADLINE
                      )}
                      control={form.control}
                      name={
                        SaveLawDocumentRequestFieldNames.EXTENDDATEALLOWDEADLINE
                      }
                      label={t(
                        `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.EXTENDDATEALLOWDEADLINE}`
                      )}
                      placeHolder={t(`LEGISLATION.field_name.extendDeadline`)}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (props.formMode === "update" &&
                          !ownRole.includes(
                            LegalDocumentUserRole.get(
                              LegalDocumentUserRoleKey.PIC_LC
                            ) as number
                          ) &&
                          !ownRole.includes(
                            LegalDocumentUserRole.get(
                              LegalDocumentUserRoleKey.PERSON_CHARGE
                            ) as number
                          ))
                      }
                    />
                  </Box>
                  <Box flex={1}>
                    <FormSelect
                      control={form.control}
                      name={
                        SaveLawDocumentRequestFieldNames.EXTENDDATEALLOWDEADLINENUMBERTYPE
                      }
                      options={Array.from(LegalTimeUnit.keys()).map((key) => ({
                        label: t(
                          `common.option.${ReminderTemplateContentFieldNames.TIME_TYPE}.${key}`
                        ),
                        value: LegalTimeUnit.get(key)!,
                      }))}
                      getOptionKey={(option) => option.value}
                      getOptionLabel={(option) => option.label}
                      disabled={
                        !appContext.meCanWrite ||
                        (props.formMode === "update" &&
                          !ownRole.includes(
                            LegalDocumentUserRole.get(
                              LegalDocumentUserRoleKey.PIC_LC
                            ) as number
                          ) &&
                          !ownRole.includes(
                            LegalDocumentUserRole.get(
                              LegalDocumentUserRoleKey.PERSON_CHARGE
                            ) as number
                          ))
                      }
                    />
                  </Box>
                </Box>
              </Grid>
            </Grid>
            {props.children}
            <ReminderPickerSubForm
              name={SaveLawDocumentRequestFieldNames.REMIND}
              module={ModuleFields.LEGISLATION_NAME.module}
              placeholder={t(`menu.reminder`)}
            />
            <FormActionButtons
              formMode={props.formMode}
              loading={props.loading}
              onCancel={props.onCancel}
              isDisableButonSave={
                !appContext.meCanWrite ||
                (props.formMode === "update" &&
                  !ownRole.includes(
                    LegalDocumentUserRole.get(
                      LegalDocumentUserRoleKey.PIC_LC
                    ) as number
                  ) &&
                  !ownRole.includes(
                    LegalDocumentUserRole.get(
                      LegalDocumentUserRoleKey.PERSON_CHARGE
                    ) as number
                  ))
                || isStatusDone
              }
              allowDraft={
                props.formMode === "create" ||
                props?.initialValueReceive?.isDraft
              }
              onSaveDraft={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    // const filterFile: any = [];
                    const filterFileId: number[] = files
                      ?.filter((item: any) => item.id !== selectionId)
                      ?.map((item: any) => item.id);
                    // files.filter((item: any) => {
                    //   if (item?.id === undefined) {
                    //     filterFile.push(item);
                    //   } else {
                    //     filterFileId.push(item?.id);
                    //   }
                    // });
                    attachments = [...filterFileId];
                    const filterSharepointFiles = files.filter(
                      (item: any) => item.id === selectionId
                    );
                    props?.setFileSharePoint?.(filterSharepointFiles);
                  }

                  props?.onSubmitDraft &&
                    props.onSubmitDraft({
                      ...form.getValues(),
                      attachments: attachments,
                      remind: form.getValues("remind")
                        ? castReminderSchemaToSaveReminderDTO(
                          form.getValues("remind")!
                        )
                        : undefined,
                      users: form.getValues("users").map((ite: any) => ite.id),
                      departments:
                        form.getValues("departments") &&
                        form.getValues("departments")?.map((el: any) => el.id),
                      departmentsResponsible:
                        departmentList?.map((el: any) => el.id) ?? [],
                    });
                } catch (error) { }
              }}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  let restOfFileSharepoint: any = [];
                  if (files.length > 0 && props.formMode === "create") {
                    // const filterFile: any = [];
                    const filterFileId: number[] = files
                      ?.filter((item: any) => item.id !== selectionId)
                      ?.map((item: any) => item.id);
                    // files.filter((item: any) => {
                    //   if (item?.id === undefined) {
                    //     filterFile.push(item);
                    //   } else {
                    //     filterFileId.push(item?.id);
                    //   }
                    // });
                    attachments = [...filterFileId];
                    const filterSharepointFiles = files.filter(
                      (item: any) => item.id === selectionId
                    );
                    props?.setFileSharePoint?.(filterSharepointFiles);
                  } else if (files.length > 0 && props.formMode === "update") {
                    // const filterFile: any = [];
                    let filterFileId: number[] = [];
                    const listFileFilterDetail: any = [];
                    const arrSaveFileSharepoint: any = [];

                    files.forEach((item: any) => {
                      // if (
                      //   item?.id === undefined &&
                      //   item?.isEvaluateFile === undefined
                      // ) {
                      //   filterFile.push(item);
                      // } else
                      if (
                        (item?.id && item?.isEvaluateFile === false) ||
                        item?.isEvaluateFile === undefined
                      ) {
                        filterFileId.push(item?.id);
                        listFileFilterDetail.push(item);
                      }

                      if (item?.id && listFileSharepoint.length > 0) {
                        listFileSharepoint.map((file: any) => {
                          if (file.id === item.id) {
                            arrSaveFileSharepoint.push({
                              ...file,
                              id: file.id,
                              isEvaluateFile:
                                file.id === selectionId ? true : false,
                            });
                          }
                        });
                      }
                    });
                    if (arrSaveFileSharepoint.length > 0) {
                      // restOfFileSharepoint.push({
                      //   id: checkFile.id,
                      //   isEvaluateFile:
                      //     checkFile.id === selectionId ? true : false,
                      // });
                      restOfFileSharepoint = [...arrSaveFileSharepoint];
                    }
                    let filterNameFindFromDetail: any[] = [];
                    if (selectionId) {
                      filterNameFindFromDetail = listFileFilterDetail.filter(
                        (item: any) => item.id === selectionId
                      );

                      if (
                        filterNameFindFromDetail.length > 0 &&
                        props.setFileSharePoint
                      ) {
                        props.setFileSharePoint(filterNameFindFromDetail);
                      }

                      if (filterNameFindFromDetail.length > 0) {
                        filterFileId = filterFileId.filter(
                          (e) => e !== filterNameFindFromDetail[0].id
                        );
                      }
                    }
                    attachments = [...filterFileId];
                  }
                  // }

                  props.onSubmit({
                    ...form.getValues(),
                    attachments: attachments,
                    attachmentsSharepoint:
                      restOfFileSharepoint?.length > 0
                        ? restOfFileSharepoint
                        : [],
                    remind:
                      form.getValues("remind") !== undefined
                        ? castReminderSchemaToSaveReminderDTO(
                          form.getValues("remind")!
                        )
                        : undefined,

                    users: form.getValues("users").map((ite: any) => ite.id),
                    departments:
                      form.getValues("departments") &&
                      form.getValues("departments")?.map((el: any) => el.id),
                    departmentsResponsible:
                      departmentList?.map((el: any) => el.id) ?? [],
                  });
                } catch (error) {
                  // toast.error(JSON.stringify(error))
                }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </>
  );
};

export async function processFileAttachments(files: any[]): Promise<number[]> {
  let attachments: number[] = [];

  if (files.length > 0) {
    const filterFile: any[] = [];
    const filterFileId: number[] = [];

    files.forEach((item) => {
      if (item?.id === undefined) {
        filterFile.push(item);
      } else {
        filterFileId.push(item?.id);
      }
    });

    if (filterFile.length > 0) {
      const response = await GetListIdFile(filterFile);
      const formatResponse: number[] = response.fileUploadResponses.map(
        (item: FileInfo) => item.fileId
      );
      attachments = [...formatResponse, ...filterFileId];
    } else {
      attachments = [...filterFileId];
    }
  }

  return attachments;
}

export const ConvertDataCodetoNameHelp = (
  name: string,
  list?: Array<SaveHelpRequestSchemaI>
) => {
  const itemCheck: SaveHelpRequestSchemaI[] = [];

  list &&
    list?.length > 0 &&
    list.map((item) => {
      if (ModuleFieldsPaths[item.helpName].split(".")[2] == name) {
        itemCheck.push({
          ...item,
          helpName: ModuleFieldsPaths[item.helpName],
        });
      }
    });

  return itemCheck;
};
