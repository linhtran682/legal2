import { getDepartments } from "@/apis/service/department/department";
import { requestEvaluateMultiple, requestReviewLegalDocument } from "@/apis/service/law_document/law_document";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { GLOBAL_SPACING } from "@/constants/format";
import { LegalDocumentStatusContent, LegalDocumentUserStatusKey, Module, ModuleFields, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { castDepartmentToSchema, Department } from "@/models/department/Department";
import { LawDocumentBodyReceive, SaveLawDocumentRequestFieldNames } from "@/models/law_document/LawDocument";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useContext, useEffect, useMemo, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import {
  castRequestReviewLegalDocumentRequestSchemaToDTO,
  RequestReviewLegalDocumentRequestFieldNames,
  RequestReviewLegalDocumentRequestSchema,
  RequestReviewLegalDocumentRequestSchemaI,
} from "../../../models/law_document/RequestReviewLegalDocument";
import { BasedLegalDocument } from "@/models/law_document/BasedLegalDocument";
import { useSearchStatus } from "@/hooks/useSearchStatus";

export interface RequestReviewLegalDocumentFormProps {
  id?: number;
  name?: string;
  titlePopup?: string;
  legalDocumentId?: number;
  extendDeadlineId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  initialValues?: LawDocumentBodyReceive;
  selectedDocuments?: BasedLegalDocument[];
  module?: number;
  defaultStatus?: string;
}

const initialEmptyValue: RequestReviewLegalDocumentRequestSchemaI = {
  users: [],
  departments: [],
  content: '',
  departmentResponseDate: ''
};

export const RequestReviewLegalDocumentForm = (
  props: RequestReviewLegalDocumentFormProps
) => {
  const {
    titlePopup = "requestReview.title.titlePopup",
    isOpen = false,
    setIsOpen,
    selectedDocuments,
    module = Module.get(ModuleKeys.LEGISLATION),
    defaultStatus= LegalDocumentStatusContent.get(
      LegalDocumentUserStatusKey.REQUEST_REVIEW
    ) as string
  } = props;
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const [departmentList, setDepartmentList] = useState<Department[]>([]);
  const [keyword, setKeyword] = useState<string>("");

  const form = useForm<RequestReviewLegalDocumentRequestSchemaI>({
    resolver: yupResolver(RequestReviewLegalDocumentRequestSchema as any),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    // mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const querySearchStatus = useSearchStatus({
    keyword: defaultStatus,
    form,
    queryKey: "LEGAL_DOCUMENT_REQUEST_REVIEW",
  });

  useEffect(() => {
    querySearchStatus?.data?.[0]?.id &&
      form.reset({
        status: querySearchStatus?.data?.[0]?.id,
      })
  }, [querySearchStatus?.data?.[0]?.id])

  const requestReviewLegalDocumentQuery = useMutation({
    mutationFn: requestReviewLegalDocument,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t("requestReview.title.titlePopup"),
      }));
      onCloseForm(true)
    },
  });
  const requestEvaluateMultipleQuery = useMutation({
    mutationFn: requestEvaluateMultiple,
    onSuccess: () => {
      toast.success(t("common.message.create_success", {
        recordName: t("requestReview.title.titlePopup"),
      }));
      onCloseForm(true)
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset(initialEmptyValue)
  };

  const { data: users = [], refetch } = useQuery({
    queryKey: ["get_users", departmentList, keyword],
    queryFn: async () => {
      if (!departmentList.length) return [];

      const response = await getUsers({
        searchTerm: keyword,
        page: 0,
        size: 100,
        sortBy: "name",
        sortOrder: "ASC",
        departmentIds: departmentList.map((el) => el.id),
      });

      return (response?.users ?? []).map((user) => ({
        id: user.id,
        name: user.name ?? "",
        departmentName: user.department?.name ?? "",
        email: user.email ?? "",
      })) as BasedUser[];
    },
    enabled: departmentList.length > 0,
  });

  useEffect(() => {
    if (departmentList.length) {
      refetch();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [departmentList]);

  const getOptions = useMemo(
    () => async (searchKeyword: string) => {
      setKeyword(searchKeyword);
      await refetch();
      return users || [];
    },
    [users, refetch]
  );

  const onSave = () => {
    if (props.legalDocumentId) {
      requestReviewLegalDocumentQuery.mutate({
        id: props.legalDocumentId,
        request: castRequestReviewLegalDocumentRequestSchemaToDTO({
          ...form.getValues(),
          departments: departmentList.map((el: any) => el.id)
        }),
      })
    }
    selectedDocuments?.length &&
      requestEvaluateMultipleQuery.mutate({
        request: castRequestReviewLegalDocumentRequestSchemaToDTO({
          ...form.getValues(),
          legalDocumentIds: selectedDocuments?.map((ele) => ele.id),
          departments: departmentList.map((el: any) => el.id),
        }),
      })
  }

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm(false)}>
      <FormProvider {...form}>
        <Grid container className='form-wrapper'>
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className='form-section-wrapper'
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size='small' fullWidth>
                  <Typography fontWeight="bold">
                    {t("timeExtension.title.textName")}
                  </Typography>
                  {selectedDocuments?.length ?
                    selectedDocuments?.map((ele, index) => (
                      <Typography key={ele.id.toString()}>
                        {index + 1}.  {ele.documentName}
                      </Typography>
                    ))
                    : <Typography>
                      {props.name}
                    </Typography>}
                </FormControl>
              </Grid>

              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={6}>
                  <FormSelectTreeView
                    name={'departments'}
                    control={form.control}
                    label={t("requestReview.title.departmentUser")}
                    getOptions={async (keyword) => {
                      try {
                        const response = await getDepartments({
                          searchTerm: keyword,
                        });
                        const first100Departments: Department[] = (
                          response?.departments ?? []
                        ).slice(0, 150);
                        return first100Departments; // Assuming the data is in response.data
                      } catch (e) {
                        return [];
                      }
                    }}
                    getOptionLabel={(option) => option.name ?? ""}
                    getOptionKey={(option) => option.id ?? ""}
                    getOptionChildren={(option) => option.children}
                    variant="outlined"
                    debounceMs={FILTER_DEBOUNCE_MS}
                    onChange={(value: Department[]) => {
                      const mappedValue: string[] = value.map(
                        (item) => item.id ?? ""
                      );
                      form.setValue("departments", mappedValue);
                      form.trigger("departments");
                      setDepartmentList(
                        (value ?? []).map((department) =>
                          castDepartmentToSchema(department)
                        )
                      );
                      const departmentNames = value.map((item) => item.name);
                      const formUsers = form.getValues("users") ?? []
                      if (
                        formUsers !== undefined &&
                        formUsers?.length > 0
                      ) {
                        const filteredUsers = formUsers
                          ?.filter((user: any) =>
                            departmentNames?.includes(user.departmentName)
                          );
                        form.setValue("users", filteredUsers);
                      }
                    }}
                    required
                  />
                </Grid>
                <Grid item xs={6} sx={{marginTop:"24px"}}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={'users'}
                    label={''}
                    placeholder={
                      t(
                        `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.PERSON_RESPONSIBLE}`
                      )?.toLocaleLowerCase()
                    }
                    getOptions={getOptions}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${option.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery='request-review/queryUser'
                    isFocus
                    minCharLength={1}
                  />
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestReviewLegalDocumentRequestFieldNames.CONTENT}
                  label={t(
                    `LEGISLATION.field_name.${RequestReviewLegalDocumentRequestFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `LEGISLATION.field_name.${RequestReviewLegalDocumentRequestFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={SaveLawDocumentRequestFieldNames.STATUS}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.STATUS}`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query-request-review"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }
                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled
                />
              </Grid>
              <Grid item width={'100%'}>
                <DateInput
                  name={
                    SaveLawDocumentRequestFieldNames.DEPARTMENT_RESPONSE_DATE
                  }
                  control={form.control}
                  label={t(
                    `LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DEPARTMENT_RESPONSE_DATE}`
                  )}
                  // placeholder={t('common.place_holder.enter_value', {
                  //   fieldName: t(`LEGISLATION.field_name.${SaveLawDocumentRequestFieldNames.DEPARTMENT_RESPONSE_DATE}`)?.toLocaleLowerCase()
                  // }
                  // )}
                  placeholder="dd/mm/yyyy"
                  required
                />
              </Grid>
            </Grid>
          </Grid>

          <Grid item>
            <ReminderPickerSubForm
              name={RequestReviewLegalDocumentRequestFieldNames.REMIND}
              module={module}
            />
          </Grid>

          <FormActionButtons
            formMode={"update"}
            loading={false}
            onCancel={onCloseForm}
            cancelConfirm={form.formState.isDirty}
            onSave={onSave}
            textSave="common.button.send"
          />
        </Grid>
      </FormProvider>
    </ModalCommon>
  );
};
