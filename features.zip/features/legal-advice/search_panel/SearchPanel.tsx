'use client'
import { getAllHierarchyById, getLegalAdviceRequests } from "@/apis/service/legal-advice/legalAdvice";
import { QuickFilter } from "@/components/commons/tables/multiple_filter_table/multiple_filter_table_bar/quick_filter/QuickFilter";
import { COLOR_TYPE } from "@/constants/color";
import {
  EXPECTED_DATE_TIME_LOCALE,
  GLOBAL_SMALL_SPACING
} from "@/constants/format";
import { LEGAL_ADVICE_ROOT_PATH } from "@/constants/paths";
import { LANGUAGES } from "@/locales/config-translation";
import { GetBasedLegalDocumentsResponse } from "@/models/law_document/BasedLegalDocument";
import { GetLegalAdviceListParams } from "@/models/legal-advice/LegalAdviceList";
import { mergeArraysByKey } from "@/utils";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import {
  Avatar,
  CircularProgress,
  Grid,
  IconButton,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Stack,
  Tooltip
} from "@mui/material";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useRouter } from "next/router";
import { Fragment, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useInView } from 'react-intersection-observer';

enum SearchPanelQueries {
  GET_HIERARCHY = 'legal-document/get-hierarchy',
  SEARCH_DOCUMENT = 'legal-advice/search_document',
}

const defaultParams: GetLegalAdviceListParams = {
  orderBy: 'DESC',
  page: 0,
  size: 10,
  sortBy: 'id',
  tab: 0,
  isPanelSearch: true,
}

export const getTooltip = (user: any, isEnglish: boolean) => {
  const name = user?.name;
  let position = isEnglish ? user?.positionResponse?.nameEnglish : user?.positionResponse?.name;
  position = position ? `${position}.` : "";
  const department = isEnglish ? user?.departmentResponse?.nameEnglish : user?.departmentResponse?.name;
  return `${name} - ${position}${department ?? ""}`
}
export const SearchPanel = () => {
  const [openPanel, setOpenPanel] = useState(true);
  const { ref, inView } = useInView();
  const [searchString, setSearchString] = useState<string>('')
  const router = useRouter();
  const queryClient = useQueryClient();
  const id = router.query.id;
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [currentPage, setCurrentPage] = useState(0)
  const { t, i18n } = useTranslation();

  const allHierarchyQuery = useQuery({
    queryKey: [SearchPanelQueries.GET_HIERARCHY],
    queryFn: () => getAllHierarchyById({ id: typeof id == "string" ? Number(id) : Number((id || [])[0]) }),
    placeholderData: (prevData) => prevData,
    enabled: false
  })
  useEffect(() => {
    allHierarchyQuery.refetch()
  }, [id]);
  useEffect(() => {
    if (inView && !!searchString.length && !isLoadingMore) {
      loadMoreDocuments();
    }
  }, [inView]);

  const searchPanelQuery = useQuery({
    queryKey: [SearchPanelQueries.SEARCH_DOCUMENT, searchString],
    queryFn: () => {
      const params: GetLegalAdviceListParams = {
        ...defaultParams,
        legalAdviceName: searchString
      };
      return getLegalAdviceRequests(params)
    },
    enabled: false
  })

  const loadMoreDocuments = async () => {
    setIsLoadingMore(true);
    const params: GetLegalAdviceListParams = {
      ...defaultParams,
      page: currentPage + 1,
      legalAdviceName: searchString
    };
    try {
      const response = await getLegalAdviceRequests(params);
      if (response?.data?.length) {
        queryClient.setQueryData([SearchPanelQueries.SEARCH_DOCUMENT, searchString], (prevData: GetBasedLegalDocumentsResponse) => {
          const mergedData = [...mergeArraysByKey(
            [[...(prevData?.data || [])], [...response?.data]],
            (ele: any) => ele?.id
          )]
          const hasIncreased = prevData?.data?.length < mergedData?.length;
          hasIncreased && setCurrentPage(currentPage + 1);
          return {
            ...(prevData ?? {}),
            data: mergedData
          }
        })
      }
    } catch (error) {
    } finally {
      setIsLoadingMore(false)
    }
  }



  return (
    <Grid container direction={"column"} width={openPanel ? 410 : undefined}>
      <Grid
        item
        sx={{
          position: "sticky",
          top: 0,
          zIndex: 1000,
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA7,
        }}
      >
        <Grid container direction={"row"} wrap='nowrap' justifyContent={"end"}>
          {openPanel && (
            <Grid item flex={1}>
              <QuickFilter
                filterOptions={[{ key: "name", label: "name" }]}
                placeHolder={() => {
                  return t('common.place_holder.enter_search_value')
                }}
                defaultSelectedOptionKey='name'
                onChange={(_, searchValue: string) => {
                  setSearchString(searchValue);
                  setCurrentPage((prevValue) => searchValue === searchString ? prevValue : 0)
                  if (!!searchValue.length) {
                    searchPanelQuery.refetch()
                  }
                }}
              />
            </Grid>
          )}
          <Grid item>
            <IconButton
              onClick={() => setOpenPanel((prev) => !prev)}
              sx={{
                backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                marginRight: GLOBAL_SMALL_SPACING,
              }}
            >
              {!openPanel ? <NavigateNextIcon /> : <NavigateBeforeIcon />}
            </IconButton>
          </Grid>
        </Grid>
      </Grid>

      {openPanel && (
        <Grid item width={410}>
          <List sx={{ width: 400 }}>
            {(!searchString.length && allHierarchyQuery.data) ? <SearchItem item={allHierarchyQuery.data} /> : null}
            {!!searchString.length && searchPanelQuery?.data?.data?.length
              ? <>
                {searchPanelQuery?.data?.data?.map((item) => (
                  <SearchItem item={item} key={item.id} isEnglish={i18n.language === LANGUAGES.ENGLISH} />
                ))}
                <ListItem ref={ref} sx={{ justifyContent: 'center', height: 28, marginTop: 2 }}>
                  {isLoadingMore ? <CircularProgress size={28} color="primary" /> : null}
                </ListItem>
              </> : null}
          </List>
        </Grid>
      )}
    </Grid>
  );
};

const SearchItem = (props: any) => {
  const { item, isEnglish } = props
  return <ListItem
    key={item.id}
    sx={{
      width: '100%',
      backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
      margin: "1rem 1rem 0 0",
    }}
    dense
  >
    <List sx={{ width: '100%' }}>
      <ListItem disablePadding dense >
        <ListItemAvatar>
          <Tooltip title={getTooltip(item?.pic ?? item?.createdUser, isEnglish)}>
            <Avatar
              key={item?.pic?.id ?? item?.createdUser?.name}
              alt={item?.pic?.name ?? item?.createdUser?.name}
              src={item?.pic?.avatarUrl}
              sx={{ width: 40, height: 40 }}
            />
          </Tooltip>
        </ListItemAvatar>
        <ListItemText
          primary={<Link href={`/${LEGAL_ADVICE_ROOT_PATH}/update/${item?.legalAdviceId ?? item?.id}`}>{item?.legalAdviceName}</Link>}
          secondary={item?.createdDate ? Intl.DateTimeFormat(
            EXPECTED_DATE_TIME_LOCALE,
            {
              dateStyle: "short",
              timeStyle: "short",
            }
          ).format(new Date(item?.createdDate)) : null}
          primaryTypographyProps={{
            variant: "h5",
            sx: {
              overflow: "hidden",
              textOverflow: "ellipsis",
              display: "-webkit-box",
              WebkitLineClamp: "2",
              WebkitBoxOrient: "vertical",
              title: item.title,
            },
          }}
        />
      </ListItem>
      <ListItem dense sx={{ justifyContent: 'space-between', pr: 0, mt: 1 }}>
        <ListItemAvatar>
          <Stack direction={'row'} gap={0.5}>
            {(item?.receiverUsers ?? [])?.map((user: any) => (
              <Tooltip title={getTooltip(user, isEnglish)} key={user.id}>
                <Avatar
                  alt={user.name}
                  src={user?.avatarUrl}
                  sx={{ width: 32, height: 32, }}
                />
              </Tooltip>
            ))}
          </Stack>
        </ListItemAvatar>
        <Link href={`/${LEGAL_ADVICE_ROOT_PATH}/update/${item?.legalAdviceId ?? item?.id}`}>
          <ListItemText
            sx={{ cursor: 'pointer', textAlign: 'right', color: '#007AFF', textDecorationLine: 'underline' }}
            primary={item?.status?.name || item?.status}
          />
        </Link>
      </ListItem>
      {
        (item?.children ?? []).map((child: any, chIndex: number) => (
          <Fragment key={child.id}>
            <ListItem key={child.id} dense>
              <ListItemText
                primary={`Yêu cầu kiểm tra lần ${chIndex + 2}`}
              />
            </ListItem>
            <ListItem dense sx={{ justifyContent: 'space-between', pr: 0 }}>
              <ListItemAvatar>
                <Stack direction={'row'} gap={0.25}>
                  {(child?.receiverUsers ?? [])?.map((user: any) => (
                    <Tooltip title={getTooltip(user, isEnglish)} key={user.id}>
                      <Avatar
                        alt={user.name}
                        src={user.avatarUrl}
                        sx={{ width: 30, height: 30 }}
                      />
                    </Tooltip>
                  ))}
                </Stack>
              </ListItemAvatar>
              <Link href={`/${LEGAL_ADVICE_ROOT_PATH}/update/${child?.legalAdviceId ?? child?.id}`}>
                <ListItemText
                  primary={`Lần ${chIndex + 2}: ${child.status?.name ?? child?.status}`}
                  sx={{ cursor: 'pointer', textAlign: 'right', color: '#007AFF', textDecorationLine: 'underline' }}
                />
              </Link>
            </ListItem>
          </Fragment>
        ))
      }
    </List >
  </ListItem >
}