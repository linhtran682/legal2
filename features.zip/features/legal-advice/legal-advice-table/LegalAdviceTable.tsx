import { getFields } from "@/apis/service/field/Field";
import { useConfirmLegalAdvice } from "@/apis/service/legal-advice/confirmLegalAdvice";
import {
  cloneLegalAdvice,
  getLegalAdviceExcel,
  getLegalAdviceRequests,
  shareLegalAdviceFn,
} from "@/apis/service/legal-advice/legalAdvice";
import { useRecallLegalAdvice } from "@/apis/service/legal-advice/recallLegalAdvice";
import { getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import IconRecheck from "@/assets/iconMenu/IconRecheck";
import { getMultipleAsyncChoosingOperators } from "@/components/commons/filters/MultipleAsyncChoosingFilter";
import { getMultipleSelectOperators } from "@/components/commons/filters/MultipleSelectFilter";
import HierarchyToolTip from "@/components/commons/hierarchy-tooltip/HierarchyTooltip";
import { ConfirmPopup, ConfirmPopupProps, DefaultConfirmPopupState } from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import MultipleTabsTable from "@/components/commons/tables/multiple_tabs_table/MultipleTabsTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import { URL_OUTLOOK } from "@/constants/constraint";
import {
  LegalAdviceActionsBtnKey,
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  MIME_TYPES,
  ModuleFields,
} from "@/constants/general";
import { LEGAL_ADVICE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import { FieldDTO, FieldFieldNames } from "@/models/field/Field";
import { legalAdviceSearchPanelConfig } from "@/models/legal-advice/LegalAdviceDetail";
import {
  BaseLegalAdviceFields,
  GetLegalAdviceListParams,
} from "@/models/legal-advice/LegalAdviceList";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser } from "@/models/user/User";
import { downloadFile, formatDate } from "@/utils";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { Button, Grid, IconButton, Tooltip } from "@mui/material";
import { GridFilterItem } from "@mui/x-data-grid";
import { useMutation, useQuery } from "@tanstack/react-query";
import { endOfDay, format } from "date-fns";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { Range as DateRange } from "react-date-range";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { AdvisorLegalAdviceForm } from "../advisor_legal_advice_form/AdvisorLegalAdviceForm";
import { FeedbackAdviceForm } from "../advisor_legal_advice_form/FeedbackAdviceForm";
import { SupervisorAdviceForm } from "../advisor_legal_advice_form/SupervisorAdviceForm";
import { AssignmentLegalAdviceForm } from "../assignment_legal_advice_form/AssignmentLegalAdviceForm";
import { FeedbackLegalAdviceForm } from "../feedback_legal_advice_form/FeedbackLegalAdviceForm";
import { FinishLegalAdviceForm } from "../finish_legal_advice_form/FinishLegalAdviceForm";
import { ForwardLegalAdviceForm } from "../forward_legal_advice_form/ForwardLegalAdviceForm";
import { RequestAdditionalForm } from "../request_additional_information_form/RequestAdditionalForm";
import { RequestVendorForm } from "../request_vendor_form/RequestVendorForm";
import SendMailForm from "../send_mail_form/SendMailForm";
import { TimeExtensionAdviceForm } from "../time_extension_Advice_form/TimeExtensionAdviceForm";
import { LegalAdviceTableActions } from "./legal_advice_table_actions/LegalAdviceTableActions";
import { FeedbackLegalAdviceFieldNames } from "@/models/legal-advice/FeedbackLegalAdvice";

export const LegalAdviceTableConst = {
  GENERAL_TABLE: "LEGAL_ADVICE.title.general_table",
  GET_ALL_QUERY_KEY: "getAllLegalAdvice",
  PERSONAL_TABLE: "LEGAL_ADVICE.title.personal_table",
  GET_PERSONAL_QUERY_KEY: "getPersonalLegalAdvice",
  GET_LEGAL_ADVICE_EXCEL: "getLegalAdviceExcel",
};

const getFieldLabel = (key: string) => {
  return `legalAdvice.fields.${key}`;
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetLegalAdviceListParams => {
  const params: GetLegalAdviceListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 10,
    sortBy: BaseLegalAdviceFields.ID,
    orderBy: "DESC",
  };
  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == BaseLegalAdviceFields.LEGAL_ADVICE_NAME) {
      params.legalAdviceName = item.value;
    }

    if (item.field == BaseLegalAdviceFields.FIELD) {
      params.fields = (item.value ?? [])
        .map((item: FieldDTO) => item.id ?? item)
        .join(",");
    }

    if (item.field == BaseLegalAdviceFields.STATUS) {
      params.statusList = (item.value ?? [])
        .map((item: StatusDTO) => item.id ?? item)
        .join(",");
    }
    if (item.field == BaseLegalAdviceFields.SENDER) {
      params.picIds = (item.value ?? [])
        .map((item: BasedUser) => item.id)
        .join(",");
    }

    if (item.field == BaseLegalAdviceFields.RESPONSE_DATE) {
      params.responseDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();

      params.responseDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};

const LegalAdviceTable = () => {
  const { t, i18n } = useTranslation();
  const [activeTab, setActiveTab] = useState<number>(0);
  const router = useRouter();
  const appContext = useContext(AppContext);
  const [initialLegalAdvice, setInitialLegalAdvice] = useState<any>(undefined);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [legalDocumentTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: BaseLegalAdviceFields.ID,
      label: BaseLegalAdviceFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: 'center'
    },
    {
      key: BaseLegalAdviceFields.LEGAL_ADVICE_NAME,
      label: BaseLegalAdviceFields.LEGAL_ADVICE_NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      flex: 2,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => (
        <HierarchyToolTip
          {...legalAdviceSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.legalAdviceName}
          openNewTab
        >
          <span>{params.value}</span>
        </HierarchyToolTip>
      ),
    },
    {
      key: BaseLegalAdviceFields.FIELD,
      label: BaseLegalAdviceFields.FIELD,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => <span>{params.value?.name}</span>,
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getFields({
              page: 0,
              size: 100,
              sortBy: FieldFieldNames.NAME,
              orderBy: "ASC",
            });

            return response?.fieldResponses || [];
          },
          getOptionKey: (item) => item.id.toString(),
          getOptionLabel: (item) => item.name,
          keyQuery: BaseLegalAdviceFields.FIELD,
        },
        t
      ),
    },
    {
      key: BaseLegalAdviceFields.REASON,
      label: BaseLegalAdviceFields.REASON,
      type: undefined,
      quickFilter: false,
      // filterable: true,
      sortable: true,
      minWidth: 200,
      // hideable: true,
    },
    {
      key: BaseLegalAdviceFields.STATUS,
      label: BaseLegalAdviceFields.STATUS,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        return (
          <Button
            variant="outlined"
            style={{
              background:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params.row?.isDraft ? t('common.label.draft') : params.value?.name}
          </Button>
        );
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusList({
              page: 0,
              size: 100,
              sortBy: FieldFieldNames.NAME,
              orderBy: "ASC",
              modules: [ModuleFields.ADVISE_NAME.module],
              active: 1
            });

            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item.id,
          getOptionLabel: (item) => item.name,
          keyQuery: `legal-advice-${BaseLegalAdviceFields.STATUS}`,
        },
        t
      ),
    },
    {
      key: BaseLegalAdviceFields.DEADLINE_TYPE,
      label: BaseLegalAdviceFields.DEADLINE,
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 270,
      flex: 1,
      renderCell: (params) =>
        params.value === 1 ? t("legalAdvice.label.SOP") : "Urgent",
    },
    {
      key: BaseLegalAdviceFields.RESPONSE_DATE,
      label: BaseLegalAdviceFields.RETURN_DATE_ALL,
      filterLabel: "legalAdvice.label.responseDeadline",
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, 'dd/MM/yyyy HH:mm'),
    },
    {
      key: BaseLegalAdviceFields.SENDER,
      label: BaseLegalAdviceFields.SENDER,
      filterLabel: "legalAdvice.label.creator",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 250,
      flex: 1,
      renderCell: (params) => <Tooltip
        placement="bottom-start"
        title={params.row?.pic
          ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
          : ""}>
        <span>
          {params.row?.pic
            ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
            : ""}
        </span>
      </Tooltip>,
      filterOperators: getMultipleSelectOperators(
        {
          getOptions: async (keyword) => {
            const response = await getUsers({
              searchTerm: keyword,
              page: 0,
              size: 100,
              sortBy: "name",
              sortOrder: "ASC",
            });

            return response?.users ?? [];
          },
          getOptionKey: (item) => item.id.toString(),
          getOptionLabel: (item) =>
            `${item?.name} - ${item?.position?.name ? `${item?.position?.name}.` : ""
            }${item?.department?.name ?? ""}`,
          keyQuery: BaseLegalAdviceFields.SENDER,
        },
        t
      ),
    },
    {
      key: BaseLegalAdviceFields.RECEIVER,
      label: BaseLegalAdviceFields.RECEIVER,
      type: "string",
      quickFilter: false,
      // filterable: true,
      flex: 2,
      sortable: true,
      minWidth: 250,
      renderCell: (params) =>
        <Tooltip
          placement="bottom-start"
          title={
            <>
              {params.row?.receiverUsers
                ?.map(
                  (user: any) => <p key={user?.id}>{user.name} - {user?.departmentResponse?.name}</p>
                )}
            </>
          }>
          {params.row?.receiverUsers
            ?.map(
              (user: any) => `${user.name} - ${user?.departmentResponse?.name}`
            )
            .join(", ")}
        </Tooltip>
    },
    {
      key: BaseLegalAdviceFields.ACTION,
      label: BaseLegalAdviceFields.ACTION,
      type: undefined,
      renderCell: (params) => (!params?.row?.isDraft
        // && params?.row?.status?.name !== LegalAdviceStatusContent.get(
        //   LegalAdviceStatusKey.DONE)
      )
        && LegalAdviceTableActions({
          params,
          handleClickRecall: async () =>
            await recallLegalAdvice(Number(params.id)),
          handleClickForWard: () =>
            handleClick(LegalAdviceActionsBtnKey.FORWARD, params.row),
          handleClickFeedBack: () =>
            handleClick(LegalAdviceActionsBtnKey.FEEDBACK, params.row),
          handleClickSendMail: () =>
            handleClick(LegalAdviceActionsBtnKey.SEND_MAIL, params.row),
          handleClickExtendTime: () =>
            handleClick(
              LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
              params.row
            ),
          handleClickConfirm: async () =>
            await confirmLegalAdvice(Number(params.id)),
          handleClickAssignment: () =>
            handleClick(LegalAdviceActionsBtnKey.ASSIGNMENT, params.row),
          handleClickRequestVendor: () =>
            handleClick(LegalAdviceActionsBtnKey.REQUEST_VENDOR, params.row),
          handleClickFeedbackAdvise: () =>
            handleClick(LegalAdviceActionsBtnKey.FEEDBACK_ADVISE, params.row),
          handleClickRequestAdditional: () =>
            handleClick(
              LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL,
              params.row
            ),
          handleClickAdvise: () =>
            handleClick(LegalAdviceActionsBtnKey.ADVISE, params.row),
          handleClickShare: () =>
            handleClick(LegalAdviceActionsBtnKey.SHARE, params.row),
          handleClickRecheck: () => {
            handleRecheck(params.row);
          },
          handleClickDone: () =>
            handleClick(LegalAdviceActionsBtnKey.DONE, params.row),
          handleClickRequestMeeting: () => window.open(URL_OUTLOOK, "_blank"),
        }),
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "last-column-sticky",
      headerClassName: "last-column-sticky-header",
    },
  ]);

  /** Get all legal advice */
  const getAllLegalAdviceQuery = useQuery({
    queryKey: [LegalAdviceTableConst.GET_ALL_QUERY_KEY],
    queryFn: () =>
      getLegalAdviceRequests({
        ...castTableStateToParams(generalTableState),
        tab: 0,
      }),
    enabled: false,
  });
  /** Get personal legal advice request */
  const getPersonalLegalAdviceQuery = useQuery({
    queryKey: [LegalAdviceTableConst.GET_PERSONAL_QUERY_KEY],
    queryFn: () =>
      getLegalAdviceRequests({
        ...castTableStateToParams(personalTableState),
        tab: 1,
      }),
    enabled: false,
  });

  const { mutateAsync: recallLegalAdvice } = useRecallLegalAdvice({
    config: {
      onSuccess: () => {
        toast.success(
          t("legalAdvice.recallLegalAdvice.message.recall_success")
        );
        getAllLegalAdviceQuery.refetch();
        getPersonalLegalAdviceQuery.refetch();
      },
    },
  });

  const { mutateAsync: confirmLegalAdvice } = useConfirmLegalAdvice({
    config: {
      onSuccess: () => {
        toast.success(
          t("legalAdvice.confirmLegalAdvice.message.confirm_success")
        );
        getAllLegalAdviceQuery.refetch();
        getPersonalLegalAdviceQuery.refetch();
      },
    },
  });

  const changePopupVisible = (type: any, state: boolean = false, reload: boolean = false) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state) {
      setInitialLegalAdvice(undefined);
    }
    if (reload) {
      getAllLegalAdviceQuery.refetch();
      getPersonalLegalAdviceQuery.refetch();
    }
  };

  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialLegalAdvice(row);
      changePopupVisible(type, true);
    }
  };

  useEffect(() => {
    generalTableState &&
      activeTab === 0 &&
      getAllLegalAdviceQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generalTableState, activeTab]);

  useEffect(() => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalLegalAdviceQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [personalTableState, activeTab]);

  /** Get excel file */
  const getLegalAdviceExcelQuery = useQuery({
    queryKey: [LegalAdviceTableConst.GET_LEGAL_ADVICE_EXCEL],
    queryFn: () =>
      getLegalAdviceExcel({
        ...castTableStateToParams(
          activeTab === 0 ? generalTableState : personalTableState
        ),
        tab: activeTab,
        size: 9999,
        isEnglish: i18n.language === "en",
      }),
    enabled: false,
  });

  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getLegalAdviceExcelQuery.refetch().then((response: any) => {
              const fileName = `${i18n.language === "en"
                ? "RequestLegalAdvice"
                : "Yêu cầu tư vấn pháp lý"
                }_${format(new Date(), "ddMMyyyy")}`;
              response?.data &&
                downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getAllLegalAdviceQuery.isFetching ||
            getPersonalLegalAdviceQuery.isFetching ||
            getLegalAdviceExcelQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };

  const shareMutation = useMutation({
    mutationFn: shareLegalAdviceFn,
    onSuccess: () => {
      toast.success(
        t(`legalAdvice.messages.shareSuccess`)
      );
    },
  });
  const cloneMutation = useMutation({
    mutationFn: cloneLegalAdvice,
    onSuccess: () => {
      toast.success(
        t(`legalAdvice.messages.recheckSuccess`)
      );
      setConfirmPopupState(DefaultConfirmPopupState);
      getAllLegalAdviceQuery.refetch();
      getPersonalLegalAdviceQuery.refetch();
    },
  });

  const getStatusListQuery = useQuery({
    queryKey: ['legal-advice/get-status-list'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.ADVISE_NAME.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.NAME,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: true
  });

  const handleRecheck = (advice: any) => {
    setConfirmPopupState({
      open: true,
      icon: <IconRecheck />,
      title: t(`legalAdvice.messages.confirmRecheck`),
      handleConfirm: () => {
        const requestAdviceStatus = getStatusListQuery?.data
          ?.find((ele: StatusDTO) => ele.name === LegalAdviceStatusContent.get(
            LegalAdviceStatusKey.REQUEST_ADVICE
          )!)

        advice?.id && cloneMutation.mutate({
          id: advice?.id as number,
          data: {
            childStatus: requestAdviceStatus?.id as number,
            status: advice?.status?.id as number
          }
        })
      },
      handleCancel: () => {
        setConfirmPopupState(DefaultConfirmPopupState);
      },
    })
  }

  return (
    <>
      <MultipleTabsTable
        tableTabs={[
          {
            tabName: t("legalAdvice.label.allRequests"),
            tabKey: LegalAdviceTableConst.GENERAL_TABLE,
            data: getAllLegalAdviceQuery?.data?.data ?? [],
            loading: getAllLegalAdviceQuery?.isFetching,
            rowCount: getAllLegalAdviceQuery?.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t("legalAdvice.label.myRequests"),
            tabKey: LegalAdviceTableConst.PERSONAL_TABLE,
            data: getPersonalLegalAdviceQuery?.data?.data ?? [],
            loading: getPersonalLegalAdviceQuery?.isFetching,
            rowCount: getPersonalLegalAdviceQuery?.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={legalDocumentTableColumns.map((column) => ({
          ...column,
          label: column.label ? getFieldLabel(column.label) : "",
        }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        quickFilterProps={{
          defaultSelectedOptionKey: BaseLegalAdviceFields.LEGAL_ADVICE_NAME,
          placeHolder: () => t("legalAdvice.placeholder.enterAdviceName"),
        }}
        onRowClick={(params) =>
          router.push(
            `/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
          )
        }
        exportFile={renderExportButton()}
        onTabChange={setActiveTab}
      />
      <ConfirmPopup {...confirmPopupState} />
      {popupVisibleState?.[LegalAdviceActionsBtnKey.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialLegalAdvice?.pic}
          pics={initialLegalAdvice?.responsibleUsers}
          onSubmit={async (data: any) => {
            const params = {
              id: initialLegalAdvice?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
          initialValue={{
            legalAccessType: initialLegalAdvice?.legalAccessType,
            sharedDepartments: initialLegalAdvice?.sharedDepartments,
            sharedUsers: initialLegalAdvice?.sharedUsers,
          }}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.SEND_MAIL] && (
        <SendMailForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.SEND_MAIL,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.SEND_MAIL]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          legalAdvice={initialLegalAdvice}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.FORWARD] && (
        <ForwardLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.FORWARD, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.FORWARD]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          responseDate={initialLegalAdvice?.responseDate}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.ASSIGNMENT] && (
        <AssignmentLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.ASSIGNMENT,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.ASSIGNMENT]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_VENDOR] && (
        <RequestVendorForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.REQUEST_VENDOR,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_VENDOR]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION] && (
        <TimeExtensionAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
              state,
              reload
            )
          }
          isOpen={
            popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION]
          }
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialLegalAdvice?.pic],
          }}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.DONE] && (
        <FinishLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.DONE]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAdditionalForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL,
              state,
              reload
            )
          }
          isOpen={
            popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL]
          }
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [appContext?.me],
          }}
          maxDate={initialLegalAdvice?.responseDate}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.ADVISE] &&
        (!initialLegalAdvice?.superVisor ? (
          <AdvisorLegalAdviceForm
            legalAdviceId={initialLegalAdvice?.id}
            legalAdviceName={initialLegalAdvice?.legalAdviceName}
            isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.ADVISE]}
            adviseId={initialLegalAdvice?.adviseId}
            setIsOpen={(state, reload) =>
              changePopupVisible(LegalAdviceActionsBtnKey.ADVISE, state, reload)
            }
            senderDocumentManagement={appContext?.me}
            initialLegalAdvice={initialLegalAdvice}
          />
        ) : (
          <SupervisorAdviceForm
            legalAdviceId={initialLegalAdvice?.id}
            legalAdviceName={initialLegalAdvice?.legalAdviceName}
            isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.ADVISE]}
            adviseId={initialLegalAdvice?.adviseId}
            setIsOpen={(state, reload) =>
              changePopupVisible(LegalAdviceActionsBtnKey.ADVISE, state, reload)
            }
            senderDocumentManagement={appContext?.me}
            initialLegalAdvice={initialLegalAdvice}
          />
        ))}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE] && (
        <FeedbackAdviceForm
          legalAdviceId={initialLegalAdvice?.id}
          legalAdviceName={initialLegalAdvice?.legalAdviceName}
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.FEEDBACK_ADVISE,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE]}
          senderDocumentManagement={appContext?.me}
          responseDate={initialLegalAdvice?.responseDate}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK] && (
        <FeedbackLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.FEEDBACK, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          initialValue={{
            [FeedbackLegalAdviceFieldNames.USERS]: initialLegalAdvice?.pic
              ? [initialLegalAdvice?.pic]
              : [],
            [FeedbackLegalAdviceFieldNames.DEADLINE]:
              initialLegalAdvice?.responseDate
                ? new Date(initialLegalAdvice?.responseDate)
                : new Date(),
          }}
        />
      )}
    </>
  );
};

export default LegalAdviceTable;
