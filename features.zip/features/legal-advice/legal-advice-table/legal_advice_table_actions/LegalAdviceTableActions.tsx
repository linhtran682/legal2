import React from "react";
import { IconAdvise } from "@/assets/iconMenu/IconAdvise";
import { IconAssignment } from "@/assets/iconMenu/IconAssignment";
import { IconConfirm } from "@/assets/iconMenu/IconConfirm";
import { IconDone } from "@/assets/iconMenu/IconDone";
import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";
import { IconFeedback } from "@/assets/iconMenu/IconFeedback";
import { IconFeedbackAdvise } from "@/assets/iconMenu/IconFeedbackAdvise";
import { IconForward } from "@/assets/iconMenu/IconForward";
import { IconRequestAdditional } from "@/assets/iconMenu/IconRequestAdditional";
import { IconRequestMeeting } from "@/assets/iconMenu/IconRequestMeeting";
import { IconSendMail } from "@/assets/iconMenu/IconSendMail";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";
import {
  ActionButtonCustom,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButtonCustom";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { COLOR_TYPE } from "@/constants/color";
import {
  LegalAdviceActionsBtnKey,
  LegalAdviceActionsBtnR,
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  LegalAdviceUserRole,
  LegalAdviceUserRoleKey,
} from "@/constants/general";
import { useTranslation } from "react-i18next";
import { IconRecall } from "@/assets/iconMenu/IconRecall";
import { IconRequestVendor } from "@/assets/iconMenu/IconRequestVendor";
import IconShare from "@/assets/iconMenu/IconShare";
import IconCopy from "@/assets/iconMenu/IconCopy";
import { LegalAdviceBodyReceive } from "@/models/legal-advice/LegalAdviceDetail";
import AddTaskIcon from '@mui/icons-material/AddTask';

type TypeActionRole = {
  typeBtn: string;
  disable?: boolean;
};

type TypePropsLegalAdviceTableActions = {
  params: { row: any };
  isActionDetail?: boolean;
  handleClickRecall?: () => void;
  handleClickForWard?: () => void;
  handleClickFeedBack?: () => void;
  handleClickRequestMeeting?: () => void;
  handleClickSendMail?: () => void;
  handleClickExtendTime?: () => void;
  handleClickConfirm?: () => void;
  handleClickAssignment?: () => void;
  handleClickRequestVendor?: () => void;
  handleClickFeedbackAdvise?: () => void;
  handleClickRequestAdditional?: () => void;
  handleClickAdvise?: () => void;
  handleClickDone?: () => void;
  handleClickShare?: () => void;
  handleClickRecheck?: () => void;
  handleClickAddInfo?: () => void;
};

const uniqueCheck = (checkData: TypeActionRole[]) => {
  return checkData.reduce(
    (accumulator: TypeActionRole[], currentValue: TypeActionRole) => {
      const existing = accumulator.find(
        (item) => item.typeBtn === currentValue.typeBtn
      );

      if (existing) {
        if (Boolean(existing?.disable) === Boolean(currentValue?.disable)) {
          accumulator = accumulator.filter(
            (item) => item.typeBtn !== currentValue.typeBtn
          );
          accumulator.push(currentValue);
        } else {
          const indexAcc = accumulator.findIndex(
            (item: TypeActionRole) => item.typeBtn === currentValue.typeBtn
          );
          accumulator.splice(indexAcc, 1, { ...currentValue, disable: false });
        }
      } else {
        accumulator.push(currentValue);
      }

      return accumulator;
    },
    []
  );
};

const authorizedActionMapCallBack = (legalAdviceActions: any, params: {
  row: LegalAdviceBodyReceive
},
  isDetail: boolean = false) => {
  const listLcDone = [
    {
      typeBtn: LegalAdviceActionsBtnKey.SHARE,
    },
  ]
  const listItemActionPicDone = [
    {
      typeBtn: LegalAdviceActionsBtnKey.RECHECK,
    },
    {
      typeBtn: LegalAdviceActionsBtnKey.SHARE,
    },
  ];
  let roleList = [];
  if (params?.row?.userLastActionAndLegalAdviceRoleResponse?.userLastActionAndRoleList?.length) {
    const { userLastActionAndLegalAdviceRoleResponse: { userLastActionAndRoleList } } = params?.row;
    roleList = userLastActionAndRoleList?.map((ele: any) => ele.role)
    // setOwnRole(roleList);
  }

  if (params?.row?.status?.name === LegalAdviceStatusContent.get(
    LegalAdviceStatusKey.DONE
  )!) {
    return roleList.includes(1)
      ? listItemActionPicDone
      : (
        roleList.includes(2)
          || roleList.includes(3)
          || roleList.includes(4)
          ? listLcDone
          : []);
  }

  const btnCondition = {
    [LegalAdviceActionsBtnKey.RECALL]:
      params?.row?.userLastActionAndLegalAdviceRoleResponse
        ?.otherActionsAvailableFlag,
    [LegalAdviceActionsBtnKey.FEEDBACK]:
      params?.row?.userLastActionAndLegalAdviceRoleResponse
        ?.feedbackAvailableFlag,
    [LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION]:
      params?.row?.userLastActionAndLegalAdviceRoleResponse
        ?.requestTimeExtensionAvailableFlag,
    [LegalAdviceActionsBtnKey.FEEDBACK_ADVISE]:
      params?.row?.userLastActionAndLegalAdviceRoleResponse
        ?.legalAdviceDoneFlag,
    [LegalAdviceActionsBtnKey.DONE]:
      params?.row?.userLastActionAndLegalAdviceRoleResponse
        ?.legalAdviceDoneFlag,
    [LegalAdviceActionsBtnKey.CONFIRM]:
      !!params?.row?.confirmFlag,
    [LegalAdviceActionsBtnKey.INFO_ADDED]:
      [LegalAdviceStatusContent.get(
        LegalAdviceStatusKey.REQUEST_ADDITIONAL
      )!]
        ?.includes(params?.row?.status?.name) && isDetail,

  };

  const listItemActionsPic = [
    ...(!!btnCondition[LegalAdviceActionsBtnKey.INFO_ADDED] ? [{
      typeBtn: LegalAdviceActionsBtnKey.INFO_ADDED,
    }] : []),
    { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
    {
      typeBtn: LegalAdviceActionsBtnKey.RECALL,
    },
    {
      typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
      disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: LegalAdviceActionsBtnKey.REQUEST_MEETING },
    { typeBtn: LegalAdviceActionsBtnKey.SEND_MAIL },
    // {
    //   typeBtn: LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
    //   disable: !btnCondition[LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION],
    // },
    {
      typeBtn: LegalAdviceActionsBtnKey.FEEDBACK_ADVISE,
      disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE],
    },
    {
      typeBtn: LegalAdviceActionsBtnKey.DONE,
      disable: !btnCondition[LegalAdviceActionsBtnKey.DONE],
    },
    {
      typeBtn: LegalAdviceActionsBtnKey.SHARE,
    },
  ];

  const listItemActionsForWard = [
    { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
    {
      typeBtn: LegalAdviceActionsBtnKey.RECALL,
    },
    ...(!btnCondition[LegalAdviceActionsBtnKey.FEEDBACK]
      ? [
        {
          typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
        },
      ]
      : []),
  ];

  const listItemActionsLcAndHeadLc = [
    { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
    { typeBtn: LegalAdviceActionsBtnKey.RECALL },
    {
      typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
      disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: LegalAdviceActionsBtnKey.REQUEST_MEETING },
    { typeBtn: LegalAdviceActionsBtnKey.SEND_MAIL },
    { typeBtn: LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION },
    { typeBtn: LegalAdviceActionsBtnKey.ASSIGNMENT },
    { typeBtn: LegalAdviceActionsBtnKey.REQUEST_VENDOR },
    {
      typeBtn: LegalAdviceActionsBtnKey.CONFIRM,
      disable: !!btnCondition[LegalAdviceActionsBtnKey.CONFIRM]
    },
    { typeBtn: LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL },
    { typeBtn: LegalAdviceActionsBtnKey.ADVISE },
    {
      typeBtn: LegalAdviceActionsBtnKey.SHARE,
    },
  ];

  const listItemActionsLcAndHeadLcAdvice = [
    { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
    { typeBtn: LegalAdviceActionsBtnKey.RECALL },
    {
      typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
      disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK],
    },
    { typeBtn: LegalAdviceActionsBtnKey.SEND_MAIL },
    { typeBtn: LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION },
    { typeBtn: LegalAdviceActionsBtnKey.ASSIGNMENT },
    { typeBtn: LegalAdviceActionsBtnKey.REQUEST_VENDOR, disable: true },
    {
      typeBtn: LegalAdviceActionsBtnKey.CONFIRM,
      disable: !!btnCondition[LegalAdviceActionsBtnKey.CONFIRM],
    },
    { typeBtn: LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL, disable: true },
    { typeBtn: LegalAdviceActionsBtnKey.ADVISE },
    {
      typeBtn: LegalAdviceActionsBtnKey.SHARE,
    },
  ];

  const listItemActionsSupervisor = [
    { typeBtn: LegalAdviceActionsBtnKey.RECALL },
    { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
    {
      typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
      disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: LegalAdviceActionsBtnKey.REQUEST_MEETING },
    { typeBtn: LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION },
    { typeBtn: LegalAdviceActionsBtnKey.ADVISE },
    {
      typeBtn: LegalAdviceActionsBtnKey.SHARE,
    },
  ];

  const listItemActionsRelatedPerson = [
    {
      typeBtn: LegalAdviceActionsBtnKey.RECALL,
      disable: !!btnCondition[LegalAdviceActionsBtnKey.DONE],
    },
    {
      typeBtn: LegalAdviceActionsBtnKey.FORWARD,
      disable: !!btnCondition[LegalAdviceActionsBtnKey.DONE],
    },
    {
      typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
      disable: !!btnCondition[LegalAdviceActionsBtnKey.DONE],
    },
  ];

  const listActionsPic = {
    [LegalAdviceActionsBtnKey.CREATE_NEW]: [
      ...(!!btnCondition[LegalAdviceActionsBtnKey.INFO_ADDED] ? [{
        typeBtn: LegalAdviceActionsBtnKey.INFO_ADDED,
      }] : []),
      { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
      {
        typeBtn: LegalAdviceActionsBtnKey.RECALL,
      },
      ...(!btnCondition[LegalAdviceActionsBtnKey.FEEDBACK]
        ? [
          {
            typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
            disable: true,
          },
        ]
        : []),
      // { typeBtn: LegalAdviceActionsBtnKey.REQUEST_MEETING },
      { typeBtn: LegalAdviceActionsBtnKey.SEND_MAIL },
      {
        typeBtn: LegalAdviceActionsBtnKey.FEEDBACK_ADVISE,
        disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE],
      },
      {
        typeBtn: LegalAdviceActionsBtnKey.DONE,
        disable: !btnCondition[LegalAdviceActionsBtnKey.DONE],
      },
      {
        typeBtn: LegalAdviceActionsBtnKey.SHARE,
      },
    ],
    [LegalAdviceActionsBtnKey.RECALL]: [
      ...(!!btnCondition[LegalAdviceActionsBtnKey.INFO_ADDED] ? [{
        typeBtn: LegalAdviceActionsBtnKey.INFO_ADDED,
      }] : []),
      { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
      {
        typeBtn: LegalAdviceActionsBtnKey.RECALL,
      },
      ...(!btnCondition[LegalAdviceActionsBtnKey.FEEDBACK]
        ? [
          {
            typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
            disable: true,
          },
        ]
        : []),
      // { typeBtn: LegalAdviceActionsBtnKey.REQUEST_MEETING },
      { typeBtn: LegalAdviceActionsBtnKey.SEND_MAIL },
      ...(!btnCondition[LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION]
        ? [
          {
            typeBtn: LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
            disable: true,
          },
        ]
        : []),
      {
        typeBtn: LegalAdviceActionsBtnKey.FEEDBACK_ADVISE,
        disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE],
      },
      ...(!btnCondition[LegalAdviceActionsBtnKey.DONE]
        ? [
          {
            typeBtn: LegalAdviceActionsBtnKey.DONE,
            disable: true,
          },
        ]
        : []),
      {
        typeBtn: LegalAdviceActionsBtnKey.SHARE,
      },
    ],
    [LegalAdviceActionsBtnKey.FORWARD]: listItemActionsPic,
    [LegalAdviceActionsBtnKey.FEEDBACK]: listItemActionsPic,
    // [LegalAdviceActionsBtnKey.REQUEST_MEETING]: listItemActionsPic,
    [LegalAdviceActionsBtnKey.SEND_MAIL]: listItemActionsPic,
    [LegalAdviceActionsBtnKey.FEEDBACK_ADVISE]: listItemActionsPic,
    // [LegalAdviceActionsBtnKey.DONE]: [
    //   { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
    //   {
    //     typeBtn: LegalAdviceActionsBtnKey.RECALL,
    //   },
    //   ...(!btnCondition[LegalAdviceActionsBtnKey.FEEDBACK]
    //     ? [
    //         {
    //           typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
    //           disable: true,
    //         },
    //       ]
    //     : []),
    //   { typeBtn: LegalAdviceActionsBtnKey.REQUEST_MEETING },
    //   { typeBtn: LegalAdviceActionsBtnKey.SEND_MAIL },
    //   {
    //     typeBtn: LegalAdviceActionsBtnKey.FEEDBACK_ADVISE,
    //     disable: !btnCondition[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE],
    //   },
    //   {
    //     typeBtn: LegalAdviceActionsBtnKey.DONE,
    //     disable: !btnCondition[LegalAdviceActionsBtnKey.DONE],
    //   },
    // ],
    // [LegalAdviceActionsBtnKey.DONE]: listItemActionsPic?.map(
    //   (listItemDefault) => ({
    //     ...listItemDefault,
    //     disable: listItemDefault.typeBtn !== LegalAdviceActionsBtnKey.SHARE,
    //   }),
    // ),
    [LegalAdviceActionsBtnKey.DONE]: listItemActionsPic?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: listItemDefault.typeBtn !== LegalAdviceActionsBtnKey.SHARE,
      }),
    ),
    [LegalAdviceActionsBtnKey.NOT_AVAILABLE]: listItemActionsPic,
  };

  const listActionsLcAndHeadLc = {
    [LegalAdviceActionsBtnKey.RECALL]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.FORWARD]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.FEEDBACK]: listItemActionsLcAndHeadLc,
    // [LegalAdviceActionsBtnKey.REQUEST_MEETING]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.SEND_MAIL]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION]:
      listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.CONFIRM]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.ASSIGNMENT]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.REQUEST_VENDOR]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.ADVISE]: listItemActionsLcAndHeadLcAdvice,
    [LegalAdviceActionsBtnKey.NOT_AVAILABLE]: listItemActionsLcAndHeadLc,
    [LegalAdviceActionsBtnKey.DONE]: listItemActionsLcAndHeadLc?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
  };

  const listActionsSupervisor = {
    [LegalAdviceActionsBtnKey.RECALL]: listItemActionsSupervisor,
    [LegalAdviceActionsBtnKey.FORWARD]: listItemActionsSupervisor,
    [LegalAdviceActionsBtnKey.FEEDBACK]: listItemActionsSupervisor,
    [LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION]:
      listItemActionsSupervisor,
    // [LegalAdviceActionsBtnKey.REQUEST_MEETING]: listItemActionsSupervisor,
    [LegalAdviceActionsBtnKey.ADVISE]: listItemActionsSupervisor,
    [LegalAdviceActionsBtnKey.NOT_AVAILABLE]: listItemActionsSupervisor,
    [LegalAdviceActionsBtnKey.DONE]: listItemActionsSupervisor?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
  };
  const listActionsRelatedPerson = {
    [LegalAdviceActionsBtnKey.NOT_AVAILABLE]: listItemActionsRelatedPerson,
    [LegalAdviceActionsBtnKey.FORWARD]: listItemActionsRelatedPerson,
    [LegalAdviceActionsBtnKey.RECALL]: listItemActionsRelatedPerson,
    [LegalAdviceActionsBtnKey.FEEDBACK]: listItemActionsRelatedPerson,
    [LegalAdviceActionsBtnKey.DONE]: listItemActionsRelatedPerson?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
  }
  const listActionsForWard = {
    [LegalAdviceActionsBtnKey.FORWARD]: listItemActionsForWard,
    [LegalAdviceActionsBtnKey.RECALL]: listItemActionsForWard,
    [LegalAdviceActionsBtnKey.FEEDBACK]: listItemActionsForWard,
    [LegalAdviceActionsBtnKey.DONE]: listItemActionsForWard?.map(
      (listItemDefault) => ({
        ...listItemDefault,
        disable: true,
      })
    ),
    [LegalAdviceActionsBtnKey.NOT_AVAILABLE]: [
      { typeBtn: LegalAdviceActionsBtnKey.FORWARD },
      {
        typeBtn: LegalAdviceActionsBtnKey.RECALL,
      },
      {
        typeBtn: LegalAdviceActionsBtnKey.FEEDBACK,
      }
    ],
  };
  const authorizedActionMap = new Map<number | string, any>([
    [LegalAdviceUserRole.get(LegalAdviceUserRoleKey.PIC)!, listActionsPic],
    [
      LegalAdviceUserRole.get(LegalAdviceUserRoleKey.L_C)!,
      listActionsLcAndHeadLc,
    ],
    [
      LegalAdviceUserRole.get(LegalAdviceUserRoleKey.HEAD_OF_L_C)!,
      listActionsLcAndHeadLc,
    ],
    [
      LegalAdviceUserRole.get(LegalAdviceUserRoleKey.SUPERVISOR)!,
      listActionsSupervisor,
    ],
    [
      LegalAdviceUserRole.get(LegalAdviceUserRoleKey.RELATED_PERSON)!,
      listActionsRelatedPerson,
    ],
    [
      LegalAdviceUserRole.get(LegalAdviceUserRoleKey.FORWARD)!,
      listActionsForWard,
    ],
    [LegalAdviceUserRole.get(LegalAdviceUserRoleKey.VIEWER)!, []],
  ]);
  let listActionAuthorizedMap: TypeActionRole[] = [];
  legalAdviceActions.forEach((legalDocumentItemAction: any) => {
    const authorizedAction =
      authorizedActionMap?.get(legalDocumentItemAction?.role)?.[
      LegalAdviceActionsBtnR.get(
        legalDocumentItemAction?.lastAction
      ) as string
      ] || [];
    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });
  return uniqueCheck(listActionAuthorizedMap);
};

export const LegalAdviceTableActions = (
  props: TypePropsLegalAdviceTableActions
) => {
  const {
    params,
    isActionDetail = false,
    handleClickRecall = () => { },
    handleClickForWard = () => { },
    handleClickFeedBack = () => { },
    handleClickRequestMeeting = () => { },
    handleClickSendMail = () => { },
    handleClickExtendTime = () => { },
    handleClickConfirm = () => { },
    handleClickAssignment = () => { },
    handleClickRequestVendor = () => { },
    handleClickFeedbackAdvise = () => { },
    handleClickRequestAdditional = () => { },
    handleClickAdvise = () => { },
    handleClickDone = () => { },
    handleClickShare = () => { },
    handleClickRecheck = () => { },
    handleClickAddInfo = () => { },
  } = props;
  const [t] = useTranslation();
  const styleBtn = { background: COLOR_TYPE.TOYOTA.TOYOTA1, color: COLOR_TYPE.TOYOTA.TOYOTA8 }
  const buttonMap = new Map<string, ActionButtonItem>([
    [
      LegalAdviceActionsBtnKey.RECALL,
      {
        key: LegalAdviceActionsBtnKey.RECALL,
        icon: <IconRecall />,
        iconDisable: <IconRecall color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.RECALL}`),
        onClick: handleClickRecall,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.RECALL}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `legalAdvice.recallLegalAdvice.message.confirm_${LegalAdviceActionsBtnKey.RECALL}`
          ),
        },
        styleBtn,
        secondaryBtn: 1,
      },
    ],
    [
      LegalAdviceActionsBtnKey.FORWARD,
      {
        key: LegalAdviceActionsBtnKey.FORWARD,
        icon: <IconForward />,
        iconDisable: <IconForward color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.FORWARD}`),
        onClick: handleClickForWard,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.FORWARD}`
        ),
        styleBtn,
        secondaryBtn: 3,
      },
    ],
    [
      LegalAdviceActionsBtnKey.FEEDBACK,
      {
        key: LegalAdviceActionsBtnKey.FEEDBACK,
        icon: <IconFeedback />,
        iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.FEEDBACK}`),
        onClick: handleClickFeedBack,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.FEEDBACK}`
        ),
        styleBtn,
        secondaryBtn: 4,
      },
    ],
    [
      LegalAdviceActionsBtnKey.REQUEST_MEETING,
      {
        key: LegalAdviceActionsBtnKey.REQUEST_MEETING,
        icon: <IconRequestMeeting />,
        iconDisable: <IconRequestMeeting color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_MEETING}`
        ),
        onClick: handleClickRequestMeeting,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_MEETING}`
        ),
        styleBtn,
        secondaryBtn: 5,
      },
    ],
    [
      LegalAdviceActionsBtnKey.SEND_MAIL,
      {
        key: LegalAdviceActionsBtnKey.SEND_MAIL,
        icon: <IconSendMail />,
        iconDisable: <IconSendMail color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.SEND_MAIL}`),
        onClick: handleClickSendMail,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.SEND_MAIL}`
        ),
        styleBtn,
        secondaryBtn: 2,
      },
    ],
    [
      LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
      {
        key: LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
        icon: <IconExtendDeadline />,
        iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION}`
        ),
        onClick: handleClickExtendTime,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION}`
        ),
        styleBtn,
        secondaryBtn: 6,
      },
    ],
    [
      LegalAdviceActionsBtnKey.CONFIRM,
      {
        key: LegalAdviceActionsBtnKey.CONFIRM,
        icon: <IconConfirm />,
        iconDisable: <IconConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.CONFIRM}`),
        onClick: handleClickConfirm,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.CONFIRM}`
        ),
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `legalAdvice.confirmLegalAdvice.message.confirm_done`
          ),
        },
        styleBtn,
        order: 1,
      },
    ],
    [
      LegalAdviceActionsBtnKey.ASSIGNMENT,
      {
        key: LegalAdviceActionsBtnKey.ASSIGNMENT,
        icon: <IconAssignment />,
        iconDisable: <IconAssignment color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.ASSIGNMENT}`),
        onClick: handleClickAssignment,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.ASSIGNMENT}`
        ),
        styleBtn,
        order: 2,
      },
    ],
    [
      LegalAdviceActionsBtnKey.REQUEST_VENDOR,
      {
        key: LegalAdviceActionsBtnKey.REQUEST_VENDOR,
        icon: <IconRequestVendor />,
        iconDisable: <IconRequestVendor color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_VENDOR}`
        ),
        onClick: handleClickRequestVendor,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_VENDOR}`
        ),
        styleBtn,
        order: 3,
      },
    ],
    [
      LegalAdviceActionsBtnKey.FEEDBACK_ADVISE,
      {
        key: LegalAdviceActionsBtnKey.FEEDBACK_ADVISE,
        icon: <IconFeedbackAdvise />,
        iconDisable: <IconFeedbackAdvise color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.FEEDBACK_ADVISE}`
        ),
        onClick: handleClickFeedbackAdvise,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.FEEDBACK_ADVISE}`
        ),
        styleBtn,
        order: 6,
      },
    ],
    [
      LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL,
      {
        key: LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL,
        icon: <IconRequestAdditional />,
        iconDisable: <IconRequestAdditional color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL}`
        ),
        onClick: handleClickRequestAdditional,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL}`
        ),
        styleBtn,
        order: 4,
      },
    ],
    [
      LegalAdviceActionsBtnKey.ADVISE,
      {
        key: LegalAdviceActionsBtnKey.ADVISE,
        icon: <IconAdvise />,
        iconDisable: <IconAdvise color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.ADVISE}`),
        onClick: handleClickAdvise,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.ADVISE}`
        ),
        styleBtn,
        order: 5,
      },
    ],
    [
      LegalAdviceActionsBtnKey.DONE,
      {
        key: LegalAdviceActionsBtnKey.DONE,
        icon: <IconDone />,
        iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.DONE}`),
        onClick: handleClickDone,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.DONE}`
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        order: 8,
      },
    ],
    [
      LegalAdviceActionsBtnKey.SHARE,
      {
        key: LegalAdviceActionsBtnKey.SHARE,
        icon: <IconShare />,
        iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.SHARE}`),
        onClick: handleClickShare,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.SHARE}`
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        secondaryBtn: 7,
      },
    ],
    [
      LegalAdviceActionsBtnKey.RECHECK,
      {
        key: LegalAdviceActionsBtnKey.RECHECK,
        icon: <IconCopy />,
        iconDisable: <IconCopy color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
        textBtn: t(`legalAdvice.button.${LegalAdviceActionsBtnKey.RECHECK}`),
        onClick: handleClickRecheck,
        tooltipTitle: t(
          `legalAdvice.button.${LegalAdviceActionsBtnKey.RECHECK}`
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        order: 7,
      },
    ],
    [
      LegalAdviceActionsBtnKey.INFO_ADDED,
      {
        key: LegalAdviceActionsBtnKey.INFO_ADDED,
        icon: <AddTaskIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA1 }} />,
        iconDisable: <AddTaskIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA5 }} />,
        textBtn: t('DOCUMENT_REVIEW.button.infoAdded'),
        onClick: handleClickAddInfo,
        tooltipTitle: t(
          'DOCUMENT_REVIEW.buttons.infoAdded'
        ),
        styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        confirmPopupProps: {
          icon: <SaveRecordDialogIcon />,
          title: t(
            `DOCUMENT_REVIEW.messages.infoAddedConfirm`
          ),
        },
      },
    ]
  ])
  if (isActionDetail)
    return (
      <ActionButtonDetail
        params={params}
        actionButtonItems={authorizedActionMapCallBack(
          params?.row?.userLastActionAndLegalAdviceRoleResponse
            ?.userLastActionAndRoleList ?? [],
          params,
          true
        )?.map((buttons: TypeActionRole) => ({
          ...buttonMap.get(buttons?.typeBtn)!,
          disable: buttons?.disable,
        }))}
      />
    );

  return (
    <ActionButtonCustom
      params={params}
      actionButtonItems={authorizedActionMapCallBack(
        params?.row?.userLastActionAndLegalAdviceRoleResponse
          ?.userLastActionAndRoleList ?? [],
        params
      )?.map((buttons: TypeActionRole) => ({
        ...buttonMap.get(buttons?.typeBtn)!,
        disable: buttons?.disable,
      }))}
      listActions={
        props?.params?.row?.userLastActionAndLegalAdviceRoleResponse
          ?.userLastActionAndRoleList ?? []
      }
    />
  );
};
