  import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { getStatus, getStatusListNames } from "@/apis/service/status/Status";
import { StatusDTO } from "@/models/status/Status";
import {
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import {
  AdviceOptions,
  AdvisorLegalAdviceFieldNames,
  AdvisorLegalAdviceSchemaI,
  castAdvisorLegalAdviceRequestSchemaToDTO,
  FileInfo,
  SupervisorLegalAdviceSchema,
} from "@/models/legal-advice/AdvisorLegalAdvice";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import {
  useCreateAdvisorLegalAdvice,
  useGetAdvisorLegalAdvice,
  useGetAdvisorLegalAdviceList,
  useUpdateAdvisorLegalAdviceDetail,
} from "@/apis/service/legal-advice/advisorLegalAdvice";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { FormSelectButton } from "@/components/commons/form_inputs/FormSelectButton";
import {
  getDepartmentHeads,
  getLegalDepartments,
} from "@/apis/service/department/department";
import { useQuery } from "@tanstack/react-query";
import { findDeepestId } from "@/utils";

const initialEmptyValue: AdvisorLegalAdviceSchemaI = {
  [AdvisorLegalAdviceFieldNames.CONTENT]: "",
  [AdvisorLegalAdviceFieldNames.FINISH]: false,
  [AdvisorLegalAdviceFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  legalAdviceName?: string;
  initialValue?: AdvisorLegalAdviceSchemaI;
  legalAdviceId?: number;
  adviseId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  minDateAdvisor?: Date | undefined;
  senderDocumentManagement?: any;
  defaultStatus?: string;
  initialLegalAdvice?: any;
}

export const AdvisorLegalAdviceForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.advisorLegalAdvice.title.titlePage",
    legalAdviceName,
    initialValue = initialEmptyValue,
    legalAdviceId,
    adviseId,
    isOpen = false,
    setIsOpen,
    module = Module.get(ModuleKeys.ADVISE),
    senderDocumentManagement,
    initialLegalAdvice,
    defaultStatus = LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.CONSULTATION_COMPLETED
    )!,
  } = props;
  const [files, setFiles] = useState<any>([]);
  const [listStatus, setListStatus] = useState<any>([]);
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(SupervisorLegalAdviceSchema)
  });
  
  const getSearchStatusQuery = useSearchStatus({
    keyword: !adviseId ? defaultStatus : undefined,
    modules: ModuleFields.ADVISE_NAME.module,
    queryKey: "LEGAL_ADVICE_ADVISOR",
  });

  const { data: getAdvisorLegalAdvice, isLoading } = useGetAdvisorLegalAdvice({
    request: { legalAdviceId, adviseId },
    config: {
      enabled: !!legalAdviceId && !!adviseId,
    },
  });
  const { data: getAdvisorLegalAdviceList } = useGetAdvisorLegalAdviceList({
    request: { legalAdviceId },
    config: {
      enabled: !!legalAdviceId,
    },
  });

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["legal-advice/get-legal-department-popup"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        // setDepartmentId(deepestId?.id ?? '')
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const getDepartmentHeadQuery = useQuery({
    queryKey: ["legal-advice/popup-advice", getLegalDepartmentQuery?.data],
    queryFn: () => getDepartmentHeads(getLegalDepartmentQuery?.data as string),
    placeholderData: (prev) => prev,
    enabled: !!getLegalDepartmentQuery?.data,
  });

  const { mutateAsync: createAdvisorLegalAdvice, isPending } =
    useCreateAdvisorLegalAdvice({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const {
    mutateAsync: updateAdvisorLegalAdviceDetail,
    isPending: isLoadingUpdateAdvisor,
  } = useUpdateAdvisorLegalAdviceDetail({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(titlePopup),
          })
        );
        onCloseForm(true);
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    if (adviseId) {
      await updateAdvisorLegalAdviceDetail({
        legalAdviceId,
        adviseId,
        data: {
          ...data,
          status: +data?.status,
        },
      });
      return;
    }
    await createAdvisorLegalAdvice({
      legalAdviceId,
      data: {
        ...data,
        ...(data?.status && { status: +data?.status }),
      },
    });
  };

  useEffect(() => {
    if (getAdvisorLegalAdvice) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { receiverUsers, department, type, ...restGetSupervisorLegalAdvice } =
        getAdvisorLegalAdvice;
      restGetSupervisorLegalAdvice?.attachments &&
        setFiles(
          restGetSupervisorLegalAdvice.attachments?.map((item: any) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          })
        );
      form.reset({
        ...restGetSupervisorLegalAdvice,
        [AdvisorLegalAdviceFieldNames.STATUS]: initialLegalAdvice?.status?.id,
        [AdvisorLegalAdviceFieldNames.USER_IDS]: initialLegalAdvice?.pic
          ? [initialLegalAdvice?.pic]
          : [],
      });
    } else {
      form.reset({
        ...initialValue,
        ...(getSearchStatusQuery?.data && {
          [AdvisorLegalAdviceFieldNames.STATUS]:
            getSearchStatusQuery?.data?.find(
              (status) => status?.name === defaultStatus
            )?.id,
        }),
        [AdvisorLegalAdviceFieldNames.USER_IDS]: initialLegalAdvice?.pic
          ? [initialLegalAdvice?.pic]
          : [],
      });
    }
  }, [getAdvisorLegalAdvice, getSearchStatusQuery?.data, initialLegalAdvice]);

  useEffect(() => {
    const fetch = async () => {
      try {
        const response = await getStatusListNames({
          names: [
            LegalAdviceStatusContent.get(LegalAdviceStatusKey.SENT_SUPERVISOR)!,
            LegalAdviceStatusContent.get(
              LegalAdviceStatusKey.CONSULTATION_COMPLETED
            )!,
          ],
          modules: [ModuleFields.ADVISE_NAME.module],
        });
        setListStatus(response?.statusResponses);
      } catch (errors) {}
    };
    fetch();
  }, []);

  const handleChangeRadioType = (
    _event: React.ChangeEvent<HTMLInputElement>,
    value: string | number | boolean
  ) => {
    const itemAdvisorLegalAdvice = getAdvisorLegalAdviceList?.find(
      (userAdvice) =>
        userAdvice?.user?.id === getDepartmentHeadQuery?.data?.deptHead?.id
    );
    const isCheckDepartmentHead =
      senderDocumentManagement?.id ===
        getDepartmentHeadQuery?.data?.deptHead?.id ||
      senderDocumentManagement?.id ===
        getDepartmentHeadQuery?.data?.division?.id;
    form.setValue(
      AdvisorLegalAdviceFieldNames.STATUS,
      !value
        ? listStatus?.find(
            (status: any) =>
              status?.name ===
              LegalAdviceStatusContent.get(
                LegalAdviceStatusKey.CONSULTATION_COMPLETED
              )
          )?.id
        : listStatus?.find(
            (status: any) =>
              status?.name ===
              LegalAdviceStatusContent.get(LegalAdviceStatusKey.SENT_SUPERVISOR)
          )?.id
    );
    form.setValue(
      AdvisorLegalAdviceFieldNames.USER_IDS,
      !value
        ? initialLegalAdvice?.pic
          ? [initialLegalAdvice?.pic]
          : []
        : itemAdvisorLegalAdvice || isCheckDepartmentHead
        ? []
        : [getDepartmentHeadQuery?.data?.deptHead]
    );
  };
  const handleGetOptions = async (keyword: string) => {
    const itemAdvisorLegalAdviceList =
      getAdvisorLegalAdviceList?.map((userAdvice: any) => userAdvice?.user?.id) ??
      [];
    const listNotActiveUser = [
      initialLegalAdvice?.pic?.id,
      senderDocumentManagement?.id,
    ]?.concat(itemAdvisorLegalAdviceList);
    const params: GetUsersParams = {
      searchTerm: keyword,
      page: 0,
      size: 100,
      sortBy: "name",
      sortOrder: "ASC",
    };
    const response = await getUsers(params);
    if (form.getValues(AdvisorLegalAdviceFieldNames.TYPE)) {
      return (response?.users ?? [])
        ?.filter((user) => !listNotActiveUser?.includes(user?.id))
        ?.map((user) => ({
          id: user.id,
          name: user?.name ?? "",
          departmentName: user?.department?.name ?? user?.departmentName,
          email: user.email,
        }));
    }
    else {
      return (response?.users ?? []).map((user) => ({
        id: user.id,
        name: user?.name ?? "",
        departmentName: user?.department?.name ?? user?.departmentName,
        email: user.email,
      }));
    }
  };

  if (isLoading || isPending) return;

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("legalAdvice.advisorLegalAdvice.title.name")}
                </Typography>
                <Typography>{legalAdviceName}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`legalAdvice.advisorLegalAdvice.title.receiverUsers`)}
                </label>
                <Typography>
                  {adviseId
                    ? `${getAdvisorLegalAdvice?.user?.name} (${getAdvisorLegalAdvice?.user?.email}) - ${getAdvisorLegalAdvice?.user?.department?.name}`
                    : `${senderDocumentManagement?.name} (${
                        senderDocumentManagement?.email
                      }) - ${
                        senderDocumentManagement?.departmentName ??
                        senderDocumentManagement?.department?.name
                      }`}
                </Typography>
              </Grid>
              <Grid item width={"100%"}>
                <RadioGroupField
                  isNumber
                  items={AdviceOptions}
                  name={AdvisorLegalAdviceFieldNames.TYPE}
                  error={
                    form.formState.errors[
                      AdvisorLegalAdviceFieldNames.TYPE
                    ] as FieldError
                  }
                  onChangeRadioGroup={handleChangeRadioType}
                  defaultValue={AdviceOptions?.[0]?.value as number}
                />
              </Grid>
              <Grid item width={"100%"} display="none">
                <FormSelectButton
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.STATUS}
                  label={t(`legalAdvice.advisorLegalAdvice.title.status`)}
                  placeholder={t(
                    `legalAdvice.advisorLegalAdvice.placeHolder.status`
                  )}
                  keyQuery={"status-query-advisor"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusListNames({
                        names: [
                          LegalAdviceStatusContent.get(
                            LegalAdviceStatusKey.ADVICE
                          )!,
                          LegalAdviceStatusContent.get(
                            LegalAdviceStatusKey.SENT_SUPERVISOR
                          )!,
                          LegalAdviceStatusContent.get(
                            LegalAdviceStatusKey.CONSULTATION_COMPLETED
                          )!,
                          keyword,
                        ],
                        modules: [ModuleFields.ADVISE_NAME.module],
                      });
                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option?.name}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.advisorLegalAdvice.title.${AdvisorLegalAdviceFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.advisorLegalAdvice.placeHolder.${AdvisorLegalAdviceFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={!adviseId}
                  preview={!!adviseId}
                  files={files}
                  setFiles={setFiles}
                  title={t(`legalAdvice.advisorLegalAdvice.title.file`)}
                  inputId="advisorLegalAdvice"
                />
              </Grid>
              {/* <Grid item width={"100%"}>
                <FormCheckbox
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.FINISH}
                  label={t(
                    `legalAdvice.advisorLegalAdvice.title.completeAdvisor`
                  )}
                  inputTransform={(value: boolean) => value != false}
                  outputTransform={(bool) => (bool ? true : false)}
                />
              </Grid> */}
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AdvisorLegalAdviceFieldNames.USER_IDS}
                    label={t("legalAdvice.advisorLegalAdvice.title.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={handleGetOptions}
                    getOptionLabel={(option) =>
                      `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                        option?.department?.name ??
                        option?.departmentName ??
                        option?.departmentResponse?.name ??
                        ""
                      }`
                    }
                    getOptionKey={(option) => option?.id}
                    keyQuery={"advisorLegalAdvice/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={AdvisorLegalAdviceFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave={`common.button.send`}
              loading={isLoadingUpdateAdvisor || isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit(
                    castAdvisorLegalAdviceRequestSchemaToDTO({
                      ...form.getValues(),
                      attachmentIds: attachments,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
