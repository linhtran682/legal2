import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  AdvisorLegalAdviceFieldNames,
  ResponsesAdvisorLegalAdviceDTO,
} from "@/models/legal-advice/AdvisorLegalAdvice";
import { Grid, TextField, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";

type TypePropsListAdvisorLegal = {
  data?: ResponsesAdvisorLegalAdviceDTO[];
};

export const ListAdvisorLegalAdvice = (props: TypePropsListAdvisorLegal) => {
  const { data } = props;
  const { t } = useTranslation();
  return (
    <>
      {data?.map((item) => {
        const attachmentsItem = item.attachments?.map((item: any) => {
          return {
            name: item?.fileName,
            path: item?.filePath,
            id: item?.fileId,
            uploadDate: item?.uploadDate,
          };
        });
        return (
          <Grid
            container
            className="form-sub-section-wrapper"
            position={"relative"}
            rowGap={GLOBAL_SPACING}
            key={item?.id}
          >
            <Grid item width={"100%"}>
              <label style={{ padding: 0 }}>
                {t(
                  item?.superVisor
                    ? "legalAdvice.supervisorAdvice.title.titlePage"
                    : "legalAdvice.advisorLegalAdvice.title.receiverUsers"
                )}
              </label>
              <Typography>{`${item?.user?.name} (${item?.user?.email}) - ${item?.department?.name}`}</Typography>
            </Grid>
            <Grid item width={"100%"}>
              <label style={{ padding: 0 }}>
                {t(
                  `legalAdvice.advisorLegalAdvice.title.${AdvisorLegalAdviceFieldNames.CONTENT}`
                )}
              </label>
              <TextField
                value={item?.content}
                label={""}
                placeholder={t(
                  `legalAdvice.advisorLegalAdvice.placeHolder.${AdvisorLegalAdviceFieldNames.CONTENT}`
                )}
                minRows={2}
                size="small"
                InputLabelProps={{
                  shrink: true,
                }}
                multiline
                fullWidth
                disabled
              />
            </Grid>
            {item?.attachments?.length ? <Grid item width={"100%"}>
              <DropPreviewFileUploadComponent
                files={attachmentsItem as any}
                setFiles={() => {}}
                preview
                disabled
                title={t(`legalAdvice.label.attachments`)}
                inputId={`file-input-${item?.id}`}
              />
            </Grid> : <></>}
          </Grid>
        );
      })}
    </>
  );
};
