import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { getStatus, getStatusListNames } from "@/apis/service/status/Status";
import { StatusDTO } from "@/models/status/Status";
import {
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import {
  AdvisorLegalAdviceFieldNames,
  AdvisorLegalAdviceSchemaI,
  FeedBackAdvisorLegalAdviceSchema,
  FileInfo,
} from "@/models/legal-advice/AdvisorLegalAdvice";
import {
  useGetAdvisorLegalAdviceList,
  useUpdateAdvisorLegalAdvice,
} from "@/apis/service/legal-advice/advisorLegalAdvice";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { ListAdvisorLegalAdvice } from "./ListAdvisorLegalAdvice";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { FormSelectButton } from "@/components/commons/form_inputs/FormSelectButton";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { useQueryClient } from "@tanstack/react-query";

const initialEmptyValue: AdvisorLegalAdviceSchemaI = {
  [AdvisorLegalAdviceFieldNames.CONTENT]: "",
  [AdvisorLegalAdviceFieldNames.USERS]: [],
  [AdvisorLegalAdviceFieldNames.FINISH]: false,
  [AdvisorLegalAdviceFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: AdvisorLegalAdviceSchemaI;
  legalAdviceId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  legalAdviceName?: string;
  module?: number;
  minDateAdvisor?: Date | undefined;
  defaultStatus?: string;
  senderDocumentManagement?: any;
  responseDate?: string;
}

const uniqueData = (listFeedback: any) => Array.from(new Set(listFeedback?.map((Feedback: BasedUser) => Feedback.id)))
  .map(id => listFeedback?.find((Feedback: BasedUser) => Feedback.id === id));

export const FeedbackAdviceForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.feedbackAdvice.title.titlePopup",
    legalAdviceName,
    initialValue = initialEmptyValue,
    legalAdviceId,
    isOpen = false,
    setIsOpen,
    module = Module.get(ModuleKeys.ADVISE),
    minDateAdvisor = undefined,
    defaultStatus = LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.FEEDBACK_ADVICE
    )!,
    senderDocumentManagement,
    responseDate
  } = props;
  const [files, setFiles] = useState<any>([]);
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();
  const form = useForm<any>({
    resolver: yupResolver(FeedBackAdvisorLegalAdviceSchema),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    modules: ModuleFields.ADVISE_NAME.module,
    queryKey: "LEGAL_ADVICE_FEEDBACK_ADVICE",
  });
  
  const {
    data: getAdvisorLegalAdviceList,
    isLoading: isLoadingAdvisorLegalAdviceList,
  } = useGetAdvisorLegalAdviceList({
    request: { legalAdviceId },
    config: {
      enabled: !!legalAdviceId,
    },
  });

  const {
    mutateAsync: updateAdvisorLegalAdvice,
    isPending: isLoadingUpdateAdvisorLegalAdvice,
  } = useUpdateAdvisorLegalAdvice({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(titlePopup),
          })
        );
        queryClient.invalidateQueries({
          queryKey: [`advise-feedback-${legalAdviceId}`]
        })
        onCloseForm(true);
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await updateAdvisorLegalAdvice({
      legalAdviceId,
      data: {
        status: +data?.status,
        type: 0,
        deadlineNew: data?.deadlineNew,
        reason: data?.reason,
        users: data?.users,
        remind: data?.remind,
      },
    });
  };
  useEffect(() => {
    if (getAdvisorLegalAdviceList) {
      form.reset({
        [AdvisorLegalAdviceFieldNames.DEADLINE_NEW]: responseDate ? new Date(responseDate) : null,
        users:
        uniqueData(getAdvisorLegalAdviceList?.map((userItem) => userItem?.user)) || [],
      });
    }
  }, [getAdvisorLegalAdviceList, responseDate]);

  if (isLoadingAdvisorLegalAdviceList)
    return <></>;

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("legalAdvice.feedbackAdvice.title.textName")}
                </Typography>
                <Typography>{legalAdviceName}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {t(`legalAdvice.feedbackAdvice.title.sender`)}
                </label>
                <Typography>
                  {`${senderDocumentManagement?.name} (${
                        senderDocumentManagement?.email
                      }) - ${
                        senderDocumentManagement?.departmentName ??
                        senderDocumentManagement?.department?.name
                      }`}
                </Typography>
              </Grid>
              {getAdvisorLegalAdviceList && (
                <ListAdvisorLegalAdvice data={getAdvisorLegalAdviceList} />
              )}
              <Grid item width={"100%"} display="none">
                <FormSelectButton
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.STATUS}
                  label={t(`legalAdvice.feedbackAdvice.title.status`)}
                  placeholder={t(
                    `legalAdvice.feedbackAdvice.placeHolder.status`
                  )}
                  keyQuery={"status-query-feedbackAdviceForm"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusListNames({
                        names: [
                          LegalAdviceStatusContent.get(
                            LegalAdviceStatusKey.FEEDBACK_ADVICE
                          )!,
                          keyword,
                        ],
                        modules: [ModuleFields.ADVISE_NAME.module],
                      });
                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView
                  preview={false}
                  files={files}
                  setFiles={setFiles}
                  title={t(`legalAdvice.feedbackAdvice.title.file`)}
                  inputId="feedbackAdvice"
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateTimeInput
                  name={AdvisorLegalAdviceFieldNames.DEADLINE_NEW}
                  control={form.control}
                  label={t(`legalAdvice.feedbackAdvice.title.newDeadline`)}
                  placeholder={t(
                    `legalAdvice.feedbackAdvice.title.newDeadline`
                  )}
                  minDate={minDateAdvisor}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.REASON}
                  label={t(`legalAdvice.feedbackAdvice.title.reason`)}
                  placeHolder={t(
                    `legalAdvice.feedbackAdvice.placeHolder.reason`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AdvisorLegalAdviceFieldNames.USERS}
                    label={t(
                      "legalAdvice.feedbackAdvice.title.responsiblePerson"
                    )}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"feedbackAdviceForm/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={AdvisorLegalAdviceFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave={`legalAdvice.feedbackAdvice.button.feedback`}
              loading={
                isLoadingUpdateAdvisorLegalAdvice ||
                isLoadingAdvisorLegalAdviceList
              }
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit({
                    ...form.getValues(),
                    attachmentIds: attachments,
                    users: form.getValues()?.users?.map((user: any)=>user?.id) || [],
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
