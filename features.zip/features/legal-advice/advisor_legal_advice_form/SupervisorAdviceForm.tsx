import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import {
  getStatus,
  getStatusListNames,
} from "@/apis/service/status/Status";
import { StatusDTO } from "@/models/status/Status";
import {
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import {
  AdvisorLegalAdviceFieldNames,
  AdvisorLegalAdviceSchemaI,
  castAdvisorLegalAdviceRequestSchemaToDTO,
  FileInfo,
  SupervisorAdviceOptions,
  SupervisorLegalAdviceSchema,
  TypeAdvisorLegal,
} from "@/models/legal-advice/AdvisorLegalAdvice";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import {
  useCreateAdvisorLegalAdvice,
  useGetAdvisorLegalAdvice,
  useGetAdvisorLegalAdviceList,
  useUpdateAdvisorLegalAdviceDetail,
} from "@/apis/service/legal-advice/advisorLegalAdvice";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { ListAdvisorLegalAdvice } from "./ListAdvisorLegalAdvice";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { FormSelectButton } from "@/components/commons/form_inputs/FormSelectButton";

const initialEmptyValue: AdvisorLegalAdviceSchemaI = {
  [AdvisorLegalAdviceFieldNames.CONTENT]: "",
  [AdvisorLegalAdviceFieldNames.TYPE]: TypeAdvisorLegal.toUser,
  [AdvisorLegalAdviceFieldNames.USER_IDS]: [],
  [AdvisorLegalAdviceFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  legalAdviceName?: string;
  initialValue?: AdvisorLegalAdviceSchemaI;
  legalAdviceId?: number;
  adviseId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  minDateAdvisor?: Date | undefined;  
  senderDocumentManagement?: any;
  initialLegalAdvice?: any;
  defaultStatus?: string
}

// const uniqueData = (listSupervisor: any) => Array.from(new Set(listSupervisor?.map((Supervisor: BasedUser) => Supervisor.id)))
//   .map(id => listSupervisor?.find((Supervisor: BasedUser) => Supervisor.id === id));

export const SupervisorAdviceForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.supervisorAdvice.title.titlePage",
    legalAdviceName,
    initialValue = initialEmptyValue,
    legalAdviceId,
    adviseId,
    isOpen = false,
    setIsOpen,
    module = Module.get(ModuleKeys.ADVISE),
    senderDocumentManagement,
    initialLegalAdvice,
    defaultStatus = LegalAdviceStatusContent.get(LegalAdviceStatusKey.CONSULTATION_COMPLETED)!,
  } = props;
  const [files, setFiles] = useState<any>([]);
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const [listStatus, setListStatus] = useState<any>([]);

  const form = useForm<any>({
    resolver: yupResolver(SupervisorLegalAdviceSchema),
    defaultValues: initialValue,
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: !adviseId ? defaultStatus : undefined,
    modules: ModuleFields.ADVISE_NAME.module,
    queryKey: "LEGAL_ADVICE_SUPERVISOR",
  });

  const { data: getSupervisorLegalAdvice, isLoading } =
    useGetAdvisorLegalAdvice({
      request: { legalAdviceId, adviseId },
      config: {
        enabled: !!legalAdviceId && !!adviseId,
      },
    });

  const {
    data: getSupervisorLegalAdviceList,
    isLoading: isLoadingSupervisorList,
  } = useGetAdvisorLegalAdviceList({
    request: { legalAdviceId },
    config: {
      enabled: !!legalAdviceId,
    },
  });

  const { mutateAsync: createSupervisorLegalAdvice, isPending } =
    useCreateAdvisorLegalAdvice({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const {
    mutateAsync: updateSupervisorLegalAdviceDetail,
    isPending: isLoadingUpdateSupervisor,
  } = useUpdateAdvisorLegalAdviceDetail({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(titlePopup),
          })
        );
        onCloseForm(true);
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    if (adviseId) {
      await updateSupervisorLegalAdviceDetail({
        legalAdviceId,
        adviseId,
        data: {
          ...data,
          status: +data?.status,
        },
      });
      return;
    }
    await createSupervisorLegalAdvice({
      legalAdviceId,
      data: {
        ...data,
        ...(data?.status && { status: +data?.status }),
      },
    });
  };

  useEffect(() => {
    const listLegalAdvice = getSupervisorLegalAdviceList?.filter(advice=>!advice?.superVisor)?.map(advice=>advice?.user) ?? []
    if (getSupervisorLegalAdvice) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { receiverUsers,user, department, type, ...restGetSupervisorLegalAdvice } =
        getSupervisorLegalAdvice;
      restGetSupervisorLegalAdvice?.attachments &&
        setFiles(
          restGetSupervisorLegalAdvice.attachments?.map((item: any) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          })
        );
      form.reset({
        ...initialValue,
        ...restGetSupervisorLegalAdvice,
        [AdvisorLegalAdviceFieldNames.STATUS]: initialLegalAdvice?.status?.id,
        [AdvisorLegalAdviceFieldNames.USER_IDS]: listLegalAdvice,
      });
     } else {
      form.reset({
        ...initialValue,
        ...(getSearchStatusQuery?.data && {
          [AdvisorLegalAdviceFieldNames.STATUS]: getSearchStatusQuery?.data?.find(
            (status) => status?.name === defaultStatus
          )?.id,
        }),
        [AdvisorLegalAdviceFieldNames.USER_IDS]: listLegalAdvice,
      });
    }
  }, [getSupervisorLegalAdvice, getSearchStatusQuery?.data, getSupervisorLegalAdviceList, initialLegalAdvice]);
  
  const handleChangeRadioType = (
    _event: React.ChangeEvent<HTMLInputElement>,
    value: string | number | boolean
  ) => {
    const listLegalAdvice = getSupervisorLegalAdviceList?.filter(advice=>!advice?.superVisor)?.map(advice=>advice?.user) ?? []
    form.setValue(
      AdvisorLegalAdviceFieldNames.STATUS,
      !value
        ? listStatus?.find(
            (status: any) =>
              status?.name ===
              LegalAdviceStatusContent.get(
                LegalAdviceStatusKey.CONSULTATION_COMPLETED
              )
          )?.id
        : listStatus?.find(
            (status: any) =>
              status?.name ===
              LegalAdviceStatusContent.get(
                LegalAdviceStatusKey.SUPERVISOR_CONSULTED
              )
          )?.id
    );
    form.setValue(
      AdvisorLegalAdviceFieldNames.USER_IDS,
      value
        ? listLegalAdvice
        : initialLegalAdvice?.pic
        ? [initialLegalAdvice?.pic]
        : []
    );
  };

  useEffect(()=>{
    const fetch = async()=>{
      try{
        const response = await getStatusListNames({
          names: [
            LegalAdviceStatusContent.get(
              LegalAdviceStatusKey.SUPERVISOR_CONSULTED
            )!,
            LegalAdviceStatusContent.get(
              LegalAdviceStatusKey.CONSULTATION_COMPLETED
            )!,
          ],
          modules: [ModuleFields.ADVISE_NAME.module],
        });
        setListStatus(response?.statusResponses)
      }
      catch(errors){
      }
    }
    fetch()
  },[])
  if (isLoading || isLoadingSupervisorList || isPending) return;

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("legalAdvice.supervisorAdvice.title.name")}
                </Typography>
                <Typography>{legalAdviceName}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`legalAdvice.supervisorAdvice.title.supervisor`)}
                </label>
                <Typography>
                  {adviseId
                    ? `${getSupervisorLegalAdvice?.user?.name} (${getSupervisorLegalAdvice?.user?.email}) - ${getSupervisorLegalAdvice?.user?.department?.name}`
                    : `${senderDocumentManagement?.name} (${
                        senderDocumentManagement?.email
                      }) - ${
                        senderDocumentManagement?.departmentName ??
                        senderDocumentManagement?.department?.name
                      }`}
                </Typography>
              </Grid>
              {getSupervisorLegalAdviceList && (
                <ListAdvisorLegalAdvice
                  data={getSupervisorLegalAdviceList?.filter(
                    (supervisor) =>
                      supervisor?.user?.id !==
                        getSupervisorLegalAdvice?.user?.id ||
                      (supervisor?.user?.id ===
                        getSupervisorLegalAdvice?.user?.id &&
                        !supervisor?.superVisor)
                  )}
                />
              )}
              <Grid item width={"100%"}>
                <RadioGroupField
                  isNumber
                  items={SupervisorAdviceOptions}
                  name={AdvisorLegalAdviceFieldNames.TYPE}
                  error={
                    form.formState.errors[
                      AdvisorLegalAdviceFieldNames.TYPE
                    ] as FieldError
                  }
                  onChangeRadioGroup={handleChangeRadioType}
                  defaultValue={SupervisorAdviceOptions?.[0]?.value as number}
                />
              </Grid>
              <Grid item width={"100%"} display="none">
                <FormSelectButton
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.STATUS}
                  label={t(`legalAdvice.supervisorAdvice.title.status`)}
                  placeholder={t(
                    `legalAdvice.supervisorAdvice.placeHolder.status`
                  )}
                  keyQuery={"status-query-advisor"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusListNames({
                        names: [
                          LegalAdviceStatusContent.get(
                            LegalAdviceStatusKey.SUPERVISOR_CONSULTED
                          )!,
                          LegalAdviceStatusContent.get(
                            LegalAdviceStatusKey.CONSULTATION_COMPLETED
                          )!,
                          keyword,
                        ],
                        modules: [ModuleFields.ADVISE_NAME.module],
                      });
                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.supervisorAdvice.title.${AdvisorLegalAdviceFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.supervisorAdvice.placeHolder.${AdvisorLegalAdviceFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={!adviseId}
                  preview={!!adviseId}
                  files={files}
                  setFiles={setFiles}
                  title={t(`legalAdvice.supervisorAdvice.title.file`)}
                  inputId="supervisorAdvice"
                />
              </Grid>
              {/* <Grid item width={"100%"}>
                <FormCheckbox
                  control={form.control}
                  name={AdvisorLegalAdviceFieldNames.FINISH}
                  label={t(
                    `legalAdvice.supervisorAdvice.title.completeAdvisor`
                  )}
                  inputTransform={(value: boolean) => value != false}
                  outputTransform={(bool) => (bool ? true : false)}
                />
              </Grid> */}
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AdvisorLegalAdviceFieldNames.USER_IDS}
                    label={t("legalAdvice.supervisorAdvice.title.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user?.name ?? "",
                        departmentName: user.department?.name,
                        email: user?.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                        option?.department?.name ??
                        option?.departmentName ??
                        option?.departmentResponse?.name ??
                        ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"supervisorAdvice/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={AdvisorLegalAdviceFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave={`common.button.send`}
              loading={
                isLoadingSupervisorList ||
                isLoadingUpdateSupervisor ||
                isPending
              }
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit(
                    castAdvisorLegalAdviceRequestSchemaToDTO({
                      ...form.getValues(),
                      attachmentIds: attachments,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
