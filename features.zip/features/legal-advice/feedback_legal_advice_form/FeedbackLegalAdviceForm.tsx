import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import {
  castFeedbackLegalAdviceRequestSchemaToDTO,
  FeedbackLegalAdviceFieldNames,
  FeedbackLegalAdviceSchema,
  FeedbackLegalAdviceSchemaI,
} from "@/models/legal-advice/FeedbackLegalAdvice";
import { useCreateFeedbackLegalAdvice } from "@/apis/service/legal-advice/feedbackLegalAdvice";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import { useQueryClient } from "@tanstack/react-query";

const initialEmptyValue: FeedbackLegalAdviceSchemaI = {
  [FeedbackLegalAdviceFieldNames.USERS]: [],
  [FeedbackLegalAdviceFieldNames.DEADLINE]: "",
  [FeedbackLegalAdviceFieldNames.CONTENT]: "",
  [FeedbackLegalAdviceFieldNames.REMIND]: undefined,
};

export interface FeedbackLegalAdviceTypeFormProps {
  titlePopup?: string;
  initialValue?: any;
  legalAdviceId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  minDateReturnAdvice?: Date | undefined;
  senderDocumentManagement?: any;
}

export const FeedbackLegalAdviceForm = (
  props: FeedbackLegalAdviceTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.feedbackLegalAdvice.title.titlePopup",
    initialValue = initialEmptyValue,
    legalAdviceId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.ADVISE),
    minDateReturnAdvice = undefined,
    senderDocumentManagement
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();
  const form = useForm<any>({
    resolver: yupResolver(FeedbackLegalAdviceSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createFeedbackLegalAdvice, isPending } =
    useCreateFeedbackLegalAdvice({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          queryClient.invalidateQueries({
            queryKey: [`request-feedback-${legalAdviceId}`]
          })
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;
    await createFeedbackLegalAdvice({
      legalAdviceId,
      data: restData,
    });
  };

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("legalAdvice.feedbackLegalAdvice.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`legalAdvice.feedbackAdvice.title.sender`)}
                </label>
                <Typography>
                  {`${senderDocumentManagement?.name} (${
                    senderDocumentManagement?.email
                  }) - ${
                    senderDocumentManagement?.departmentName ??
                    senderDocumentManagement?.department?.name
                  }`}
                </Typography>
              </Grid>
              <Grid item width={"100%"}>
                <DateTimeInput
                  name={FeedbackLegalAdviceFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.feedbackLegalAdvice.title.deadline`)}
                  minDate={minDateReturnAdvice}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FeedbackLegalAdviceFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.feedbackLegalAdvice.title.${FeedbackLegalAdviceFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.feedbackLegalAdvice.placeHolder.${FeedbackLegalAdviceFieldNames.CONTENT}`
                  )}
                  required
                  minRows={5}
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={FeedbackLegalAdviceFieldNames.USERS}
                    label={t("legalAdvice.feedbackLegalAdvice.title.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const selectedDepartments = form.getValues("departments");
                      if (selectedDepartments?.length) {
                        params.departmentIds = selectedDepartments;
                      }
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"feedbackLegalAdvice/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={FeedbackLegalAdviceFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castFeedbackLegalAdviceRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
