import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import {
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import {
  RequestVendorFieldNames,
  RequestVendorSchema,
  RequestVendorSchemaI,
} from "@/models/legal-advice/RequestVendor";
import { useCreateRequestVendor } from "@/apis/service/legal-advice/requestVendor";
import { useSearchStatus } from "@/hooks/useSearchStatus";

const initialEmptyValue: RequestVendorSchemaI = {
  [RequestVendorFieldNames.DEADLINE]: "",
  [RequestVendorFieldNames.USERS]: [],
  [RequestVendorFieldNames.REMIND]: undefined,
};

export interface RequestVendorTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestVendorSchemaI;
  legalAdviceId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  maxDateReturnAdvice?: Date | undefined;
  senderDocumentManagement?: any;
  defaultStatus?: string;
}

export const RequestVendorForm = (props: RequestVendorTypeFormProps) => {
  const {
    titlePopup = "legalAdvice.requestVendor.title.titlePopup",
    initialValue = initialEmptyValue,
    legalAdviceId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.ADVISE),
    maxDateReturnAdvice = undefined,
    senderDocumentManagement,
    defaultStatus = LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.REQUEST_VENDOR
    )!,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(RequestVendorSchema),
    defaultValues: initialValue,
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: defaultStatus,
    modules: ModuleFields.ADVISE_NAME.module,
    queryKey: "LEGAL_ADVICE_REQUEST_VENDOR",
  });

  const { mutateAsync: createRequestVender, isPending } =
    useCreateRequestVendor({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { user, ...restData } = data;
    await createRequestVender({
      legalAdviceId,
      data: {
        ...restData,
        ...(getSearchStatusQuery?.data && {
          [RequestVendorFieldNames.STATUS]: getSearchStatusQuery?.data?.find(
            (status) => status?.name === defaultStatus
          )?.id,
        }),
      },
    });
  };

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("legalAdvice.requestVendor.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestVendorFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.requestVendor.title.deadline`)}
                  required
                  maxDate={maxDateReturnAdvice}
                  placeholder="dd/mm/yyyy"
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={RequestVendorFieldNames.USERS}
                    label={t("legalAdvice.requestVendor.title.receiver")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const selectedDepartments = form.getValues("departments");
                      if (selectedDepartments?.length) {
                        params.departmentIds = selectedDepartments;
                      }
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"requestVendor/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={RequestVendorFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    userIds: form
                      .getValues()
                      .userIds?.map((user: any) => user?.id),
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
