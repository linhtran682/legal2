import { GLOBAL_SPACING } from "@/constants/format";
import { LegalAdviceAdvise } from "@/models/legal-advice/LegalAdviceDetail";
import { Box } from "@mui/material";
import { FC, useEffect, useState } from "react";
import AdviceListItem from "./AdviceListItem";
import { useQuery } from "@tanstack/react-query";
import { getLegalAdviceAdviseList } from "@/apis/service/legal-advice/legalAdvice";
import { AdvisorLegalAdviceForm } from "../advisor_legal_advice_form/AdvisorLegalAdviceForm";
import { SupervisorAdviceForm } from "../advisor_legal_advice_form/SupervisorAdviceForm";

interface AdviceListProps {
  legalAdviceId: number;
  legalAdviceName?: string;
  initialLegalAdvice?: any;
  handleReloadLegalAdviceQuery?: ()=>void
}

const AdviceList: FC<AdviceListProps> = (props) => {
  const { legalAdviceId, legalAdviceName, initialLegalAdvice } = props;
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedAdvise, setSelectedAdvise] = useState<
    LegalAdviceAdvise | undefined
  >(undefined);

  useEffect(() => {
    legalAdviceId && getAdviseListQuery.refetch();
  }, [legalAdviceId]);

  const getAdviseListQuery = useQuery({
    queryKey: ["get-legal-advice-advise-list", legalAdviceId],
    queryFn: () => getLegalAdviceAdviseList(legalAdviceId),
    enabled: !!legalAdviceId,
  });

  const handleEditClick = (advise: LegalAdviceAdvise) => {
    setSelectedAdvise(advise);
    setPopupVisible(true);
  };

  const onPopupClose = async() => {
    setPopupVisible(false);
    setSelectedAdvise(undefined);
    getAdviseListQuery?.refetch();
    props?.handleReloadLegalAdviceQuery && await props.handleReloadLegalAdviceQuery()
  };
  
  return getAdviseListQuery?.data?.responses?.length ? (
    <Box display={"flex"} flexDirection={"column"} gap={GLOBAL_SPACING}>
      {(getAdviseListQuery?.data?.responses ?? [])?.map(
        (advise: LegalAdviceAdvise) => (
          <AdviceListItem
            key={advise.id.toString()}
            onEditClick={() => handleEditClick(advise)}
            advise={advise}
          />
        )
      )}
      {popupVisible &&
        (!selectedAdvise?.superVisor ? (
          <AdvisorLegalAdviceForm
            legalAdviceId={legalAdviceId}
            legalAdviceName={legalAdviceName}
            isOpen={popupVisible}
            adviseId={selectedAdvise?.id}
            setIsOpen={onPopupClose}
            senderDocumentManagement={selectedAdvise?.user}
            initialLegalAdvice={initialLegalAdvice}
          />
        ) : (
          <SupervisorAdviceForm
            legalAdviceId={legalAdviceId}
            legalAdviceName={legalAdviceName}
            isOpen={popupVisible}
            adviseId={selectedAdvise?.id}
            setIsOpen={onPopupClose}
            senderDocumentManagement={selectedAdvise?.user}
            initialLegalAdvice={initialLegalAdvice}
          />
        ))}
    </Box>
  ) : null;
};

export default AdviceList;
