import { getAssignedPerson } from '@/apis/service/assignment/Assignment';
import { getDepartmentHeads, getLegalDepartments } from '@/apis/service/department/department';
import { getField, getFields } from '@/apis/service/field/Field';
// import { getStatus, getStatusList, getStatusListNames } from '@/apis/service/status/Status';
import { getUsers } from '@/apis/service/user/User';
import { FormActionButtons } from '@/components/commons/action_button/FormActionButtons';
import { FormAsyncSelect } from '@/components/commons/form_inputs/FormAsyncSelect';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormSelect } from '@/components/commons/form_inputs/FormSelect';
// import { FormSelectButton } from '@/components/commons/form_inputs/FormSelectButton';
import { FormTextArea } from '@/components/commons/form_inputs/FormTextArea';
import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import DateInput from '@/components/commons/inputs/date_input/DateInput';
import DateTimeInput from '@/components/commons/inputs/date_time_input/DateTimeInput';
import DropPreviewFileUploadComponent from '@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload';
import { COLOR_TYPE } from '@/constants/color';
import { GLOBAL_SPACING } from '@/constants/format';
import { LegalAdviceStatus, LegalAdviceStatusContent, LegalAdviceStatusKey, ModuleFields } from '@/constants/general';
import { VALIDATION_MSG } from '@/constants/message';
import { formInputSxProps } from '@/constants/theme';
import { AppContext } from '@/context/AppContext';
import { ReminderPickerSubForm } from '@/features/reminder_template/reminder_picker/ReminderPickerSubForm';
import { FieldDTO } from '@/models/field/Field';
import { LegalAdviceBodyReceive, LegalAdviceBodySend, LegalAdviceDetailFields, SaveLegalAdviceRequestSchema } from '@/models/legal-advice/LegalAdviceDetail';
import { castReminderInputToReminderSchema, castReminderSchemaToSaveReminderDTO } from '@/models/reminder_template/ReminderDTO';
import { StatusDTO, StatusFieldNames } from '@/models/status/Status';
import { BasedUser, UserProfileDTO } from '@/models/user/User';
import { yupResolver } from '@hookform/resolvers/yup';
import { FormHelperText, Grid, Stack, Typography } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { add } from 'date-fns';
import { ForwardedRef, forwardRef, ReactNode, useContext, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import * as Yup from "yup";
import AdviceList from './AdviceList';
import { FormTextField } from '@/components/commons/form_inputs/FormTextField';


export interface LegalAdviceFormProps {
  handleReloadLegalAdviceQuery?: () => void;
  formMode?: "create" | "update";
  initialValue?: any;
  onSubmit: (data: LegalAdviceBodySend) => void;
  onSubmitDraft?: (data: LegalAdviceBodySend) => void;
  onCancel: () => void;
  loading?: boolean;
  initialValueReceive?: LegalAdviceBodyReceive;
  children?: ReactNode;
  getStatusListQuery?: any;
}
const initialEmptyValue = {
  legalAccessType: 2,
  checkDeptHeadFlag: true,
  checkDivisionFlag: true,
}

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}

export interface LegalAdviceFormRef {
  getParams: () => LegalAdviceBodySend;
}

const LegalAdviceForm = forwardRef(function LegalAdviceForm(
  props: LegalAdviceFormProps,
  ref: ForwardedRef<LegalAdviceFormRef>
) {
  const { formMode, getStatusListQuery } = props;
  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  // const [departmentId, setDepartmentId] = useState<string>('');

  useImperativeHandle(ref, () => ({
    getParams: () => handleSaveParams()
  }))

  const validateVendorDate = Yup.object().shape({
    [LegalAdviceDetailFields.VENDOR_RESPONSE_DATE]: Yup.mixed()
      .when('status', {
        is: () => isRequestVendorAdvice,
        then: () => Yup.date().typeError(VALIDATION_MSG.ENTER_VALID_VALUE).required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }),
  });

  const isStatusDone = useMemo(() => props?.initialValueReceive?.status?.name
    === LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.DONE
    ), [props?.initialValueReceive?.status]);
  const isRequestInformation = useMemo(() => props?.initialValueReceive?.status?.name
    === LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.REQUEST_ADDITIONAL
    ), [props?.initialValueReceive?.status]);

  const form = useForm({
    resolver: yupResolver(
      SaveLegalAdviceRequestSchema.concat(validateVendorDate)
    ),
    defaultValues: JSON.parse(
      JSON.stringify({
        ...initialEmptyValue,
        ...(props.formMode === "create" && {
          status: LegalAdviceStatus.get(LegalAdviceStatusKey.REQUEST_ADVICE),
        }),
      })
    ),
    mode: "onBlur",
    disabled:
      !appContext.meCanWrite
      || (props.formMode === "update" && !ownRole.includes(1))
      || isStatusDone
      || (props.formMode === "update" && !isRequestInformation && !props.initialValueReceive?.isDraft),
  });

  const disableSpecialFields = useMemo(() => {
    return !appContext.meCanWrite
      || (props.formMode === "update"
        && !ownRole.includes(1)
        && !ownRole.includes(2)
        && !ownRole.includes(3)
        && !ownRole.includes(4)
        && !ownRole.includes(5)
      )
      || !!props.loading
      || isStatusDone
  }, [appContext.meCanWrite, props.formMode, ownRole, props.loading, isStatusDone])

  useEffect(() => {
    if (props?.initialValue) {
      form.reset({
        ...props?.initialValue
      })
    }
    if (formMode === 'create') {
      getAssignedPersonQuery.refetch().then((res) => {
        form?.setValue(LegalAdviceDetailFields.RECEIVER_USER_IDS, res.data?.users ?? [])
      })
      form?.setValue(LegalAdviceDetailFields.RESPONSIBLE_USERS, appContext?.me ? [appContext?.me] : [])
    }
  }, [props?.initialValue])

  useEffect(() => {
    if (props.initialValueReceive) {
      if (props?.initialValueReceive?.attachments) {
        let attachments: any[] = [];
        const attachmentsSharepoint: any[] = [];

        if (props?.initialValueReceive?.attachments.length) {
          attachments = props.initialValueReceive.attachments?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setFiles([...attachments, ...attachmentsSharepoint]);
      }
      const files =
        disableSpecialFields
          ? props.initialValueReceive?.attachments
          : props.initialValueReceive?.attachments?.length
            ? props.initialValueReceive?.attachments
            : null;
      props.initialValueReceive &&
        form.reset({
          ...props.initialValueReceive,
          files,
          fieldId: props.initialValueReceive?.field?.id,
          status: props.initialValueReceive?.status?.id,
          receiverUserIds: props?.initialValueReceive?.receiverUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          responsibleUsers: props?.initialValueReceive?.responsibleUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          relatedUserIds: props?.initialValueReceive?.legalAdviceRelateUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          assignmentUsers: props?.initialValueReceive?.assignmentUsers?.map((user: any) => ({
            ...user,
            department: user?.departmentResponse
          })),
          // legalAccessType: props?.initialValueReceive?.legalAccessType ?? 2,
          vendorResponseDate: props?.initialValueReceive?.vendorResponseDate
            ? new Date(props?.initialValueReceive?.vendorResponseDate)
            : undefined,
          responseDate: props?.initialValueReceive?.consultingDeadlineType === 1 && props?.initialValueReceive?.responseDate
            ? new Date(props?.initialValueReceive?.responseDate)
            : undefined,
          urgentResponseDate: props?.initialValueReceive?.consultingDeadlineType === 2 && props?.initialValueReceive?.responseDate
            ? new Date(props?.initialValueReceive?.responseDate)
            : undefined,
          remind: props.initialValueReceive.remind?.title
            ? castReminderInputToReminderSchema(
              props.initialValueReceive!.remind!
            )
            : undefined,
        });
      if (props.initialValueReceive?.userLastActionAndLegalAdviceRoleResponse?.userLastActionAndRoleList?.length) {
        const { userLastActionAndLegalAdviceRoleResponse: { userLastActionAndRoleList } } = props.initialValueReceive;
        const roleList = userLastActionAndRoleList?.map((ele) => ele.role)
        setOwnRole(roleList);
      } else {
        setOwnRole([]);
      }
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValueReceive]);

  const getLegalDepartmentQuery = useQuery({
    queryKey: ['legal-advice/get-legal-department'],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(response?.departments?.length ? response?.departments?.[0] : null)
        // setDepartmentId(deepestId?.id ?? '')
        return deepestId?.id ?? null
      } catch (error) {
      }
      return null
    },
    placeholderData: prev => prev,
  })

  const getAssignedPersonQuery = useQuery({
    queryKey: ['legal-advice/get-legal-assigned-person'],
    queryFn: () => getAssignedPerson(),
    placeholderData: prev => prev,
    enabled: false
  })

  const getDepartmentHeadQuery = useQuery({
    queryKey: ['legal-advice/get-department-heads', getLegalDepartmentQuery?.data],
    queryFn: () => getDepartmentHeads(getLegalDepartmentQuery?.data as string),
    placeholderData: prev => prev,
    enabled: !!getLegalDepartmentQuery?.data
  })


  const deadlineType = form.watch(LegalAdviceDetailFields.DEADLINE_TYPE)
  const status = form.watch(LegalAdviceDetailFields.STATUS)
  const checkDeptHeadFlag = form.watch('checkDeptHeadFlag')
  const checkDivisionFlag = form.watch('checkDivisionFlag')
  // const bookingFlag = form.watch('bookingFlag')

  const sendToError = !checkDeptHeadFlag && !checkDivisionFlag
  const isRequestVendorAdvice = getStatusListQuery?.data
    ?.find((ele: StatusDTO) => ele.id === Number(status))
    ?.name?.toLocaleLowerCase() === 'yêu cầu vendor tư vấn';

  const handleSaveParams = () => {
    // let attachments: number[] = [];
    // if (files.length > 0) {
    // const filterFile: any = [];
    // const filterFileId: number[] = [];

    // files.filter((item: any) => {
    //   if (item?.id === undefined) {
    //     filterFile.push(item);
    //   } else {
    //     filterFileId.push(item?.id);
    //   }
    // });
    // if (filterFile.length > 0) {
    //   const response = await GetListIdFile(filterFile);
    //   const formatResponse: number[] =
    //     response.fileUploadResponses.map(
    //       (item: FileInfo) => item.fileId
    //     );
    //   attachments = [...formatResponse, ...filterFileId];
    // } else {
    // attachments = [...filterFileId];
    // }
    // }

    const receiverUsers = form.getValues("receiverUserIds")
    const relatedUsers = form.getValues("relatedUserIds")
    const responsibleUsers = form.getValues("responsibleUsers")

    const formValues = form.getValues()
    const params: LegalAdviceBodySend = {} as LegalAdviceBodySend;
    params.legalAdviceName = formValues.legalAdviceName;
    params.fieldId = Number(formValues.fieldId);
    // params.attachmentIds = attachments;
    params.attachmentIds = files?.map((item: any) => item?.id) ?? [];
    params.status = Number(formValues.status)
    params.reason = formValues.reason;
    params.vendorResponseDate = formValues.vendorResponseDate ? formValues.vendorResponseDate?.toISOString() : undefined;
    params.summaryIssue = formValues.summaryIssue;
    params.problem = formValues.problem;
    params.opinion = formValues.opinion;
    params.consultingDeadlineType = formValues.consultingDeadlineType;

    if (formValues.responseDate && formValues.consultingDeadlineType === 1) {
      params.responseDate = formValues.responseDate?.toISOString();
    }
    if (formValues.urgentResponseDate && formValues.consultingDeadlineType === 2) {
      params.responseDate = formValues.urgentResponseDate?.toISOString();
      params.urgentResponseReason = formValues.urgentResponseReason;
    }

    const departmentIds = receiverUsers.map((user: BasedUser) => user?.department?.id);
    params.departments = Array.from(new Set(departmentIds)) ?? [];
    params.receiverUserIds = receiverUsers?.map((ite: any) => ite.id);
    params.responsibleUsers = responsibleUsers?.map((ite: any) => ite.id);
    params.relatedUserIds = relatedUsers?.map((ite: any) => ite.id);

    params.remind =
      (formMode === 'create' && !!form.getValues("remind")?.id)
        || (formMode === 'update' && !!form.getValues("remind")?.title)
        ? {
          ...castReminderSchemaToSaveReminderDTO(
            form.getValues("remind")!
          ),
        }
        : {
          title: "",
          description: "",
          module: 2,
          receivedTitle: [],
          receivingDepartment: [],
          remindContents: [],
          relatedUsers: []
        };

    // params.legalAccessType = formValues.legalAccessType;
    params.checkDivisionFlag = formValues.checkDivisionFlag ? 1 : 0;
    params.checkDeptHeadFlag = formValues.checkDeptHeadFlag ? 1 : 0;
    params.bookingFlag = formValues.bookingFlag ? 1 : 0;

    return params
  }

  const disableCheckbox = !appContext.meCanWrite ||
    (props.formMode === "update" && !ownRole.includes(1))
    || isStatusDone
    || (props.formMode === "update" && !isRequestInformation && !props.initialValueReceive?.isDraft)


  const watchLc = form.watch(LegalAdviceDetailFields.RECEIVER_USER_IDS);
  const watchPic = form.watch(LegalAdviceDetailFields.RESPONSIBLE_USERS);

  const excludedPicIds = useMemo(() => {
    return (watchLc ?? []).map((item: BasedUser) => item.id)
  }, [watchLc])

  const excludedIds = useMemo(() => { // trường người tư vấn
    const list = [];
    const myId = appContext.me?.id;
    const deptHeadId = getDepartmentHeadQuery?.data?.deptHead?.id;
    myId && list.push(myId);
    deptHeadId && list.push(deptHeadId);
    watchPic?.length && list.push(...((watchPic ?? []).map((item: BasedUser) => item.id)))
    return list;
  }, [appContext.me?.id, getDepartmentHeadQuery?.data?.deptHead, watchPic]);

  const showHead = useMemo(() => {
    const myId = appContext.me?.id;
    const deptHeadId = getDepartmentHeadQuery?.data?.deptHead?.id;
    const divHeadId = getDepartmentHeadQuery?.data?.division?.id;
    const picId = props.initialValueReceive?.pic?.id;
    let dept = false;
    let div = false;
    if (props.formMode === 'create') {
      dept = !!myId && !!deptHeadId && (deptHeadId !== myId);
      div = !!myId && !!divHeadId && (divHeadId !== myId);
    }
    if (props.formMode === 'update') {
      dept = !!picId && !!deptHeadId && (deptHeadId !== picId);
      div = !!picId && !!divHeadId && (divHeadId !== picId)
    }
    return {
      dept, div
    }
  }, [
    appContext.me?.id,
    getDepartmentHeadQuery?.data?.deptHead,
    getDepartmentHeadQuery?.data?.division,
    props.formMode,
    props.initialValueReceive?.pic
  ]);

  return (
    <>
      <Grid
        container
        className="form-wrapper"
      // style={{ marginTop: props.formMode === "update" ? 24 : 0 }}
      >
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              {!appContext.meCanWrite
                || (props.formMode === "update")
                // ||  (props.formMode === "update" && !ownRole.includes(1))
                ? null
                : <Grid item width={"100%"}>
                  <FormTextField
                    control={form.control}
                    name={LegalAdviceDetailFields.LEGAL_ADVICE_NAME}
                    label={t(
                      `legalAdvice.label.${LegalAdviceDetailFields.LEGAL_ADVICE_NAME}`
                    )}
                    placeHolder={t(
                      `legalAdvice.fields.${LegalAdviceDetailFields.LEGAL_ADVICE_NAME}`
                    )}
                    required
                    // minRows={2}
                    disabled={
                      !appContext.meCanWrite
                      // ||
                      // (props?.formMode === "update" && !ownRole.includes(1))
                    }
                  />
                </Grid>}
              {/* {formMode === "update" && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={[
                      { label: "Public", value: 2 },
                      { label: "Private", value: 1 },
                    ]}
                    name={LegalAdviceDetailFields.LEGAL_ACCESS_TYPE}
                    isDisabled={
                      !appContext.meCanWrite ||
                      (props.formMode === "update" &&
                        !(ownRole.includes(1) || ownRole.includes(2)))
                    }
                  />
                </Grid>
              )} */}
              {/* {formMode === 'update' ? <Grid item width={"100%"}>
                <FormSelectButton
                  control={form.control}
                  name={LegalAdviceDetailFields.STATUS}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.STATUS}`
                  )}
                  placeholder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.STATUS}`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={`legal-advice-status-query-${props?.initialValueReceive?.id}`}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      if (props?.formMode === "create") {
                        const response = await getStatusListNames({
                          names: [
                            LegalAdviceStatusContent.get(
                              LegalAdviceStatusKey.REQUEST_ADVICE
                            )!,
                            keyword,
                          ],
                          modules: [ModuleFields.ADVISE_NAME.module],
                        });
                        return response?.statusResponses || [];
                      }
                      if (props?.formMode === "update"
                        && props?.initialValueReceive?.status?.name === LegalAdviceStatusContent.get(
                          LegalAdviceStatusKey.DONE
                        )!) {
                        const response = await getStatusListNames({
                          names: [
                            LegalAdviceStatusContent.get(
                              LegalAdviceStatusKey.DONE
                            )!,
                            LegalAdviceStatusContent.get(
                              LegalAdviceStatusKey.REQUEST_ADVICE
                            )!,
                            LegalAdviceStatusContent.get(
                              LegalAdviceStatusKey.FEEDBACK_ADVICE
                            )!,
                          ],
                          modules: [ModuleFields.ADVISE_NAME.module],
                        });
                        return response?.statusResponses || [];
                      }
                      if (props?.formMode === "update"
                        && props?.initialValueReceive?.status?.name === LegalAdviceStatusContent.get(
                          LegalAdviceStatusKey.REQUEST_ADDITIONAL
                        )!) {
                        const response = await getStatusListNames({
                          names: [
                            LegalAdviceStatusContent.get(
                              LegalAdviceStatusKey.REQUEST_ADDITIONAL
                            )!,
                            LegalAdviceStatusContent.get(
                              LegalAdviceStatusKey.ADDITIONAL_INFORMATION
                            )!,
                          ],
                          modules: [ModuleFields.ADVISE_NAME.module],
                        });
                        return response?.statusResponses || [];
                      }
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.ADVISE_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  // required
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" && !ownRole.includes(1))
                    || props?.initialValueReceive?.status?.name === LegalAdviceStatusContent.get(
                      LegalAdviceStatusKey.DONE)
                    || (props.formMode === "update" && !isRequestInformation)
                    || props.formMode === "create"
                  }
                />
              </Grid> : null} */}
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={formMode === "create"}
                  preview={formMode === "update"}
                  name={LegalAdviceDetailFields.FILES}
                  control={form.control}
                  disabled={disableSpecialFields}
                  files={files}
                  preventOnchange
                  setFiles={(files) => {
                    setFiles(files);
                    form.setValue(LegalAdviceDetailFields.FILES, files ?? []);
                    form.trigger(LegalAdviceDetailFields.FILES)
                  }}
                  title={t(
                    `legalAdvice.label.${LegalAdviceDetailFields.ATTACHMENTS}`
                  )}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={LegalAdviceDetailFields.FIELD_ID}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.FIELD}`
                  )}
                  placeholder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.FIELD}`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"field-query"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getFields({
                        name: keyword,
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                      });

                      return response?.fieldResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getField(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as FieldDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" && !ownRole.includes(1))
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={LegalAdviceDetailFields.REASON}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.REASON}`
                  )}
                  placeHolder={t(
                    `legalAdvice.placeholder.${LegalAdviceDetailFields.REASON}`
                  )}
                  required
                  minRows={3}
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" && !ownRole.includes(1))
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={LegalAdviceDetailFields.SUMMARY_ISSUE}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.SUMMARY_ISSUE}`
                  )}
                  placeHolder={t(
                    `legalAdvice.placeholder.${LegalAdviceDetailFields.SUMMARY_ISSUE}`
                  )}
                  required
                  minRows={3}
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" && !ownRole.includes(1))
                  }
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={LegalAdviceDetailFields.PROBLEM}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.PROBLEM}`
                  )}
                  placeHolder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.PROBLEM}`
                  )}
                  // required
                  minRows={3}
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" && !ownRole.includes(1))
                  }
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={LegalAdviceDetailFields.OPINION}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.OPINION}`
                  )}
                  placeHolder={t(
                    `legalAdvice.placeholder.${LegalAdviceDetailFields.OPINION}`
                  )}
                  // required
                  minRows={3}
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" && !ownRole.includes(1))
                  }
                />
              </Grid>
              {/* chỉ hiện khi trạng thái là Yêu cầu vendor tư vấn */}
              {isRequestVendorAdvice && (
                <Grid item width={"100%"}>
                  <DateInput
                    name={LegalAdviceDetailFields.VENDOR_RESPONSE_DATE}
                    control={form.control}
                    label={t(
                      `legalAdvice.fields.${LegalAdviceDetailFields.VENDOR_RESPONSE_DATE}`
                    )}
                    placeholder={"dd/mm/yyyy"}
                    required
                    disabled={
                      !appContext.meCanWrite ||
                      (props.formMode === "update" && !ownRole.includes(1))
                    }
                  />
                </Grid>
              )}
              <Grid item width={"100%"}>
                <FormSelect
                  control={form.control}
                  required
                  name={LegalAdviceDetailFields.DEADLINE_TYPE}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.DEADLINE_TYPE}`
                  )}
                  placeHolder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.DEADLINE_TYPE}`
                  )}
                  options={[
                    {
                      value: 1,
                      label: t("legalAdvice.label.SOP"),
                    },
                    {
                      value: 2,
                      label: "Urgent",
                    },
                  ]}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  onChange={(event) => {
                    const value = event.target.value;
                    form.setValue(
                      LegalAdviceDetailFields.RESPONSE_DATE,
                      value === 1 ? add(new Date(), { days: 5 }) : undefined
                    );
                    form.setValue(
                      LegalAdviceDetailFields.URGENT_RESPONSE_DATE,
                      new Date()
                    );
                    form.setValue(
                      LegalAdviceDetailFields.URGENT_RESPONSE_REASON,
                      undefined
                    );
                  }}
                />
              </Grid>
              {deadlineType === 1 && (
                <Grid item width={"100%"}>
                  <DateTimeInput
                    control={form.control}
                    name={LegalAdviceDetailFields.RESPONSE_DATE}
                    required
                    label={t(
                      `legalAdvice.label.${LegalAdviceDetailFields.RESPONSE_DATE_LA}`
                    )}
                    disabled={
                      !appContext.meCanWrite ||
                      (props.formMode === "update" && !ownRole.includes(1))
                    }
                  />
                </Grid>
              )}
              {deadlineType === 2 && (
                <>
                  <Grid item width={"100%"}>
                    <DateTimeInput
                      control={form.control}
                      name={LegalAdviceDetailFields.URGENT_RESPONSE_DATE}
                      label={t(
                        `legalAdvice.label.${LegalAdviceDetailFields.URGENT_RESPONSE_DATE}`
                      )}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (props.formMode === "update" && !ownRole.includes(1))
                      }
                    />
                  </Grid>
                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={LegalAdviceDetailFields.URGENT_RESPONSE_REASON}
                      label={t(
                        `legalAdvice.label.${LegalAdviceDetailFields.URGENT_RESPONSE_REASON}`
                      )}
                      placeHolder={t(
                        `legalAdvice.label.${LegalAdviceDetailFields.URGENT_RESPONSE_REASON}`
                      )}
                      required
                      minRows={3}
                      disabled={
                        !appContext.meCanWrite ||
                        (props.formMode === "update" && !ownRole.includes(1))
                      }
                    />
                  </Grid>
                </>
              )}

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={LegalAdviceDetailFields.RESPONSIBLE_USERS}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.RESPONSIBLE_USERS}`
                  )}
                  placeholder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.RESPONSIBLE_USERS}`
                  )}
                  minCharLength={1}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });
                    return response?.users?.filter((user) => !excludedPicIds?.includes(user.id)) ?? [];
                    ;
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  required
                  getOptionKey={(option) => option.id}
                  keyQuery="legal-advice-pics"
                  isFocus
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={LegalAdviceDetailFields.RECEIVER_USER_IDS}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.ADVISOR}`
                  )}
                  placeholder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.ADVISOR}`
                  )}
                  minCharLength={1}
                  getOptions={async (keyword) => {
                    if (!getLegalDepartmentQuery.data) return [];
                    const advisorIds =
                      getAssignedPersonQuery?.data?.users?.map(
                        (user) => user.id
                      ) ?? [];
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                      departmentIds: getLegalDepartmentQuery.data
                        ? [getLegalDepartmentQuery.data]
                        : [],
                    });
                    return (
                      response?.users
                        ?.map((user, index) => ({
                          ...user,
                          rank: advisorIds?.includes(user.id) ? index : 99999,
                        }))
                        ?.sort((first, second) => first.rank - second.rank) ??
                      []
                    )?.filter((user) => !excludedIds?.includes(user?.id));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  required
                  getOptionKey={(option) => option.id}
                  keyQuery="queryAdvisor"
                  isFocus
                />
              </Grid>

              <Stack direction={'row'} width={"100%"} mt={0.5} gap={2}>
                <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA1, fontStyle: 'italic' }} >{t(`legalAdvice.label.requiredToBeSentTo`)}*:</Typography>
                <Stack gap={"1rem"}>
                  {showHead?.dept ? <CheckboxInput
                    fontSize={'1rem'}
                    checked={form.watch("checkDeptHeadFlag")}
                    borderColor={disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                    checkboxBg={disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : 'white'}
                    onChange={(value) => {
                      form.setValue(
                        "checkDeptHeadFlag",
                        value
                      );
                    }}
                    label={
                      getDepartmentHeadQuery?.data?.deptHead
                        ? `${getDepartmentHeadQuery?.data?.deptHead?.name} - Dept Head.${getDepartmentHeadQuery?.data?.deptHead?.department?.name}`
                        : t(
                          "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                        )
                    }
                    disabled={disableCheckbox || !showHead?.div}
                  /> : null}
                  {showHead?.div ? <CheckboxInput
                    fontSize={'1rem'}
                    checked={form.watch("checkDivisionFlag")}
                    borderColor={disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                    checkboxBg={disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : 'white'}
                    onChange={(value) => {
                      form.setValue(
                        "checkDivisionFlag",
                        value
                      );
                    }}
                    label={
                      getDepartmentHeadQuery?.data?.division
                        ? `${getDepartmentHeadQuery?.data?.division?.name} - Division Head.${getDepartmentHeadQuery?.data?.division?.department?.name}`
                        : t(
                          "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                        )
                    }
                    disabled={disableCheckbox || !showHead?.dept}
                  /> : null}
                  {sendToError ? (
                    <FormHelperText error>
                      {t("legalAdvice.messages.requiredToBeSentTo")}
                    </FormHelperText>
                  ) : null}
                </Stack>
              </Stack>

              {props?.initialValueReceive?.assignmentUsers?.length && <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={LegalAdviceDetailFields.ASSIGNMENT_USERS}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.ASSIGNMENT_USERS}`
                  )}
                  placeholder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.ASSIGNMENT_USERS}`
                  )}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });

                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="legal-advice-assigners"
                  disabled
                />
              </Grid>}
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, UserProfileDTO>
                  control={form.control}
                  name={LegalAdviceDetailFields.RELATED_USER_IDS}
                  label={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.RELATED_USERS}`
                  )}
                  placeholder={t(
                    `legalAdvice.fields.${LegalAdviceDetailFields.RELATED_USERS}`
                  )}
                  getOptions={async (keyword) => {
                    const response = await getUsers({
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    });

                    return response?.users ?? [];
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryRelatedUser"
                  disabled={
                    !appContext.meCanWrite ||
                    (props.formMode === "update" && !ownRole.includes(1))
                  }
                />
              </Grid>

              {formMode === "update" && props?.initialValueReceive?.id && (
                <Grid item width={"100%"}>
                  <AdviceList
                    handleReloadLegalAdviceQuery={props?.handleReloadLegalAdviceQuery}
                    legalAdviceId={props?.initialValueReceive?.id}
                    legalAdviceName={
                      props?.initialValueReceive?.legalAdviceName
                    }
                    initialLegalAdvice={props?.initialValueReceive}
                  />
                </Grid>
              )}
            </Grid>
            <ReminderPickerSubForm
              name={"remind"}
              module={ModuleFields.ADVISE_NAME.module}
              placeholder={t("menu.reminder")}
            />

            <FormActionButtons
              formMode={props.formMode}
              loading={props.loading}
              onCancel={props.onCancel}
              isDisableButonSave={isStatusDone
                || !appContext.meCanWrite
                || (props.formMode === "update" && !ownRole.includes(1))
                || (props.formMode === "update" && !isRequestInformation && !props.initialValueReceive?.isDraft)
              }
              allowDraft={props.formMode === "create" || props?.initialValueReceive?.isDraft}
              onSaveDraft={async () => {
                try {
                  const params = await handleSaveParams();
                  params.isDraft = true;
                  props?.onSubmitDraft?.(params);
                } catch (error) { }
              }}
              onSave={async () => {
                try {
                  const params = await handleSaveParams();
                  params.isDraft = false;
                  props?.onSubmit?.(params);
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid >
    </>
  );
})

export default LegalAdviceForm

