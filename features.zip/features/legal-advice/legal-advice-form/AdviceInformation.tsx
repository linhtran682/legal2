import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import { COLOR_TYPE } from '@/constants/color';
import { GLOBAL_SPACING } from '@/constants/format';
import { formInputSxProps } from '@/constants/theme';
import { LegalAdviceBodyReceive } from '@/models/legal-advice/LegalAdviceDetail';
import { Box, Grid } from '@mui/material';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';


interface AdviceInformationProps {
  initialValueReceive?: LegalAdviceBodyReceive;
  onChangeMeeting: (isMeeting: boolean) => void;
  isMeeting?: boolean;
  disabled: boolean;
}
const AdviceInformation: FC<AdviceInformationProps> = (props) => {
  const [t] = useTranslation();
  return (
    <Grid container className="form-wrapper">
      <Grid
        container
        direction={"column"}
        rowGap={GLOBAL_SPACING}
        alignItems={"center"}
        className="form-section-wrapper"
        sx={formInputSxProps}
      >
        <Grid item container direction="row" spacing={2}>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.SUCCESS.GREEN7}
                labelColor={COLOR_TYPE.SUCCESS.GREEN7}
                checked={!!props.isMeeting}
                onChange={(e) => props?.onChangeMeeting(e)}
                disabled={props.disabled}
                label={t("LEGISLATION.evaluateField.meeting")}
              />
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                disabled
                checked={!!props.initialValueReceive?.responseFlag}
                label={t("LEGISLATION.evaluateField.response")}
              />
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                disabled
                checked={!!props.initialValueReceive?.confirmFlag}
                label={t('legalAdvice.label.adviceConfirm')}
              />
            </Box>
          </Grid>
        </Grid>
        <Grid item container direction="row" spacing={2}>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                checked={!!props.initialValueReceive?.completeAdviseFlag}
                disabled
                label={t('legalAdvice.label.adviceCompleted')}
              />
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box display="flex" alignItems="center">
              <CheckboxInput
                borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                labelColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                checked={!!props.initialValueReceive?.supervisorAdviseFlag}
                disabled
                label={t('legalAdvice.label.supervisorAdvised')}
              />
            </Box>
          </Grid>
        </Grid>
      </Grid>

    </Grid>
  )
}

export default AdviceInformation