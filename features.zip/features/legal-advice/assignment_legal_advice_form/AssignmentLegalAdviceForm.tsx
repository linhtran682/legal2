import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { getLegalDepartments } from "@/apis/service/department/department";
import { BasedUser } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { useQuery } from "@tanstack/react-query";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import {
  AssignmentLegalAdviceFieldNames,
  AssignmentLegalAdviceSchema,
  AssignmentLegalAdviceSchemaI,
  castAssignmentLegalAdviceRequestSchemaToDTO,
} from "@/models/legal-advice/AssignmentLegalAdvice";
import { useCreateAssignmentLegalAdvice } from "@/apis/service/legal-advice/assignmentLegalAdvice";
import {
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { useQueryClient } from "@tanstack/react-query";

const initialEmptyValue: AssignmentLegalAdviceSchemaI = {
  [AssignmentLegalAdviceFieldNames.CONTENT]: "",
  [AssignmentLegalAdviceFieldNames.USERS_IDS]: [],
  [AssignmentLegalAdviceFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: AssignmentLegalAdviceSchemaI;
  legalAdviceId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  defaultStatus?: string;
  pic?: any
}

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}

export const AssignmentLegalAdviceForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "legalAdvice.assignment.title.titlePopup",
    initialValue = initialEmptyValue,
    legalAdviceId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.ADVISE),
    senderDocumentManagement,
    defaultStatus = LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.ASSIGNMENT
    ) as string,
    pic
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const queryClient = useQueryClient();
  const form = useForm<any>({
    resolver: yupResolver(AssignmentLegalAdviceSchema),
    defaultValues: initialValue,
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: defaultStatus,
    modules: ModuleFields.ADVISE_NAME.module,
    queryKey: "LEGAL_ADVICE_ASSIGNMENT",
  });

  const { mutateAsync: createRequestApproval, isPending } =
    useCreateAssignmentLegalAdvice({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("legalAdvice.assignment.title.titlePopup"),
            })
          );
          queryClient.invalidateQueries({
            queryKey: [`advice-assignment-${legalAdviceId}`]
          })
          onCloseForm(true);
        },
      },
    });

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["legal-advice/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });
  
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createRequestApproval({
      legalAdviceId,
      data: { 
        ...data,
        ...(getSearchStatusQuery?.data && {
          [AssignmentLegalAdviceFieldNames.STATUS]:
            getSearchStatusQuery?.data?.find(
              (status) => status?.name === defaultStatus
            )?.id,
        }),
      },
    });
  };
  
  const handleGetOptions = async (keyword: any) => {
    if (!getLegalDepartmentQuery.data) return [];
    const response = await getUsers({
      searchTerm: keyword,
      page: 0,
      size: 100,
      sortBy: "name",
      sortOrder: "ASC",
      departmentIds: getLegalDepartmentQuery.data
        ? [getLegalDepartmentQuery.data]
        : [],
    });
    return (response?.users ?? [])?.filter(user => user?.id !== pic?.id).map((user) => ({
      id: user.id,
      name: user.name ?? "",
      departmentName: user.department?.name,
      email: user.email,
    }));
  }

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("legalAdvice.assignment.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={AssignmentLegalAdviceFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.assignment.title.${AssignmentLegalAdviceFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.assignment.placeHolder.${AssignmentLegalAdviceFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={AssignmentLegalAdviceFieldNames.USERS_IDS}
                    label={t("legalAdvice.assignment.title.responsiblePerson")}
                    placeholder="Nhập tên nhân viên"
                    getOptions={handleGetOptions}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"assignmentAdvice/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={AssignmentLegalAdviceFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castAssignmentLegalAdviceRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
