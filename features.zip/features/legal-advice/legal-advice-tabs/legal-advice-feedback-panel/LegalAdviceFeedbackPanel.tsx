import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { COLOR_TYPE } from "@/constants/color";
import {
  EXPECTED_DATE_TIME_LOCALE,
  GLOBAL_LARGE_SPACING,
  GLOBAL_SMALL_SPACING,
} from "@/constants/format";
import {
  Avatar,
  Divider,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Typography,
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { uniqueId } from "lodash";
import { Fragment } from "react";
import { useTranslation } from "react-i18next";

export interface LegalAdviceFeedbackPanelProps<T> {
  queryKey: string;
  getData: () => Promise<T[]>;
  getTitle: (item: T) => string;
  getDisplayDate: (item: T) => string;
  getSubtitle: (item: T) => string;
  contentHeader?: string;
  contentHeaderFn?: (item: T) => string;
  getContent: (item: T) => string;
  getNewDeadline?: (item: T) => string;
}

export const LegalAdviceFeedbackPanel = <T,>(props: LegalAdviceFeedbackPanelProps<T>) => {
  const [t] = useTranslation();
  const { getData, queryKey, getContent, contentHeader,
    getSubtitle, getTitle, getDisplayDate, getNewDeadline, contentHeaderFn } = props;

  const getDataQuery = useQuery({
    queryKey: [queryKey],
    queryFn: () => getData(),
  });

  return (
    <List dense>
      <LoadingWrapper loading={getDataQuery.isLoading}>
        {(getDataQuery.data || []).map((item) => (
          <Fragment key={uniqueId()}>
            <ListItem>
              <ListItemAvatar>
                <Avatar src='/' />
              </ListItemAvatar>
              <ListItemText
                primary={getTitle?.(item) ?? ''}
                secondary={getDisplayDate?.(item) ? Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                  dateStyle: "short",
                  timeStyle: "medium",
                }).format(new Date(getDisplayDate?.(item))) : null}
                secondaryTypographyProps={{
                  variant: "caption",
                }}
                primaryTypographyProps={{
                  variant: "h5",
                }}
              />
            </ListItem>
            <ListItem sx={{ paddingLeft: GLOBAL_LARGE_SPACING }}>
              <ListItemText
                secondary={
                  <>
                    <Typography
                      variant='body2'
                      sx={{ paddingBottom: GLOBAL_SMALL_SPACING }}
                    >
                      {getSubtitle?.(item) ?? ''}
                    </Typography>
                    <Typography variant='h5'>
                      {contentHeaderFn?.(item) ?? t(contentHeader ?? "")}:{" "}
                    </Typography>
                    <Typography variant='body2'>{getContent?.(item) ?? ""}</Typography>
                    {getNewDeadline?.(item) ? <Typography variant='h5'>
                      {getNewDeadline?.(item)}
                    </Typography> : null}
                  </>
                }
                secondaryTypographyProps={{
                  color: COLOR_TYPE.TOYOTA.TOYOTA2,
                }}
              />
            </ListItem>
            <Divider variant='middle' />
          </Fragment>
        ))}
      </LoadingWrapper>
    </List>
  );
};
