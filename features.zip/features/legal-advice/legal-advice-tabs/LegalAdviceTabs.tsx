'use client'

import { uploadDocumentTabAttachments } from '@/apis/service/files_upload/files';
import { commentLegalAdvice, createLegalAdviceMeeting, deleteLegalAdviceMeeting, getAdviseFeedbacks, getLegalAdviceAssignments, getLegalAdviceAttachment, getLegalAdviceComments, getLegalAdviceExtensions, getLegalAdviceForwards, getLegalAdviceHistory, getLegalAdviceInformationRequests, getLegalAdviceMeeting, getLegalAdviceRequestFeedback, updateLegalAdviceMeeting } from '@/apis/service/legal-advice/legalAdvice';
import { LoadingWrapper } from '@/components/commons/loading_indicator/LoadingWrapper';
import { TabNav } from '@/components/commons/tab-nav/TabNav';
import { UploadPanel } from '@/components/commons/upload/upload_panel/UploadPanel';
import { COLOR_TYPE } from '@/constants/color';
import { AppContext } from '@/context/AppContext';
import { CommentPanel } from '@/features/metadata_tab_panel/comment_panel/CommentPanel';
import { GenericContentPanel } from '@/features/metadata_tab_panel/generic_content_panel/GenericContentPanel';
import { InformationRequestPanel } from '@/features/metadata_tab_panel/information_request_panel/InformationRequestPanel';
import { MeetingPanel } from '@/features/metadata_tab_panel/meeting_panel/MeetingPanel';
import { LANGUAGES } from '@/locales/config-translation';
import { LegalAdviceBodyReceive } from '@/models/legal-advice/LegalAdviceDetail';
import { AdviceAssignment, AdviceRequestFeedback, AdviseFeedback, LegalAdviceForward } from '@/models/legal-advice/LegalAdviceList';
import { getUserLabel } from '@/utils';
import { ForwardedRef, forwardRef, useContext, useImperativeHandle, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { LegalAdviceExtendPanel } from './legal-advice-extend-panel/LegalAdviceExtendPanel';
import { LegalAdviceFeedbackPanel } from './legal-advice-feedback-panel/LegalAdviceFeedbackPanel';
import { LegalAdviceHistoryPanel } from './legal-advice-history-panel/LegalAdviceHistoryPanel';

export interface LegalAdviceTabsProps {
  legalAdviceId: number;
  legalAdvice?: LegalAdviceBodyReceive;
  loading?: boolean;
  handleReloadLegalAdviceQuery: () => void;
  containerHeight: number;
}

export interface LegalAdviceTabsRef {
  scrollToTab: (tab: number) => void;
}
const VIEW_ID = "legal-advice-tabs";
const LegalAdviceTabs = forwardRef(function LegalAdviceTabs(
  props: LegalAdviceTabsProps,
  ref: ForwardedRef<LegalAdviceTabsRef>
) {
  const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const { loading, legalAdviceId, handleReloadLegalAdviceQuery } = props;
  const isEnglish = i18n.language === LANGUAGES.ENGLISH;
  const [activeIndex, setActiveIndex] = useState(0);

  const scrollToTab = (tab: number) => {
    setActiveIndex(tab);
    const tabElement = document.getElementById(VIEW_ID);
    setTimeout(() => tabElement?.scrollIntoView({
      behavior: 'smooth',
    }), 400)
  }

  useImperativeHandle(ref, () => ({
    scrollToTab: (tab: number) => scrollToTab(tab)
  }))

  const ownerRole = useMemo(() => {
    const roles = props.legalAdvice
      ?.userLastActionAndLegalAdviceRoleResponse
      ?.userLastActionAndRoleList?.map((role) => role.role) ?? [];
    return roles;
  }, [props.legalAdvice]);

  return (
    <LoadingWrapper loading={loading || appContext.loading}>
      <div id={VIEW_ID} style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
        <TabNav
          index={activeIndex}
          onChangeTabIndex={setActiveIndex}
          tabItems={[
            // 1. Yêu cầu bổ sung thông tin
            {
              key: "information-request",
              label: t("metadata.informationRequest.title"),
              content: (
                <InformationRequestPanel
                  queryKey={`legal-advice-information-request-${legalAdviceId}`}
                  getInformationRequests={async () => {
                    return (
                      (await getLegalAdviceInformationRequests((props.legalAdviceId)))
                        ?.detailInformationRequestResponses?.map((ele, index: number) => ({
                          ...ele,
                          id: index + 1
                        })) ?? []
                    )
                  }
                  }
                />
              )

            },
            // 2. Phân công
            {
              key: 'assignment',
              label: t('legalAdvice.tabs.assignment'),
              content: (
                <GenericContentPanel<AdviceAssignment>
                  getData={async () => {
                    return (
                      (await getLegalAdviceAssignments(props.legalAdviceId))
                        ?.assignmentResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) => getUserLabel(item.assignUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('legalAdvice.tabs.assignTo')}:  ${item?.receiveUsers?.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='legalAdvice.tabs.assignmentContent'
                  getContent={(item) => item.content}
                  queryKey={`advice-assignment-${legalAdviceId}`}
                />
              )
            },
            // 3. Chuyển tiếp
            {
              key: "forward",
              label: t("metadata.forward.title"),
              content: (
                <GenericContentPanel<LegalAdviceForward>
                  getData={async () => {
                    return (await getLegalAdviceForwards(props.legalAdviceId))
                      ?.forwardResponseDetails ?? []
                  }}
                  getTitle={(item) => getUserLabel(item.forwardUser, isEnglish)}
                  getDisplayDate={(item) => item.forwardDate}
                  getSubtitle={(item) => `${t('legalAdvice.tabs.forwardedTo')}:  ${item?.receiveUsers?.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='legalAdvice.forwardLegalAdvice.title.content'
                  getContent={(item) => item.content}
                  queryKey={`advice-forward-${legalAdviceId}`}
                />
              ),
            },
            // 4. Gia hạn thời gian
            {
              key: 'extend',
              label: t("metadata.extend.title"),
              content: (
                <LegalAdviceExtendPanel
                  legalAdviceId={props.legalAdviceId}
                  legalAdvice={props.legalAdvice}
                  getExtendRecords={async () => {
                    return (await getLegalAdviceExtensions(props.legalAdviceId))
                      ?.timeExtensionResponseDetails ?? []
                  }}
                  queryKey={`legal-advice-extend-tab-${legalAdviceId}`}
                />
              )
            },
            // 5. Phản hồi tư vấn
            {
              key: 'advise-feedback',
              label: t('legalAdvice.tabs.adviceFeedback'),
              content: (
                <GenericContentPanel<AdviseFeedback>
                  getData={async () => {
                    return (await getAdviseFeedbacks(props.legalAdviceId))
                      ?.feedbackAdviseResponseDetails ?? []
                  }
                  }
                  getTitle={(item) => getUserLabel(item.feedbackAdviseUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('legalAdvice.tabs.adviceFeedbackTo')}: ${getUserLabel(item.receiveUser, isEnglish)}`}
                  contentHeader='legalAdvice.tabs.adviceFeedbackContent'
                  getContent={(item) => item.reason}
                  getNewDeadline={() => ''}
                  queryKey={`advise-feedback-${legalAdviceId}`}
                />
              )
            },
            // 6. Phản hồi văn bản
            {
              key: 'request-feedback',
              label: t('legalAdvice.tabs.documentFeedback'),
              content: (
                <LegalAdviceFeedbackPanel<AdviceRequestFeedback>
                  getData={async () => {
                    return (await getLegalAdviceRequestFeedback(props.legalAdviceId))
                      ?.feedbackResponseDetails ?? []
                  }}
                  getTitle={(item) => getUserLabel(item.feedbackUser, isEnglish)}
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) => `${t('legalAdvice.tabs.feedbackTo')}: ${item.receiveUsers.map((user) => getUserLabel(user, isEnglish)).join(', ')}`}
                  contentHeader='legalAdvice.tabs.feedbackContent'
                  getContent={(item) => item.content}
                  queryKey={`request-feedback-${legalAdviceId}`}
                />
              )
            },
            // 7. Book lịch họp
            {
              key: "meeting",
              label: t("metadata.meeting.tab"),
              content: (
                <MeetingPanel
                  containerHeight={props.containerHeight}
                  queryKey={`legal-advice-meeting-${legalAdviceId}`}
                  reloadDetail={handleReloadLegalAdviceQuery}
                  updateMeeting={(data) => updateLegalAdviceMeeting({
                    id: props.legalAdviceId,
                    content: data.content,
                    meetingId: data.meetingId
                  })
                  }
                  deleteMeeting={(meetingId) => deleteLegalAdviceMeeting({
                    id: props.legalAdviceId,
                    meetingId: meetingId
                  })}
                  getMeetings={async () => {
                    return (
                      (await getLegalAdviceMeeting(props.legalAdviceId))
                        .result?.meetingResponses ?? []
                    );
                  }}
                  addMeeting={(content) =>
                    createLegalAdviceMeeting({
                      id: props.legalAdviceId,
                      content: content,
                    })
                  }
                  disabled={
                    !appContext.meCanRead
                    || (!ownerRole.includes(1)
                      && !ownerRole.includes(2)
                      && !ownerRole.includes(4))
                  }
                />
              ),
            },
            // 8. Bình luận
            {
              key: "comment",
              label: t("metadata.comment.title"),
              content: (
                <CommentPanel
                  queryKey={`legal-advice-comment-${legalAdviceId}`}
                  getComments={async () => {
                    return (
                      (await getLegalAdviceComments(props.legalAdviceId))
                        .result?.data ?? []
                    );
                  }}
                  addComment={(comment) =>
                    commentLegalAdvice({
                      id: props.legalAdviceId,
                      content: comment,
                    })
                  }
                  disabled={
                    !appContext.meCanRead ||
                    props.legalAdvice?.userLastActionAndLegalAdviceRoleResponse
                      ?.userLastActionAndRoleList?.length === 0
                  }
                />
              ),
            },
            // 9. Đính kèm
            {
              key: "attachment",
              label: t("metadata.attachment.title"),
              content: (
                <UploadPanel
                  queryKey={`legal-advice-upload-${legalAdviceId}`}
                  onGetFiles={async () =>
                    (
                      (await getLegalAdviceAttachment(props.legalAdviceId))
                        ?.data || []
                    ).map((legalDocumentAttachment) => ({
                      fileId: legalDocumentAttachment.fileId,
                      fileName: legalDocumentAttachment.fileName,
                      storagePath: legalDocumentAttachment.filePath,
                      uploadDate: legalDocumentAttachment.uploadDate,
                    }))
                  }
                  onDelete={() => Promise.resolve()}
                  onUpload={async (files) => {
                    await uploadDocumentTabAttachments({
                      files: files,
                      id: props.legalAdviceId,
                      reference_file_type: 4
                    });
                  }}
                  disabled
                />
              ),
            },
            // 9. Lịch sử
            {
              key: "history",
              label: t("metadata.history.title"),
              content: (
                <LegalAdviceHistoryPanel
                  queryKey={`legal-advice-history-${legalAdviceId}`}
                  getHistoryRecords={async () => {
                    return (await getLegalAdviceHistory(props.legalAdviceId)).result
                      ?.data ?? []
                  }}
                />
              ),
            },
          ]}
        />
      </div>
    </LoadingWrapper>
  )
})

export default LegalAdviceTabs