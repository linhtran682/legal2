import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { HistoryRecord } from "@/models/metadata/Metadata";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";



export interface LegalAviceHistoryPanelProps {
  queryKey: string;
  getHistoryRecords: () => Promise<HistoryRecord[]>;
}

export const LegalAdviceHistoryPanel = (props: LegalAviceHistoryPanelProps) => {
  const { t } = useTranslation();
  const getHistoryRecordsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getHistoryRecords(),
  });

  const getUserAction = (history: HistoryRecord) => {
    // if (history.action === 16) {
    //   return t(`legalAdvice.actionContent.${history.action}`, {
    //     username: history.actionOwner.name,
    //     receiveUser: history?.receiverUsers?.map((user) => user.name)?.join(', ')
    //   })
    // }
    if (history.action === 10) {
      return <>
        <p>{t(`legalAdvice.actionContent.${history.action}`, {
          username: history.actionOwner.name,
        })}
        </p>
        <p>{t(`legalAdvice.label.content`)}: {history.content}</p>
      </>
    }

    return t(`legalAdvice.actionContent.${history.action}`, {
      username: history.actionOwner.name,
      receiveUser: history?.receiverUsers?.map((user) => user.name)?.join(', ')
    })
  }

  const HistoryTableColumns: StandardSimpleTableColumn<HistoryRecord>[] = [
    {
      key: "date",
      label: "metadata.history.column.date",
      type: "date",
      flex: 1,
    },
    {
      key: "user",
      label: "metadata.history.column.user",
      type: "string",
      flex: 1,
      renderCell: (params) => getUserAction(params.row)
    },
    {
      key: "action",
      label: "Action",
      type: "string",
      flex: 1,
      renderCell: (params) => t(`legalAdvice.actions.${params.row.action}`),
    },
  ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        columns={HistoryTableColumns}
        data={getHistoryRecordsQuery.data ?? []}
        getRowId={(row) => row.date}
      />
    </div>
  );
};
