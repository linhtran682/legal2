import CheckboxInput from '@/components/commons/inputs/checkbox/CheckboxInput';
import { COLOR_TYPE } from '@/constants/color';
// import { LegalAdviceStatusContent, LegalAdviceStatusKey } from '@/constants/general';
// import { AppContext } from '@/context/AppContext';
import useObserveElementSize from '@/hooks/useObserveElementSize';
import { LegalAdviceBodyReceive } from '@/models/legal-advice/LegalAdviceDetail';
import { Box } from '@mui/material';
// import { useContext, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface OverviewHeaderProps {
  initialValueReceive?: LegalAdviceBodyReceive;
  isMeeting?: boolean;
  disabled?: boolean;
  handleUpdateBookMeeting?: (params: any) => void;
  isLoading?: boolean;
  scrollToTab: (tab: number) => void;
}
const OverviewHeader = (props: OverviewHeaderProps) => {
  const { t } = useTranslation();
  const { scrollToTab } = props;
  // const [isBooked, setIsBooked] = useState(false);
  // const [ownRole, setOwnRole] = useState<number[]>([]);
  // const appContext = useContext(AppContext);

  // useEffect(() => {
  //   if (props.initialValueReceive) {
  //     setIsBooked(!!props?.initialValueReceive?.bookingFlag);
  //   }
  //   if (
  //     props.initialValueReceive &&
  //     props.initialValueReceive?.userLastActionAndLegalAdviceRoleResponse?.userLastActionAndRoleList?.length
  //   ) {
  //     const { userLastActionAndLegalAdviceRoleResponse: { userLastActionAndRoleList } } = props.initialValueReceive;
  //     const roleList = userLastActionAndRoleList?.map((ele) => ele.role)
  //     setOwnRole(roleList);
  //   } else {
  //     setOwnRole([]);
  //   }
  // }, [props.initialValueReceive]);

  // const isStatusDone = useMemo(() => props?.initialValueReceive?.status?.name
  //   === LegalAdviceStatusContent.get(
  //     LegalAdviceStatusKey.DONE
  //   ), [props?.initialValueReceive?.status]);

  // const canBookMeeting = (ownRole.includes(1)
  //   || ownRole.includes(2)
  //   || ownRole.includes(3)
  //   || ownRole.includes(4)
  //   || ownRole.includes(5)) && !isStatusDone;

  // const disableBookMeeting = !appContext.meCanWrite ||
  //   (!canBookMeeting)
  //   || props.isLoading;

  const { elementRef, size } = useObserveElementSize();

  const responsiveSx = {
    minWidth: 200,
    flex: 1
  }

  return (
    <Box
      ref={elementRef}
      sx={{
        display: size.width <= 980 ? 'grid' : 'flex',
        p: 2, backgroundColor: 'white',
        mb: 2,
        gridTemplateColumns: `repeat(auto-fill, minmax(200px, 1fr))`
      }}
    >
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={(props.initialValueReceive?.meetingNumber as number) > 0}
          // disabled={disableBookMeeting}
          disabled
          // onChange={async (value) => {
          //   if (disableBookMeeting) return;
          //   await props?.handleUpdateBookMeeting?.({
          //     legalAdviceId: props?.initialValueReceive?.id,
          //     request: {
          //       isBookMeeting: value
          //     }
          //   })
          //   setIsBooked(value)
          // }}
          label={`${t("LEGISLATION.evaluateField.meeting")}
          ${(props.initialValueReceive?.meetingNumber as number) > 0
              ? ` (${props.initialValueReceive?.meetingNumber})`
              : ""
            }`}
          labelColor={COLOR_TYPE.BLUE.BLUE6}
          onLabelClick={() => scrollToTab(6)}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          disabled
          // checked={!!props.initialValueReceive?.responseFlag}
          checked={(props.initialValueReceive?.responseAdviseNumber as number) > 0}
          labelColor={COLOR_TYPE.BLUE.BLUE6}
          onLabelClick={() => scrollToTab(4)}
          label={`${t("legalAdvice.label.adviceFeedback")}
          ${(props.initialValueReceive?.responseAdviseNumber as number) > 0
              ? ` (${props.initialValueReceive?.responseAdviseNumber})`
              : ""
            }
          `}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          disabled
          checked={!!props.initialValueReceive?.confirmFlag}
          label={t('legalAdvice.label.adviceConfirm')}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={(props.initialValueReceive?.adviceNumber as number) > 0}
          disabled
          label={`${t('legalAdvice.label.lcCompleted')}
          ${(props.initialValueReceive?.requestAdviceNumber as number) > 0
              ? ` (${props.initialValueReceive?.adviceNumber}/${props.initialValueReceive?.requestAdviceNumber})`
              : ""
            }
          `}
        />
      </Box>
      <Box sx={{ padding: '4px 0px', width: 'fit-content', ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={(props.initialValueReceive?.supervisorAdviceNumber as number) > 0}
          disabled
          label={`${t('legalAdvice.label.supervisorAdvised')}
           ${(props.initialValueReceive?.requestSupervisorAdviceNumber as number) > 0
              ? ` (${props.initialValueReceive?.supervisorAdviceNumber}/${props.initialValueReceive?.requestSupervisorAdviceNumber})`
              : ""
            }
          `}
        />
      </Box>
      {/* </Stack > */}
    </Box>
  )
}

export default OverviewHeader