import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormCheckbox } from "@/components/commons/form_inputs/FormCheckbox";
import { FormSelect } from "@/components/commons/form_inputs/FormSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import {
  SaveStatusDTO,
  SaveStatusRequestFieldNames,
  SaveStatusRequestSchema,
  SaveStatusRequestSchemaI,
} from "@/models/status/Status";
import { BasicSaveForm } from "@/models/ui/form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

export interface SaveStatusFormProps
  extends BasicSaveForm<SaveStatusDTO, SaveStatusDTO> {}

const initialEmptyValue: SaveStatusDTO = {
  name: "",
  description: "",
  active: 0,
  module: 1,
};

export const SaveStatusForm = (props: SaveStatusFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<SaveStatusRequestSchemaI>({
    resolver: yupResolver(SaveStatusRequestSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  useEffect(() => {
    props.initialValue && form.reset(props.initialValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);

  return (
    <Grid container className='form-wrapper'>
      <FormProvider {...form}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className='form-section-wrapper'
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <Grid container direction={"column"} spacing={GLOBAL_SPACING}>
              <Grid item>
                <FormTextField
                  control={form.control}
                  name={SaveStatusRequestFieldNames.NAME}
                  label={t(
                    `status.field_name.${SaveStatusRequestFieldNames.NAME}`
                  )}
                  placeHolder={t(
                    `status.field_name.${SaveStatusRequestFieldNames.NAME}`
                  )}
                  required
                />
              </Grid>
              <Grid item>
                <FormSelect
                  control={form.control}
                  name={SaveStatusRequestFieldNames.MODULE}
                  label={t(
                    `status.field_name.${SaveStatusRequestFieldNames.MODULE}`
                  )}
                  placeHolder={t(
                    `status.field_name.${SaveStatusRequestFieldNames.MODULE}`
                  )}
                  options={Array.from(Module.keys()).map((key) => ({
                    label: t(
                      `common.option.${SaveStatusRequestFieldNames.MODULE}.${key}`
                    ),
                    value: Module.get(key)!,
                  }))}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => option.label}
                  required
                />
              </Grid>

              <Grid item>
                <FormCheckbox
                  control={form.control}
                  name={SaveStatusRequestFieldNames.ACTIVE}
                  label={t(
                    `status.field_name.${SaveStatusRequestFieldNames.ACTIVE}`
                  )}
                  inputTransform={(value: number) => value != 0}
                  outputTransform={(bool) => (bool ? 1 : 0)}
                />
              </Grid>

              <Grid item>
                <FormTextArea
                  control={form.control}
                  name={SaveStatusRequestFieldNames.DESCRIPTION}
                  label={t(
                    `status.field_name.${SaveStatusRequestFieldNames.DESCRIPTION}`
                  )}
                  placeHolder={t(
                    `status.field_name.${SaveStatusRequestFieldNames.DESCRIPTION}`
                  )}
                  minRows={3}
                />
              </Grid>
            </Grid>
          </Grid>
        </Grid>

        <FormActionButtons
          formMode={props.formMode}
          loading={props.loading}
          onCancel={props.onCancel}
          cancelConfirm={form.formState.isDirty}
          onDelete={props.onDelete}
          onSave={props.onSubmit}
        />
      </FormProvider>
    </Grid>
  );
};
