import MultipleFilterTable, {
  MultipleFilterTableColumn,
} from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { GridFilterItem } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { StatusTableAtions } from "./status_table_actions/StatusTableActions";
import { GetStatusListParams, StatusFieldNames } from "@/models/status/Status";
import { useTranslation } from "react-i18next";
import { deleteStatusList, getStatusList } from "@/apis/service/status/Status";
import { Checkbox } from "@mui/material";
import { Module, ModuleR } from "@/constants/general";
import { useRouter } from "next/navigation";
import { STATUS_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { TableGroupedActionButtons } from "@/components/commons/action_button/TableGroupedActionButtons";
import { getMultipleChoosingOperators } from "@/components/commons/filters/MultipleChoosingFilter";

export const StatusTableConst = {
  TABLE_NAME: "StatusTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getStatusList",
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetStatusListParams => {
  const params: GetStatusListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: StatusFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == StatusFieldNames.NAME) {
      params.name = item.value;
    }
    if (item.field == StatusFieldNames.MODULE) {
      params.modules = item.value;
    }
    if (item.field == StatusFieldNames.ACTIVE) {
      params.active = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() || "";
  }

  return params;
};

export const StatusTable = () => {
  const router = useRouter();
  const [t] = useTranslation();
  const queryClient = useQueryClient();

  const [statusTableColumns] = useState<MultipleFilterTableColumn[]>(() => [
    {
      key: StatusFieldNames.ID,
      label: StatusFieldNames.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
    },
    {
      key: StatusFieldNames.MODULE,
      label: StatusFieldNames.MODULE,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: false,
      filterOperators: getMultipleChoosingOperators(
        {
          options: Array.from(Module.keys()).map((key) => ({
            label: t(`common.option.${StatusFieldNames.MODULE}.${key}`),
            value: Module.get(key)!,
          })),
          getOptionKey: (option) => option.value,
          getOptionLabel: (option) => option.label,
        },
        t
      ),
      renderCell: (params) => (
        <>
          {t(
            `common.option.${StatusFieldNames.MODULE}.${ModuleR.get(
              Number(params.value)
            )!}`
          )}
        </>
      ),
      flex: 1,
    },
    {
      key: StatusFieldNames.NAME,
      label: StatusFieldNames.NAME,
      type: "string",
      quickFilter: true,
      filterable: false,
      sortable: true,
      hideable: false,
      flex: 1,
    },

    {
      key: StatusFieldNames.ACTIVE,
      label: StatusFieldNames.ACTIVE,
      type: undefined,
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      renderCell: (params) => <Checkbox checked={params.value == 1} />,
    },
    {
      key: StatusFieldNames.CREATED_AT,
      label: StatusFieldNames.CREATED_AT,
      type: "date",
      quickFilter: false,
      filterable: false,
      sortable: true,
      hideable: false,
      flex: 1,
    },
    {
      key: "action",
      label: "",
      type: undefined,
      renderCell: StatusTableAtions,
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "stickyRight",
    },
  ]);

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getStatusListQuery = useQuery({
    queryKey: [StatusTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getStatusList(castTableStateToParams(tableState)),
  });

  const deleteStatusListQuery = useMutation({
    mutationFn: deleteStatusList,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.status"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [StatusTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  // Watch table state then refetch new data for the table
  useEffect(() => {
    tableState && getStatusListQuery.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);
  
  return (
    <MultipleFilterTable
      data={getStatusListQuery.data?.statusResponses || []}
      columns={statusTableColumns
        // .filter((column) => appContext.meCanWrite || column.key != "action")
        .map((column) => ({
          ...column,
          label: column.label && `status.column.${column.label}`,
        }))}
      getRowId={(item) => item.id.toString()}
      loading={getStatusListQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getStatusListQuery.data?.total}
      multipleFilter
      onRowClick={(params) => {
        router.push(`/${STATUS_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`);
      }}
      quickFilterProps={{
        defaultSelectedOptionKey: StatusFieldNames.NAME,
        placeHolder: (fieldKey) =>
          t(`common.place_holder.search`, {
            fieldName: t(`status.column.${fieldKey}`).toLocaleLowerCase(),
          }),
      }}
      groupedActions={(model) => (
        <TableGroupedActionButtons
          selectModel={model}
          onDelete={deleteStatusListQuery.mutate}
        />
      )}
    />
  );
};
