import {
  ActionButtonCustom,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButtonCustom";
import { ConflictActionsBtnKey } from "@/constants/general";
import { useMemo, useState } from "react";
// import { IconAdvise } from "@/assets/iconMenu/IconAdvise";
// import { IconAssignment } from "@/assets/iconMenu/IconAssignment";
import { IconConfirm } from "@/assets/iconMenu/IconConfirm";
import { IconDone } from "@/assets/iconMenu/IconDone";
import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";
import { IconFeedback } from "@/assets/iconMenu/IconFeedback";
// import { IconFeedbackAdvise } from "@/assets/iconMenu/IconFeedbackAdvise";
import { IconForward } from "@/assets/iconMenu/IconForward";
import { IconRequestAdditional } from "@/assets/iconMenu/IconRequestAdditional";
import { IconRequestMeeting } from "@/assets/iconMenu/IconRequestMeeting";
import { IconSendMail } from "@/assets/iconMenu/IconSendMail";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";
import { COLOR_TYPE } from "@/constants/color";
import { IconRecall } from "@/assets/iconMenu/IconRecall";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { useTranslation } from "react-i18next";
// import HvacIcon from "@mui/icons-material/Hvac";
import { IconRequestConfirm } from "@/assets/iconMenu/IconRequestConfirm";
import RuleIcon from "@mui/icons-material/Rule";
import { IconRequestEvaluate } from "@/assets/iconMenu/IconRequestEvaluate";
import { IconFollow } from "@/assets/iconMenu/IconFollow";
import { TypeActionRole } from "./RelationMngActionsFunction";
import { orderMap } from "@/features/conflict_management/conflict_management_table/ConflictMngActions/ConflictMngActions";
import IconShare from "@/assets/iconMenu/IconShare";
type TypePropsLegalAdviceTableActions = {
  params: { row: any };
  isActionDetail?: boolean;
  actionButtonItemValidate?: Array<TypeActionRole>;
  handleClickRecall?: () => void;
  handleClickForWard?: () => void;
  handleClickSendMail?: () => void;
  handleClickFeedBack?: () => void;
  handleClickRequestMeeting?: () => void;
  handleClickExtendTime?: () => void;
  handleClickConfirm?: () => void;
  handleClickRequestVendor?: () => void;
  handleClickRequestAdditional?: () => void;
  handleClickDone?: () => void;
  handleClickRequestEvaluate?: () => void;
  handleClickEvaluate?: () => void;
  handleClickRequestConfirm?: () => void;
  handleClickConflictMonitor?: () => void;
  handleClickExtendTimeConfirm?: () => void;
  handleClickSignApprove?: () => void;
  handleClickShare?: () => void;
};

export const RelationMngActions = (props: TypePropsLegalAdviceTableActions) => {
  const [t] = useTranslation();
  const {
    params,
    isActionDetail = false,
    handleClickRecall = () => { },
    handleClickForWard = () => { },
    handleClickFeedBack = () => { },
    handleClickRequestMeeting = () => { },
    handleClickSendMail = () => { },
    handleClickExtendTime = () => { },
    handleClickConfirm = () => { },
    handleClickRequestEvaluate = () => { },
    handleClickEvaluate = () => { },
    handleClickRequestAdditional = () => { },
    handleClickDone = () => { },
    handleClickRequestConfirm = () => { },
    handleClickConflictMonitor = () => { },
    handleClickExtendTimeConfirm = () => { },
    handleClickSignApprove = () => { },
    handleClickShare = () => { }
  } = props;
  const styleBtn = {
    background: COLOR_TYPE.TOYOTA.TOYOTA1,
    color: COLOR_TYPE.TOYOTA.TOYOTA8,
  };
  const [buttonMap] = useState(
    new Map<string, ActionButtonItem>([
      [
        ConflictActionsBtnKey.RECALL,
        {
          key: ConflictActionsBtnKey.RECALL,
          icon: <IconRecall />,
          iconDisable: <IconRecall color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`legalAdvice.button.${ConflictActionsBtnKey.RECALL}`),
          onClick: handleClickRecall,
          tooltipTitle: t(`legalAdvice.button.${ConflictActionsBtnKey.RECALL}`),
          confirmPopupProps: {
            icon: <SaveRecordDialogIcon />,
            title: t(
              `legalAdvice.recallLegalAdvice.message.confirm_${ConflictActionsBtnKey.RECALL}`
            ),
          },
          styleBtn,
          secondaryBtn: 1,
        },
      ],
      [
        ConflictActionsBtnKey.SEND_MAIL,
        {
          key: ConflictActionsBtnKey.SEND_MAIL,
          icon: <IconSendMail />,
          iconDisable: <IconSendMail color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`legalAdvice.button.${ConflictActionsBtnKey.SEND_MAIL}`),
          onClick: handleClickSendMail,
          tooltipTitle: t(
            `legalAdvice.button.${ConflictActionsBtnKey.SEND_MAIL}`
          ),
          styleBtn,
          secondaryBtn: 2,
        },
      ],
      [
        ConflictActionsBtnKey.REQUEST_ADDITIONAL,
        {
          key: ConflictActionsBtnKey.REQUEST_ADDITIONAL,
          icon: <IconRequestAdditional />,
          iconDisable: (
            <IconRequestAdditional color={COLOR_TYPE.TOYOTA.TOYOTA5} />
          ),
          textBtn: t(
            `CONFLICT_MANAGEMENT.requestAdditional.title.button`
          ),
          onClick: handleClickRequestAdditional,
          tooltipTitle: t(
            `CONFLICT_MANAGEMENT.requestAdditional.title.button`
          ),
          styleBtn,
        },
      ],
      [
        ConflictActionsBtnKey.EVALUATE,
        {
          key: ConflictActionsBtnKey.EVALUATE,
          icon: <RuleIcon />,
          iconDisable: <RuleIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA5 }} />,
          textBtn: t(`RELATION_SHIP_DISCLOSURE.button.evaluate`),
          onClick: handleClickEvaluate,
          tooltipTitle: t(`RELATION_SHIP_DISCLOSURE.button.evaluate`),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        },
      ],
      [
        ConflictActionsBtnKey.REQUEST_CONFIRM,
        {
          key: ConflictActionsBtnKey.REQUEST_CONFIRM,
          icon: <IconRequestConfirm />,
          iconDisable: <IconRequestConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`CONFLICT_MANAGEMENT.requestConfirm.title`),
          onClick: handleClickRequestConfirm,
          tooltipTitle: t(`CONFLICT_MANAGEMENT.requestConfirm.title`),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        },
      ],
      [
        ConflictActionsBtnKey.CONFLICT_MONITORING,
        {
          key: ConflictActionsBtnKey.CONFLICT_MONITORING,
          icon: <IconFollow />,
          iconDisable: <IconFollow color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`RELATION_SHIP_DISCLOSURE.follow.title`),
          onClick: handleClickConflictMonitor,
          tooltipTitle: t(`RELATION_SHIP_DISCLOSURE.follow.title`),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        },
      ],

      [
        ConflictActionsBtnKey.REQUEST_MEETING,
        {
          key: ConflictActionsBtnKey.REQUEST_MEETING,
          icon: <IconRequestMeeting />,
          iconDisable: <IconRequestMeeting color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(
            `legalAdvice.button.${ConflictActionsBtnKey.REQUEST_MEETING}`
          ),
          onClick: handleClickRequestMeeting,
          tooltipTitle: t(
            `legalAdvice.button.${ConflictActionsBtnKey.REQUEST_MEETING}`
          ),
          styleBtn,
        },
      ],
      [
        ConflictActionsBtnKey.FORWARD,
        {
          key: ConflictActionsBtnKey.FORWARD,
          icon: <IconForward />,
          iconDisable: <IconForward color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`legalAdvice.button.${ConflictActionsBtnKey.FORWARD}`),
          onClick: handleClickForWard,
          tooltipTitle: t(
            `legalAdvice.button.${ConflictActionsBtnKey.FORWARD}`
          ),
          styleBtn,
          secondaryBtn: 3,
        },
      ],
      [
        ConflictActionsBtnKey.FEEDBACK,
        {
          key: ConflictActionsBtnKey.FEEDBACK,
          icon: <IconFeedback />,
          iconDisable: <IconFeedback color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`CONFLICT_MANAGEMENT.feedback.title`),
          onClick: handleClickFeedBack,
          tooltipTitle: t(`CONFLICT_MANAGEMENT.feedback.title`),
          styleBtn,
          secondaryBtn: 4,
        },
      ],
      [
        ConflictActionsBtnKey.REQUEST_MEETING,
        {
          key: ConflictActionsBtnKey.REQUEST_MEETING,
          icon: <IconRequestMeeting />,
          iconDisable: <IconRequestMeeting color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(
            `legalAdvice.button.${ConflictActionsBtnKey.REQUEST_MEETING}`
          ),
          onClick: handleClickRequestMeeting,
          tooltipTitle: t(
            `legalAdvice.button.${ConflictActionsBtnKey.REQUEST_MEETING}`
          ),
          styleBtn,
          secondaryBtn: 5,
        },
      ],
      [
        ConflictActionsBtnKey.TIME_EXTENSION_EVALUATE,
        {
          key: ConflictActionsBtnKey.TIME_EXTENSION_EVALUATE,
          icon: <IconExtendDeadline />,
          iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(
            `CONFLICT_MANAGEMENT.button.${ConflictActionsBtnKey.TIME_EXTENSION_EVALUATE}`
          ),
          onClick: handleClickExtendTime,
          tooltipTitle: t(
            `CONFLICT_MANAGEMENT.button.${ConflictActionsBtnKey.TIME_EXTENSION_EVALUATE}`
          ),
          styleBtn,
          secondaryBtn: 6,
        },
      ],
      [
        ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
        {
          key: ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
          icon: <IconExtendDeadline />,
          iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(
            `CONFLICT_MANAGEMENT.button.${ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM}`
          ),
          onClick: handleClickExtendTimeConfirm,
          tooltipTitle: t(
            `CONFLICT_MANAGEMENT.button.${ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM}`
          ),
          styleBtn,
          secondaryBtn: 6,
        },
      ],
      [
        ConflictActionsBtnKey.CONFIRM,
        {
          key: ConflictActionsBtnKey.CONFIRM,
          icon: <IconConfirm />,
          iconDisable: <IconConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`legalAdvice.button.${ConflictActionsBtnKey.CONFIRM}`),
          onClick: handleClickConfirm,
          tooltipTitle: t(
            `legalAdvice.button.${ConflictActionsBtnKey.CONFIRM}`
          ),
          styleBtn,
        },
      ],

      [
        ConflictActionsBtnKey.DONE,
        {
          key: ConflictActionsBtnKey.DONE,
          icon: <IconDone />,
          iconDisable: <IconDone color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`CONFLICT_MANAGEMENT.button.finishConflict`),
          onClick: handleClickDone,
          tooltipTitle: t(`CONFLICT_MANAGEMENT.button.finishConflict`),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        },
      ],
      [
        ConflictActionsBtnKey.REQUEST_EVALUATE,
        {
          key: ConflictActionsBtnKey.REQUEST_EVALUATE,
          icon: <IconRequestEvaluate />,
          iconDisable: <IconRequestEvaluate color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`CONFLICT_MANAGEMENT.requestEvaluate.title`),
          onClick: handleClickRequestEvaluate,
          tooltipTitle: t(`CONFLICT_MANAGEMENT.requestEvaluate.title`),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        },
      ],
      [
        ConflictActionsBtnKey.REQUEST_CONFIRM,
        {
          key: ConflictActionsBtnKey.REQUEST_CONFIRM,
          icon: <IconRequestConfirm />,
          iconDisable: <IconRequestConfirm color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`CONFLICT_MANAGEMENT.requestConfirm.title`),
          onClick: handleClickRequestConfirm,
          tooltipTitle: t(`CONFLICT_MANAGEMENT.requestConfirm.title`),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        },
      ],

      [
        ConflictActionsBtnKey.APPROVE,
        {
          key: ConflictActionsBtnKey.APPROVE,
          icon: <RuleIcon />,
          iconDisable: <RuleIcon sx={{ color: COLOR_TYPE.TOYOTA.TOYOTA5 }} />,
          textBtn: t(`CONFLICT_MANAGEMENT.button.approve`),
          onClick: handleClickSignApprove,
          tooltipTitle: t(`CONFLICT_MANAGEMENT.button.approve`),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
        },
      ],
      [
        ConflictActionsBtnKey.SHARE,
        {
          key: ConflictActionsBtnKey.SHARE,
          icon: <IconShare />,
          iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`legalAdvice.button.${ConflictActionsBtnKey.SHARE}`),
          onClick: handleClickShare,
          tooltipTitle: t(
            `legalAdvice.button.${ConflictActionsBtnKey.SHARE}`
          ),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
          secondaryBtn: 7,
        },
      ],
    ])
  );
  const buttonList = useMemo(() => {
    const btnList: TypeActionRole[] = props.actionButtonItemValidate?.length
      ? [...props.actionButtonItemValidate]
      : [];

    if ((params as any)?.ownerRoles?.includes(1)
      || params?.row?.ownerRoles?.includes(1)) {
      btnList.push({
        typeBtn: ConflictActionsBtnKey.SHARE,
        disable: false
      })
    }
    return btnList;
  }, [props.actionButtonItemValidate, params])
  if (isActionDetail)
    return (
      <ActionButtonDetail
        params={params}
        // actionButtonItems={props.actionButtonItemValidate?.sort((a, b) => {
        actionButtonItems={buttonList?.sort((a, b) => {
          const indexA = orderMap[a.typeBtn] ?? Infinity; // Giá trị không có trong customOrder sẽ có thứ tự rất lớn
          const indexB = orderMap[b.typeBtn] ?? Infinity;

          return indexA - indexB; // So sánh thứ tự
        }).map(
          (buttons: TypeActionRole) => ({
            ...buttonMap.get(buttons?.typeBtn)!,
            disable: buttons?.disable,
          })
        ) as ActionButtonItem[]}
      />
    );
  return (
    <ActionButtonCustom
      params={params}
      // actionButtonItems={props.actionButtonItemValidate?.sort((a, b) => {
      actionButtonItems={buttonList?.sort((a, b) => {
        const indexA = orderMap[a.typeBtn] ?? Infinity; // Giá trị không có trong customOrder sẽ có thứ tự rất lớn
        const indexB = orderMap[b.typeBtn] ?? Infinity;

        return indexA - indexB; // So sánh thứ tự
      }).map(
        (buttons: TypeActionRole) => ({
          ...buttonMap.get(buttons?.typeBtn)!,
          disable: buttons?.disable,
        })
      ) as ActionButtonItem[]}
      listActions={[{ ownerRole: 1, ownerAction: 1 }]}
    />
  );
};
