import { getStatusListNames } from "@/apis/service/status/Status";
import { getUser, getUsers } from "@/apis/service/user/User";
import { getAsyncSelectOperators } from "@/components/commons/filters/AsyncSelectFilter";
import { getMultipleAsyncChoosingOperators } from "@/components/commons/filters/MultipleAsyncChoosingFilter";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import MultipleTabsTable from "@/components/commons/tables/multiple_tabs_table/MultipleTabsTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { COLOR_TYPE } from "@/constants/color";
import {
  ConflictActionsBtnKey,
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  MIME_TYPES,
  Module,
  ModuleKeys,
} from "@/constants/general";
import { RELATIONSHIP_DISCLOSURE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { StatusDTO } from "@/models/status/Status";
import { GetUsersParams } from "@/models/user/User";
import { downloadFile, formatDate } from "@/utils";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { Button, Grid, IconButton } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { endOfDay, format } from "date-fns";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { Range as DateRange } from "react-date-range";
import { AppContext } from "@/context/AppContext";
import { GridFilterItem } from "@mui/x-data-grid";
import { useRecallConflict } from "@/apis/service/conflict_management/conflictMngFormPopup";
import { TimeExtensionConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/time_extension_conflict_mng_form";
import { ForwardConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/forward_conflict_mng_form";
import { RequestAdditionalForm } from "@/features/conflict_management/conflict _management_dialog/request_additional_information_form";
import { RequestEvaluateConflictForm } from "@/features/conflict_management/conflict _management_dialog/RequestEvalueteConfictForm";
import { RequestApprovalConflictForm } from "@/features/conflict_management/conflict _management_dialog/request_approval_form";
import { ConfirmConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/confirm_conflict_mng_form";
import { FinishConflictForm } from "@/features/conflict_management/conflict _management_dialog/finish_conflict_mng_form";
import SendMailConflictForm from "@/features/conflict_management/conflict _management_dialog/sendmail_conflict_form";
import { FollowConflictForm } from "@/features/conflict_management/conflict _management_dialog/follow_conflict_mng_form";
import { FeedbackConflictForm } from "@/features/conflict_management/conflict _management_dialog/feedback_conflict_mng_form";
import { SignApprovalConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/sign_approval_conflict_form";
import { EvaluateConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/evaluate_form";
import { BaseRelationshipDisclosureFields, GetRelationshipDisclosureListParams } from "@/models/relationship-disclosure/RelationshipDisclosureList";
import { RelationMngActions } from "./RelationMngActions/RelationMngActions";
import { listStatusConfirmRelation, listStatusEvaluateRelation } from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import { getListRelationShipDisclosureQueryFn, getRelationShipDisclosureExcel, shareRelationshipDisclosureFn } from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";
import SharePopup from "@/components/commons/share_popup/SharePopup";

export const RelationshipDisclosureTableConst = {
  GENERAL_TABLE: "LEGAL_ADVICE.title.general_table",
  GET_ALL_QUERY_KEY: "getAllRelationshipDisclosure",
  PERSONAL_TABLE: "LEGAL_ADVICE.title.personal_table",
  GET_PERSONAL_QUERY_KEY: "getPersonalRelationshipDisclosure",
  GET_RELATION_DISCLOSURE_EXCEL: "getRelationshipDisclosureExcel",
};

const getFieldLabel = (key: string) => {
  return `RELATION_SHIP_DISCLOSURE.column.${key}`;
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetRelationshipDisclosureListParams => {
  const params: GetRelationshipDisclosureListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 10,
    sortBy: BaseRelationshipDisclosureFields.ID,
    orderBy: "DESC",
  };
  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == BaseRelationshipDisclosureFields.DOCUMENT_NAME) {
      params[BaseRelationshipDisclosureFields.DOCUMENT_NAME] = item?.value;
    }
    if (
      item.field == BaseRelationshipDisclosureFields.EMPLOYEE_INFO_IDS &&
      item?.value
    ) {
      params[BaseRelationshipDisclosureFields.EMPLOYEE_INFO_IDS] = item?.value;
    }
    if (item.field == BaseRelationshipDisclosureFields.STATUS_CONFIRM) {
      params[BaseRelationshipDisclosureFields.STATUS_CONFIRM] = (item?.value ?? [])
        .map((item: StatusDTO) => item?.id ?? item)
        .join(",");
    }
    if (item.field == BaseRelationshipDisclosureFields.STATUS_EVALUATED) {
      params[BaseRelationshipDisclosureFields.STATUS_EVALUATED] = (
        item?.value ?? []
      )
        .map((item: StatusDTO) => item?.id ?? item)
        .join(",");
    }
    if (
      item.field == BaseRelationshipDisclosureFields.EMPLOYEE_POSITION &&
      item?.value
    ) {
      params[BaseRelationshipDisclosureFields.EMPLOYEE_POSITION] = item?.value;
    }
    if (
      item.field == BaseRelationshipDisclosureFields.EMPLOYEE_DEPARTMENT &&
      item?.value
    ) {
      params[BaseRelationshipDisclosureFields.EMPLOYEE_DEPARTMENT] = item?.value;
    }
    if (
      item.field == BaseRelationshipDisclosureFields.OFFICER_INFO_NAME &&
      item?.value
    ) {
      params[BaseRelationshipDisclosureFields.OFFICER_INFO_NAME] = item?.value;
    }
    if (
      item.field == BaseRelationshipDisclosureFields.OFFICER_INFO_AGENCY &&
      item?.value
    ) {
      params[BaseRelationshipDisclosureFields.OFFICER_INFO_AGENCY] = item?.value;
    }
    if (item.field == BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE) {
      params[BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE_FROM] = (
        item?.value as DateRange
      ).startDate?.toISOString();

      params[BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE_TO] = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }
    if (item.field == BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE) {
      params[BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE_FROM] = (
        item?.value as DateRange
      )?.startDate?.toISOString();

      params[BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE_TO] = endOfDay(
        new Date((item.value as DateRange)?.endDate as Date)
      )?.toISOString();
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};

const RelationshipDisclosureTable = () => {
  const { t, i18n } = useTranslation();
  const [activeTab, setActiveTab] = useState<number>(0);
  const router = useRouter();
  const appContext = useContext(AppContext);

  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });
  const [initialRelationshipDisclosure, setInitialRelationshipDisclosure] =
    useState<any>(undefined);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialRelationshipDisclosure(row);
      changePopupVisible(type, true);
    }
  };
  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload: boolean = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state) {
      setInitialRelationshipDisclosure(undefined);
    }
    if (reload) {
      getAllRelationshipDisclosureQuery.refetch();
      getPersonalRelationshipDisclosureQuery.refetch();
    }
  };
  const { mutateAsync: recallConflictMutationFn } = useRecallConflict({
    config: {
      onSuccess: () => {
        toast.success(
          t("RELATION_SHIP_DISCLOSURE.recallConflict.message.recall_success")
        );
        // getLegalAdviceQuery.refetch().then((response) => {
        //   setInitialLegalAdvice(response.data);
        // });
      },
    },
  });
  const [relationshipDisclosureTableColumns] = useState<
    MultipleFilterTableColumn[]
  >([
    {
      key: BaseRelationshipDisclosureFields.ID,
      label: BaseRelationshipDisclosureFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: "center",
    },
    {
      key: BaseRelationshipDisclosureFields.DOCUMENT_NAME,
      label: BaseRelationshipDisclosureFields.DOCUMENT_NAME,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => (
        // <ConflictManagementTableTooltip
        //   adviceId={params.id}
        //   adviceName={params?.row?.conflictName}
        // >
        <span>{params.value}</span>
        // </ConflictManagementTableTooltip>
      ),
    },
    {
      key: BaseRelationshipDisclosureFields.EMPLOYEE_CODE,
      label: BaseRelationshipDisclosureFields.EMPLOYEE_CODE,
      filterLabel: "RELATION_SHIP_DISCLOSURE.label.employeeInfo",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 200,
      renderCell: (params) => params?.row?.employeeInfoResponse?.employee?.employeeCode,
      filterOperators: getAsyncSelectOperators(
        {
          getOptions: async (keyword) => {
            if (typeof keyword == "string") {
              const params: GetUsersParams = {
                searchTerm: keyword as string,
                page: 0,
                size: 100,
                sortBy: "name",
                sortOrder: "ASC",
              };
              const response = await getUsers(params);

              return response?.users ?? [];
            } else if (keyword?.length && keyword.length > 0) {
              return getUser(keyword[0])
                .then((response) => (response ? [response] : []))
                .catch(() => []);
            }
            return [];
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) =>
            `${item?.name} - ${item?.position?.name ? `${item?.position?.name}.` : ""
            }${item?.department?.name ?? ""}`,
          keyQuery: BaseRelationshipDisclosureFields.EMPLOYEE_INFO_IDS,
        },
        t
      ),
    },
    {
      key: BaseRelationshipDisclosureFields.EMPLOYEE_NAME,
      label: BaseRelationshipDisclosureFields.EMPLOYEE_NAME,
      type: undefined,
      quickFilter: false,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => {
        return params?.row?.employeeInfoResponse?.employee?.name ?? "";
      },
    },
    {
      key: BaseRelationshipDisclosureFields.EMPLOYEE_POSITION,
      label: BaseRelationshipDisclosureFields.EMPLOYEE_POSITION,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) =>
        params?.row?.employeeInfoResponse?.positionNameCustom ?? "",
    },
    {
      key: BaseRelationshipDisclosureFields.EMPLOYEE_DEPARTMENT,
      label: BaseRelationshipDisclosureFields.EMPLOYEE_DEPARTMENT,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) =>
        params?.row?.employeeInfoResponse?.departmentNameCustom ?? "",
    },
    {
      key: BaseRelationshipDisclosureFields.NAME,
      label: BaseRelationshipDisclosureFields.NAME,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.officerInfoResponse?.name ?? "",
    },
    {
      key: BaseRelationshipDisclosureFields.AGENCY,
      label: BaseRelationshipDisclosureFields.AGENCY,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 200,
      renderCell: (params) => params?.row?.officerInfoResponse?.agency ?? "",
    },
    {
      key: BaseRelationshipDisclosureFields.STATUS_CONFIRM,
      label: BaseRelationshipDisclosureFields.STATUS_CONFIRM,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        return (
          params.value?.name ? <Button
            variant="outlined"
            style={{
              background:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params.value?.name}
          </Button> : <></>
        );
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusListNames({
              names: listStatusConfirmRelation,
              modules: [Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!],
            });
            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) => item?.name,
          keyQuery: `relationship-disclosure-${BaseRelationshipDisclosureFields.STATUS_CONFIRM}`,
        },
        t
      ),
    },
    {
      key: BaseRelationshipDisclosureFields.STATUS_EVALUATED,
      label: BaseRelationshipDisclosureFields.STATUS_EVALUATED,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        return (
          params.value?.name ? <Button
            variant="outlined"
            style={{
              background:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params.value?.name}
          </Button> : <></>
        );
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusListNames({
              names: listStatusEvaluateRelation,
              modules: [Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!],
            });
            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item?.id,
          getOptionLabel: (item) => item?.name,
          keyQuery: `relationship-disclosure-${BaseRelationshipDisclosureFields.STATUS_EVALUATED}`,
        },
        t
      ),
    },
    {
      key: BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE,
      label: BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE,
      filterLabel: `RELATION_SHIP_DISCLOSURE.label.${BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE}`,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
    },
    {
      key: BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE,
      label: BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE,
      filterLabel: `RELATION_SHIP_DISCLOSURE.label.${BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE}`,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
    },
    {
      key: BaseRelationshipDisclosureFields.BUTTON_ACTION,
      label: BaseRelationshipDisclosureFields.BUTTON_ACTION,
      type: undefined,
      // renderCell: (params) => "Action",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      renderCell: (params) =>
        !params?.row?.isDraft &&
        params?.row?.status?.name !==
        ConflictManagementStatusContent.get(
          ConflictManagementStatusKey.COMPLETED
        ) &&
        RelationMngActions({
          actionButtonItemValidate: Object.entries(params?.row.buttonAction)
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            .filter(([_, value]) => value !== 3)
            .map(([key, value]) => ({
              typeBtn: key,
              disable: value === 2,
            })),
          params: params,
          handleClickRecall: async () =>
            recallConflictMutationFn(Number(params?.row.id)),
          handleClickForWard: () =>
            handleClick(ConflictActionsBtnKey.FORWARD, params.row),
          handleClickExtendTime: () =>
            handleClick(
              ConflictActionsBtnKey.REQUEST_TIME_EXTENSION,
              params.row
            ),
          handleClickConfirm: () =>
            handleClick(ConflictActionsBtnKey.CONFIRM, params.row),
          handleClickRequestAdditional: () =>
            handleClick(ConflictActionsBtnKey.REQUEST_ADDITIONAL, params.row),
          handleClickRequestEvaluate: () =>
            handleClick(ConflictActionsBtnKey.REQUEST_EVALUATE, params.row),
          handleClickDone: () =>
            handleClick(ConflictActionsBtnKey.DONE, params.row),
          handleClickRequestConfirm: () =>
            handleClick(ConflictActionsBtnKey.REQUEST_CONFIRM, params.row),
          handleClickConflictMonitor: () =>
            handleClick(ConflictActionsBtnKey.CONFLICT_MONITORING, params.row),
          handleClickSendMail: () =>
            handleClick(ConflictActionsBtnKey.SEND_MAIL),
          handleClickFeedBack: () =>
            handleClick(ConflictActionsBtnKey.FEEDBACK, params.row),
          handleClickExtendTimeConfirm: () =>
            handleClick(
              ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
              params.row
            ),
          handleClickEvaluate: () =>
            handleClick(ConflictActionsBtnKey.EVALUATE, params.row),
          handleClickSignApprove: () =>
            handleClick(ConflictActionsBtnKey.APPROVE, params.row),
          handleClickShare: () =>
            handleClick(ConflictActionsBtnKey.SHARE, params.row),
        }),
      cellClassName: "last-column-sticky",
      headerClassName: "last-column-sticky-header",
    },
  ]);

  /** Get all relation ship */
  const getAllRelationshipDisclosureQuery = useQuery({
    queryKey: [RelationshipDisclosureTableConst.GET_ALL_QUERY_KEY],
    queryFn: () =>
      getListRelationShipDisclosureQueryFn({
        ...castTableStateToParams(generalTableState),
        tab: 0,
      }),
    enabled: false,
  });
  /** Get personal relation ship request */
  const getPersonalRelationshipDisclosureQuery = useQuery({
    queryKey: [RelationshipDisclosureTableConst.GET_PERSONAL_QUERY_KEY],
    queryFn: () =>
      getListRelationShipDisclosureQueryFn({
        ...castTableStateToParams(personalTableState),
        tab: 1,
      }),
    enabled: false,
  });

  useEffect(() => {
    generalTableState &&
      activeTab === 0 &&
      getAllRelationshipDisclosureQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  }, [generalTableState, activeTab]);

  useEffect(() => {
    personalTableState &&
      activeTab === 1 &&
      getPersonalRelationshipDisclosureQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
  }, [personalTableState, activeTab]);

  /** Get excel file */
  const getRelationshipDisclosureQuery = useQuery({
    queryKey: [RelationshipDisclosureTableConst.GET_RELATION_DISCLOSURE_EXCEL],
    queryFn: () =>
      getRelationShipDisclosureExcel({
        ...castTableStateToParams(
          activeTab === 0 ? generalTableState : personalTableState
        ),
        tab: activeTab,
        size: 9999,
        isEnglish: i18n.language === "en",
      }),
    enabled: false,
  });
  const shareMutation = useMutation({
    mutationFn: shareRelationshipDisclosureFn,
    onSuccess: () => {
      toast.success(
        t(`RELATION_SHIP_DISCLOSURE.messages.shareSuccess`)
      );
    },
  });

  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getRelationshipDisclosureQuery.refetch().then((response: any) => {
              const fileName = `${i18n.language === "en"
                ? "RelationshipDisclosure"
                : "Kê khai quan hệ"
                }_${format(new Date(), "ddMMyyyy")}`;
              response?.data &&
                downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getAllRelationshipDisclosureQuery.isFetching ||
            getPersonalRelationshipDisclosureQuery.isFetching ||
            getRelationshipDisclosureQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };

  return (
    <>
      <MultipleTabsTable
        tableTabs={[
          {
            tabName: t("RELATION_SHIP_DISCLOSURE.label.allRelationInterest"),
            tabKey: RelationshipDisclosureTableConst.GENERAL_TABLE,
            data: getAllRelationshipDisclosureQuery?.data?.data ?? [],
            loading: getAllRelationshipDisclosureQuery?.isFetching,
            rowCount: getAllRelationshipDisclosureQuery?.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t("RELATION_SHIP_DISCLOSURE.label.myRelationInterest"),
            tabKey: RelationshipDisclosureTableConst.PERSONAL_TABLE,
            data: getPersonalRelationshipDisclosureQuery?.data?.data ?? [],
            loading: getPersonalRelationshipDisclosureQuery?.isFetching,
            rowCount: getPersonalRelationshipDisclosureQuery?.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={relationshipDisclosureTableColumns.map((column) => ({
          ...column,
          label: column.label ? getFieldLabel(column.label) : "",
        }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        quickFilterProps={{
          defaultSelectedOptionKey: BaseRelationshipDisclosureFields.DOCUMENT_NAME,
          placeHolder: () =>
            t("RELATION_SHIP_DISCLOSURE.placeholder.enterAdviceName"),
        }}
        onRowClick={(params) =>
          router.push(
            `/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
          )
        }
        exportFile={renderExportButton()}
        onTabChange={setActiveTab}
      />

      {popupVisibleState?.[ConflictActionsBtnKey.SHARE] && <SharePopup
        setIsOpen={(state, reload) =>
          changePopupVisible(ConflictActionsBtnKey.SHARE, state, reload)
        }
        isOpen={true}
        owner={initialRelationshipDisclosure?.pic}
        pics={initialRelationshipDisclosure?.responsibleUsers}
        onSubmit={async (data: any) => {
          const params = {
            id: initialRelationshipDisclosure?.id as number,
            data
          }
          await shareMutation.mutateAsync(params)
        }}
        initialValue={{
          legalAccessType: initialRelationshipDisclosure?.legalAccessType,
          sharedDepartments: initialRelationshipDisclosure?.sharedDepartments,
          sharedUsers: initialRelationshipDisclosure?.sharedUsers
        }}
      />}

      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAdditionalForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_ADDITIONAL,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL]}
          conflictId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialRelationshipDisclosure?.pic],
          }}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FORWARD] && (
        <ForwardConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FORWARD, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FORWARD]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {initialRelationshipDisclosure &&
        popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION] && (
          <TimeExtensionConflictMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.REQUEST_TIME_EXTENSION,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION]
            }
            ciId={initialRelationshipDisclosure?.id}
            name={initialRelationshipDisclosure?.conflictName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialRelationshipDisclosure?.pic],
              timeExtensionType: 1,
            }}
          />
        )}
      {initialRelationshipDisclosure &&
        popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM] && (
          <TimeExtensionConflictMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM]
            }
            ciId={initialRelationshipDisclosure?.id}
            name={initialRelationshipDisclosure?.conflictName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialRelationshipDisclosure?.pic],
              timeExtensionType: 2,
            }}
          />
        )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE] && (
        <RequestEvaluateConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_EVALUATE,
              state,
              reload
            )
          }
          ciId={initialRelationshipDisclosure?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE]}
          name={initialRelationshipDisclosure?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM] && (
        <RequestApprovalConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_CONFIRM,
              state,
              reload
            )
          }
          ciId={initialRelationshipDisclosure?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM]}
          name={initialRelationshipDisclosure?.conflictName}
          initialValue={{
            deadline: initialRelationshipDisclosure.lcReviewDeadline,
          }}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFIRM] && (
        <ConfirmConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.CONFIRM, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.CONFIRM]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.DONE] && (
        <FinishConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.DONE]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL] && (
        <SendMailConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.SEND_MAIL, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL]}
          conflictId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          legalAdvice={initialRelationshipDisclosure}
          senderDocumentManagement ={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFLICT_MONITORING] && (
        <FollowConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.CONFLICT_MONITORING,
              state,
              reload
            )
          }
          isOpen={true}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK] && (
        <FeedbackConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FEEDBACK, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {/* Ký duyệt */}
      {popupVisibleState?.[ConflictActionsBtnKey.APPROVE] && (
        <SignApprovalConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.APPROVE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.APPROVE]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}

      {/* Đánh giá nhận xét */}
      {popupVisibleState?.[ConflictActionsBtnKey.EVALUATE] && (
        <EvaluateConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.EVALUATE, state, reload)
          }
          isOpen={true}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
    </>
  );
};

export default RelationshipDisclosureTable;
