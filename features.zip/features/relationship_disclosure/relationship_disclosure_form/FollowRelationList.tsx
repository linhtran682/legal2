import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import { FC, useContext, useState } from "react";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import { useQueryClient } from "@tanstack/react-query";
import {
  RelationshipDisclosureRole,
  RelationshipDisclosureRoleKey,
} from "@/constants/general";
import { AppContext } from "@/context/AppContext";
import { ConflictInformation } from "@/models/relationship-disclosure/ConfirmConflict";
import { GET_FOLLOW_MANAGEMENT } from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";
import RelationshipDisclosureItem from "./RelationshipDisclosureItem";
import { useDeleteFollowMng, useGetFollowMng } from "@/apis/service/relationship_disclosure/relationMngFormPopup";
import { FollowRelationshipForm } from "../relationship_disclosure_dialog/follow_relationship_mng_form";

interface ConfirmListProps {
  relationshipId: number;
  documentName?: string;
  initialValue?: any;
  ownRole?: number[];
}

const FollowRelationList: FC<ConfirmListProps> = (props) => {
  const { relationshipId, ownRole, initialValue } = props;
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedFollow, setSelectedFollow] = useState<
    ConflictInformation | undefined
  >(undefined);
  const [followPopupState, setFollowPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const { data: getFollowListQuery } = useGetFollowMng({
    request: { drId: relationshipId },
    config: {
      enabled: !!relationshipId,
    },
  });
  const { mutateAsync: deleteFollowMutationFn } = useDeleteFollowMng({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t("Thông tin theo dõi"),
          })
        );
        setFollowPopupState(DefaultConfirmPopupState);
        queryClient.invalidateQueries({
          queryKey: [GET_FOLLOW_MANAGEMENT],
        });
      },
    },
  });
  const handleEditClick = (relationshipItem: ConflictInformation) => {
    setSelectedFollow(relationshipItem);
    setPopupVisible(true);
  };

  const handleDeleteClick = (relationshipItem: ConflictInformation) => {
    setFollowPopupState({
      open: true,
      icon: <DeleteRecordDialogIcon />,
      title: "Bạn có chắc chắn muốn xóa không ?",
      handleConfirm: async () => {
        await deleteFollowMutationFn({
          drId: relationshipId,
          followId: relationshipItem.id,
        });
        setFollowPopupState(DefaultConfirmPopupState);
      },
      handleCancel: () => setFollowPopupState(DefaultConfirmPopupState),
    });
  };
  const onPopupClose = async () => {
    setPopupVisible(false);
    setSelectedFollow(undefined);
  };
  return getFollowListQuery?.responses?.length ? (
    <Grid
      container
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
    >
      <Typography fontWeight="bold">
        {t("CONFLICT_MANAGEMENT.label.informationFollow")}
      </Typography>
      {(getFollowListQuery?.responses ?? [])?.map(
        (relationshipItem: ConflictInformation, index: number) => (
          <RelationshipDisclosureItem
            key={relationshipItem.id.toString()}
            indexRelationshipItem={index}
            isActiveAction={
              ownRole?.includes(
                RelationshipDisclosureRole.get(
                  RelationshipDisclosureRoleKey.RELATION_SHIP_DECLATION
                )!
              ) ||
              ownRole?.includes(
                RelationshipDisclosureRole.get(
                  RelationshipDisclosureRoleKey.DEPT_HEAD_RELATION_SHIP_DECLATION
                )!
              ) ||
              ownRole?.includes(
                RelationshipDisclosureRole.get(RelationshipDisclosureRoleKey.LC)!
              )
            }
            label={`RELATION_SHIP_DISCLOSURE.label.requester`}
            onDeleteClick={() => handleDeleteClick(relationshipItem)}
            onEditClick={() => handleEditClick(relationshipItem)}
            relationshipItem={{
              ...relationshipItem,
              user: relationshipItem?.userResponse,
              attachments: relationshipItem?.attachmentResponses,
            }}
          />
        )
      )}
      <ConfirmPopup {...followPopupState} />
      {popupVisible && (
        <>
          <FollowRelationshipForm
            setIsOpen={onPopupClose}
            isOpen={popupVisible}
            drId={relationshipId}
            followId={selectedFollow?.id}
            name={initialValue?.documentName}
            senderConflict={appContext?.me}
          />
        </>
      )}
    </Grid>
  ) : null;
};

export default FollowRelationList;
