import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import { FC, useContext, useState } from "react";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import { useQueryClient } from "@tanstack/react-query";
import { RelationshipDisclosureRole, RelationshipDisclosureRoleKey } from "@/constants/general";
import { AppContext } from "@/context/AppContext";
import { GET_CONFIRM_INFORMATION_MANAGEMENT } from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";
import { ConflictInformation } from "@/models/relationship-disclosure/ConfirmConflict";
import RelationshipDisclosureItem from "./RelationshipDisclosureItem";
import { useDeleteConfirmInformation, useGetConfirmInformation } from "@/apis/service/relationship_disclosure/relationMngFormPopup";
import { ConfirmRelationshipMngForm } from "../relationship_disclosure_dialog/confirm_relationship_form";

interface ConfirmListProps {
  relationshipId: number;
  documentName?: string;
  initialValue?: any;
  ownRole?: number[]
}

const ConfirmationInformationList: FC<ConfirmListProps> = (props) => {
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const { relationshipId, ownRole, initialValue } = props;
  const queryClient = useQueryClient();
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedConfirm, setSelectedConfirm] = useState<ConflictInformation | undefined>(
    undefined
  );
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const { data: getConfirmationInformationListQuery } =
    useGetConfirmInformation({
      request: { drId: relationshipId },
      config: {
        enabled: !!relationshipId,
      },
    });
  const { mutateAsync: deleteConfirmInformationMutationFn } =
    useDeleteConfirmInformation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("Xác nhận"),
            })
          );
          setConfirmPopupState(DefaultConfirmPopupState);
          queryClient.invalidateQueries({
            queryKey: [GET_CONFIRM_INFORMATION_MANAGEMENT],
          });
        },
      },
    });
  const handleEditClick = (relationshipItem: ConflictInformation) => {
    setSelectedConfirm(relationshipItem);
    setPopupVisible(true);
  };

  const handleDeleteClick = (relationshipItem: ConflictInformation) => {
    setConfirmPopupState({
      open: true,
      icon: <DeleteRecordDialogIcon />,
      title: "Bạn có chắc chắn muốn xóa không ?",
      handleConfirm: async () => {
        await deleteConfirmInformationMutationFn({
          drId: relationshipId,
          confirmId: relationshipItem.id,
        });
        setConfirmPopupState(DefaultConfirmPopupState);
      },
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
    });
  };
  const onPopupClose = async () => {
    setPopupVisible(false);
    setSelectedConfirm(undefined);
  };
  return getConfirmationInformationListQuery?.responses?.length ? (
    <Grid
      container
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
    >
      <Typography fontWeight="bold">
        {t("CONFLICT_MANAGEMENT.label.informationConfirm")}
      </Typography>
      {(getConfirmationInformationListQuery?.responses ?? [])?.map(
        (relationshipItem: ConflictInformation, index: number) => (
          <RelationshipDisclosureItem
            key={relationshipItem.id.toString()}
            indexRelationshipItem={index}
            isActiveAction={ownRole?.includes(
              RelationshipDisclosureRole.get(
                RelationshipDisclosureRoleKey.DEPT_HEAD_RELATION_SHIP_DECLATION
              )!
            )}
            label={`RELATION_SHIP_DISCLOSURE.label.approver`}
            onDeleteClick={() => handleDeleteClick(relationshipItem)}
            onEditClick={() => handleEditClick(relationshipItem)}
            relationshipItem={{
              ...relationshipItem,
              user: relationshipItem?.userResponse,
              attachments: relationshipItem?.attachmentResponses,
            }}
          />
        )
      )}
      <ConfirmPopup {...confirmPopupState} />
      {popupVisible && (
        <>
          <ConfirmRelationshipMngForm
            setIsOpen={onPopupClose}
            isOpen={popupVisible}
            drId={relationshipId}
            confirmId={selectedConfirm?.id}
            name={initialValue?.documentName}
            senderDocumentManagement={appContext?.me}
          />
        </>
      )}
    </Grid>
  ) : null;
};

export default ConfirmationInformationList;
