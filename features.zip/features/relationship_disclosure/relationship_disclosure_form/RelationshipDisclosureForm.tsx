import {
  getDepartmentHeads,
  getLegalDepartments,
} from "@/apis/service/department/department";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { getUser, getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { CheckBoxGroupField } from "@/components/commons/form_inputs/CheckBoxGroupFiled";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import DateTimeInput from "@/components/commons/inputs/date_time_input/DateTimeInput";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SPACING } from "@/constants/format";
import { Module, ModuleKeys } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { LANGUAGES } from "@/locales/config-translation";
import { FileInfo } from "@/models/law_document/LawDocument";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import { GetUsersParams, UserProfileDTO } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormHelperText, Grid, Stack, Typography } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { FC, ReactNode, useContext, useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import {
  RelationshipDisclosureBodySend,
  RelationshipDisclosureDetailFields,
  SaveRelationshipDisclosureRequestCreateSchema,
  SaveRelationshipDisclosureRequestSchema,
  TypeRelationshipDisclosureForm,
} from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import ConfirmationInformationList from "./ConfirmationInformationList";
import EvaluateCommentList from "./EvaluateCommentList";
import FollowRelationList from "./FollowRelationList";
import { getAssignedPerson } from "@/apis/service/assignment/Assignment";
import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";

export interface RelationshipDisclosureFormProps {
  formMode?: "create" | "update";
  onSubmit: (data: RelationshipDisclosureBodySend) => void;
  onSubmitDraft?: (data: RelationshipDisclosureBodySend) => void;
  initialValue?: any;
  onCancel: () => void;
  loading?: boolean;
  defaultValues?: TypeRelationshipDisclosureForm;
  children?: ReactNode;
}

function findDeepestId(department: any): { id: string; depth: number } {
  let deepest = { id: department.id, depth: 1 };

  department?.children?.forEach((child: any) => {
    const childDeepest = findDeepestId(child);
    if (childDeepest.depth + 1 > deepest.depth) {
      deepest = { id: childDeepest.id, depth: childDeepest.depth + 1 };
    }
  });

  return deepest;
}

const RelationshipDisclosureForm: FC<RelationshipDisclosureFormProps> = (
  props
) => {
  const {
    formMode,
    onSubmit,
    onSubmitDraft,
    onCancel,
    loading,
    defaultValues,
    initialValue,
  } = props;
  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);
  const { i18n, t } = useTranslation();
  const appContext = useContext(AppContext);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const [employeeInfo, setEmployeeInfo] = useState<UserProfileDTO>();
  // TypeRelationshipManagementForm
  const form = useForm<any>({
    resolver: yupResolver(
      formMode === "update"
        ? SaveRelationshipDisclosureRequestSchema
        : SaveRelationshipDisclosureRequestSchema.concat(
            SaveRelationshipDisclosureRequestCreateSchema
          )
    ),
    defaultValues,
    mode: "onBlur",
    disabled:
      !appContext.meCanWrite ||
      (formMode === "update" && !ownRole?.includes(1)),
  });

  useEffect(() => {
    if (initialValue) {
      let attachments: any[] = [];
      if (initialValue?.receptionStaffInfoAttachments?.length) {
        attachments = initialValue?.receptionStaffInfoAttachments?.map(
          (item: any) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          }
        );
      }
      setFiles(attachments);
      setOwnRole(initialValue?.ownerRoles);
    }
  }, [initialValue]);

  useEffect(() => {
    if (defaultValues) {
      form.reset(defaultValues);
    }
  }, [defaultValues]);

  const getLegalDepartmentQuery = useQuery({
    queryKey: ["relationship-disclosure/get-legal-department"],
    queryFn: async () => {
      try {
        const response = await getLegalDepartments();
        const deepestId = findDeepestId(
          response?.departments?.length ? response?.departments?.[0] : null
        );
        return deepestId?.id ?? null;
      } catch (error) {}
      return null;
    },
    placeholderData: (prev) => prev,
  });

  const getDepartmentHeadQuery = useQuery({
    queryKey: ["relationship-disclosure/get-department-heads"],
    queryFn: async () => {
      const departmentHeadResponse = await getDepartmentHeads(
        initialValue?.pic?.departmentResponse?.id ??
          (appContext?.me?.department?.id as string)
      );
      return departmentHeadResponse;
    },
    placeholderData: (prev) => prev,
    enabled: !!initialValue?.pic || !!appContext?.me,
  });

  const checkDeptHeadFlag = form.watch(
    RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG
  );
  const checkDivisionFlag = form.watch(
    RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG
  );
  const sendToError = !checkDeptHeadFlag && !checkDivisionFlag;

  const handleSaveParams = async () => {
    let attachments: number[] = [];
    if (files.length > 0) {
      const filterFile: any = [];
      const filterFileId: number[] = [];

      files.filter((item: any) => {
        if (item?.id === undefined) {
          filterFile.push(item);
        } else {
          filterFileId.push(item?.id);
        }
      });
      if (filterFile.length > 0) {
        const response = await GetListIdFile(filterFile);
        const formatResponse: number[] = response.fileUploadResponses.map(
          (item: FileInfo) => item.fileId
        );
        attachments = [...formatResponse, ...filterFileId];
      } else {
        attachments = [...filterFileId];
      }
    }

    const formValues = form.getValues();
    const params: RelationshipDisclosureBodySend =
      {} as RelationshipDisclosureBodySend;
    params[RelationshipDisclosureDetailFields.DOCUMENT_NAME] =
      formValues[RelationshipDisclosureDetailFields.DOCUMENT_NAME];
    params[RelationshipDisclosureDetailFields.STATUS_CONFIRM] = Number(
      formValues[RelationshipDisclosureDetailFields.STATUS_CONFIRM]
    );
    params[RelationshipDisclosureDetailFields.STATUS_EVALUATED] = Number(
      formValues[RelationshipDisclosureDetailFields.STATUS_EVALUATED]
    );
    params.employeeInfoRequest = {
      employeeId: formValues[RelationshipDisclosureDetailFields.EMPLOYEE_NAME],
      [RelationshipDisclosureDetailFields.DEPARTMENT_ID]:
        employeeInfo?.department?.id ??
        formValues?.employeeInfoResponse?.employee?.departmentResponse?.id,
      [RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM]:
        formValues[RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM] ??
        "",
      [RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM]:
        formValues[RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM] ??
        "",
      [RelationshipDisclosureDetailFields.GROUP_NAME]:
        formValues[RelationshipDisclosureDetailFields.GROUP_NAME] ?? "",
      [RelationshipDisclosureDetailFields.WORKING_AREA]:
        formValues[RelationshipDisclosureDetailFields.WORKING_AREA] ?? "",
      [RelationshipDisclosureDetailFields.MANAGER_ID]:
        formValues[RelationshipDisclosureDetailFields.MANAGER_ID],
    };
    (params[RelationshipDisclosureDetailFields.ATTACHMENTS] = attachments),
      (params.officerInfoRequest = {
        [RelationshipDisclosureDetailFields.NAME]:
          formValues[RelationshipDisclosureDetailFields.NAME],
        [RelationshipDisclosureDetailFields.AGENCY]:
          formValues[RelationshipDisclosureDetailFields.AGENCY],
        [RelationshipDisclosureDetailFields.POSITION]:
          formValues[RelationshipDisclosureDetailFields.POSITION],
        [RelationshipDisclosureDetailFields.ROLE_DESCRIPTION]:
          formValues[RelationshipDisclosureDetailFields.ROLE_DESCRIPTION],
        [RelationshipDisclosureDetailFields.CHARACTERISTIC]:
          formValues[RelationshipDisclosureDetailFields.CHARACTERISTIC],
      });
    params[RelationshipDisclosureDetailFields.RELATION_SHIP] =
      formValues[RelationshipDisclosureDetailFields.RELATION_SHIP] ?? [];
    params[RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG] = Number(
      formValues[RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]
    );
    params[RelationshipDisclosureDetailFields.EMPLOYEE_IDS] = formValues?.[
      RelationshipDisclosureDetailFields.EMPLOYEE_IDS
    ]
      ? [formValues?.[RelationshipDisclosureDetailFields.EMPLOYEE_IDS]]
      : [];
    params[RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE] = new Date(
      formValues[RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE]
    ).toISOString();
    params[RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS] = formValues?.[
      RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS
    ]
      ? [formValues?.[RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS]]
      : [];
    params[RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE] = new Date(
      formValues[RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE]
    ).toISOString();
    params[RelationshipDisclosureDetailFields.REMIND] =
      (formMode === "create" &&
        !!formValues[RelationshipDisclosureDetailFields.REMIND]?.id) ||
      (formMode === "update" &&
        !!formValues[RelationshipDisclosureDetailFields.REMIND]?.title)
        ? {
            ...castReminderSchemaToSaveReminderDTO(
              formValues[RelationshipDisclosureDetailFields.REMIND]!
            ),
          }
        : {
            title: "",
            description: "",
            module: 2,
            receivedTitle: [],
            receivingDepartment: [],
            remindContents: [],
            relatedUsers: [],
          };
    params[RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG] =
      formValues?.[RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]
        ? 1
        : 0;
    params[RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG] =
      formValues?.[RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG]
        ? 1
        : 0;

    return params;
  };

  const handleChangeCode = async (EmployeeCode?: UserProfileDTO | null) => {
    if (!EmployeeCode) return;
    const departmentId = EmployeeCode?.department?.id;
    if (departmentId) {
      const deptHead = await getDepartmentHeads(departmentId);
      deptHead?.deptHead?.id &&
        form.setValue(
          RelationshipDisclosureDetailFields.MANAGER_ID,
          deptHead?.deptHead?.id
        );
    }
    setEmployeeInfo(EmployeeCode);
    form.setValue(
      RelationshipDisclosureDetailFields.EMPLOYEE_NAME,
      EmployeeCode.id
    );
    form.setValue(
      RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM,
      EmployeeCode?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
    form.setValue(
      RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM,
      EmployeeCode?.position?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
  };

  const handleChangeEmployee = async (EmployeeName?: UserProfileDTO | null) => {
    if (!EmployeeName) return;
    const departmentId = EmployeeName?.department?.id;
    if (departmentId) {
      const deptHead = await getDepartmentHeads(departmentId);
      deptHead?.deptHead?.id &&
        form.setValue(
          RelationshipDisclosureDetailFields.MANAGER_ID,
          deptHead?.deptHead?.id
        );
    }
    setEmployeeInfo(EmployeeName);
    form.setValue(
      RelationshipDisclosureDetailFields.EMPLOYEE_ID,
      EmployeeName.id
    );
    form.setValue(
      RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM,
      EmployeeName?.department?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
    form.setValue(
      RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM,
      EmployeeName?.position?.[
        i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
      ] ?? ""
    );
  };

  const getAssignedPersonQuery = useQuery({
    queryKey: ["relation/get-legal-assigned-person"],
    queryFn: () => getAssignedPerson(),
    placeholderData: (prev) => prev,
    enabled: false,
  });

  const disableCheckbox =
    !appContext.meCanWrite || (formMode === "update" && !ownRole?.includes(1));

  return (
    <>
      <Grid
        container
        className="form-wrapper"
        style={{ marginTop: formMode === "update" ? 24 : 0 }}
      >
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              {formMode !== "update" && (
                <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={RelationshipDisclosureDetailFields.DOCUMENT_NAME}
                    label={t(
                      `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.DOCUMENT_NAME}`
                    )}
                    placeHolder={t(
                      `RELATION_SHIP_DISCLOSURE.placeholder.${RelationshipDisclosureDetailFields.DOCUMENT_NAME}`
                    )}
                    required
                    minRows={2}
                    disabled={!appContext.meCanWrite}
                  />
                </Grid>
              )}
              {/* {formMode === "update" && (
                <>
                  <Grid item width={"100%"}>
                    <FormSelectButton
                      control={form.control}
                      name={RelationshipDisclosureDetailFields.STATUS_CONFIRM}
                      label={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.STATUS_CONFIRM}`
                      )}
                      placeholder={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.STATUS_CONFIRM}`
                      )}
                      keyQuery={`${RelationshipDisclosureDetailFields.STATUS_CONFIRM}-query-relationship-disclosure-form`}
                      getOptions={async (keyword) => {
                        if (typeof keyword == "string") {
                          const response = await getStatusListNames({
                            names: [...listStatusConfirmRelation, keyword],
                            modules: [
                              Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!,
                            ],
                          });
                          return response?.statusResponses || [];
                        } else {
                          if (keyword?.length && keyword.length > 0) {
                            return getStatus(Number(keyword[0])).then((value) =>
                              value ? [value] : []
                            );
                          }
                        }

                        return [] as StatusDTO[];
                      }}
                      getOptionKey={(option) => option.id.toString()}
                      getOptionLabel={(option) => option.name}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                  <Grid item width={"100%"}>
                    <FormSelectButton
                      control={form.control}
                      name={RelationshipDisclosureDetailFields.STATUS_EVALUATED}
                      label={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.STATUS_EVALUATED}`
                      )}
                      placeholder={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.STATUS_EVALUATED}`
                      )}
                      keyQuery={`${RelationshipDisclosureDetailFields.STATUS_EVALUATED}-query-relationship-disclosure-form`}
                      getOptions={async (keyword) => {
                        if (typeof keyword == "string") {
                          const response = await getStatusListNames({
                            names: [...listStatusEvaluateRelation, keyword],
                            modules: [
                              Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!,
                            ],
                          });
                          return response?.statusResponses || [];
                        } else {
                          if (keyword?.length && keyword.length > 0) {
                            return getStatus(Number(keyword[0])).then((value) =>
                              value ? [value] : []
                            );
                          }
                        }

                        return [] as StatusDTO[];
                      }}
                      getOptionKey={(option) => option.id.toString()}
                      getOptionLabel={(option) => option.name}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                </>
              )} */}
              <Grid item width={"100%"}>
                <Grid
                  container
                  className="form-sub-section-wrapper"
                  position={"relative"}
                  rowGap={GLOBAL_SPACING}
                >
                  <Grid item width={"100%"}>
                    <Typography fontWeight="bold">
                      {t("RELATION_SHIP_DISCLOSURE.label.information")}
                    </Typography>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        name={RelationshipDisclosureDetailFields.EMPLOYEE_ID}
                        minCharLength={1}
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.EMPLOYEE_ID}`
                        )}
                        placeholder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.EMPLOYEE_ID}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return (
                              response?.users?.filter(
                                (user) => user.employeeCode
                              ) ?? []
                            );
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option.employeeCode ?? ""}`
                        }
                        getOptionKey={(option) => option.id}
                        keyQuery={"employeesCode/queryUser"}
                        onChange={(_, option) => handleChangeCode(option)}
                        isFocus
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        minCharLength={1}
                        name={RelationshipDisclosureDetailFields.EMPLOYEE_NAME}
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.EMPLOYEE_NAME}`
                        )}
                        placeholder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.EMPLOYEE_NAME}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return response?.users ?? [];
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option.name ?? ""} - ${option.employeeCode ?? ""}`
                        }
                        onChange={(_, option) => handleChangeEmployee(option)}
                        getOptionKey={(option) => option.id}
                        keyQuery={"employeesName/queryUser"}
                        isFocus
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={
                          RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM
                        }
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM}`
                        )}
                        placeHolder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={
                          RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM
                        }
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM}`
                        )}
                        placeHolder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={RelationshipDisclosureDetailFields.GROUP_NAME}
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.GROUP_NAME}`
                        )}
                        placeHolder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.GROUP_NAME}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={RelationshipDisclosureDetailFields.WORKING_AREA}
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.WORKING_AREA}`
                        )}
                        placeHolder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.WORKING_AREA}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={12}>
                    <Grid item width="100%">
                      <FormAsyncSelect<any, UserProfileDTO>
                        control={form.control}
                        minCharLength={1}
                        name={RelationshipDisclosureDetailFields.MANAGER_ID}
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.MANAGER_ID}`
                        )}
                        placeholder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.MANAGER_ID}`
                        )}
                        getOptions={async (keyword) => {
                          if (typeof keyword == "string") {
                            const params: GetUsersParams = {
                              searchTerm: keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            };
                            const response = await getUsers(params);

                            return response?.users ?? [];
                          } else if (keyword?.length && keyword.length > 0) {
                            return getUser(keyword[0])
                              .then((response) => (response ? [response] : []))
                              .catch(() => []);
                          }

                          return [];
                        }}
                        getOptionLabel={(option) =>
                          `${option?.name} - ${
                            option?.position?.name
                              ? `${option?.position?.name}.`
                              : ""
                          }${option?.department?.name ?? ""}`
                        }
                        getOptionKey={(option) => option.id}
                        keyQuery={"managerId/queryUser"}
                        isFocus
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={12} mt="10px">
                      <DropPreviewFileUploadComponent
                        dropView={formMode === "create"}
                        preview={formMode === "update"}
                        name={RelationshipDisclosureDetailFields.FILES}
                        control={form.control}
                        files={files}
                        setFiles={setFiles}
                        title={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.ATTACHMENTS}`
                        )}
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                        required
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <Grid
                  container
                  className="form-sub-section-wrapper"
                  position={"relative"}
                  rowGap={GLOBAL_SPACING}
                >
                  <Grid item width={"100%"}>
                    <Typography fontWeight="bold">
                      {t("RELATION_SHIP_DISCLOSURE.label.servantsRelation")}
                    </Typography>
                  </Grid>
                  <Grid container xs={12} justifyContent="space-between">
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={RelationshipDisclosureDetailFields.NAME}
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.NAME}`
                        )}
                        placeHolder={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.NAME}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                    <Grid item xs={5.9}>
                      <FormTextField
                        control={form.control}
                        name={RelationshipDisclosureDetailFields.AGENCY}
                        label={t(
                          `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.AGENCY}`
                        )}
                        placeHolder={t(
                          `RELATION_SHIP_DISCLOSURE.placeholder.${RelationshipDisclosureDetailFields.AGENCY}`
                        )}
                        required
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>
                  </Grid>
                  <Grid container xs={5.9}>
                    <FormTextField
                      control={form.control}
                      name={RelationshipDisclosureDetailFields.POSITION}
                      label={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.POSITION}`
                      )}
                      placeHolder={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.POSITION}`
                      )}
                      required
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                  <Grid container xs={12}>
                    <FormTextArea
                      control={form.control}
                      name={RelationshipDisclosureDetailFields.CHARACTERISTIC}
                      label={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.CHARACTERISTIC}`
                      )}
                      placeHolder={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.CHARACTERISTIC}`
                      )}
                      required
                      minRows={2}
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                  <Grid container xs={12}>
                    <FormTextArea
                      control={form.control}
                      name={RelationshipDisclosureDetailFields.ROLE_DESCRIPTION}
                      label={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.ROLE_DESCRIPTION}`
                      )}
                      placeHolder={t(
                        `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.ROLE_DESCRIPTION}`
                      )}
                      required
                      minRows={2}
                      disabled={
                        !appContext.meCanWrite ||
                        (formMode === "update" && !ownRole?.includes(1))
                      }
                    />
                  </Grid>
                </Grid>
              </Grid>
              <Grid item width="100%">
                <CheckBoxGroupField
                  label={t(
                    `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.RELATION_SHIP}`
                  )}
                  errors={
                    form.formState.errors?.[
                      RelationshipDisclosureDetailFields.RELATION_SHIP
                    ]
                  }
                  items={[...Array(10)].map((_, index) => ({
                    label: t(`RELATION_SHIP_DISCLOSURE.relationship.${index}`),
                    value: index,
                  }))}
                  required
                  name={RelationshipDisclosureDetailFields.RELATION_SHIP}
                  isDisabled={!appContext.meCanWrite}
                />
              </Grid>
              {form
                .watch(RelationshipDisclosureDetailFields.RELATION_SHIP)
                ?.includes(9) && (
                <Grid item width="100%">
                  <FormTextArea
                    control={form.control}
                    name={
                      RelationshipDisclosureDetailFields.REASON_RELATION_SHIP
                    }
                    placeHolder={t(
                      `RELATION_SHIP_DISCLOSURE.placeholder.${RelationshipDisclosureDetailFields.REASON_RELATION_SHIP}`
                    )}
                    minRows={2}
                    disabled={
                      !appContext.meCanWrite ||
                      (formMode === "update" && !ownRole?.includes(1))
                    }
                  />
                </Grid>
              )}
              <Grid item width={"100%"}>
                <FormAsyncSelect<any, UserProfileDTO>
                  control={form.control}
                  name={RelationshipDisclosureDetailFields.EMPLOYEE_IDS}
                  label={t(`RELATION_SHIP_DISCLOSURE.label.approver`)}
                  placeholder={t(`RELATION_SHIP_DISCLOSURE.label.approver`)}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return response?.users ?? [];
                    } else if (keyword?.length && keyword.length > 0) {
                      return getUser(keyword[0])
                        .then((response) => (response ? [response] : []))
                        .catch(() => []);
                    }

                    return [];
                  }}
                  getOptionLabel={(option) =>
                    `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                      option?.department?.name ?? option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="queryRelatedUser"
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              {getDepartmentHeadQuery?.data && (
                <Stack direction={"row"} width={"100%"} mt={0.5} gap={2}>
                  <Typography
                    sx={{
                      fontSize: "14px",
                      color: COLOR_TYPE.TOYOTA.TOYOTA1,
                      fontStyle: "italic",
                    }}
                  >
                    {t(`legalAdvice.label.requiredToBeSentTo`)}*:
                  </Typography>
                  <Stack gap={"1rem"}>
                    {getDepartmentHeadQuery?.data?.deptHead && (
                      <CheckboxInput
                        fontSize={"1rem"}
                        checked={form.watch(
                          RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG
                        )}
                        borderColor={
                          disableCheckbox
                            ? COLOR_TYPE.TOYOTA.TOYOTA5
                            : COLOR_TYPE.TOYOTA.TOYOTA1
                        }
                        checkboxBg={
                          disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"
                        }
                        onChange={(value) => {
                          form.setValue(
                            RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG,
                            value
                          );
                        }}
                        label={
                          getDepartmentHeadQuery?.data?.deptHead
                            ? `${
                                getDepartmentHeadQuery?.data?.deptHead?.name
                              } - ${
                                getDepartmentHeadQuery?.data?.deptHead
                                  ?.position?.[
                                  i18n.language == LANGUAGES.VIETNAMESE
                                    ? "name"
                                    : "nameEnglish"
                                ]
                              }.${
                                getDepartmentHeadQuery?.data?.deptHead
                                  ?.department?.name
                              }`
                            : t(
                                "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={disableCheckbox}
                      />
                    )}
                    {getDepartmentHeadQuery?.data?.division && (
                      <CheckboxInput
                        fontSize={"1rem"}
                        checked={form.watch(
                          RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG
                        )}
                        borderColor={
                          disableCheckbox
                            ? COLOR_TYPE.TOYOTA.TOYOTA5
                            : COLOR_TYPE.TOYOTA.TOYOTA1
                        }
                        checkboxBg={
                          disableCheckbox ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"
                        }
                        onChange={(value) => {
                          form.setValue(
                            RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG,
                            value
                          );
                        }}
                        label={
                          getDepartmentHeadQuery?.data?.division
                            ? `${getDepartmentHeadQuery?.data?.division?.name} - Division Head.${getDepartmentHeadQuery?.data?.division?.department?.name}`
                            : t(
                                "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={disableCheckbox}
                      />
                    )}
                  </Stack>
                  {/* <Grid container direction={"row"} rowGap={"0.5rem"}>
                    {getDepartmentHeadQuery?.data?.deptHead && <Grid item xs={6}>
                      <FormControlLabel
                        name={
                          RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG
                        }
                        control={
                          <Checkbox
                            checked={checkDeptHeadFlag}
                            onChange={(e) => {
                              form.setValue(
                                RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG,
                                e.target.checked
                              );
                            }}
                          />
                        }
                        label={
                          getDepartmentHeadQuery?.data?.deptHead
                            ? `${getDepartmentHeadQuery?.data?.deptHead?.name} - ${getDepartmentHeadQuery?.data?.deptHead?.position?.[
                              i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
                            ]}.${getDepartmentHeadQuery?.data?.deptHead?.department?.name}`
                            : t(
                                "reminder_template.title.DEPT_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>}
                    {getDepartmentHeadQuery?.data?.division && <Grid item xs={6}>
                      <FormControlLabel
                        name={
                          RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG
                        }
                        control={
                          <Checkbox
                            checked={checkDivisionFlag}
                            onChange={(e) => {
                              form.setValue(
                                RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG,
                                e.target.checked
                              );
                            }}
                          />
                        }
                        label={
                          getDepartmentHeadQuery?.data?.division
                            ? `${getDepartmentHeadQuery?.data?.division?.name} - ${getDepartmentHeadQuery?.data?.division?.position?.[
                              i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
                            ]}.${getDepartmentHeadQuery?.data?.division?.department?.name}`
                            : t(
                                "reminder_template.title.DIVISION_HEAD_OF_THE_RECIPIENT"
                              )
                        }
                        disabled={
                          !appContext.meCanWrite ||
                          (formMode === "update" && !ownRole?.includes(1))
                        }
                      />
                    </Grid>}
                  </Grid> */}

                  {sendToError ? (
                    <FormHelperText error>
                      {t("legalAdvice.messages.requiredToBeSentTo")}
                    </FormHelperText>
                  ) : null}
                </Stack>
              )}
              <Grid item width={"100%"}>
                <DateTimeInput
                  control={form.control}
                  name={
                    RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE
                  }
                  required
                  label={t(
                    `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE}`
                  )}
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormAsyncSelect<any, UserProfileDTO>
                    control={form.control}
                    name={RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS}
                    label={t(
                      `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS}`
                    )}
                    placeholder={t(
                      `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS}`
                    )}
                    getOptions={async (keyword) => {
                      if (!getLegalDepartmentQuery.data) return [];
                      const advisorIds =
                        getAssignedPersonQuery?.data?.users?.map(
                          (user) => user.id
                        ) ?? [];
                      if (typeof keyword == "string") {
                        const params: GetUsersParams = {
                          searchTerm: keyword,
                          page: 0,
                          size: 100,
                          sortBy: "name",
                          sortOrder: "ASC",
                          departmentIds: getLegalDepartmentQuery.data
                            ? [getLegalDepartmentQuery.data]
                            : [],
                        };
                        const response = await getUsers(params);

                        return (
                          response?.users
                            ?.map((user, index) => ({
                              ...user,
                              rank: advisorIds?.includes(user?.id)
                                ? index
                                : 99999,
                            }))
                            ?.sort(
                              (first, second) => first?.rank - second?.rank
                            ) ?? []
                        );
                      } else if (keyword?.length && keyword.length > 0) {
                        return getUser(keyword[0])
                          .then((response) => (response ? [response] : []))
                          .catch(() => []);
                      }
                      return [];
                    }}
                    getOptionLabel={(option) =>
                      `${option?.name ?? ""} (${option?.email ?? ""}) - ${
                        option?.department?.name ?? option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"lcOfficersRelationship/queryUser"}
                    isFocus
                    disabled={
                      !appContext.meCanWrite ||
                      (formMode === "update" && !ownRole?.includes(1))
                    }
                  />
                </Grid>
              </Grid>
              <Grid item width={"100%"}>
                <DateTimeInput
                  control={form.control}
                  name={RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE}
                  label={t(
                    `RELATION_SHIP_DISCLOSURE.label.${RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE}`
                  )}
                  required
                  disabled={
                    !appContext.meCanWrite ||
                    (formMode === "update" && !ownRole?.includes(1))
                  }
                />
              </Grid>
              {formMode === "update" && initialValue?.id && (
                <Grid width={"100%"} container gap={2}>
                  <ConfirmationInformationList
                    ownRole={ownRole}
                    relationshipId={initialValue?.id}
                    initialValue={initialValue}
                  />
                  <EvaluateCommentList
                    ownRole={ownRole}
                    relationshipId={initialValue?.id}
                    initialValue={initialValue}
                  />
                  <FollowRelationList
                    ownRole={ownRole}
                    relationshipId={initialValue?.id}
                    initialValue={initialValue}
                  />
                </Grid>
              )}
            </Grid>
            <ReminderPickerSubForm
              name={"remind"}
              module={Module.get(ModuleKeys.DECLARE_RELATIONSHIP)}
              placeholder={t("menu.reminder")}
            />
            <FormActionButtons
              formMode={formMode}
              loading={loading}
              onCancel={onCancel}
              allowDraft={formMode === "create" || defaultValues?.isDraft}
              onSaveDraft={async () => {
                try {
                  const params = await handleSaveParams();
                  params[RelationshipDisclosureDetailFields.IS_DRAFT] = true;
                  onSubmitDraft?.(params);
                } catch (error) {}
              }}
              onSave={async () => {
                try {
                  const params = await handleSaveParams();
                  params[RelationshipDisclosureDetailFields.IS_DRAFT] = false;
                  onSubmit?.(params);
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </>
  );
};

export default RelationshipDisclosureForm;
