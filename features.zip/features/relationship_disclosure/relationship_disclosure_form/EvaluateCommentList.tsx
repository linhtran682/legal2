import { GLOBAL_SPACING } from "@/constants/format";
import {  Grid, Typography } from "@mui/material";
import { FC, useContext, useEffect, useState } from "react";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import {
  GET_EVALUATE_COMMENT_LIST,
  getListRelationShipDisclosureEvaluate,
  useDeleteEvaluateMng,
} from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { useTranslation } from "react-i18next";
import {
  RelationshipDisclosureRole,
  RelationshipDisclosureRoleKey,
} from "@/constants/general";
import { AppContext } from "@/context/AppContext";
import { ConflictInformation } from "@/models/relationship-disclosure/ConfirmConflict";
import RelationshipDisclosureItem from "./RelationshipDisclosureItem";
import { EvaluateRelationshipMngForm } from "../relationship_disclosure_dialog/evaluate_form";

interface EvaluateCommentListProps {
  relationshipId: number;
  documentName?: string;
  initialValue?: any;
  ownRole?: number[];
}

const EvaluateCommentList: FC<EvaluateCommentListProps> = (props) => {
  const { t } = useTranslation();
  const appContext = useContext(AppContext);
  const { relationshipId, ownRole, initialValue } = props;
  const queryClient = useQueryClient();
  const [popupVisible, setPopupVisible] = useState(false);
  const [selectedEvaluate, setSelectedEvaluate] = useState<
    ConflictInformation | undefined
  >(undefined);
  const [evaluatePopupState, setEvaluatePopupState] =
    useState<ConfirmPopupProps>(() => DefaultConfirmPopupState);
  const getEvaluateCommentListQuery = useQuery({
    queryKey: [GET_EVALUATE_COMMENT_LIST, relationshipId],
    queryFn: () => getListRelationShipDisclosureEvaluate(relationshipId),
    enabled: !!relationshipId,
  });
  const { mutateAsync: deleteEvaluateMutationFn } = useDeleteEvaluateMng({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.create_success", {
            recordName: t("Đánh giá/Nhận xét"),
          })
        );
        setEvaluatePopupState(DefaultConfirmPopupState);
        queryClient.invalidateQueries({
          queryKey: [GET_EVALUATE_COMMENT_LIST],
        });
      },
    },
  });
  const handleEditClick = (relationshipItem: ConflictInformation) => {
    setSelectedEvaluate(relationshipItem);
    setPopupVisible(true);
  };

  const handleDeleteClick = (relationshipItem: ConflictInformation) => {
    setEvaluatePopupState({
      open: true,
      icon: <DeleteRecordDialogIcon />,
      title: "Bạn có chắc chắn muốn xóa không ?",
      handleConfirm: async () => {
        await deleteEvaluateMutationFn({
          drId: relationshipId,
          evaluateId: relationshipItem.id,
        });
      },
      handleCancel: () => setEvaluatePopupState(DefaultConfirmPopupState),
    });
  };
  const onPopupClose = async () => {
    setPopupVisible(false);
    setSelectedEvaluate(undefined);
  };
  useEffect(() => {
    relationshipId && getEvaluateCommentListQuery.refetch();
  }, [relationshipId]);

  return getEvaluateCommentListQuery?.data?.result?.responses?.length ? (
    <Grid
      container
      direction={"column"}
      className="form-sub-section-wrapper"
      rowGap={GLOBAL_SPACING}
      position={"relative"}
    >
      <Typography fontWeight="bold">
        {t("CONFLICT_MANAGEMENT.label.evaluateConflict")}
      </Typography>
      {(getEvaluateCommentListQuery?.data?.result?.responses ?? [])?.map(
        (relationshipItem: ConflictInformation, index: number) => (
          <RelationshipDisclosureItem
            key={relationshipItem?.id?.toString()}
            indexRelationshipItem={index}
            isActiveAction={ownRole?.includes(
              RelationshipDisclosureRole.get(RelationshipDisclosureRoleKey.LC)!
            )}
            label={`RELATION_SHIP_DISCLOSURE.label.reviewer`}
            onDeleteClick={() => handleDeleteClick(relationshipItem)}
            onEditClick={() => handleEditClick(relationshipItem)}
            relationshipItem={{
              ...relationshipItem,
              user: relationshipItem?.userResponse,
              attachments: relationshipItem?.attachmentResponses,
            }}
          />
        )
      )}
      <ConfirmPopup {...evaluatePopupState} />
      {popupVisible && (
        <>
          <EvaluateRelationshipMngForm
            setIsOpen={onPopupClose}
            isOpen={popupVisible}
            drId={relationshipId}
            evaluateId={selectedEvaluate?.id}
            name={initialValue?.documentName}
            senderDocumentManagement={appContext?.me}
          />
        </>
      )}
    </Grid>
  ) : null;
};

export default EvaluateCommentList;
