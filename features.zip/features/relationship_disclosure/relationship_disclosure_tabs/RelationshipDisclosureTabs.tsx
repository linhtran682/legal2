import { uploadDocumentTabAttachments } from "@/apis/service/files_upload/files";
import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { TabNav } from "@/components/commons/tab-nav/TabNav";
import { UploadPanel } from "@/components/commons/upload/upload_panel/UploadPanel";
import { COLOR_TYPE } from "@/constants/color";
import { AppContext } from "@/context/AppContext";
import { GenericContentPanel } from "@/features/metadata_tab_panel/generic_content_panel/GenericContentPanel";
import { InformationRequestPanel } from "@/features/metadata_tab_panel/information_request_panel/InformationRequestPanel";
import { LANGUAGES } from "@/locales/config-translation";
import {
  AdviceRequestFeedback,
  LegalAdviceForward,
} from "@/models/legal-advice/LegalAdviceList";
import { getUserLabel } from "@/utils";
import { FC, useContext } from "react";
import { useTranslation } from "react-i18next";
import { RelationshipDisclosureEvaluationPanel } from "../metadata_tab_panel/relationship_disclosure_evaluation_panel/RelationshipDisclosureEvaluationPanel";
import { RelationshipDisclosureConfirmPanel } from "../metadata_tab_panel/relationship_disclosure_confirm_panel/RelationshipDisclosureConfirmPanel";
import { RelationshipDisclosureExtendPanel } from "../metadata_tab_panel/relationship_disclosure_extend-panel/RelationshipDisclosureExtendPanel";
import { RelationshipDisclosureFeedbackPanel } from "../metadata_tab_panel/relationship_disclosure_feedback-panel/RelationshipDisclosureFeedbackPanel";
import { RelationshipDisclosureHistoryPanel } from "../metadata_tab_panel/relationship_disclosure_history-panel/RelationshipDisclosureHistoryPanel";
import { RelationshipDisclosureBodyReceive } from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import {
  getRelationShipDisclosureApproval,
  getRelationShipDisclosureAttachment,
  getRelationShipDisclosureEvaluateTab,
  getRelationShipDisclosureExtensions,
  getRelationShipDisclosureForwards,
  getRelationShipDisclosureHistory,
  getRelationShipDisclosureInformationRequests,
  getRelationShipDisclosureRequestFeedback,
} from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";

export interface RelationshipDisclosureTabsProps {
  relationshipDisclosureId: number;
  relationshipDisclosure?: RelationshipDisclosureBodyReceive;
  loading?: boolean;
}

const RelationshipDisclosureTabs: FC<RelationshipDisclosureTabsProps> = (
  props
) => {
  const { relationshipDisclosureId, relationshipDisclosure } = props;
  const { t, i18n } = useTranslation();
  const appContext = useContext(AppContext);
  const { loading } = props;
  const isEnglish = i18n.language === LANGUAGES.ENGLISH;

  return (
    <LoadingWrapper loading={loading || appContext.loading}>
      <div style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
        <TabNav
          tabItems={[
            // 1. Yêu cầu bổ sung thông tin
            {
              key: "information-request",
              label: t("metadata.informationRequest.title"),
              content: (
                <InformationRequestPanel
                  queryKey="relationship-disclosure-information-request"
                  getInformationRequests={async () => {
                    return (
                      (
                        await getRelationShipDisclosureInformationRequests(
                          relationshipDisclosureId
                        )
                      )?.detailInformationRequestResponses?.map(
                        (ele, index: number) => ({
                          ...ele,
                          id: index + 1,
                        })
                      ) ?? []
                    );
                  }}
                />
              ),
            },
            // 2. Đánh giá
            {
              key: "evaluation",
              label: t("metadata.evaluation.title"),
              content: (
                <RelationshipDisclosureEvaluationPanel
                  queryKey="relationship-disclosure-evaluation"
                  getEvaluations={async () =>
                    (
                      await getRelationShipDisclosureEvaluateTab(
                        relationshipDisclosureId
                      )
                    ).result?.responses ?? []
                  }
                />
              ),
            },
            // 3. Duyệt
            {
              key: "confirm",
              label: t("metadata.confirm.title"),
              content: (
                <RelationshipDisclosureConfirmPanel
                  queryKey="legal-document-confirm"
                  getConfirmRecords={async () =>
                    (
                      await getRelationShipDisclosureApproval(
                        relationshipDisclosureId
                      )
                    ).result?.requestApproveResponses ?? []
                  }
                />
              ),
            },
            // 4. Đính kèm
            {
              key: "attachment",
              label: t("metadata.attachment.title"),
              content: (
                <UploadPanel
                  queryKey="relationship-disclosure-upload"
                  onGetFiles={async () =>
                    (
                      (
                        await getRelationShipDisclosureAttachment(
                          relationshipDisclosureId,
                          24
                        )
                      )?.data || []
                    ).map((legalDocumentAttachment) => ({
                      fileId: legalDocumentAttachment.fileId,
                      fileName: legalDocumentAttachment.fileName,
                      storagePath: legalDocumentAttachment.filePath,
                      uploadDate: legalDocumentAttachment.uploadDate,
                    }))
                  }
                  onDelete={() => Promise.resolve()}
                  onUpload={async (files) => {
                    await uploadDocumentTabAttachments({
                      files: files,
                      id: relationshipDisclosureId,
                      reference_file_type: 24,
                    });
                  }}
                  disabled
                />
              ),
            },
            // 5. Chuyển tiếp
            {
              key: "forward",
              label: t("metadata.forward.title"),
              content: (
                <GenericContentPanel<LegalAdviceForward>
                  getData={async () => {
                    return (
                      (
                        await getRelationShipDisclosureForwards(
                          relationshipDisclosureId
                        )
                      )?.forwardResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) => getUserLabel(item.forwardUser, isEnglish)}
                  getDisplayDate={(item) => item.forwardDate}
                  getSubtitle={(item) =>
                    `${t("legalAdvice.tabs.forwardedTo")}:  ${item?.receiveUsers
                      ?.map((user) => getUserLabel(user, isEnglish))
                      .join(", ")}`
                  }
                  contentHeader="legalAdvice.forwardLegalAdvice.title.content"
                  getContent={(item) => item.content}
                  queryKey="relationship-disclosure-forward"
                />
              ),
            },
            // 6. Gia hạn thời gian
            {
              key: "extend",
              label: t("metadata.extend.title"),
              content: (
                <RelationshipDisclosureExtendPanel
                  relationshipDisclosureId={relationshipDisclosureId}
                  relationshipDisclosure={relationshipDisclosure}
                  getExtendRecords={async () => {
                    return (
                      (
                        await getRelationShipDisclosureExtensions(
                          relationshipDisclosureId
                        )
                      )?.timeExtensionResponseDetails ?? []
                    );
                  }}
                  queryKey="relationship-disclosure-extend-tab"
                />
              ),
            },
            // 7. Phản hồi văn bản
            {
              key: "request-feedback",
              label: t("legalAdvice.tabs.documentFeedback"),
              content: (
                <RelationshipDisclosureFeedbackPanel<AdviceRequestFeedback>
                  getData={async () => {
                    return (
                      (
                        await getRelationShipDisclosureRequestFeedback(
                          relationshipDisclosureId
                        )
                      )?.feedbackResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) =>
                    getUserLabel(item.feedbackUser, isEnglish)
                  }
                  getDisplayDate={(item) => item.date}
                  getSubtitle={(item) =>
                    `${t("legalAdvice.tabs.feedbackTo")}: ${item.receiveUsers
                      .map((user) => getUserLabel(user, isEnglish))
                      .join(", ")}`
                  }
                  contentHeader="legalAdvice.tabs.feedbackContent"
                  getContent={(item) => item.content}
                  queryKey="relationship-disclosure-request-feedback"
                />
              ),
            },
            // 9. Lịch sửa
            {
              key: "history",
              label: t("metadata.history.title"),
              content: (
                <RelationshipDisclosureHistoryPanel
                  queryKey="relationship-disclosure-history"
                  getHistoryRecords={async () => {
                    return (
                      (
                        await getRelationShipDisclosureHistory(
                          relationshipDisclosureId
                        )
                      ).result?.data ?? []
                    );
                  }}
                />
              ),
            },
          ]}
        />
      </div>
    </LoadingWrapper>
  );
};

export default RelationshipDisclosureTabs;
