import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { EXPECTED_DATE_TIME_LOCALE, GLOBAL_SPACING } from "@/constants/format";
import { LANGUAGES } from "@/locales/config-translation";
import { RelationShipEvaluateTab } from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

export interface RelationshipDisclosureEvaluationPanelProps {
  queryKey: string;
  getEvaluations: () => Promise<RelationShipEvaluateTab[]>;
}

export const RelationshipDisclosureEvaluationPanel = (
  props: RelationshipDisclosureEvaluationPanelProps
) => {
  const { t, i18n } = useTranslation();
  const getEvaluationsQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () => props.getEvaluations(),
  });
  const EvaluationTableColumns: StandardSimpleTableColumn<RelationShipEvaluateTab>[] =
    [
      {
        key: "id",
        label: "document_type.column.id",
        type: "number",
        flex: 1,
        renderCell: (params) => +(params?.id ?? 0) + 1,
      },
      {
        key: "department",
        label: "metadata.evaluation.column.department",
        type: "string",
        flex: 1,
        renderCell: (params) =>
          params.row?.user?.[
            i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
          ],
      },
      {
        key: "user",
        label: "metadata.evaluation.column.user",
        type: "string",
        flex: 1,
        renderCell: (params) => params.row?.user?.name,
      },
      {
        key: "content",
        label: "metadata.evaluation.column.content",
        type: "string",
        flex: 1,
        renderCell: (params) => params.row?.content,
      },
      {
        key: "evaluateUser",
        label: "metadata.evaluation.column.employeeEvaluate",
        type: "string",
        flex: 1,
        renderCell: (params) => params.row?.evaluateUser?.[
          i18n.language == LANGUAGES.VIETNAMESE ? "name" : "nameEnglish"
        ]
      },
      {
        key: "deadline",
        label: "metadata.evaluation.column.evaluationTime",
        type: "date",
        flex: 1,
        renderCell: (params) =>
          params.row.deadline
            ? Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                dateStyle: "short",
                timeStyle: "medium",
              }).format(new Date(params.row.deadline))
            : null,
      },
      {
        key: "type",
        label: "metadata.evaluation.column.status",
        type: "string",
        flex: 1,
        renderCell: (params) =>
          params.row.type
            ? t(`CONFLICT_MANAGEMENT.typeEvaluateTab.${params.row.type}`)
            : "",
      },
    ];

  return (
    <div style={{ paddingTop: GLOBAL_SPACING }}>
      <StandardSimpleTable
        loading={getEvaluationsQuery.isFetching}
        columns={EvaluationTableColumns}
        data={getEvaluationsQuery.data ?? []}
        getRowId={(_, index) => index.toString()}
      />
    </div>
  );
};
