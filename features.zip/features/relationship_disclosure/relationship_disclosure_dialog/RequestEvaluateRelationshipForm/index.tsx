import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import {
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  Module,
  ModuleFields,
  ModuleKeys,
} from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";

import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormControl, Grid, Typography } from "@mui/material";
import { useContext, useEffect } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

import { BasedLegalDocument } from "@/models/law_document/BasedLegalDocument";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { castRequestEvaluateConflictSchemaToDTO, RequestEvaluateConflictFieldNames, RequestEvaluateConflictSchema, RequestEvalueConflictSchemaI } from "@/models/relationship-disclosure/RequestEvaluate";
import { useCreateRequestEvaluateConflict } from "@/apis/service/relationship_disclosure/relationMngFormPopup";

const initialEmptyValue: RequestEvalueConflictSchemaI = {
  [RequestEvaluateConflictFieldNames.USERS_IDS]: [],
  [RequestEvaluateConflictFieldNames.DEADLINE]: "",
  [RequestEvaluateConflictFieldNames.CONTENT]: "",
  [RequestEvaluateConflictFieldNames.REMIND]: undefined,
  [RequestEvaluateConflictFieldNames.STATUS]: 0,
};
export interface RequestReviewLegalDocumentFormProps {
  name?: string;
  titlePopup?: string;
  extendDeadlineId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload: boolean) => void;
  initialValues?: RequestEvalueConflictSchemaI;
  selectedDocuments?: BasedLegalDocument[];
  module?: number;
  defaultStatus?: string;
  senderDocumentManagement?: any;
  ciId?: number;
}
export const RequestEvaluateRelationshipForm = (
  props: RequestReviewLegalDocumentFormProps
) => {
  const {
    titlePopup = "RELATION_SHIP_DISCLOSURE.requestEvaluate.title",
    isOpen = false,
    setIsOpen,
    selectedDocuments,
    module = Module.get(ModuleKeys.DECLARE_RELATIONSHIP),
   defaultStatus = ConflictManagementStatusContent.get(
      ConflictManagementStatusKey.REQUEST_REVIEW
    )!,
    senderDocumentManagement,
    ciId,
  } = props;
  const [t] = useTranslation();
  const appContext = useContext(AppContext);

  const form = useForm<any>({
    resolver: yupResolver(RequestEvaluateConflictSchema),
    defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    // mode: "onBlur",
    disabled: !appContext.meCanWrite,
  });

  const querySearchStatus = useSearchStatus({
    keyword: defaultStatus,
    form,
    queryKey: "DECLARE_RELATIONSHIP_REQUEST_EVALUATE",
  });

  useEffect(() => {
    querySearchStatus?.data?.[0]?.id &&
      form.reset({
        status: querySearchStatus?.data?.[0]?.id,
      });
  }, [querySearchStatus?.data?.[0]?.id]);

  const { mutateAsync: createRequestEvaluateConflictMutationFn, isPending } =
    useCreateRequestEvaluateConflict({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });
  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset(initialEmptyValue);
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { ...restData } = data;
    await createRequestEvaluateConflictMutationFn({
      drId: ciId,
      data: restData,
    });
  };
  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm(false)}
    >
      <FormProvider {...form}>
        <Grid container className="form-wrapper">
          <Grid item>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={formInputSxProps}
            >
              <Grid item width={"100%"}>
                <FormControl size="small" fullWidth>
                  <Typography fontWeight="bold">
                    {t("RELATION_SHIP_DISCLOSURE.requestAdditional.title.textName")}
                  </Typography>
                  {selectedDocuments?.length ? (
                    selectedDocuments?.map((ele, index) => (
                      <Typography key={ele.id.toString()}>
                        {index + 1}. {ele.documentName}
                      </Typography>
                    ))
                  ) : (
                    <Typography>{props.name}</Typography>
                  )}
                </FormControl>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {/* {t(`legalAdvice.forwardLegalAdvice.title.sender`)} */}
                  {t("CONFLICT_MANAGEMENT.forwardConflict.transitioner")}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={RequestEvaluateConflictFieldNames.STATUS}
                  label={t(
                    `LEGISLATION.field_name.${RequestEvaluateConflictFieldNames.STATUS}`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query-request-review"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.LEGISLATION_NAME.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }
                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestEvaluateConflictFieldNames.DEADLINE}
                  control={form.control}
                  label={t(
                    `CONFLICT_MANAGEMENT.requestEvaluate.lcReviewDeadline`
                  )}
                  placeholder="dd/mm/yyyy"
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestEvaluateConflictFieldNames.CONTENT}
                  label={t(
                    `LEGISLATION.field_name.${RequestEvaluateConflictFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `LEGISLATION.field_name.${RequestEvaluateConflictFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={RequestEvaluateConflictFieldNames.USERS_IDS}
                  label={t(`CONFLICT_MANAGEMENT.requestEvaluate.receiver`)}
                  placeholder={t(
                    `CONFLICT_MANAGEMENT.requestEvaluate.receiver`
                  )}
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery="request-review/queryUser"
                  isFocus
                  minCharLength={1}
                  required
                />
              </Grid>
            </Grid>
          </Grid>

          <Grid item>
            <ReminderPickerSubForm
              name={RequestEvaluateConflictFieldNames.REMIND}
              module={module}
            />
          </Grid>

          <FormActionButtons
            formMode="create"
            loading={isPending}
            onCancel={onCloseForm}
            cancelConfirm={form.formState.isDirty}
            onSave={() => {
              try {
                onSubmit(
                  castRequestEvaluateConflictSchemaToDTO({
                    ...form.getValues(),
                  })
                );
              } catch (error) {}
            }}
            textSave="common.button.send"
          />
        </Grid>
      </FormProvider>
    </ModalCommon>
  );
};
