import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import {
  Module,
  ModuleFields,
  ModuleKeys,
  RelationshipDisclosureStatusContent,
  RelationshipDisclosureStatusKey,
} from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import {
  FinishLegalAdviceFieldNames,
  FinishLegalAdviceSchemaI,
} from "@/models/legal-advice/FinishLegalAdvice";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import {
  useCreateFollow,
  useGetFollowConflict,
  useGetUserDefaultFollow,
} from "@/apis/service/relationship_disclosure/relationMngFormPopup";
import {
  FollowConflictMngFieldNames,
  FollowConflictMngSchema,
  FollowConflictMngSchemaI,
} from "@/models/relationship-disclosure/FollowConflict";

const initialEmptyValue: FollowConflictMngSchemaI = {
  [FollowConflictMngFieldNames.USER_IDS]: [],
  [FollowConflictMngFieldNames.DEADLINE]: "",
  [FollowConflictMngFieldNames.CONTENT]: "",
  [FollowConflictMngFieldNames.REMIND]: undefined,
};

export interface FinishLegalAdviceTypeFormProps {
  titlePopup?: string;
  initialValue?: FinishLegalAdviceSchemaI;
  drId?: number;
  followId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderConflict?: any;
  defaultStatus?: string;
}

export const FollowRelationshipForm = (
  props: FinishLegalAdviceTypeFormProps
) => {
  const {
    titlePopup = "RELATION_SHIP_DISCLOSURE.follow.title",
    initialValue = initialEmptyValue,
    drId,
    followId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DECLARE_RELATIONSHIP),
    senderConflict,
    defaultStatus = RelationshipDisclosureStatusContent.get(
      RelationshipDisclosureStatusKey.DECLARATION_MONITORING
    )!,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(FollowConflictMngSchema),
    defaultValues: initialValue,
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: !followId ? defaultStatus : undefined,
    modules: Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!,
    queryKey: "FOLLOW_DECLARE_RELATIONSHIP",
  });

  const { data: getFollowConflict } = useGetFollowConflict({
    request: {
      drId,
      followId,
    },
    config: {
      enabled: !!followId && !!drId,
    },
  });

  const {
    data: getUserDefaultFollowQueryFn,
    isLoading: isLoadingUserDefaultFollow,
  } = useGetUserDefaultFollow({
    request: { conflictId: drId },
    config: {
      enabled: !!drId,
    },
  });
  const { mutateAsync: createFollowConflictMutationFn, isPending } =
    useCreateFollow({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createFollowConflictMutationFn({
      drId,
      data: { ...data, status: +data?.status },
    });
  };

  useEffect(() => {
    if (getFollowConflict) {
      const { userResponse, ...restGetDataFollowConflict } = getFollowConflict;
      form.reset({
        ...restGetDataFollowConflict,
        [FinishLegalAdviceFieldNames.USER_IDS]: [userResponse],
      });
    } else {
      form.reset({
        ...initialValue,
        ...(getSearchStatusQuery?.data && {
          [FinishLegalAdviceFieldNames.STATUS]:
            getSearchStatusQuery?.data?.find(
              (status) => status?.name === defaultStatus
            )?.id,
          userIds: getUserDefaultFollowQueryFn && getUserDefaultFollowQueryFn,
        }),
      });
    }
  }, [
    getFollowConflict,
    getSearchStatusQuery?.data,
    getUserDefaultFollowQueryFn,
  ]);

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t(
                    "RELATION_SHIP_DISCLOSURE.requestAdditional.title.textName"
                  )}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {t(`legalAdvice.finishLegalAdvice.title.requester`)}
                </label>
                {senderConflict && (
                  <Typography>
                    {`${senderConflict?.name} (${senderConflict?.email}) - ${
                      senderConflict?.departmentName ??
                      senderConflict?.department?.name
                    }`}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={FinishLegalAdviceFieldNames.STATUS}
                  label={t(`legalAdvice.finishLegalAdvice.title.status`)}
                  keyQuery={"status-query-finish"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [ModuleFields.CONFLICT_MANAGEMENT.module],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1,
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={FollowConflictMngFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.forwardLegalAdvice.title.deadline`)}
                  minDate={new Date()}
                  required
                  placeholder="dd/mm/yyyy"
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={FollowConflictMngFieldNames.CONTENT}
                  label={t(
                    `legalAdvice.finishLegalAdvice.title.${FinishLegalAdviceFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `legalAdvice.finishLegalAdvice.placeHolder.${FinishLegalAdviceFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={FinishLegalAdviceFieldNames.USER_IDS}
                    label={t(
                      "legalAdvice.finishLegalAdvice.title.responsiblePerson"
                    )}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"finishLegalAdvice/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={FinishLegalAdviceFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending || isLoadingUserDefaultFollow}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...form.getValues(),
                    userIds: form
                      .getValues()
                      ?.userIds?.map((user: any) => user?.id),
                    remind: form.getValues()?.remind
                      ? castReminderSchemaToSaveReminderDTO(
                          form.getValues().remind
                        )
                      : undefined,
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
