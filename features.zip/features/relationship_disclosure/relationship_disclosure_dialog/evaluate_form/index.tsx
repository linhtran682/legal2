import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Checkbox, FormControlLabel, Grid, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import {
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  Module,
  ModuleKeys,
  RelationshipDisclosureStatusContent,
  RelationshipDisclosureStatusKey,
} from "@/constants/general";

import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { FileInfo } from "@/models/conflict_management/ConflictManagementDetail";
import { castEvaluateSchemaToDTO } from "@/models/conflict_management/EvaluateConflictManagement ";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { getStatus, getStatusListNames } from "@/apis/service/status/Status";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { StatusDTO } from "@/models/status/Status";
import {
  useCreateEvaluateRelationship,
  useGetEvaluateConflict,
} from "@/apis/service/relationship_disclosure/relationMngFormPopup";
import {
  ConfirmConflictSchema,
  EvaluateConflictFieldNames,
} from "@/models/relationship-disclosure/EvaluateConflictManagement ";
import { ConfirmConflictSchemaII } from "@/models/relationship-disclosure/ConfirmConflict";

const initialEmptyValue: ConfirmConflictSchemaII = {
  [EvaluateConflictFieldNames.USERS_IDS]: [],
  [EvaluateConflictFieldNames.DEADLINE]: "",
  [EvaluateConflictFieldNames.CONTENT]: "",
  [EvaluateConflictFieldNames.REMIND]: undefined,
  [EvaluateConflictFieldNames.STATUS]: 0,
  [EvaluateConflictFieldNames.ACCEPT]: true,
};

export interface ForwardRelationshipTypeFormProps {
  titlePopup?: string;
  initialValue?: ConfirmConflictSchemaII;
  drId: number;
  evaluateId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  defaultStatus?: string;
}

export const EvaluateRelationshipMngForm = (
  props: ForwardRelationshipTypeFormProps
) => {
  const {
    titlePopup = "CONFLICT_MANAGEMENT.evaluate.title",
    initialValue = initialEmptyValue,
    drId,
    evaluateId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DECLARE_RELATIONSHIP),
    senderDocumentManagement,
    defaultStatus = RelationshipDisclosureStatusContent.get(
      RelationshipDisclosureStatusKey.REVIEW_COMMENTED
    )!,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);

  const form = useForm<any>({
    resolver: yupResolver(ConfirmConflictSchema),
    defaultValues: initialValue,
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: !evaluateId ? defaultStatus : undefined,
    modules: Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!,
    queryKey: "EVALUATE_ELATIONSHIP_MNG",
  });

  const { data: getEvaluateConflict } = useGetEvaluateConflict({
    request: {
      drId,
      evaluateId,
    },
    config: {
      enabled: !!evaluateId && !!drId,
    },
  });

  const { mutateAsync: createEvaluateConflictMutationFn, isPending } =
    useCreateEvaluateRelationship({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { ...restData } = data;
    await createEvaluateConflictMutationFn({
      drId,
      data: {
        ...restData,
        accept: form.getValues('accept') ? 0 : 1,
        evaluateUserIds: form.getValues('evaluateUserIds') ? form.getValues('evaluateUserIds')?.map((ele: BasedUser) => ele.id) : []
      },
    });
  };

  useEffect(() => {
    if (getEvaluateConflict) {
      const { userResponse, ...restGetDataEvaluateConflict } =
        getEvaluateConflict;
      restGetDataEvaluateConflict?.attachments &&
        setFiles(
          restGetDataEvaluateConflict.attachments?.map((item: any) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          })
        );
      form.reset({
        ...restGetDataEvaluateConflict,
        [EvaluateConflictFieldNames.USERS_IDS]: [userResponse],
      });
    } else {
      form.reset({
        ...initialValue,
        ...(getSearchStatusQuery?.data && {
          [EvaluateConflictFieldNames.STATUS]: getSearchStatusQuery?.data?.find(
            (status) => status?.name === defaultStatus
          )?.id,
        }),
      });
    }
  }, [getEvaluateConflict, getSearchStatusQuery?.data]);
  const checkAgree = form.watch('accept')
  const checkdisagree = !form.watch('accept')

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t(
                    "RELATION_SHIP_DISCLOSURE.requestAdditional.title.textName"
                  )}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {/* {t(`legalAdvice.forwardLegalAdvice.title.sender`)} */}
                  {t("RELATION_SHIP_DISCLOSURE.confirm_conflict.confirmer")}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={EvaluateConflictFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.forwardLegalAdvice.title.deadline`)}
                  placeholder="dd/mm/yyyy"
                  minDate={new Date()}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={EvaluateConflictFieldNames.STATUS}
                  label={t(`approvalNextActionForm.title.status`)}
                  keyQuery={"status-query-confirm-conflict"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusListNames({
                        names: [
                          ConflictManagementStatusContent.get(
                            ConflictManagementStatusKey.REVIEW_COMMENTED
                          )!,
                          ConflictManagementStatusContent.get(
                            ConflictManagementStatusKey.REVIEW_REJECTED
                          )!,
                          keyword,
                        ],
                        modules: [Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!],
                      });
                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option?.name}
                  required
                />
              </Grid>

              <Grid item width={"100%"} mt={0.5}>
                {/* <InputLabel shrink required sx={{ ml: 1.5 }}>
                  {t("legalAdvice.label.requiredToBeSentTo")}
                </InputLabel> */}
                <label>
                  {t("RELATION_SHIP_DISCLOSURE.evaluate.approvalInCurrentRole")}
                  <span style={{ color: "red" }}>*</span>
                </label>

                <Grid container direction={"row"}>
                  <Grid item xs={2}>
                    <FormControlLabel
                      name="accept"
                      label="Có"
                      control={
                        <Checkbox
                          checked={checkAgree}
                          onChange={(e) => {
                            form.setValue(
                              "accept",
                              e.target.checked
                            );
                          }}
                        />
                      }
                    />
                  </Grid>
                  <Grid
                    item
                    xs={2}
                    sx={{
                      display: "flex",
                      flexDirection: "row",
                      alignContent: "flex-end",
                    }}
                  >
                    <FormControlLabel
                      name="accept"
                      control={
                        <Checkbox
                          checked={checkdisagree}
                          onChange={(e) => {
                            form.setValue(
                              "accept",
                              !e.target.checked
                            );
                          }}
                        />
                      }
                      label="Không"
                    />
                  </Grid>
                  <Grid item xs={8}>
                    <p style={{ marginTop: "10px", marginLeft: "-10px" }}>
                      (Nếu chọn không, hãy hoàn thành các biện pháp khắc phục
                      bên dưới )
                    </p>
                  </Grid>
                </Grid>

                {/* {sendToError ? (
                    <FormHelperText error>
                      {t("legalAdvice.messages.requiredToBeSentTo")}
                    </FormHelperText>
                  ) : null} */}
                {/* </Grid> */}
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={EvaluateConflictFieldNames.CONTENT}
                  label={t(
                    `RELATION_SHIP_DISCLOSURE.evaluate.necessaryCorrectiveActions`
                  )}
                  placeHolder={t(
                    `RELATION_SHIP_DISCLOSURE.evaluate.necessaryCorrectiveActions`
                  )}
                  minRows={5}
                  required
                />
              </Grid>

              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={EvaluateConflictFieldNames.EVALUATE_USER_IDS}
                  label={t(
                    "RELATION_SHIP_DISCLOSURE.evaluate.recipientOrApprovedBy"
                  )}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"forwardLegalAdvice/queryUser"}
                  isFocus
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={EvaluateConflictFieldNames.DATEOFACTION}
                  control={form.control}
                  label={t(
                    `RELATION_SHIP_DISCLOSURE.evaluate.correctiveActionDate`
                  )}
                  minDate={new Date()}
                  required
                  placeholder="dd/mm/yyyy"
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={!drId}
                  preview={!!drId}
                  files={files}
                  setFiles={setFiles}
                  title={t(`legalAdvice.advisorLegalAdvice.title.file`)}
                  inputId="advisorLegalAdvice"
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={EvaluateConflictFieldNames.USERS_IDS}
                  label={t("legalAdvice.forwardLegalAdvice.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"forwardLegalAdvice/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={EvaluateConflictFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit(
                    castEvaluateSchemaToDTO({
                      ...form.getValues(),
                      attachmentIds: attachments,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
