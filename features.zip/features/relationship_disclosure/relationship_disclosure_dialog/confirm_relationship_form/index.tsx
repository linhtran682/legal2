import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import {  FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ConflictManagementStatusContent, ConflictManagementStatusKey, Module, ModuleKeys, RelationshipDisclosureStatusContent, RelationshipDisclosureStatusKey } from "@/constants/general";
import {
  castConfirmRequestSchemaToDTO,
  ConfirmConflictFieldNames,
  ConfirmConflictSchema,
  ConfirmConflictSchemaI,
} from "@/models/conflict_management/ConfirmConflict";
// import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { FileInfo } from "@/models/conflict_management/ConflictManagementDetail";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusListNames } from "@/apis/service/status/Status";
import { StatusDTO } from "@/models/status/Status";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { useCreateConfirmRelationship, useGetConfirmRelationship } from "@/apis/service/relationship_disclosure/relationMngFormPopup";

const initialEmptyValue: ConfirmConflictSchemaI = {
  [ConfirmConflictFieldNames.USERS_IDS]: [],
  [ConfirmConflictFieldNames.DEADLINE]: "",
  [ConfirmConflictFieldNames.CONTENT]: "",
  [ConfirmConflictFieldNames.REMIND]: undefined,
  [ConfirmConflictFieldNames.ACCEPT]: 0,
};

export interface ForwardLegalAdviceTypeFormProps {
  titlePopup?: string;
  initialValue?: ConfirmConflictSchemaI;
  drId?: number;
  confirmId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  defaultStatus?: string;
}

export const ConfirmRelationshipMngForm = (
  props: ForwardLegalAdviceTypeFormProps
) => {
  const {
    titlePopup = "RELATION_SHIP_DISCLOSURE.confirm_conflict.title",
    initialValue = initialEmptyValue,
    drId ,
    confirmId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DECLARE_RELATIONSHIP),
    senderDocumentManagement,
    defaultStatus= RelationshipDisclosureStatusContent.get(
      RelationshipDisclosureStatusKey.CONFIRM
    )!,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const [files, setFiles] = useState<any>([]);

  const form = useForm<any>({
    resolver: yupResolver(ConfirmConflictSchema),
    defaultValues: initialValue,
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: !confirmId ? defaultStatus : undefined,
    modules: Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!,
    queryKey: "CONFIRM_RELATIONSHIP_MNG",
  });

  const { data: getConfirmConflict } = useGetConfirmRelationship({
    request: {
      drId,
      confirmId,
    },
    config: {
      enabled: !!confirmId && !!drId,
    },
  });

  const { mutateAsync: createConfirmConflictMutationFn, isPending } =
  useCreateConfirmRelationship({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;
    await createConfirmConflictMutationFn({
      drId,
      data: restData,
    });
  };

  useEffect(() => {
    if (getConfirmConflict) {
      const { userResponse, ...restGetDataConfirmConflict } =
        getConfirmConflict;
      restGetDataConfirmConflict?.attachmentResponses &&
        setFiles(
          restGetDataConfirmConflict.attachmentResponses?.map((item: any) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          })
        );
      form.reset({
        ...restGetDataConfirmConflict,
        [ConfirmConflictFieldNames.USERS_IDS]: [userResponse],
      });
    } else {
      form.reset({
        ...initialValue,
        ...(getSearchStatusQuery?.data && {
          [ConfirmConflictFieldNames.STATUS]: getSearchStatusQuery?.data?.find(
            (status) => status?.name === defaultStatus
          )?.id,
        }),
      });
    }
  }, [getConfirmConflict, getSearchStatusQuery?.data]);

  return (
    <ModalCommon
      title={t(titlePopup)}
      open={isOpen}
      onClose={() => onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              {/* <Grid item width={"100%"}>
                <RadioGroupField
                  isNumber
                  onChangeRadioGroup={(e) => {
                    form.setValue("status", e.target.value);
                  }}
                  items={[
                    {
                      label: t(`CONFLICT_MANAGEMENT.confirm_conflict.approve`),
                      value: 0,
                    },
                    {
                      label: t(`CONFLICT_MANAGEMENT.confirm_conflict.reject`),
                      value: 1,
                    },
                  ]}
                  name={ConfirmConflictFieldNames.ACCEPT}
                  error={
                    form.formState.errors[
                      ConfirmConflictFieldNames.ACCEPT
                    ] as FieldError
                  }
                />
              </Grid> */}
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("RELATION_SHIP_DISCLOSURE.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{ padding: 0 }}>
                  {/* {t(`legalAdvice.forwardLegalAdvice.title.sender`)} */}
                  {t("RELATION_SHIP_DISCLOSURE.confirm_conflict.confirmer")}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={ConfirmConflictFieldNames.DEADLINE}
                  control={form.control}
                  label={t(`legalAdvice.forwardLegalAdvice.title.deadline`)}
                  minDate={new Date()}
                  required
                  placeholder="dd/mm/yyyy"
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormAsyncSelect
                  control={form.control}
                  name={ConfirmConflictFieldNames.STATUS}
                  label={t(`approvalNextActionForm.title.status`)}
                  keyQuery={"status-query-confirm-conflict"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusListNames({
                        names: [
                          ConflictManagementStatusContent.get(
                            ConflictManagementStatusKey.CONFIRM
                          )!,
                          ConflictManagementStatusContent.get(
                            ConflictManagementStatusKey.CONFIRM_REJECTED
                          )!,
                          keyword,
                        ],
                        modules: [Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!],
                      });
                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option?.name}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ConfirmConflictFieldNames.CONTENT}
                  label={t(`RELATION_SHIP_DISCLOSURE.confirm_conflict.content`)}
                  placeHolder={t(
                    `RELATION_SHIP_DISCLOSURE.confirm_conflict.content`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <DropPreviewFileUploadComponent
                  dropView={!drId}
                  preview={!!drId}
                  files={files}
                  setFiles={setFiles}
                  title={t(`legalAdvice.advisorLegalAdvice.title.file`)}
                  inputId="advisorLegalAdvice"
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormMultipleSelect<any, BasedUser>
                  control={form.control}
                  name={ConfirmConflictFieldNames.USERS_IDS}
                  label={t("legalAdvice.forwardLegalAdvice.title.receiver")}
                  placeholder="Nhập tên nhân viên"
                  getOptions={async (keyword) => {
                    const params: GetUsersParams = {
                      searchTerm: keyword,
                      page: 0,
                      size: 100,
                      sortBy: "name",
                      sortOrder: "ASC",
                    };
                    const response = await getUsers(params);

                    return (response?.users ?? []).map((user) => ({
                      id: user.id,
                      name: user.name ?? "",
                      departmentName: user.department?.name,
                      email: user.email,
                    }));
                  }}
                  getOptionLabel={(option) =>
                    `${option.name ?? ""} (${option.email ?? ""}) - ${
                      option?.departmentName ?? ""
                    }`
                  }
                  getOptionKey={(option) => option.id}
                  keyQuery={"forwardLegalAdvice/queryUser"}
                  isFocus
                  required
                />
              </Grid>
            </Grid>

            <ReminderPickerSubForm
              name={ConfirmConflictFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  let attachments: number[] = [];
                  if (files.length > 0) {
                    const filterFile: any = [];
                    const filterFileId: number[] = [];

                    files.filter((item: any) => {
                      if (item?.id === undefined) {
                        filterFile.push(item);
                      } else {
                        filterFileId.push(item?.id);
                      }
                    });
                    if (filterFile.length > 0) {
                      const response = await GetListIdFile(filterFile);
                      const formatResponse: number[] =
                        response.fileUploadResponses.map(
                          (item: FileInfo) => item.fileId
                        );
                      attachments = [...formatResponse, ...filterFileId];
                    } else {
                      attachments = [...filterFileId];
                    }
                  }
                  onSubmit(
                    castConfirmRequestSchemaToDTO({
                      ...form.getValues(),
                      attachments: attachments,
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
