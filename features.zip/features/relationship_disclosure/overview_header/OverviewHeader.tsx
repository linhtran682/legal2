import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";
import { COLOR_TYPE } from "@/constants/color";
import { AppContext } from "@/context/AppContext";
import useObserveElementSize from "@/hooks/useObserveElementSize";
import { StatusConfirmValue } from "@/models/conflict_management/ConflictManagementDetail";
import { RelationshipDisclosureBodyReceive } from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import { Box } from "@mui/material";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

interface OverviewHeaderProps {
  initialValueReceive?: RelationshipDisclosureBodyReceive;
  isMeeting?: boolean;
  disabled?: boolean;
  handleUpdateBookMeeting?: (params: any) => void;
  isLoading?: boolean;
}
const OverviewHeader = (props: OverviewHeaderProps) => {
  const { t } = useTranslation();
  const [isBooked, setIsBooked] = useState(false);
  const [ownRole, setOwnRole] = useState<number[]>([1]);
  const appContext = useContext(AppContext);

  const canBookMeeting =
    ownRole.includes(1) ||
    ownRole.includes(2) ||
    ownRole.includes(3) ||
    ownRole.includes(4) ||
    ownRole.includes(5);

  const disableBookMeeting =
    !appContext.meCanWrite || !canBookMeeting || props.isLoading;

  const { elementRef, size } = useObserveElementSize();

  const responsiveSx = {
    minWidth: 170,
    flex: 1,
  };
  
useEffect(() => {
    if (props.initialValueReceive) {
      setIsBooked(!!props?.initialValueReceive?.bookingFlag);
      setOwnRole(ownRole);
    }
  }, [props.initialValueReceive]);

  return (
    <Box
      ref={elementRef}
      sx={{
        display: size.width <= 880 ? "grid" : "flex",
        p: 2,
        backgroundColor: "white",
        mb: 2,
        gridTemplateColumns: `repeat(auto-fill, minmax(170px, 1fr))`,
      }}
    >
      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={
            !canBookMeeting
              ? COLOR_TYPE.TOYOTA.TOYOTA5
              : COLOR_TYPE.TOYOTA.TOYOTA1
          }
          checkboxBg={!canBookMeeting ? COLOR_TYPE.TOYOTA.TOYOTA6 : "white"}
          labelVariant={canBookMeeting ? "subtitle1" : undefined}
          checked={isBooked}
          disabled={disableBookMeeting}
          onChange={async (value) => {
            if (disableBookMeeting) return;
            await props?.handleUpdateBookMeeting?.({
              relationshipId: props?.initialValueReceive?.id,
              request: {
                isBookMeeting: value,
              },
            });
            setIsBooked(value);
          }}
          label={t("LEGISLATION.evaluateField.meeting")}
        />
      </Box>
      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={
            !props.initialValueReceive?.confirmValue
              ? COLOR_TYPE.TOYOTA.TOYOTA5
              : props.initialValueReceive?.confirmValue ===
                StatusConfirmValue.ALL_CONFIRM
              ? COLOR_TYPE.SUCCESS.GREEN8
              : COLOR_TYPE.TOYOTA.TOYOTA1
          }
          checkboxBg={
            !props.initialValueReceive?.confirmValue
              ? COLOR_TYPE.TOYOTA.TOYOTA6
              : props.initialValueReceive?.confirmValue ===
                StatusConfirmValue.ALL_CONFIRM
              ? COLOR_TYPE.SUCCESS.GREEN8
              : COLOR_TYPE.TOYOTA.TOYOTA1
          }
          disabled
          checked={[
            StatusConfirmValue.REJECTED,
            StatusConfirmValue.ALL_CONFIRM,
          ].includes(props.initialValueReceive?.confirmValue as number)}
          label={t("CONFLICT_MANAGEMENT.label.deptHeadConfirm")}
          isSuccess={
            props.initialValueReceive?.confirmValue ===
            StatusConfirmValue.ALL_CONFIRM
          }
        />
      </Box>
      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.lcEvaluateFlag}
          disabled
          label={t("CONFLICT_MANAGEMENT.label.lcEvaluate")}
        />
      </Box>
      <Box sx={{ padding: "4px 0px", width: "fit-content", ...responsiveSx }}>
        <CheckboxInput
          borderColor={COLOR_TYPE.TOYOTA.TOYOTA5}
          checkboxBg={COLOR_TYPE.TOYOTA.TOYOTA6}
          checked={!!props.initialValueReceive?.approvedFlag}
          disabled
          label={t("CONFLICT_MANAGEMENT.label.lcDeptHeadApproval")}
        />
      </Box>
    </Box>
  );
};

export default OverviewHeader;
