// import { getStatisticChartFn } from '@/apis/service/legal-advice/legalAdvice'
import { getStatisticChartFn } from '@/apis/service/document-review/documentReview'
import { PieChartCommon } from '@/components/commons/chart/PieChartCommon'
// import { COLOR_TYPE } from '@/constants/color'
import { Button, Stack } from '@mui/material'
import { useQuery } from '@tanstack/react-query'
import { useRouter } from 'next/router'
import { useMemo } from 'react'
import { useTranslation } from 'react-i18next'

const DocumentReviewOverview = () => {
  const router = useRouter();
  const { t } = useTranslation();
  const getStatisticChartQuery = useQuery({
    queryKey: ['document-review/statistic/chart'],
    queryFn: getStatisticChartFn
  });

  const pieChartData = useMemo(() => {
    const data = getStatisticChartQuery?.data?.pieChart?.data ?? [];
    const total = data?.reduce((sum, item) => sum + item.value, 0);
    // Convert values to percentages
    const dataWithPercentages = data.map(item => ({
      ...item,
      fill: item.name === 'Hoàn thành'
        ? '#3B00ED'
        : (item.name === 'Chưa hoàn thành'
          ? '#D81B60'
          : '#FF9800'),
      value: total > 0 ? Number(((item.value / total) * 100).toFixed(2)) : 0 // Rounded to 2 decimal places
    }));
    return dataWithPercentages
  }, [getStatisticChartQuery?.data?.pieChart])

  // const barChartData = useMemo(() => {
  //   return getStatisticChartQuery?.data?.barChart?.data ?? []
  // }, [getStatisticChartQuery?.data?.barChart]);

  return (
    <Stack height={"100%"} >
      <Stack bgcolor={"white"} flexShrink={1} overflow={'auto'} p={3} direction={'column'} alignItems={"center"}>
        <PieChartCommon
          width={450}
          height={180}
          data={pieChartData}
        />
        {/* <BarChartCommon
          data={barChartData}
        /> */}
      </Stack>
      <Stack direction={'row'} gap={2} mt={2} flexWrap={'wrap'}>
        <Button
          onClick={() => router.push('/statistics-document-rev/report')}
          variant='contained' className='confirm' >{t('menu.statisticDocumentReviewReport')}</Button>
        <Button
          onClick={() => router.push('/statistics-document-rev/report-done')}
          variant='contained' className='confirm' >{t('menu.statisticDocumentReviewReportDone')}</Button>
        <Button
          onClick={() => router.push('/statistics-document-rev/report-backdate-request')}
          variant='contained' className='confirm' >{t('menu.statisticDocumentReviewBackdateRequest')}</Button>
        <Button
          onClick={() => router.push('/statistics-document-rev/report-backdate')}
          variant='contained' className='confirm' >{t('menu.statisticDocumentReviewBackdate')}</Button>
      </Stack>

    </Stack >
  )
}

export default DocumentReviewOverview