
import { getStatisticTableBackdateFn } from '@/apis/service/document-review/documentReview';
import HierarchyToolTip from '@/components/commons/hierarchy-tooltip/HierarchyTooltip';
import { StatusBadge } from '@/components/commons/status_badge/StatusBadge';
import { MultipleFilterTableColumn } from '@/components/commons/tables/multiple_filter_table/MultipleFilterTable';
import StandardTable, { DEFAULT_PAGE_MODAL, StandardTableState } from '@/components/commons/tables/standard_table/StandardTable';
import { LEGAL_ADVICE_ROOT_PATH, UI_PATH } from '@/constants/paths';
import { THOUSAND_SEPARATOR } from '@/constants/regex';
import ReportFilterPanel from '@/features/document-review/report_filter_panel/ReportFilterPanel';
import { documentReviewSearchPanelConfig, LcsStatusLabels } from '@/models/document-review/DocumentReviewDetail';
import { ATTACHMENT_TYPES, DocumentReviewTableFields, GetDocumentReviewListParams, SAMPLE_CONTRACT_TYPES } from '@/models/document-review/DocumentReviewList';
import { formatDate } from '@/utils';
import { Button, Stack, Tooltip } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface IReportFilters {
  startDate?: string;
  endDate?: string;
  departments?: string[];
  status?: number[];
}

const DocumentReviewReportBackdate = () => {
  const { t } = useTranslation();
  const router = useRouter();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [reportFilters, setReportFilters] = useState<IReportFilters>({});

  const [DocumentReviewTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: DocumentReviewTableFields.ID,
      label: DocumentReviewTableFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: 'center'
    },
    {
      key: DocumentReviewTableFields.DOCUMENT_NAME,
      label: DocumentReviewTableFields.DOCUMENT_NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      flex: 1,
      renderCell: (params) => (
        <HierarchyToolTip
          {...documentReviewSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.documentName}
          openNewTab
        >
          <span>{params.value}</span>
        </HierarchyToolTip>
      ),
    },
    {
      key: DocumentReviewTableFields.STATUS,
      label: DocumentReviewTableFields.STATUS,
      type: "string",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => {
        return (
          <StatusBadge label={params?.row?.isDraft
            ? t('common.label.draft')
            : (params?.row?.lcsStatus
              ? (LcsStatusLabels as any)?.[params?.row?.lcsStatus?.toString?.()]
              : params?.row?.status?.name as string)} />
        )
      },
    },
    {
      key: DocumentReviewTableFields.ATTACHMENT_TYPE,
      label: DocumentReviewTableFields.ATTACHMENT_TYPE,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => t(ATTACHMENT_TYPES
        ?.find((ele) => ele?.value === params?.value)?.label ?? '')
    },
    {
      key: DocumentReviewTableFields.SIGNERS,
      label: DocumentReviewTableFields.SIGNERS,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 280,
      renderCell: (params) =>
        <Tooltip
          placement="bottom-start"
          title={
            <>
              {params.row?.signerList
                ?.map(
                  (user: any) => <p key={user?.id}>{user.name} - {user?.departmentResponse?.name}</p>
                )}
            </>
          }>
          {params.row?.signerList
            ?.map(
              (user: any) => `${user.name} - ${user?.departmentResponse?.name}`
            )
            .join(", ")}
        </Tooltip>
    },
    {
      key: DocumentReviewTableFields.SIGNING_DATE,
      label: DocumentReviewTableFields.SIGNING_DATE,
      type: "date",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: DocumentReviewTableFields.EFFECTIVE_DATE,
      label: DocumentReviewTableFields.EFFECTIVE_DATE,
      type: "date",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: DocumentReviewTableFields.EFFECTIVE_END_DATE,
      label: DocumentReviewTableFields.EFFECTIVE_END_DATE,
      type: "date",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: DocumentReviewTableFields.SOW_CONTRACT,
      label: DocumentReviewTableFields.SOW_CONTRACT,
      type: "string",
      sortable: true,
      hideable: false,
      minWidth: 240,
    },
    {
      key: DocumentReviewTableFields.CONTRACT_VALUE,
      label: DocumentReviewTableFields.CONTRACT_VALUE,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => `${String(params.value)?.replace?.(THOUSAND_SEPARATOR, ",")} ${params.row?.currency?.unit ?? ''}`.trim(),
    },
    {
      key: DocumentReviewTableFields.SAMPLE_CONTRACT_TYPE,
      label: DocumentReviewTableFields.SAMPLE,
      type: "string",
      quickFilter: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => t(SAMPLE_CONTRACT_TYPES
        ?.find((ele) => ele?.value === params?.value)?.label ?? '')
    },
    {
      key: DocumentReviewTableFields.LCS_STATUS,
      label: DocumentReviewTableFields.LCS_STATUS,
      type: "string",
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 240,
      filterRank: 1,
      renderCell: (params) => {
        if (!params.row?.lcsStatus) return null;
        return (
          <Button
            variant="outlined"
            style={{
              background:
                ((LcsStatusLabels as any)?.[params.row?.lcsStatus]) === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                ((LcsStatusLabels as any)?.[params.row?.lcsStatus]) === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {(LcsStatusLabels as any)?.[params.row?.lcsStatus] ?? ""}
          </Button>
        )
      },
    },
    {
      key: DocumentReviewTableFields.PIC,
      label: DocumentReviewTableFields.PIC,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 250,
      renderCell: (params) => <Tooltip
        placement="bottom-start"
        title={params.row?.pic
          ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
          : ""}>
        <span>
          {params.row?.pic
            ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
            : ""}
        </span>
      </Tooltip>,
    },
  ]);

  /** Get all legal advice */
  const getTableQuery = useQuery({
    queryKey: ['document-review/statistics/table/backdate'],
    queryFn: async () =>
      await getStatisticTableBackdateFn(castTableStateToParams(tableState, reportFilters)),
    enabled: false,
  });

  useEffect(() => {
    tableState && getTableQuery.refetch();
  }, [tableState, reportFilters])

  const onSearchClick = (data: any) => {
    setReportFilters({
      ...data
    })
  }



  return (
    <Stack direction={'column'} height={'100%'}>
      <ReportFilterPanel onSearch={onSearchClick} />
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.data ?? []}
          columns={DocumentReviewTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabel(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          onRowClick={(params) =>
            router.push(
              `/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            )
          }
          hideRowCheckbox
        />
      </div>
    </Stack>
  )
}

export default DocumentReviewReportBackdate


const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: IReportFilters
): GetDocumentReviewListParams => {
  const params: GetDocumentReviewListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: DocumentReviewTableFields.ID,
    orderBy: "DESC",
  };
  if (filters?.status?.length) {
    params.statusList = filters.status?.join(',');
  }
  if (filters?.departments?.length) {
    params.departmentIds = filters.departments?.join(',');
  }
  if (filters?.startDate) {
    params.createFrom = filters?.startDate;
  }
  if (filters?.endDate) {
    params.createTo = filters?.endDate;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  return params;
};
const getFieldLabel = (key: string) => {
  return `DOCUMENT_REVIEW.column.${key}`;
};