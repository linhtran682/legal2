import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FieldError, FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  ConfirmExtensionRequestSchema,
  ExtensionOptions,
  TimeExtensionRequestFieldNames,
  TimeExtensionRequestSchema,
  TimeExtensionRequestSchemaI,
} from "@/models/document_management/TimeExtensionDocument";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { RadioGroupField } from "@/components/commons/form_inputs/RadioGroupField";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { castFeedbackLegalDocumentRequestSchemaToDTO } from "@/models/law_document/FeedbackLegalDocument";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { Module, ModuleKeys } from "@/constants/general";
import {
  useCreateTimeExtension,
  useGetTimeExtension,
  useUpdateTimeExtension,
} from "@/apis/service/document_management/timeExtensionDocument";

const initialEmptyValue: TimeExtensionRequestSchemaI = {
  [TimeExtensionRequestFieldNames.DEADLINE]: "",
  [TimeExtensionRequestFieldNames.REASON]: "",
  [TimeExtensionRequestFieldNames.USERS]: [],
  [TimeExtensionRequestFieldNames.REMIND]: undefined,
};

export interface TimeExtensionTypeFormProps {
  titlePopup?: string;
  initialValue?: TimeExtensionRequestSchemaI;
  documentId?: number;
  timeExtensionRequestId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  isConfirmExtension?: boolean;
  name?: string;
  handleSubmit?: any;
  module?: number;
  senderDocumentManagement?: any;
}

export const TimeExtensionDocumentForm = (
  props: TimeExtensionTypeFormProps
) => {
  const {
    titlePopup,
    initialValue = initialEmptyValue,
    documentId,
    timeExtensionRequestId,
    isOpen = false,
    setIsOpen,
    isConfirmExtension = false,
    name,
    handleSubmit,
    module = Module.get(ModuleKeys.ADVISE),
    senderDocumentManagement,
  } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const { data: getDataTimeExtension, isLoading } = useGetTimeExtension({
    request: { documentId, timeExtensionRequestId },
    config: {
      enabled: !!documentId && !!timeExtensionRequestId && isConfirmExtension,
    },
  });

  const form = useForm<any>({
    resolver: yupResolver(
      isConfirmExtension
        ? TimeExtensionRequestSchema.concat(ConfirmExtensionRequestSchema)
        : TimeExtensionRequestSchema
    ),
    defaultValues: initialValue,
  });

  const { mutateAsync: createTimeExtension, isPending } =
    useCreateTimeExtension({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(
                titlePopup ??
                  `DOCUMENT_MANAGEMENT.timeExtension.title.${
                    isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                  }`
              ),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const {
    mutateAsync: updateTimeExtension,
    isPending: isLoadingUpdateTimeExtension,
  } = useUpdateTimeExtension({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t(
              titlePopup ??
                `DOCUMENT_MANAGEMENT.timeExtension.title.${
                  isConfirmExtension ? "titlePopup" : "titlePopupRequest"
                }`
            ),
          })
        );
        onCloseForm(true);
      },
    },
  });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    if (isConfirmExtension) {
      await updateTimeExtension({
        documentId,
        timeExtensionRequestId,
        data: {
          remind: data?.remind,
          users: data?.users,
          type: data?.confirm,
          ...(!data?.confirm && {
            deadlineAccept: data?.acceptableDeadline,
            reason: data?.acceptableReason,
          }),
        },
      });
      handleSubmit && handleSubmit();
      return;
    }

    await createTimeExtension({
      documentId,
      data,
    });
  };

  useEffect(() => {
    if (initialValue?.userIds && !isConfirmExtension) {
      form.reset({
        userIds: initialValue?.userIds,
      });
    }
  }, [initialValue?.userIds, isConfirmExtension]);

  useEffect(() => {
    if (getDataTimeExtension) {
      const { user, ...restGetDataTimeExtension } = getDataTimeExtension;

      form.reset({
        ...restGetDataTimeExtension,
        [TimeExtensionRequestFieldNames.CONFIRM]: 1,
        users: [user],
      });
    }
  }, [getDataTimeExtension]);

  if (isLoading) return;

  return (
    <ModalCommon
      title={t(
        titlePopup ??
          `DOCUMENT_MANAGEMENT.timeExtension.title.${
            isConfirmExtension ? "titlePopup" : "titlePopupRequest"
          }`
      )}
      open={isOpen}
      onClose={()=>onCloseForm()}
    >
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_MANAGEMENT.timeExtension.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              {isConfirmExtension && (
                <Grid item width={"100%"}>
                  <RadioGroupField
                    isNumber
                    items={ExtensionOptions}
                    name={TimeExtensionRequestFieldNames.CONFIRM}
                    error={
                      form.formState.errors[
                        TimeExtensionRequestFieldNames.CONFIRM
                      ] as FieldError
                    }
                  />
                </Grid>
              )}
              <Grid item width={"100%"}>
                <DateInput
                  name={TimeExtensionRequestFieldNames.DEADLINE}
                  control={form.control}
                  label={t(
                    `DOCUMENT_MANAGEMENT.timeExtension.title.newDeadline`
                  )}
                  placeholder={t(
                    `DOCUMENT_MANAGEMENT.timeExtension.placeHolder.newDeadline`
                  )}
                  minDate={new Date()}
                  required
                  disabled={isConfirmExtension}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={TimeExtensionRequestFieldNames.REASON}
                  label={t(`DOCUMENT_MANAGEMENT.timeExtension.title.reason`)}
                  placeHolder={t(
                    `DOCUMENT_MANAGEMENT.timeExtension.placeHolder.reason`
                  )}
                  minRows={5}
                  required
                  disabled={isConfirmExtension}
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={TimeExtensionRequestFieldNames.USERS}
                    label={t(
                      "DOCUMENT_MANAGEMENT.timeExtension.title.personDocument"
                    )}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"timeExtensionDocumentManagement/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
              {isConfirmExtension && (
                <>
                  <Grid item width={"100%"}>
                    <DateInput
                      name={TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE}
                      control={form.control}
                      label={t(
                        `DOCUMENT_MANAGEMENT.timeExtension.title.newDeadlineAccept`
                      )}
                      placeholder={t(
                        `DOCUMENT_MANAGEMENT.timeExtension.placeHolder.newDeadlineAccept`
                      )}
                      required
                      disabled={form?.watch(
                        TimeExtensionRequestFieldNames.CONFIRM
                      )}
                    />
                  </Grid>
                  <Grid item width={"100%"}>
                    <FormTextArea
                      control={form.control}
                      name={
                        TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON
                      }
                      label={t(
                        `DOCUMENT_MANAGEMENT.timeExtension.title.reason`
                      )}
                      placeHolder={t(
                        `DOCUMENT_MANAGEMENT.timeExtension.placeHolder.reason`
                      )}
                      minRows={5}
                      required
                      disabled={form?.watch(
                        TimeExtensionRequestFieldNames.CONFIRM
                      )}
                    />
                  </Grid>
                </>
              )}
              {/* <Grid item width={"100%"}>
                <Grid width={"100%"}>
                  <Typography variant="h5">
                    {t("reminder_template.title.reminder_sent_to")}
                  </Typography>
                </Grid>
              </Grid> */}
            </Grid>
          
            <ReminderPickerSubForm
              name={TimeExtensionRequestFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave={`common.button.${
                isConfirmExtension ? "confirm" : "send"
              }`}
              loading={isPending || isLoadingUpdateTimeExtension || isLoading}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    ...castFeedbackLegalDocumentRequestSchemaToDTO({
                      ...form.getValues(),
                    }),
                  });
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
