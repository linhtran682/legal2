import { FormRadio } from "@/components/commons/form_inputs/FormRadio";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { Box, Grid } from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import StockManagement from "../stock_management/StockManagement";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { useEffect, useRef, useState } from "react";
import {
  getDocumentMngStock,
  updatePositionDocumentManagement,
} from "@/apis/service/document_management/DocumentManagement";
import { useMutation, useQuery } from "@tanstack/react-query";
import { DocumentMoveModel } from "@/models/document_management/DocumentManagement";
import { toast } from "react-toastify";

interface StockPositionFormProps {
  titlePopup: string;
  isOpen: boolean;
  selectedRequest?: any;
  setIsOpen: (isOpen: boolean) => void;
  folderId: number;
}
export const StockPositionForm = (props: StockPositionFormProps) => {
  const { titlePopup, isOpen = false, setIsOpen } = props;
  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const [idFolder, setIdFolder] = useState<number | undefined>(undefined);

  const handleGetIdFolder = (id: number) => {
    setIdFolder(id);
  };
  const onCloseForm = () => {
    setIsOpen(false);
    form.reset({ type: true });
  };
  const form = useForm<any>({
    defaultValues: {
      type: true,
    },
  });
  const getlStocksQuery = useQuery({
    queryKey: ["getlStocksQuery"],
    queryFn: () => getDocumentMngStock({name:''}),
  });
  useEffect(() => {
    getlStocksQuery.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const updateDocumentPositionQuery = useMutation({
    mutationFn: updatePositionDocumentManagement,
    onSuccess: () => {
      toast.success(t("DOCUMENT_MANAGEMENT.stock_position_change_form.move_success"));
      props.setIsOpen(false);
    },
  });
  const textPopup = form.watch("type") == true
    ? t("DOCUMENT_MANAGEMENT.stock_position_change_form.confirm_copy")
    : t("DOCUMENT_MANAGEMENT.stock_position_change_form.confirm_move");
  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={onCloseForm}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid container>
              <FormRadio
                name="type"
                control={form.control}
                label={""}
                radioOptions={[
                  {
                    value: true,
                    label: t(
                      "DOCUMENT_MANAGEMENT.stock_position_change_form.copy"
                    ),
                  },
                  {
                    value: false,
                    label: t(
                      "DOCUMENT_MANAGEMENT.stock_position_change_form.move"
                    ),
                  },
                ]}
                explanation={t(
                  "DOCUMENT_MANAGEMENT.stock_position_change_form.helpText"
                )}
                required
              />
            </Grid>
            <Box minHeight={100}>
              <StockManagement
                defaultExpandedItems={["1"]}
                defaultSelectedItems="1"
                listItem={
                  getlStocksQuery.data?.folders
                    ? getlStocksQuery.data.folders
                    : []
                }
                handleItemClick={(id: any) => {
                  handleGetIdFolder(id);
                  // props.handleItemClick && props.handleItemClick(id);
                }}
                isCopy={true}
              />
            </Box>
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={false}
              onCancel={onCloseForm}
              textDescription={textPopup}
              onSave={async () => {
                try {
                  if (idFolder === undefined) {
                    toast.warning(
                      t("DOCUMENT_MANAGEMENT.stock_create_form.validateFolder")
                    );
                    return;
                  }
                  const bodySend: DocumentMoveModel = {
                    documentIds: props.selectedRequest.map(
                      (ele: any) => ele.id
                    ),
                    newFolderId: idFolder,
                    type: form.getValues("type") === 'true' ? 1 : 0,
                  };
                  updateDocumentPositionQuery.mutate(bodySend);
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
