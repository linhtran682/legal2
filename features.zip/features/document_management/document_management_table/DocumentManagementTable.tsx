"use client";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import MultipleTabsTable from "@/components/commons/tables/multiple_tabs_table/MultipleTabsTable";
import {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { DOCUMENT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import {
  BasedDocumentManagementFieldNames,
  DocumentManagementParams,
  DocumentMngColumn,
} from "@/models/document_management/DocumentManagement";
import { Box, Button, Grid, IconButton, Radio } from "@mui/material";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  getDocumentManagementExcel,
  getDocumentManagements,
  getDocumentMngStock,
  shareDocumentMgmtFn,
} from "@/apis/service/document_management/DocumentManagement";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { GridFilterItem } from "@mui/x-data-grid";
import { MIME_TYPES, ModuleFields } from "@/constants/general";
import { StockPositionForm } from "../stock_position_change_form/StockPositionForm";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import { COLOR_TYPE } from "@/constants/color";
import { downloadFile } from "@/utils";
import { format, endOfDay } from "date-fns";
import DocumentManagementTableActions, {
  ButtonActionDocumentManagement,
} from "./document_management_table_actions/DocumentManagementTableActions";
import { TimeExtensionDocumentForm } from "../time_extension_document_form/TimeExtensionDocumentForm";
import { ForwardDocumentManagementForm } from "../forward_legal_advice_form/ForwardDocumentManagementForm";
import { AppContext } from "@/context/AppContext";
import { RequestAdditionalForm } from "../request_additional_information_form/RequestAdditionalForm";
import { getStatusList } from "@/apis/service/status/Status";
import { FieldFieldNames } from "@/models/field/Field";
import { StatusDTO } from "@/models/status/Status";
import { Range as DateRange } from "react-date-range";
import { getMultipleTreeSelectOperators } from "@/components/commons/filters/MultipleTreeSelectFilter";
import { Department } from "@/models/department/Department";
import { getMultipleAsyncChoosingOperators } from "@/components/commons/filters/MultipleAsyncChoosingFilter";
import SharePopup from "@/components/commons/share_popup/SharePopup";

export const DocumentManagementTableConst = {
  GENERAL_TABLE: "DOCUMENT_MANAGEMENT.title.general_table",
  GET_GENERAL_TABLE_ITEM_QUERY_KEY: "getGeneralBasedDocumentManagement",
  PERSONAL_TABLE: "DOCUMENT_MANAGEMENT.title.personal_table",
  GET_PERSONAL_TABLE_ITEM_QUERY_KEY: "getPersonalBasedLegalDocumentManagement",
  GET_LEGAL_DOCUMENT_EXCEL: "getLegalDocumentExcel",
};
interface DocumentManagementTableProps {
  folderId: number;
}
export const DocumentManagementTable = (
  props: DocumentManagementTableProps
) => {
  const [t, i18n] = useTranslation();
  const appContext = useContext(AppContext);
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<number>(0);
  const [popupVisibleState, setPopupVisibleState] = useState<boolean>(false);
  const [popupVisibleStateObject, setPopupVisibleStateObject] = useState<
    Record<string, boolean>
  >({});
  const [selectedDocuments, setSelectedDocuments] = useState<[] | undefined>(
    []
  );
  const [initialDocumentManagement, setInitialDocumentManagement] =
    useState<any>(undefined);

  const getGeneralBasedDocumentsManagmentQuery = useQuery({
    queryKey: ["getGeneralDocumentsManagment"],
    queryFn: () =>
      getDocumentManagements({
        ...castTableStateToParams(generalTableState),
        parentId: props.folderId,
      }),
  });
  const getPersonalBasedDocumentsManagmentQuery = useQuery({
    queryKey: ["getPersonalDocumentsManagment"],
    queryFn: () =>
      getDocumentManagements({
        ...castTableStateToParams(personalTableState),
        tab: 1,
        parentId: props.folderId,
      }),
  });
  const [generalTableState, setGeneralTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });

  const [personalTableState, setPersonalTableState] =
    useState<StandardTableState>({
      filterModel: { items: [] },
      sorterModel: [],
      paginationModel: DEFAULT_PAGE_MODAL,
      columnVisibilityModel: undefined,
    });
  const handleClick = (type: any, row?: any) => {
    if (type) {
      row && setInitialDocumentManagement(row);
      changePopupVisibleObject(type, true);
    }
  };

  useEffect(() => {
    generalTableState &&
      getGeneralBasedDocumentsManagmentQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generalTableState, props.folderId]);

  useEffect(() => {
    personalTableState &&
      getPersonalBasedDocumentsManagmentQuery
        .refetch()
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [personalTableState, props.folderId]);

  useEffect(() => {
    setGeneralTableState({ ...generalTableState });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.folderId]);

  const shareMutation = useMutation({
    mutationFn: shareDocumentMgmtFn,
    onSuccess: () => {
      toast.success(
        t(`DOCUMENT_MANAGEMENT.messages.shareSuccess`)
      );
      // router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const [legalDocumentTableColumns] = useState<MultipleFilterTableColumn[]>(() => [
    {
      key: BasedDocumentManagementFieldNames.ID,
      label: BasedDocumentManagementFieldNames.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
    },
    {
      key: BasedDocumentManagementFieldNames.FOLDER_ID,
      label: BasedDocumentManagementFieldNames.FOLDER_ID,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      flex: 1,
      minWidth: 150,
      renderCell: (row) => <>{row.row.folderName}</>,
      filterOperators: getMultipleTreeSelectOperators<Department>(
        {
          getOptions: async (keyword) => {
            try {
              const response = await getDocumentMngStock({ name: keyword });
              return (response?.folders as unknown as Department[]) ?? [];
            } catch (e) {
              return [];
            }
          },
          getOptionChildren: (item) => item.children,
          getOptionKey: (item) => item.id.toString(),
          getOptionLabel: (item) => item.name ?? "",
          keyQuery: "stock_List_Query_filter",
        },
        t
      ),
    },
    {
      key: BasedDocumentManagementFieldNames.DOCUMENT_TYPE,
      label: BasedDocumentManagementFieldNames.DOCUMENT_TYPE,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      flex: 1
    },
    {
      key: BasedDocumentManagementFieldNames.NAME,
      label: BasedDocumentManagementFieldNames.NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 150,
      flex: 1
    },
    {
      key: BasedDocumentManagementFieldNames.STATUS,
      label: BasedDocumentManagementFieldNames.STATUS,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 220,
      renderCell: (params) => {
        return (
          <Button
            variant="outlined"
            style={{
              background:
                params?.row?.status?.name && params?.row?.status?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params?.row?.status?.name && params?.row?.status?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params?.row?.status?.name}
          </Button>
        );
      },
      filterOperators: getMultipleAsyncChoosingOperators(
        {
          getOptions: async () => {
            const response = await getStatusList({
              // name: keyword,
              page: 0,
              size: 100,
              sortBy: FieldFieldNames.NAME,
              orderBy: "ASC",
              modules: [ModuleFields.DOCUMENT_MANAGEMENT.module],
              active: 1,
            });

            return response?.statusResponses || [];
          },
          getOptionKey: (item) => item.id.toString(),
          getOptionLabel: (item) => item.name,
          keyQuery: `document-management-${BasedDocumentManagementFieldNames.STATUS}`,
        },
        t
      ),
    },
    {
      key: BasedDocumentManagementFieldNames.DATE_ISSUED,
      label: BasedDocumentManagementFieldNames.DATE_ISSUED,
      type: "date",
      quickFilter: true,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      renderCell: (params) => params.row.dateIssued ? format(new Date(params.row.dateIssued), 'dd/MM/yyyy') : ''

    },
    {
      key: BasedDocumentManagementFieldNames.DOCUMENT_CHANGE_DATE,
      label: BasedDocumentManagementFieldNames.DOCUMENT_CHANGE_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      renderCell: (params) => params.row.documentChangeDate ? format(new Date(params.row.documentChangeDate), 'dd/MM/yyyy') : ''
    },
    {
      key: BasedDocumentManagementFieldNames.EXPIRY_DATE,
      label: BasedDocumentManagementFieldNames.EXPIRY_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      renderCell: (params) => params.row.expiryDate ? format(new Date(params.row.expiryDate), 'dd/MM/yyyy') : ''

    },
    {
      key: BasedDocumentManagementFieldNames.COMPANY_SCOPE,
      label: BasedDocumentManagementFieldNames.COMPANY_SCOPE,
      type: "string",
      filterable: false,
      sortable: false,
      align: 'center',
      renderCell: (params) => <Radio checked={params.value} />,
      minWidth: 120,
    },
    {
      key: BasedDocumentManagementFieldNames.DEPARTMENT_SCOPE,
      label: BasedDocumentManagementFieldNames.DEPARTMENT_SCOPE,
      type: "string",
      filterable: false,
      sortable: false,
      minWidth: 120,
      align: 'center',
      renderCell: (params) => (
        <Radio style={{ width: 10 }} checked={params.value} />
      ),
    },
    {
      key: BasedDocumentManagementFieldNames.CREATOR,
      label: BasedDocumentManagementFieldNames.CREATOR,
      type: "string",
      sortable: true,
      minWidth: 200,
      renderCell: (row) => <>{row.row.createdBy.name}</>,

    },
    {
      key: BasedDocumentManagementFieldNames.RECEIVERS,
      label: BasedDocumentManagementFieldNames.RECEIVERS,
      type: "string",
      sortable: true,
      minWidth: 200,
      flex: 1,
      renderCell: (params) =>
        (params.value || []).map((item: any) => item.name).join(","),
    },
    {
      key: BasedDocumentManagementFieldNames.RELATED_DEPARTMENTS,
      label: BasedDocumentManagementFieldNames.RELATED_DEPARTMENTS,
      type: "string",
      sortable: true,
      renderCell: (params) =>
        (params.value || []).map((item: any) => item.name).join(","),
      minWidth: 200,
      flex: 1
    },
    {
      key: "action",
      label: "action",
      type: undefined,
      renderCell: (params) =>
        DocumentManagementTableActions({
          params,
          handleClickForward: () =>
            handleClick(ButtonActionDocumentManagement.FORWARD, params.row),
          handleClickExtendDeadline: () =>
            handleClick(
              ButtonActionDocumentManagement.EXTEND_DEADLINE,
              params.row
            ),
          handleClickRequestAdditional: () =>
            handleClick(
              ButtonActionDocumentManagement.REQUEST_ADDITIONAL,
              params.row
            ),
          handleClickShare: () =>
            handleClick(
              ButtonActionDocumentManagement.SHARE,
              params.row
            ),
        }),
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "last-column-sticky",
      headerClassName: 'last-column-sticky-header',
    },
  ]);

  const renderGroupActions = (prop: any) => {
    const selectedItems: DocumentMngColumn[] =
      (getPersonalBasedDocumentsManagmentQuery.data &&
        getPersonalBasedDocumentsManagmentQuery.data?.data?.filter((ele) =>
          prop?.includes(ele?.id?.toString())
        )) ||
      [];

    return (
      <>
        <Box
          sx={{
            display: "flex",
            width: "100%",
            gap: 1,
            justifyContent: "flex-end",
          }}
        >
          <Button
            sx={{
              visibility:
                activeTab === 0 || !prop?.length ? "hidden" : "visible",
            }}
            className="confirm"
            // disabled={!enableRequestButton}
            onClick={() => handleClickopenPopupStock(selectedItems, true)}
            variant="contained"
          >
            {t("DOCUMENT_MANAGEMENT.button.copyMoveTo")}
          </Button>
        </Box>
      </>
    );
  };
  const handleClickopenPopupStock = (selectedRow: any, isOpen: boolean) => {
    changePopupVisible(isOpen);
    setSelectedDocuments(selectedRow);
  };

  const changePopupVisible = (state: boolean = false) => {
    setPopupVisibleState(state);
    if (!state) {
      setInitialDocumentManagement(undefined);
      setSelectedDocuments([]);
    }
  };

  const changePopupVisibleObject = (type: any, state: boolean = false, reload: boolean = false) => {
    setPopupVisibleStateObject((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state) {
      setInitialDocumentManagement(undefined);
      setSelectedDocuments([]);
    }
    if (reload) {
      getPersonalBasedDocumentsManagmentQuery.refetch()
      getGeneralBasedDocumentsManagmentQuery.refetch()
    }
  };

  const getDocumentManagementExcelQuery = useQuery({
    queryKey: ["document_management_excel"],
    queryFn: () =>
      getDocumentManagementExcel({
        ...castTableStateToParams(
          activeTab === 0 ? generalTableState : personalTableState
        ),
        tab: activeTab,
        size: 9999,
      }),
    enabled: false,
  });
  const renderExportButton = () => {
    return (
      <Grid item>
        <IconButton
          onClick={() => {
            getDocumentManagementExcelQuery.refetch().then((response: any) => {
              const fileName = `${i18n.language === "en"
                ? "Document Management"
                : "Quản lý tài liệu"
                }_${format(new Date(), "ddMMyyyy")}`;
              response?.data &&
                downloadFile(response, MIME_TYPES.XLSX, fileName);
            });
          }}
          disabled={
            getGeneralBasedDocumentsManagmentQuery.isFetching ||
            getPersonalBasedDocumentsManagmentQuery.isFetching ||
            getDocumentManagementExcelQuery.isFetching
          }
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <FileDownloadOutlinedIcon />
        </IconButton>
      </Grid>
    );
  };
  return (
    <>
      <MultipleTabsTable
        groupedActions={renderGroupActions}
        tableTabs={[
          {
            tabName: t(DocumentManagementTableConst.GENERAL_TABLE),
            tabKey: DocumentManagementTableConst.GENERAL_TABLE,
            data: getGeneralBasedDocumentsManagmentQuery.data?.data || [],
            loading: getGeneralBasedDocumentsManagmentQuery.isFetching,
            rowCount: getGeneralBasedDocumentsManagmentQuery.data?.total,
            onChange: setGeneralTableState,
          },
          {
            tabName: t(DocumentManagementTableConst.PERSONAL_TABLE),
            tabKey: DocumentManagementTableConst.PERSONAL_TABLE,
            data: getPersonalBasedDocumentsManagmentQuery?.data?.data || [],
            loading: getPersonalBasedDocumentsManagmentQuery.isFetching,
            rowCount: getPersonalBasedDocumentsManagmentQuery?.data?.total,
            onChange: setPersonalTableState,
          },
        ]}
        columns={legalDocumentTableColumns
          .map((column) => ({
            ...column,
            label: column.label && `DOCUMENT_MANAGEMENT.column.${column.label}`,
          }))}
        getRowId={(item) => item.id.toString()}
        multipleFilter
        // exportFile={renderExportButton()}
        quickFilterProps={{
          defaultSelectedOptionKey: BasedDocumentManagementFieldNames.NAME,
          // quickFilterMode: "multiple",
          placeHolder: (fieldKey) =>
            t(`common.place_holder.search`, {
              fieldName: t(
                `DOCUMENT_MANAGEMENT.field_name.${fieldKey}`
              ).toLocaleLowerCase(),
            }),
        }}
        onRowClick={(params) =>
          router.push(
            `/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${props.folderId}/${params.id}`
          )
        }
        onTabChange={setActiveTab}
        exportFile={renderExportButton()}
      />
      {/* <DocumentManagementForm /> */}
      {props.folderId && (
        <StockPositionForm
          folderId={props.folderId && props.folderId}
          setIsOpen={(state) => changePopupVisible(state)}
          isOpen={popupVisibleState}
          titlePopup={t("DOCUMENT_MANAGEMENT.button.copyMoveTo")}
          selectedRequest={selectedDocuments}

        />
      )}
      {popupVisibleStateObject?.[ButtonActionDocumentManagement.SHARE] && <SharePopup
        setIsOpen={(state, reload) =>
          changePopupVisibleObject(ButtonActionDocumentManagement.SHARE, state, reload)
        }
        isOpen={true}
        owner={initialDocumentManagement?.createdBy}
        pics={initialDocumentManagement?.receivers}
        onSubmit={async (data: any) => {
          const params = {
            id: initialDocumentManagement?.id as number,
            data
          }
          await shareMutation.mutateAsync(params)
        }}
        initialValue={{
          legalAccessType: initialDocumentManagement?.legalAccessType,
          sharedDepartments: initialDocumentManagement?.sharedDepartments,
          sharedUsers: initialDocumentManagement?.sharedUsers
        }}
      />}
      {popupVisibleStateObject?.[
        ButtonActionDocumentManagement.EXTEND_DEADLINE
      ] && (
          <TimeExtensionDocumentForm
            setIsOpen={(state, reload) =>
              changePopupVisibleObject(
                ButtonActionDocumentManagement.EXTEND_DEADLINE,
                state, reload
              )
            }
            documentId={initialDocumentManagement?.id}
            isOpen={
              popupVisibleStateObject?.[
              ButtonActionDocumentManagement.EXTEND_DEADLINE
              ]
            }
            name={initialDocumentManagement?.name}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: initialDocumentManagement?.receivers,
            }}
          />
        )}
      {popupVisibleStateObject?.[ButtonActionDocumentManagement.FORWARD] && (
        <ForwardDocumentManagementForm
          setIsOpen={(state, reload) =>
            changePopupVisibleObject(
              ButtonActionDocumentManagement.FORWARD,
              state,
              reload
            )
          }
          documentId={initialDocumentManagement?.id}
          isOpen={
            popupVisibleStateObject?.[ButtonActionDocumentManagement.FORWARD]
          }
          name={initialDocumentManagement?.name}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleStateObject?.[
        ButtonActionDocumentManagement.REQUEST_ADDITIONAL
      ] && (
          <RequestAdditionalForm
            setIsOpen={(state, reload) =>
              changePopupVisibleObject(
                ButtonActionDocumentManagement.REQUEST_ADDITIONAL,
                state,
                reload
              )
            }
            documentId={initialDocumentManagement?.id}
            isOpen={
              popupVisibleStateObject?.[
              ButtonActionDocumentManagement.REQUEST_ADDITIONAL
              ]
            }
            name={initialDocumentManagement?.name}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: initialDocumentManagement?.receivers,
            }}
          />
        )}
    </>
  );
};
const castTableStateToParams = (
  tableState: StandardTableState
): DocumentManagementParams => {
  const params: DocumentManagementParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: BasedDocumentManagementFieldNames.ID,
    orderBy: "DESC",
  };

  (tableState.filterModel?.items || []).forEach((item: GridFilterItem) => {
    if (item.field == BasedDocumentManagementFieldNames.STATUS) {
      params.status = (item.value ?? [])
        .map((item: StatusDTO) => item.id)
        .join(",");
    }
    if (item.field == BasedDocumentManagementFieldNames.FOLDER_ID) {
      params.folderIds = (item.value ?? [])
        .map((item: StatusDTO) => item.id)
        .join(",");
    }
    if (item.field == BasedDocumentManagementFieldNames.DATE_ISSUED) {
      params.dateIssuedFrom = (
        item.value as DateRange
      ).startDate?.toISOString();

      params.dateIssuedTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }
    if (item.field == BasedDocumentManagementFieldNames.DOCUMENT_CHANGE_DATE) {
      params.documentChangeDateFrom = (
        item.value as DateRange
      ).startDate?.toISOString();

      params.documentChangeDateTo = endOfDay(
        new Date((item.value as DateRange).endDate as Date)
      )?.toISOString();
    }
    if (item.field == BasedDocumentManagementFieldNames.NAME) {
      params.name = item.value;
    }
    if (item.field == BasedDocumentManagementFieldNames.DOCUMENT_TYPE) {
      params.documentType = item.value;
    }
  });

  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  return params;
};
