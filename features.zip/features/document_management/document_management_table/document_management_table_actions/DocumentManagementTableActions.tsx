import { IconExtendDeadline } from "@/assets/iconMenu/IconExtendDeadline";
import { IconForward } from "@/assets/iconMenu/IconForward";
import { IconRequestAdditional } from "@/assets/iconMenu/IconRequestAdditional";
import IconShare from "@/assets/iconMenu/IconShare";
import {
  ActionButtonCustom,
  ActionButtonItem,
} from "@/components/commons/action_button/ActionButtonCustom";
import { ActionButtonDetail } from "@/components/commons/action_button/ActionButtonDetail";
import { COLOR_TYPE } from "@/constants/color";
import {
  OwnerRoleDocumentManagement,
  OwnerRoleDocumentManagementKey,
} from "@/constants/general";
import { TypeActionsRole } from "@/models/law_document/LawDocument";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";

export const ButtonActionDocumentManagement = {
  FORWARD: "forward", // Chuyển tiếp
  EXTEND_DEADLINE: "extendDeadline", // Gia hạn thời gian
  REQUEST_ADDITIONAL: "requestAdditional", // Yêu cầu bổ sung thông tin
  SHARE: "share"
};

type TypeActionBtn = {
  typeBtn: string;
  disable?: boolean;
};

const uniqueCheck = (checkData: TypeActionBtn[]) => {
  return checkData.reduce(
    (accumulator: TypeActionBtn[], currentValue: TypeActionBtn) => {
      const existing = accumulator.find(
        (item) => item.typeBtn === currentValue.typeBtn
      );

      if (existing) {
        if (Boolean(existing?.disable) === Boolean(currentValue?.disable)) {
          accumulator = accumulator.filter(
            (item) => item.typeBtn !== currentValue.typeBtn
          );
          accumulator.push(currentValue);
        } else {
          const indexAcc = accumulator.findIndex(
            (item: TypeActionBtn) => item.typeBtn === currentValue.typeBtn
          );
          accumulator.splice(indexAcc, 1, { ...currentValue, disable: false });
        }
      } else {
        accumulator.push(currentValue);
      }

      return accumulator;
    },
    []
  );
};

const authorizedActionMapCallBack = (documentActions: TypeActionsRole[]) => {
  const listActionsDefaults = [
    { typeBtn: ButtonActionDocumentManagement.FORWARD },
    { typeBtn: ButtonActionDocumentManagement.EXTEND_DEADLINE },
    { typeBtn: ButtonActionDocumentManagement.REQUEST_ADDITIONAL },
    { typeBtn: ButtonActionDocumentManagement.SHARE },
  ];
  const authorizedActionMap = new Map<number | string, any>([
    [
      OwnerRoleDocumentManagement.get(
        OwnerRoleDocumentManagementKey.AUTHORIZED_PERSON
      )!,
      listActionsDefaults,
    ],
    [
      OwnerRoleDocumentManagement.get(
        OwnerRoleDocumentManagementKey.ASSIGNMENT_DOUCMENT
      )!,
      listActionsDefaults,
    ],
    [
      OwnerRoleDocumentManagement.get(
        OwnerRoleDocumentManagementKey.ASSIGNMENT_POPUP
      )!,
      listActionsDefaults,
    ],
    [
      OwnerRoleDocumentManagement.get(OwnerRoleDocumentManagementKey.FORWARD)!,
      [],
    ],
    [
      OwnerRoleDocumentManagement.get(OwnerRoleDocumentManagementKey.VIEWER)!,
      [],
    ],
  ]);
  let listActionAuthorizedMap: TypeActionBtn[] = [];
  documentActions?.forEach((documentItemAction: any) => {
    const authorizedAction =
      authorizedActionMap?.get(documentItemAction?.ownerRole) || [];
    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });
  return uniqueCheck(listActionAuthorizedMap);
};

type TypePropsDocumentManagementTableActions = {
  params: { row: any };
  isActionDetail?: boolean;
  handleClickForward?: () => void;
  handleClickRequestAdditional?: () => void;
  handleClickExtendDeadline?: () => void;
  handleClickShare?: () => void;
};

const DocumentManagementTableActions = (
  props: TypePropsDocumentManagementTableActions
) => {
  const {
    params,
    isActionDetail,
    handleClickForward,
    handleClickExtendDeadline,
    handleClickRequestAdditional,
    handleClickShare
  } = props;
  const { t } = useTranslation();
  const styleBtn = {
    background: COLOR_TYPE.TOYOTA.TOYOTA1,
    color: COLOR_TYPE.TOYOTA.TOYOTA8,
  };
  const [buttonMap] = useState(
    new Map<string, ActionButtonItem>([
      [
        ButtonActionDocumentManagement.FORWARD,
        {
          key: ButtonActionDocumentManagement.FORWARD,
          icon: <IconForward />,
          iconDisable: <IconForward color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(
            `DOCUMENT_MANAGEMENT.button.${ButtonActionDocumentManagement.FORWARD}`
          ),
          onClick: handleClickForward,
          tooltipTitle: t(
            `DOCUMENT_MANAGEMENT.button.${ButtonActionDocumentManagement.FORWARD}`
          ),
          styleBtn,
          secondaryBtn: 1,
        },
      ],
      [
        ButtonActionDocumentManagement.EXTEND_DEADLINE,
        {
          key: ButtonActionDocumentManagement.EXTEND_DEADLINE,
          icon: <IconExtendDeadline />,
          iconDisable: <IconExtendDeadline color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(
            `DOCUMENT_MANAGEMENT.button.${ButtonActionDocumentManagement.EXTEND_DEADLINE}`
          ),
          onClick: handleClickExtendDeadline,
          tooltipTitle: t(
            `DOCUMENT_MANAGEMENT.button.${ButtonActionDocumentManagement.EXTEND_DEADLINE}`
          ),
          styleBtn,
          secondaryBtn: 2,
        },
      ],
      [
        ButtonActionDocumentManagement.REQUEST_ADDITIONAL,
        {
          key: ButtonActionDocumentManagement.REQUEST_ADDITIONAL,
          icon: <IconRequestAdditional />,
          iconDisable: (
            <IconRequestAdditional color={COLOR_TYPE.TOYOTA.TOYOTA5} />
          ),
          textBtn: t(
            `DOCUMENT_MANAGEMENT.button.${ButtonActionDocumentManagement.REQUEST_ADDITIONAL}`
          ),
          onClick: handleClickRequestAdditional,
          tooltipTitle: t(
            `DOCUMENT_MANAGEMENT.button.${ButtonActionDocumentManagement.REQUEST_ADDITIONAL}`
          ),
          styleBtn,
        },
      ],
      [
        ButtonActionDocumentManagement.SHARE,
        {
          key: ButtonActionDocumentManagement.SHARE,
          icon: <IconShare />,
          iconDisable: <IconShare color={COLOR_TYPE.TOYOTA.TOYOTA5} />,
          textBtn: t(`legalAdvice.button.${ButtonActionDocumentManagement.SHARE}`),
          onClick: handleClickShare,
          tooltipTitle: t(
            `legalAdvice.button.${ButtonActionDocumentManagement.SHARE}`
          ),
          styleBtn: { background: COLOR_TYPE.TOYOTA.TOYOTA1 },
          secondaryBtn: 7,
        },
      ],
    ])
  );

  if (isActionDetail) {
    return (
      <ActionButtonDetail
        params={params}
        actionButtonItems={authorizedActionMapCallBack(
          params?.row?.documentActions ?? []
        )?.map((buttons: TypeActionBtn) => buttonMap.get(buttons?.typeBtn)!)}
      />
    );
  }

  return (
    <ActionButtonCustom
      params={params}
      actionButtonItems={
        authorizedActionMapCallBack(params?.row?.documentActions)?.map(
          (buttons: TypeActionBtn) => buttonMap.get(buttons?.typeBtn)
        ) as ActionButtonItem[]
      }
      listActions={props?.params?.row?.documentActions ?? []}
    />
  );
};

export default DocumentManagementTableActions;
