import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { LegalAdviceStatusContent, LegalAdviceStatusKey, Module, ModuleFields, ModuleKeys } from "@/constants/general";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { castReminderSchemaToSaveReminderDTO } from "@/models/reminder_template/ReminderDTO";
import {
  RequestAdditionalFieldNames,
  RequestAdditionalSchema,
  RequestAdditionalSchemaI,
} from "@/models/document_management/RequestAdditionalForm";
import { useCreateRequestAdditional } from "@/apis/service/document_management/requestAdditional";
import { useSearchStatus } from "@/hooks/useSearchStatus";

const initialEmptyValue: RequestAdditionalSchemaI = {
  [RequestAdditionalFieldNames.DEADLINE]: "",
  [RequestAdditionalFieldNames.CONTENT]: "",
  [RequestAdditionalFieldNames.USERS]: [],
  [RequestAdditionalFieldNames.REMIND]: undefined,
};

export interface RequestAdditionalInformationTypeFormProps {
  titlePopup?: string;
  initialValue?: RequestAdditionalSchemaI;
  documentId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
  defaultStatus?: string
}

export const RequestAdditionalForm = (
  props: RequestAdditionalInformationTypeFormProps
) => {
  const {
    titlePopup = "DOCUMENT_MANAGEMENT.requestAdditional.title.titlePopup",
    initialValue = initialEmptyValue,
    documentId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DOCUMENT_MANAGEMENT),
    senderDocumentManagement,
    defaultStatus= LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.REQUEST_ADDITIONAL
    ) as string,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);

  const form = useForm<any>({
    resolver: yupResolver(RequestAdditionalSchema),
    defaultValues: initialValue,
  });

  useSearchStatus({
    keyword: defaultStatus,
    form,
    modules: ModuleFields.DOCUMENT_MANAGEMENT.module,
    queryKey: "DOCUMENT_MANAGEMENT_REQUEST_ADDITIONAL",
  });

  const { mutateAsync: createRequestApproval, isPending } =
    useCreateRequestAdditional({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    await createRequestApproval({
      documentId,
      data,
    });
  };

  useEffect(() => {
    if (initialValue?.userIds) {
      form.reset({
        ...initialEmptyValue,
        userIds: initialValue?.userIds,
      });
    }
  }, [initialValue?.userIds]);

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_MANAGEMENT.requestAdditional.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} (
                    {senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"} style={{display: 'none'}}>
                <FormAsyncSelect
                  control={form.control}
                  name={RequestAdditionalFieldNames.STATUS}
                  label={t(
                    `DOCUMENT_MANAGEMENT.requestAdditional.title.status`
                  )}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  keyQuery={"status-query-request-additional"}
                  getOptions={async (keyword) => {
                    if (typeof keyword == "string") {
                      const response = await getStatusList({
                        name: keyword,
                        modules: [
                          Module.get(ModuleKeys.DOCUMENT_MANAGEMENT) as number,
                        ],
                        page: 0,
                        size: 100,
                        sortBy: StatusFieldNames.NAME,
                        orderBy: "ASC",
                        active: 1
                      });

                      return response?.statusResponses || [];
                    } else {
                      if (keyword?.length && keyword.length > 0) {
                        return getStatus(Number(keyword[0])).then((value) =>
                          value ? [value] : []
                        );
                      }
                    }

                    return [] as StatusDTO[];
                  }}
                  getOptionKey={(option) => option.id.toString()}
                  getOptionLabel={(option) => option.name}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={RequestAdditionalFieldNames.DEADLINE}
                  control={form.control}
                  label={t(
                    `DOCUMENT_MANAGEMENT.requestAdditional.title.deadline`
                  )}
                  placeholder={'dd/mm/yyyy'}
                  required
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={RequestAdditionalFieldNames.CONTENT}
                  label={t(
                    `DOCUMENT_MANAGEMENT.requestAdditional.title.${RequestAdditionalFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `DOCUMENT_MANAGEMENT.requestAdditional.placeHolder.${RequestAdditionalFieldNames.CONTENT}`
                  )}
                  minRows={5}
                  required
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={RequestAdditionalFieldNames.USERS}
                    label={t(
                      "DOCUMENT_MANAGEMENT.requestAdditional.title.responsiblePerson"
                    )}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };
                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"requestAdditional/queryUser"}
                    isFocus
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={RequestAdditionalFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit({
                    users:
                      form.getValues().users?.map((ele: BasedUser) => ele.id) ||
                      [],
                    deadline: form.getValues()?.deadline ?? "",
                    content: form.getValues()?.content ?? "",
                    status: +form.getValues()?.status,
                    remind: form.getValues().remind
                      ? castReminderSchemaToSaveReminderDTO(
                        form.getValues().remind
                      )
                      : undefined,
                  });
                } catch (error) { }
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
