import {
  createDocumentManagementComment,
  getDocumentManagementAttachment,
  getDocumentManagementExtensions,
  getDocumentManagementHistory,
  getDocumentManagementTabComment,
  getDocumentManagementTabForward,
  getDocumentManagementTabInformation,
} from "@/apis/service/document_management/DocumentManagement";
import { LoadingWrapper } from "@/components/commons/loading_indicator/LoadingWrapper";
import { TabNav } from "@/components/commons/tab-nav/TabNav";
import { COLOR_TYPE } from "@/constants/color";
import { AppContext } from "@/context/AppContext";
import { CommentPanel } from "@/features/metadata_tab_panel/comment_panel/CommentPanel";
import { InformationRequestPanel } from "@/features/metadata_tab_panel/information_request_panel/InformationRequestPanel";
import { BasedDocumentManagementBodyReceive } from "@/models/document_management/DocumentManagement";
import { FC, useContext } from "react";
import { useTranslation } from "react-i18next";
import { DocumentManagementHistoryPanel } from "./DocumentManagementHistoryPanel";
import { DocumentMngExtendPanel } from "./DocumentMngExtendPanel";
import { UploadPanel } from "@/components/commons/upload/upload_panel/UploadPanel";
import { uploadDocumentTabAttachments } from "@/apis/service/files_upload/files";
import { LegalAdviceForward } from "@/models/legal-advice/LegalAdviceList";
import { LegalAdviceFeedbackPanel } from "@/features/legal-advice/legal-advice-tabs/legal-advice-feedback-panel/LegalAdviceFeedbackPanel";
import { getUserLabel } from '@/utils';
import { LANGUAGES } from "@/locales/config-translation";

export interface DocumentManagementTabsProps {
  documentManagementId: number;
  documentManagement?: BasedDocumentManagementBodyReceive;
  loading?: boolean;
}
const DocumentManagementTab: FC<DocumentManagementTabsProps> = (props) => {
  const [t, i18n] = useTranslation();
  const isEnglish = i18n.language === LANGUAGES.ENGLISH;

  const appContext = useContext(AppContext);
  const { loading } = props;

  return (
    <LoadingWrapper loading={loading || appContext.loading}>
      <div style={{ backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8 }}>
        <TabNav
          tabItems={[
            // 1. Yêu cầu bổ sung thông tin
            {
              key: "information-request",
              label: t("metadata.informationRequest.title"),
              content: (
                <InformationRequestPanel
                  queryKey="document-management-information-request"
                  getInformationRequests={async () => {
                    return (
                      (
                        await getDocumentManagementTabInformation(
                          props.documentManagementId
                        )
                      )?.detailInformationRequestResponses ?? []
                    );
                  }}
                />
              ),
            },
            // 3. Chuyển tiếp
            {
              key: "forward",
              label: t("metadata.forward.title"),
              content: (
                // <ForwardPanel
                //   queryKey="document-mng-forward"
                //   getForwards={async () => {
                //     return (
                //       (
                //         await getDocumentManagementTabForward(
                //           props.documentManagementId
                //         )
                //       ).forwardResponseDetails ?? []
                //     );
                //   }}
                // />
                <LegalAdviceFeedbackPanel<LegalAdviceForward>
                  getData={async () => {
                    return (
                      (
                        await getDocumentManagementTabForward(
                          props.documentManagementId
                        )
                      )?.forwardResponseDetails ?? []
                    );
                  }}
                  getTitle={(item) =>
                    item?.receiveUsers
                      ?.map((user) => getUserLabel(user, isEnglish))
                      .join(", ")
                  }
                  getDisplayDate={(item) => item.forwardDate}
                  getSubtitle={(item) =>
                    `${t("legalAdvice.tabs.forwardedBy")}:  ${getUserLabel(
                      item.forwardUser,
                      isEnglish
                    )}`
                  }
                  contentHeader="legalAdvice.forwardLegalAdvice.title.content"
                  getContent={(item) => item.content}
                  queryKey="advice-forward"
                />
              ),
            },
            // 4. Gia hạn thời gian
            {
              key: "extend",
              label: t("metadata.extend.title"),
              content: (
                <DocumentMngExtendPanel
                  documentMngId={props.documentManagementId}
                  documentManagement={props.documentManagement}
                  getExtendRecords={async () => {
                    return (
                      (
                        await getDocumentManagementExtensions(
                          props.documentManagementId
                        )
                      )?.timeExtensionResponseDetails ?? []
                    );
                  }}
                  queryKey="legal-advice-extend-tab"
                />
              ),
            },

            // // 7. Bình luận
            {
              key: "comment",
              label: t("metadata.comment.title"),
              content: (
                <CommentPanel
                  queryKey="document-manage-comment"
                  getComments={async () => {
                    return (
                      (
                        await getDocumentManagementTabComment(
                          props.documentManagementId
                        )
                      ).result?.data ?? []
                    );
                  }}
                  addComment={(comment) =>
                    createDocumentManagementComment(
                      props.documentManagementId,
                      comment
                    )
                  }
                  disabled={
                    !appContext.meCanRead
                    // ||
                    // props.legalAdvice?.legalAdviceRoles?.length === 0
                  }
                />
              ),
            },
            // // 8. Đính kèm
            {
              key: "attachment",
              label: t("metadata.attachment.title"),
              content: (
                <UploadPanel
                  queryKey="legal-advice-upload"
                  onGetFiles={async () =>
                    (
                      (
                        await getDocumentManagementAttachment(
                          props.documentManagementId
                        )
                      )?.data || []
                    ).map((legalDocumentAttachment) => ({
                      fileId: legalDocumentAttachment.fileId,
                      fileName: legalDocumentAttachment.fileName,
                      storagePath: legalDocumentAttachment.filePath,
                      uploadDate: legalDocumentAttachment.uploadDate,
                    }))
                  }
                  onDelete={() => Promise.resolve()}
                  onUpload={async (files) => {
                    await uploadDocumentTabAttachments({
                      files: files,
                      id: props.documentManagementId,
                      reference_file_type: 6,
                    });
                  }}
                // disabled={
                //   !appContext.meCanRead ||
                //   props.legalAdvice?.legalAdviceRoles?.length === 0
                // }
                />
              ),
            },
            // // 9. Lịch sử
            {
              key: "history",
              label: t("metadata.history.title"),
              content: (
                <DocumentManagementHistoryPanel
                  queryKey="document-management-history"
                  getHistoryRecords={async () => {
                    return (
                      (
                        await getDocumentManagementHistory(
                          props.documentManagementId
                        )
                      ).result?.data ?? []
                    );
                  }}
                />
              ),
            },
          ]}
        />
      </div>
    </LoadingWrapper>
  );
};
export default DocumentManagementTab;
