import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { ModalCommon } from "@/components/commons/popups/modal/Modal";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import React, { useRef } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { yupResolver } from "@hookform/resolvers/yup";
import { formInputSxProps } from "@/constants/theme";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { toast } from "react-toastify";
import { BasedUser, GetUsersParams } from "@/models/user/User";
import { getUsers } from "@/apis/service/user/User";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { Module, ModuleKeys } from "@/constants/general";
import {
  castForwardDocumentManagementRequestSchemaToDTO,
  ForwardDocumentManagementFieldNames,
  ForwardDocumentManagementSchema,
  ForwardDocumentManagementSchemaI,
} from "@/models/document_management/ForwardDocumentManagement";
import { useCreateForwardDocumentManagement } from "@/apis/service/document_management/forwardDocumentManagement";

const initialEmptyValue: ForwardDocumentManagementSchemaI = {
  [ForwardDocumentManagementFieldNames.USERS_IDS]: [],
  [ForwardDocumentManagementFieldNames.DEADLINE]: "",
  [ForwardDocumentManagementFieldNames.CONTENT]: "",
  [ForwardDocumentManagementFieldNames.REMIND]: undefined,
};

export interface ForwardDocumentManagementTypeFormProps {
  titlePopup?: string;
  initialValue?: ForwardDocumentManagementSchemaI;
  documentId?: number;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
  name?: string;
  module?: number;
  senderDocumentManagement?: any;
}

export const ForwardDocumentManagementForm = (
  props: ForwardDocumentManagementTypeFormProps
) => {
  const {
    titlePopup = "DOCUMENT_MANAGEMENT.forwardLegalAdvice.title.titlePopup",
    initialValue = initialEmptyValue,
    documentId,
    isOpen = false,
    setIsOpen,
    name,
    module = Module.get(ModuleKeys.DOCUMENT_MANAGEMENT),
    senderDocumentManagement,
  } = props;

  const { t } = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  
  const form = useForm<any>({
    resolver: yupResolver(ForwardDocumentManagementSchema),
    defaultValues: initialValue,
  });

  const { mutateAsync: createForwardLegalAdvice, isPending } =
    useCreateForwardDocumentManagement({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t(titlePopup),
            })
          );
          onCloseForm(true);
        },
      },
    });

  const onCloseForm = (reload: boolean = false) => {
    setIsOpen(false, reload);
    form.reset({});
  };

  const onSubmit = async (data: any) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { departments, ...restData } = data;
    await createForwardLegalAdvice({
      documentId,
      data: restData,
    });
  };

  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={()=>onCloseForm()}>
      <Grid container className="form-wrapper" marginTop="20px">
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, paddingBottom: 0 }}
            >
              <Grid item width={"100%"}>
                <Typography fontWeight="bold">
                  {t("DOCUMENT_MANAGEMENT.forwardLegalAdvice.title.textName")}
                </Typography>
                <Typography>{name}</Typography>
              </Grid>
              <Grid item width={"100%"}>
                <label style={{padding:0}}>
                  {t(`legalAdvice.forwardLegalAdvice.title.sender`)}
                </label>
                {senderDocumentManagement && (
                  <Typography>
                    {senderDocumentManagement?.name} ({senderDocumentManagement?.email}) -{" "}
                    {senderDocumentManagement?.department?.name}
                  </Typography>
                )}
              </Grid>
              <Grid item width={"100%"}>
                <DateInput
                  name={ForwardDocumentManagementFieldNames.DEADLINE}
                  control={form.control}
                  label={t(
                    `DOCUMENT_MANAGEMENT.forwardLegalAdvice.title.deadline`
                  )}
                  minDate={new Date()}
                  placeholder={'dd/mm/yyyy'}
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextArea
                  control={form.control}
                  name={ForwardDocumentManagementFieldNames.CONTENT}
                  label={t(
                    `DOCUMENT_MANAGEMENT.forwardLegalAdvice.title.${ForwardDocumentManagementFieldNames.CONTENT}`
                  )}
                  placeHolder={t(
                    `DOCUMENT_MANAGEMENT.forwardLegalAdvice.placeHolder.${ForwardDocumentManagementFieldNames.CONTENT}`
                  )}
                  minRows={5}
                />
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                <Grid item xs={12}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={ForwardDocumentManagementFieldNames.USERS_IDS}
                    label={t(
                      "DOCUMENT_MANAGEMENT.forwardLegalAdvice.title.receiver"
                    )}
                    placeholder="Nhập tên nhân viên"
                    getOptions={async (keyword) => {
                      const params: GetUsersParams = {
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      };

                      const response = await getUsers(params);

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${
                        option?.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery={"forwardLegalAdvice/queryUser"}
                    isFocus
                  />
                </Grid>
              </Grid>
            </Grid>
            <ReminderPickerSubForm
              name={ForwardDocumentManagementFieldNames.REMIND}
              module={module}
            />
            <FormActionButtons
              formMode="create"
              textSave="common.button.send"
              loading={isPending}
              onCancel={onCloseForm}
              onSave={async () => {
                try {
                  onSubmit(
                    castForwardDocumentManagementRequestSchemaToDTO({
                      ...form.getValues(),
                    })
                  );
                } catch (error) {}
              }}
            />
          </form>
        </FormProvider>
      </Grid>
    </ModalCommon>
  );
};
