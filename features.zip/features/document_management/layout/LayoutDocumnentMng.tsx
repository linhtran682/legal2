import { COLOR_TYPE } from "@/constants/color";
// import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { Box, Grid } from "@mui/material";
import { ReactNode, useEffect, useState } from "react";
import StockManagement from "../stock_management/StockManagement";
import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import { useRouter } from "next/router";
import { DOCUMENT_MANAGEMENT_ROOT_PATH } from "@/constants/paths";
import { useQuery } from "@tanstack/react-query";
import { getDocumentMngStock } from "@/apis/service/document_management/DocumentManagement";
import { toast } from "react-toastify";
// import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
// import NavigateNextIcon from "@mui/icons-material/NavigateNext";
export interface LegalDocumentLayoutProps {
  children: ReactNode | ReactNode[];
  handleItemClick?: (id: any, isAllowCreateStock: boolean) => void;
  isShowAddICon?: boolean;
  handleItemClickDetail?: (id: any) => void;
}

export const LayoutDocumentMng = (props: LegalDocumentLayoutProps) => {
  // const [openPanel, setOpenPanel] = useState(true);
  const router = useRouter();
  const [idFolder, setIdFolder] = useState<number | undefined>(undefined);
  const [isAllowCreateStock, setIsAllowCreateStock] = useState(true);
  const handleGetIdFolder = (id: number) => {
    setIdFolder(id);
  };
  const getStockListQuery = useQuery({
    queryKey: ["getStockList"],
    queryFn: () => getDocumentMngStock({name: ''}),
  });
  useEffect(() => {
    getStockListQuery.refetch().catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (idFolder === undefined) {
      props.handleItemClick &&
        props.handleItemClick(getStockListQuery.data?.folders[0].id, true);
      setIdFolder(getStockListQuery.data?.folders[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idFolder, props.handleItemClick, getStockListQuery.data]);

  return (
    <Grid
      direction={"row"}
      wrap="nowrap"
      sx={{ display: "flex", overflow: "hidden", height: "100%" }}
    >
      <Grid
        item
        sx={{ overflow: "auto", height: "100%", position: "relative" }}
      >
        <Grid
          container
          direction={"column"}
          width={310}
          // width={openPanel ? 310 : undefined}
        >
          {/* <Grid
            item
            sx={{
              position: "sticky",
              top: 0,
              zIndex: 1000,
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA7,
            }}
          >
            <Grid
              container
              direction={"row"}
              wrap="nowrap"
              justifyContent={"end"}
            >
              {openPanel && <Grid item flex={1}></Grid>}
              <Grid item>
                <IconButton
                  onClick={() => setOpenPanel((prev) => !prev)}
                  sx={{
                    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                    marginRight: GLOBAL_SMALL_SPACING,
                    // height: 20,
                    // width: 20,
                  }}
                >
                  {!openPanel ? <NavigateNextIcon /> : <NavigateBeforeIcon />}
                </IconButton>
              </Grid>
            </Grid>
          </Grid> */}

            <Grid item width={310}>
              <Box
                sx={{
                  // marginTop: 2,
                  width: 300,
                  backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                }}
              >
                <StockManagement
                  listItem={
                    getStockListQuery.data?.folders
                      ? getStockListQuery.data?.folders
                      : []
                  }
                  defaultExpandedItems={["1"]}
                  defaultSelectedItems="1"
                  handleItemClick={(id: any, isAllowCreateStock: boolean) => {
                    setIsAllowCreateStock(isAllowCreateStock);
                    handleGetIdFolder(id);
                    props.handleItemClickDetail &&
                      props.handleItemClickDetail(id);
                    props.handleItemClick &&
                      props.handleItemClick(id, isAllowCreateStock);
                  }}
                />
                {!props.isShowAddICon && isAllowCreateStock && (
                  <StickyAddButton
                    ariaLabel="add_reminder_template"
                    onClick={() =>
                      router.push(
                        `/${DOCUMENT_MANAGEMENT_ROOT_PATH}/stock/${idFolder}`
                      )
                    }
                  />
                )}
              </Box>

              {/* <List sx={{ width: 400 }}>
               
              </List> */}
            </Grid>
        </Grid>
      </Grid>
      <Grid
        item
        flex={1}
        style={{
          maxWidth: "100%",
          transition: "max-width 0.2s ease",
          height: "calc(100vh - 200px)",
          overflow: "auto",
          position: "relative",
        }}
      >
        {props.children}
      </Grid>
    </Grid>
  );
};
