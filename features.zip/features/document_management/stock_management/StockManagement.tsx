import * as React from "react";
import clsx from "clsx";
import { animated, useSpring } from "@react-spring/web";
import { styled, alpha } from "@mui/material/styles";
import { TransitionProps } from "@mui/material/transitions";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import Typography from "@mui/material/Typography";
import { RichTreeView } from "@mui/x-tree-view/RichTreeView";
import { treeItemClasses } from "@mui/x-tree-view/TreeItem";
import {
  unstable_useTreeItem2 as useTreeItem2,
  UseTreeItem2Parameters,
} from "@mui/x-tree-view/useTreeItem2";
import {
  TreeItem2Checkbox,
  TreeItem2Content,
  TreeItem2IconContainer,
  TreeItem2Label,
  TreeItem2Root,
} from "@mui/x-tree-view/TreeItem2";
import { TreeItem2Icon } from "@mui/x-tree-view/TreeItem2Icon";
import { TreeItem2Provider } from "@mui/x-tree-view/TreeItem2Provider";
import { IconFolder } from "@/assets/iconMenu/IconFolder";
import { Folders } from "@/models/document_management/DocumentManagement";
import {
  IconButton,
  List,
  ListItem,
  ListItemText,
  Tooltip,
} from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { DOCUMENT_MANAGEMENT_ROOT_PATH } from "@/constants/paths";
import { useTranslation } from "react-i18next";
import { useRouter } from "next/router";

declare module "react" {
  interface CSSProperties {
    "--tree-view-color"?: string;
    "--tree-view-bg-color"?: string;
  }
}

const StyledTreeItemRoot = styled(TreeItem2Root)(({ theme }) => ({
  color: theme.palette.primary.dark,
  position: "relative",
  [`& .${treeItemClasses.groupTransition}`]: {
    marginLeft: 20,
  },
})) as unknown as typeof TreeItem2Root;

const CustomTreeItemContent = styled(TreeItem2Content)(({ theme }) => ({
  flexDirection: "row-reverse",
  borderRadius: 0,
  marginBottom: theme.spacing(0.5),
  marginTop: theme.spacing(0.5),
  // paddingRight: theme.spacing(1),
  fontWeight: 500,
  [`&.Mui-expanded `]: {
    "&:not(.Mui-focused, .Mui-selected, .Mui-selected.Mui-focused) .labelIcon":
      {
        color: theme.palette.primary.dark,
        
      },
    // "&::before": {
    //   content: '""',
    //   display: "block",
    //   position: "absolute",
    //   left: "16px",
    //   top: "44px",
    //   height: "calc(100% - 48px)",
    //   width: "1.5px",
    //   backgroundColor: theme.palette.primary.dark,
    //   ...theme.applyStyles("light", {
    //     backgroundColor: theme.palette.grey[300],
    //   }),
    // },
  },
  "&:hover": {
    backgroundColor: alpha(theme.palette.primary.main, 0.1),
    color: theme.palette.primary.main,
  },
  [`&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused`]: {
    // backgroundColor: theme.palette.primary.dark,
    color: theme.palette.primary.main,
    // ...theme.applyStyles("light", {
    //   backgroundColor: theme.palette.primary.main,
    // }),
  },
}));

const AnimatedCollapse = animated(Collapse);

function TransitionComponent(props: TransitionProps) {
  const style = useSpring({
    to: {
      opacity: props.in ? 1 : 0,
      transform: `translate3d(0,${props.in ? 0 : 20}px,0)`,
    },
  });

  return <AnimatedCollapse style={style} {...props} />;
}

interface CustomLabelProps {
  children: React.ReactNode;
  icon?: React.ElementType;
  level: number
}

function CustomLabel({ icon: Icon, children,level, ...other }: CustomLabelProps) {
  const levelCheck = +level*2 + 10 
  return (
    <TreeItem2Label
      {...other}
      sx={{
        display: "flex",
        alignItems: "center",
        paddingLeft: level && level === 1 ? '0px' : `${levelCheck}px`,
      }}
    >
      {Icon && (
        <Box
          component={Icon}
          className="labelIcon"
          color="inherit"
          sx={{
            mr: 1,
            fontSize: "1.2rem",
            flex: 1,
            minWidth: 50
          }}
        />
      )}

      <Typography
        sx={{
          flex: 2,
          paddingLeft: 1,
          fontSize: "14px",
          overflow: "hidden",
          whiteSpace: "nowrap",
          textOverflow: "ellipsis",
          wordBreak:'break-word'
        }}
        variant="subtitle1"
      >
        {children}
      </Typography>
      
    </TreeItem2Label>
  );
}

const isExpandable = (reactChildren: React.ReactNode) => {
  if (Array.isArray(reactChildren)) {
    return reactChildren.length > 0 && reactChildren.some(isExpandable);
  }
  return Boolean(reactChildren);
};
interface CustomTreeItemProps
  extends Omit<UseTreeItem2Parameters, "rootRef">,
    Omit<React.HTMLAttributes<HTMLLIElement>, "onFocus"> {
  onItemClick?: (id: string, isAllowCreateStock: boolean) => void;
  roles?: number[];
  isCopy?: boolean;
  level: number;
}

const CustomTreeItem = React.forwardRef(function CustomTreeItem(
  props: CustomTreeItemProps,
  ref: React.Ref<HTMLLIElement>
) {
  const [t] = useTranslation();
  const router = useRouter();

  const { id, itemId, label, roles, level, children, onItemClick, ...other } =
    props;

  const stringId = String(id);
  const stringItemId = String(itemId);
  const isDisabled = roles && roles.length > 0 && roles.includes(1) ? false : roles && roles.length > 0 && roles.includes(2) ? true : true;
  const {
    getRootProps,
    getContentProps,
    getIconContainerProps,
    getCheckboxProps,
    getLabelProps,
    getGroupTransitionProps,
    status,
  } = useTreeItem2({
    id: stringId,
    itemId: stringItemId,
    children,
    label,
    disabled: isDisabled,
    rootRef: ref,
  });

  const expandable = isExpandable(children);
  const icon = IconFolder;

  const handleClick = (event: any) => {
    event.stopPropagation(); // Prevent event bubbling
    event.preventDefault();
    if (onItemClick && !isDisabled) {
      !(props.isCopy && isDisabled) && onItemClick(itemId, true);
    } else {
      !(props.isCopy && isDisabled) && onItemClick && onItemClick(itemId, false);
    }
  };

  return (
    <TreeItem2Provider itemId={itemId}>
      <StyledTreeItemRoot
        {...getRootProps(other)}
        sx={{
          cursor: "not-allowed !important",
          pointerEvents: isDisabled && props.isCopy ? "none" : "",
        }}
        onClick={handleClick}
      >
        <CustomTreeItemContent
          {...getContentProps({
            className: clsx("content", {
              "Mui-expanded": status.expanded || !(isDisabled && props.isCopy),
              "Mui-selected": status.selected,
              "Mui-focused": status.focused,
              "Mui-disabled": true,
            }),
          })}
        >
          <div>
            {!props.isCopy && (
              <Tooltip
                title={
                  <List>
                    {!isDisabled && level < 5 && (
                      <ListItem
                        button
                        onClick={() => {
                          itemId && router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/stock/${itemId}`);
                        }}
                        sx={{
                          "&:hover": {
                            backgroundColor: "#FFE5E5", // Màu nền khi hover
                          },
                        }}
                      >
                        <ListItemText primary={t("common.button.create")} />
                      </ListItem>
                    )}

                    <ListItem
                      button
                      sx={{
                        "&:hover": {
                          backgroundColor: "#FFE5E5", // Màu nền khi hover
                        },
                      }}
                      onClick={() => {
                        router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/stock_update/${itemId}`);
                      }}
                    >
                      <ListItemText primary={t("DOCUMENT_MANAGEMENT.button.detailStock")} />
                    </ListItem>
                  </List>
                }
              >
                <IconButton
                  sx={{
                    marginRight: GLOBAL_SMALL_SPACING,
                    paddingLeft: 1,
                  }}
                >
                  <MoreVertIcon />
                </IconButton>
              </Tooltip>
            )}
          </div>

          <TreeItem2IconContainer {...getIconContainerProps()}>
            <TreeItem2Icon status={status} />
          </TreeItem2IconContainer>
          <TreeItem2Checkbox {...getCheckboxProps()} />

          <CustomLabel {...getLabelProps({ icon, expandable: expandable && status.expanded, level:level  })} />
        </CustomTreeItemContent>

        {children && <TransitionComponent {...getGroupTransitionProps()} />}
      </StyledTreeItemRoot>
    </TreeItem2Provider>
  );
});

interface StockManagementProps {
  handleItemClick?: (id: number, isAllowCreateStock: boolean) => void;
  defaultExpandedItems?: string[];
  defaultSelectedItems?: string;
  listItem: Folders[];
  isCopy?: boolean;
}
export default function StockManagement(props: StockManagementProps) {
  return (
    <RichTreeView
      items={props.listItem}
      defaultExpandedItems={props.defaultExpandedItems}
      defaultSelectedItems={props.defaultSelectedItems}
      getItemLabel={(item) => item.name ?? ""}
      sx={{
        height: "fit-content",
        flexGrow: 1,
        maxWidth: 400,
        overflowY: "auto",
      }}
      slots={{
        item: (e: any) => {
          const detailStock = findRolesById(props.listItem, e.itemId);
          return (
            <CustomTreeItem
              roles={detailStock && detailStock.roles}
              level={detailStock && detailStock.level}
              {...e}
              onItemClick={props.handleItemClick}
              isCopy={props.isCopy}
            />
          );
        },
      }}
    />
  );
}

export function findRolesById(
  items: Folders[],
  id: number
):
  | {
      roles: number[] | undefined;
      level: number | undefined;
    }
  | undefined {
  for (const item of items) {
    if (item.id === id) {
      return {
        roles: item.roles,
        level: item.level,
      }; // Return roles if found
    }

    // If the item has children, recurse into the children
    if (item.children && item.children.length > 0) {
      const roles = findRolesById(item.children, id);
      if (roles) {
        return roles; // Return roles if found in children
      }
    }
  }

  return undefined; // Return undefined if not found
}
