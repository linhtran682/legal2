import { getUser, getUsers } from "@/apis/service/user/User";
import { FormAsyncSelect } from "@/components/commons/form_inputs/FormAsyncSelect";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
// import { AppContext } from "@/context/AppContext";
import {
  BasedDocumentManagementFieldNames,
  CreateStockModel,
  DepartmentStockModelDetail,
  StockModelSchema,
  stockModelSchema,
} from "@/models/document_management/DocumentManagement";
import { BasedUser } from "@/models/user/User";
import {
  Box,
  FormControlLabel,
  Grid,
  IconButton,
  Typography,
} from "@mui/material";
import { useEffect, useRef, useState } from "react";
import { FormProvider, useFieldArray, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import AddIcon from "@mui/icons-material/Add";
import { getDepartments } from "@/apis/service/department/department";
import { Department } from "@/models/department/Department";
import { FormSelectSingleTreeView } from "@/components/commons/form_inputs/FormSelectSingleTree";
import { LANGUAGES } from "@/locales/config-translation";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { getDocumentSubStock } from "@/apis/service/document_management/DocumentManagement";
import { useQuery } from "@tanstack/react-query";
import { COLOR_TYPE } from "@/constants/color";
import DeleteIcon from "@mui/icons-material/Delete";
import renderUserOptions from "@/components/commons/user_option";
import CheckboxInput from "@/components/commons/inputs/checkbox/CheckboxInput";

const defaultEmptyValue: any = {
  parentId: undefined,
  folderName: "",
  departmentPermissions: [],
  userPermissions: [],
};
export interface StockCreateManagementProps {
  formMode?: "create" | "update";
  initialValue?: any;
  onSubmit: (data: CreateStockModel) => void;
  onCancel: () => void;
  loading?: boolean;
  initialValueReceive?: DepartmentStockModelDetail;
  folderId: number;
  onDelete?: () => void;
}
export const StockCreateManagement = (props: StockCreateManagementProps) => {
  // const appContext = useContext(AppContext);
  const [t, i18n] = useTranslation();
  const formRef = useRef<HTMLFormElement>(null);
  const [disableRole, setDisableRole] = useState(false);
  const form = useForm<any>({
    resolver: yupResolver(stockModelSchema),
    defaultValues: JSON.parse(JSON.stringify(defaultEmptyValue)),
    mode: "onBlur",
    disabled: disableRole,
  });
  const departmentFieldArray = useFieldArray({
    control: form.control,
    name: `departmentPermissions`,
  });
  const userFieldArray = useFieldArray({
    control: form.control,
    name: `userPermissions`,
  });
  const handleAddDepartment = () => {
    departmentFieldArray.append({
      departments: 
      {
       id: 'ALL',
       name: "Tất cả",
      },
      roles: [1],
    });
  };
  const handleAddUser = () => {
    userFieldArray.append({
      users: "ALL",
      isView: false,
      isEdit: false,
      roles: [1],
    });
  };
  const handleRemoveDepartment = (index: number) => {
    departmentFieldArray.remove(index);
  };
  const handleRemoveUser = (index: number) => {
    userFieldArray.remove(index);
  };
  useEffect(() => {
    if (props.initialValueReceive) {
      const { departmentRoles, name, parent, userRoles, roles } =
        props.initialValueReceive;
      if (roles && roles?.length > 0 && roles.includes(1)) {
        setDisableRole(false);
      } else if (roles && roles?.length > 0 && roles.includes(2)) {
        setDisableRole(true);
      } else {
        setDisableRole(true);
      }
      form.reset({
        departmentPermissions: departmentRoles.map((role) => ({
          departments: {
            id: role.id,
            name: role.name,
            nameEnglish: role.nameEnglish,
          },
          roles: role.roles,
          isView: role.roles?.includes(2) ? true : false,
          isEdit: role.roles?.includes(1) ? true : false,
        })),
        folderName: name,
        parentId: parent,
        userPermissions: userRoles.map((user) => ({
          roles: user.roles,
          users: user?.id,
          isView: user.roles?.includes(2) ? true : false,
          isEdit: user.roles?.includes(1) ? true : false,
        })),
      });
    }
  }, [props.initialValueReceive, form]);
  const getlStocksQuery = useQuery({
    queryKey: ["getlStocksQuery"],
    queryFn: () => getDocumentSubStock(props.folderId),
  });
  useEffect(() => {
    props.folderId && getlStocksQuery.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.folderId]);
  return (
    <FormProvider {...form}>
      <form ref={formRef}>
        <Grid
          container
          direction={"column"}
          rowGap={GLOBAL_SPACING}
          alignItems={"center"}
          className="form-section-wrapper"
          sx={formInputSxProps}
        >
          <Grid item width={"100%"}>
            <FormSelectSingleTreeView
              name={BasedDocumentManagementFieldNames.PARENT_ID}
              control={form.control}
              label={t(`DOCUMENT_MANAGEMENT.stock_create_form.parentStock`)}
              placeholder={t(
                `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.FOLDER_ID}`
              )}
              disabled={true}
              getOptions={async () => {
                try {
                  const response = await getDocumentSubStock(props.folderId);
                  form.setValue("parentId", response?.folders[0]);
                  return response?.folders ?? [];
                } catch (e) {
                  return [];
                }
              }}
              getOptionLabel={(option) => option.name ?? ""}
              getOptionKey={(option) => option.id ?? ""}
              getOptionChildren={(option) => option?.children}
              variant="outlined"
              debounceMs={FILTER_DEBOUNCE_MS}
              onChange={(value: any) => {
                form.setValue("parentId", (value ?? [])[0]);
              }}
              queryKey={"stockListQuery"}
              required
            />
          </Grid>
          <Grid item width={"100%"}>
            <FormTextField
              control={form.control}
              name={"folderName"}
              label={t(`DOCUMENT_MANAGEMENT.stock_create_form.stockName`)}
              placeHolder={t(`DOCUMENT_MANAGEMENT.stock_create_form.stockName`)}
              required
              disabled={disableRole}
            />
          </Grid>
          <Grid
            container
            direction={"column"}
            alignItems={"center"}
            className="form-sub-section-wrapper"
            rowGap={"1rem"}
          >
            <Grid item width={"100%"}>
              <Typography variant="subtitle1">
                {t("DOCUMENT_MANAGEMENT.title.auth")}
              </Typography>
            </Grid>
            <Grid item width={"100%"} marginBottom={"0px !important"}>
              <Typography
                style={{
                  lineHeight: "1.6rem",
                  fontWeight: 700,
                  color: "rgba(0, 0, 0, 0.6)",
                  marginBottom: 0,
                }}
              >
                {t(`DOCUMENT_MANAGEMENT.stock_create_form.department`)}
              </Typography>
            </Grid>

            <Grid item width={"100%"}>
              <Grid
                container
                // rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                {departmentFieldArray.fields.map((item, index) => (
                  <>
                    <Grid item xs={6}>
                      <FormSelectSingleTreeView
                        name={`departmentPermissions[${index}].departments`}
                        control={form.control}
                        label={""}
                        placeholder={t("common.place_holder.select_department")}
                        getOptions={async (keyword) => {
                          try {
                            const response = await getDepartments({
                              searchTerm: keyword,
                            });
                            const first100Departments: Department[] = (
                              response?.departments ?? []
                            ).slice(0, 150);
                            return [
                              {
                                id: "ALL",
                                code: "ALL",
                                name: "Tất cả",
                                nameEnglish: "ALL",
                                description: "",
                              },
                              ...first100Departments,
                            ];
                          } catch (e) {
                            return [];
                          }
                        }}
                        getOptionLabel={(option) => option.name ?? ""}
                        getOptionKey={(option) => option.id ?? ""}
                        getOptionChildren={(option) => option?.children}
                        variant="outlined"
                        debounceMs={FILTER_DEBOUNCE_MS}
                        onChange={(value: any) => {
                          form.setValue(
                            `departmentPermissions[${index}].departments`,
                            {
                              id: value[0].id,
                              name: value[0].name,
                              nameEnglish: value[0].nameEnglish,
                            }
                          );
                          if (value) {
                            form.trigger(
                              `departmentPermissions[${index}].departments`
                            );
                          }
                        }}
                        selectedItemsProp={
                          form.getValues(
                            `departmentPermissions[${index}].departments`
                          )
                            ? form.getValues(
                                `departmentPermissions[${index}].departments`
                              )
                            : undefined
                        }
                        queryKey={`department${index}`}
                        disabled={disableRole}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      display={"flex"}
                      justifyContent={"center"}
                      alignItems={"flex-end"}
                      marginTop={-3}
                      gap={3}
                    >
                      <Box display="flex" alignItems="center">
                        <FormControlLabel
                          label=""
                          name={`departmentPermissions[${index}].isView`}
                          control={
                            <CheckboxInput
                              disabled={disableRole}
                              borderColor={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA5
                                  : COLOR_TYPE.TOYOTA.TOYOTA1
                              }
                              checkboxBg={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA6
                                  : "white"
                              }
                              // sx={{
                              //   color: COLOR_TYPE.TOYOTA.TOYOTA1,
                              //   "&.Mui-checked": {
                              //     color: COLOR_TYPE.TOYOTA.TOYOTA1,
                              //   },
                              //   "&.Mui-disabled": {
                              //     color: "red",
                              //     borderColor: "red",
                              //   },
                              // }}
                              checked={form.watch(
                                `departmentPermissions[${index}].isView`
                              )}
                              onChange={(val) => {
                                form.setValue(
                                  `departmentPermissions[${index}].isView`,
                                  val
                                );
                              }}
                            />
                          }
                        />
                        <Typography color={"primary.main"} variant="body1">
                          {t(`DOCUMENT_MANAGEMENT.stock_create_form.view`)}
                        </Typography>
                      </Box>
                      <Box display="flex" alignItems="center">
                        <FormControlLabel
                          label=""
                          name={`departmentPermissions[${index}].isEdit`}
                          control={
                            <CheckboxInput
                              disabled={disableRole}
                              borderColor={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA5
                                  : COLOR_TYPE.TOYOTA.TOYOTA1
                              }
                              checkboxBg={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA6
                                  : "white"
                              }
                              checked={form.watch(
                                `departmentPermissions[${index}].isEdit`
                              )}
                              onChange={(val) => {
                                form.setValue(
                                  `departmentPermissions[${index}].isEdit`,
                                  val
                                );
                              }}
                            />
                          }
                        />
                        <Typography color={"primary.main"} variant="body1">
                          {t(`DOCUMENT_MANAGEMENT.stock_create_form.edit`)}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid
                      item
                      container
                      direction={"row"}
                      justifyContent={"end"}
                      alignContent={"end"}
                      xs={2}
                    >
                      <IconButton
                        color="primary"
                        onClick={() => handleRemoveDepartment(index)}
                        disabled={disableRole}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Grid>
                  </>
                ))}
                <Grid container direction={"row"} justifyContent={"end"}>
                  <IconButton
                    className="red-round"
                    onClick={handleAddDepartment}
                    disabled={disableRole}
                  >
                    <AddIcon />
                  </IconButton>
                </Grid>
              </Grid>
            </Grid>
            <Grid item width={"100%"} marginBottom={"0px !important"}>
              <Typography
                style={{
                  lineHeight: "1.6rem",
                  fontWeight: 700,
                  color: "rgba(0, 0, 0, 0.6)",
                }}
              >
                {t("DOCUMENT_MANAGEMENT.stock_create_form.user")}
              </Typography>
            </Grid>
            <Grid item width={"100%"}>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={formInputSxProps}
              >
                {userFieldArray.fields.map((item, index) => (
                  <>
                    <Grid item xs={6}>
                      <FormAsyncSelect
                        control={form.control}
                        name={
                          `userPermissions[${index}].users` as keyof StockModelSchema
                        }
                        keyQuery={`userPermissions[${index}]`}
                        placeholder={t(
                          "DOCUMENT_MANAGEMENT.stock_create_form.user"
                        )}
                        label={""}
                        getOptions={async (keyword) => {
                          if (typeof keyword === "string") {
                            const response = await getUsers({
                              searchTerm: keyword === "ALL" ? "" : keyword,
                              page: 0,
                              size: 100,
                              sortBy: "name",
                              sortOrder: "ASC",
                            });
                            const valueShow = (response?.users ?? []).map(
                              (user) =>
                                ({
                                  id: user.id,
                                  name: user.name ?? "",
                                  departmentName: user.department?.name,
                                  email: user.email,
                                } as BasedUser)
                            );

                            return [
                              {
                                id: "ALL",
                                name: "Tất cả",
                                departmentName: "",
                                email: "",
                              },
                              ...valueShow,
                            ];
                          } else if (
                            keyword?.length &&
                            keyword.length > 0 &&
                            !keyword.includes("ALL")
                          ) {
                            return getUser(keyword[0])
                              .then((response) =>
                                response
                                  ? [
                                      {
                                        id: response.id,
                                        name: response.name ?? "",
                                        nameEnglish: response.nameEnglish,
                                        departmentName:
                                          response.department?.name,
                                        email: response.email,
                                      } as BasedUser,
                                    ]
                                  : []
                              )
                              .catch(() => []);
                          } else if (
                            keyword?.length &&
                            keyword.length > 0 &&
                            keyword.includes("ALL")
                          ) {
                            return [
                              {
                                id: "ALL",
                                name: "Tất cả",
                                departmentName: "",
                                email: "",
                              },
                            ];
                          }

                          return [];
                        }}
                        getOptionKey={(option) => option.id}
                        getOptionLabel={(option) =>
                          `${
                            i18n.language === LANGUAGES.VIETNAMESE
                              ? option.name ?? ""
                              : option.nameEnglish ?? ""
                          }${option.email ? "(" + option.email + ") -" : ""}  ${
                            option.departmentName ?? ""
                          }`
                        }
                        renderOption={(optionProps, option, selected) =>
                          renderUserOptions(
                            optionProps,
                            option,
                            selected,
                            i18n.language === LANGUAGES.ENGLISH,
                            false
                          )
                        }
                        disabled={disableRole}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      display={"flex"}
                      justifyContent={"center"}
                      alignItems={"flex-end"}
                      marginTop={-3}
                      gap={3}
                    >
                      <Box display="flex" alignItems="center">
                        <FormControlLabel
                          label=""
                          name={`userPermissions[${index}].isView`}
                          control={
                            <CheckboxInput
                              disabled={disableRole}
                              borderColor={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA5
                                  : COLOR_TYPE.TOYOTA.TOYOTA1
                              }
                              checkboxBg={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA6
                                  : "white"
                              }
                              checked={form.watch(
                                `userPermissions[${index}].isView`
                              )}
                              onChange={(val) => {
                                form.setValue(
                                  `userPermissions[${index}].isView`,
                                  val
                                );
                              }}
                            />
                          }
                          //  disabled={!appContext.meCanWrite || isDisable}
                        />
                        <Typography color={"primary.main"} variant="body1">
                          {t(`DOCUMENT_MANAGEMENT.stock_create_form.view`)}
                        </Typography>
                      </Box>
                      <Box display="flex" alignItems="center">
                        <FormControlLabel
                          label=""
                          name={`userPermissions[${index}].isEdit`}
                          control={
                            <CheckboxInput
                              disabled={disableRole}
                              borderColor={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA5
                                  : COLOR_TYPE.TOYOTA.TOYOTA1
                              }
                              checkboxBg={
                                disableRole
                                  ? COLOR_TYPE.TOYOTA.TOYOTA6
                                  : "white"
                              }
                              checked={form.watch(
                                `userPermissions[${index}].isEdit`
                              )}
                              onChange={(val) => {
                                form.setValue(
                                  `userPermissions[${index}].isEdit`,
                                  val
                                );
                              }}
                            />
                          }
                          //  disabled={!appContext.meCanWrite || isDisable}
                        />
                        <Typography color={"primary.main"} variant="body1">
                          {t(`DOCUMENT_MANAGEMENT.stock_create_form.edit`)}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid
                      item
                      container
                      direction={"row"}
                      justifyContent={"end"}
                      alignContent={"end"}
                      xs={2}
                    >
                      <IconButton
                        color="primary"
                        onClick={() => handleRemoveUser(index)}
                        disabled={disableRole}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Grid>
                  </>
                ))}
                <Grid container direction={"row"} justifyContent={"end"}>
                  <IconButton
                    className="red-round"
                    onClick={handleAddUser}
                    disabled={disableRole}
                  >
                    <AddIcon />
                  </IconButton>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <FormActionButtons
          isDisableButonSave={disableRole}
          formMode={props.formMode}
          loading={props.loading}
          onCancel={props.onCancel}
          onDelete={props.onDelete}
          allowDraft={props.formMode === "create" ? true : false}
          onSaveDraft={async () => {}}
          onSave={async () => {
            props.onSubmit({
              folderName: form.getValues("folderName"),
              parentId: +form.getValues("parentId").id
                ? +form.getValues("parentId").id
                : 1,
              userPermissions: form
                .getValues("userPermissions")
                .map((ele: any) => {
                  const roleList = [];
                  if (ele.isView) {
                    roleList.push(2);
                  }
                  if (ele.isEdit) {
                    roleList.push(1);
                  }

                  return {
                    userId: ele?.users,
                    roles: roleList,
                  };
                }),
              departmentPermissions: form
                .getValues("departmentPermissions")
                .map((ele: any) => {
                  const roleList = [];
                  if (ele.isView) {
                    roleList.push(2);
                  }
                  if (ele.isEdit) {
                    roleList.push(1);
                  }
                  return {
                    departmentId: ele.departments.id,
                    roles: roleList,
                  };
                }),
            });
          }}
        />
      </form>
    </FormProvider>
  );
};
