import { getDepartments } from "@/apis/service/department/department";
import { getDocumentSubStock } from "@/apis/service/document_management/DocumentManagement";
import { GetListIdFile } from "@/apis/service/files_upload/files";
import { getStatus, getStatusList } from "@/apis/service/status/Status";
import { getUsers } from "@/apis/service/user/User";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { FormMultipleSelect } from "@/components/commons/form_inputs/FormMultipleSelect";
import { FormRadio } from "@/components/commons/form_inputs/FormRadio";
import { FormSelectButton } from "@/components/commons/form_inputs/FormSelectButton";
import { FormSelectSingleTreeView } from "@/components/commons/form_inputs/FormSelectSingleTree";
import { FormSelectTreeView } from "@/components/commons/form_inputs/FormSelectTreeView";
import { FormTextArea } from "@/components/commons/form_inputs/FormTextArea";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import DateInput from "@/components/commons/inputs/date_input/DateInput";
import DropPreviewFileUploadComponent from "@/components/commons/upload/drop_preview_file_upload/DropPreviewFileUpload";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { GLOBAL_SPACING } from "@/constants/format";
import { ModuleFields } from "@/constants/general";
import { formInputSxProps } from "@/constants/theme";
import { AppContext } from "@/context/AppContext";
import { ReminderPickerSubForm } from "@/features/reminder_template/reminder_picker/ReminderPickerSubForm";
import {
  castDepartmentToSchema,
  Department,
} from "@/models/department/Department";
import {
  BasedDocumentManagementBodyReceive,
  BasedDocumentManagementBodySend,
  BasedDocumentManagementFieldNames,
  // BasedDocumentManagementSchemaI,
  documentManagementSchema,
} from "@/models/document_management/DocumentManagement";
import { FileInfo } from "@/models/law_document/LawDocument";
import {
  castReminderInputToReminderSchema,
  castReminderSchemaToSaveReminderDTO,
} from "@/models/reminder_template/ReminderDTO";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { BasedUser } from "@/models/user/User";
import { yupResolver } from "@hookform/resolvers/yup";
import { Grid } from "@mui/material";
import React, { useContext, useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

const defaultEmptyValue: any = {
  companyScope: true,
};

export interface SaveDocumentManagementFormProps {
  formMode?: "create" | "update";
  initialValue?: any;
  onSubmit: (data: BasedDocumentManagementBodySend) => void;
  onCancel: () => void;
  loading?: boolean;
  initialValueReceive?: BasedDocumentManagementBodyReceive;
  folderId: number;
  onDelete?: () => void;
}
export const DocumentManagementForm = (
  props: SaveDocumentManagementFormProps
) => {
  const [t] = useTranslation();
  const [files, setFiles] = useState<any>([]);
  const formRef = useRef<HTMLFormElement>(null);
  const appContext = useContext(AppContext);
  const [disableRole, setDisableRole] = useState(false);

  const form = useForm<any>({
    resolver: yupResolver(documentManagementSchema),
    defaultValues: JSON.parse(JSON.stringify(defaultEmptyValue)),
    mode: "onBlur",
    disabled: disableRole,
  });
  useEffect(() => {
    if (props?.initialValue) {
      form.reset({
        ...props?.initialValue,
      });
    }
  }, [props?.initialValue]);

  useEffect(() => {
    if (props.initialValueReceive) {
      const { roles } = props.initialValueReceive;
      if (roles && roles?.length > 0) {
        setDisableRole(false);
      } else {
        setDisableRole(true);
      }
      if (props?.initialValueReceive?.attachments) {
        let attachments: any[] = [];
        const attachmentsSharepoint: any[] = [];

        if (props?.initialValueReceive?.attachments.length) {
          attachments = props.initialValueReceive.attachments?.map((item) => {
            return {
              name: item.fileName,
              path: item.filePath,
              id: item.fileId,
              uploadDate: item.uploadDate,
            };
          });
        }
        setFiles([...attachments, ...attachmentsSharepoint]);
      }
      const files =
        !appContext.meCanWrite || disableRole
          ? props.initialValueReceive?.attachments
          : props.initialValueReceive?.attachments?.length
            ? props.initialValueReceive?.attachments
            : null;

      props.initialValueReceive &&
        form.reset({
          managementDepartments:
            props.initialValueReceive.managementDepartments,
          relatedDepartments: props.initialValueReceive.relatedDepartments,
          attachments: props?.initialValueReceive?.attachments?.map(
            (ele: any) => ele?.fileId
          ),
          agencyIssued: props.initialValueReceive.agencyIssued,
          documentType: props.initialValueReceive.documentType,
          name: props.initialValueReceive.name,
          status: props.initialValueReceive?.status,
          companyScope:
            props.initialValueReceive.companyScope == true ? "true" : "false",
          departmentScope:
            props.initialValueReceive.companyScope == false ? "false" : "true",
          dateIssued: props.initialValueReceive.dateIssued,
          documentChangeDate: props.initialValueReceive.documentChangeDate,
          expiryDate: props.initialValueReceive.expiryDate,
          folderId: props.initialValueReceive.folder,
          noteDateIssued: props.initialValueReceive.noteDateIssued,
          noteDocumentChangeDate:
            props.initialValueReceive.noteDocumentChangeDate,
          receivers: props.initialValueReceive.receivers,
          noteExpiryDate: props.initialValueReceive.noteExpiryDate,
          noteUpdateTime: props.initialValueReceive.noteUpdateTime,
          remind: props.initialValueReceive.remind
            ? castReminderInputToReminderSchema(
              props.initialValueReceive.remind!
            )
            : undefined,
          files,
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValueReceive]);
  useEffect(() => {
    if (
      form.formState.touchedFields.dateIssued ||
      form.formState.touchedFields.noteDateIssued
    ) {
      form.trigger(["dateIssued", "noteDateIssued"]);
    }
    if (
      form.formState.touchedFields.expiryDate ||
      form.formState.touchedFields.noteExpiryDate
    ) {
      form.trigger(["expiryDate", "noteExpiryDate"]);
    }
    if (form.formState.touchedFields.managementDepartments) {
      form.trigger(["managementDepartments"]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    form.formState.touchedFields.dateIssued,
    form.formState.touchedFields.noteDateIssued,
    form.formState.touchedFields.expiryDate,
    form.formState.touchedFields.noteExpiryDate,
    form.formState.touchedFields.managementDepartments,
    form.trigger,
  ]);

  return (
    <>
      <FormProvider {...form}>
        <form ref={formRef}>
          <Grid container className="form-wrapper" spacing={GLOBAL_SPACING}>
            <Grid item>
              <Grid
                container
                direction={"column"}
                rowGap={GLOBAL_SPACING}
                alignItems={"center"}
                className="form-section-wrapper"
                sx={formInputSxProps}
              >
                <Grid item width={"100%"}>
                  <FormSelectSingleTreeView
                    name={BasedDocumentManagementFieldNames.FOLDER_ID}
                    control={form.control}
                    label={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.FOLDER_ID}`
                    )}
                    placeholder={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.FOLDER_ID}`
                    )}
                    getOptions={async () => {
                      try {
                        const response = await getDocumentSubStock(
                          props.folderId
                        );
                        if (response?.folders[0]) {
                          form.setValue("folderId", {
                            id: response?.folders[0].id.toString(),
                            name: response?.folders[0].name,
                          });
                        }
                        return response?.folders ?? [];
                      } catch (e) {
                        return [];
                      }
                    }}
                    getOptionLabel={(option) => option.name ?? ""}
                    getOptionKey={(option) => option.id ?? ""}
                    getOptionChildren={(option) => option?.children}
                    variant="outlined"
                    debounceMs={FILTER_DEBOUNCE_MS}
                    onChange={(value: any) => {
                      form.setValue("folderId", (value ?? [])[0]);
                    }}
                    disabled={true}
                    // selectedItemsProp={
                    //   getStockListQuery.data?.folders
                    //     ? getStockListQuery.data.folders
                    //     : undefined
                    // }
                    required
                    queryKey={"stockListQuery"}
                  />
                </Grid>
                <Grid item width={"100%"}>
                  <FormTextField
                    control={form.control}
                    name={BasedDocumentManagementFieldNames.DOCUMENT_TYPE}
                    label={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.DOCUMENT_TYPE}`
                    )}
                    placeHolder={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.DOCUMENT_TYPE}`
                    )}
                    required
                    disabled={!appContext.meCanWrite || disableRole}
                  />
                </Grid>
                {!appContext.meCanWrite || disableRole ? null : <Grid item width={"100%"}>
                  <FormTextArea
                    control={form.control}
                    name={BasedDocumentManagementFieldNames.NAME}
                    label={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.NAME}`
                    )}
                    placeHolder={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.NAME}`
                    )}
                    minRows={3}
                    disabled={!appContext.meCanWrite || disableRole}
                    required
                  />
                </Grid>}
                <Grid item width={"100%"}>
                  <FormSelectButton
                    control={form.control}
                    name={BasedDocumentManagementFieldNames.STATUS}
                    label={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.STATUS}`
                    )}
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    keyQuery={"status-query"}
                    getOptions={async (keyword) => {
                      if (typeof keyword == "string") {
                        const response = await getStatusList({
                          name: keyword,
                          modules: [ModuleFields.DOCUMENT_MANAGEMENT.module],
                          page: 0,
                          size: 100,
                          sortBy: StatusFieldNames.NAME,
                          orderBy: "ASC",
                          active: 1,
                        });

                        return response?.statusResponses || [];
                      } else {
                        if (keyword?.length && keyword.length > 0) {
                          return getStatus(Number(keyword[0])).then((value) =>
                            value ? [value] : []
                          );
                        }
                      }

                      return [] as StatusDTO[];
                    }}
                    getOptionKey={(option) => option.id.toString()}
                    getOptionLabel={(option) => option.name}
                    required
                    disabled={!appContext.meCanWrite || disableRole}
                  />
                </Grid>
                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                  sx={formInputSxProps}
                >
                  <Grid item xs={6}>
                    <FormTextField
                      control={form.control}
                      name={BasedDocumentManagementFieldNames.AGENCY_ISSUED}
                      label={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.AGENCY_ISSUED}`
                      )}
                      placeHolder={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.AGENCY_ISSUED}`
                      )}
                      required
                      disabled={!appContext.meCanWrite || disableRole}
                    />
                  </Grid>

                  <Grid item xs={6}>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <FormTextField
                          control={form.control}
                          name={
                            BasedDocumentManagementFieldNames.NOTE_DATE_ISSUED
                          }
                          label={t(
                            `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.DATE_ISSUED}`
                          )}
                          placeHolder={" "}
                          required
                          disabled={!appContext.meCanWrite || disableRole}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <DateInput
                          name={BasedDocumentManagementFieldNames.DATE_ISSUED}
                          control={form.control}
                          label={""}
                          placeholder={t(`dd/mm/yyyy`)}
                          disabled={!appContext.meCanWrite || disableRole}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                  sx={formInputSxProps}
                >
                  <Grid item xs={6}>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <FormTextField
                          control={form.control}
                          name={
                            BasedDocumentManagementFieldNames.NOTE_DOCUMENT_CHANGE_DATE
                          }
                          label={t(
                            `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.DOCUMENT_CHANGE_DATE}`
                          )}
                          placeHolder={" "}
                          // required
                          disabled={!appContext.meCanWrite || disableRole}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <DateInput
                          name={
                            BasedDocumentManagementFieldNames.DOCUMENT_CHANGE_DATE
                          }
                          control={form.control}
                          label={""}
                          placeholder={t(`dd/mm/yyyy`)}
                          disabled={!appContext.meCanWrite || disableRole}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item xs={6}>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <FormTextField
                          control={form.control}
                          name={
                            BasedDocumentManagementFieldNames.NOTE_EXPIRY_DATE
                          }
                          label={t(
                            `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.EXPIRY_DATE}`
                          )}
                          placeHolder={" "}
                          required
                          disabled={!appContext.meCanWrite || disableRole}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <DateInput
                          name={BasedDocumentManagementFieldNames.EXPIRY_DATE}
                          control={form.control}
                          label={""}
                          placeholder={t(`dd/mm/yyyy`)}
                          // required
                          disabled={!appContext.meCanWrite || disableRole}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                  sx={formInputSxProps}
                >
                  <Grid item xs={6}>
                    <FormTextField
                      control={form.control}
                      name={BasedDocumentManagementFieldNames.NOTE_UPDATE_TIME}
                      label={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.NOTE_UPDATE_TIME}`
                      )}
                      placeHolder={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.NOTE_UPDATE_TIME}`
                      )}
                      // required
                      disabled={!appContext.meCanWrite || disableRole}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <Grid
                      container
                      columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                      sx={{
                        ...formInputSxProps,
                        display: "flex",
                        justifyContent: "center",
                        alignContent: "center",
                        height: "100%",
                        width: "100%",
                        // paddingLeft: "30%",
                      }}
                    >
                      <FormRadio
                        name={BasedDocumentManagementFieldNames.COMPANY_SCOPE}
                        control={form.control}
                        label={""}
                        disabled={!appContext.meCanWrite || disableRole}
                        radioOptions={[
                          {
                            options: [
                              {
                                value: true,
                                label: t(
                                  "DOCUMENT_MANAGEMENT.field_name.companyScope"
                                ),
                              },
                            ],
                          },
                          {
                            options: [
                              {
                                value: false,
                                label: t(
                                  "DOCUMENT_MANAGEMENT.field_name.departmentScope"
                                ),
                              },
                            ],
                          },
                        ]}
                        rules={{
                          required: t("This field is required"),
                        }}
                      />
                    </Grid>
                  </Grid>
                </Grid>
                <Grid
                  item
                  width={"100%"}
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                  sx={formInputSxProps}
                >
                  <Grid item xs={6}>
                    <FormSelectTreeView
                      name={
                        BasedDocumentManagementFieldNames.MANAGEMENT_DEPARTMENTS
                      }
                      control={form.control}
                      label={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.MANAGEMENT_DEPARTMENTS}`
                      )}
                      placeholder={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.MANAGEMENT_DEPARTMENTS}`
                      )}
                      getOptions={async (keyword) => {
                        try {
                          const response = await getDepartments({
                            searchTerm: keyword,
                          });
                          const first100Departments: Department[] = (
                            response?.departments ?? []
                          ).slice(0, 150);
                          return first100Departments;
                        } catch (e) {
                          return [];
                        }
                      }}
                      getOptionLabel={(option) => option.name ?? ""}
                      getOptionKey={(option) => option.id ?? ""}
                      getOptionChildren={(option: any) => option?.children}
                      variant="outlined"
                      debounceMs={FILTER_DEBOUNCE_MS}
                      onChange={(value: Department[]) => {
                        form.setValue(
                          "managementDepartments",
                          (value ?? []).map((department) =>
                            castDepartmentToSchema(department)
                          )
                        );
                      }}
                      rules={{ required: "This field is required" }}
                      selectedItemsProp={
                        props.initialValueReceive
                          ? props.initialValueReceive?.managementDepartments
                          : undefined
                      }
                      required
                      queryKeyCheck="queryManagementDepartments"
                      disabled={!appContext.meCanWrite || disableRole}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <FormSelectTreeView
                      name={
                        BasedDocumentManagementFieldNames.RELATED_DEPARTMENTS
                      }
                      control={form.control}
                      label={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.RELATED_DEPARTMENTS}`
                      )}
                      placeholder={t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.RELATED_DEPARTMENTS}`
                      )}
                      getOptions={async (keyword) => {
                        try {
                          const response = await getDepartments({
                            searchTerm: keyword,
                          });
                          const first100Departments: Department[] = (
                            response?.departments ?? []
                          ).slice(0, 150);
                          return first100Departments;
                        } catch (e) {
                          return [];
                        }
                      }}
                      getOptionLabel={(option) => option.name ?? ""}
                      getOptionKey={(option) => option.id ?? ""}
                      getOptionChildren={(option: any) => option?.children}
                      variant="outlined"
                      debounceMs={FILTER_DEBOUNCE_MS}
                      onChange={(value: Department[]) => {
                        form.setValue(
                          "relatedDepartments",
                          (value ?? []).map((department) =>
                            castDepartmentToSchema(department)
                          )
                        );
                      }}
                      rules={{ required: "This field is required" }}
                      selectedItemsProp={
                        props.initialValueReceive
                          ? props.initialValueReceive?.relatedDepartments
                          : undefined
                      }
                      // required
                      queryKeyCheck="relatedDepartments"
                      disabled={!appContext.meCanWrite || disableRole}
                    />
                  </Grid>
                </Grid>
                <Grid item width={"100%"}>
                  <FormMultipleSelect<any, BasedUser>
                    control={form.control}
                    name={`${BasedDocumentManagementFieldNames.RECEIVERS}`}
                    label={t(
                      `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.RECEIVERS}`
                    )}
                    placeholder={t(`common.place_holder.enter_value`, {
                      fieldName: t(
                        `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.RECEIVERS}`
                      ),
                    })}
                    required
                    getOptions={async (keyword) => {
                      const response = await getUsers({
                        searchTerm: keyword,
                        page: 0,
                        size: 100,
                        sortBy: "name",
                        sortOrder: "ASC",
                      });

                      return (response?.users ?? []).map((user) => ({
                        id: user.id,
                        name: user.name ?? "",
                        departmentName: user.department?.name,
                        email: user.email,
                      }));
                    }}
                    getOptionLabel={(option) =>
                      `${option.name ?? ""} (${option.email ?? ""}) - ${option.departmentName ?? ""
                      }`
                    }
                    getOptionKey={(option) => option.id}
                    keyQuery="queryUser"
                    disabled={!appContext.meCanWrite || disableRole}
                    isFocus
                  />
                </Grid>
                <Grid item width={"100%"}>
                  <DropPreviewFileUploadComponent
                    dropView={props?.formMode === "create"}
                    preview={props?.formMode === "update"}
                    control={form.control}
                    name={BasedDocumentManagementFieldNames.FILES}
                    title={t("common.button.files")}
                    disabled={!appContext.meCanWrite || disableRole}
                    files={files}
                    setFiles={setFiles}
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <ReminderPickerSubForm
            name={BasedDocumentManagementFieldNames.REMIND}
            module={ModuleFields.DOCUMENT_MANAGEMENT.module}
            placeholder={t(`menu.reminder`)}
          />
          <FormActionButtons
            formMode={props.formMode}
            loading={props.loading}
            isDisableButonSave={!appContext.meCanWrite || disableRole}
            onCancel={props.onCancel}
            allowDraft={false}
            onSaveDraft={async () => { }}
            onDelete={props.onDelete}
            onSave={async () => {
              try {
                let attachments: number[] = [];
                if (files.length > 0) {
                  const filterFile: any = [];
                  const filterFileId: number[] = [];

                  files.filter((item: any) => {
                    if (item?.id === undefined) {
                      filterFile.push(item);
                    } else {
                      filterFileId.push(item?.id);
                    }
                  });
                  if (filterFile.length > 0) {
                    const response = await GetListIdFile(filterFile);
                    const formatResponse: number[] =
                      response.fileUploadResponses.map(
                        (item: FileInfo) => item.fileId
                      );
                    attachments = [...formatResponse, ...filterFileId];
                  } else {
                    attachments = [...filterFileId];
                  }
                }
                props.onSubmit({
                  ...form.getValues(),
                  attachments: attachments,
                  receivers: form
                    .getValues("receivers")
                    .map((ite: any) => ite.id),
                  folderId: +form.getValues("folderId").id,
                  relatedDepartments:
                    form.getValues("relatedDepartments") &&
                      form.getValues("relatedDepartments").length > 0
                      ? form
                        .getValues("relatedDepartments")
                        .map((el: any) => el.id)
                      : undefined,
                  managementDepartments: form
                    .getValues("managementDepartments")
                    .map((el: any) => el.id),
                  companyScope:
                    form.getValues("companyScope") === "true" ||
                      form.getValues("companyScope") === true
                      ? true
                      : false,
                  departmentScope:
                    form.getValues("companyScope") === "false" ||
                      form.getValues("companyScope") === false
                      ? true
                      : false,
                  remind:
                    form.getValues("remind") !== undefined
                      ? castReminderSchemaToSaveReminderDTO(
                        form.getValues("remind")!
                      )
                      : undefined,
                });
              } catch (error) { }
            }}
          />
        </form>
      </FormProvider>
    </>
  );
};
