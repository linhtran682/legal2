import { getLegalDocumentStatisticChartFn } from "@/apis/service/law_document/law_document";
import { PieChartCommon } from "@/components/commons/chart/PieChartCommon";
// import { COLOR_TYPE } from '@/constants/color'
import { Button, Stack } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useMemo } from "react";
import { useTranslation } from "react-i18next";

const LegalDocumentOverview = () => {
  const router = useRouter();
  const { t } = useTranslation();
  const getStatisticChartQuery = useQuery({
    queryKey: ["statistics-legal-doc/statistic/chart"],
    queryFn: getLegalDocumentStatisticChartFn,
  });

  const pieChartData = useMemo(() => {
    const data = getStatisticChartQuery?.data?.pieChart?.data ?? [];
    const total = data?.reduce((sum, item) => sum + item.value, 0);
    // Convert values to percentages
    const dataWithPercentages = data.map((item) => ({
      ...item,
      fill:
        item.name === "Hoàn thành"
          ? "#3B00ED"
          : item.name === "Chưa hoàn thành"
          ? "#D81B60"
          : item.name === "Kiểm tra lại"
          ? "#FF9800"
          : "rgba(215, 215, 215, 1)",
      value: total > 0 ? Number(((item.value / total) * 100).toFixed(2)) : 0, // Rounded to 2 decimal places
    }));
    return dataWithPercentages;
  }, [getStatisticChartQuery?.data?.pieChart]);

  // const barChartData = useMemo(() => {
  //   return getStatisticChartQuery?.data?.barChart?.data ?? []
  // }, [getStatisticChartQuery?.data?.barChart]);

  return (
    <Stack height={"100%"}>
      <Stack
        bgcolor={"white"}
        flexShrink={1}
        overflow={"auto"}
        p={3}
        direction={"column"}
        alignItems={"center"}
      >
        <PieChartCommon width={450} height={180} data={pieChartData} />
        {/* <BarChartCommon
          data={barChartData}
        /> */}
      </Stack>
      <Stack direction={"row"} gap={2} mt={2} flexWrap={"wrap"}>
        <Button
          onClick={() => router.push("/statistics-legal-doc/report")}
          variant="contained"
          className="confirm"
        >
          {t("menu.statisticLegalDocumentReport")}
        </Button>
        <Button
          onClick={() =>
            router.push("/statistics-legal-doc/report-slow-evaluate")
          }
          variant="contained"
          className="confirm"
        >
          {t("menu.statisticLegalDocumentReportSlowEvaluate")}
        </Button>
        <Button
          onClick={() =>
            router.push("/statistics-legal-doc/report-no-evaluate")
          }
          variant="contained"
          className="confirm"
        >
          {t("menu.statisticLegalDocumentReportNoEvaluate")}
        </Button>
        <Button
          onClick={() => router.push("/statistics-legal-doc/report-done")}
          variant="contained"
          className="confirm"
        >
          {t("menu.statisticLegalDocumentReportDone")}
        </Button>
        <Button
          onClick={() => router.push("/statistics-legal-doc/report-following")}
          variant="contained"
          className="confirm"
        >
          {t("menu.statisticLegalDocumentReportFollowing")}
        </Button>
        <Button
          onClick={() => router.push("/statistics-legal-doc/report-effective")}
          variant="contained"
          className="confirm"
        >
          {t("menu.statisticLegalDocumentReportEffective")}
        </Button>
      </Stack>
    </Stack>
  );
};

export default LegalDocumentOverview;
