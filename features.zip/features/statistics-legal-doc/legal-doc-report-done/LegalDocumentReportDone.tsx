import { getLegalDocumentStatisticDoneFn } from "@/apis/service/law_document/law_document";
import HierarchyToolTip from "@/components/commons/hierarchy-tooltip/HierarchyTooltip";
import { MultipleFilterTableColumn } from "@/components/commons/tables/multiple_filter_table/MultipleFilterTable";
import StandardTable, {
  DEFAULT_PAGE_MODAL,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { LEGAL_DOCUMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import ReportFilterPanel from "@/features/legal-document/report_filter_panel/ReportFilterPanel";
import {
  BasedLegalDocumentFieldNames,
} from "@/models/law_document/BasedLegalDocument";
import { castTableStateToParams, getFieldLabelLegalDoc, IReportFilters, legalDocumentSearchPanelConfig } from "@/models/law_document/LawDocument";
import { formatDate } from "@/utils";
import { Button, Stack, Tooltip } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { uniqueId } from "lodash";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

const LegalDocumentReportDone = () => {
  const router = useRouter();
  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [reportFilters, setReportFilters] = useState<IReportFilters>({});

  const [legalDocumentTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: BasedLegalDocumentFieldNames.ID,
      label: BasedLegalDocumentFieldNames.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
    },
    {
      key: BasedLegalDocumentFieldNames.DOCUMENT_TYPE,
      label: BasedLegalDocumentFieldNames.DOCUMENT_TYPE,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 150,
      filterRank: 1,
      flex: 1,
    },
    {
      key: BasedLegalDocumentFieldNames.DOCUMENT_NAME,
      label: BasedLegalDocumentFieldNames.DOCUMENT_NAME,
      type: "string",
      quickFilter: true,
      filterable: false,
      sortable: true,
      hideable: false,
      minWidth: 240,
      flex: 2,
      renderCell: (params) => (
        <HierarchyToolTip
          {...legalDocumentSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.documentName}
          openNewTab
        >
          <span>{params.value}</span>
        </HierarchyToolTip>
      ),
    },
    {
      key: BasedLegalDocumentFieldNames.AGENCY_ISSUES,
      label: BasedLegalDocumentFieldNames.AGENCY_ISSUES,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      renderCell: (params) => params.value?.name,
      filterRank: 3,
    },
    {
      key: BasedLegalDocumentFieldNames.TEXT_NUMBER,
      label: BasedLegalDocumentFieldNames.TEXT_NUMBER,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      filterRank: 4,
    },
    {
      key: BasedLegalDocumentFieldNames.FIELD,
      label: BasedLegalDocumentFieldNames.FIELD,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      filterRank: 2,
    },
    {
      key: BasedLegalDocumentFieldNames.STATUS,
      label: BasedLegalDocumentFieldNames.STATUS,
      type: undefined,
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      renderCell: (params) => {
        return (
          <Button
            variant="outlined"
            style={{
              background:
                params?.row?.status?.name &&
                params?.row?.status?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params?.row?.status?.name &&
                params?.row?.status?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params?.row?.status?.name}
          </Button>
        );
      },
      filterRank: 6,
    },
    {
      key: BasedLegalDocumentFieldNames.RECEIVE_FROM_VENDOR_DATE,
      label: BasedLegalDocumentFieldNames.RECEIVE_FROM_VENDOR_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 160,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: BasedLegalDocumentFieldNames.VENDOR_RESPONSE_DATE,
      label: BasedLegalDocumentFieldNames.VENDOR_RESPONSE_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 160,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: BasedLegalDocumentFieldNames.SUBMISSION_DEADLINE,
      label: BasedLegalDocumentFieldNames.SUBMISSION_DEADLINE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 120,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: BasedLegalDocumentFieldNames.DEPARTMENT_RESPONSE_DATE,
      label: BasedLegalDocumentFieldNames.DEPARTMENT_RESPONSE_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: BasedLegalDocumentFieldNames.PUBLISH_DATE,
      label: BasedLegalDocumentFieldNames.PUBLISH_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 140,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: BasedLegalDocumentFieldNames.EFFECTIVE_DATE,
      label: BasedLegalDocumentFieldNames.EFFECTIVE_DATE,
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 140,
      renderCell: (params) => formatDate(params.value),
    },
    {
      key: BasedLegalDocumentFieldNames.DEPARTMENTS,
      label: BasedLegalDocumentFieldNames.RELATED_DEPARTMENTS,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      filterRank: 5,
      flex: 1,
      renderCell: (params) => (
        <Tooltip
          placement="bottom-start"
          title={(params.value || [])?.map((departmentName: any) => (
            <p key={uniqueId("dept_")}>{departmentName}</p>
          ))}
        >
          {(params.value || []).join(",")}
        </Tooltip>
      ),
    },
    {
      key: BasedLegalDocumentFieldNames.CREATED_BY,
      label: BasedLegalDocumentFieldNames.CREATED_BY,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      filterRank: 7,
      renderCell: (params) => params?.row?.createdBy?.name,
    },
    {
      key: BasedLegalDocumentFieldNames.CREATED_DATE,
      label: BasedLegalDocumentFieldNames.CREATED_DATE,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: true,
      minWidth: 240,
      filterRank: 7,
      renderCell: (params) =>
        formatDate(params?.row?.createdDate, "dd/MM/yyyy"),
    },
  ]);

  /** Get all legal advice */
  const getTableQuery = useQuery({
    queryKey: ["legal-document/statistic/table/done"],
    queryFn: async () =>
      await getLegalDocumentStatisticDoneFn(
        castTableStateToParams(tableState, reportFilters)
      ),
    enabled: false,
  });

  useEffect(() => {
    tableState && getTableQuery.refetch();
  }, [tableState, reportFilters]);

  const onSearchClick = (data: any) => {
    setReportFilters({
      ...data,
    });
  };

  return (
    <Stack direction={"column"} height={"100%"}>
      <ReportFilterPanel onSearch={onSearchClick} noStatus isDepartments/>
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.data ?? []}
          columns={legalDocumentTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabelLegalDoc(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          onRowClick={(params) =>
            router.push(
              `/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            )
          }
          hideRowCheckbox
        />
      </div>
    </Stack>
  );
};

export default LegalDocumentReportDone;
