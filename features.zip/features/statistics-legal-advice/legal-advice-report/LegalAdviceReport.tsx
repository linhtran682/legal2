
import { getStatisticTableFn } from '@/apis/service/legal-advice/legalAdvice';
import HierarchyToolTip from '@/components/commons/hierarchy-tooltip/HierarchyTooltip';
import { MultipleFilterTableColumn } from '@/components/commons/tables/multiple_filter_table/MultipleFilterTable';
import StandardTable, { DEFAULT_PAGE_MODAL, StandardTableState } from '@/components/commons/tables/standard_table/StandardTable';
import { LEGAL_ADVICE_ROOT_PATH, UI_PATH } from '@/constants/paths';
import ReportFilterPanel from '@/features/legal-advice/report_filter_panel/ReportFilterPanel';
import { legalAdviceSearchPanelConfig } from '@/models/legal-advice/LegalAdviceDetail';
import { BaseLegalAdviceFields, GetLegalAdviceListParams } from '@/models/legal-advice/LegalAdviceList';
import { formatDate } from '@/utils';
import { Button, Stack, Tooltip } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface IReportFilters {
  startDate?: string;
  endDate?: string;
  departments?: string[];
  status?: number[];
}

const LegalAdviceReport = () => {
  const { t } = useTranslation();
  const router = useRouter();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [reportFilters, setReportFilters] = useState<IReportFilters>({});

  const [legalDocumentTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: BaseLegalAdviceFields.ID,
      label: BaseLegalAdviceFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: 'center'
    },
    {
      key: BaseLegalAdviceFields.LEGAL_ADVICE_NAME,
      label: BaseLegalAdviceFields.LEGAL_ADVICE_NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      flex: 2,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => (
        <HierarchyToolTip
          {...legalAdviceSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.legalAdviceName}
          openNewTab
        >
          <span>{params.value}</span>
        </HierarchyToolTip>
      ),
    },
    {
      key: BaseLegalAdviceFields.FIELD,
      label: BaseLegalAdviceFields.FIELD,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => <span>{params.value?.name}</span>,
    },
    {
      key: BaseLegalAdviceFields.REASON,
      label: BaseLegalAdviceFields.REASON,
      type: undefined,
      quickFilter: false,
      // filterable: true,
      sortable: true,
      minWidth: 200,
      // hideable: true,
    },
    {
      key: BaseLegalAdviceFields.STATUS,
      label: BaseLegalAdviceFields.STATUS,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => {
        return (
          <Button
            variant="outlined"
            style={{
              background:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#E7F4EE"
                  : "#D781001A",
              borderRadius: "100px",
              color:
                params.value?.name && params.value?.name === "Hoàn thành"
                  ? "#0D894F"
                  : "#D78100",
              border: "none",
              padding: "4px 12px",
            }}
          >
            {params?.row?.isDraft ? t('common.label.draft') : params.value?.name}
          </Button>
        );
      },
    },
    {
      key: BaseLegalAdviceFields.DEADLINE_TYPE,
      label: BaseLegalAdviceFields.DEADLINE,
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 270,
      flex: 1,
      renderCell: (params) =>
        params.value === 1 ? t("legalAdvice.label.SOP") : "Urgent",
    },
    {
      key: BaseLegalAdviceFields.RESPONSE_DATE,
      label: BaseLegalAdviceFields.RETURN_DATE_ALL,
      filterLabel: "legalAdvice.label.responseDeadline",
      type: "date",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, 'dd/MM/yyyy HH:mm'),
    },
    {
      key: BaseLegalAdviceFields.SENDER,
      label: BaseLegalAdviceFields.SENDER,
      filterLabel: "legalAdvice.label.creator",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 250,
      flex: 1,
      renderCell: (params) => <Tooltip
        placement="bottom-start"
        title={params.row?.pic
          ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
          : ""}>
        <span>
          {params.row?.pic
            ? `${params.row?.pic?.name} - ${params.row?.pic?.departmentResponse?.name}`
            : ""}
        </span>
      </Tooltip>,
    },
    {
      key: BaseLegalAdviceFields.RECEIVER,
      label: BaseLegalAdviceFields.RECEIVER,
      type: "string",
      quickFilter: false,
      // filterable: true,
      flex: 2,
      sortable: true,
      minWidth: 250,
      renderCell: (params) =>
        <Tooltip
          placement="bottom-start"
          title={
            <>
              {params.row?.receiverUsers
                ?.map(
                  (user: any) => <p key={user?.id}>{user.name} - {user?.departmentResponse?.name}</p>
                )}
            </>
          }>
          {params.row?.receiverUsers
            ?.map(
              (user: any) => `${user.name} - ${user?.departmentResponse?.name}`
            )
            .join(", ")}
        </Tooltip>
    },
  ]);

  /** Get all legal advice */
  const getTableQuery = useQuery({
    queryKey: ['legal-advice/statistics/table'],
    queryFn: async () =>
      await getStatisticTableFn(castTableStateToParams(tableState, reportFilters)),
    enabled: false,
  });

  useEffect(() => {
    tableState && getTableQuery.refetch();
  }, [tableState, reportFilters])

  const onSearchClick = (data: any) => {
    setReportFilters({
      ...data
    })
  }



  return (
    <Stack direction={'column'} height={'100%'}>
      <ReportFilterPanel onSearch={onSearchClick} />
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.data ?? []}
          columns={legalDocumentTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabel(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          onRowClick={(params) =>
            router.push(
              `/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            )
          }
          hideRowCheckbox
        />
      </div>
    </Stack>
  )
}

export default LegalAdviceReport


const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: IReportFilters
): GetLegalAdviceListParams => {
  const params: GetLegalAdviceListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: BaseLegalAdviceFields.ID,
    orderBy: "DESC",
  };
  if (filters?.status?.length) {
    params.statusList = filters.status?.join(',');
  }
  if (filters?.departments?.length) {
    params.departmentIds = filters.departments?.join(',');
  }
  if (filters?.startDate) {
    params.createFrom = filters?.startDate;
  }
  if (filters?.endDate) {
    params.createTo = filters?.endDate;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  return params;
};
const getFieldLabel = (key: string) => {
  return `legalAdvice.fields.${key}`;
};