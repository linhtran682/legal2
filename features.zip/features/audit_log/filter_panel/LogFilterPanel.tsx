import DateInput from "@/components/commons/inputs/date_input/DateInput";
import { formInputSxProps } from "@/constants/theme";
import { toIsoEndOfDay, toIsoStartOfDay } from "@/utils";
import { Box, Button, Grid, Stack } from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

interface Props {
  onSearch?: (data: any) => void;
  onExport?: (data: any) => void;
  loading?: boolean;
}
const LogFilterPanel = (props: Props) => {
  const { onExport, onSearch, loading } = props;
  const form = useForm();
  const { t } = useTranslation();

  const getParams = () => {
    const data = form.getValues();
    const params = {
      from: toIsoStartOfDay(data?.from as Date),
      to: toIsoEndOfDay(data?.to as Date),
    };
    return params;
  };

  const handleSearch = () => {
    const params = getParams();
    onSearch?.(params);
  };
  const handleExport = () => {
    const params = getParams();
    onExport?.(params);
  };

  return (
    <FormProvider {...form}>
      <Box
        sx={{
          backgroundColor: "white",
          p: 1,
          ...formInputSxProps,
        }}
      >
        <Grid container spacing={1}>
          {/* <ReportTypeSelect /> */}
          <Grid item xs={12} display={"flex"} direction={"row"} gap={1} md={6}>
            <Box flex={1}>
              <DateInput
                control={form.control}
                name="from"
                label={t("common.input.number_range.from")}
                placeholder={"dd/mm/yyyy"}
                maxDate={form.watch("to")}
                onChange={(date) => form.setValue("from", date)}
                value={form.watch("from")}
                watchValue
                shouldRemove
              />
            </Box>
            <Box flex={1}>
              <DateInput
                control={form.control}
                name="to"
                label={t("common.input.number_range.to")}
                placeholder={"dd/mm/yyyy"}
                minDate={form.watch("from")}
                onChange={(date) => form.setValue("to", date)}
                value={form.watch("to")}
                watchValue
                shouldRemove
              />
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Stack
        sx={{
          backgroundColor: "white",
        }}
        p={1.5}
        direction={"row"}
        mt={1.5}
        gap={1.5}
        width={"100%"}
        justifyContent={"flex-end"}
      >
        <Button
          variant="contained"
          className="confirm"
          disabled={loading}
          sx={{ minWidth: 128 }}
          onClick={form.handleSubmit(handleSearch)}
        >
          {t("report.search")}
        </Button>
        {onExport ? (
          <Button
            variant="contained"
            className="confirm"
            disabled={loading}
            sx={{ minWidth: 128 }}
            onClick={form.handleSubmit(handleExport)}
          >
            Export
          </Button>
        ) : null}
      </Stack>
    </FormProvider>
  );
};

export default LogFilterPanel;
