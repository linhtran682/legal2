import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { GLOBAL_SPACING } from "@/constants/format";
import { formInputSxProps } from "@/constants/theme";
import { Button, Grid } from "@mui/material";
import {
  FC,
  ReactNode,
  useEffect,
  useRef,
} from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { formatDate } from "@/utils";
import { AuditLog, AuditLogFields } from "@/models/setting/Log";
import { useRouter } from "next/router";

export interface Props {
  initialValue: AuditLog;
  children?: ReactNode;
}

const AuditLogForm: FC<Props> = (props) => {
  const { initialValue } = props;

  const formRef = useRef<HTMLFormElement>(null);
  const { t } = useTranslation();
  const router = useRouter();

  const form = useForm<any>({
    mode: "onBlur",
    disabled: true,
  });

  useEffect(() => {
    if (initialValue) {
      form.reset({
        ...initialValue,
        [AuditLogFields.USER_NAME]: initialValue.user.name,
        [AuditLogFields.SUCCESS]: initialValue.success
          ? t("setting.auditLog.fields.success")
          : t("setting.auditLog.fields.failed"),
        [AuditLogFields.SERVICE]: initialValue.service,
        [AuditLogFields.ACTION]: initialValue.action,
        [AuditLogFields.DURATION]: initialValue.duration,
        [AuditLogFields.IP]: initialValue.ip,
        [AuditLogFields.USER_AGENT]: initialValue.userAgent,
        [AuditLogFields.TIME]: formatDate(
          initialValue.time,
          "dd/MM/yyyy HH:mm"
        ),
      });
    }
  }, [initialValue, form, t]);

  return (
    <>
      <Grid container className="form-wrapper" sx={{ mt: 0 }}>
        <FormProvider {...form}>
          <form ref={formRef}>
            <Grid
              container
              direction={"column"}
              rowGap={GLOBAL_SPACING}
              alignItems={"center"}
              className="form-section-wrapper"
              sx={{ ...formInputSxProps, pb: 2 }}
            >
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.USER_NAME}
                  label={t(
                    `setting.auditLog.fields.${AuditLogFields.USER_NAME}`
                  )}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.USER_NAME}`
                  )}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.SUCCESS}
                  label={t(`setting.auditLog.fields.${AuditLogFields.SUCCESS}`)}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.SUCCESS}`
                  )}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.SERVICE}
                  label={t(`setting.auditLog.fields.${AuditLogFields.SERVICE}`)}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.SERVICE}`
                  )}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.ACTION}
                  label={t(`setting.auditLog.fields.${AuditLogFields.ACTION}`)}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.ACTION}`
                  )}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.DURATION}
                  label={t(
                    `setting.auditLog.fields.${AuditLogFields.DURATION}`
                  )}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.DURATION}`
                  )}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.IP}
                  label={t(`setting.auditLog.fields.${AuditLogFields.IP}`)}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.IP}`
                  )}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.USER_AGENT}
                  label={t(
                    `setting.auditLog.fields.${AuditLogFields.USER_AGENT}`
                  )}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.USER_AGENT}`
                  )}
                  disabled
                />
              </Grid>
              <Grid item width={"100%"}>
                <FormTextField
                  control={form.control}
                  name={AuditLogFields.TIME}
                  label={t(`setting.auditLog.fields.${AuditLogFields.TIME}`)}
                  placeHolder={t(
                    `setting.auditLog.fields.${AuditLogFields.TIME}`
                  )}
                  disabled
                />
              </Grid>
            </Grid>

            <Grid
              container
              justifyContent={"end"}
              style={{ position: "fixed", bottom: 0 }}
            >
              <Grid item sx={{ position: "sticky", right: 0, px: 4, py: 1 }}>
                <Button
                  onClick={() => router.back()}
                  variant="contained"
                  className="cancel"
                  sx={{ px: 6 }}
                >
                  {t("common.button.close")}
                </Button>
              </Grid>
            </Grid>
          </form>
        </FormProvider>
      </Grid>
    </>
  );
};

export default AuditLogForm;
