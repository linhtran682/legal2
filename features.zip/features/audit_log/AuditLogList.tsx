'use client'
import { ExtractFnReturnType } from '@/apis';
import { getAuditLogExcel, getAuditLogQueryFn } from '@/apis/service/setting/LogApi';
import { MultipleFilterTableColumn } from '@/components/commons/tables/multiple_filter_table/MultipleFilterTable';
import StandardTable, { DEFAULT_PAGE_MODAL, StandardTableState } from '@/components/commons/tables/standard_table/StandardTable';
import { AUDIT_LOG_ROOT_PATH, UI_PATH } from '@/constants/paths';
import { AuditLogFields, AuditLoglistRequest, GetAuditLogFnType } from '@/models/setting/Log';
import { downloadFile, formatDate } from '@/utils';
import { Stack } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import LogFilterPanel from './filter_panel/LogFilterPanel';
import { format } from 'date-fns';
import { MIME_TYPES } from '@/constants/general';

interface ILogFilters {
  from?: string;
  to?: string;
}

const AuditLogList = () => {
  const { t, i18n } = useTranslation();
  const router = useRouter();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [logFilters, setLogFilters] = useState<ILogFilters>({});

  const logTableColumns: MultipleFilterTableColumn[] = useMemo(() => [
    {
      key: AuditLogFields.ID,
      label: AuditLogFields.ID,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: 'center'
    },
    {
      key: AuditLogFields.USER_ID,
      label: AuditLogFields.USER_ID,
      type: "string",
      quickFilter: true,
      // filterable: true,
      flex: 2,
      sortable: true,
      hideable: false,
      minWidth: 300,
      renderCell: (params) => <span>{params.row?.user?.id}</span>,
    },
    {
      key: AuditLogFields.USER_NAME,
      label: AuditLogFields.USER_NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      flex: 2,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => {
        return <span>{params.row?.user?.name}</span>
      },
    },
    {
      key: AuditLogFields.SUCCESS,
      label: AuditLogFields.SUCCESS,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 120,
      renderCell: (params) => <span>{params.row?.success ? t("setting.auditLog.fields.success") : t("setting.auditLog.fields.failed")}</span>,
    },
    {
      key: AuditLogFields.SERVICE,
      label: AuditLogFields.SERVICE,
      type: undefined,
      quickFilter: false,
      // filterable: true,
      sortable: true,
      minWidth: 300,
      // hideable: true,
    },
    {
      key: AuditLogFields.ACTION,
      label: AuditLogFields.ACTION,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
    },
    {
      key: AuditLogFields.DURATION,
      label: AuditLogFields.DURATION,
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 100,
      flex: 1,
      renderCell: (params) => <span>{params.value}</span>
    },
    {
      key: AuditLogFields.IP,
      label: AuditLogFields.IP,
      filterLabel: "setting.auditLog.fields.ip",
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      minWidth: 150,
    },
    {
      key: AuditLogFields.USER_AGENT,
      label: AuditLogFields.USER_AGENT,
      type: "string",
      quickFilter: false,
      filterable: false,
      sortable: true,
      minWidth: 400,
      flex: 1,
    },
    {
      key: AuditLogFields.TIME,
      label: AuditLogFields.TIME,
      type: "string",
      quickFilter: false,
      // filterable: true,
      flex: 1,
      sortable: true,
      minWidth: 180,
      renderCell: (params) => formatDate(params.value, 'dd/MM/yyyy HH:mm'),
    },
  ], [t]);

  const getTableQuery = useQuery<ExtractFnReturnType<GetAuditLogFnType>>({
    queryKey: ['get_audit_log/table'],
    queryFn: async () =>
      await getAuditLogQueryFn(castTableStateToParams(tableState, logFilters)),
    enabled: false,
  });

  useEffect(() => {
    tableState && logFilters && getTableQuery.refetch();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState, logFilters]);

  const onSearchClick = (data: any) => {
    setLogFilters(data)
  }

    /** Get excel file */
    const getLogQuery = useQuery({
      queryKey: ["get_audit_log_excel"],
      queryFn: () =>
        getAuditLogExcel({
          ...castTableStateToParams(tableState, logFilters),
          size: 999999,
        }),
      enabled: false,
    });

    const onExport = () => {
      getLogQuery.refetch().then((response: any) => {
        const fileName = `${
          i18n.language === "en" ? "AuditLog" : "Audit Log"
        }_${format(new Date(), "ddMMyyyy")}`;
        response?.data &&
          downloadFile(response, MIME_TYPES.XLSX, fileName);
      });
    }
    
  return (
    <Stack direction={'column'} height={'100%'}>
      <LogFilterPanel onSearch={onSearchClick} onExport={onExport} loading={getTableQuery.isFetching || getLogQuery.isFetching} />
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.apiLogResponses ?? []}
          columns={logTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabel(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          onRowClick={(params) =>
            router.push(
              `/${AUDIT_LOG_ROOT_PATH}/${UI_PATH.VIEW}/${params.id}`
            )
          }
          hideRowCheckbox
        />
      </div>
    </Stack>
  )
}

export default AuditLogList


const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: ILogFilters
): AuditLoglistRequest => {
  const params: AuditLoglistRequest = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: AuditLogFields.ID,
    orderBy: "DESC",
  };
  if (filters?.from) {
    params.from = filters?.from;
  }
  if (filters?.to) {
    params.to = filters?.to;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }

  return params;
};
const getFieldLabel = (key: string) => {
  return `setting.auditLog.fields.${key}`;
};