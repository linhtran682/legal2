import { getDepartments } from '@/apis/service/department/department';
import { getStatusList } from '@/apis/service/status/Status';
import { FormMultipleSelect } from '@/components/commons/form_inputs/FormMultipleSelect';
import { FormSelectTreeView } from '@/components/commons/form_inputs/FormSelectTreeView';
import ReportTypeSelect from '@/components/commons/report_type_select/ReportTypeSelect';
import { FILTER_DEBOUNCE_MS } from '@/constants/filter';
import { ModuleFields } from '@/constants/general';
import { formInputSxProps } from '@/constants/theme';
import { Department } from '@/models/department/Department';
import { FieldFieldNames } from '@/models/field/Field';
import { toIsoEndOfDay, toIsoStartOfDay } from '@/utils';
import { Box, Button, Grid, Stack } from '@mui/material';
import { FormProvider, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

interface ReportFilterPanelProps {
  onSearch?: (data: any) => void;
  onExport?: (data: any) => void;
  loading?: boolean;
  noStatus?: boolean;
}
const ReportFilterPanel = (props: ReportFilterPanelProps) => {
  const { onExport, onSearch, loading, noStatus } = props;
  const form = useForm();
  const { t } = useTranslation();

  const getParams = () => {
    const data = form.getValues();
    const params = {
      startDate: toIsoStartOfDay(data?.from as Date),
      endDate: toIsoEndOfDay(data?.to as Date),
      departments: data?.departments,
      status: data?.status?.map((ele: any) => ele?.id)
    }
    return params;
  }

  const handleSearch = () => {
    const params = getParams();
    onSearch?.(params);
  }
  const handleExport = () => {
    const params = getParams();
    onExport?.(params);
  }

  return (
    <FormProvider {...form}>
      <Box
        sx={{
          backgroundColor: "white",
          p: 1,
          ...formInputSxProps
        }}
      >
        <Grid
          container
          spacing={1}
        >
          <ReportTypeSelect />


          {noStatus ? null : <Grid item xs={12} md={6}>
            <FormMultipleSelect
              control={form.control}
              name={'status'}
              label={t(`report.status`)}
              placeholder={t(`report.status`)}
              keyQuery={"conflict-report-status-query"}
              getOptions={async () => {
                const response = await getStatusList({
                  page: 0,
                  size: 100,
                  sortBy: FieldFieldNames.NAME,
                  orderBy: "ASC",
                  modules: [ModuleFields.DECLARE_RELATIONSHIP.module],
                  active: 1
                });
                return response?.statusResponses || [];
              }}
              showAllSelected={false}
              getOptionKey={(option) => option.id.toString()}
              getOptionLabel={(option) => option?.name}
              isFocus
            />
          </Grid>}

          <Grid item xs={12} md={noStatus ? 12 : 6}>
            <FormSelectTreeView
              name={"departments"}
              control={form.control}
              label={t("report.department")}
              getOptions={async (keyword) => {
                try {
                  const response = await getDepartments({
                    searchTerm: keyword,
                  });
                  const first100Departments: Department[] = (
                    response?.departments ?? []
                  ).slice(0, 150);
                  return first100Departments;
                } catch (e) {
                  return [];
                }
              }}
              getOptionLabel={(option) => option.name ?? ""}
              getOptionKey={(option) => option.id ?? ""}
              getOptionChildren={(option) => option.children}
              variant='outlined'
              debounceMs={FILTER_DEBOUNCE_MS}
              onChange={(value: Department[]) => {
                const mappedValue: string[] = value.map(
                  (item) => item.id ?? ""
                );
                form.setValue("departments", mappedValue);
              }}
              showAllSelected={false}
              ignoreChildren
            />
          </Grid>

        </Grid>
      </Box>
      <Stack
        sx={{
          backgroundColor: "white",
        }}
        p={1.5} direction={'row'} mt={1.5} gap={1.5} width={'100%'} justifyContent={'flex-end'}>
        <Button
          variant='contained'
          className='confirm'
          disabled={loading}
          sx={{ minWidth: 128 }}
          onClick={form.handleSubmit(handleSearch)}>
          {t('report.search')}</Button>
        {onExport ? <Button
          variant='contained'
          className='confirm'
          disabled={loading}
          sx={{ minWidth: 128 }}
          onClick={form.handleSubmit(handleExport)}>Export</Button> : null}

      </Stack>
    </FormProvider>
  )
}

export default ReportFilterPanel