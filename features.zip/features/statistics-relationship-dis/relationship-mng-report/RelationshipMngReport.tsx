
import { getStatisticTableFn } from '@/apis/service/relationship_disclosure/relationMngFormPopup';
import HierarchyToolTip from '@/components/commons/hierarchy-tooltip/HierarchyTooltip';
import { MultipleFilterTableColumn } from '@/components/commons/tables/multiple_filter_table/MultipleFilterTable';
import StandardTable, { DEFAULT_PAGE_MODAL, StandardTableState } from '@/components/commons/tables/standard_table/StandardTable';
import { LEGAL_ADVICE_ROOT_PATH, UI_PATH } from '@/constants/paths';
import { GetConflictManagementListParams } from '@/models/conflict_management/ConflictManagementList';
import { legalAdviceSearchPanelConfig } from '@/models/legal-advice/LegalAdviceDetail';
import { BaseLegalAdviceFields } from '@/models/legal-advice/LegalAdviceList';
import { BaseRelationshipDisclosureFields, GetRelationshipDisclosureListParams } from '@/models/relationship-disclosure/RelationshipDisclosureList';
import { formatDate } from '@/utils';
import { Stack } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import ReportFilterPanel from '../report_filter_panel/ReportFilterPanel';

interface IReportFilters {
  startDate?: string;
  endDate?: string;
  departments?: string[];
  status?: number[];
}

const RelationshipMngReport = () => {
  // const { t } = useTranslation();
  const router = useRouter();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [reportFilters, setReportFilters] = useState<IReportFilters>({});

  const [legalDocumentTableColumns] = useState<MultipleFilterTableColumn[]>([
    {
      key: BaseRelationshipDisclosureFields.ID,
      label: BaseRelationshipDisclosureFields.ID,
      type: "number",
      quickFilter: false,
      filterable: false,
      sortable: false,
      hideable: false,
      maxWidth: 52,
      align: 'center'
    },
    {
      key: BaseRelationshipDisclosureFields.DOCUMENT_NAME,
      label: BaseRelationshipDisclosureFields.DOCUMENT_NAME,
      type: "string",
      quickFilter: true,
      // filterable: true,
      flex: 2,
      sortable: true,
      hideable: false,
      minWidth: 240,
      renderCell: (params) => (
        <HierarchyToolTip
          {...legalAdviceSearchPanelConfig}
          targetId={params.id as number}
          previewTitle={params?.row?.legalAdviceName}
          openNewTab
        >
          <span>{params.row.documentName}</span>
        </HierarchyToolTip>
      ),
    },
    {
      key: BaseRelationshipDisclosureFields.EMPLOYEE_ID,
      label: BaseRelationshipDisclosureFields.EMPLOYEE_ID,
      type: "string",
      quickFilter: false,
      filterable: true,
      sortable: true,
      hideable: false,
      minWidth: 180,
      renderCell: (params) => <span>{params.row?.employeeInfoResponse.employee.employeeCode}</span>,
    },
    // {
    //   key: BaseRelationshipDisclosureFields.EMPLOYEE_INFO,
    //   label: BaseRelationshipDisclosureFields.EMPLOYEE_NAME,
    //   type: undefined,
    //   quickFilter: false,
    //   // filterable: true,
    //   sortable: true,
    //   minWidth: 200,
    //   // hideable: true,
    //   renderCell: (params) => <span>{params.row?.employeeInfo.employee.name}</span>,

    // },
    {
      key: BaseRelationshipDisclosureFields.POSITION,
      label: BaseRelationshipDisclosureFields.POSITION,
      type: "string",
      quickFilter: true,
      filterable: true,
      sortable: true,
      minWidth: 240,
      renderCell: (params) => <span>{params.row?.employeeInfoResponse.positionNameCustom}</span>,

      // renderCell: (params) => {
      //   return (
      //     <Button
      //       variant="outlined"
      //       style={{
      //         background:
      //           params.value?.name && params.value?.name === "Hoàn thành"
      //             ? "#E7F4EE"
      //             : "#D781001A",
      //         borderRadius: "100px",
      //         color:
      //           params.value?.name && params.value?.name === "Hoàn thành"
      //             ? "#0D894F"
      //             : "#D78100",
      //         border: "none",
      //         padding: "4px 12px",
      //       }}
      //     >
      //       {params.value?.name}
      //     </Button>
      //   );
      // },
    },
    // {
    //   key: BaseRelationshipDisclosureFields.,
    //   label: BaseRelationshipDisclosureFields.DEPARTMENT,
    //   type: "string",
    //   quickFilter: false,
    //   sortable: true,
    //   minWidth: 270,
    //   flex: 1,
    //   renderCell: (params) => <span>{params.row?.employeeInfo.departmentNameCustom}</span>,

    //   // renderCell: (params) =>
    //   //   params.value === 1 ? t("legalAdvice.label.SOP") : "Urgent",
    // },
    {
      key: 'statusConfirmId',
      label: 'statusConfirmId',
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 270,
      flex: 1,
      renderCell: (params) => <span>{ params.row?.statusConfirm?.active === 1 &&   params.row?.statusConfirm?.name}</span>,

      // renderCell: (params) =>
      //   params.value === 1 ? t("legalAdvice.label.SOP") : "Urgent",
    },
    {
      key: 'statusEvaluateId',
      label: 'statusEvaluateId',
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 270,
      flex: 1,
      renderCell: (params) => <span>{ params.row?.statusEvaluate?.active === 1 &&   params.row?.statusEvaluate?.name}</span>,

      // renderCell: (params) =>
      //   params.value === 1 ? t("legalAdvice.label.SOP") : "Urgent",
    },
    {
      key: BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE,
      label: BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE,
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 270,
      flex: 1,
      renderCell: (params) => <span>{formatDate(params.row?.confirmationDeadline)}</span>,

      // renderCell: (params) =>
      //   params.value === 1 ? t("legalAdvice.label.SOP") : "Urgent",
    },
    {
      key: 'createdDate',
      label: 'createdDate',
      type: "string",
      quickFilter: false,
      sortable: true,
      minWidth: 270,
      flex: 1,
      renderCell: (params) => <span>{formatDate(params.row?.createdDate)}</span>,

      // renderCell: (params) =>
      //   params.value === 1 ? t("legalAdvice.label.SOP") : "Urgent",
    },
  ]);

  /** Get all legal advice */
  const getTableQuery = useQuery({
    queryKey: ['conflict-mng/statistics/table'],
    queryFn: async () =>
      await getStatisticTableFn(castTableStateToParams(tableState, reportFilters)),
    enabled: false,
  });
    
  useEffect(() => {
    tableState && getTableQuery.refetch();
  }, [tableState, reportFilters])

  const onSearchClick = (data: any) => {
    setReportFilters({
      ...data
    })
  }

  return (
    <Stack direction={'column'} height={'100%'}>
      <ReportFilterPanel onSearch={onSearchClick} />
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.data  ?? []}
          columns={legalDocumentTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabel(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          onRowClick={(params) =>
            router.push(
              `/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            )
          }
          hideRowCheckbox
        />
      </div>
    </Stack>
  )
}

export default RelationshipMngReport


const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: IReportFilters
): GetConflictManagementListParams => {
  const params: GetRelationshipDisclosureListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: BaseLegalAdviceFields.ID,
    orderBy: "DESC",
  };
  if (filters?.status?.length) {
    params.statusList = filters.status?.join(',');
  }
  if (filters?.departments?.length) {
    params.departmentIds = filters.departments?.join(',');
  }
  if (filters?.startDate) {
    params.createFrom = filters.startDate;
  }
  if (filters?.endDate) {
    params.createTo = filters.endDate;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  return params;
};
const getFieldLabel = (key: string) => {
  return `RELATION_SHIP_DISCLOSURE.label.${key}`;
};