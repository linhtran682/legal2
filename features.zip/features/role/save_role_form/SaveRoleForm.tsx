import { useContext, useEffect, useRef, useState } from "react";
import {
  StandardSimpleTable,
  StandardSimpleTableColumn,
} from "@/components/commons/tables/standard_simple_table/StandardSimpleTable";
import { GLOBAL_SPACING } from "@/constants/format";
import { Checkbox, Grid } from "@mui/material";
import { FormTextField } from "@/components/commons/form_inputs/FormTextField";
import { FormProvider, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  RoleBodySendForm,
  SaveRoleRequestFieldNames,
} from "@/models/role/Role";
import { useTranslation } from "react-i18next";
import { formInputSxProps } from "@/constants/theme";
import { FormCheckbox } from "@/components/commons/form_inputs/FormCheckbox";
import { BasicSaveForm } from "@/models/ui/form";
import { FormActionButtons } from "@/components/commons/action_button/FormActionButtons";
import { v4 as uuidv4 } from "uuid";
import { Permission, RoleAdminSystem, RoleSystem } from "@/constants/general";
import { AppContext } from "@/context/AppContext";
import * as Yup from "yup";

export interface RoleDTO {
  name?: string;
  // builtInRole?: boolean;
  defaultRole?: boolean;
  permissions?: string[];
}

interface FlattenedPermission {
  id?: string;
  permission: string;
  read: boolean;
  write: boolean;
  admin: boolean
}

function flattenPermissions(role: RoleDTO): FlattenedPermission[] {
  const flattenedData: { [key: string]: FlattenedPermission } = {};

  role.permissions?.forEach((item) => {
    const [permission, action] = item.split(":");

    if (!flattenedData[permission]) {
      flattenedData[permission] = {
        id: uuidv4(), // Generate a unique ID
        permission,
        read: false,
        write: false,
        admin: false
      };
    }

    flattenedData[permission][action as "read" | "write" | "admin"] = true;
  });

  return Object.values(flattenedData);
}
function convertToOriginalFormat(
  flattenedPermissions: FlattenedPermission[]
): string[] {
  const originalPermissions: string[] = [];

  flattenedPermissions.forEach((item) => {
    if (item.read) {
      originalPermissions.push(`${item.permission}:read`);
    }
    if (item.write) {
      originalPermissions.push(`${item.permission}:write`);
    }
    if (item.admin) {
      originalPermissions.push(`${item.permission}:admin`);
    }
  });

  return originalPermissions;
}
export interface SaveStatusFormProps extends BasicSaveForm<RoleDTO, RoleDTO> {}

export const SaveRoleForm = (props: SaveStatusFormProps) => {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const formRef = useRef<HTMLFormElement>(null);
  const SaveRoleRequestSchema = Yup.object().shape({
    defaultRole: Yup.boolean(),
    name: Yup.string().required(t("role.field_name.messageErrorNameRequire")),
    permissions: Yup.array().of(Yup.string().defined()).optional(),
  });
  const [data, setData] = useState<any[]>([]);
  const form = useForm<RoleBodySendForm>({
    resolver: yupResolver(SaveRoleRequestSchema),
    // defaultValues: JSON.parse(JSON.stringify(initialEmptyValue)),
    disabled: !appContext.meCanWrite,
  });
  useEffect(() => {
    if (props.initialValue) {
      setData(flattenPermissions(props.initialValue));
    }
  }, [props.initialValue]);

  const handleCheckboxChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    id: number,
    key: "write" | "read" | "admin"
  ) => {
    setData((prevData) =>
      prevData.map((item) =>
        item.id === id ? { ...item, [key]: event.target.checked } : item
      )
    );
  };

  const RolePermissionTableColumns: StandardSimpleTableColumn<any>[] = [
    {
      key: "permission",
      label: t("role.column.permission"),
      type: "string",
      flex: 1,
      renderCell: ({ row }) => t(Permission?.[row.permission]),
    },
    {
      key: "read",
      label: t("role.column.read"),
      type: "checkbox",
      flex: 1,
      renderCell: ({ row }) => (
        <Checkbox
          disabled={RoleSystem?.includes(props?.initialValue?.name || "")}
          checked={row.read}
          onChange={(event) => handleCheckboxChange(event, row.id, "read")}
        />
      ),
    },
    {
      key: "write",
      label: t("role.column.write"),
      type: "checkbox",
      flex: 1,
      renderCell: ({ row }) => (
        <Checkbox
          disabled={RoleSystem?.includes(props?.initialValue?.name || "")}
          checked={row.write}
          onChange={(event) => handleCheckboxChange(event, row.id, "write")}
        />
      ),
    },
    {
      key: "admin",
      label: t("role.column.manager"),
      type: "checkbox",
      flex: 1,
      renderCell: ({ row }) => (
        <Checkbox
          disabled={RoleSystem?.includes(props?.initialValue?.name || "") || !RoleAdminSystem?.includes(row.permission)}
          checked={row.admin}
          onChange={(event) => handleCheckboxChange(event, row.id, "admin")}
        />
      ),
    },
  ];
  useEffect(() => {
    props.initialValue && form.reset(props.initialValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.initialValue]);
  return (
    <Grid container className="form-wrapper">
      <FormProvider {...form}>
        <form ref={formRef}>
          <Grid
            container
            direction={"column"}
            rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={formInputSxProps}
          >
            <Grid item width={"100%"}>
              <FormTextField
                control={form.control}
                name={SaveRoleRequestFieldNames.NAME}
                label={t(`role.field_name.${SaveRoleRequestFieldNames.NAME}`)}
                placeHolder={t(
                  `role.field_name.${SaveRoleRequestFieldNames.NAME}`
                )}
                required
                disabled={RoleSystem?.includes(props?.initialValue?.name || "")}
              />
            </Grid>

            <Grid item width={"100%"}>
              <FormCheckbox
                control={form.control}
                name={SaveRoleRequestFieldNames.ROLE_DEFAULT}
                label={t(
                  `role.field_name.${SaveRoleRequestFieldNames.ROLE_DEFAULT}`
                )}
                inputTransform={(value: boolean) => value != false}
                outputTransform={(bool) => (bool ? true : false)}
              />
            </Grid>
            <StandardSimpleTable
              columns={RolePermissionTableColumns}
              data={data}
              getRowId={(row) => row.permission.toString()}
            />
          </Grid>
        </form>
        <FormActionButtons
          formMode={props.formMode}
          loading={props.loading}
          onCancel={props.onCancel}
          cancelConfirm={form.formState.isDirty}
          onDelete={props.onDelete}
          onSave={() => {
            props.onSubmit({
              ...form.getValues(),
              permissions: convertToOriginalFormat(data),
            });
          }}
        />
      </FormProvider>
    </Grid>
  );
};
