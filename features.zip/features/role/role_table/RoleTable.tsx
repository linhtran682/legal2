import { getRoles } from "@/apis/service/role/Role";
import StandardTable, {
  DEFAULT_PAGE_MODAL,
  StandardTableColumn,
  StandardTableState,
} from "@/components/commons/tables/standard_table/StandardTable";
import { ROLE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { GetRolesParams, RoleFieldNames } from "@/models/role/Role";
import { Checkbox } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { RoleTableActions } from "./role_table_actions/RoleTableActions";

export const RoleTableConst = {
  TABLE_NAME: "RoleTable",
  GET_TABLE_ITEMS_QUERY_KEY: "getRoleList",
  TABLE_ROLE_DEFAULT: "RolesDefault",
};

const castTableStateToParams = (
  tableState: StandardTableState
): GetRolesParams => {
  const params: GetRolesParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
  };

  return params;
};

export const RoleTable = () => {
  const router = useRouter();

  const [roleTableColumns] = useState<StandardTableColumn[]>(() => [
    {
      key: RoleFieldNames.NAME,
      label: RoleFieldNames.NAME,
      type: "string",
      filterable: false,
      sortable: false,
      hideable: false,
      flex: 1,
    },
    {
      key: RoleFieldNames.BUILT_IN_ROLE,
      label: RoleFieldNames.BUILT_IN_ROLE,
      type: undefined,
      filterable: false,
      sortable: false,
      hideable: false,
      renderCell: (params) => <Checkbox checked={params.value} />,
      flex: 1,
    },
    {
      key: RoleFieldNames.DEFAULT_ROLE,
      label: RoleFieldNames.DEFAULT_ROLE,
      type: undefined,
      filterable: false,
      sortable: false,
      hideable: false,
      renderCell: (params) => (
        <Checkbox disableFocusRipple checked={params.value == 1} />
      ),
      flex: 1,
    },
    {
      key: "action",
      label: "",
      type: undefined,
      renderCell: RoleTableActions,
      filterable: false,
      sortable: false,
      hideable: false,
      cellClassName: "stickyRight",
    },
  ]);

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const getRolesQuery = useQuery({
    queryKey: [RoleTableConst.GET_TABLE_ITEMS_QUERY_KEY],
    queryFn: () => getRoles(castTableStateToParams(tableState)),
  });

  useEffect(() => {
    tableState && getRolesQuery.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tableState]);

  return (
    <StandardTable
      data={getRolesQuery.data?.roles ?? []}
      columns={roleTableColumns
        // .filter((column) => appContext.meCanWrite || column.key != "action")
        .map((column) => ({
          ...column,
          label: column.label && `role.field_name.${column.label}`,
        }))}
      getRowId={(item) => item.id.toString()}
      loading={getRolesQuery.isFetching}
      filterModel={tableState?.filterModel}
      sorterModel={tableState?.sorterModel}
      paginationModel={tableState?.paginationModel}
      onChange={setTableState}
      rowCount={getRolesQuery.data?.total}
      onRowClick={(params) => {
        router.push(`/${ROLE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`);
      }}
      hideRowCheckbox
    />
  );
};
