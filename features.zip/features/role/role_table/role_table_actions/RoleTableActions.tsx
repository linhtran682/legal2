import { deleteRole } from "@/apis/service/role/Role";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { RoleTableConst } from "../RoleTable";
import { ActionButton } from "@/components/commons/action_button/ActionButton";
import { GridRenderCellParams } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import { ROLE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import DeleteIcon from "@mui/icons-material/Delete";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { RoleSystem } from "@/constants/general";

export const RoleTableActions = (params: GridRenderCellParams) => {
  const router = useRouter();
  const [t] = useTranslation();

  const queryClient = useQueryClient();

  const deleteRoleQuery = useMutation({
    mutationFn: deleteRole,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.status"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: [RoleTableConst.GET_TABLE_ITEMS_QUERY_KEY],
      });
    },
  });

  return (
    <ActionButton
      params={params}
      actionButtomItems={[
        {
          key: "update_status",
          icon: <EditIcon />,
          onClick: (params) =>
            router.push(`/${ROLE_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`),
          tooltipTitle: t("common.button.update"),
        },
        ...(!RoleSystem?.includes(params?.row?.name)
          ? [
              {
                key: "delete_status",
                icon: <DeleteIcon color="primary" />,
                onClick: (params: any) =>
                  params.id && deleteRoleQuery.mutate(String(params.id)),
                tooltipTitle: t("common.button.delete"),
                confirmPopupProps: {
                  icon: <DeleteRecordDialogIcon />,
                  title: t("common.message.confirm_delete"),
                },
              },
            ]
          : []),
      ]}
    />
  );
};
