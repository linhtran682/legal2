
import { getVisitationStatisticTableFn } from '@/apis/service/visitation/visitationApi';
import HierarchyToolTip from '@/components/commons/hierarchy-tooltip/HierarchyTooltip';
import { MultipleFilterTableColumn } from '@/components/commons/tables/multiple_filter_table/MultipleFilterTable';
import StandardTable, { DEFAULT_PAGE_MODAL, StandardTableState } from '@/components/commons/tables/standard_table/StandardTable';
import { UI_PATH, VISITATION_ROOT_PATH } from '@/constants/paths';
import { FollowViolationFields } from '@/models/follow_violation/FollowViolationType';
import { VisitationDetailFields, visitationSearchPanelConfig } from '@/models/visitation/VisitationDetail';
import { GetVisitationListParams } from '@/models/visitation/VisitationList';
import { formatDate } from '@/utils';
import { Button, Stack } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import VisitationReportFilterPanel from '../filter/ReportFilterPanel';

interface IReportFilters {
  startDate?: string;
  endDate?: string;
  department?: string;
  status?: number[];
}

const VisitationReport = () => {
  const { t } = useTranslation();
  const router = useRouter();

  const [tableState, setTableState] = useState<StandardTableState>({
    filterModel: { items: [] },
    sorterModel: [],
    paginationModel: DEFAULT_PAGE_MODAL,
    columnVisibilityModel: undefined,
  });

  const [reportFilters, setReportFilters] = useState<IReportFilters>({});

  const violationTableColumns: MultipleFilterTableColumn[] = useMemo(() => [
    {
          key: VisitationDetailFields.ID,
          label: VisitationDetailFields.ID,
          type: "number",
          quickFilter: false,
          filterable: false,
          sortable: false,
          hideable: false,
          maxWidth: 52,
          align: "center",
        },
        {
          key: VisitationDetailFields.NAME,
          label: VisitationDetailFields.NAME,
          type: "string",
          quickFilter: false,
          sortable: false,
          hideable: false,
          minWidth: 240,
          renderCell: (params) => (
            <HierarchyToolTip
              {...visitationSearchPanelConfig}
              targetId={params.id as number}
              previewTitle={params?.value}
              openNewTab
            >
              <span>{params.value}</span>
            </HierarchyToolTip>
          ),
        },
        {
          key: VisitationDetailFields.RECEPTION_IDS,
          label: VisitationDetailFields.RECEPTION_ID,
          filterLabel: "visitation.label.reception",
          type: "string",
          quickFilter: false,
          filterable: false,
          sortable: true,
          minWidth: 200,
          renderCell: (params) => {
            return params?.row?.receptionUser?.employeeCode;
          },
        },
        {
          key: VisitationDetailFields.RECEPTION_NAME,
          label: VisitationDetailFields.RECEPTION_NAME,
          type: "string",
          quickFilter: false,
          filterable: false,
          sortable: true,
          minWidth: 200,
          renderCell: (params) => {
            return params?.row?.receptionUser?.name ?? "";
          },
        },
        {
          key: VisitationDetailFields.POSITION,
          label: VisitationDetailFields.POSITION,
          type: undefined,
          quickFilter: false,
          filterable: true,
          sortable: true,
          minWidth: 200,
          renderCell: (params) => params?.row?.position,
        },
        {
          key: VisitationDetailFields.DEPARTMENT,
          label: VisitationDetailFields.DEPARTMENT,
          type: undefined,
          quickFilter: false,
          filterable: true,
          sortable: true,
          minWidth: 200,
          renderCell: (params) => params?.row?.department,
        },
        {
          key: VisitationDetailFields.FIELD,
          label: VisitationDetailFields.FIELD,
          type: undefined,
          quickFilter: false,
          filterable: false,
          sortable: true,
          minWidth: 200,
          renderCell: (params) => params?.row?.field ?? "",
        },
        {
          key: VisitationDetailFields.ORGANIZATION_NAME,
          label: VisitationDetailFields.ORGANIZATION_NAME,
          type: undefined,
          quickFilter: false,
          filterable: false,
          sortable: true,
          minWidth: 200,
          renderCell: (params) => params?.row?.organizationName ?? "",
        },
        {
          key: VisitationDetailFields.VISITATION_STATUS,
          label: VisitationDetailFields.VISITATION_STATUS,
          type: "string",
          quickFilter: false,
          filterable: false,
          sortable: false,
          minWidth: 240,
          renderCell: (params) => {
            const status = params?.row?.isDraft ? t("common.label.draft") : params.value?.name
            return (
              <Button
                variant="outlined"
                style={{
                  background:
                  status === "Hoàn thành"
                      ? "#E7F4EE"
                      : "#D781001A",
                  borderRadius: "100px",
                  color:
                  status === "Hoàn thành"
                      ? "#0D894F"
                      : "#D78100",
                  border: "none",
                  padding: "4px 12px",
                }}
              >
                {status}
              </Button>
            );
          },
        },
        {
          key: VisitationDetailFields.RECEPTION_TIME,
          label: VisitationDetailFields.RECEPTION_TIME,
          filterLabel: `visitation.label.${VisitationDetailFields.RECEPTION_TIME}`,
          type: "date",
          quickFilter: false,
          filterable: false,
          sortable: false,
          minWidth: 220,
          renderCell: (params) =>
            params.row.receptionTimeFrom
              ? `${formatDate(params.row.receptionTimeFrom)} - ${formatDate(
                  params.row.receptionTimeTo
                )}`
              : "",
        },
        {
          key: VisitationDetailFields.CONFIRM_DEADLINE,
          label: VisitationDetailFields.CONFIRM_DEADLINE,
          filterLabel: `visitation.label.${VisitationDetailFields.CONFIRM_DEADLINE}`,
          type: "date",
          quickFilter: false,
          filterable: true,
          sortable: false,
          minWidth: 160,
          renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
        },
        {
          key: VisitationDetailFields.RESPONSE_LC_DEADLINE,
          label: VisitationDetailFields.RESPONSE_LC_DEADLINE,
          filterLabel: `visitation.label.${VisitationDetailFields.RESPONSE_LC_DEADLINE}`,
          type: "date",
          quickFilter: false,
          filterable: true,
          sortable: false,
          minWidth: 180,
          renderCell: (params) => formatDate(params.value, "dd/MM/yyyy"),
        },
        {
          key: VisitationDetailFields.CREATED_BY,
          label: VisitationDetailFields.CREATED_BY,
          filterLabel: `visitation.label.${VisitationDetailFields.CREATED_BY}`,
          type: undefined,
          quickFilter: false,
          filterable: false,
          sortable: true,
          minWidth: 270,
          renderCell: (params) =>
            params.row?.createdBy
              ? `${params.row?.createdBy?.name} - ${params.row?.createdBy?.department?.name}`
              : "",
        },
  ], [t]);

  /** Get all legal advice */
  const getTableQuery = useQuery({
    queryKey: ['violation/statistics/table'],
    queryFn: async () =>
      await getVisitationStatisticTableFn(castTableStateToParams(tableState, reportFilters)),
    enabled: false,
  });

  useEffect(() => {
    tableState && getTableQuery.refetch();
  }, [tableState, reportFilters])

  const onSearchClick = (data: any) => {
    setReportFilters({
      ...data
    })
  }

  return (
    <Stack direction={'column'} height={'100%'}>
      <VisitationReportFilterPanel onSearch={onSearchClick} />
      <div style={{ height: "100%", overflow: "hidden" }}>
        <StandardTable
          data={getTableQuery?.data?.data ?? []}
          columns={violationTableColumns.map((column) => ({
            ...column,
            label: column.label ? getFieldLabel(column.label) : "",
          }))}
          getRowId={(item: any) => item?.id?.toString()}
          loading={getTableQuery?.isFetching}
          filterModel={tableState?.filterModel}
          sorterModel={tableState?.sorterModel}
          paginationModel={tableState?.paginationModel}
          onChange={setTableState}
          rowCount={getTableQuery?.data?.total}
          onRowClick={(params) =>
            router.push(
              `/${VISITATION_ROOT_PATH}/${UI_PATH.UPDATE}/${params.id}`
            )
          }
          hideRowCheckbox
        />
      </div>
    </Stack>
  )
}

export default VisitationReport;


const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: IReportFilters
): GetVisitationListParams => {
  const params: GetVisitationListParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: FollowViolationFields.ID,
    orderBy: "DESC",
  };
  if (filters?.status?.length) {
    params.status = filters.status?.join(',');
  }
  if (filters?.department) {
    params.department = filters.department;
  }
  if (filters?.startDate) {
    params.from = filters?.startDate;
  }
  if (filters?.endDate) {
    params.to = filters?.endDate;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  params.tab = 0
  return params;
};
const getFieldLabel = (key: string) => {
  return `visitation.fields.${key}`;
};