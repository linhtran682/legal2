export default async function mockApiCall<T>(
  response: T,
  isRejected: boolean = false
): Promise<T> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (isRejected) {
        reject(new Error("Mock error: Request failed"));
      } else {
        resolve(response);
      }
    }, 2000);
  });
}
