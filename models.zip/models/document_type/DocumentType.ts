import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface DocumentTypeDTO {
  id: number;
  name: string;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
}

export const enum DocumentTypeFieldNames {
  ID = "id",
  NAME = "name",
  DESCRIPTION = "description",
  CREATED_BY = "createdBy",
  CREATED_AT = "createdAt",
}

export interface GetDocumentTypesParams {
  name?: string;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export interface GetDocumentTypesResponse {
  total: number;
  documentTypes: DocumentTypeDTO[];
}

export interface SaveDocumentTypeDTO {
  name?: string;
  description?: string;
}

export const enum SaveDocumentTypeRequestFieldNames {
  NAME = "name",
  DESCRIPTION = "description",
}

export const SaveDocumentTypeRequestSchema = Yup.object().shape({
  name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  description: Yup.string().optional(),
});

export interface SaveDocumentTypeRequestSchemaI {
  description?: string | undefined;
  name: string;
}
