import { MutationConfig, QueryConfig } from "@/apis";
import { getAuditLogQueryFn, getLogSettingQueryFn, updateLogSettingMutationFn } from "@/apis/service/setting/LogApi";
import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { UserProfileDTO } from "../user/User";

export const SettingLogSchema = Yup.object().shape({
  limitNotificationAlive: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  limitApiLogAlive: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
});

export interface SettingLogSchemaI {
  limitNotificationAlive: number;
  limitApiLogAlive: number;
}

export type LogSettingReceive = {
  version: number;
  limitNotificationAlive: number;
  limitApiLogAlive: number;
}
export type GetLogSettingFnType = typeof getLogSettingQueryFn;

export type GetLogSettingOptions = QueryConfig<GetLogSettingFnType>;

export type UpdateLogSettingFnType = typeof updateLogSettingMutationFn;

export type UpdateLogSettingOptions = {
  config?: MutationConfig<UpdateLogSettingFnType>;
};

export type GetAuditLogFnType = typeof getAuditLogQueryFn;

export type GetAuditLogOptions = QueryConfig<GetAuditLogFnType>;

export interface AuditLoglistRequest {
  from?: string;
  to?: string;
  userId?: string;
  service?: string;
  action?: string;
  browser?: string;
  errorState?: boolean;
  sortBy: string;
  orderBy: string;
  page: number;
  size: number;
}

export interface AuditLog {
  id: number;
  user: UserProfileDTO;
  success: boolean;
  service: string;
  action: string;
  duration: number;
  ip: string;
  userAgent: string;
  time: string;
}

export interface AuditLoglistResponse {
  total: number;
  apiLogResponses: AuditLog[];
}

export const enum AuditLogFields {
  ID = "id",
  USER_ID = "userId",
  USER_NAME = "userName",
  SUCCESS = "status",
  SERVICE = "service",
  ACTION = "action",
  DURATION = "duration",
  IP = "ip",
  USER_AGENT = "userAgent",
  TIME = "time",
}