import { MutationConfig, QueryConfig } from "@/apis";
import { geMailTemplateDetailQueryFn, getListMailTemplateQueryFn, updateMailTemplateMutationFn } from "@/apis/service/setting/SettingApi";

export interface MailItem {
  id: string;
  emailType: string;
}

export interface GetMailListResponse {
  emailTemplates: MailItem[]
}

export type QueryMailTemplateFnType = typeof getListMailTemplateQueryFn;

export type GetMailTemplateOptions = {
  config?: QueryConfig<QueryMailTemplateFnType>;
};

export type QueryMailTemplateDetailFnType = typeof geMailTemplateDetailQueryFn;

export type GetMailTemplateDetailOptions = {
  config?: QueryConfig<QueryMailTemplateDetailFnType>;
  params: {
    id: string
  }
};

export type MailDetailReceive = {
  id: string;
  emailType: string;
  title: string;
  content: string;
}

export type MailTemplateBodySend = {
  title: string;
  content: string;
  templateId?: string;
}

export type UpdateMailTemplateFnType = typeof updateMailTemplateMutationFn;

export type UpdateMailTemplateOptions = {
  config?: MutationConfig<UpdateMailTemplateFnType>;
};
