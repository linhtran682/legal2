import * as Yup from "yup";
import { departmentSchema, DepartmentSchema } from "../department/Department";
import { VALIDATION_MSG } from "@/constants/message";
import {
  ReminderInput,
  ReminderSchema,
  ReminderSchemaI,
} from "../reminder_template/ReminderDTO";
import { BasedUser, BasedUserSchema } from "../user/User";
import { SaveReminderDTO } from "./ForwardDocumentManagement";
import { t } from "i18next";
import { StandardTableState } from "@/components/commons/tables/standard_table/StandardTable";

export const enum BasedDocumentManagementFieldNames {
  ID = "id",
  PARENT_ID = "parentId",
  FOLDER_ID = "folderId",
  DOCUMENT_TYPE = "documentType",
  NAME = "name",
  STATUS = "status",
  AGENCY_ISSUED = "agencyIssued",
  DATE_ISSUED = "dateIssued",
  NOTE_DATE_ISSUED = "noteDateIssued",
  DOCUMENT_CHANGE_DATE = "documentChangeDate",
  NOTE_DOCUMENT_CHANGE_DATE = "noteDocumentChangeDate",
  NOTE_EXPIRY_DATE = "noteExpiryDate",
  EXPIRY_DATE = "expiryDate",
  NOTE_UPDATE_TIME = "noteUpdateTime",
  COMPANY_SCOPE = "companyScope",
  DEPARTMENT_SCOPE = "departmentScope",
  RECEIVERS = "receivers",
  MANAGEMENT_DEPARTMENTS = "managementDepartments",
  RELATED_DEPARTMENTS = "relatedDepartments",
  ATTACHMENTS = "attachments",
  FILES = "files",
  REMIND = "remind",
  CREATOR = "creator",
}

export interface DocumentManagementAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface BasedDocumentManagementBodyReceive {
  id: number;
  folder: DepartmentSchema;
  documentType: string;
  name: string;
  status: number;
  agencyIssued: string;
  dateIssued: string;
  noteDateIssued: string;
  documentChangeDate?: string;
  noteDocumentChangeDate?: string;
  noteExpiryDate: string;
  expiryDate: string;
  noteUpdateTime?: string;
  companyScope?: boolean;
  departmentScope?: boolean;
  receivers: BasedUser[];
  managementDepartments: DepartmentSchema[];
  relatedDepartments?: DepartmentSchema[];
  attachments?: DocumentManagementAttachment[];
  remind?: ReminderInput;
  roles?: number[];

  legalAccessType: number;
  sharedDepartments?: Department[];
  sharedUsers?: BasedUser[];
  createdBy?: BasedUser;
}
export interface BasedDocumentManagementBodySend {
  folderId: number;
  documentType: string;
  name: string;
  status: number;
  agencyIssued: string;
  dateIssued: string;
  noteDateIssued: string;
  documentChangeDate?: string;
  noteDocumentChangeDate?: string;
  noteExpiryDate: string;
  expiryDate: string;
  noteUpdateTime?: string;
  companyScope?: boolean;
  departmentScope?: boolean;
  receivers: number[];
  managementDepartments: DepartmentSchema[];
  relatedDepartments?: DepartmentSchema[];
  attachments?: number[];
  remind?: SaveReminderDTO;
}
export interface BasedDocumentManagementSchemaI {
  folderId: DepartmentSchema;
  documentType: string;
  name: string;
  status: number;
  agencyIssued: string;
  dateIssued?: string;
  noteDateIssued?: string;
  documentChangeDate?: string;
  noteDocumentChangeDate?: string;
  noteExpiryDate?: string;
  expiryDate?: string;
  noteUpdateTime?: string;
  companyScope?: boolean;
  departmentScope?: boolean;
  receivers: BasedUser[];
  managementDepartments: DepartmentSchema[];
  relatedDepartments?: DepartmentSchema[];
  attachments?: number[];
  remind?: ReminderSchemaI;
  files: any;
}
export const documentManagementSchema = Yup.object({
  files: Yup.mixed().required(VALIDATION_MSG.REQUIRED_FIELD),
  folderId: departmentSchema.required(VALIDATION_MSG.REQUIRED_FIELD),
  documentType: Yup.string().nullable().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().nullable().required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.number().nullable().required(VALIDATION_MSG.REQUIRED_FIELD),
  agencyIssued: Yup.string().nullable().required(VALIDATION_MSG.REQUIRED_FIELD),
  dateIssued: Yup.string()
    .nullable()
    .test(
      "date-or-note-required",
      t("common.place_holder.please_enter") +
        " " +
        t(
          `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.DATE_ISSUED}`
        ),
      function (value) {
        const { noteDateIssued } = this.parent;
        return !!value || !!noteDateIssued;
      }
    ),

  noteDateIssued: Yup.string()
    .nullable()
    .test("note-or-date-required", "", function (value) {
      const { dateIssued } = this.parent;
      return !!value || !!dateIssued;
    }),
  documentChangeDate: Yup.string().nullable().optional(),
  noteDocumentChangeDate: Yup.string().nullable().optional(),
  // noteExpiryDate: Yup.string().nullable().required(""),
  // expiryDate: Yup.string()
  //   .nullable()
  //   .required(
  //     t("common.place_holder.please_enter") +
  //       " " +
  //       t(
  //         `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.EXPIRY_DATE}`
  //       )
  //   ),
  noteExpiryDate: Yup.string()
    .nullable()
    .test("note-or-expiry-required", "", function (value) {
      const { expiryDate } = this.parent;
      return !!value || !!expiryDate; // Pass if one field is filled
    }),

  expiryDate: Yup.string()
    .nullable()
    .test(
      "expiry-or-note-required",
      t("common.place_holder.please_enter") +
        " " +
        t(
          `DOCUMENT_MANAGEMENT.field_name.${BasedDocumentManagementFieldNames.EXPIRY_DATE}`
        ),
      function (value) {
        const { noteExpiryDate } = this.parent;
        return !!value || !!noteExpiryDate; // Pass if one field is filled
      }
    ),
  noteUpdateTime: Yup.string().nullable().optional(),
  companyScope: Yup.boolean().optional(),
  departmentScope: Yup.boolean().optional(),
  receivers: Yup.array()
    .of(BasedUserSchema)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  managementDepartments: Yup.array()
    .of(departmentSchema)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  relatedDepartments: Yup.array().of(departmentSchema).optional(),
  attachments: Yup.array().of(Yup.number().defined()).optional(),
  remind: ReminderSchema,
});

interface Department {
  id: string;
  name: string;
  nameEnglish: string;
}

interface Receiver {
  id: string;
  name: string;
  email: string;
  departmentName: string;
}

export interface DocumentMngColumn {
  id: number;
  folderId: number;
  folderName: string;
  documentType: string;
  status: number;
  name: string;
  agencyIssued: string;
  dateIssued: string;
  noteDateIssued: string;
  documentChangeDate: string;
  noteDocumentChangeDate: string;
  expiryDate: string;
  noteExpiryDate: string;
  noteUpdateTime: string;
  companyScope: boolean;
  departmentScope: boolean;
  managementDepartments: Department[];
  relatedDepartments: Department[];
  receivers: Receiver[];
  createdBy: string | null;
}

export interface DocumentMngResponse {
  total: number;
  data: DocumentMngColumn[];
}
export interface DocumentManagementParams {
  tab?: number;
  folderIds?: number[] | string;
  parentId?: number;
  status?: number[];
  documentType?: string;
  dateIssuedFrom?: string;
  dateIssuedTo?: string;
  documentChangeDateFrom?: string;
  documentChangeDateTo?: string;
  expiryDateFrom?: string;
  expiryDateTo?: string;
  sortBy?: string;
  orderBy?: string;
  page?: number;
  size?: number;
  name?: string;
  departmentId?: string;
  createFrom?: string;
  createTo?: string;
  departmentIds?: string
}

export interface Folders {
  id: number;
  name: string;
  children: Folders[];
  roles?: number[];
  level?: number;
}
export interface FoldersModel {
  folders: Folders[];
}
export interface DocumentMoveModel {
  documentIds: number[];
  type: number;
  newFolderId: number;
}
//detail folders
export interface UserRoleReceive {
  id: string;
  name: string;
  roles?: number[];
}
export interface DepartmentStockModelDetail {
  id: number;
  name: string;
  parent: DepartmentSchema;
  departmentRoles: DepartmentRole[];
  userRoles: UserRoleReceive[];
  roles?: number[];
}

interface DepartmentPermissionCreate {
  departmentId: string;
  roles: number[];
}
interface UserPermissionCreate {
  userId: string;
  roles: number[];
}

export interface CreateStockModel {
  parentId: number;
  folderName: string;
  departmentPermissions: DepartmentPermissionCreate[];
  userPermissions: UserPermissionCreate[];
}
interface DepartmentRole {
  id: string;
  name: string;
  nameEnglish: string;
  roles?: number[];
}

interface UserRole {
  users: string;
  roles?: number[];
}
// id: string;
//   name: string;
//   nameEnglish?: string;
//   department: {
//     id: string;
//     name: string;
//     nameEnglish: string;
//   };
const schemaDetailDepartment = Yup.object().shape({
  id: Yup.string().required(),
  name: Yup.string().optional(),
  nameEnglish: Yup.string().optional(),
});
export interface DetailDepartment {
  id: string;
  name: string;
  nameEnglish?: string;
}
const departmentRoleSchema = Yup.object().shape({
  departments: Yup.mixed().test(
    "is-valid-department",
    "DOCUMENT_MANAGEMENT.stock_create_form.validateDepartment",
    (value) => {
      // if (!value || typeof value !== "object") {
      //   return false;
      // }
      return schemaDetailDepartment.isValidSync(value);
    }
  ),
  roles: Yup.array().optional(),
});
const userPermissionSchema = Yup.object().shape({
  users: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  roles: Yup.array().optional(),
});

export interface DepartmentRoleField {
  departments: DetailDepartment;
  roles?: number[];
}
export interface StockModelSchema {
  parentId?: DepartmentSchema;
  folderName: string;
  departmentPermissions: DepartmentRoleField[];
  userPermissions: UserRole[];
}

export const stockModelSchema = Yup.object().shape({
  parentId: Yup.mixed()
    .optional()
    .test("is-object-or-zero", VALIDATION_MSG.REQUIRED_FIELD, (value) => {
      return (typeof value === "object" && value !== null) || value === 0;
    }),
  folderName: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  departmentPermissions: Yup.array()
    .of(departmentRoleSchema)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  userPermissions: Yup.array()
    .of(userPermissionSchema)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
});

export interface DocumentManagementAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface GetDocumentManagementTabAttachmentsResponse {
  data: DocumentManagementAttachment[];
}
export interface DocumentMngStatisticChartResponse {
  pieChart: {
    data: {
      name: string;
      value: number
    }[];
  }
  barChart: {
    data: {
      name: string;
      value: number
    }[];
  }
}
export interface IReportFilters {
  startDate?: string;
  endDate?: string;
  departmentIds?: string[];
  status?: number[];
  documentType?: string;
  folderIds?: number[]
}

export const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: IReportFilters
): DocumentManagementParams => {
  const params: DocumentManagementParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: BasedDocumentManagementFieldNames.ID,
    orderBy: "DESC",
  };
  if (filters?.departmentIds?.length) {
    params.departmentIds = filters.departmentIds?.join(",");
  }
  if (filters?.folderIds?.length) {
    params.folderIds = filters?.folderIds?.join(",");
  }
  if (filters?.documentType) {
    params.documentType = filters?.documentType;
  }
  if (filters?.startDate) {
    params.createFrom = filters?.startDate;
  }
  if (filters?.endDate) {
    params.createTo = filters?.endDate;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  return params;
};
export const getFieldLabelDocumentMng = (key: string) => {
  return `DOCUMENT_MANAGEMENT.column.${key}`;
};