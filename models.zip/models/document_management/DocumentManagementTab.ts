import { BasedUser } from "../user/User";

export interface User {
  id: string;
  name: string;
  nameEnglish: string;
  email: string;
  basicPosition: {
    id: string;
    name: string;
    nameEnglish: string;
  };
  department: {
    id: string;
    name: string;
    nameEnglish: string;
  };
}

export interface DetailInformationRequestResponse {
  user: User;
  content: string;
  deadline: string;
  date: string;
  type: number;
}

export interface DetailInformationRequestResponses {
  detailInformationRequestResponses: DetailInformationRequestResponse[];
}

export interface ForwardResponseDetail {
  forwardUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  forwardDate: string;
}

export interface ForwardResponseDetails {
  forwardResponseDetails: ForwardResponseDetail[];
}
