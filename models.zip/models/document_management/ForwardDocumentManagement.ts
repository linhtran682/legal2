import { FieldValues } from "react-hook-form";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser } from "../user/User";
import { createForwardDocumentManagementMutationFn } from "@/apis/service/document_management/forwardDocumentManagement";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ForwardDocumentManagementFieldNames {
  DEPARTMENTS = "departments",
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface ForwardDocumentManagementSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateForwardDocumentManagementBody {
  documentId?: number;
  data?: ForwardDocumentManagementSchemaI;
}

export interface CreateForwardDocumentManagementOptions {
  config?: MutationConfig<typeof createForwardDocumentManagementMutationFn>;
}

export const ForwardDocumentManagementSchema = Yup.object().shape({
  // [ForwardLegalAdviceFieldNames.DEADLINE]: Yup.number().required(
  //   "Deadline name is required"
  // ),
  // [ForwardLegalAdviceFieldNames.CONTENT]: Yup.string().required(
  //   "Content name is required"
  // ),
  [ForwardDocumentManagementFieldNames.REMIND]: ReminderSchema,
});

export const castForwardDocumentManagementRequestSchemaToDTO = (
  schema: any
): ForwardDocumentManagementSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
