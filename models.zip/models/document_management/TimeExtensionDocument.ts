import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderSchema,
  ReminderSchemaI,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createTimeExtensionMutationFn,
  getTimeExtensionQueryFn,
  updateTimeExtensionMutationFn,
} from "@/apis/service/document_management/timeExtensionDocument";
import { SaveReminderDTO } from "./ForwardDocumentManagement";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const enum TimeExtensionRequestFieldNames {
  DEADLINE = "deadline",
  REASON = "reason",
  REMIND = "remind",
  CONFIRM = "confirm",
  ACCEPTABLE_DEADLINE = "acceptableDeadline",
  ACCEPTABLE_DEADLINE_REASON = "acceptableReason",
  USERS = "users",
}

export const ExtensionOptions: RadioItem[] = [
  {
    label: "Thời hạn mới",
    value: 0,
  },
  {
    label: "Đồng ý",
    value: 1,
  },
];

export const TimeExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [TimeExtensionRequestFieldNames.REMIND]: ReminderSchema,
});

export const ConfirmExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.CONFIRM]: Yup.boolean().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE]: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD);
      }
      return schema.notRequired();
    }),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON]: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD);
      }
      return schema.notRequired();
    }),
});
export interface Department {
  id: string;
  name?: string;
  nameEnglish?: string;
}

export interface TimeExtensionUser {
  id?: string;
  name?: string | undefined;
  nameEnglish?: string;
  email?: string | undefined;
  department?: Department;
}
export interface TimeExtensionRequestSchemaI extends FieldValues {
  deadline?: string;
  reason?: string;
  remind?: ReminderSchemaI;
}

export interface RequestApprovalDTO {
  id?: number;
  deadline?: string;
  reason?: string | undefined;
  user?: TimeExtensionUser;
  department?: Department;
}

interface TypeAcceptTimeExtension {
  deadlineAccept?: string;
  reason?: string;
  type?: number;
  users?: string[];
  remind: SaveReminderDTO;
}
export interface UpdateTimeExtensionBody {
  documentId?: number;
  timeExtensionRequestId?: number;
  data?: TypeAcceptTimeExtension;
}

export interface CreateTimeExtensionBody {
  documentId?: number;
  data?: TimeExtensionRequestSchemaI;
}

export interface CreateTimeExtensionOptions {
  config?: MutationConfig<typeof createTimeExtensionMutationFn>;
}

export type TimeExtensionParams = {
  documentId?: number;
  timeExtensionRequestId?: number;
};

export type QueryFnType = typeof getTimeExtensionQueryFn;

export type GetTimeExtensionIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: TimeExtensionParams;
};

export type UpdateTimeExtensionAcceptOptions = {
  config?: MutationConfig<typeof updateTimeExtensionMutationFn>;
};
