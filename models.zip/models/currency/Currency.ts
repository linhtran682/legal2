import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface CurrencyDTO {
  id: number;
  name: string;
  unit: string;
  active: number;
  createdBy?: string;
  createdAt?: Date;
}

export const enum CurrencyFieldNames {
  ID = "id",
  NAME = "name",
  UNIT = "unit",
  ACTIVE = "active",
  CREATED_BY = "createdBy",
  CREATED_AT = "createdAt",
}

export interface GetCurrenciesParams {
  name?: string;
  unit?: string;
  active?: number;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export interface GetCurrenciesResponse {
  total: number;
  currencyResponses: CurrencyDTO[];
}

export interface SaveCurrencyDTO {
  name?: string;
  unit?: string;
  active?: number;
}

export const enum SaveCurrencyRequestFieldNames {
  NAME = "name",
  UNIT = "unit",
  ACTIVE = "active",
}

export const SaveCurrencyRequestSchema = Yup.object().shape({
  name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  unit: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  active: Yup.number()
    .integer()
    .min(0)
    .max(1)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
});

export interface SaveCurrencyRequestSchemaI {
  name: string;
  unit: string;
  active: number;
}
