import * as Yup from "yup";
import { UserProfileDTO } from "../user/User";

export interface DepartmentType {
  id?: string;
  name?: string;
}

export interface Department {
  id: string;
  code?: string;
  name?: string;
  nameEnglish?: string;
  description?: string | null;
  type?: DepartmentType;
  departmentType?: DepartmentType;
  status?: "ACTIVE" | "INACTIVE";
  children?: Department[];
  parentDepartmentNames?: string;
  parentDepartmentNameEnglish?: string;
}

export interface GetDepartmentParams {
  searchTerm: string;
}

export interface GetDepartmentResponse {
  departments: Department[];
}
export interface GetDepartmentHeadResponse {
  deptHead: UserProfileDTO;
  division: UserProfileDTO;
}

export const enum DepartmentFieldNames {
  NAME = "name",
  DESCRIPTION = "description",
  TYPE = "type",
  STATUS = "status",
  PARENT = "parent",
  CODE = "code",
}

export interface DepartmentSchema {
  id: string;
  code?: string;
  name?: string;
  nameEnglish?: string;
  description?: string | null;
  type?: DepartmentType;
  status?: "ACTIVE" | "INACTIVE";
  parentDepartmentNames?: string;
  parentDepartmentNameEnglish?: string;
}

export const castDepartmentToSchema = ({
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  children,
  ...rest
}: Department): DepartmentSchema => {
  return {
    ...rest,
  };
};

const departmentTypeSchema = Yup.object().shape({
  id: Yup.string().optional(), // Optional string
  name: Yup.string().optional(), // Optional string
});
export const departmentSchema = Yup.object().shape({
  id: Yup.string().required("Department ID is required"),
  code: Yup.string().optional(),
  name: Yup.string().optional(),
  nameEnglish: Yup.string().optional(),
  description: Yup.string().optional().nullable(),
  type: departmentTypeSchema.optional(), // Use departmentTypeSchema for validation
  status: Yup.mixed<"ACTIVE" | "INACTIVE">()
    .oneOf(["ACTIVE", "INACTIVE"])
    .optional(),
  parentDepartmentNames: Yup.string().optional(),
  parentDepartmentNameEnglish: Yup.string().optional(),
});
