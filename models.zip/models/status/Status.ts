import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface StatusDTO {
  id: number;
  name: string;
  module: number;
  active: number;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
  code?: number;
  tab?: number[];
}

export const enum StatusFieldNames {
  ID = "id",
  NAME = "name",
  MODULE = "module",
  ACTIVE = "active",
  DESCRIPTION = "description",
  CREATED_BY = "createdBy",
  CREATED_AT = "createdAt",
}

export interface GetStatusListParams {
  name?: string;
  modules?: number[];
  active?: number;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export interface GetStatusListNamesParams {
  names?: string[];
  modules?: number[];
}

export interface GetStatusListResponse {
  total: number;
  statusResponses: StatusDTO[];
}

export interface SaveStatusDTO {
  name?: string;
  module?: number;
  active?: number;
  description?: string;
}

export const enum SaveStatusRequestFieldNames {
  NAME = "name",
  MODULE = "module",
  ACTIVE = "active",
  DESCRIPTION = "description",
}

export const SaveStatusRequestSchema = Yup.object().shape({
  name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  module: Yup.number().integer().min(1).max(7).required(),
  active: Yup.number().integer().min(0).max(1).required(),
  description: Yup.string().optional(),
});

export interface SaveStatusRequestSchemaI {
  description?: string | undefined;
  name: string;
  module: number;
  active: number;
}
