import { Department } from "../department/Department";
import { FieldDTO } from "../field/Field";
import { ReminderInput } from "../reminder_template/ReminderDTO";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";
import { LegalAdviceAttachment } from "./LegalAdviceDetail";

export const enum BaseLegalAdviceFields {
  ID = "id",
  LEGAL_ADVICE_NAME = "legalAdviceName",
  FIELD = "field",
  REASON = "reason",
  STATUS = "status",
  DEADLINE = "deadline",
  DEADLINE_TYPE = "consultingDeadlineType",
  RETURN_DATE_ALL = "returnDateAll",
  RESPONSE_DATE = "responseDate",
  SENDER = "sender",
  PIC = "pic",
  RECEIVER = "receiver",
  ACTION = "action"
}

export interface BaseLegalAdvice {
  id: number;
  legalAdviceName: number;
  field: FieldDTO;
  attachments?: LegalAdviceAttachment[];
  departments?: Department[];
  vendorResponseDate?: string;
  summaryIssue?: string;
  opinion: string;
  consultingDeadlineType: number,
  responseDate: string;
  urgentResponseDate: string;
  receiverUsers: BasedUser[];
  legalAdviceRelateUsers: BasedUser[];
  isDraft?: boolean;
  legalAdviceRoles?: number[];
  status: StatusDTO;
  legalAccessType: number;
  bookingFlag?: number;
  responseFlag?: number;
  confirmFlag?: number;
  completeFlag?: number;
  supervisorAdviseFlag?: number;
  checkDivisionFlag?: number;
  checkDeptHeadFlag?: number;
  remind?: ReminderInput;

}

export interface GetLegalAdviceListParams {
  legalAdviceName?: string;
  fields?: number[];
  departments?: number[] | undefined;
  statusList?: number[] | string | undefined;
  vendorResponseDateFrom?: string;
  vendorResponseDateTo?: string;
  responseDateFrom?: string;
  responseDateTo?: string;
  urgentResponseDateFrom?: string;
  urgentResponseDateTo?: string;
  receiverUserIds?: string[] | undefined;
  relatedUserIds?: string[] | undefined;
  sortBy: string;
  orderBy: string;
  page: number;
  size: number;
  tab?: number;
  isEnglish?: boolean;
  isPanelSearch?: boolean;
  picIds?: number[];

  departmentIds?: string;
  createFrom?: string;
  createTo?: string;
}

export interface GetLegalAdviceListResponse {
  total: 0;
  data: BaseLegalAdvice[];
}

export interface AdviceAssignment {
  assignUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
}
export interface LegalAdviceForward {
  forwardUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  forwardDate: string;
}

export interface GetAdviceAssignmentResponse {
  assignmentResponseDetails: AdviceAssignment[];
}
export interface GetAdviceForwardResponse {
  forwardResponseDetails: LegalAdviceForward[];
}
export interface AdviceExtension {
  user: BasedUser;
  reason: string;
  requestDeadline: string;
  acceptDeadline: string;
  date: string;
  type?: number;
  timeExtensionType?: number;
  id: number;
  showExtension?: boolean;
  enableExtension?: boolean;
}

export interface GetAdviceExtensionResponse {
  timeExtensionResponseDetails: AdviceExtension[];
}

export interface AdviceRequestFeedback { // Phản hồi đến yêu cầu tư vấn
  feedbackUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
}
export interface GetAdviceRequestFeedbackResponse {
  feedbackResponseDetails: AdviceRequestFeedback[];
}
export interface AdviseFeedback { // Phản hồi đến người tư vấn
  feedbackAdviseUser: BasedUser;
  receiveUser: BasedUser;
  reason: string;
  date: string;
}
export interface GetAdviseFeedbackResponse {
  feedbackAdviseResponseDetails: AdviseFeedback[];
}

export interface LegalAdviceStatisticChartResponse {
  pieChart: {
    data: {
      name: string;
      value: number
    }[];
  }
  barChart: {
    data: {
      name: string;
      value: number
    }[];
  }
}