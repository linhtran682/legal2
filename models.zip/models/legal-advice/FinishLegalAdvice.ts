import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createFinishLegalAdviceMutationFn } from "@/apis/service/legal-advice/finishLegalAdvice";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FinishLegalAdviceFieldNames {
  STATUS = "status",
  CONTENT = "content",
  USER_IDS = "userIds",
  REMIND = "remind",
}
export interface FinishLegalAdviceSchemaI extends FieldValues {
  status?: number;
  content?: string;
  userIds?: string[] | BasedUser[];
  remind?: SaveReminderDTO;
}

export const FinishLegalAdviceSchema = Yup.object().shape({
  [FinishLegalAdviceFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FinishLegalAdviceFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FinishLegalAdviceFieldNames.REMIND]: ReminderSchema,
});

export interface CreateFinishLegalAdviceBody {
  legalAdviceId?: number;
  data?: FinishLegalAdviceSchemaI;
}

export interface CreateFinishLegalAdviceOptions {
  config?: MutationConfig<typeof createFinishLegalAdviceMutationFn>;
}
