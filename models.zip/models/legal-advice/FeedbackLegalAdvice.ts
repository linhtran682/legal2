import { FieldValues } from "react-hook-form";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createFeedbackLegalAdviceMutationFn } from "@/apis/service/legal-advice/feedbackLegalAdvice";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedbackLegalAdviceFieldNames {
  USERS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FeedbackLegalAdviceSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateFeedbackLegalAdviceBody {
  legalAdviceId?: number;
  data?: FeedbackLegalAdviceSchemaI;
}

export interface CreateFeedbackLegalAdviceOptions {
  config?: MutationConfig<typeof createFeedbackLegalAdviceMutationFn>;
}

export const FeedbackLegalAdviceSchema = Yup.object().shape({
  // [FeedbackLegalAdviceFieldNames.DEADLINE]: Yup.number().required(
  //   "Deadline name is required"
  // ),
  [FeedbackLegalAdviceFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FeedbackLegalAdviceFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FeedbackLegalAdviceFieldNames.REMIND]: ReminderSchema,
});

export const castFeedbackLegalAdviceRequestSchemaToDTO = (
  schema: any
): FeedbackLegalAdviceSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
