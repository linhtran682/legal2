import { FieldValues } from "react-hook-form";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createAdvisorLegalAdviceMutationFn,
  getAdvisorLegalAdviceListQueryFn,
  getAdvisorLegalAdviceQueryFn,
  updateAdvisorLegalAdviceDetailMutationFn,
  updateAdvisorLegalAdviceMutationFn,
} from "@/apis/service/legal-advice/advisorLegalAdvice";
import { BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const TypeAdvisorLegal = {
  toPic: 0,
  toUser: 1,
  toSupervisor: 2,
};

export const AdviceOptions: RadioItem[] = [
  {
    label: "Gửi tới người yêu cầu tư vấn",
    value: TypeAdvisorLegal.toPic,
  },
  {
    label: "Gửi tới giám sát",
    value: TypeAdvisorLegal.toSupervisor,
  },
];

export const SupervisorAdviceOptions: RadioItem[] = [
  {
    label: "Gửi tới người yêu cầu tư vấn",
    value: TypeAdvisorLegal.toPic,
  },
  {
    label: "Gửi tới người tư vấn",
    value: TypeAdvisorLegal.toUser,
  },
];

export const enum AdvisorLegalAdviceFieldNames {
  CONTENT = "content",
  STATUS = "status",
  DEADLINE_NEW = "deadlineNew",
  REASON = "reason",
  USERS = "users",
  USER_IDS = "userIds",
  ATTACHMENTS = "attachments",
  FINISH = "finish",
  TYPE = "type",
  REMIND = "remind",
}
export interface AdvisorLegalAdviceSchemaI extends FieldValues {
  users?: string[];
  deadlineNew?: any;
  content?: string;
  remind?: SaveReminderDTO;
}

export const AdvisorLegalAdviceSchema = Yup.object().shape({
  [AdvisorLegalAdviceFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AdvisorLegalAdviceFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AdvisorLegalAdviceFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AdvisorLegalAdviceFieldNames.REMIND]: ReminderSchema,
});

export const FeedBackAdvisorLegalAdviceSchema = Yup.object().shape({
  [AdvisorLegalAdviceFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AdvisorLegalAdviceFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AdvisorLegalAdviceFieldNames.DEADLINE_NEW]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AdvisorLegalAdviceFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AdvisorLegalAdviceFieldNames.REMIND]: ReminderSchema,
});

export const SupervisorLegalAdviceSchema = Yup.object().shape({
  [AdvisorLegalAdviceFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AdvisorLegalAdviceFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AdvisorLegalAdviceFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AdvisorLegalAdviceFieldNames.REMIND]: ReminderSchema,
});

export interface CreateAdvisorLegalAdviceOptions {
  config?: MutationConfig<typeof createAdvisorLegalAdviceMutationFn>;
}

export interface CreateAdvisorLegalAdviceBody {
  legalAdviceId?: number;
  data?: AdvisorLegalAdviceSchemaI;
}

export type AdvisorLegalAdviceParams = {
  legalAdviceId?: number;
  adviseId?: number;
};

export type QueryFnType = typeof getAdvisorLegalAdviceQueryFn;
export type QueryFnTypeList = typeof getAdvisorLegalAdviceListQueryFn;

export type GetAdvisorLegalAdviceIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: AdvisorLegalAdviceParams;
};

export type GetAdvisorLegalAdviceListOptions = {
  config?: QueryConfig<QueryFnTypeList>;
  request: { legalAdviceId?: number };
};

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};
export interface AdvisorLegalAdviceUser {
  id?: string;
  name?: string;
  email?: string;
  departmentName?: string;
}

type TypeAttachmentsDTO = {
  fileId?: number;
  fileName?: string;
  filePath?: string;
  uploadDate?: string;
  uploadUser?: AdvisorLegalAdviceUser;
};

export interface ResponsesAdvisorLegalAdviceDTO {
  id: number;
  user?: TypeUserDTO;
  receiverUsers?: TypeUserDTO;
  department?: TypeDepartment;
  title?: string;
  content?: string;
  createAt?: string;
  attachments?: TypeAttachmentsDTO[];
  superVisor?: boolean;
  editAvailable?: boolean;
  finish?: boolean;
  type?: number;
}

export type UpdateAdvisorLegalAdviceOptions = {
  config?: MutationConfig<typeof updateAdvisorLegalAdviceMutationFn>;
};

interface TypeAdvisorLegalAdvice {
  status: number;
  type: number;
  deadlineNew: string;
  reason: string;
  users?: string[];
  remind: SaveReminderDTO;
}

interface TypeAdvisorLegalAdviceDetail {
  type: number;
  userIds: string[];
  status: number;
  content: string;
  attachmentIds?: number[];
  remind: SaveReminderDTO;
  finish: boolean;
}

export interface UpdateAdvisorLegalAdviceBody {
  legalAdviceId?: number;
  adviseId?: number;
  data?: TypeAdvisorLegalAdvice;
}

export const castAdvisorLegalAdviceRequestSchemaToDTO = (
  schema: any
): AdvisorLegalAdviceSchemaI => {
  return {
    ...schema,
    finish: schema.finish ?? false,
    userIds: schema?.userIds?.map((user: any) => user?.id),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export interface UpdateAdvisorLegalAdviceDetailBody {
  legalAdviceId?: number;
  adviseId?: number;
  data?: TypeAdvisorLegalAdviceDetail;
}

export type UpdateAdvisorLegalAdviceDetailOptions = {
  config?: MutationConfig<typeof updateAdvisorLegalAdviceDetailMutationFn>;
};
