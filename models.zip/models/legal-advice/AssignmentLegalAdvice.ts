import { FieldValues } from "react-hook-form";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createAssignmentLegalAdviceMutationFn } from "@/apis/service/legal-advice/assignmentLegalAdvice";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum AssignmentLegalAdviceFieldNames {
  STATUS = "status",
  CONTENT = "content",
  USERS_IDS = "userIds",
  REMIND = "remind",
}
export interface AssignmentLegalAdviceSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export const AssignmentLegalAdviceSchema = Yup.object().shape({
  [AssignmentLegalAdviceFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AssignmentLegalAdviceFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AssignmentLegalAdviceFieldNames.REMIND]: ReminderSchema,
});

export interface CreateAssignmentLegalAdviceBody {
  legalAdviceId?: number;
  data?: AssignmentLegalAdviceSchemaI;
}

export interface CreateAssignmentLegalAdviceOptions {
  config?: MutationConfig<typeof createAssignmentLegalAdviceMutationFn>;
}

export const castAssignmentLegalAdviceRequestSchemaToDTO = (
  schema: any
): AssignmentLegalAdviceSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
