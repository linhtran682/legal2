import { FieldValues } from "react-hook-form";
import { castReminderSchemaToSaveReminderDTO, ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createForwardLegalAdviceMutationFn } from "@/apis/service/legal-advice/forwardLegalAdvice";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ForwardLegalAdviceFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface ForwardLegalAdviceSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  // departments?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateForwardLegalAdviceBody {
  legalAdviceId?: number;
  data?: ForwardLegalAdviceSchemaI;
}

export interface CreateForwardLegalAdviceOptions {
  config?: MutationConfig<typeof createForwardLegalAdviceMutationFn>;
}

export const ForwardLegalAdviceSchema = Yup.object().shape({
  // [ForwardLegalAdviceFieldNames.DEADLINE]: Yup.string().required(
  //   VALIDATION_MSG.REQUIRED_FIELD
  // ),
  [ForwardLegalAdviceFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ForwardLegalAdviceFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ForwardLegalAdviceFieldNames.REMIND]: ReminderSchema,
});

export const castForwardLegalAdviceRequestSchemaToDTO = (
  schema: any
): ForwardLegalAdviceSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };  
};