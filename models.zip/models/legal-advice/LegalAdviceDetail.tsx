import { getAllHierarchyById, getLegalAdviceRequests } from "@/apis/service/legal-advice/legalAdvice";
import { GenericSearchPanelProps } from "@/components/commons/search_panel/GenericSearchPanel";
import { LegalAdviceStatusContent, LegalAdviceStatusKey } from "@/constants/general";
import { VALIDATION_MSG } from "@/constants/message";
import { LEGAL_ADVICE_ROOT_PATH } from "@/constants/paths";
import { formatRelativeDate } from "@/utils";
import * as Yup from "yup";
import { Department } from "../department/Department";
import { FieldDTO } from "../field/Field";
import { ReminderInput, SaveReminderDTO } from "../reminder_template/ReminderDTO";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";

export enum LegalAdviceDetailFields {
  ID = "id",
  LEGAL_ADVICE_NAME = "legalAdviceName",
  FIELD = "field",
  FIELD_ID = "fieldId",
  REASON = "reason",
  CONTENT = "content",
  STATUS = "status",
  SUMMARY_ISSUE = "summaryIssue",
  PROBLEM = "problem",
  OPINION = "opinion",
  DEADLINE_TYPE = "consultingDeadlineType",
  RESPONSE_DATE = "responseDate",
  RESPONSE_DATE_LA = "responseDateLA",
  URGENT_RESPONSE_DATE = "urgentResponseDate",
  URGENT_RESPONSE_REASON = "urgentResponseReason",
  ADVISOR = "receiverUsers",
  RECEIVER_USER_IDS = "receiverUserIds",
  RESPONSIBLE_USERS = "responsibleUsers",
  SUPERVISOR_ADVISOR = "supervisorAdvisor",
  RELATED_USERS = "relatedUsers",
  RELATED_USER_IDS = "relatedUserIds",
  ASSIGNMENT_USERS = "assignmentUsers",
  RETURN_DATE_ALL = "returnDateAll",
  SENDER = "sender",
  RECEIVER = "receiver",
  ACTION = "action",
  ATTACHMENTS = "attachments",
  VENDOR_RESPONSE_DATE = "vendorResponseDate",
  LEGAL_ACCESS_TYPE = "legalAccessType", // public private
  FILES = "files"
}


export interface LegalAdviceBodyReceive {
  id: number;
  superVisor?: boolean;
  adviseId?: number;
  legalAdviceName: string;
  field: FieldDTO;
  attachments?: LegalAdviceAttachment[];
  departments?: Department[];
  vendorResponseDate?: string;
  summaryIssue?: string;
  problem?: string;
  opinion: string;
  consultingDeadlineType: number,
  responseDate: string;
  urgentResponseDate: string;
  urgentResponseReason: string;
  receiverUsers: BasedUser[];
  responsibleUsers: BasedUser[];
  assignmentUsers: BasedUser[];
  legalAdviceRelateUsers: BasedUser[];
  isDraft?: boolean;
  status: StatusDTO;
  legalAccessType: number;
  bookingFlag?: number;
  responseFlag?: number;
  confirmFlag?: number;
  completeFlag?: number;
  completeAdviseFlag?: number;
  supervisorAdviseFlag?: number;
  checkDivisionFlag?: number;
  checkDeptHeadFlag?: number;
  remind?: ReminderInput;
  pic?: BasedUser;
  reason?: string;
  userLastActionAndLegalAdviceRoleResponse: {
    feedbackAvailableFlag: number;
    otherActionsAvailableFlag: number;
    requestTimeExtensionAvailableFlag: number;
    legalAdviceDoneFlag: number;
    userLastActionAndRoleList: {
      role: number;
      lastAction: number;
    }[]
  };

  sharedDepartments?: Department[];
  sharedUsers?: BasedUser[];

  adviceNumber: number;
  requestAdviceNumber: number;
  supervisorAdviceNumber: number;
  requestSupervisorAdviceNumber: number;
  meetingNumber: number;
  responseAdviseNumber: number;
}
export interface LegalAdviceBodySend {
  isDraft?: boolean,
  legalAdviceId?: number;
  legalAdviceName: string,
  fieldId: number,
  attachmentIds?: number[],
  status?: number,
  reason: string,
  vendorResponseDate?: string | undefined,
  summaryIssue: string,
  problem: string,
  opinion: string,
  consultingDeadlineType: number,
  responseDate?: string | undefined,
  urgentResponseDate?: string | undefined,
  urgentResponseReason?: string | undefined,
  departments?: string[],
  receiverUserIds: any[],
  responsibleUsers: any[];
  relatedUserIds?: string[];
  remind?: SaveReminderDTO;
  legalAccessType: number;
  validRequest?: boolean;
  checkDivisionFlag?: number;
  checkDeptHeadFlag?: number;
  bookingFlag?: number;
}


export const SaveLegalAdviceRequestSchema = Yup.object().shape({
  // files: Yup.mixed().required(VALIDATION_MSG.SELECT),
  files: Yup.array()
    .min(1, VALIDATION_MSG.SELECT_FILE)
    .required(VALIDATION_MSG.SELECT_FILE),
  legalAdviceName: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  fieldId: Yup.number().required(VALIDATION_MSG.SELECT),
  reason: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.number().required(VALIDATION_MSG.SELECT),
  summaryIssue: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  // problem: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  // opinion: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  consultingDeadlineType: Yup.number().required(VALIDATION_MSG.SELECT),
  responseDate: Yup.mixed()
    .when('consultingDeadlineType', {
      is: (type: any) => Number(type) === 1,
      then: () => Yup.date().typeError(VALIDATION_MSG.ENTER_VALID_VALUE).required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.optional().nullable(),
    }),
  urgentResponseDate: Yup.mixed()
    .when('consultingDeadlineType', {
      is: (type: any) => Number(type) === 2,
      then: () => Yup.date().typeError(VALIDATION_MSG.ENTER_VALID_VALUE).required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.optional().nullable(),
    }),
  urgentResponseReason: Yup.string()
    .when('consultingDeadlineType', {
      is: (type: any) => Number(type) === 2,
      then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.optional().nullable(),
    }),
  responsibleUsers: Yup.array().min(1, VALIDATION_MSG.SELECT).required(VALIDATION_MSG.SELECT),
  receiverUserIds: Yup.array().min(1, VALIDATION_MSG.SELECT).required(VALIDATION_MSG.SELECT),
  checkDeptHeadFlag: Yup.boolean(),
  checkDivisionFlag: Yup.boolean(),
}).test(
  'head-checkbox',
  'legalAdvice.messages.requiredToBeSentTo',
  (values) => values.checkDeptHeadFlag || values.checkDivisionFlag
);

export interface LegalAdviceAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface LegalAdviceAdvise {
  id: number;
  user: BasedUser;
  receiverUsers?: BasedUser;
  department: Department;
  content: string;
  createAt: string;
  attachments: LegalAdviceAttachment[];
  finish: boolean;
  editAvailable: boolean;
  superVisor: boolean;
}


export interface LegalAdviceAdviseListResponse {
  responses: LegalAdviceAdvise[];
}


enum SearchPanelQueries {
  GET_HIERARCHY = 'legal-advice/get-hierarchy',
  SEARCH_DOCUMENT = 'legal-advice/search_document',
  SEARCH_KEY = "legalAdviceName"
}
export const legalAdviceSearchPanelConfig: GenericSearchPanelProps<any> = {
  completeStatusName: LegalAdviceStatusContent.get(LegalAdviceStatusKey.DONE)!,
  getHierarchyFn: (id) => getAllHierarchyById({ id }),
  getItemKey: (item) => item?.legalAdviceId ?? item?.id,
  getChildKey: (child) => child?.legalAdviceId ?? child?.id,
  getSearchResultFn: getLegalAdviceRequests,
  hierarchyQueryKey: SearchPanelQueries.GET_HIERARCHY,
  searchQueryKey: SearchPanelQueries.SEARCH_DOCUMENT,
  searchKey: SearchPanelQueries.SEARCH_KEY,
  getItemName: (item) => item?.legalAdviceName,
  getCreator: (item) => item?.pic ?? item?.createdUser,
  getParentTimeLabel: (item) =>
    item?.createdDate
      // ? formatDate(item?.createdDate, "dd/MM/yyyy")
      ? formatRelativeDate(item?.createdDate)
      : "",
  getParentUsersList: (item) => item?.receiverUsers ?? item?.users,
  getParentStatus: (item) => item?.status?.name ?? item?.status ?? "",
  getChildStatus: (child) => child?.status?.name ?? child?.status ?? "",
  getChildTimeLabel: (child) =>
    child?.createdDate
      // ? formatDate(child?.createdDate, "dd/MM/yyyy")
      ? formatRelativeDate(child?.createdDate)
      : "",
  getChildUsersList: (child) => child?.receiverUsers,
  getChildren: (item) => item?.children ?? item?.legalAdviceChild ?? [],
  getItemLink: (item) =>
    `/${LEGAL_ADVICE_ROOT_PATH}/update/${item?.legalAdviceId ?? item?.id}`,
};
