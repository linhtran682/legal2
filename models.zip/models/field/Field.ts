import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface FieldDTO {
  id: number;
  name: string;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
}

export const enum FieldFieldNames {
  ID = "id",
  NAME = "name",
  DESCRIPTION = "description",
  CREATED_BY = "createdBy",
  CREATED_AT = "createdAt",
}

export interface GetFieldsParams {
  name?: string;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export interface GetFieldsResponse {
  total: number;
  fieldResponses: FieldDTO[];
}

export interface SaveFieldDTO {
  name?: string;
  description?: string;
}

export const enum SaveFieldRequestFieldNames {
  NAME = "name",
  DESCRIPTION = "description",
}

export const SaveFieldRequestSchema = Yup.object().shape({
  name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  description: Yup.string().optional(),
});

export interface SaveFieldRequestSchemaI {
  description?: string | undefined;
  name: string;
}
