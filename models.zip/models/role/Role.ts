import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface RoleDTO {
  id: string;
  name?: string | undefined;
  defaultRole?: boolean | undefined;
  permissions?: string[] | undefined;
}

export const RoleDTOSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  defaultRole: Yup.boolean().optional(),
  permissions: Yup.array(Yup.string().defined()).optional(),
});

export interface RoleDTO1 {
  id?: string;
  name?: string;
  // builtInRole?: boolean;
  defaultRole?: boolean;
  permissions?: string[];
}
export const enum RoleFieldNames {
  ID = "id",
  NAME = "name",
  BUILT_IN_ROLE = "builtInRole",
  DEFAULT_ROLE = "defaultRole",
  PERMISSIONS = "permissions",
}

export interface GetRolesParams {
  searchTerm?: string;
  page: number;
  size: number;
  sort?: string;
}

export interface GetRolesResponse {
  total: number;
  roles: RoleDTO[];
}

export const SaveRoleRequestSchema = Yup.object().shape({
  defaultRole: Yup.boolean(),
  name: Yup.string().required("Name is field require"),
  permissions: Yup.array().of(Yup.string().defined()).optional(),
});

export interface RoleBodySendForm {
  defaultRole?: boolean;
  name: string;
  permissions?: string[];
}

export const enum SaveRoleRequestFieldNames {
  NAME = "name",
  ROLE_DEFAULT = "defaultRole",
}
