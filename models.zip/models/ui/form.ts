export interface BasicSaveForm<Input, Output> {
  formMode: "create" | "update";
  initialValue?: Input;
  onSubmit: (data: Output) => void;
  onCancel: () => void;
  onDelete?: () => void;
  loading?: boolean;
}
