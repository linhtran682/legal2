import { LegalAdviceForward } from "../legal-advice/LegalAdviceList";
import { BasedUser, Position } from "../user/User";

export interface Feedback {
  feedbackUser: BasedUser;
  content: string;
  feedbackDate: string;
  receiverUser: BasedUser;
}

export interface Forward {
  forwardUser: BasedUser;
  receiveUser: BasedUser;
  forwardDate: string;
  content: string;
}

export interface Department {
  id: string;
  code?: string;
  name?: string;
  nameEnglish?: string;
  description?: string;
  departmentType?: {
    id?: string;
    name?: string;
  };
  status?: "ACTIVE" | "INACTIVE";
}

export interface Evaluation {
  department?: Department;
  user?: BasedUser;
  deadline?: string;
  evaluated?: boolean;
  content?: string;
}

export interface Comment {
  userInfo: BasedUser;
  comment: string;
  commentDate: string;
  commentId: string;
}

export interface InformationRequestDetail {
  user: BasedUser;
  content: string;
  deadline: string;
  date: string;
  type: number; // TODO: mapping list
}

export interface GetCommentsResponse {
  data: Comment[];
}

export interface MeetingDetail {
  id: number;
  createUser: BasedUser;
  content: string;
  date: string;
  deadline: string;
  isEdit: boolean;
}

export interface GetMeetingResponse {
  meetingResponses: MeetingDetail[];
}

export interface GetFeedbacksResponse {
  feedbackResponseDetails: Feedback[];
}

export interface GetForwardsResponse {
  forwardResponseDetails: Forward[];
}
export interface GetForwardsResponseDocumentMng {
  forwardResponseDetails: LegalAdviceForward[];
}
export interface GetEvaluationsResponse {
  responses: Evaluation[];
}

export interface GetInformationRequestsResponse {
  detailInformationRequestResponses: InformationRequestDetail[];
}

export interface GetHistoryResponse {
  data: HistoryRecord[];
}

export interface HistoryRecord {
  date: string;
  action: number | string;
  actionOwner: BasedUser;
  feature?: number;
  content?: string;
  receiverUsers?: BasedUser[];
}
export interface ConfirmRecord {
  departmentName: string;
  employeeName: string;
  date: string;
  status: BasedUser;
  feature: number;
  action: number;
}

interface TypeDepartment {
  id: string;
  name: string;
  nameEnglish: string;
}

export interface UserProfileExtend {
  id: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: {
    id: string;
    name: string;
    nameEnglish: string;
  };
}

export interface TypeExtendResponses {
  department?: TypeDepartment;
  user?: UserProfileExtend;
  proposedDeadline?: string;
  newDeadline?: string;
  createAt?: string;
  status?: number;
  extendDeadlineId?: number;
}

export interface GetExtendsResponse {
  deadlineResponses?: TypeExtendResponses[];
}

type TypeEvaluateUsers = {
  department?: Position;
  email?: string;
  id?: string;
  name?: string;
  nameEnglish?: string;
  position?: Position;
};
export interface TypeRequestApprovalResponses {
  department?: TypeDepartment;
  user?: UserProfileExtend;
  content?: string;
  reason?: string;
  deadline?: string;
  approvalStatus?: number;
  createAt?: string;
  evaluateUsers?: TypeEvaluateUsers[];
}
export interface GetRequestApprovalResponse {
  requestApprovalResponses?: TypeRequestApprovalResponses[];
}
