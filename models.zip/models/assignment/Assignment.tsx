import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { BasedUser } from "../user/User";

interface Department {
  id: string;
  name: string;
  nameEnglish: string;
}

interface Person {
  id: string;
  name: string;
  nameEnglish: string;
  department: Department;
}

interface ManagedUser extends Person { }

export interface AssignmentDTO {
  id: number;
  assignmentDraftId?: number;
  draft?: boolean;
  assignedPerson: Person;
  managedUsers: ManagedUser[];
  managedDepartments: Department[];
}


export interface GetAssignmentsParams {
  name?: string;
  page: number;
  size: number;
  sortBy?: string;
  orderBy?: string;
  assignedPersonIds?: string[];
}

export interface GetAssignmentsResponse {
  total: number;
  assignments: AssignmentDTO[];
}
export interface GetAssignedPersonResponse {
  users: BasedUser[];
}

export interface SaveAssignmentDTO {
  assignmentDraftId?: number;
  assignedPersonId: string;
  managedDepartments: string[];
  managedUsers: string[];
}


export const enum AssignmentColumnNames {
  ID = "id",
  FULL_NAME = "fullName",
  DEPARTMENT = "department",
  MANAGED_DEPARTMENTS = "managedDepartments",
  MANAGED_USERS = "managedUsers",
  ASSIGNED_PERSON_ID = "assignedPersonId"
}


export const SaveAssignmentRequestSchema = Yup.object().shape({
  assignedPersonId: Yup.string()
    .required(VALIDATION_MSG.SELECT),
  managedDepartments: Yup.array()
    .of(Yup.string().defined())
    .min(1, VALIDATION_MSG.SELECT_DEPARTMENT)
    .required(VALIDATION_MSG.SELECT_DEPARTMENT),
  managedUsers: Yup.array()
});

