import {
  getAllHierarchyById,
  getDocuments,
} from "@/apis/service/law_document/law_document";
import { GenericSearchPanelProps } from "@/components/commons/search_panel/GenericSearchPanel";
import {
  LegalDocumentStatusContent,
  LegalDocumentUserStatusKey,
} from "@/constants/general";
import { VALIDATION_MSG } from "@/constants/message";
import { LEGAL_DOCUMENT_ROOT_PATH } from "@/constants/paths";
import { formatDate } from "@/utils";
import { isBefore, isValid } from "date-fns";
import * as Yup from "yup";
import {
  Department,
  departmentSchema,
  DepartmentSchema,
} from "../department/Department";
import {
  ReminderContentSchemaI,
  ReminderInput,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";
import { StandardTableState } from "@/components/commons/tables/standard_table/StandardTable";
import { GetBasedLegalDocumentsParams } from "./BasedLegalDocument";
import { BaseLegalAdviceFields } from "../legal-advice/LegalAdviceList";

export interface LawDocumentType {
  id: number;
  documentType: string;
  documentName: string;
  agencyIssued: string;
  textNumber: string;
  field: string;
  receiveFromVendorDate: string;
  vendorResponseDate: string;
  submissionDeadline: string;
  departmentResponseDate: string;
  publishDate: string;
  effectiveDate: string;
  departments: Array<string>;
  users: Array<string>;
  status: string;
  sender: string;
  receiver: string;
}

export interface LawDocumentParams {
  documentType: string;
  field: string;
  agencyIssued: string;
  textNumber: string;
  sender: string;
  receiver: string;
  departments: Array<string>;
  status: string;
  receiveFromVendorDate: string;
  vendorResponseDate: string;
  submissionDeadline: string;
  departmentResponseDate: string;
  publishDate: string;
  effectiveDate: string;
  sortBy?: string;
  orderBy?: string;
  page?: number;
  size?: number;
}
export const LawDocumentColumn = {
  RECEIVER: "Người nhận",
  STATUS: "Trạng thái",
  USER: "Người dùng",
  DEPARTMENT: "Phòng ban",
  EFFECTIVE_DATE: "Ngày có hiệu lực",
  PUBLISH_DATE: "Ngày ban hành",
  DEPARTMENT_RESPONSE_DATE: "Ngày yêu cầu phòng ban phản hồi",
  SUBMMISSION_DEADLINE: "Thời hạn gửi",
  VENDOR_RESPONSE_DATE: "Ngày vendor phản hồi",
  RECEIVE_FROM_VENDOR_DATE: "Ngày nhận từ vendor",
  FIELD: "Lĩnh vực",
  TEXT_NUMBER: "Số hiệu văn bản",
  AGENCY_ISSUED: "Cơ quan ban hành",
  DOCUMENT_NAME: "Tên văn bản",
  DOCUMENT_TYPE: "Loại văn bản",
};
export const enum SaveLawDocumentRequestFieldNames {
  FILES = "files",
  RECEIVER = "receiver",
  STATUS = "status",
  USER = "users",
  DEPARTMENT = "departments",
  DEPARTMENTS_RESPONSIBLE = "departmentsResponsible",
  DEPARTMENT_SINGLE = "department",
  EFFECTIVE_DATE = "effectiveDate",
  PUBLISH_DATE = "publishDate",
  DEPARTMENT_RESPONSE_DATE = "departmentResponseDate",
  SUBMMISSION_DEADLINE = "submissionDeadline",
  VENDOR_RESPONSE_DATE = "vendorResponseDate",
  RECEIVE_FROM_VENDOR_DATE = "receiveFromVendorDate",
  FIELD = "field",
  TEXT_NUMBER = "textNumber",
  AGENCY_ISSUED = "agencyIssued",
  DOCUMENT_NAME = "documentName",
  DOCUMENT_TYPE = "documentType",
  CONTENT = "content",
  PERSON_RESPONSIBLE = "personResponsible",
  REMIND = "remind",
  EXTENDDATEALLOWDEADLINE = "extendDateAllowDeadline",
  EXTENDDATEALLOWDEADLINENUMBERTYPE = "extendDateAllowDeadlineNumberType",
}

export const SaveLawDocumentRequestSchema = Yup.object().shape({
  // files: Yup.mixed().required(VALIDATION_MSG.REQUIRED_FIELD),
  files: Yup.array()
    .min(1, VALIDATION_MSG.SELECT_FILE)
    .required(VALIDATION_MSG.SELECT_FILE),
  legalDocumentDraftId: Yup.number().optional(),
  documentType: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  documentName: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  field: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  agencyIssued: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  textNumber: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  departments: Yup.array().of(departmentSchema).optional(),
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  receiveFromVendorDate: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  vendorResponseDate: Yup.string().when("status", {
    is: 2,
    then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
    otherwise: (schema) => schema.notRequired().nullable(), // nullable only when not required
  }),

  submissionDeadline: Yup.string().when("status", {
    is: 2,
    then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
    otherwise: (schema) => schema.notRequired().nullable(), // nullable only when not required
  }),

  departmentResponseDate: Yup.string().when("status", {
    is: 4,
    then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
    otherwise: (schema) => schema.notRequired().nullable(), // nullable only when not required
  }),
  publishDate: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .test({
      name: "test-publish-date",
      exclusive: true,
      message: "LEGISLATION.message.publishDateError",
      test: function (value) {
        if (
          !!value &&
          isValid(new Date(value)) &&
          !!this.parent?.effectiveDate &&
          isValid(new Date(this.parent?.effectiveDate)) &&
          isBefore(new Date(this.parent?.effectiveDate), new Date(value))
        ) {
          return false;
        }
        return true;
      },
    }),
  effectiveDate: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  users: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
  extendDateAllowDeadline: Yup.string()
    .trim()
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  attachments: Yup.array().of(Yup.number().defined()).optional(),
  extendDateAllowDeadlineNumberType: Yup.number().required(" "),
  isBookMeeting: Yup.boolean().nullable().optional(),
  // departmentsResponsible: Yup.array()
  //   .min(1, VALIDATION_MSG.SELECT_DEPARTMENT)
  //   .required(VALIDATION_MSG.SELECT_DEPARTMENT),
});

export interface LawDocumentBodySendForm {
  legalDocumentDraftId?: number;
  documentType: number;
  documentName: string;
  field: number;
  agencyIssued: number;
  textNumber: string;
  departments?: DepartmentSchema[];
  status: number;
  receiveFromVendorDate: string;
  vendorResponseDate?: string | undefined;
  submissionDeadline?: string | undefined;
  departmentResponseDate?: string | undefined;
  publishDate: string;
  effectiveDate: string;
  content: string;
  users: BasedUser[];
  remind?: ReminderSchemaI;
  extendDateAllowDeadline: string;
  extendDateAllowDeadlineNumberType: number;
  attachments?: number[];
  isBookMeeting?: boolean | null;
  departmentsResponsible?: DepartmentSchema[];
  files: any;
}
export interface LawDocumentBodySend {
  legalDocumentDraftId?: number;
  documentType?: number;
  documentName?: string;
  field?: number;
  agencyIssued?: number;
  textNumber?: string;
  departments?: string[];
  status?: number;
  receiveFromVendorDate?: string;
  vendorResponseDate?: string;
  submissionDeadline?: string | undefined;
  departmentResponseDate?: string;
  publishDate?: string;
  effectiveDate?: string;
  content?: string;
  users?: string[];
  remind?: SaveReminderDTO;
  extendDateAllowDeadline?: string;
  extendDateAllowDeadlineNumberType?: number;
  attachments?: number[];
  departmentsResponsible?: string[];
  attachmentsSharepoint?: attachmentsSharepointType[];
}
export interface attachmentsSharepointType {
  id: string;
  isEvaluateFile: boolean;
}
export interface ReminderSchemaII {
  id: number;
  title: string;
  module: number;
  description?: string | undefined;
  remindContents: ReminderContentSchemaI[];
  relatedUsers?: BasedUser[] | undefined;
  receivingDepartment?: string[] | undefined;
  receivedTitle?: string[] | undefined;
}

export interface SaveLawDocumentdDTO {
  documentType?: number;
  documentName?: string;
  content?: string;
  attachments?: Attachment[];
  agencyIssued?: number;
  textNumber?: string;
  field?: number;
  status?: number;
  receiveFromVendorDate?: number;
  vendorResponseDate?: number;
  submissionDeadline?: number;
  departmentResponseDate?: number;
  publishDate?: number;
  effectiveDate?: number;
  departments?: string[];
  personResponsible?: string[];
  extendDateAllowDeadline?: number;
  extendDateAllowDeadlineNumberType?: number;
  remind?: SaveReminderDTO;
}
interface Attachment {
  fileId?: number;
  fileName?: string;
  filePath?: string;
}

interface RemindContent {
  position?: number;
  remindReceiverType?: number;
  remindValueType?: number;
  timeStatus?: number;
  vendorResponseStatus?: number;
  time?: number;
  timeUnit?: number;
  legalStatus?: number;
  isSend?: boolean;
}

interface Remind {
  title?: string;
  module?: number;
  description?: string;
  remindContents?: {
    additionalProp1?: RemindContent[];
    additionalProp2?: RemindContent[];
    additionalProp3?: RemindContent[];
  };
  relatedUsers?: string[];
  receivingDepartment?: string[];
  receivedTitle?: string[];
}

export interface LawDocumentDTO {
  id?: number;
  documentType?: string;
  documentName?: string;
  agencyIssued?: string;
  textNumber?: string;
  field?: string;
  receiveFromVendorDate?: string;
  vendorResponseDate?: string;
  submissionDeadline?: string;
  departmentResponseDate?: string;
  publishDate?: string;
  effectiveDate?: string;
  attachments?: Attachment[];
  departments?: string[];
  users?: string[];
  extendDateAllowDeadline?: number;
  extendDateAllowDeadlineNumberType?: number;
  remind?: Remind;
}

export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}

export interface TypeActionsRole {
  ownerRole?: number;
  ownerAction?: number;
  role?: number;
  lastAction?: number;
}
export type TypeButtonActionNew = {
  feedbackLC?: number;
  nextAction?: number;
  nextActionApprove?: number;
  nextActionRequestApprove?: number;
  remindEvaluate?: number;
  requestApprove?: number;
};
export interface LawDocumentBodyReceive {
  id: number;
  legalDocumentDraftId?: number;
  documentType?: DetailModule;
  documentName?: string;
  field?: DetailModule;
  agencyIssued?: DetailModule;
  textNumber?: string;
  departments?: Department[];
  status?: DetailModule;
  receiveFromVendorDate?: string;
  vendorResponseDate?: string;
  submissionDeadline?: string | undefined;
  departmentResponseDate?: string;
  publishDate?: string;
  effectiveDate?: string;
  content?: string;
  users?: BasedUser[];
  remind?: ReminderInput;
  extendDateAllowDeadline?: string;
  extendDateAllowDeadlineNumberType?: number;
  attachments?: FileDetailsResponse[];
  attachmentsSharepoint?: FileDetailsSharepointResponse[];
  evaluateApproval: number;
  evaluateTotal: number;
  nextActionApproval: number;
  nextActionTotal: number;
  evaluateApprovalDepartment: number;
  evaluateTotalDepartment: number;
  legalDocumentActions?: TypeActionsRole[];
  requestEvaluateId?: number;
  requestApprovalId?: number;
  extendDeadlineId?: number;
  departmentsOfUsers?: Department[];
  departmentsResponsible?: Department[];
  btnConditions?: number[];
  isBookMeeting?: boolean;
  nextActionId?: number;
  isDraft?: boolean;
  buttonActionNew?: TypeButtonActionNew;

  legalAccessType: number;
  sharedDepartments?: Department[];
  sharedUsers?: BasedUser[];
  createdBy?: BasedUser;
  createdUser?: BasedUser;
  pic?: BasedUser;
  assignmentUsers?: BasedUser[]
}

export interface DetailModule {
  id: number;
  name: string;
  description: string;
  createdAt: Date | null;
  createdBy: string | null;
}

export interface FileDetailsResponse {
  fileId?: number;
  fileName?: string;
  file?: File;
  filePath?: string;
  uploadDate?: string;
  accessLink?: string;
}

export interface FileDetailsSharepointResponse {
  id: number;
  fileName: string;
  uploadDate?: string;
  accessLink?: string;
  isEvaluateFile?: boolean;
}

enum SearchPanelQueries {
  GET_HIERARCHY = "legal-document/get-hierarchy",
  SEARCH_DOCUMENT = "legal-document/search_document",
}

export const legalDocumentSearchPanelConfig: GenericSearchPanelProps<any> = {
  completeStatusName: LegalDocumentStatusContent.get(
    LegalDocumentUserStatusKey.DONE
  )!,
  getHierarchyFn: (id) => getAllHierarchyById({ id }),
  getItemKey: (item) => item?.documentId ?? item?.id,
  getChildKey: (child) => child?.documentId ?? child?.id,
  getSearchResultFn: getDocuments,
  hierarchyQueryKey: SearchPanelQueries.GET_HIERARCHY,
  searchQueryKey: SearchPanelQueries.SEARCH_DOCUMENT,
  searchKey: "documentName",
  getItemName: (item) => item.documentName,
  getCreator: (item) => item?.createdUser ?? item?.createdBy,
  getParentTimeLabel: (item) =>
    item?.createdDate ? formatDate(item?.createdDate, "dd/MM/yyyy HH:mm") : "",
  getParentUsersList: (item) => item?.personResponsible ?? item?.users,
  getParentStatus: (item) => item?.status?.name ?? item?.status ?? "",
  getChildStatus: (child) => child?.status?.name ?? child?.status ?? "",
  getChildTimeLabel: (child) =>
    child?.createdDate
      ? formatDate(child?.createdDate, "dd/MM/yyyy HH:mm")
      : "",
  getChildUsersList: (child) => child?.personResponsible ?? child?.users,
  getChildren: (item) => item?.children ?? [],
  getItemLink: (item) =>
    `/${LEGAL_DOCUMENT_ROOT_PATH}/update/${item?.documentId ?? item?.id}`,
};

export interface LegalDocumentAssignment {
  assignUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
}
export interface GetLawAssignmentResponse {
  assignmentResponseDetails: LegalDocumentAssignment[];
}
export interface LegalDocStatisticChartResponse {
  pieChart: {
    data: {
      name: string;
      value: number
    }[];
  }
  barChart: {
    data: {
      name: string;
      value: number
    }[];
  }
}

export interface IReportFilters {
  startDate?: string;
  endDate?: string;
  status?: number[];
  documentTypes?: number[];
  departments?: string[];
  feedbackType?: number
}

export const castTableStateToParams = (
  tableState: StandardTableState,
  filters?: IReportFilters
): GetBasedLegalDocumentsParams => {
  const params: GetBasedLegalDocumentsParams = {
    page: tableState?.paginationModel?.page || 0,
    size: tableState?.paginationModel?.pageSize || 0,
    sortBy: BaseLegalAdviceFields.ID,
    orderBy: "DESC",
  };
  
  if (filters?.status?.length) {
    params.status = filters.status?.join(",");
  }
  if (filters?.feedbackType?.toString()) {
    params.feedbackType = filters.feedbackType;
  }
  if (filters?.departments?.length) {
    params.departments = filters.departments?.join(',');
  }
  if (filters?.documentTypes?.length) {
    params.documentTypes = filters?.documentTypes?.join(",");
  }
  if (filters?.startDate) {
    params.createFrom = filters?.startDate;
  }
  if (filters?.endDate) {
    params.createTo = filters?.endDate;
  }
  if ((tableState.sorterModel || []).length > 0) {
    params.sortBy = tableState.sorterModel![0].field;
    params.orderBy = tableState.sorterModel![0].sort?.toUpperCase() ?? "";
  }
  return params;
};

export const getFieldLabelLegalDoc = (key: string) => {
  return `LEGISLATION.column.${key}`;
};

export const FeedbackTypeOptions=[
  {
    label:"notification.all",
    value: 0
  },
  {
    label:"LEGISLATION.button.evaluate",
    value: 1
  },
  {
    label:"LEGISLATION.evaluateField.nextAction",
    value: 2
  }
]