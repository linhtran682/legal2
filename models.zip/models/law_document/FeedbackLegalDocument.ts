import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { BasedUser } from "../user/User";

export interface FeedbackLegalDocumentRequest {
  users: string[];
  deadline?: string;
  content?: string;
  remind?: SaveReminderDTO;
}

export const FeedbackLegalDocumentRequestSchema = Yup.object().shape({
  users: Yup.array()
    // .of(Yup.string().defined())
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  deadline: Yup.string().optional(),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});

export interface FeedbackLegalDocumentRequestSchemaI {
  users: BasedUser[];
  deadline?: string | undefined;
  content: string;
  remind?: ReminderSchemaI | undefined;
  departments?: any[];
}

export const enum FeedbackLegalDocumentRequestFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}

export const castFeedbackLegalDocumentRequestSchemaToDTO = (
  schema: FeedbackLegalDocumentRequestSchemaI
): FeedbackLegalDocumentRequest => {
  return {
    ...schema,
    users: schema.users?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
