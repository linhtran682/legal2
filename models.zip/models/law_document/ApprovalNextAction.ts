import * as Yup from "yup";
import {
  ReminderSchema,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { VALIDATION_MSG } from "@/constants/message";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createApprovalNextActionMutationFn,
  getListApprovalNextActionQueryFn,
} from "@/apis/service/law_document/approvalNextAction";
import { FieldValues } from "react-hook-form";
import { BasedUserSchema } from "../user/User";

export const enum ApprovalNextActionFormSchemaFieldNames {
  USERS = "users",
  STATUS = "status",
  REASON = "reason",
  REMIND = "remind",
}
export interface ApprovalNextActionFormOutput {
  users?: string[];
  status?: number;
  reason?: string;
  remind?: SaveReminderDTO;
}

export interface NextActionItemInput {
  nextActionItemId?: number;
  position?: number;
  category?: string;
  legalRequirements?: string;
  complianceAssessment?: string;
  workNeed?: string;
  pic?: string;
  deadline?: string;
  deptHeadApprove?: string;
  currentStatusTMV?: string;
}

export interface ApprovalNextActionSchemaI extends FieldValues {
  nextActionItems?: NextActionItemInput[];
  nextActionIds?: number[];
  status?: number;
  reason?: string;
  users?: string[];
  remind?: SaveReminderDTO;
  nextActionItemId?: number[];
}

export interface CreateApprovalNextActionBody {
  legalDocumentId?: number;
  nextActionId?: number;
  data?: ApprovalNextActionSchemaI;
}

export type RequestApprovalResponses = {
  user: {
    id?: string;
    name?: string;
    nameEnglish?: string;
    email?: string;
    position?: {
      id: string;
      name: string;
      nameEnglish: string;
    };
    department?: {
      id: string;
      name: string;
      nameEnglish: string;
    };
  };
  reason?: string;
};

export interface ApprovalNextActionDTO {
  nextActionRequestApprovalResponses?: RequestApprovalResponses[];
}

export interface CreateApprovalNextActionOptions {
  config?: MutationConfig<typeof createApprovalNextActionMutationFn>;
}

export type ApprovalNextActionParams = {
  legalDocumentId?: number;
  nextActionId?: number;
};

export type QueryFnTypeApprovalNextAction =
  typeof getListApprovalNextActionQueryFn;

export type GetListApprovalNextActionOptions = {
  config?: QueryConfig<QueryFnTypeApprovalNextAction>;
  request: ApprovalNextActionParams;
};
export const ApprovalNextActionFormSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  reason: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});

export const StatusReviewApprovalKey = {
  REVIEW_APPROVED: "reviewApproved",
  REVIEW_REJECTED: "reviewRejected",
};

export const StatusReviewApproval: Map<string, number> = new Map([
  [StatusReviewApprovalKey.REVIEW_APPROVED, 0],
  [StatusReviewApprovalKey.REVIEW_REJECTED, 1],
]);
