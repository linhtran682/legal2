import { AgencyIssuedDTO } from "../agency_issued/AgencyIssued";
import { BasedUser } from "../user/User";
import { TypeActionsRole } from "./LawDocument";

type TypeStatusLegalDocument = {
  id?: number;
  name?: string;
  module?: string;
  active?: number;
  description?: string;
  createdBy?: string;
  createdAt?: string;
};
export interface BasedLegalDocument {
  id: number;
  documentType?: string;
  documentName?: string;
  agencyIssues?: AgencyIssuedDTO;
  textNumber?: string;
  field?: string;
  receiveFromVendorDate?: string;
  vendorResponseDate?: string;
  submissionDeadline?: string;
  departmentResponseDate?: string;
  publishDate?: string;
  effectiveDate?: string;
  departments?: string[];
  users?: BasedUser[];
  status?: TypeStatusLegalDocument;
  sender?: string;
  receiver?: string;
  legalDocumentActions?: TypeActionsRole[];
  enableFeedback?: boolean;
  btnConditions?: number[];
}

export const enum BasedLegalDocumentFieldNames {
  ID = "id",
  DOCUMENT_TYPE = "documentType",
  DOCUMENT_NAME = "documentName",
  AGENCY_ISSUES = "agencyIssues",
  TEXT_NUMBER = "textNumber",
  FIELD = "field",
  RECEIVE_FROM_VENDOR_DATE = "receiveFromVendorDate",
  VENDOR_RESPONSE_DATE = "vendorResponseDate",
  SUBMISSION_DEADLINE = "submissionDeadline",
  DEPARTMENT_RESPONSE_DATE = "departmentResponseDate",
  PUBLISH_DATE = "publishDate",
  EFFECTIVE_DATE = "effectiveDate",
  DEPARTMENTS = "departments",
  RELATED_DEPARTMENTS = "relatedDepartments",
  USERS = "users",
  STATUS = "status",
  SENDER = "sender",
  RECEIVER = "receiver",
  CREATED_BY = "createdBy",
  CREATED_DATE= "createdDate"
}

export interface GetBasedLegalDocumentsParams {
  documentTypes?: number | string;
  fields?: number;
  agencyIssued?: number;
  textNumber?: string;
  createdUsers?: string;
  departments?: string;
  status?: number | string;
  receiveFromVendorDateFrom?: string;
  receiveFromVendorDateTo?: string;
  vendorResponseDateFrom?: string;
  vendorResponseDateTo?: string;
  submissionDeadlineFrom?: string;
  submissionDeadlineTo?: string;
  departmentResponseDateFrom?: string;
  departmentResponseDateTo?: string;
  publishDateFrom?: string;
  publishDateTo?: string;
  effectiveDateFrom?: string;
  effectiveDateTo?: string;
  isPanelSearch?: boolean;
  documentName?: string;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
  tab?: number;
  isEnglish?: boolean;
  createFrom?: string;
  createTo?: string;
  feedbackType?: number
}

export interface GetBasedLegalDocumentsResponse {
  total: 0;
  data: BasedLegalDocument[];
}
