import { VALIDATION_MSG } from "@/constants/message";
import {
  castReminderInputToReminderSchema,
  castReminderSchemaToSaveReminderDTO,
  ReminderInput,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser, BasedUserSchema } from "../user/User";
import * as Yup from "yup";
import { Department, departmentSchema } from "../department/Department";
import { FileDetailsResponse, TypeButtonActionNew } from "./LawDocument";
import { TimeExtensionUser } from "./TimeExtension";

export interface NextActionItemInput {
  nextActionItemId?: number;
  // position?: number;
  category: string;
  legalRequirements: string;
  complianceAssessment: string;
  workNeed: string;
  // pic: TimeExtensionUser;
  deadline: string;
  deptHeadApprove?: string;
  currentStatusTMV: string;
  pics: Array<TimeExtensionUser>;

}

export interface NextActionInput {
  legalDocumentName?: string;
  createBy?: BasedUser;
  deadline?: string;
  nextActionItems?: NextActionItemInput[];
  remind?: ReminderInput;
  receivers?: BasedUser[];
  status: number;
  name?: string;
}
export interface NextActionItemInputReceive {
  nextActionItemId: number;
  // position?: number;
  category: string;
  legalRequirements: string;
  complianceAssessment: string;
  workNeed: string;
  // pic: BasedUser;
  deadline: string;
  deptHeadApprove?: string;
  currentStatusTMV: string;
  pics: Array<TimeExtensionUser>;

}
export interface NextActionInputReceive {
  legalDocumentName?: string;
  createBy?: BasedUser;
  deadline?: string;
  nextActionItems?: NextActionItemInputReceive[];
  remind?: ReminderInput;
  receivers?: BasedUser[];
  status: number;
  name: string;
  files?: FileDetailsResponse[];
  buttonActionNew?: TypeButtonActionNew
}
export interface NextActionItemOutput {
  nextActionItemId?: number;
  // position?: number;
  category?: string;
  legalRequirements?: string;
  complianceAssessment?: string;
  workNeed?: string;
  // pic?: string;
  deadline?: string;
  deptHeadApprove?: string;
  currentStatusTMV?: string;
  pics?: Array<string>;
}

export interface NextActionOutput {
  deadline: string;
  nextActionItems: NextActionItemOutput[];
  remind?: SaveReminderDTO;
  receivers?: string[];
  fileIds: number[];
  status?: number;
  name?: string;
}

export interface NextActionItemSchemaI {
  nextActionItemId?: number;
  // position?: number;
  category: string;
  legalRequirements: string;
  complianceAssessment: string;
  workNeed: string;
  // pic: string;
  deadline: string;
  deptHeadApprove?: string;
  currentStatusTMV: string;
  checkDelete?: boolean;
  pics?:Array<TimeExtensionUser>;
}

export const NextActionItemSchema = Yup.object().shape({
  nextActionItemId: Yup.number().optional(),
  // position: Yup.number().optional(),
  category: Yup.string().required(""),
  legalRequirements: Yup.string().required(""),
  complianceAssessment: Yup.string().required(""),
  workNeed: Yup.string().required(""),
  // pic: Yup.string().required(""),
  deadline: Yup.string().required(""),
  deptHeadApprove: Yup.string().optional(),
  currentStatusTMV: Yup.string().required(""),
  pics:  Yup.array(BasedUserSchema)
  .min(1, '')
  .required(''),
});

export interface NextActionSchemaI {
  deadline: string;
  nextActionItems: NextActionItemSchemaI[];
  remind?: ReminderSchemaI;
  fileIds: any;
  // receivers?: BasedUser[];
  status: number;
  name: string;
}

export const NextActionSchema = Yup.object().shape({
  deadline: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  nextActionItems: Yup.array(NextActionItemSchema)
    .required()
    .min(1, ""),
  remind: ReminderSchema,
  // fileIds: Yup.array().of(Yup.number().defined()).optional(),
  // receivers: Yup.array()
  //   .of(BasedUserSchema)
  //   .required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD).defined(),
  name: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD).defined(),
  fileIds: Yup.mixed().required(VALIDATION_MSG.REQUIRED_FIELD),
});

export const enum NextActionSchemaFieldNames {
  DEADLINE = "deadline",
  NEXT_ACTION_ITEMS = "nextActionItems",
  REMIND = "remind",
  STATUS = "status",
  RECEIVER = "receivers",
  NAME = "name",
  REPORT = "report",
  FILE = "fileIds",
}

export const convertNextActionItemInputToSchema = (
  nextActionItem: NextActionItemInput
): NextActionItemSchemaI => {
  return {
    ...nextActionItem,
    pics: nextActionItem?.pics ? nextActionItem?.pics : [],
    // position: nextActionItem.position,
    deadline: nextActionItem.deadline,
    deptHeadApprove: nextActionItem.deptHeadApprove?.toString() ?? undefined,
  };
};

export const convertNextActionInputToSchema = (
  nextAction: NextActionInputReceive
): NextActionSchemaI => {
  return {
    ...nextAction,
    deadline: nextAction.deadline ?? "",
    nextActionItems: (nextAction.nextActionItems ?? []).map((item) =>
      convertNextActionItemInputToSchema(item)
    ),
    remind: nextAction.remind && nextAction.remind?.module !== 0
      ? castReminderInputToReminderSchema(nextAction.remind)
      : undefined,
    fileIds: [],
    status: nextAction.status,
  };
};

export const convertNextActionItemSchemaToOutput = (
  nextActionItem: NextActionItemSchemaI
): NextActionItemOutput => {
  return {
    ...nextActionItem,
    pics: nextActionItem?.pics ? nextActionItem?.pics.map((item: any) => item.id) : [],
    nextActionItemId:
      nextActionItem.nextActionItemId == -1
        ? undefined
        : nextActionItem.nextActionItemId,
  };
};

export const convertNextActionSchemaToOutput = (
  nextAction: NextActionSchemaI,
  fileIds: number[]
): NextActionOutput => {
  return {
    deadline: nextAction.deadline ?? "",
    nextActionItems: (nextAction.nextActionItems ?? []).map((item) =>
      convertNextActionItemSchemaToOutput(item)
    ),
    remind: nextAction.remind
      ? castReminderSchemaToSaveReminderDTO(nextAction.remind)
      : undefined,
    // receivers: nextAction.receivers.map((ele: BasedUser) => ele?.id),
    fileIds: fileIds,
    status: nextAction?.status,
    name: nextAction?.name,
  };
};

export interface RequestNextActionApprovalFormOutput {
  users: string[];
  deadline: string;
  status?: number;
  content?: string;
  remind?: SaveReminderDTO;
}

export interface RequestNextActionApprovalFormSchemaI {
  users: BasedUser[];
  deadline: string;
  status?: number;
  reason?: string;
  remind?: ReminderSchemaI;
}

export const RequestNextActionApprovalFormSchema = Yup.object().shape({
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  deadline: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  reason: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});

export const castRequestNextActionApprovalFormSchemaToOutput = (
  schema: RequestNextActionApprovalFormSchemaI
): RequestNextActionApprovalFormOutput => {
  return {
    ...schema,
    status: schema.status && +schema.status,
    users: (schema.users ?? []).map((user) => user.id),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export const enum RequestNextActionApprovalFormSchemaFieldNames {
  USERS = "users",
  DEADLINE = "deadline",
  STATUS = "status",
  REASON = "reason",
  REMIND = "remind",
}

export interface ApproveNextActionFormOutput {
  nextActionIds?: number[];
  approvalStatus: number;
  status?: number;
  reason?: string;
  users?: string[];
  departments?: string[];
  nextActionId?: number[];
  remind?: SaveReminderDTO;
}

export interface ApproveNextActionFormSchemaI {
  approvalStatus: boolean;
  status: number;
  reason?: string;
  users: BasedUser[];
  departments: Department[];
  nextActionItems: NextActionItemSchemaI[];
  remind?: ReminderSchemaI;
}

export const ApproveNextActionFormSchema = Yup.object().shape({
  approvalStatus: Yup.boolean().required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  reason: Yup.string().optional(),
  departments: Yup.array(departmentSchema).required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  nextActionItems: Yup.array(NextActionItemSchema).required(),
  remind: ReminderSchema,
});

export const castNextActionInputToApproveNextActionFormSchema = (
  nextAction: NextActionInput
): ApproveNextActionFormSchemaI => {
  return {
    approvalStatus: false,
    status: -1,
    departments: [],
    users: [],
    nextActionItems: (nextAction.nextActionItems ?? []).map((item) =>
      convertNextActionItemInputToSchema(item)
    ),
  };
};

export const castApproveNextActionFormSchemaToOutput = (
  schema: ApproveNextActionFormSchemaI
): ApproveNextActionFormOutput => {
  return {
    status: schema.status,
    approvalStatus: schema.approvalStatus ? 1 : 0,
    departments: (schema.departments || []).map((department) => department.id),
    users: (schema.users ?? []).map((user) => user.id),
    nextActionId: (schema.nextActionItems ?? [])
      .filter((item) => item.deptHeadApprove)
      .map((item) => item?.nextActionItemId)
      .filter((id): id is number => id !== undefined),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export const enum ApproveNextActionFormSchemaFieldNames {
  APPROVE_STATUS = "approvalStatus",
  DEPARTMENTS = "departments",
  USERS = "users",
  STATUS = "status",
  REASON = "reason",
  REMIND = "remind",
  NEXT_ACTION_ITEM_ID = "nextActionItems",
}

export const enum FollowNextActionFormSchemaFieldNames {
  USERS = "users",
  STATUS = "status",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FollowNextActionFormOutput {
  users: string[];
  status: number;
  content?: string;
  remind?: SaveReminderDTO;
}

export const FollowNextActionFormSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().optional(),
  remind: ReminderSchema,
});

export const enum FinishEvaluateFormSchemaFieldNames {
  USERS = "users",
  STATUS = "status",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FinishEvaluateFormOutput {
  nextActionId?: number;
  evaluateDepartmentId?: string;
  evaluateUserId?: string;
  content?: string;
  status?: number;
  departments?: string[];
  users?: string[];
  remind?: SaveReminderDTO;
}

export const FinishEvaluateFormSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});

export const enum AssessmentFeedbackFormSchemaFieldNames {
  USERS = "users",
  STATUS = "status",
  CONTENT = "content",
  REMIND = "remind",
}
export interface AssessmentFeedbackFormOutput {
  nextActionId?: number;
  evaluateDepartmentId?: string;
  evaluateUserId?: string;
  content?: string;
  status?: number;
  departments?: string[];
  users?: string[];
  remind?: SaveReminderDTO;
}

export const AssessmentFeedbackFormSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});
