import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";

export interface RequestReviewLegalDocumentRequest {
  legalDocumentIds?: number[];
  departments: string[];
  users?: string[];
  deadline?: string;
  content?: string;
  status?: number;
  receiveFromVendorDate?: string;
  vendorResponseDate?: string;
  submissionDeadline?: string;
  departmentResponseDate?: string;
  publishDate?: string;
  effectiveDate?: string;
  remind?: SaveReminderDTO;
}

export const RequestReviewLegalDocumentRequestSchema = Yup.object().shape({
  departments: Yup.array()
    .min(1, VALIDATION_MSG.SELECT_DEPARTMENT)
    .required(VALIDATION_MSG.SELECT_DEPARTMENT),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  departmentResponseDate: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});

export interface RequestReviewLegalDocumentRequestSchemaI {
  legalDocumentIds?: number[];
  departments: string[];
  users?: BasedUser[];
  deadline?: string | undefined;
  content: string;
  status?: number;
  receiveFromVendorDate?: string | undefined;
  vendorResponseDate?: string | undefined;
  submissionDeadline?: string | undefined;
  departmentResponseDate: string;
  remind?: ReminderSchemaI | undefined;
}

export const enum RequestReviewLegalDocumentRequestFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}

export const castRequestReviewLegalDocumentRequestSchemaToDTO = (
  schema: RequestReviewLegalDocumentRequestSchemaI
): RequestReviewLegalDocumentRequest => {
  return {
    ...schema,
    users: schema?.users?.map((ele: BasedUser) => ele.id) ?? [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
