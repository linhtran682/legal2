import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createRequestApprovalMutationFn,
  createReviewApprovalMutationFn,
  getRequestApprovalQueryFn,
  updateRequestApprovalMutationFn,
} from "@/apis/service/law_document/requestApproval";
import { BasedUser } from "../user/User";
import { DetailModule } from "./LawDocument";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestApprovalRequestFieldNames {
  DEADLINE = "deadline",
  STATUS = "status",
  USERS = "users",
  REASON = "reason",
  DEPARTMENTS = "departments",
  REMIND = "remind",
  APPROVAL_STATUS = "approvalStatus",
  LEGAL_DOCUMENT_NAME = "legalDocumentName",
}

export interface RequestApprovalProps extends FieldValues {
  deadline?: string;
  approvalStatus?: number;
  status?: number;
  reason?: string;
  users?: BasedUser[];
  departments?: string[];
  remind?: SaveReminderDTO;
}
export interface RequestApprovalRequestSchemaI extends FieldValues {
  deadline?: string;
  approvalStatus?: number;
  status?: number;
  reason?: string;
  users?: string[];
  departments?: string[];
  remind?: SaveReminderDTO;
}

interface RemindContent {
  position?: number;
  remindReceiverType?: number;
  remindValueType?: number;
  timeStatus?: number;
  vendorResponseStatus?: number;
  time?: number;
  timeUnit?: number;
  legalStatus?: number;
  isSend?: boolean;
}

interface Remind {
  title?: string;
  module?: number;
  description?: string;
  remindContents?: {
    additionalProp1?: RemindContent[];
    additionalProp2?: RemindContent[];
    additionalProp3?: RemindContent[];
  };
  relatedUsers?: string[];
  receivingDepartment?: string[];
  receivedTitle?: string[];
}

export interface RequestApprovalUser {
  id?: string;
  name?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
}

export interface RequestApprovalDTO {
  legalDocumentName?: string | undefined;
  deadline?: string | undefined;
  status?: DetailModule;
  reason?: string;
  users?: BasedUser[];
  departments?: any;
  remind?: Remind;
}

export const ExtensionOptions: RadioItem[] = [
  {
    label: "Đồng ý",
    value: 1,
  },
  {
    label: "Từ chối",
    value: 0,
  },
];

export const RequestApprovalRequestSchema = Yup.object().shape({
  [RequestApprovalRequestFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalRequestFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalRequestFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalRequestFieldNames.USERS]: Yup.string()
  .required(VALIDATION_MSG.SELECT),
  [RequestApprovalRequestFieldNames.REMIND]: ReminderSchema,
});

export const ApprovalConfirmRequestSchema = Yup.object().shape({
  [RequestApprovalRequestFieldNames.APPROVAL_STATUS]: Yup.boolean().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalRequestFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalRequestFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalRequestFieldNames.REMIND]: ReminderSchema,
});

export interface RequestApprovalUpdate {
  requestApprovalIds?: number[];
  approvalStatus?: number;
  status?: number;
  reason?: string;
  users?: string[];
  departments?: string[];
  remind?: Remind;
}

export interface UpdateRequestApprovalBody {
  legalDocumentId?: number;
  requestApprovalId?: number;
  data?: RequestApprovalUpdate;
}

export interface CreateRequestApprovalBody {
  legalDocumentId?: number;
  data?: RequestApprovalRequestSchemaI;
}

export interface ReviewApprovalRequestSchemaI extends FieldValues {
  requestApprovalIds?: number[];
  approvalStatus?: number;
  status?: number;
  reason?: string;
  users?: string[];
  departments?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateReviewApprovalBody {
  legalDocumentId?: number;
  requestApprovalId?: number;
  data?: ReviewApprovalRequestSchemaI;
}

export interface CreateRequestApprovalOptions {
  config?: MutationConfig<typeof createRequestApprovalMutationFn>;
}

export interface CreateReviewApprovalOptions {
  config?: MutationConfig<typeof createReviewApprovalMutationFn>;
}

export type RequestApprovalParams = {
  legalDocumentId?: number;
  requestApprovalId?: number;
};

export type QueryFnType = typeof getRequestApprovalQueryFn;

export type GetRequestApprovalIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: RequestApprovalParams;
};
export type UpdateRequestApprovalOptions = {
  config?: MutationConfig<typeof updateRequestApprovalMutationFn>;
};
