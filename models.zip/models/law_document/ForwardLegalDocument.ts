import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";

export interface ForwardLegalDocumentRequest {
  legalDocumentIds?: number[];
  departments?: string[];
  users: string[];
  deadline?: string;
  content?: string;
  remind?: SaveReminderDTO;
}

export const ForwardLegalDocumentRequestSchema = Yup.object().shape({
  users: Yup.array()
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().optional(),
  remind: ReminderSchema,
});

export interface ForwardLegalDocumentRequestSchemaI {
  legalDocumentIds?: number[];
  users: BasedUser[];
  content?: string | undefined;
  remind?: ReminderSchemaI | undefined;
  departments?: string[];
}

export const enum ForwardLegalDocumentRequestFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}

export const castForwardLegalDocumentRequestSchemaToDTO = (
  schema: ForwardLegalDocumentRequestSchemaI
): ForwardLegalDocumentRequest => {
  return {
    ...schema,
    users: schema.users?.map((ele: BasedUser) => ele.id),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
