import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createFeedBackLcMutationFn } from "@/apis/service/law_document/feedbackLc";
import { VALIDATION_MSG } from "@/constants/message";
import { BasedUserSchema } from "../user/User";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedBackLcRequestFieldNames {
  USERS = "users",
  STATUS = "status",
  CONTENT = "content",
  REMIND = "remind",
}
export interface RequestFeedBackLcSchemaI extends FieldValues {
  users?: string[];
  content?: string;
  status?: number;
  nextActionId?: number;
  remind?: SaveReminderDTO;
}

export interface RequestApprovalUser {
  id?: string;
  name?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
}

export interface CreateFeedBackLcBody {
  legalDocumentId?: number;
  data?: RequestFeedBackLcSchemaI;
}

export interface CreateFeedBackLcOptions {
  config?: MutationConfig<typeof createFeedBackLcMutationFn>;
}

export const RequestFeedBackLcSchema = Yup.object().shape({
  [FeedBackLcRequestFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FeedBackLcRequestFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FeedBackLcRequestFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FeedBackLcRequestFieldNames.REMIND]: ReminderSchema,
});
