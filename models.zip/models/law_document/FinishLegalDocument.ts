import { VALIDATION_MSG } from "@/constants/message";
import {
  ReminderSchema,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { BasedUserSchema } from "../user/User";

export const enum FinishLegalDocumentFormSchemaFieldNames {
  USERS = "users",
  STATUS = "status",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FinishLegalDocumentFormOutput {
  users: string[];
  content?: string;
  status?: number;
  departments?: string[];
  remind?: SaveReminderDTO;
}

export const FinishLegalDocumentFormSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});
