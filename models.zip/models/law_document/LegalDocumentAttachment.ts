import { BasedUser } from "../user/User";

export interface LegalDocumentAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface GetLegalDocumentTabAttachmentsResponse {
  data: LegalDocumentAttachment[];
}
