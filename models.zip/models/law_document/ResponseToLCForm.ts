import { VALIDATION_MSG } from "@/constants/message";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser, BasedUserSchema } from "../user/User";
import * as Yup from "yup";

export interface ResponseToLCFormOutput {
  users: string[];
  status?: number;
  content?: string;
  remind?: SaveReminderDTO;
}

export interface ResponseToLCFormSchemaI {
  users: BasedUser[];
  status?: number;
  content?: string;
  remind?: ReminderSchemaI;
}

export const ResponseToLCFormSchema = Yup.object().shape({
  users: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  remind: ReminderSchema,
});

export const castResponseToLCFormSchemaToOutput = (
  schema: ResponseToLCFormSchemaI
): ResponseToLCFormOutput => {
  return {
    ...schema,
    users: (schema.users ?? []).map((user) => user.id),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export const enum ResponseToLCFormSchemaFieldNames {
  USERS = "users",
  STATUS = "status",
  CONTENT = "content",
  REMIND = "remind",
}
