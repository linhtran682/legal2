import { Department } from "../department/Department";

interface User {
  id: string;
  name: string;
  nameEnglish: string;
  email: string;
  department: Partial<Department>;
}

export interface DepartmentStatusDTO {
  requestApprovalIds: number[];
  department: Partial<Department>;
  users: User;
  evaluateId: 0;
  evaluate: string;
  nextActionId: 0;
  nextAction: string;
  status: 0;
  deadline: string;
  header: boolean;
}

export interface DepartmentStatusListResponse {
  departmentStatusList: DepartmentStatusDTO[];
  isCanFinish?: boolean
}
