import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { BasedUser } from "../user/User";

export interface EvaluateLegalDocumentRequest {
  status?: number;
  users: string[];
  remind?: SaveReminderDTO;
}

export const EvaluateLegalDocumentRequestSchema = Yup.object().shape({
  status: Yup.number()
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  users: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});

export interface EvaluateLegalDocumentRequestSchemaI {
  status?: number;
  remind?: ReminderSchemaI | undefined;
  users: BasedUser[];
  departments?: string[];
}

export const enum EvaluateLegalDocumentRequestFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}

export const castEvaluateLegalDocumentRequestSchemaToDTO = (
  schema: EvaluateLegalDocumentRequestSchemaI
): EvaluateLegalDocumentRequest => {
  return {
    ...schema,
    users: schema?.users?.map((ele: BasedUser) => ele.id),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
