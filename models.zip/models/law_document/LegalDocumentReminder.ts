import { VALIDATION_MSG } from "@/constants/message";

import * as Yup from "yup";
import {
  ReminderContent,
  ReminderContentSchemaI,
} from "../reminder_template/ReminderDTO";

export interface LegalDocumentRemindContent extends ReminderContent {
  position?: number;
  isSend?: boolean;
}

export const enum LegalDocumentRemindContentFieldNames {
  REMIND_RECEIVER_TYPE = "remindReceiverType",
  REMIND_VALUE_TYPE = "remindValueType",
  TIME_STATUS = "timeStatus",
  VENDOR_RESPONSE_STATUS = "vendorResponseStatus",
  TIME = "time",
  TIME_TYPE = "timeUnit",
  LEGAL_STATUS = "legalStatus",
  POSITION = "position",
  IS_SEND = "isSend",
}

export const LegalDocumentReminderContentSchema = Yup.object()
  .shape({
    remindReceiverType: Yup.number()
      .integer()
      .min(1)
      .max(8)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    remindValueType: Yup.number()
      .integer()
      .min(0)
      .max(2)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    timeStatus: Yup.number()
      .integer()
      .when(LegalDocumentRemindContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema.min(0).max(2).required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    vendorResponseStatus: Yup.number()
      .integer()
      .when(LegalDocumentRemindContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema.min(1).max(6).required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    time: Yup.number()
      .typeError(VALIDATION_MSG.MUST_BE_A_NUMBER)
      .integer()
      .when(LegalDocumentRemindContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema
            .positive(VALIDATION_MSG.GREATER_THAN_0)
            .required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    timeUnit: Yup.number()
      .integer()
      .when(LegalDocumentRemindContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema.min(1).max(3).required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    legalStatus: Yup.number()
      .integer()
      .when(LegalDocumentRemindContentFieldNames.REMIND_VALUE_TYPE, {
        is: 2,
        then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    position: Yup.number().optional(),
    isSend: Yup.boolean().required(),
  })
  .required();

export interface LegalDocumentReminderContentSchemaI
  extends ReminderContentSchemaI {
  position?: number | undefined;
  isSend: boolean;
}

export interface LegalDocumentReminder {
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[];
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: LegalDocumentRemindContent[] | undefined;
}

export const LegalDocumentReminderSchema = Yup.object()
  .shape({
    id: Yup.number().required(),
    title: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
    module: Yup.number()
      .integer()
      .min(1)
      .max(7)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    description: Yup.string().optional(),
    remindContents: Yup.array()
      .of(LegalDocumentReminderContentSchema)
      .optional(),
    relatedUsers: Yup.array().of(
      Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD)
    ),
    receivingDepartment: Yup.array().of(
      Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD)
    ),
    receivedTitle: Yup.array().of(
      Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD)
    ),
  })
  .optional();

export interface LegalDocumentReminderSchemaI {
  id: number;
  title: string;
  module: number;
  description?: string | undefined;
  remindContents?: LegalDocumentReminderContentSchemaI[] | undefined;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[] | undefined;
  receivedTitle?: string[] | undefined;
}

export const enum LegalDocumentReminderFieldNames {
  ID = "id",
  TITLE = "title",
  MODULE = "module",
  DESCRIPTION = "description",
  REMIND_CONTENTS = "remindContents",
  RELATED_USERS = "relatedUsers",
  RECEIVING_DEPARTMENT = "receivingDepartment",
  RECEIVED_TITLE = "receivedTitle",
}
