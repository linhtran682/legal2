import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface SendLegalDocumentRequest {
  userIds: string[];
  deadline?: string;
  content?: string;
  status: number;
  receiveFromVendorDate?: string;
  vendorResponseDate?: string;
  submissionDeadline?: string;
  departmentResponseDate?: string;
  publishDate?: string;
  effectiveDate?: string;
  remind?: SaveReminderDTO;
}

export const SendLegalDocumentRequestSchema = Yup.object().shape({
  userIds: Yup.array()
    .of(Yup.string().defined())
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  deadline: Yup.string().optional(),
  content: Yup.string().optional(),
  status: Yup.number()
    .min(0, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  receiveFromVendorDate: Yup.string().optional(),
  vendorResponseDate: Yup.string().optional(),
  submissionDeadline: Yup.string().optional(),
  departmentResponseDate: Yup.string().optional(),
  publishDate: Yup.string().optional(),
  effectiveDate: Yup.string().optional(),
  remind: ReminderSchema,
});

export interface SendLegalDocumentRequestSchemaI {
  userIds: string[];
  deadline?: string | undefined;
  content?: string | undefined;
  status: number;
  receiveFromVendorDate?: string | undefined;
  vendorResponseDate?: string | undefined;
  submissionDeadline?: string | undefined;
  departmentResponseDate?: string | undefined;
  publishDate?: string | undefined;
  effectiveDate?: string | undefined;
  remind?: ReminderSchemaI | undefined;
}

export const enum SendLegalDocumentRequestFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}

export const castSendLegalDocumentRequestSchemaToDTO = (
  schema: SendLegalDocumentRequestSchemaI
): SendLegalDocumentRequest => {
  return {
    ...schema,
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
