import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { VALIDATION_MSG } from "@/constants/message";
import { BasedUserSchema } from "../user/User";
import { createAssignmentMutationFn } from "@/apis/service/law_document/assignment";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum AssignmentFieldNames {
  USERS = "users",
  STATUS = "status",
  CONTENT = "content",
  REMIND = "remind",
}
export interface AssignmentSchemaI extends FieldValues {
  users?: any;
  content?: string;
  status?: number;
  nextActionId?: number;
  remind?: SaveReminderDTO;
}

export interface RequestApprovalUser {
  id?: string;
  name?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
}

export interface CreateAssignmentBody {
  legalDocumentId?: number;
  data?: AssignmentSchemaI;
}

export interface CreateAssignmentOptions {
  config?: MutationConfig<typeof createAssignmentMutationFn>;
}

export const AssignmentSchema = Yup.object().shape({
  [AssignmentFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AssignmentFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AssignmentFieldNames.REMIND]: ReminderSchema,
});
