import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderSchema,
  ReminderSchemaI,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createTimeExtensionMutationFn,
  getTimeExtensionQueryFn,
  updateTimeExtensionMutationFn,
} from "@/apis/service/law_document/time_extension";
import { SaveReminderDTO } from "./RequestApproval";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export const enum TimeExtensionRequestFieldNames {
  NEW_DEADLINE = "newDeadline",
  REASON = "reason",
  REMIND = "remind",
  CONFIRM = "confirm",
  ACCEPTABLE_DEADLINE = "acceptableDeadline",
  ACCEPTABLE_DEADLINE_REASON = "acceptableReason",
  USERS = "users",
  DEPARTMENTS = "departments",
}

export const ExtensionOptions: RadioItem[] = [
  {
    label: "Thời hạn mới",
    value: 0,
  },
  {
    label: "Đồng ý",
    value: 1,
  },
];

export const TimeExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.NEW_DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.REMIND]: ReminderSchema,
});

export const ConfirmExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.CONFIRM]: Yup.boolean().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD)
      }
      return schema.notRequired()
    }),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD)
      }
      return schema.notRequired()
    }),
});
export interface Department {
  id: string;
  code?: string;
  name?: string;
  nameEnglish?: string;
  description?: string;
  departmentType?: {
    id?: string;
    name?: string;
  };
  status?: "ACTIVE" | "INACTIVE";
}

export interface TimeExtensionUser {
  id?: string;
  name?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
}
export interface TimeExtensionRequestSchemaI extends FieldValues {
  newDeadline?: string;
  reason?: string;
  responsibleUsers?: TimeExtensionUser[];
  departments?: string[];
  remind?: ReminderSchemaI;
}

interface RemindContent {
  position?: number;
  remindReceiverType?: number;
  remindValueType?: number;
  timeStatus?: number;
  vendorResponseStatus?: number;
  time?: number;
  timeUnit?: number;
  legalStatus?: number;
  isSend?: boolean;
}
interface Remind {
  title?: string;
  module?: number;
  description?: string;
  remindContents?: {
    additionalProp1?: RemindContent[];
    additionalProp2?: RemindContent[];
    additionalProp3?: RemindContent[];
  };
  relatedUsers?: string[];
  receivingDepartment?: string[];
  receivedTitle?: string[];
}

export interface RequestApprovalDTO {
  newDeadline?: string | undefined;
  reason?: string | undefined;
  responsibleUsers?: TimeExtensionUser[];
  departments?: Department[];
  createdUser?: TimeExtensionUser;
  detailRemindNonTemplateResponse?: Remind;
}

interface TypeAcceptTimeExtension {
  acceptableDeadline?: string;
  acceptableReason?: string;
  users?: string[];
  departments?: string[];
  remind: SaveReminderDTO;
}

export interface UpdateTimeExtensionBody {
  legalDocumentId?: number;
  extendDeadlineId?: number;
  data?: TypeAcceptTimeExtension;
}

export interface CreateTimeExtensionBody {
  legalDocumentId?: number;
  data?: TimeExtensionRequestSchemaI;
  nextActionId?: number;
}

export interface CreateTimeExtensionOptions {
  config?: MutationConfig<typeof createTimeExtensionMutationFn>;
}

export type TimeExtensionParams = {
  legalDocumentId?: number;
  extendDeadlineId?: number;
};

export type QueryFnType = typeof getTimeExtensionQueryFn;

export type GetTimeExtensionIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: TimeExtensionParams;
};

export type UpdateTimeExtensionAcceptOptions = {
  config?: MutationConfig<typeof updateTimeExtensionMutationFn>;
};
