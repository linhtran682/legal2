import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { VALIDATION_MSG } from "@/constants/message";
import { BasedUserSchema } from "../user/User";
import { createRequestVendorMutationFn } from "@/apis/service/law_document/request_vendor";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestVendorFieldNames {
  USERS = "users",
  STATUS = "status",
  TIME_VENDOR_RESPONSE = "timeVendorResponse",
  REMIND = "remind",
}
export interface RequestVendorSchemaI extends FieldValues {
  users?: any;
  status?: number;
  timeVendorResponse?: string | Date | null;
  remind?: SaveReminderDTO;
}

export interface CreateRequestVendorBody {
  legalDocumentId?: number;
  data?: RequestVendorSchemaI;
}

export interface CreateRequestVendorOptions {
  config?: MutationConfig<typeof createRequestVendorMutationFn>;
}

export const RequestVendorSchema = Yup.object().shape({
  [RequestVendorFieldNames.TIME_VENDOR_RESPONSE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestVendorFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestVendorFieldNames.REMIND]: ReminderSchema,
});
