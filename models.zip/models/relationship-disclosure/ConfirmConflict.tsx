import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import { createForwardLegalAdviceMutationFn } from "@/apis/service/legal-advice/forwardLegalAdvice";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";
import { RelationshipDisclosureAttachment } from "./RelationshipDisclosureList";
import {
  createConfirmConflictMutationFn,
  deleteConfirmInformationMutationFn,
  deleteFollowMngMutationFn,
  getConfirmConflictQueryFn,
  getListConfirmInformationQueryFn,
  getListFollowQueryFn,
} from "@/apis/service/relationship_disclosure/relationMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ConfirmConflictFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
  STATUS = "status",
  ACCEPT = "accept",
}
export interface ConfirmConflictSchemaI {
  deadline?: string;
  content?: string;
  userIds?: string[];
  // departments?: string[];
  status?: number;
  remind?: SaveReminderDTO;
  accept?: number;
  attachments?: number[];
}
export interface ConfirmConflictSchemaII {
  deadline?: string;
  content?: string;
  userIds?: string[];
  // departments?: string[];
  status?: number;
  remind?: SaveReminderDTO;
  accept?: boolean;
  attachments?: number[];
}

export interface CreateConfirmBody {
  drId?: number;
  data?: ConfirmConflictSchemaII;
}

export interface CreateForwardLegalAdviceOptions {
  config?: MutationConfig<typeof createForwardLegalAdviceMutationFn>;
}

export const ConfirmConflictSchema = Yup.object().shape({
  [ConfirmConflictFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConfirmConflictFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConfirmConflictFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ConfirmConflictFieldNames.REMIND]: ReminderSchema,
});

export const castConfirmRequestSchemaToDTO = (
  schema: any
): ConfirmConflictSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
    accept: schema.accept === 0 ? true : false,
    attachments: schema.attachments,
  };
};

export interface CreateConfirmOptions {
  config?: MutationConfig<typeof createConfirmConflictMutationFn>;
}
export type QueryFnTypeConfirm = typeof getConfirmConflictQueryFn;

export interface GetConfirmConflictDTO {
  id?: number;
  userResponse?: BasedUser;
  deadline?: string;
  content?: string | undefined;
  attachmentResponses?: RelationshipDisclosureAttachment[];
  status?: number;
}

export type GetConfirmConflictIdOptions = {
  config?: QueryConfig<QueryFnTypeConfirm>;
  request: { drId?: number; confirmId?: number };
};
export interface ConflictInformation {
  id: number;
  userResponse: BasedUser;
  content?: string;
  status?: number;
  deadline?: number;
  attachmentResponses?: RelationshipDisclosureAttachment[];
}
export interface ConfirmInformationBodyReceive {
  responses?: ConflictInformation[];
}
export type QueryConflictManagementFnType =
  typeof getListConfirmInformationQueryFn;

export type GetConfirmOptions = {
  config?: QueryConfig<QueryConflictManagementFnType>;
  request: { drId: number };
};

export type DeleteConfirmInformationOptions = {
  config?: MutationConfig<typeof deleteConfirmInformationMutationFn>;
};

export type DeleteFollowOptions = {
  config?: MutationConfig<typeof deleteFollowMngMutationFn>;
};
export type QueryFollowMngFnType = typeof getListFollowQueryFn;

export type GetFollowOptions = {
  config?: QueryConfig<QueryFollowMngFnType>;
  request: { drId: number };
};
