import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import { ReminderInput } from "../reminder_template/ReminderDTO";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";

export interface RelationshipDisclosureAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface DetailPosition {
  id: string;
  name: string;
  nameEnglish?: string;
}

export const enum BaseRelationshipDisclosureFields {
  ID = "id",
  IS_DRAFT = "isDraft",
  PIC = "pic",
  DOCUMENT_NAME = "documentName",
  STATUS_CONFIRM = "statusConfirm",
  STATUS_EVALUATED = "statusEvaluate",
  EMPLOYEE_INFO_IDS = "employeeInfoIds",
  EMPLOYEE_NAME = "employeeName",
  EMPLOYEE_CODE = "employeeCode",
  EMPLOYEE_POSITION = "employeePosition",
  EMPLOYEE_DEPARTMENT = "employeeDepartment",
  OFFICER_INFO_NAME = "officerInfoName",
  OFFICER_INFO_AGENCY = "officerInfoAgency",
  EMPLOYEE_INFO_RESPONSE = "employeeInfoResponse",
  POSITION_NAME_CUSTOM = "positionNameCustom",
  DEPARTMENT_NAME_CUSTOM = "departmentNameCustom",
  GROUP_NAME = "groupName",
  WORKING_AREA = "workingArea",
  MANAGER = "manager",
  ATTACHMENTS = "receptionStaffInfoAttachments",
  OFFICER_INFO_RESPONSE = "officerInfoResponse",
  NAME = "name",
  AGENCY = "agency",
  POSITION = "position",
  ROLE_DESCRIPTION = "roleDescription",
  CHARACTERISTIC = "characteristic",
  RELATION_SHIP = "relationship",
  EMPLOYEES = "employees",
  CONFIRMATION_DEADLINE = "confirmationDeadline",
  CONFIRMATION_DEADLINE_FROM = "confirmationDeadlineFrom",
  CONFIRMATION_DEADLINE_TO = "confirmationDeadlineTo",
  LC_EMPLOYEES = "lcEmployees",
  LC_REVIEW_DEADLINE = "lcReviewDeadline",
  LC_REVIEW_DEADLINE_FROM = "lcReviewDeadlineFrom",
  LC_REVIEW_DEADLINE_TO = "lcReviewDeadlineTo",
  REMIND = "remind",
  CHECK_DEPT_HEAD_FLAG = "checkDeptHeadFlag",
  CHECK_DIVISION_FLAG = "checkDivisionFlag",
  OWNER_ROLES = "ownerRoles",
  APPROVED_FLAG = "approvedFlag",
  CONFIRM_FLAG = "confirmFlag",
  LC_EVALUATE_FLAG = "lcEvaluateFlag",
  BOOKING_FLAG = "bookingFlag",
  FINISH_FLAG = "finishFlag",
  BUTTON_ACTION = "buttonAction",
  EMPLOYEE_ID = "employeeId",

}
export interface BaseRelationshipDisclosure {
  id: number;
  pic?: BasedUser;
  [BaseRelationshipDisclosureFields.IS_DRAFT]: boolean;
  [BaseRelationshipDisclosureFields.DOCUMENT_NAME]: string;
  [BaseRelationshipDisclosureFields.STATUS_CONFIRM]: StatusDTO;
  [BaseRelationshipDisclosureFields.STATUS_EVALUATED]: StatusDTO;
  [BaseRelationshipDisclosureFields.EMPLOYEE_INFO_RESPONSE]: {
    id: number;
    employee: BasedUser;
    [BaseRelationshipDisclosureFields.POSITION_NAME_CUSTOM]?: string;
    [BaseRelationshipDisclosureFields.DEPARTMENT_NAME_CUSTOM]?: string;
    [BaseRelationshipDisclosureFields.GROUP_NAME]?: string;
    [BaseRelationshipDisclosureFields.WORKING_AREA]?: string;
    manager?: BasedUser;
  };
  [BaseRelationshipDisclosureFields.ATTACHMENTS]: LegalAdviceAttachment[];
  [BaseRelationshipDisclosureFields.OFFICER_INFO_RESPONSE]: {
    id: number;
    name: string;
    agency: string;
    position: string;
    roleDescription: string;
    characteristic: string;
  };
  [BaseRelationshipDisclosureFields.RELATION_SHIP]?: number[];
  [BaseRelationshipDisclosureFields.EMPLOYEES]: BasedUser[];
  [BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE]: string;
  [BaseRelationshipDisclosureFields.LC_EMPLOYEES]: BasedUser[];
  [BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE]: string;
  [BaseRelationshipDisclosureFields.REMIND]: ReminderInput;
  [BaseRelationshipDisclosureFields.CHECK_DIVISION_FLAG]: number;
  [BaseRelationshipDisclosureFields.CHECK_DEPT_HEAD_FLAG]: number;
  [BaseRelationshipDisclosureFields.OWNER_ROLES]?: number[];
  [BaseRelationshipDisclosureFields.BUTTON_ACTION]?: any;
  [BaseRelationshipDisclosureFields.APPROVED_FLAG]: number;
  [BaseRelationshipDisclosureFields.CONFIRM_FLAG]: number;
  [BaseRelationshipDisclosureFields.LC_EVALUATE_FLAG]: number;
  [BaseRelationshipDisclosureFields.BOOKING_FLAG]: number;
  [BaseRelationshipDisclosureFields.FINISH_FLAG]: number;
}

export type GetRelationshipDisclosureListParams = {
  picIds?: string[];
  [BaseRelationshipDisclosureFields.DOCUMENT_NAME]?: string;
  [BaseRelationshipDisclosureFields.EMPLOYEE_INFO_IDS]?: string;
  [BaseRelationshipDisclosureFields.EMPLOYEE_POSITION]?: string;
  [BaseRelationshipDisclosureFields.EMPLOYEE_DEPARTMENT]?: string;
  [BaseRelationshipDisclosureFields.OFFICER_INFO_NAME]?: string;
  [BaseRelationshipDisclosureFields.OFFICER_INFO_AGENCY]?: string;
  statusConfirm?: number[];
  statusEvaluate?: number[];
  [BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE_FROM]?: string;
  [BaseRelationshipDisclosureFields.CONFIRMATION_DEADLINE_TO]?: string;
  [BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE_FROM]?: string;
  [BaseRelationshipDisclosureFields.LC_REVIEW_DEADLINE_TO]?: string;
  employeeIds?: string[];
  lcEmployeeIds?: string[];
  sortBy: string;
  orderBy: string;
  page: number;
  size: number;
  tab?: number;
  isPanelSearch?: boolean;
  isEnglish?: boolean;
  departmentIds?: string;
  createFrom?: string;
  createTo?: string;
  statusList?: number[] | string | undefined;
};
export interface GetRelationShipDisclosureListResponse {
  total: number;
  data: BaseRelationshipDisclosure[];
}
