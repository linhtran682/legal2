import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";
import { createFinishConflictMngMutationFn, getUserDefaultQueryFn } from "@/apis/service/relationship_disclosure/relationMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FinishConflictMngFieldNames {
  STATUS = "status",
  CONTENT = "content",
  USER_IDS = "userIds",
  REMIND = "remind",
  DEADLINE = "deadline",
}
export interface FinishConflictMngSchemaI extends FieldValues {
  status?: number;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export const FinishConflictMngSchema = Yup.object().shape({
  [FinishConflictMngFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FinishConflictMngFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FinishConflictMngFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FinishConflictMngFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FinishConflictMngFieldNames.REMIND]: ReminderSchema,
});

export interface CreateFinishConflictMngBody {
  data?: FinishConflictMngSchemaI;
  drId?: number;
}

export interface CreateFinishConflictMngOptions {
  config?: MutationConfig<typeof createFinishConflictMngMutationFn>;
}
//get user
export interface GetUserDefaultForFinishPopupResponse {
   [x: string]: any;
   user: Array<BasedUser>
}
export interface GetUserDefaultParams{
  conflictId?: number
}
export type QueryFnUserType = typeof getUserDefaultQueryFn;

export type GetUserDefaultForFinishPopupOptions = {
  config?: QueryConfig<QueryFnUserType>;
  request: GetUserDefaultParams;
};