import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { VALIDATION_MSG } from "@/constants/message";
import { createRequestApproveConflictMutationFn } from "@/apis/service/relationship_disclosure/relationMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestApprovalConflictFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
  STATUS = "status",
}
export interface RequestApprovalConflictSchemaI {
  deadline?: string;
  content?: string;
  userIds?: string;
  status?: number;
  remind?: SaveReminderDTO;
}
export interface RequestApprovalConflictSchemaII {
  deadline?: string;
  content?: string;
  userIds?: string[];
  // departments?: string[];
  status?: number;
  remind?: SaveReminderDTO;
}
export interface CreateRequestApprovalBody {
  drId?: number;
  data?: RequestApprovalConflictSchemaI;
}

export const ConfirmRequestApprovalSchema = Yup.object().shape({
  [RequestApprovalConflictFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalConflictFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestApprovalConflictFieldNames.USERS_IDS]: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestApprovalConflictFieldNames.REMIND]: ReminderSchema,
});

export const castRequestApprovalConflictSchemaToDTO = (
  schema: any
): RequestApprovalConflictSchemaII => {
  return {
    ...schema,
    userIds: [schema.userIds],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export interface CreateRequestApprovalOptions {
  config?: MutationConfig<typeof createRequestApproveConflictMutationFn>;
}
