import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser, BasedUserSchema } from "../user/User";

export interface RequestEvalueConflictSchemaI {
  deadline?: string;
  content?: string;
  userIds?: string[];
  status?: number;
  remind?: SaveReminderDTO;
}

export const enum RequestEvaluateConflictFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
  STATUS = "status",
}
export const RequestEvaluateConflictSchema = Yup.object().shape({
  [RequestEvaluateConflictFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestEvaluateConflictFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestEvaluateConflictFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestEvaluateConflictFieldNames.REMIND]: ReminderSchema,
});

export const castRequestEvaluateConflictSchemaToDTO = (
  schema: any
): RequestEvalueConflictSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };  
};
