import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderSchema,
  ReminderSchemaI,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";

import { VALIDATION_MSG } from "@/constants/message";
import { SaveReminderDTO } from "./ForwardConflict";
import { createTimeExtensionMutationFn, getTimeExtensionQueryFn, updateTimeExtensionMutationFn } from "@/apis/service/relationship_disclosure/relationMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export const enum TimeExtensionRequestFieldNames {
  DEADLINE = "deadline",
  REASON = "reason",
  REMIND = "remind",
  CONFIRM = "confirm",
  ACCEPTABLE_DEADLINE = "acceptableDeadline",
  ACCEPTABLE_DEADLINE_REASON = "acceptableReason",
  USERS = "users",
  TINMEEXTENTIONTYPE= "timeExtensionType"
}

export const ExtensionOptions: RadioItem[] = [
  {
    label: "Thời hạn mới",
    value: 0,
  },
  {
    label: "Đồng ý",
    value: 1,
  },
];

export const TimeExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.REMIND]: ReminderSchema,
  [TimeExtensionRequestFieldNames.TINMEEXTENTIONTYPE]: Yup.boolean().optional(),
});

export const ConfirmExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.CONFIRM]: Yup.boolean().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE]: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD);
      }
      return schema.notRequired();
    }),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON]: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD);
      }
      return schema.notRequired();
    }),
    [TimeExtensionRequestFieldNames.TINMEEXTENTIONTYPE]: Yup.boolean().optional(),
});
export interface Department {
  id: string;
  name?: string;
  nameEnglish?: string;
}

export interface TimeExtensionUser {
  id?: string;
  name?: string | undefined;
  nameEnglish?: string;
  email?: string | undefined;
  department?: Department;
}
export interface TimeExtensionRequestSchemaI extends FieldValues {
  deadline?: string;
  reason?: string;
  remind?: ReminderSchemaI;
  timeExtensionType?: number
}

export interface RequestApprovalDTO {
  id?: number;
  deadline?: string;
  reason?: string | undefined;
  user?: TimeExtensionUser;
  department?: Department;
}

interface TypeAcceptTimeExtension {
  deadlineAccept?: string;
  reason?: string;
  type?: number;
  users?: string[];
  remind: SaveReminderDTO;
}
export interface UpdateTimeExtensionBody {
  drId?: number;
  timeExtensionRequestId?: number;
  data?: TypeAcceptTimeExtension;
}

export interface CreateTimeExtensionBody {
  drId?: number;
  data?: TimeExtensionRequestSchemaI;
}

export interface CreateTimeExtensionOptions {
  config?: MutationConfig<typeof createTimeExtensionMutationFn>;
}

export type TimeExtensionParams = {
  drId?: number;
  timeExtensionRequestId?: number;
};

export type QueryFnType = typeof getTimeExtensionQueryFn;

export type GetTimeExtensionIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: TimeExtensionParams;
};

export type UpdateTimeExtensionAcceptOptions = {
  config?: MutationConfig<typeof updateTimeExtensionMutationFn>;
};
