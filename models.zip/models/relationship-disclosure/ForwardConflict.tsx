import { FieldValues } from "react-hook-form";
import { castReminderSchemaToSaveReminderDTO, ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";
import { createForwardConflictMngMutationFn } from "@/apis/service/relationship_disclosure/relationMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ForwardConflictMngFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface ForwardConflictMngSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  // departments?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateForwardConflictMngBody {
  lcsId ?: number;
  data?: ForwardConflictMngSchemaI;
}

export interface CreateForwardConflictMngOptions {
  config?: MutationConfig<typeof createForwardConflictMngMutationFn>;
}

export const ForwardConflictMngSchema = Yup.object().shape({
  [ForwardConflictMngFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ForwardConflictMngFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ForwardConflictMngFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ForwardConflictMngFieldNames.REMIND]: ReminderSchema,
});

export const castForwardConflictMngRequestSchemaToDTO = (
  schema: any
): ForwardConflictMngSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };  
};