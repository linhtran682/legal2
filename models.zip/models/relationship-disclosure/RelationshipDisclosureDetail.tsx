import { VALIDATION_MSG } from "@/constants/message";
import {
  ReminderInput,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { MutationConfig, QueryConfig } from "@/apis";
import { Position, UserProfileDTO } from "../user/User";
import { Department, DepartmentSchema } from "../department/Department";
import { StatusDTO } from "../status/Status";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import { GenericSearchPanelProps } from "@/components/commons/search_panel/GenericSearchPanel";
import {
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
  RelationshipDisclosureStatusContent,
  RelationshipDisclosureStatusKey,
} from "@/constants/general";
import { RELATIONSHIP_DISCLOSURE_ROOT_PATH } from "@/constants/paths";
import { formatDate } from "@/utils";
import { RelationshipDisclosureAttachment } from "./RelationshipDisclosureList";
import {
  createRelationShipDisclosureMutationFn,
  deleteEvaluateMngMutationFn,
  getAllHierarchyById,
  getListRelationShipDisclosureQueryFn,
  getRelationShipDisclosureQueryFn,
  updateBookMeetingRelationShipDisclosureMutationFn,
  updateRelationShipDisclosureMutationFn,
} from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";
export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}
export interface BasedUser {
  id: string;
  name?: string | undefined;
  nameEnglish?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
  department: DepartmentSchema;
  basicPosition?: Position;
  position?: Position;
  positionResponse?: Position;
  departmentResponse?: DepartmentSchema;
}
export const enum RelationshipDisclosureDetailFields {
  DOCUMENT_ID = "documentId",
  FILES = "files",
  IS_DRAFT = "isDraft",
  PIC = "pic",
  DOCUMENT_NAME = "documentName",
  STATUS_CONFIRM = "statusConfirmId",
  STATUS_EVALUATED = "statusEvaluateId",
  ATTACHMENTS = "employeeInfoAttachmentIds",
  EMPLOYEE_NAME = "employeeName",
  EMPLOYEE_ID = "employeeId",
  DEPARTMENT_ID = "departmentId",
  DEPARTMENT_NAME_CUSTOM = "departmentNameCustom",
  POSITION_NAME_CUSTOM = "positionNameCustom",
  MANAGER_ID = "managerId",
  GROUP_NAME = "groupName",
  WORKING_AREA = "workingArea",
  NAME = "name",
  AGENCY = "agency",
  POSITION = "position",
  ROLE_DESCRIPTION = "roleDescription",
  CHARACTERISTIC = "characteristic",
  RELATION_SHIP = "relationship",
  REASON_RELATION_SHIP = "reasonRelationship",
  CONFIRMATION_DEADLINE = "confirmationDeadline",
  EMPLOYEE_IDS = "employeeIds",
  LC_EMPLOYEE_IDS = "lcEmployeeIds",
  LC_EMPLOYEES = "lcEmployees",
  LC_REVIEW_DEADLINE = "lcReviewDeadline",
  REMIND = "remind",
  CHECK_DEPT_HEAD_FLAG = "checkDeptHeadFlag",
  CHECK_DIVISION_FLAG = "checkDivisionFlag",
}

export type TypeRelationshipDisclosureForm = {
  [RelationshipDisclosureDetailFields.IS_DRAFT]?: boolean;
  [RelationshipDisclosureDetailFields.FILES]?: any;
  [RelationshipDisclosureDetailFields.DOCUMENT_NAME]?: string;
  [RelationshipDisclosureDetailFields.STATUS_EVALUATED]?: number;
  [RelationshipDisclosureDetailFields.STATUS_CONFIRM]?: number;
  [RelationshipDisclosureDetailFields.RELATION_SHIP]?: number[];
  [RelationshipDisclosureDetailFields.ATTACHMENTS]?: number[];
  [RelationshipDisclosureDetailFields.EMPLOYEE_ID]?: string;
  [RelationshipDisclosureDetailFields.EMPLOYEE_NAME]?: string;
  [RelationshipDisclosureDetailFields.DEPARTMENT_ID]?: string;
  [RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM]?: string;
  [RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM]?: string;
  [RelationshipDisclosureDetailFields.MANAGER_ID]?: string;
  [RelationshipDisclosureDetailFields.GROUP_NAME]?: string;
  [RelationshipDisclosureDetailFields.WORKING_AREA]?: string;
  [RelationshipDisclosureDetailFields.NAME]?: string;
  [RelationshipDisclosureDetailFields.AGENCY]?: string;
  [RelationshipDisclosureDetailFields.POSITION]?: string;
  [RelationshipDisclosureDetailFields.ROLE_DESCRIPTION]?: string;
  [RelationshipDisclosureDetailFields.CHARACTERISTIC]?: string;
  [RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]?: boolean;
  [RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG]?: boolean;
  [RelationshipDisclosureDetailFields.EMPLOYEE_IDS]?: UserProfileDTO[];
  [RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE]?: string | Date;
  [RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS]?: UserProfileDTO;
  [RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE]?: string | Date;
  [RelationshipDisclosureDetailFields.REMIND]?: ReminderSchemaI;
};

export interface RelationshipDisclosureBodySend {
  documentId?: number;
  [RelationshipDisclosureDetailFields.IS_DRAFT]?: boolean;
  [RelationshipDisclosureDetailFields.DOCUMENT_NAME]: string;
  [RelationshipDisclosureDetailFields.STATUS_EVALUATED]: number;
  [RelationshipDisclosureDetailFields.STATUS_CONFIRM]: number;
  employeeInfoRequest: {
    [RelationshipDisclosureDetailFields.EMPLOYEE_ID]: string;
    [RelationshipDisclosureDetailFields.DEPARTMENT_ID]: string;
    [RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM]?: string;
    [RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM]?: string;
    [RelationshipDisclosureDetailFields.MANAGER_ID]: string;
    [RelationshipDisclosureDetailFields.GROUP_NAME]: string;
    [RelationshipDisclosureDetailFields.WORKING_AREA]: string;
  };
  [RelationshipDisclosureDetailFields.ATTACHMENTS]: number[];
  officerInfoRequest: {
    name: string;
    agency: string;
    position: string;
    roleDescription: string;
    characteristic: string;
  };
  [RelationshipDisclosureDetailFields.RELATION_SHIP]?: number[];
  [RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]?: number;
  [RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG]?: number;
  [RelationshipDisclosureDetailFields.EMPLOYEE_IDS]: string[];
  [RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE]: string;
  [RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS]?: string[];
  [RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE]: string;
  [RelationshipDisclosureDetailFields.REMIND]: SaveReminderDTO;
}

export interface RelationshipDisclosureBodyReceive {
  id: number;
  [RelationshipDisclosureDetailFields.IS_DRAFT]?: boolean;
  pic?: BasedUser;
  [RelationshipDisclosureDetailFields.DOCUMENT_NAME]: string;
  statusConfirm: StatusDTO;
  statusEvaluate: StatusDTO;
  employeeInfoResponse: {
    id?: number;
    employee?: BasedUser;
    [RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM]?: string;
    [RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM]?: string;
    [RelationshipDisclosureDetailFields.GROUP_NAME]?: string;
    [RelationshipDisclosureDetailFields.WORKING_AREA]?: string;
    manager: BasedUser;
  };
  receptionStaffInfoAttachments: LegalAdviceAttachment[];
  officerInfoResponse: {
    id: number;
    name: string;
    agency: string;
    position: string;
    roleDescription: string;
    characteristic: string;
  };
  [RelationshipDisclosureDetailFields.RELATION_SHIP]: number[];
  [RelationshipDisclosureDetailFields.REASON_RELATION_SHIP]?: string;
  employees?: BasedUser[];
  [RelationshipDisclosureDetailFields.EMPLOYEE_IDS]?: string[];
  [RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE]?: string;
  [RelationshipDisclosureDetailFields.LC_EMPLOYEES]?: BasedUser[];
  [RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE]: string;
  [RelationshipDisclosureDetailFields.REMIND]: ReminderInput;
  [RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]?: number;
  [RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG]?: number;
  ownerRoles?: number[];
  buttonAction?: object;
  approvedFlag?: boolean;
  confirmFlag?: boolean;
  lcEvaluateFlag?: boolean;
  bookingFlag?: boolean;
  finishFlag?: boolean;
  confirmValue?: number;
}
export const SaveRelationshipDisclosureRequestCreateSchema = Yup.object().shape({
  [RelationshipDisclosureDetailFields.DOCUMENT_NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
})
export const SaveRelationshipDisclosureRequestSchema = Yup.object().shape({
  files: Yup.mixed().required(VALIDATION_MSG.SELECT),
  // [RelationshipDisclosureDetailFields.DOCUMENT_NAME]: Yup.string().required(
  //   VALIDATION_MSG.REQUIRED_FIELD
  // ),
  [RelationshipDisclosureDetailFields.STATUS_EVALUATED]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.STATUS_CONFIRM]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.EMPLOYEE_NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [RelationshipDisclosureDetailFields.GROUP_NAME]: Yup.string().optional(),
  [RelationshipDisclosureDetailFields.WORKING_AREA]: Yup.string().optional(),
  [RelationshipDisclosureDetailFields.MANAGER_ID]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.AGENCY]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.POSITION]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.ROLE_DESCRIPTION]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.CHARACTERISTIC]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RelationshipDisclosureDetailFields.RELATION_SHIP]: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  [RelationshipDisclosureDetailFields.REASON_RELATION_SHIP]: Yup.string().optional(),
  [RelationshipDisclosureDetailFields.EMPLOYEE_IDS]: Yup.string().optional(),
  [RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]: Yup.boolean(),
    [RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG]: Yup.boolean(),
  [RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS]: Yup.string().optional(),
  [RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [RelationshipDisclosureDetailFields.REMIND]: ReminderSchema,
}).test(
  'head-checkbox',
  'CONFLICT_MANAGEMENT.messages.requiredToBeSentTo',
  (values) => values.checkDeptHeadFlag || values.checkDivisionFlag
);

enum SearchPanelQueries {
  GET_HIERARCHY = "relationship-disclosure/get-hierarchy",
  SEARCH_DOCUMENT = "relationship-disclosure/search_document",
  SEARCH_KEY = "relationshipDisclosureName",
}

export const relationshipDisclosureSearchPanelConfig: GenericSearchPanelProps<any> =
  {
    completeStatusName: LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.DONE
    )!,
    getHierarchyFn: (id) => getAllHierarchyById({ id }),
    getItemKey: (item) => item?.documentId ?? item?.id,
    getChildKey: (child) => child?.documentId ?? child?.id,
    getSearchResultFn: getListRelationShipDisclosureQueryFn,
    hierarchyQueryKey: SearchPanelQueries.GET_HIERARCHY,
    searchQueryKey: SearchPanelQueries.SEARCH_DOCUMENT,
    searchKey: SearchPanelQueries.SEARCH_KEY,
    getItemName: (item) => item?.documentName,
    getCreator: (item) => item?.pic ?? item?.createdUser,
    getParentTimeLabel: (item) =>
      item?.createdDate
        ? formatDate(item?.createdDate, "dd/MM/yyyy HH:mm")
        : "",
    getParentUsersList: (item) => item?.employees ?? item?.users,
    getParentStatus: (item) =>
      item?.status?.name ??
      item?.statusConfirm?.name ??
      item?.statusEvaluate?.name ??
      item?.status ??
      item?.statusConfirm ??
      item?.statusEvaluate ??
      "",
    getChildStatus: (child) =>
      child?.status?.name ??
      child?.statusConfirm?.name ??
      child?.statusEvaluate?.name ??
      child?.status ??
      child?.statusConfirm ??
      child?.statusEvaluate ??
      "",
    getChildTimeLabel: (child) =>
      child?.createdDate
        ? formatDate(child?.createdDate, "dd/MM/yyyy HH:mm")
        : "",
    getChildUsersList: (child) => child?.employees,
    getChildren: (item) =>
      item?.children ?? item?.relationShipChild ?? [],
    getItemLink: (item) =>
      `/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/update/${
        item?.documentId ?? item?.id
      }`,
  };

//api

export type RelationShipDisclosureParams = {
  id?: number;
};

export type QueryRelationShipDisclosureFnType =
  typeof getRelationShipDisclosureQueryFn;

export type GetRelationShipDisclosureOptions = {
  config?: QueryConfig<QueryRelationShipDisclosureFnType>;
  request: RelationShipDisclosureParams;
};

export interface CreateRelationShipDisclosureOptions {
  config?: MutationConfig<typeof createRelationShipDisclosureMutationFn>;
}

export type UpdateRelationShipDisclosureRequest = {
  id?: number;
  request?: RelationshipDisclosureBodySend;
};

export type UpdateRelationShipDisclosureOptions = {
  config?: MutationConfig<typeof updateRelationShipDisclosureMutationFn>;
};

export type UpdateBookMeetingRelationShipDisclosureOptions = {
  config?: MutationConfig<
    typeof updateBookMeetingRelationShipDisclosureMutationFn
  >;
};

export interface RelationShipRequestFeedback {
  // Phản hồi đến yêu cầu tư vấn
  feedbackUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
  deadlineNew?: string;
}
export interface GetRelationShipRequestFeedbackResponse {
  feedbackResponseDetails: RelationShipRequestFeedback[];
}

export interface RelationShipExtension {
  user: BasedUser;
  reason: string;
  requestDeadline: string;
  acceptDeadline: string;
  date: string;
  type?: number;
  id: number;
  showExtension?: boolean;
  enableExtension?: boolean;
}

export interface GetRelationShipExtensionResponse {
  timeExtensionResponseDetails: RelationShipExtension[];
}
export interface RelationShipDisclosureForward {
  forwardUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  forwardDate: string;
}
export interface GetRelationShipForwardResponse {
  forwardResponseDetails: RelationShipDisclosureForward[];
}

export interface RelationShipDisclosureConfirm {
  id: number;
  userResponse: BasedUser;
  content?: string;
  status?: number;
  deadline?: number;
  attachmentResponses?: RelationshipDisclosureAttachment[];
}
export interface GetRelationShipConfirmResponse {
  responses: RelationShipDisclosureConfirm[];
}
export interface RelationShipApproval {
  user: BasedUser;
  status?: number;
  content?: string;
}
export interface GetRelationShipApprovalResponse {
  requestApproveResponses?: RelationShipApproval[];
}
export interface RelationShipEvaluateTab {
  department?: Department;
  user?: BasedUser;
  deadline?: number;
  createTime?: string;
  evaluateUser?: BasedUser;
  type?: number;
  evaluated?: boolean;
  content?: string;
}
export interface GetRelationShipEvaluateTabResponse {
  responses: RelationShipEvaluateTab[];
}
export interface RelationShipEvaluateList {
  id: number;
  userResponse: BasedUser;
  content?: string;
  attachments?: RelationshipDisclosureAttachment[];
  deadline?: number;
  status?: number;
  editAvailable?: boolean;
  accept?: boolean;
}
export interface GetListRelationShipEvaluateResponse {
  responses: RelationShipEvaluateList[];
}

export interface ButtonAction {
  requestEvaluate: number;
  follow: number;
  informationRequest: number;
  confirm: number;
  finish: number;
  evaluate: number;
  requestApprove: number;
  approve: number;
  timeExtensionRequest: number;
  timeExtension: number;
  recall: number;
  sendMail: number;
  forward: number;
  requestMeeting: number;
  feedback: number;
}

export type DeleteEvaluateIdOptions = {
  config?: MutationConfig<typeof deleteEvaluateMngMutationFn>;
};

export const listStatusConfirmRelation = [
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.REQUEST_ADDITIONAL
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.INFORMATION_PROVIDED
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.REQUEST_CONFIRMATION
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.CONFIRM
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.CONFIRM_REJECTED
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.DONE
  )!,
];

export const listStatusEvaluateRelation = [
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.REQUEST_ADDITIONAL
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.INFORMATION_PROVIDED
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.REQUEST_REVIEW
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.REVIEW_COMMENTED
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.REVIEW_REJECTED
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.REQUEST_APPROVAL
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.APPROVAL
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.APPROVAL_REQUEST_FOLLOW
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.APPROVAL_REJECTED
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.DECLARATION_MONITORING
  )!,
  RelationshipDisclosureStatusContent.get(
    RelationshipDisclosureStatusKey.DONE
  )!,
];
