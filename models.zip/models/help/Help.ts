import { VALIDATION_MSG } from "@/constants/message";
import { FieldValues } from "react-hook-form";
import * as Yup from "yup";

export interface HelpDTO {
  id: number;
  name: string;
  helpName: string;
  module: number;
  active: number;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
}

export const enum HelpFieldNames {
  ID = "id",
  NAME = "name",
  HELP_NAME = "helpName",
  MODULE = "module",
  ACTIVE = "active",
  DESCRIPTION = "description",
  CREATED_BY = "createdBy",
  CREATED_AT = "createdAt",
}

export interface GetHelpListParams {
  name?: string;
  helpName?: string;
  modules?: number[];
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export interface GetHelpListResponse {
  total: number;
  fieldResponses: HelpDTO[];
}

export interface SaveHelpDTO {
  name?: string;
  helpName: string;
  module?: number;
  active?: number;
  description?: string;
}

export const enum SaveHelpRequestFieldNames {
  NAME = "name",
  HELP_NAME = "helpName",
  MODULE = "module",
  ACTIVE = "active",
  DESCRIPTION = "description",
}

export const SaveHelpRequestSchema = Yup.object().shape({
  name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  helpName: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  active: Yup.number()
    .integer()
    .min(0)
    .max(1)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  description: Yup.string().optional(),
});

export interface SaveHelpRequestSchemaI extends FieldValues {
  description?: string | undefined;
  name: string;
  helpName: string;
  active: number;
}
