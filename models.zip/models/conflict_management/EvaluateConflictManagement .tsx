import { castReminderSchemaToSaveReminderDTO, ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createForwardLegalAdviceMutationFn } from "@/apis/service/legal-advice/forwardLegalAdvice";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";
import { createEvaluateConflictMutationFn } from "@/apis/service/conflict_management/conflictMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum EvaluateConflictFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
  STATUS = "status",
  ACCEPT = "accept"
}
export interface EvaluateConflictSchemaI {
  deadline?: string;
  content?: string;
  userIds?: string[];
  status?: number;
  remind?: SaveReminderDTO;
  accept?: number;
  attachmentIds?: number[]
}
export interface EvaluateConflictSchemaII {
  deadline?: string;
  content?: string;
  userIds?: string[];
  status?: number;
  remind?: SaveReminderDTO;
  accept?: boolean;
  attachmentIds?: number[]
}

export interface CreateEvaluateBody {
  ciId?: number;
  data?: EvaluateConflictSchemaII;
}

export interface CreateForwardLegalAdviceOptions {
  config?: MutationConfig<typeof createForwardLegalAdviceMutationFn>;
}

export const ConfirmConflictSchema = Yup.object().shape({
  [EvaluateConflictFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [EvaluateConflictFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [EvaluateConflictFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [EvaluateConflictFieldNames.REMIND]: ReminderSchema,
});

export const castEvaluateSchemaToDTO = (
  schema: any
): EvaluateConflictSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
    accept: schema.accept === 0 ? true : false,
    attachmentIds: schema.attachmentIds
  };  
};

export interface CreateEvaluateOptions {
  config?: MutationConfig<typeof createEvaluateConflictMutationFn>;
}

export const EvaluateConflictOptions: RadioItem[] = [
  {
    label: "Đã đánh giá/nhận xét",
    value: 0,
  },
  {
    label: "Đánh giá: Từ chối",
    value: 1,
  },
];