import { VALIDATION_MSG } from "@/constants/message";
import {
  ReminderInput,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { ConflictManagementAttachment } from "./ConflictManagementList";
import * as Yup from "yup";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createConflictManagementMutationFn,
  deleteEvaluateMngMutationFn,
  getAllHierarchyById,
  getConflictManagementQueryFn,
  getListConflictManagementQueryFn,
  updateBookMeetingConflictManagementMutationFn,
  updateConflictManagementMutationFn,
} from "@/apis/service/conflict_management/conflictManagementForm";
import { Position, UserProfileDTO } from "../user/User";
import { Department, DepartmentSchema } from "../department/Department";
import { StatusDTO } from "../status/Status";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import { GenericSearchPanelProps } from "@/components/commons/search_panel/GenericSearchPanel";
import {
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
} from "@/constants/general";
import { CONFLICT_MANAGEMENT_ROOT_PATH } from "@/constants/paths";
import { formatDate } from "@/utils";
export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}
export interface BasedUser {
  id: string;
  name?: string | undefined;
  nameEnglish?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
  department: DepartmentSchema;
  basicPosition?: Position;
  position?: Position;
  positionResponse?: Position;
  departmentResponse?: DepartmentSchema;
}
export const enum ConflictManagementDetailFields {
  IS_DRAFT = "isDraft",
  CONFLICT_NAME = "conflictName",
  STATUS_EVALUATED = "statusEvaluateId",
  STATUS_CONFIRM = "statusConfirmId",
  EMPLOYEE_CODE = "employeeCode",
  EMPLOYEE_NAME = "employeeName",
  DEPARTMENT = "departmentId",
  DEPARTMENT_NAME_CUSTOM = "departmentNameCustom",
  POSITION = "position",
  POSITION_NAME_CUSTOM = "positionNameCustom",
  MANAGER_ID = "managerId",
  ATTACHMENTS = "employeeAttachmentIds",
  CONFLICT_OBJECT_NAME = "conflictObjectName",
  CONFLICT_OBJECT_AGENCY = "conflictObjectAgency",
  CONFLICT_OBJECT_POSITION = "conflictObjectPosition",
  CONFLICT_OBJECT_RELATION = "conflictObjectRelation",
  NATURE_CONFLICT = "natureConflict",
  REASON_CONFLICT = "reasonConflict",
  CONFLICT_DETAIL = "conflictDetail",
  CONFLICT_RESOLUTION = "conflictResolution",
  CHECK_DEPT_HEAD_FLAG = "checkDeptHeadFlag",
  CHECK_DIVISION_FLAG = "checkDivisionFlag",
  EMPLOYEE_IDS = "employeeIds",
  CONFIRMATION_DEADLINE = "confirmationDeadline",
  LC_EMPLOYEES = "lcEmployees",
  LC_REVIEW_DEADLINE = "lcReviewDeadline",
  REMIND = "remind",
  FILES = "files",
}

export type TypeConflictManagementForm = {
  [ConflictManagementDetailFields.IS_DRAFT]?: boolean;
  [ConflictManagementDetailFields.FILES]?: any;
  [ConflictManagementDetailFields.CONFLICT_NAME]?: string;
  [ConflictManagementDetailFields.STATUS_EVALUATED]?: number;
  [ConflictManagementDetailFields.STATUS_CONFIRM]?: number;
  [ConflictManagementDetailFields.EMPLOYEE_CODE]?: string;
  [ConflictManagementDetailFields.EMPLOYEE_NAME]?: string;
  [ConflictManagementDetailFields.DEPARTMENT]?: string;
  [ConflictManagementDetailFields.POSITION]?: string;
  [ConflictManagementDetailFields.MANAGER_ID]?: string;
  [ConflictManagementDetailFields.CONFLICT_OBJECT_NAME]?: string;
  [ConflictManagementDetailFields.CONFLICT_OBJECT_AGENCY]?: string;
  [ConflictManagementDetailFields.CONFLICT_OBJECT_POSITION]?: string;
  [ConflictManagementDetailFields.CONFLICT_OBJECT_RELATION]?: string;
  [ConflictManagementDetailFields.NATURE_CONFLICT]?: number[];
  [ConflictManagementDetailFields.REASON_CONFLICT]?: string;
  [ConflictManagementDetailFields.CONFLICT_DETAIL]?: string;
  [ConflictManagementDetailFields.CONFLICT_RESOLUTION]?: string;
  [ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG]?: boolean;
  [ConflictManagementDetailFields.CHECK_DIVISION_FLAG]?: boolean;
  [ConflictManagementDetailFields.EMPLOYEE_IDS]?: UserProfileDTO[];
  [ConflictManagementDetailFields.CONFIRMATION_DEADLINE]?: string | Date;
  [ConflictManagementDetailFields.LC_EMPLOYEES]?: UserProfileDTO;
  [ConflictManagementDetailFields.LC_REVIEW_DEADLINE]?: string | Date;
  [ConflictManagementDetailFields.REMIND]?: ReminderSchemaI;
};

export interface ConflictManagementBodySend {
  documentId?: number;
  [ConflictManagementDetailFields.IS_DRAFT]?: boolean;
  [ConflictManagementDetailFields.CONFLICT_NAME]: string;
  [ConflictManagementDetailFields.STATUS_EVALUATED]: number;
  [ConflictManagementDetailFields.STATUS_CONFIRM]: number;
  employeeInfo: {
    employeeId: string;
    [ConflictManagementDetailFields.DEPARTMENT]: string;
    [ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM]?: string;
    [ConflictManagementDetailFields.POSITION_NAME_CUSTOM]?: string;
    [ConflictManagementDetailFields.MANAGER_ID]: string;
  };
  [ConflictManagementDetailFields.ATTACHMENTS]: number[];
  conflictObject: {
    name: string;
    agency: string;
    position: string;
    relation: string;
  };
  [ConflictManagementDetailFields.NATURE_CONFLICT]: number[];
  [ConflictManagementDetailFields.REASON_CONFLICT]?: string;
  [ConflictManagementDetailFields.CONFLICT_DETAIL]: string;
  [ConflictManagementDetailFields.CONFLICT_RESOLUTION]: string;
  [ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG]?: number;
  [ConflictManagementDetailFields.CHECK_DIVISION_FLAG]?: number;
  [ConflictManagementDetailFields.EMPLOYEE_IDS]: string[];
  [ConflictManagementDetailFields.CONFIRMATION_DEADLINE]: string;
  [ConflictManagementDetailFields.LC_EMPLOYEES]?: string[];
  [ConflictManagementDetailFields.LC_REVIEW_DEADLINE]: string;
  [ConflictManagementDetailFields.REMIND]: SaveReminderDTO;
}

export interface ConflictManagementBodyReceive {
  id: number;
  pic?: BasedUser;
  [ConflictManagementDetailFields.IS_DRAFT]?: boolean;
  [ConflictManagementDetailFields.CONFLICT_NAME]: string;
  statusConfirm: StatusDTO;
  statusEvaluate: StatusDTO;
  employeeInfo: {
    id?: number;
    employee?: BasedUser;
    [ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM]?: string;
    [ConflictManagementDetailFields.POSITION_NAME_CUSTOM]?: string;
    manager: BasedUser;
  };
  employeeAttachments: LegalAdviceAttachment[];
  conflictObject: {
    id: number;
    name: string;
    agency: string;
    position: string;
    relation: string;
  };
  [ConflictManagementDetailFields.NATURE_CONFLICT]: number[];
  [ConflictManagementDetailFields.REASON_CONFLICT]?: string;
  [ConflictManagementDetailFields.CONFLICT_DETAIL]: string;
  [ConflictManagementDetailFields.CONFLICT_RESOLUTION]: string;
  employees?: BasedUser[];
  [ConflictManagementDetailFields.EMPLOYEE_IDS]: string[];
  [ConflictManagementDetailFields.CONFIRMATION_DEADLINE]: string;
  [ConflictManagementDetailFields.LC_EMPLOYEES]?: BasedUser[];
  [ConflictManagementDetailFields.LC_REVIEW_DEADLINE]: string;
  [ConflictManagementDetailFields.REMIND]: ReminderInput;
  [ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG]?: number;
  [ConflictManagementDetailFields.CHECK_DIVISION_FLAG]?: number;
  buttonAction?: object;
  approvedFlag?: boolean;
  confirmFlag?: boolean;
  lcEvaluateFlag?: boolean;
  bookingFlag?: boolean;
  confirmValue?: number;
}
export const SaveConflictManagementRequestCreateSchema = Yup.object().shape({
  [ConflictManagementDetailFields.CONFLICT_NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
}) 
export const SaveConflictManagementRequestSchema = Yup.object().shape({
  files: Yup.mixed().required(VALIDATION_MSG.SELECT),
  // [ConflictManagementDetailFields.CONFLICT_NAME]: Yup.string().required(
  //   VALIDATION_MSG.REQUIRED_FIELD
  // ),
  // [ConflictManagementDetailFields.STATUS_EVALUATED]: Yup.number().required(
  //   VALIDATION_MSG.REQUIRED_FIELD
  // ),
  // [ConflictManagementDetailFields.STATUS_CONFIRM]: Yup.number().required(
  //   VALIDATION_MSG.REQUIRED_FIELD
  // ),
  [ConflictManagementDetailFields.EMPLOYEE_NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [ConflictManagementDetailFields.POSITION_NAME_CUSTOM]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.MANAGER_ID]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.CONFLICT_OBJECT_NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.CONFLICT_OBJECT_AGENCY]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [ConflictManagementDetailFields.CONFLICT_OBJECT_POSITION]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [ConflictManagementDetailFields.CONFLICT_OBJECT_RELATION]:
    Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  [ConflictManagementDetailFields.NATURE_CONFLICT]: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  [ConflictManagementDetailFields.REASON_CONFLICT]: Yup.string().optional(),
  [ConflictManagementDetailFields.CONFLICT_DETAIL]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.CONFLICT_RESOLUTION]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG]: Yup.boolean(),
  [ConflictManagementDetailFields.CHECK_DIVISION_FLAG]: Yup.boolean(),
  [ConflictManagementDetailFields.EMPLOYEE_IDS]: Yup.string().optional(),
  [ConflictManagementDetailFields.CONFIRMATION_DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.LC_EMPLOYEES]: Yup.string().optional(),
  [ConflictManagementDetailFields.LC_REVIEW_DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [ConflictManagementDetailFields.REMIND]: ReminderSchema,
}).test(
  'head-checkbox',
  'CONFLICT_MANAGEMENT.messages.requiredToBeSentTo',
  (values) => values.checkDeptHeadFlag || values.checkDivisionFlag
);

enum SearchPanelQueries {
  GET_HIERARCHY = "conflict-management/get-hierarchy",
  SEARCH_DOCUMENT = "conflict-management/search_document",
  SEARCH_KEY = "conflictManagementName",
}

export const conflictManagementSearchPanelConfig: GenericSearchPanelProps<any> = {
  completeStatusName: LegalAdviceStatusContent.get(LegalAdviceStatusKey.DONE)!,
  getHierarchyFn: (id) => getAllHierarchyById({ id }),
  getItemKey: (item) => item?.documentId ?? item?.id,
  getChildKey: (child) => child?.documentId ?? child?.id,
  getSearchResultFn: getListConflictManagementQueryFn,
  hierarchyQueryKey: SearchPanelQueries.GET_HIERARCHY,
  searchQueryKey: SearchPanelQueries.SEARCH_DOCUMENT,
  searchKey: SearchPanelQueries.SEARCH_KEY,
  getItemName: (item) => item?.conflictName,
  getCreator: (item) => item?.pic ?? item?.createdUser,
  getParentTimeLabel: (item) =>
    item?.createdDate ? formatDate(item?.createdDate, "dd/MM/yyyy HH:mm") : "",
  getParentUsersList: (item) => item?.employees ?? item?.users,
  getParentStatus: (item) =>
    item?.status?.name ??
    item?.statusConfirm?.name ??
    item?.statusEvaluate?.name ??
    item?.status ??
    item?.statusConfirm ??
    item?.statusEvaluate ??
    "",
  getChildStatus: (child) =>
    child?.status?.name ??
    child?.statusConfirm?.name ??
    child?.statusEvaluate?.name ??
    child?.status ??
    child?.statusConfirm ??
    child?.statusEvaluate ??
    "",
  getChildTimeLabel: (child) =>
    child?.createdDate
      ? formatDate(child?.createdDate, "dd/MM/yyyy HH:mm")
      : "",
  getChildUsersList: (child) => child?.employees,
  getChildren: (item) => item?.children ?? item?.conflictManagementChild ?? [],
  getItemLink: (item) =>
    `/${CONFLICT_MANAGEMENT_ROOT_PATH}/update/${item?.documentId ?? item?.id}`,
};

//api

export type ConflictManagementParams = {
  id?: number;
};

export type QueryConflictManagementFnType = typeof getConflictManagementQueryFn;

export type GetConflictManagementOptions = {
  config?: QueryConfig<QueryConflictManagementFnType>;
  request: ConflictManagementParams;
};

export interface CreateConflictManagementOptions {
  config?: MutationConfig<typeof createConflictManagementMutationFn>;
}

export type UpdateConflictManagementRequest = {
  id?: number;
  request?: ConflictManagementBodySend;
};

export type UpdateConflictManagementOptions = {
  config?: MutationConfig<typeof updateConflictManagementMutationFn>;
};

export type UpdateBookMeetingConflictManagementOptions = {
  config?: MutationConfig<typeof updateBookMeetingConflictManagementMutationFn>;
};

export interface ConflictRequestFeedback {
  // Phản hồi đến yêu cầu tư vấn
  feedbackUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
  deadlineNew?: string;
}
export interface GetConflictRequestFeedbackResponse {
  feedbackResponseDetails: ConflictRequestFeedback[];
}

export interface ConflictExtension {
  user: BasedUser;
  reason: string;
  requestDeadline: string;
  acceptDeadline: string;
  date: string;
  type?: number;
  id: number;
  showExtension?: boolean;
  enableExtension?: boolean;
}

export interface GetConflictExtensionResponse {
  timeExtensionResponseDetails: ConflictExtension[];
}
export interface ConflictManagementForward {
  forwardUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  forwardDate: string;
}
export interface GetConflictForwardResponse {
  forwardResponseDetails: ConflictManagementForward[];
}

export interface ConflictManagementConfirm {
  id: number;
  userResponse: BasedUser;
  content?: string;
  status?: number;
  deadline?: number;
  attachmentResponses?: ConflictManagementAttachment[];
}
export interface GetConflictConfirmResponse {
  responses: ConflictManagementConfirm[];
}
export interface ConflictApproval {
  user: BasedUser;
  status?: number;
  content?: string;
}
export interface GetConflictApprovalResponse {
  requestApproveResponses?: ConflictApproval[];
}
export interface ConflictEvaluateTab {
  department?: Department;
  user?: BasedUser;
  deadline?: number;
  createTime?: string;
  evaluateUser?: BasedUser;
  type?: number;
  evaluated?:boolean;
  content?:string;
}
export interface GetConflictEvaluateTabResponse {
  responses: ConflictEvaluateTab[];
}
export interface ConflictEvaluateList {
  id: number;
  userResponse: BasedUser;
  content?: string;
  attachments?: ConflictManagementAttachment[];
  deadline?: number;
  status?: number;
  editAvailable?: boolean;
  accept?: boolean;
}
export interface GetListConflictEvaluateResponse {
  responses: ConflictEvaluateList[];
}

export interface ButtonAction {
  requestEvaluate: number;
  follow: number;
  informationRequest: number;
  confirm: number;
  finish: number;
  evaluate: number;
  requestApprove: number;
  approve: number;
  timeExtensionRequest: number;
  timeExtension: number;
  recall: number;
  sendMail: number;
  forward: number;
  requestMeeting: number;
  feedback: number;
}

export type DeleteEvaluateIdOptions = {
  config?: MutationConfig<typeof deleteEvaluateMngMutationFn>;
};

export const listStatusConfirmConflict = [
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.REQUEST_ADDITIONAL
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.INFORMATION_PROVIDED
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.REQUEST_CONFIRMATION
  )!,
  ConflictManagementStatusContent.get(ConflictManagementStatusKey.CONFIRM)!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.CONFIRM_REJECTED
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.COMPLETED
  )!,
];

export const listStatusEvaluateConflict = [
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.REQUEST_ADDITIONAL
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.INFORMATION_PROVIDED
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.REQUEST_REVIEW
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.REVIEW_COMMENTED
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.REVIEW_REJECTED
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.REQUEST_APPROVAL
  )!,
  ConflictManagementStatusContent.get(ConflictManagementStatusKey.APPROVAL)!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.APPROVAL_REQUEST_FOLLOW
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.APPROVAL_REJECTED
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.CONFLICT_MONITORING
  )!,
  ConflictManagementStatusContent.get(
    ConflictManagementStatusKey.COMPLETED
  )!,
];

export const StatusConfirmValue = {
  REJECTED : -1,
  NOT_YET_CONFIRM: 0,
  ALL_CONFIRM: 1
}