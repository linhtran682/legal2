import { Department } from "../department/Department";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import { ReminderInput } from "../reminder_template/ReminderDTO";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";

export interface ConflictManagementAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface DetailPosition {
  id: string;
  name: string;
  nameEnglish?: string;
}

export const enum BaseConflictManagementFields {
  ID = "id",
  IS_DRAFT = "isDraft",
  PIC = "pic",
  CONFLICT_NAME = "conflictName",
  STATUS_CONFIRM = "statusConfirm",
  STATUS_EVALUATED = "statusEvaluate",
  EMPLOYEE_INFO_IDS = "employeeInfoIds",
  EMPLOYEE_INFO = "employeeInfo",
  EMPLOYEE_CODE = "employeeCode",
  EMPLOYEE_NAME = "employeeName",
  POSITION = "position",
  EMPLOYEE_POSITION = "employeePosition",
  POSITION_NAME_CUSTOM = "positionNameCustom",
  DEPARTMENT = "departmentId",
  EMPLOYEE_DEPARTMENT = "employeeDepartment",
  DEPARTMENT_NAME_CUSTOM = "departmentNameCustom",
  EMPLOYEE_ATTACHMENTS = "employeeAttachments",
  CONFLICT_OBJECT = "conflictObject",
  CONFLICT_OBJECT_NAME = "conflictObjectName",
  NAME = "name",
  AGENCY = "agency",
  CONFLICT_OBJECT_AGENCY = "conflictObjectAgency",
  NATURE_CONFLICT = "natureConflict",
  REASON_CONFLICT = "reasonConflict",
  REASON_DETAIL = "conflictDetail",
  REASON_RESOLUTION = "conflictResolution",
  EMPLOYEE = "employees",
  CONFIRMATION_DEADLINE = "confirmationDeadline",
  CONFIRMATION_DEADLINE_FROM = "confirmationDeadlineFrom",
  CONFIRMATION_DEADLINE_TO = "confirmationDeadlineTo",
  LC_EMPLOYEES = "lcEmployees",
  LC_REVIEW_DEADLINE = "lcReviewDeadline",
  LC_REVIEW_DEADLINE_FROM = "lcReviewDeadlineFrom",
  LC_REVIEW_DEADLINE_TO = "lcReviewDeadlineTo",
  REMIND = "remind",
  CHECK_DEPT_HEAD_FLAG = "checkDeptHeadFlag",
  CHECK_DIVISION_FLAG = "checkDivisionFlag",
  ACTION = "action",
}
export interface BaseConflictManagement {
  id: number;
  [BaseConflictManagementFields.IS_DRAFT]: boolean;
  [BaseConflictManagementFields.CONFLICT_NAME]: string;
  [BaseConflictManagementFields.STATUS_CONFIRM]: StatusDTO;
  [BaseConflictManagementFields.STATUS_EVALUATED]: StatusDTO;
  [BaseConflictManagementFields.EMPLOYEE_INFO]: {
    id: number;
    employeeCode: string;
    department?: Department;
    position?: DetailPosition;
    manager?: {
      id: string;
      name: string;
      email: string;
      departmentName: string;
      departmentResponse: {
        id: string;
        code: string;
        name: string;
        nameEnglish?: string;
        description: string;
        departmentType: {
          id: string;
          name: string;
        };
        children: string[];
        status?: string;
      };
      positionResponse?: {
        id: string;
        name: string;
        nameEnglish?: string;
      };
    };
  };
  [BaseConflictManagementFields.EMPLOYEE_ATTACHMENTS]: LegalAdviceAttachment[];
  [BaseConflictManagementFields.CONFLICT_OBJECT]: {
    id: number;
    name: string;
    agency: string;
    position: string;
    relation: string;
  };
  [BaseConflictManagementFields.NATURE_CONFLICT]?: number[];
  [BaseConflictManagementFields.REASON_CONFLICT]: string;
  [BaseConflictManagementFields.REASON_DETAIL]: string;
  [BaseConflictManagementFields.REASON_RESOLUTION]: string;
  [BaseConflictManagementFields.EMPLOYEE]: BasedUser[];
  [BaseConflictManagementFields.CONFIRMATION_DEADLINE]: string;
  [BaseConflictManagementFields.LC_EMPLOYEES]: BasedUser[];
  [BaseConflictManagementFields.LC_REVIEW_DEADLINE]: string;
  [BaseConflictManagementFields.REMIND]: ReminderInput;
  [BaseConflictManagementFields.CHECK_DIVISION_FLAG]: number;
  [BaseConflictManagementFields.CHECK_DEPT_HEAD_FLAG]: number;
}

export type GetConflictManagementListParams = {
  picIds?: string[];
  [BaseConflictManagementFields.CONFLICT_NAME]?: string;
  [BaseConflictManagementFields.EMPLOYEE_INFO_IDS]?: string;
  [BaseConflictManagementFields.EMPLOYEE_POSITION]?: string;
  [BaseConflictManagementFields.EMPLOYEE_DEPARTMENT]?: string;
  [BaseConflictManagementFields.CONFLICT_OBJECT_NAME]?: string;
  [BaseConflictManagementFields.CONFLICT_OBJECT_AGENCY]?: string;
  statusConfirm?: number[];
  statusEvaluate?: number[];
  [BaseConflictManagementFields.CONFIRMATION_DEADLINE_FROM]?: string
  [BaseConflictManagementFields.CONFIRMATION_DEADLINE_TO]?: string;
  [BaseConflictManagementFields.LC_REVIEW_DEADLINE_FROM]?: string;
  [BaseConflictManagementFields.LC_REVIEW_DEADLINE_TO]?: string;
  employeeIds?: string[];
  lcEmployeeIds?: string[];
  sortBy: string;
  orderBy: string;
  page: number;
  size: number;
  tab?: number;
  isPanelSearch?: boolean;
  isEnglish?: boolean;
  createFrom?: string;
  createTo?: string;
  statusList?: number[] | string | undefined;
  departmentIds?: string;

}
export interface GetConflictManagementListResponse {
  total: number;
  data: BaseConflictManagement[];
}

export interface ConflictMngStatisticChartResponse {
  pieChart: {
    data: {
      name: string;
      value: number
    }[];
  }
  barChart: {
    data: {
      name: string;
      value: number
    }[];
  }
}