import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";
import {  createFollowConflictMutationFn, getFollowConflictQueryFn } from "@/apis/service/conflict_management/conflictMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FollowConflictMngFieldNames {
  STATUS = "status",
  CONTENT = "content",
  USER_IDS = "userIds",
  REMIND = "remind",
  DEADLINE = "deadline"
}
export interface FollowConflictMngSchemaI extends FieldValues {
  status?: number;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
  deadline?: string;
}

export const FinishConflictMngSchema = Yup.object().shape({
  [FollowConflictMngFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FollowConflictMngFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FollowConflictMngFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FollowConflictMngFieldNames.REMIND]: ReminderSchema,
});

export interface CreateFollowConflictMngBody {
  ciId?: number;
  data?: FollowConflictMngSchemaI;
}

export interface CreateFollowConflictMngOptions {
  config?: MutationConfig<typeof createFollowConflictMutationFn>;
}
export type QueryFollowManagementFnType = typeof getFollowConflictQueryFn;

export interface ConflictConfirmDetail {
  id: number;
  userResponse: BasedUser;
  content?: string;
  status?: number;
  editAvailable?: boolean;
}