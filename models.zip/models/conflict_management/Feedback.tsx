import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";
import {  createFeedbackConflictMutationFn } from "@/apis/service/conflict_management/conflictMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedbackConflictMngFieldNames {
  STATUS = "status",
  CONTENT = "content",
  USER_IDS = "userIds",
  REMIND = "remind",
  DEADLINE = "deadline"
}
export interface FeedbackConflictMngSchemaI {
  status?: number;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
  deadline?: string;
}

export const FeedbackConflictMngSchema = Yup.object().shape({
  [FeedbackConflictMngFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FeedbackConflictMngFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FeedbackConflictMngFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FeedbackConflictMngFieldNames.REMIND]: ReminderSchema,
  [FeedbackConflictMngFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
});

export interface CreateFeedbackConflictMngBody {
  ciId?: number;
  data?: FeedbackConflictMngSchemaI;
}

export interface CreateFeedbackConflictMngOptions {
  config?: MutationConfig<typeof createFeedbackConflictMutationFn>;
}
