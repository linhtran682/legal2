import { MutationConfig, QueryConfig } from "@/apis";
import { createSignApproveConflictMutationFn, getSignApprovalQueryFn } from "@/apis/service/conflict_management/conflictMngFormPopup";
import { castReminderSchemaToSaveReminderDTO, ReminderContent } from "../reminder_template/ReminderDTO";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { RadioItem } from "./ConfirmConflict";


type TypeDepartment = {
    id?: string;
    name?: string;
    nameEnglish?: string;
  };
type TypeUserDTO = {
    id?: string;
    name?: string;
    nameEnglish?: string;
    email?: string;
    department?: TypeDepartment;
  };
export type SignApprovalParams = {
    ciId ?: number;
  };

export interface ResponsesRecordSignApprovalDTO{
    status: number;
    user?: TypeUserDTO;
    content: string
}
export type QueryFnCoflictType = typeof getSignApprovalQueryFn;

export type GetSignApprovalOptions = {
    config?: QueryConfig<QueryFnCoflictType>;
    request: SignApprovalParams;
  };
// create Approval 

export interface SaveReminderDTO {
    remindId?: number;
    title?: string;
    module?: number;
    description?: string;
    relatedUsers?: string[] | undefined;
    receivingDepartment?: string[];
    receivedTitle?: string[];
    remindContents?: ReminderContent[];
  }
  
  export const enum ApproveConflictFieldNames {
    USERS_IDS = "userIds",
    DEADLINE = "deadline",
    CONTENT = "content",
    REMIND = "remind",
    STATUS = "status",
  }
  export interface ApproveConflictSchemaI {
    deadline?: string;
    content?: string;
    userIds?: string[];
    status?: number;
    remind?: SaveReminderDTO;
    accept?: number;
  }
  export interface ApproveConflictSchemaII {
    deadline?: string;
    content?: string;
    userIds?: string[];
    status?: number;
    remind?: SaveReminderDTO;
    accept?: boolean;
  }
  
  export interface CreateApproveBody {
    ciId?: number;
    data?: ApproveConflictSchemaII;
  }
  
  export interface CreateForwardLegalAdviceOptions {
    config?: MutationConfig<typeof createSignApproveConflictMutationFn>;
  }
  
  export const ConfirmConflictSchema = Yup.object().shape({
    [ApproveConflictFieldNames.DEADLINE]: Yup.string().required(
      VALIDATION_MSG.REQUIRED_FIELD
    ),
    [ApproveConflictFieldNames.CONTENT]: Yup.string().required(
      VALIDATION_MSG.REQUIRED_FIELD
    ),
    [ApproveConflictFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
      .min(1, VALIDATION_MSG.REQUIRED_FIELD)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    [ApproveConflictFieldNames.REMIND]: ReminderSchema,
  });
  
  export const castConfirmRequestSchemaToDTO = (
    schema: any
  ): ApproveConflictSchemaI => {
    return {
      ...schema,
      userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
      remind: schema.remind
        ? castReminderSchemaToSaveReminderDTO(schema.remind)
        : undefined,
      accept: schema.accept === 0 ? true : false,
      attachments: schema.attachments
    };  
  };
  
  export interface CreateApproveOptions {
    config?: MutationConfig<typeof createSignApproveConflictMutationFn>;
  }

  export const AproveConflictOptions: RadioItem[] = [
    {
      label: "Đã ký duyệt + Yêu cầu theo dõi",
      value: 0,
    },
    {
      label: "Ký duyệt: Từ chối",
      value: 1,
    },
  ];
