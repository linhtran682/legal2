import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { VALIDATION_MSG } from "@/constants/message";
import { createRequestInformationMutationFn } from "@/apis/service/conflict_management/conflictMngFormPopup";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestAdditionalFieldNames {
  STATUS = "status",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
  USERID = "userIds",
  DEPARTMENTS_RESPONSIBLE ="departmentsResponsible"
}
export interface RequestAdditionalSchemaI extends FieldValues {
  deadline?: string;
  status?: number;
  content?: string;
  remind?: SaveReminderDTO;
  userIds?: string[]
}

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};
export interface RequestAdditionalParams {
  legalAdviceId?: number;
  informationRequestId: number;
}

export interface RequestAdditionalDTO {
  user?: TypeUserDTO;
  department?: TypeDepartment;
  deadLine?: string;
  content?: string;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const RequestAdditionalSchema = Yup.object().shape({
  [RequestAdditionalFieldNames.STATUS]: Yup.number().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestAdditionalFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestAdditionalFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestAdditionalFieldNames.USERID]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestAdditionalFieldNames.REMIND]: ReminderSchema,
  // [RequestAdditionalFieldNames.USERID]: Yup.string().required(
  //   VALIDATION_MSG.REQUIRED_FIELD
  // )
});

export interface CreateRequestAdditionalBody {
  ciId?: number;
  data?: RequestAdditionalSchemaI;
}
export interface CreateRequestAddInfoConflictBody {
  ciId?: number;
  data?: RequestAdditionalSchemaI;
}
export interface CreateRequestAdditionalOptions {
  config?: MutationConfig<typeof createRequestInformationMutationFn>;
}

// export type QueryFnType = typeof getRequestAdditionalQueryFn;

// export type GetRequestAdditionalIdOptions = {
//   config?: QueryConfig<QueryFnType>;
//   request: RequestAdditionalParams;
// };