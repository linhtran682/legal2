import { FieldValues } from "react-hook-form";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createAdvisorFollowViolationMutationFn,
  feedbackAdviceFollowViolationMutationFn,
  getAdvisorFollowViolationListQueryFn,
  updateAdvisorFollowViolationDetailMutationFn,
} from "@/apis/service/follow_violation/advisorFollowViolation";
import { BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const TypeAdvisorFollowViolation = {
  toPic: 0,
  toUser: 1,
  toSupervisor: 2,
};

export const AdviceFvOptions: RadioItem[] = [
  {
    label: "followViolation.advisor.title.sendToPic",
    value: TypeAdvisorFollowViolation.toPic,
  },
  {
    label: "followViolation.advisor.title.sendToSupervior",
    value: TypeAdvisorFollowViolation.toSupervisor,
  },
];

export const AdviceSupervisorFvOptions: RadioItem[] = [
  {
    label: "followViolation.advisor.title.sendToPic",
    value: TypeAdvisorFollowViolation.toPic,
  },
  {
    label: "followViolation.advisor.title.sendToConsultant",
    value: TypeAdvisorFollowViolation.toUser,
  },
];

export const enum AdvisorFollowViolationFieldNames {
  CONTENT = "content",
  DEADLINE = "deadline",
  USERS = "userIds",
  ATTACHMENTS = "attachments",
  FINISH = "finish",
  TYPE = "type",
  REMIND = "remind",
}
export interface AdvisorFollowViolationSchemaI extends FieldValues {
  users?: any[];
  deadline?: string;
  content?: string;
  remind?: SaveReminderDTO;
}

export const AdvisorFollowViolationSchema = Yup.object().shape({
  [AdvisorFollowViolationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [AdvisorFollowViolationFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AdvisorFollowViolationFieldNames.REMIND]: ReminderSchema,
});

export const FeedBackAdvisorFollowViolationSchema = Yup.object().shape({
  [AdvisorFollowViolationFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [AdvisorFollowViolationFieldNames.CONTENT]: Yup.string().required(
    "Reason name is required"
  ),
});

export interface CreateAdvisorFollowViolationOptions {
  config?: MutationConfig<typeof createAdvisorFollowViolationMutationFn>;
}

export interface CreateAdvisorFollowViolationBody {
  violationId?: number;
  data?: TypeAdvisorFollowViolationDetail;
}

export interface FeedbackAdviceFollowViolationOptions {
  config?: MutationConfig<typeof feedbackAdviceFollowViolationMutationFn>;
}

export interface FeedbackAdviceFollowViolationBody {
  violationId?: number;
  data?: TypeAdvisorFollowViolationDetail;
}

export type AdvisorFollowViolationParams = {
  violationId?: number;
  adviseId?: number;
};

export type QueryFnTypeList = typeof getAdvisorFollowViolationListQueryFn;

export type GetAdvisorFollowViolationListOptions = {
  config?: QueryConfig<QueryFnTypeList>;
  request: { violationId?: number };
};

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};
export interface AdvisorFollowViolationUser {
  id?: string;
  name?: string;
  email?: string;
  departmentName?: string;
}

type TypeAttachmentsDTO = {
  fileId?: number;
  fileName?: string;
  filePath?: string;
  uploadDate?: string;
  uploadUser?: AdvisorFollowViolationUser;
};

export interface ResponsesAdvisorFollowViolationDTO {
  id: number;
  user?: TypeUserDTO;
  department?: TypeDepartment;
  title?: string;
  content?: string;
  createAt?: string;
  createBy?: any;
  attachments?: TypeAttachmentsDTO[];
  superVisor?: boolean;
  isSupervisor?: boolean;
  editAvailable?: boolean;
  finish?: boolean;
  type?: number;
}

interface TypeAdvisorFollowViolation {
  status: number;
  type: number;
  deadline: string;
  content: string;
  userIds: string[];
  remind: SaveReminderDTO;
}

interface TypeAdvisorFollowViolationDetail {
  type?: number;
  content: string;
  deadline?: string;
  finish?: boolean;
  userIds: string[];
  attachmentIds?: number[];
  remind: SaveReminderDTO;
}

export interface UpdateAdvisorFollowViolationBody {
  violationId?: number;
  adviseId?: number;
  data?: TypeAdvisorFollowViolation;
}

export const castAdvisorFollowViolationRequestSchemaToDTO = (
  schema: any
): AdvisorFollowViolationSchemaI => {
  return {
    ...schema,
    finish: schema.finish ?? false,
    userIds: schema?.userIds?.map((user: any) => user?.id),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export interface UpdateAdvisorFollowViolationDetailBody {
  violationId?: number;
  adviseId?: number;
  data?: TypeAdvisorFollowViolationDetail;
}

export type UpdateAdvisorFollowViolationDetailOptions = {
  config?: MutationConfig<typeof updateAdvisorFollowViolationDetailMutationFn>;
};
