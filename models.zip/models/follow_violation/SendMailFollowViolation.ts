import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface SendMailFollowViolationRequest {
  subject?: string;
  content?: string;
  receivers: string[];
}

export const SendMailFollowViolationRequestSchema = Yup.object().shape({
  title: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .test("non-empty", VALIDATION_MSG.REQUIRED_FIELD, (value) => {
      const strippedValue = value?.replace(/<[^>]+>/g, "").trim();
      return strippedValue !== "";
    }),
  receivers: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
});
