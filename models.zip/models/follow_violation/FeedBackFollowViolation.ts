import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createFeedbackFollowViolationMutationFn } from "@/apis/service/follow_violation/feedbackFollowViolation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedbackFollowViolationFieldNames {
  USERS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FeedbackFollowViolationSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateFeedbackFollowViolationBody {
  violationId?: number;
  data?: FeedbackFollowViolationSchemaI;
}

export interface CreateFeedbackFollowViolationOptions {
  config?: MutationConfig<typeof createFeedbackFollowViolationMutationFn>;
}

export const FeedbackFollowViolationSchema = Yup.object().shape({
  [FeedbackFollowViolationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [FeedbackFollowViolationFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FeedbackFollowViolationFieldNames.REMIND]: ReminderSchema,
});

export const castFeedBackFollowViolationRequestSchemaToDTO = (
  schema: any
): FeedbackFollowViolationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export const castRequestApproveNextActionSchemaToDTO = (
  schema: any
): FeedbackFollowViolationSchemaI => {
  return {
    ...schema,
    approvalUsers: schema.approvalUsers?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
