import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createApprovalFvMutationFn,
  createRequestApprovalFvMutationFn,
  getRequestApprovalFvQueryFn,
  updateRequestApprovalFvMutationFn,
} from "@/apis/service/follow_violation/requestApprovalFollowViolation";
import { BasedUser } from "../user/User";
import { DetailModule } from "./FormType";

export const enum APPROVAL_ROLE_ID {
  DEPT_HEAD = 1,
  GROUP_HEAD = 2,
  TOP_HEAD = 3,
}

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestApprovalRequestFvFieldNames {
  DEADLINE = "deadline",
  USERS = "approvalUsers",
  CONTENT = "content",
  REMIND = "remind",
  NAME = "name",
}
export interface RequestApprovalRequestFvSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  users?: string[];
  approvalIds?: any[];
  deniedIds?: any[];
  remind?: SaveReminderDTO;
}

interface RemindContent {
  position?: number;
  remindReceiverType?: number;
  remindValueType?: number;
  timeStatus?: number;
  vendorResponseStatus?: number;
  time?: number;
  timeUnit?: number;
  legalStatus?: number;
  isSend?: boolean;
}

interface Remind {
  title?: string;
  module?: number;
  description?: string;
  remindContents?: {
    additionalProp1?: RemindContent[];
    additionalProp2?: RemindContent[];
    additionalProp3?: RemindContent[];
  };
  relatedUsers?: string[];
  receivingDepartment?: string[];
  receivedTitle?: string[];
}

export interface RequestApprovalUser {
  id?: string;
  name?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
}

export interface RequestApprovalFvDTO {
  name?: string | undefined;
  deadLine?: string;
  status?: DetailModule;
  content?: string;
  users?: BasedUser[];
  remind?: Remind;
}

export const ExtensionFvOptions: RadioItem[] = [
  {
    label: "Đồng ý",
    value: 1,
  },
  {
    label: "Từ chối",
    value: 0,
  },
];

export const RequestApprovalRequestFvSchema = Yup.object().shape({
  [RequestApprovalRequestFvFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [RequestApprovalRequestFvFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [RequestApprovalRequestFvFieldNames.REMIND]: ReminderSchema,
});

export const ApprovalConfirmRequestFvSchema = Yup.object().shape({
  [RequestApprovalRequestFvFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [RequestApprovalRequestFvFieldNames.REMIND]: ReminderSchema,
});

export interface RequestApprovalUpdateFv {
  requestApprovalIds?: number[];
  approvalStatus?: number;
  status?: number;
  content?: string;
  users?: string[];
  remind?: Remind;
}

export interface UpdateRequestApprovalFvBody {
  violationId?: number;
  requestApprovalId?: number;
  data?: RequestApprovalUpdateFv;
}

export interface CreateRequestApprovalFvBody {
  violationId?: number;
  data?: RequestApprovalRequestFvSchemaI;
}

export interface CreateApprovalFvBody {
  violationId?: number;
  data?: RequestApprovalRequestFvSchemaI;
}

export interface CreateRequestApprovalFvOptions {
  config?: MutationConfig<typeof createRequestApprovalFvMutationFn>;
}

export type RequestApprovalFvParams = {
  violationId?: number;
  requestApprovalId?: number;
};

export type QueryFnTypeFv = typeof getRequestApprovalFvQueryFn;

export type GetRequestApprovalFvIdOptions = {
  config?: QueryConfig<QueryFnTypeFv>;
  request: RequestApprovalFvParams;
};

export type UpdateRequestApprovalFvOptions = {
  config?: MutationConfig<typeof updateRequestApprovalFvMutationFn>;
};

export interface CreateApprovalFvOptions {
  config?: MutationConfig<typeof createApprovalFvMutationFn>;
}
