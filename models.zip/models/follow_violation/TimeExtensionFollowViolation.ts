import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
  ReminderSchemaI,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import { VALIDATION_MSG } from "@/constants/message";
import {
  createTimeExtensionFvMutationFn,
  getTimeExtensionFvQueryFn,
  updateTimeExtensionFvMutationFn,
} from "@/apis/service/follow_violation/timeExtensionFollowViolation";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const enum TimeExtensionRequestFvFieldNames {
  DEADLINE = "deadline",
  REASON = "reason",
  REMIND = "remind",
  CONFIRM = "confirm",
  ACCEPTABLE_DEADLINE = "acceptableDeadline",
  ACCEPTABLE_DEADLINE_REASON = "acceptableReason",
  USERS = "users",
}

export const ConfirmExtensionFollowViolationType = {
  NEW_DEADLINE: 1,
  APPROVE: 0,
};

export const ExtensionFvOptions: RadioItem[] = [
  {
    label: "Đồng ý",
    value: ConfirmExtensionFollowViolationType.APPROVE,
  },
  {
    label: "Thời hạn mới",
    value: ConfirmExtensionFollowViolationType.NEW_DEADLINE,
  },
];

export const TimeExtensionRequestFvSchema = Yup.object().shape({
  [TimeExtensionRequestFvFieldNames.DEADLINE]: Yup.string().required(
    "Deadline from vendor date is required"
  ),
  [TimeExtensionRequestFvFieldNames.REASON]: Yup.string().required(
    "Reason name is required"
  ),
  [TimeExtensionRequestFvFieldNames.REMIND]: ReminderSchema,
});

export const ConfirmExtensionRequestFvSchema = Yup.object().shape({
  [TimeExtensionRequestFvFieldNames.CONFIRM]: Yup.boolean().required(
    "Confirm is required"
  ),
  [TimeExtensionRequestFvFieldNames.ACCEPTABLE_DEADLINE]: Yup.string()
    .required("Deadline accept name is required")
    .when(
      TimeExtensionRequestFvFieldNames.CONFIRM,
      ([isNewDeadline], schema) => {
        if (isNewDeadline) {
          return schema.required("Deadline accept name is required");
        }
        return schema.notRequired();
      }
    ),
  [TimeExtensionRequestFvFieldNames.ACCEPTABLE_DEADLINE_REASON]: Yup.string()
    .required("Reason accept name is required")
    .when(
      TimeExtensionRequestFvFieldNames.CONFIRM,
      ([isNewDeadline], schema) => {
        if (isNewDeadline) {
          return schema.required("Reason accept name is required");
        }
        return schema.notRequired();
      }
    ),
  [TimeExtensionRequestFvFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [TimeExtensionRequestFvFieldNames.REMIND]: ReminderSchema,
});
export interface Department {
  id: string;
  name?: string;
  nameEnglish?: string;
}

export interface TimeExtensionUser {
  id?: string;
  name?: string | undefined;
  nameEnglish?: string;
  email?: string | undefined;
  department?: Department;
}
export interface TimeExtensionRequestFvSchemaI extends FieldValues {
  deadline?: string;
  reason?: string;
  remind?: ReminderSchemaI;
}

export interface RequestApprovalDTO {
  id?: number;
  deadline?: string;
  reason?: string | undefined;
  user?: TimeExtensionUser;
  department?: Department;
}

interface TypeAcceptTimeExtension {
  deadlineAccept?: string;
  reason?: string;
  type?: number;
  users?: string[];
  remind: SaveReminderDTO;
}
export interface UpdateTimeExtensionFvBody {
  violationId?: number;
  timeExtensionRequestId?: number;
  data?: TypeAcceptTimeExtension;
}

export interface CreateTimeExtensionFvBody {
  violationId?: number;
  data?: TimeExtensionRequestFvSchemaI;
}

export interface CreateTimeExtensionFvOptions {
  config?: MutationConfig<typeof createTimeExtensionFvMutationFn>;
}

export type TimeExtensionFvParams = {
  violationId?: number;
  timeExtensionRequestId?: number;
};

export type QueryFnTypeFv = typeof getTimeExtensionFvQueryFn;

export type GetTimeExtensionFvIdOptions = {
  config?: QueryConfig<QueryFnTypeFv>;
  request: TimeExtensionFvParams;
};

export type UpdateTimeExtensionFvAcceptOptions = {
  config?: MutationConfig<typeof updateTimeExtensionFvMutationFn>;
};
