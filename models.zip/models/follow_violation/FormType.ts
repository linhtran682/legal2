import { FieldValues } from "react-hook-form";
import { Department, DepartmentSchema } from "../department/Department";
import { FieldDTO } from "../field/Field";
import { ReminderInput, ReminderSchemaI, SaveReminderDTO } from "../reminder_template/ReminderDTO";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";
import { HistoryRecord } from "../metadata/Metadata";
import { GenericSearchPanelProps } from "@/components/commons/search_panel/GenericSearchPanel";
import { LegalAdviceStatusContent, LegalAdviceStatusKey } from "@/constants/general";
import { getAllHierarchyViolationById, getFollowViolationList } from "@/apis/service/follow_violation/followViolationAPI";
import { formatDate } from "@/utils";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH } from "@/constants/paths";

export enum FollowViolationFieldsName {
  ID = "id",
  NAME = "name",
  ATTACHMENT_FILE_IDS = "attachmentFileIds",
  FIELD_ID = "fieldId",
  PURPOSE = "purpose",
  STATUS = "status",
  VENDOR_MUST_RESPONSE_DATE = "vendorMustResponseDate",
  SUMMARY_ISSUE = "summary",
  PROBLEM = "problem",
  RESEARCH_OPINION = "researchOpinion",
  DEADLINE_TYPE = "consultingDeadlineType",
  ANSWER_DATE = "answerDate",
  URGENT_DATE = "urgentDate",
  URGENT_REASON = "urgentReason",
  RECEIVER_IDS = "receiverIds",
  RESPONSIBLE_USERS = "responsibleUsers",
  ASSIGNMENT_USERS = "assignmentUsers",
  RELATED_IDS = "relatedIds",
  REMIND = "remind",
  DRAFT = "draft",
  BOOK_MEETING = "isBookMeeting",
}

export interface AttachmentFile {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate?: string;
  uploadUser?: BasedUser;
}

export interface FollowViolationRequest {
  id?: number,
  isDraft?: boolean,
  name: string,
  attachmentFileIds?: number[],
  fieldId: number,
  purpose: string,
  statusId: number,
  vendorMustResponseDate?: string | undefined,
  summary: string,
  researchOpinion: string,
  consultingDeadlineType: number,
  answerDate?: string | undefined,
  urgentReason?: string | undefined,
  urgentDate?: string | undefined,
  departmentIds?: string[],
  receiverIds: string[],
  relatedIds?: string[];
  responsibleIds?: string[];
  remind?: SaveReminderDTO;
  isBookMeeting?: boolean;
  isApprovedByManager?: boolean;
  isRequestVendorAdvice?: boolean;
  checkDivisionFlag?: boolean;
  checkDeptHeadFlag?: boolean;
}

export interface ViolationTabsRef {
  scrollToTab: (tab: number) => void;
}


export interface FollowViolationDetail {
  id: number;
  name: string;
  field: FieldDTO;
  attachments?: AttachmentFile[];
  purpose?: string;
  status: StatusDTO;
  vendorMustResponseDate?: string;
  summary?: string;
  researchOpinion: string;
  consultingDeadlineType: number;
  answerDate: string;
  urgentReason: string;
  departments?: Department[];
  receiverUsers: BasedUser[];
  relatedUsers: BasedUser[];
  remind?: ReminderInput;
  children?: string[];
  isDraft?: boolean;
  isBookMeeting?: boolean;
  totalBookMeeting?: number;
  checkDivisionFlag?: boolean;
  checkDeptHeadFlag?: boolean;
  approved?: boolean;
  responsibleUsers?: BasedUser[];
  assignmentUsers?: BasedUser[];
  isVerifiedConsulting?: boolean;
  isSupervisorConsulting?: boolean;
  isNextActionReport?: boolean;
  isCompletedConsulting?: boolean;
  isApproved?: boolean;
  isApprovedByManager?: boolean;
  lastActionAndRole: {
    feedbackAvailableFlag?: number;
    otherActionsAvailableFlag?: number;
    requestFeedbackAvailableFlag?: number;
    requestTimeExtensionAvailableFlag?: number;
    requestConfirmAvailableFlag?: number;
    violationApprovalFlag?: number;
    violationDoneFlag?: number;
    currentRowStatus?: any; 
    userLastActionAndRoleList: {
      role: number;
      lastAction: number;
    }[]
  },
  createdBy?: BasedUser;
  totalUserAdvice: number;
  totalSupervisorAdvice: number;
  currentUserAdvice: number;
  currentSupervisorAdvice: number;
  supervisorUsers?: BasedUser;
  legalAccessType?: number;
  sharedDepartments?: Department[];
  sharedUsers?: BasedUser[];
}

export interface ViolationExtension {
  user: BasedUser;
  reason: string;
  requestDeadline: string;
  acceptDeadline: string;
  date: string;
  type?: number;
  id: number;
  showExtension?: boolean;
  enableExtension?: boolean;
}

type DepartmentType = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  basicPosition?: DepartmentType;
  department?: DepartmentType;
};

export interface InformationRequestType {
  user?: TypeUserDTO;
  department?: DepartmentType;
  deadLine?: string;
  content?: string;
  type?: string;
}

export interface ViolationAssignmentResponse {
  assignmentResponseDetails: ViolationAssignment[];
}

export interface ViolationAssignment {
  assignUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
}


export interface ViolationAdvise {
  id: number;
  users: BasedUser[];
  createBy: BasedUser;
  department: Department;
  content: string;
  createAt: string;
  attachments: AttachmentFile[];
  finish: boolean;
  editAvailable: boolean;
  isSupervisor: boolean;
}

export interface ResponsesAdvisorViolationTO {
  id: number;
  user?: TypeUserDTO;
  department?: DepartmentType;
  title?: string;
  content?: string;
  createAt?: string;
  attachments?: AttachmentFile[];
  superVisor?: boolean;
  editAvailable?: boolean;
  finish?: boolean;
  type?: number;
}

interface AdvisorViolationType {
  status: number;
  type: number;
  deadlineNew: string;
  reason: string;
  remind: SaveReminderDTO;
}

export interface UpdateAdvisorViolationRequest {
  violationId?: number;
  adviseId?: number;
  data?: AdvisorViolationType;
}

interface AdvisorViolationDetailType {
  type: number;
  userIds: string[];
  status: number;
  content: string;
  attachmentIds?: number[];
  remind: SaveReminderDTO;
  finish: boolean;
}

export interface UpdateAdvisorViolationDetailRequest {
  violationId?: number;
  adviseId?: number;
  data?: AdvisorViolationDetailType;
}

export interface CreateAdvisorViolationRequest {
  violationId?: number;
  data?: AdvisorViolationSchemaI;
}

export interface AdvisorViolationSchemaI extends FieldValues {
  departments?: string[];
  users?: string[];
  deadline?: string;
  content?: string;
  remind?: SaveReminderDTO;
}

export const enum AdvisorViolationFieldNames {
  CONTENT = "content",
  STATUS = "status",
  DEPARTMENTS = "departments",
  DEADLINE_NEW = "deadlineNew",
  REASON = "reason",
  USERS = "userIds",
  ATTACHMENTS = "attachments",
  FINISH = "finish",
  TYPE = "type",
  REMIND = "remind",
}

export interface ViolationForward {
  forwardUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  forwardDate: string;
}

export interface GetViolationForwardResponse {
  forwardResponseDetails: ViolationForward[];
}

export interface ViolationExtension {
  user: BasedUser;
  reason: string;
  requestDeadline: string;
  acceptDeadline: string;
  date: string;
  type?: number;
  id: number;
  showExtension?: boolean;
  enableExtension?: boolean;
}

export interface GetViolationExtensionResponse {
  timeExtensionResponseDetails: ViolationExtension[];
}

export type TimeExtensionParams = {
  violationId?: number;
  timeExtensionRequestId?: number;
};

export interface TimeExtensionUser {
  id?: string;
  name?: string | undefined;
  nameEnglish?: string;
  email?: string | undefined;
  department?: Department;
}

export interface RequestApprovalDTO {
  id?: number;
  deadline?: string;
  reason?: string | undefined;
  user?: TimeExtensionUser;
  department?: Department;
}

interface TypeAcceptTimeExtension {
  deadlineAccept?: string;
  reason?: string;
  type?: number;
  users?: string[];
  remind: SaveReminderDTO;
}

export interface UpdateTimeExtensionRequest {
  violationId?: number;
  timeExtensionRequestId?: number;
  data?: TypeAcceptTimeExtension;
}

export interface TimeExtensionRequestSchemaI extends FieldValues {
  deadline?: string;
  reason?: string;
  remind?: ReminderSchemaI;
}

export interface CreateTimeExtensionViolation {
  violationId?: number;
  data?: TimeExtensionRequestSchemaI;
}

export interface ViolationFeedback { // Phản hồi đến người tư vấn
  feedbackAdviseUser: BasedUser;
  receiveUser: BasedUser;
  reason: string;
  date: string;
  deadline?: string;
}
export interface GetViolationFeedbackResponse {
  feedbackAdviseResponseDetails: ViolationFeedback[];
}

export interface ViolationRequestFeedback { // Phản hồi đến yêu cầu tư vấn
  feedbackUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
}
export interface GetViolationRequestFeedbackResponse {
  feedbackResponseDetails: ViolationRequestFeedback[];
}

export interface Comment {
  userInfo: BasedUser;
  comment: string;
  commentDate: string;
  commentId: string;
}

export interface GetViolationCommentsResponse {
  data: Comment[];
}

export interface GetViolationAttachmentsResponse {
  data: AttachmentFile[];
}

export interface GetViolationHistoryResponse {
  data: HistoryRecord[];
}

export interface ApprovalRecord {
  id: number;
  user: BasedUser;
  content: string;
  deadline: string;
  status: number;
}

export interface NextActionDTO {
  itemId?: number;
  // position: number;
  category?: string;
  legalRequirements?: string;
  complianceAssessment?: string;
  currentStatusTMV?: string;
  workNeed?: string;
  pic?: string;
  deadline?: string;

}
export interface ViolationNextActionRequest {
  name: string,
  deadline: string,
  status: number,
  fileIds?: number[],
  nextActions: NextActionDTO[];
}

export interface DepartmentNextAction extends DepartmentSchema {
  departmentType?: DepartmentType
}
export interface PicUser extends BasedUser {
  departmentResponse?: DepartmentNextAction
}

export interface NextActionItem {
  nextActionId?: number;
  position: number;
  category: string;
  legalRequirements?: string;
  complianceAssessment?: string;
  currentStatusTMV?: string;
  workNeed?: string;
  receivers?: PicUser[];
  deptHeadApproved?: boolean;
  groupHeadApproved?: boolean;
  topHeadApproved?: boolean;
  deadline?: string
}
export interface ViolationNextActionResponse {
  violationName: string;
  nextActionItems: NextActionItem[];
  createBy: PicUser;
  deadline?: string;
  name: string;
  status: StatusDTO;
  files: AttachmentFile[];
  receivers: PicUser[];
}

export enum NextActionFieldsName {
  NAME = "name",
  VIOLATION_NAME = "violationName",
  SENDER = "sender",
  STATUS = "status",
  DEADLINE = "deadline",
  FILE_IDS = "fileIds",
  RECEIVERS = "receivers",
  NEXT_ACTION = "nextActions",
}

export enum NextActionTableFieldsName {
  POSITION = "position",
  CATEGORY = "category",
  LEGAL_REQUIREMENTS = "legalRequirements",
  COMPLIANCE_ASSESSMENT = "complianceAssessment",
  CURRENT_STATUS = "currentStatusTMV",
  WORK_NEED = "workNeed",
  RECEIVERS_IDS = "receiverIds",
  DEADLINE = "deadline",
  DEPT_HEAD_APPROVED = "deptHeadApproved",
  GROUP_HEAD_APPROVED = "groupHeadApproved",
  TOP_HEAD_APPROVED = "topHeadApproved",
}

export interface DetailModule {
  id: number;
  name: string;
  description: string;
  createdAt: Date | null;
  createdBy: string | null;
}

export enum ApproveType {
  APPROVED = "approved",
  REJECTED = "rejected",
}

enum SearchPanelQueries {
  GET_HIERARCHY = 'violation/get-hierarchy',
  SEARCH_DOCUMENT = 'violation/search_document',
  SEARCH_KEY = "name"
}

export const violationSearchPanelConfig: GenericSearchPanelProps<any> = {
  completeStatusName: LegalAdviceStatusContent.get(LegalAdviceStatusKey.DONE)!,
  getHierarchyFn: (id) => getAllHierarchyViolationById({ id }),
  getItemKey: (item) => +(item?.violationId ?? item?.id),
  getChildKey: (child) => +(child?.violationId ?? child?.id),
  getSearchResultFn: getFollowViolationList,
  hierarchyQueryKey: SearchPanelQueries.GET_HIERARCHY,
  searchQueryKey: SearchPanelQueries.SEARCH_DOCUMENT,
  searchKey: SearchPanelQueries.SEARCH_KEY,
  getItemName: (item) => item?.name,
  getIsDraft: (item) => item?.isDraft,
  getCreator: (item) => item?.createdUser ?? item?.createBy,
  getParentTimeLabel: (item) => {
    const createdDate = item?.createdDate || item?.createdAt;
    return createdDate ? formatDate(createdDate, "dd/MM/yyyy HH:mm") : ""
  },
  getParentUsersList: (item) => item?.receiverUsers ?? item?.users,
  getParentStatus: (item) => item?.status?.name ?? item?.status ?? "",
  getChildStatus: (child) => child?.status?.name ?? child?.status ?? "",
  getChildTimeLabel: (child) =>
    child?.createdDate
      ? formatDate(child?.createdDate, "dd/MM/yyyy HH:mm")
      : "",
  getChildUsersList: (child) => child?.receiverUsers,
  getChildren: (item) => item?.children ?? item?.child ?? [],
  getItemLink: (item) =>
    `/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/update/${item?.violationId ?? item?.id}`,
  openNewTab: false
};
