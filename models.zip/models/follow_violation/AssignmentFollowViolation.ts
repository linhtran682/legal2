import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createAssignmentFollowViolationMutationFn } from "@/apis/service/follow_violation/assignmentFollowViolation";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum AssignmentFollowViolationFieldNames {
  CONTENT = "content",
  USERS_IDS = "userIds",
  REMIND = "remind",
}
export interface AssignmentFollowViolationSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export const AssignmentFollowViolationSchema = Yup.object().shape({
  [AssignmentFollowViolationFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AssignmentFollowViolationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateAssignmentFollowViolationBody {
  violationId?: number;
  data?: AssignmentFollowViolationSchemaI;
}

export interface CreateAssignmentFollowViolationOptions {
  config?: MutationConfig<typeof createAssignmentFollowViolationMutationFn>;
}

export const castAssignmentFollowViolationRequestSchemaToDTO = (
  schema: any
): AssignmentFollowViolationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
