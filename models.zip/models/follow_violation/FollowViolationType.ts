export const enum FollowViolationFields {
  ID = "id",
  REQUEST_NAME = "name",
  FIELD = "field",
  REASON = "reason",
  PURPOSE = "purpose",
  PROBLEM = "problem",
  STATUS = "status",
  DEADLINE = "deadline",
  DEADLINE_TYPE = "consultingDeadlineType",
  RETURN_DATE_ALL = "returnDateAll",
  RESPONSE_DATE = "answerDate",
  SENDER = "sender",
  PIC = "pic",
  RECEIVER = "receiver",
  ACTION = "action",
  STATUS_NEXT_ACTION = "nextActionStatus"
}

export enum ViolationRole {
  SUPERVISOR = 3,
}