import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createFinishFollowViolationMutationFn } from "@/apis/service/follow_violation/finishFollowViolation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FinishFollowViolationFieldNames {
  USERS = "userIds",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FinishFollowViolationSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateFinishFollowViolationBody {
  violationId?: number;
  data?: FinishFollowViolationSchemaI;
}

export interface CreateFinishFollowViolationOptions {
  config?: MutationConfig<typeof createFinishFollowViolationMutationFn>;
}

export const FinishFollowViolationSchema = Yup.object().shape({
  [FinishFollowViolationFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FinishFollowViolationFieldNames.REMIND]: ReminderSchema,
});

export const castFinishFollowViolationRequestSchemaToDTO = (
  schema: any
): FinishFollowViolationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
