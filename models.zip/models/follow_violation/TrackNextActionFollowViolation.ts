import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createTrackFollowViolationMutationFn } from "@/apis/service/follow_violation/trackNextActionFollowViolation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum TrackNextActionFvFieldNames {
  USERS = "userIds",
  CONTENT = "reason",
  REMIND = "remind",
}
export interface TrackNextActionFvSchemaI extends FieldValues {
  reason?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateTrackFollowViolationBody {
  violationId?: number;
  data?: TrackNextActionFvSchemaI;
}

export interface CreateTrackFollowViolationOptions {
  config?: MutationConfig<typeof createTrackFollowViolationMutationFn>;
}

export const TrackNextActionFvSchema = Yup.object().shape({
  [TrackNextActionFvFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [TrackNextActionFvFieldNames.REMIND]: ReminderSchema,
});

export const castTrackFollowViolationRequestSchemaToDTO = (
  schema: any
): TrackNextActionFvSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
