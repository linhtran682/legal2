import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createRequestVendorFvMutationFn } from "@/apis/service/follow_violation/requestVendorFollowViolation";
import { BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestVendorFvFieldNames {
  DEADLINE = "timeVendorResponse",
  USERS = "userIds",
  DEPARTMENTS = "departments",
  REMIND = "remind",
}
export interface RequestVendorFvSchemaI extends FieldValues {
  timeVendorResponse?: string;
  userIds?: string[];
  content?: string;
  remind?: SaveReminderDTO;
}

export const RequestVendorFvSchema = Yup.object().shape({
  [RequestVendorFvFieldNames.DEADLINE]: Yup.string().required(
    "Time Vendor Response name is required"
  ),
  [RequestVendorFvFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestVendorFvFieldNames.REMIND]: ReminderSchema,
});

export interface CreateRequestVendorFvBody {
  violationId?: number;
  data?: RequestVendorFvSchemaI;
}

export interface CreateRequestVendorFvOptions {
  config?: MutationConfig<typeof createRequestVendorFvMutationFn>;
}
