import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export const FollowVoilationSchema = Yup.object().shape({
    attachmentFileIds: Yup.mixed().required(VALIDATION_MSG.REQUIRED_FIELD),
    name: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
    fieldId: Yup.number().required(VALIDATION_MSG.SELECT),
    purpose: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
    status: Yup.number().optional().nullable(),
    summary: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
    problem: Yup.string().optional().nullable(),
    researchOpinion: Yup.string().optional().nullable(),
    consultingDeadlineType: Yup.number().required(VALIDATION_MSG.SELECT),
    answerDate: Yup.date().typeError(VALIDATION_MSG.ENTER_VALID_VALUE).required(VALIDATION_MSG.REQUIRED_FIELD),
    vendorMustResponseDate: Yup.string()
      .when('isRequestVendorAdvice', {
        is: (type: any) => type === true,
        then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }),
    urgentReason: Yup.string()
      .when('consultingDeadlineType', {
        is: (type: any) => Number(type) === 2,
        then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }),
      receiverIds: Yup.array().min(1, VALIDATION_MSG.SELECT).required(VALIDATION_MSG.SELECT),
      responsibleUsers: Yup.array().min(1, VALIDATION_MSG.SELECT).required(VALIDATION_MSG.SELECT),
  });

  export const VoilationNextActionSchema = Yup.object().shape({
    fileIds: Yup.mixed().required(VALIDATION_MSG.REQUIRED_FIELD),
    name: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
    deadline: Yup.date().typeError(VALIDATION_MSG.ENTER_VALID_VALUE).required(VALIDATION_MSG.REQUIRED_FIELD),
    nextActions: Yup.array()
    .of(
      Yup.object().shape({
        // position: Yup.number(),
        category: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
        legalRequirements: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
        complianceAssessment: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
        currentStatusTMV: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
        workNeed: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
        // pic: Yup.string().required(VALIDATION_MSG.SELECT),
        receiverIds: Yup.array().min(1, VALIDATION_MSG.SELECT).required(VALIDATION_MSG.SELECT),
        deadline: Yup.date().typeError(VALIDATION_MSG.ENTER_VALID_VALUE).required(VALIDATION_MSG.REQUIRED_FIELD),
      })
    ).min(1, VALIDATION_MSG.REQUIRED_FIELD)

    
  });