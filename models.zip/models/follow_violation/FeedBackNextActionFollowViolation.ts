import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createFeedbackFollowViolationMutationFn } from "@/apis/service/follow_violation/feedbackNextActionFollowViolation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedBackNextActionFvFieldNames {
  USERS = "userIds",
  CONTENT = "reason",
  REMIND = "remind",
}
export interface FeedbackNextActionFvSchemaI extends FieldValues {
  reason?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateFeedbackFollowViolationBody {
  violationId?: number;
  data?: FeedbackNextActionFvSchemaI;
}

export interface CreateFeedbackFollowViolationOptions {
  config?: MutationConfig<typeof createFeedbackFollowViolationMutationFn>;
}

export const FeedbackNextActionFvSchema = Yup.object().shape({
  [FeedBackNextActionFvFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FeedBackNextActionFvFieldNames.REMIND]: ReminderSchema,
});

export const castFeedBackFollowViolationRequestSchemaToDTO = (
  schema: any
): FeedbackNextActionFvSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
