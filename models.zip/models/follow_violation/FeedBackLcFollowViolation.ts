import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createFeedBackLcFollowViolationMutationFn } from "@/apis/service/follow_violation/feedbackLcFollowViolation";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedBackLcFollowViolationRequestFieldNames {
  USERS = "users",
  CONTENT = "reason",
  REMIND = "remind",
}
export interface RequestFeedBackLcFollowViolationSchemaI extends FieldValues {
  reason?: string;
  users?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateFeedBackLcFollowViolationBody {
  violationId?: number;
  data?: RequestFeedBackLcFollowViolationSchemaI;
}

export interface CreateFeedBackLcFollowViolationOptions {
  config?: MutationConfig<typeof createFeedBackLcFollowViolationMutationFn>;
}

export const RequestFeedBackLcFollowViolationSchema = Yup.object().shape({
  [FeedBackLcFollowViolationRequestFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [FeedBackLcFollowViolationRequestFieldNames.REMIND]: ReminderSchema,
});
