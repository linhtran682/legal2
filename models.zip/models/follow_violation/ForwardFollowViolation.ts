import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createForwardFollowViolationMutationFn } from "@/apis/service/follow_violation/forwardFollowViolation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ForwardFollowViolationFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface ForwardFollowViolationSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateForwardFollowViolationBody {
  violationId?: number;
  data?: ForwardFollowViolationSchemaI;
}

export interface CreateForwardFollowViolationOptions {
  config?: MutationConfig<typeof createForwardFollowViolationMutationFn>;
}

export const ForwardFollowViolationSchema = Yup.object().shape({
  [ForwardFollowViolationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [ForwardFollowViolationFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ForwardFollowViolationFieldNames.REMIND]: ReminderSchema,
});

export const castForwardFollowViolationRequestSchemaToDTO = (
  schema: any
): ForwardFollowViolationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
