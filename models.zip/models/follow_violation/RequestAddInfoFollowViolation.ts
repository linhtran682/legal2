import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createRequestAddInfoFvMutationFn } from "@/apis/service/follow_violation/requestAddInfoFollowViolation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestAddInfoFvFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  USERS = "users",
  DEPARTMENTS = "departments",
  REMIND = "remind",
}
export interface RequestAddInfoFvSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  remind?: SaveReminderDTO;
}

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};

export interface RequestAddInfoFvDTO {
  user?: TypeUserDTO;
  department?: TypeDepartment;
  deadLine?: string;
  content?: string;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const RequestAddInfoSchemaFV = Yup.object().shape({
  [RequestAddInfoFvFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [RequestAddInfoFvFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [RequestAddInfoFvFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestAddInfoFvFieldNames.REMIND]: ReminderSchema,
});

export interface CreateRequestAddInfoFvBody {
  violationId?: number;
  data?: RequestAddInfoFvSchemaI;
}

export interface CreateRequestAddInfoFvOptions {
  config?: MutationConfig<typeof createRequestAddInfoFvMutationFn>;
}
