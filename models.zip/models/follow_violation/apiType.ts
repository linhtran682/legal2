import { QueryConfig } from "@/apis";
import { ViolationAdvise } from "./FormType";
import { QueryFnType } from "@/apis/service/follow_violation/followViolationAPI";


export interface FollowViolationListParams {
  name?: string;
  field?: number[];
  status?: number[] | string | undefined;
  department?: string;
  nextActionStatus?: number[] | undefined;
  vendorResponseDateFrom?: string;
  vendorResponseDateTo?: string;
  responseDateFrom?: string;
  responseDateTo?: string;
  receiverIds?: string[] | undefined;
  sortBy: string;
  orderBy: string;
  from?: string;
  to?: string;
  page: number;
  size: number;
  tab?: number;
  isEnglish?: boolean;
  picIds?: number[];
}

export interface ObjectCommon {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  createdAt: string;
}

export interface FollowViolation {
  id: string;
  name: string;
  field: ObjectCommon;
  purpose: string;
  status: ObjectCommon;
  vendorMustResponseDate: string;
  summary: string;
  researchOpinion: string;
  consultingDeadlineType: number;
  answerDate: string;
}

export interface FollowViolationListResponse {
  total: 0;
  data: FollowViolation[];
}

// export interface InformationRequestsResponse {
//   detail: InformationRequestType[];
// }

export interface ViolationAdviseListResponse {
  responses: ViolationAdvise[];
}

export type GetAdvisorViolationIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: AdvisorViolationParams;
};

export type AdvisorViolationParams = {
  violationId?: number;
  adviseId?: number;
};

export type GetViolationStatusRequest = {
  name?: string;
  modules?: number[];
  active?: number;
  tab?: number;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}


export interface ViolationStatusDTO {
  id: number;
  name: string;
  module: number;
  active: number;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
  code?: number;
  tab?: number[];
}

export interface GetViolationStatusResponse {
  total: number;
  statusResponses: ViolationStatusDTO[];
}

export interface ViolationStatisticChartResponse {
  pieChart: {
    data: {
      name: string;
      value: number
    }[];
  }
  barChart: {
    data: {
      name: string;
      value: number
    }[];
  }
}
