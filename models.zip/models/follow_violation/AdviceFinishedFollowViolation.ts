import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createAdviceFinishedFvMutationFn } from "@/apis/service/follow_violation/adviceFinishedFollowViolation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum AdviceFinishedFollowViolationFieldNames {
  USERS = "userIds",
  CONTENT = "content",
  REMIND = "remind",
}
export interface AdviceFinishedFollowViolationSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateAdviceFinishedFollowViolationBody {
  violationId?: number;
  data?: AdviceFinishedFollowViolationSchemaI;
}

export interface CreateAdviceFinishedFvOptions {
  config?: MutationConfig<typeof createAdviceFinishedFvMutationFn>;
}

export const AdviceFinishedFollowViolationSchema = Yup.object().shape({
  [AdviceFinishedFollowViolationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [AdviceFinishedFollowViolationFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AdviceFinishedFollowViolationFieldNames.REMIND]: ReminderSchema,
});

export const castAdviceFinishedFvRequestSchemaToDTO = (
  schema: any
): AdviceFinishedFollowViolationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
