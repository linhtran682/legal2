export interface StatusFollowViolationDTO {
  id: number;
  code: number;
  name: string;
  module: number;
  active: number;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
  tab?: number[];
}

// export const enum StatusFollowViolationFieldNames {
//   ID = "id",
//   NAME = "name",
//   MODULE = "module",
//   ACTIVE = "active",
//   DESCRIPTION = "description",
//   CREATED_BY = "createdBy",
//   CREATED_AT = "createdAt",
// }

// export interface GetStatusFollowViolationListParams {
//   name?: string;
//   modules?: number[];
//   active?: number;
//   page: number;
//   size: number;
//   sortBy: string;
//   orderBy: string;
// }

export interface GetStatusFollowViolationListResponse {
  total: number;
  statusResponses: StatusFollowViolationDTO[];
}

// export interface SaveStatusFollowViolationDTO {
//   name?: string;
//   module?: number;
//   active?: number;
//   description?: string;
// }

// export const enum SaveStatusFollowViolationRequestFieldNames {
//   NAME = "name",
//   MODULE = "module",
//   ACTIVE = "active",
//   DESCRIPTION = "description",
// }

// export const SaveStatusFollowViolationRequestSchema = Yup.object().shape({
//   name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
//   module: Yup.number().integer().min(1).max(7).required(),
//   active: Yup.number().integer().min(0).max(1).required(),
//   description: Yup.string().optional(),
// });

// export interface SaveStatusFollowViolationRequestSchemaI {
//   description?: string | undefined;
//   name: string;
//   module: number;
//   active: number;
// }
