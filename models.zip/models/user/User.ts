import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { DepartmentSchema } from "../department/Department";
import { RoleDTO, RoleDTOSchema } from "../role/Role";

export interface Position {
  id: string;
  name: string;
  nameEnglish: string;
}

export interface UserProfileDTO {
  id: string;
  name?: string;
  nameEnglish?: string;
  roles?: RoleDTO[];
  email?: string;
  type?: string;
  company?: string;
  department?: {
    id: string;
    name: string;
    nameEnglish?: string;
  };
  status?: string;
  employeeCode?: string;
  entraId?: string;
  position?: Position;
  editable?: boolean;
  departmentName?: string;
}

export const enum UserProfileFieldNames {
  ID = "id",
  NAME = "name",
  NAME_ENGLISH = "nameEnglish",
  ROLES = "roles",
  EMAIL = "email",
  TYPE = "type",
  COMPANY = "company",
  DEPARTMENT = "department",
  STATUS = "status",
  EMPLOYEE_CODE = "employeeCode",
  ENTRA_ID = "entraId",
  POSITION = "position",
}

export interface GetUsersParams {
  searchTerm?: string;
  sortBy: string;
  sortOrder: string;
  page: number;
  size: number;
  departmentIds?: Array<string>;
  status?: string;
}

export interface GetUsersResponse {
  total: number;
  users: UserProfileDTO[];
}

export interface SaveUserRequestDTO {
  userId?: string;
  name: string;
  email?: string;
  phoneNumber?: string;
  company?: string | null;
  status: string;
  roleIds: string[];
}
export interface CreateUserRequestDTO {
  name: string;
  email: string;
  company?: string | null;
  status: string;
  roleIds: string[];
}

export const SaveUserRequestSchema = Yup.object().shape({
  name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  nameEnglish: Yup.string().trim().optional().nullable(),
  roles: Yup.array(RoleDTOSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(),
  employeeCode: Yup.string().optional().nullable(),
  entraId: Yup.string().optional().nullable(),
  email: Yup.string()
    .email(VALIDATION_MSG.MUST_BE_A_VALID_EMAIL)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  status: Yup.string()
    .trim()
    .defined(VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  // type: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  company: Yup.string().optional().nullable(),
  departmentId: Yup.string().trim().optional().nullable(),
});

export const enum SaveUserRequestSchemaFieldnames {
  NAME = "name",
  NAME_ENGLISH = "nameEnglish",
  ROLES = "roles",
  EMPLOYEE_CODE = "employeeCode",
  ENTRA_ID = "entraId",
  EMAIL = "email",
  STATUS = "status",
  TYPE = "type",
  COMPANY = "company",
  DEPARTMENT_ID = "departmentId",
  DEPARTMENT_NAME = "departmentName",
  POSITION = "position",
}

export interface SaveUserRequestSchemaI {
  name: string;
  nameEnglish?: string | null | undefined;
  roles: RoleDTO[];
  employeeCode?: string | null | undefined;
  entraId?: string | null | undefined;
  email?: string;
  status: string;
  type: string;
  company?: string | null | undefined;
  departmentId?: string | null | undefined;
  position?: string;
  departmentName?: string;
}

export const castUserProfileDTOToSaveUserRequestSchemaI = (
  userProfile: UserProfileDTO
): SaveUserRequestSchemaI => {
  return {
    name: userProfile.name ?? "",
    nameEnglish: userProfile.nameEnglish,
    roles: userProfile.roles ?? [],
    employeeCode: userProfile.employeeCode,
    entraId: userProfile.entraId,
    email: userProfile.email,
    status: userProfile.status ?? "",
    type: userProfile.type ?? "GUEST",
    company: userProfile.company,
    departmentId: userProfile.department?.id,
    position: userProfile?.position?.name,
    departmentName: userProfile?.department?.name,
  };
};

export const castSaveUserRequestSchemaIToSaveUserRequestDTO = (
  schema: SaveUserRequestSchemaI,
  userId?: string
): SaveUserRequestDTO => {
  return {
    userId: userId,
    name: schema.name,
    email: schema.email,
    company: schema.company,
    status: schema.status,
    roleIds: schema.roles.map((role) => role.id),
  };
};

export interface BasedUser {
  id: string;
  name?: string | undefined;
  nameEnglish?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
  department?: DepartmentSchema;
  basicPosition?: Position;
  position?: Position;
  positionResponse?: Position;
  departmentResponse?: DepartmentSchema;
}

export const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().nullable().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable().optional(),
});
