import { FieldValues } from "react-hook-form";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createFeedbackDocumentReviewMutationFn } from "@/apis/service/document-review/feedback";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedbackFieldNames {
  USERS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FeedbackSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateFeedbackDocumentReviewBody {
  documentReviewId?: number;
  data?: FeedbackSchemaI;
}

export interface CreateFeedbackOptions {
  config?: MutationConfig<typeof createFeedbackDocumentReviewMutationFn>;
}

export const FeedbackSchema = Yup.object().shape({
  // [FeedbackLegalAdviceFieldNames.DEADLINE]: Yup.number().required(
  //   "Deadline name is required"
  // ),
  [FeedbackFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [FeedbackFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  [FeedbackFieldNames.REMIND]: ReminderSchema,
});

export const castFeedbackRequestSchemaToDTO = (
  schema: any
): FeedbackSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

/**
 * Legal check sheet
 */

export interface CreateFeedbackLcBody {
  status: number;
  content: string;
  userIds: string[];
  remind?: SaveReminderDTO;
}

export const FeedbackLcSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  userIds: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});

export const castFeedbackLcDTO = (schema: any): CreateFeedbackLcBody => {
  return {
    ...schema,
    responseDate: schema?.responseDate?.toISOString?.() ?? undefined,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export interface LcsFeedbackItem {
  content: string;
  date: string;
  feedbackUser: BasedUser;
  receiveUser: BasedUser;
  type: number;
}

export interface DrrFeedbackItem {
  feedbackUser: BasedUser;
  receiveUsers: BasedUser[];
  receiveUser: BasedUser;
  content: string;
  date: string;
  type: number;
  feedbackType?: number;
}
