import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createTimeExtensionMutationFn,
  getTimeExtensionQueryFn,
  updateTimeExtensionMutationFn,
} from "@/apis/service/document-review/timeExtensionDocumentReview";
import { VALIDATION_MSG } from "@/constants/message";
import { BasedUser } from "../user/User";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export const enum TimeExtensionRequestFieldNames {
  DEADLINE = "deadline",
  REASON = "reason",
  REMIND = "remind",
  CONFIRM = "confirm",
  ACCEPTABLE_DEADLINE = "acceptableDeadline",
  ACCEPTABLE_DEADLINE_REASON = "acceptableReason",
  USERS = "users",
  DEPARTMENTS = "departments",
}

export const ExtensionOptions: RadioItem[] = [
  {
    label: "metadata.extend.column.accept",
    value: 1,
  },
  {
    label: "metadata.extend.column.newDeadline",
    value: 0,
  },
];

export const TimeExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.REMIND]: ReminderSchema,
});

export const ConfirmExtensionRequestSchema = Yup.object().shape({
  [TimeExtensionRequestFieldNames.CONFIRM]: Yup.boolean().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE]: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD);
      }
      return schema.notRequired();
    }),
  [TimeExtensionRequestFieldNames.ACCEPTABLE_DEADLINE_REASON]: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .when(TimeExtensionRequestFieldNames.CONFIRM, ([confirm], schema) => {
      if (!confirm) {
        return schema.required(VALIDATION_MSG.REQUIRED_FIELD);
      }
      return schema.notRequired();
    }),
});
export interface Department {
  id: string;
  name?: string;
  nameEnglish?: string;
}

export interface TimeExtensionUser {
  id?: string;
  name?: string | undefined;
  nameEnglish?: string;
  email?: string | undefined;
  department?: Department;
}
export interface TimeExtensionRequestSchemaI extends FieldValues {
  deadline?: string;
  reason?: string;
  remind?: ReminderSchemaI;
}

export interface RequestApprovalDTO {
  id?: number;
  deadline?: string;
  reason?: string | undefined;
  user?: TimeExtensionUser;
  department?: Department;
}

interface TypeAcceptTimeExtension {
  deadlineAccept?: string;
  reason?: string;
  type?: number;
  users?: string[];
  remind: SaveReminderDTO;
}
export interface UpdateTimeExtensionBody {
  documentReviewId?: number;
  lcsId?: number;
  timeExtensionRequestId?: number;
  lcsTimeExtensionRequestId?: number;
  data?: TypeAcceptTimeExtension;
}

export interface CreateTimeExtensionBody {
  documentReviewId?: number;
  lcsId?: number;
  data?: TimeExtensionRequestSchemaI;
}

export interface CreateTimeExtensionOptions {
  config?: MutationConfig<typeof createTimeExtensionMutationFn>;
}

export type TimeExtensionParams = {
  documentReviewId?: number;
  timeExtensionRequestId?: number;
};
export type LcsTimeExtensionParams = {
  lcsId?: number;
  lcsTimeExtensionRequestId?: number;
};

export type QueryFnType = typeof getTimeExtensionQueryFn;

export type GetTimeExtensionIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: TimeExtensionParams;
};
export type GetLcsTimeExtensionIdOptions = {
  config?: QueryConfig<QueryFnType>;
  request: LcsTimeExtensionParams;
};

export type UpdateTimeExtensionAcceptOptions = {
  config?: MutationConfig<typeof updateTimeExtensionMutationFn>;
};

export interface ReviewTimeExtension {
  user: BasedUser;
  reason: string;
  requestDeadline: string;
  acceptDeadline: string;
  date: string;
  type?: number;
  id: number;
  showExtension?: boolean;
  enableExtension?: boolean;
}

export interface GetReviewExtensionResponse {
  timeExtensionResponseDetails: ReviewTimeExtension[];
}
