import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface SendMailRequest {
  subject?: string;
  content?: string;
  receivers: string[];
}

export const SendMailRequestSchema = Yup.object().shape({
  receivers: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  content: Yup.string().optional(),
  departments: Yup.array().optional(),
});
