import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { SaveReminderDTO } from "./AssignmentDocumentReview";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";
import { CurrencyDTO } from "../currency/Currency";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import { ReminderInput } from "../reminder_template/ReminderDTO";
import { isBefore, startOfDay } from "date-fns";
import {
  getAllHierarchyById,
  getDocumentReviewRequests,
} from "@/apis/service/document-review/documentReview";
import { GenericSearchPanelProps } from "@/components/commons/search_panel/GenericSearchPanel";
import { formatDate } from "@/utils";
import { DOCUMENT_REVIEW_ROOT_PATH } from "@/constants/paths";
import { REGEX_LINK } from "@/constants/regex";
import { Department } from "../department/Department";

export const enum AttachmentTypes {
  RINGI_FILE = 0,
  PR_FILE = 1,
  DRAFT_CONTRACT_FILE = 2,
  DEBT_FILE = 3,
  OTHER = 4,
}

export const enum DocumentReviewDetailFields {
  ID = "id",
  DOCUMENT_NAME = "documentName",
  PURPOSE = "purpose",
  CONFIRMED_WITH_MANAGERS = "confirmWithManagementLevelFlag",
  STATUS = "status",
  VENDOR_RESPONSE_DATE = "vendorResponseDate",
  ATTACHMENT_TYPE = "attachmentType",
  REPAYMENT_DATE = "repaymentDate",
  REPAYMENT_REASON = "repaymentReason",
  SIGNERS = "signers",
  SIGNING_DATE = "signingDate",
  EFFECTIVE_DATE = "effectiveDate",
  EFFECTIVE_END_DATE = "effectiveEndDate",
  BACKDATE_APPROVAL_TYPE = "backdateApprovalEmailAttachmentType",
  BACKDATE_DUE_DATE = "backdateApprovalEmailDebtDate",
  BACKDATE_DEBT_REASON = "backdateApprovalEmailDebtReason",
  SOW_CONTRACT = "sowContract",
  CONTRACT_VALUE = "contractValue",
  CONTRACT_CONTENT = "contractContent",
  CONTRACT_CURRENCY = "contractCurrency",
  SAMPLE = "sampleContractType",
  SAMPLE_CONTRACT_CONTENT = "sampleContractContent",
  DESIRED_CONDITION = "desiredCondition",
  PROBLEM = "problem",
  OPINION = "opinion",
  RESPONSE_TYPE = "responseDeadlineType",
  RESPONSE_DATE = "responseDate",
  URGENT_RESPONSE_DATE = "urgentResponseDate",
  URGENT_RESPONSE_REASON = "urgentResponseReason",
  RECEIVERS = "receivers",
  RELATED_USERS = "relatedUsers",
  LCS_STATUS = "lcsStatus",
  LCS_RECEIVERS = "lcsReceivers",
  //
  LCS_NAME = "lcsName",
  LCS_DUE_DATE = "lcsDueDate",
  OTHER_SAMPLE_CONTENT = "sampleOtherContent",
  APPROVAL_CONTENT = "approvalContent",
  ASSIGNMENT_USERS = "assignUsers",
  RESPONSIBLE_USERS = "responsibleUsers",
}

export const DocumentReviewRequestSchema = Yup.object()
  .shape({
    // [DocumentReviewDetailFields.PURPOSE]: Yup.number()
    //   .min(1, VALIDATION_MSG.SELECT)
    //   .required(VALIDATION_MSG.SELECT),
    [DocumentReviewDetailFields.DOCUMENT_NAME]: Yup.string().required(
      VALIDATION_MSG.REQUIRED_FIELD
    ),
    [DocumentReviewDetailFields.STATUS]: Yup.number().required(
      VALIDATION_MSG.SELECT
    ),
    [DocumentReviewDetailFields.ATTACHMENT_TYPE]: Yup.number().required(
      VALIDATION_MSG.SELECT
    ),
    attachments: Yup.array()
      .min(1, VALIDATION_MSG.SELECT_FILE)
      .required(VALIDATION_MSG.SELECT_FILE),
    contractAttachments: Yup.array()
      .min(1, VALIDATION_MSG.SELECT_FILE)
      .required(VALIDATION_MSG.SELECT_FILE),

    [DocumentReviewDetailFields.REPAYMENT_DATE]: Yup.mixed().when(
      DocumentReviewDetailFields.ATTACHMENT_TYPE,
      {
        is: (type: any) => Number(type) === 3,
        then: () =>
          Yup.date()
            .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
            .required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    [DocumentReviewDetailFields.REPAYMENT_REASON]: Yup.string().when(
      DocumentReviewDetailFields.ATTACHMENT_TYPE,
      {
        is: (type: any) => Number(type) === 3,
        then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),

    [DocumentReviewDetailFields.BACKDATE_APPROVAL_TYPE]: Yup.number().when(
      DocumentReviewDetailFields.EFFECTIVE_DATE,
      {
        is: (value: any) => {
          return (
            !!value &&
            isBefore(startOfDay(new Date(value)), startOfDay(new Date()))
          );
        },
        // is: (value: any) => !value,
        then: () =>
          Yup.number()
            .min(0, VALIDATION_MSG.SELECT)
            .required(VALIDATION_MSG.SELECT),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    // backDateAttachments: Yup.array()
    // .min(1, VALIDATION_MSG.SELECT_FILE)
    // .required(VALIDATION_MSG.SELECT_FILE),
    backDateAttachments: Yup.array().when(
      DocumentReviewDetailFields.BACKDATE_APPROVAL_TYPE,
      {
        is: (type: any) => type === 0,
        then: () =>
          Yup.array()
            .min(1, VALIDATION_MSG.SELECT_FILE)
            .required(VALIDATION_MSG.SELECT_FILE),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    [DocumentReviewDetailFields.BACKDATE_DUE_DATE]: Yup.mixed().when(
      DocumentReviewDetailFields.BACKDATE_APPROVAL_TYPE,
      {
        is: (type: any) => Number(type) === 1,
        then: () =>
          Yup.date()
            .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
            .required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    [DocumentReviewDetailFields.BACKDATE_DEBT_REASON]: Yup.string().when(
      DocumentReviewDetailFields.BACKDATE_APPROVAL_TYPE,
      {
        is: (type: any) => Number(type) === 1,
        then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    [DocumentReviewDetailFields.SIGNERS]: Yup.array()
      .min(1, VALIDATION_MSG.SELECT)
      .required(VALIDATION_MSG.SELECT),
    [DocumentReviewDetailFields.SIGNING_DATE]: Yup.date()
      .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    [DocumentReviewDetailFields.EFFECTIVE_DATE]: Yup.date()
      .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    [DocumentReviewDetailFields.EFFECTIVE_END_DATE]: Yup.date()
      .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    [DocumentReviewDetailFields.SOW_CONTRACT]: Yup.string().required(
      VALIDATION_MSG.REQUIRED_FIELD
    ),
    [DocumentReviewDetailFields.CONTRACT_VALUE]: Yup.string()
      // .typeError(VALIDATION_MSG.REQUIRED_FIELD)
      // .positive(VALIDATION_MSG.ENTER_GREATER_THAN_0)
      .required(VALIDATION_MSG.REQUIRED_FIELD)
      .test("is-integer", VALIDATION_MSG.REQUIRED_FIELD, (value) =>
        /^[0-9,]+$/.test(value)
      ),
    // .test(
    //   "is-zero",
    //   VALIDATION_MSG.ENTER_GREATER_THAN_0,
    //   (value) => value !== "0"
    // ),
    [DocumentReviewDetailFields.CONTRACT_CURRENCY]: Yup.number().required(
      VALIDATION_MSG.SELECT
    ),
    [DocumentReviewDetailFields.SAMPLE]: Yup.number().required(
      VALIDATION_MSG.SELECT
    ),
    [DocumentReviewDetailFields.SAMPLE_CONTRACT_CONTENT]: Yup.string().required(
      VALIDATION_MSG.REQUIRED_FIELD
    ),
    [DocumentReviewDetailFields.DESIRED_CONDITION]: Yup.string().required(
      VALIDATION_MSG.REQUIRED_FIELD
    ),
    // [DocumentReviewDetailFields.PROBLEM]: Yup.string().required(
    //   VALIDATION_MSG.REQUIRED_FIELD
    // ),
    // [DocumentReviewDetailFields.OPINION]: Yup.string().required(
    //   VALIDATION_MSG.REQUIRED_FIELD
    // ),
    [DocumentReviewDetailFields.RESPONSE_TYPE]: Yup.number().required(
      VALIDATION_MSG.SELECT
    ),

    [DocumentReviewDetailFields.RESPONSE_DATE]: Yup.mixed().when(
      DocumentReviewDetailFields.RESPONSE_TYPE,
      {
        is: (type: any) => Number(type) === 1,
        then: () =>
          Yup.date()
            .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
            .required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    [DocumentReviewDetailFields.URGENT_RESPONSE_DATE]: Yup.mixed().when(
      DocumentReviewDetailFields.RESPONSE_TYPE,
      {
        is: (type: any) => Number(type) === 2,
        then: () =>
          Yup.date()
            .typeError(VALIDATION_MSG.ENTER_VALID_VALUE)
            .required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    [DocumentReviewDetailFields.URGENT_RESPONSE_REASON]: Yup.string().when(
      DocumentReviewDetailFields.RESPONSE_TYPE,
      {
        is: (type: any) => Number(type) === 2,
        then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.optional().nullable(),
      }
    ),
    [DocumentReviewDetailFields.RECEIVERS]: Yup.array()
      .min(1, VALIDATION_MSG.SELECT)
      .required(VALIDATION_MSG.SELECT),
    sampleContractLink: Yup.string()
      .nullable()
      .test("is-url", VALIDATION_MSG.MUST_BE_A_VALID_URL, (value) => {
        if (!value) return true;
        return REGEX_LINK.test(value);
      }),
    checkDeptHeadFlag: Yup.boolean(),
    checkDivisionFlag: Yup.boolean(),
  })
  .test(
    "head-checkbox",
    "legalAdvice.messages.requiredToBeSentTo",
    (values) => values.checkDeptHeadFlag || values.checkDivisionFlag
  );

export interface DocumentReviewFormSend {
  documentName?: string;
  status?: number;
  confirmWithManagementLevelFlag?: boolean;
  receivers?: BasedUser[];
  responseDeadlineType?: number;
  checkDeptHeadFlag?: boolean;
  checkDivisionFlag?: boolean;
  bookingFlag?: boolean;
  attachmentType?: number;
  effectiveDate?: any;
  signingDate?: any;
  effectiveEndDate?: any;
  backdateApprovalEmailAttachmentType?: number;
  relatedUsers?: BasedUser[];
  repaymentDate?: any;
  repaymentReason?: string;
  departments?: any;
  signers?: BasedUser[];
  sowContract?: string;
  backdateApprovalEmailDebtReason?: string;
  contractCurrency?: any;
  sampleContractType?: number;
  sampleContractContent?: string;
  contractValue?: string;
  purpose?: string;
  opinion?: string;
  problem?: string;
  desiredCondition?: string;
  responseDate?: any;
  urgentResponseDate?: any;
  urgentResponseReason?: any;
  backdateApprovalEmailDebtDate?: any;
  sampleContractLink?: string;

  remind?: any;
  lcsStatus?: any;
  lcsReceivers?: any;
}
export interface DocumentReviewBodySend {
  isDraft?: boolean;
  documentId?: number;
  documentName?: string;
  attachmentIds?: number[];
  statusId?: number;
  attachmentType?: number;
  confirmWithManagementLevelFlag?: number;
  vendorResponseDate?: string;
  repaymentDate?: string;
  repaymentReason?: string;
  signerIds?: string[];
  signingDate?: string;
  effectiveDate?: string;
  effectiveEndDate?: string;
  backdateApprovalEmailAttachmentType?: number;
  backdateApprovalEmailAttachmentIds?: number[];
  backdateApprovalEmailDebtDate?: string;
  backdateApprovalEmailDebtReason?: string;
  sowContract?: string;
  contractValue?: number;
  currencyId?: number;
  sampleContractType?: number;
  sampleContractContent?: string;
  sampleContractAttachmentIds?: number[];
  sampleContractLink?: string;
  desiredCondition?: string;
  problem?: string;
  opinion?: string;
  responseDeadlineType?: number;
  responseDate?: string;
  urgentResponseReason?: string;
  relatedUserIds?: string[];
  receiverUserIds?: string[];
  checkDivisionFlag?: number;
  checkDeptHeadFlag?: number;
  bookingFlag?: number;
  remind?: SaveReminderDTO;
  sampleOtherContent?: string;
  responsibleUsers?: string[];
}
export interface DocumentReviewBodyReceive {
  id: number;
  lcsId?: number;
  pic?: BasedUser;
  documentName: string;
  attachmentType?: number;
  attachments?: LegalAdviceAttachment[];
  status?: StatusDTO;
  confirmWithManagementLevelFlag?: number;
  vendorResponseDate?: string;
  repaymentDate?: string;
  signerList: BasedUser[];
  signingDate?: string;
  effectiveDate?: string;
  effectiveEndDate?: string;
  backdateApprovalEmailAttachmentType?: number;
  backdateApprovalEmailAttachmentFiles: LegalAdviceAttachment[];
  backdateApprovalEmailDebtDate?: string;
  backdateApprovalEmailDebtReason?: string;
  sowContract?: string;
  contractValue?: number;
  currency?: CurrencyDTO;
  sampleContractType?: number;
  sampleContractContent?: string;
  sampleContractAttachmentFiles: LegalAdviceAttachment[];
  sampleContractLink?: string;
  desiredCondition?: string;
  problem?: string;
  opinion?: string;
  responseDeadlineType?: number;
  responseDate?: string;
  urgentResponseReason?: string;
  receiverUsers: BasedUser[];
  relateUsers: BasedUser[];
  isDraft: boolean;
  bookingFlag: number;
  completeLCSFlag: number;
  confirmLCSFlag?: number;
  confirmFlag?: number;
  completeReviewFlag: number;
  approvedFlag: number;
  checkDivisionFlag?: number;
  checkDeptHeadFlag?: number;
  remind?: ReminderInput;
  createdDate?: string;
  inspectionId?: number;
  isSupervisor?: boolean;

  userLastActionAndRoleResponse: {
    otherActionsAvailableFlag: 0;
    requestTimeExtensionAvailableFlag: 0;
    documentDoneOrInspectionDoneFlag: 0;
    userLastActionAndRoleList: {
      role: number;
      lastAction: number;
    }[];
  };

  completeInspectionFlag?: number;
  supervisorInspectionFlag?: number;

  sharedDepartments?: Department[];
  legalAccessType?: number;
  sharedUsers?: BasedUser[];

  assignUsers?: BasedUser[];
  responsibleUsers?: BasedUser[];
  lcsStatus?: number;

  meetingNumber?: number;
  inspectionNumber?: number;
  requestInspectionNumber?: number;
  supervisorInspectionNumber?: number;
  requestSupervisorInspectionNumber?: number;
  evaluateNumber?: number;
  esignSigned?: number;
}

export enum DocumentReviewStatusList {
  REQUEST_REVIEW = "Yêu cầu kiểm tra",
  ASSIGNMENT = "Phân công", //
  REQUEST_VENDOR_REVIEW = "Gửi vendor kiểm tra",
  REQUEST_INFORMATION = "Yêu cầu bổ sung thông tin", //
  INFORMATION_ADDED = "Đã bổ sung thông tin", //
  REVIEW = "Kiểm tra",
  SENT_TO_SUPERVISOR = "Yêu cầu giám sát kiểm tra",
  SUPERVISOR_REVIEWED = "Giám sát đã kiểm tra",
  DONE_REVIEW = "Đã kiểm tra",
  DONE_DOCUMENT_REVIEW = "Hoàn thành kiểm tra tài liệu",
  REVIEW_FEEDBACK = "Phản hồi kiểm tra",
  // DONE = "Hoàn thành", //
}
export const DONE_STATUS = "Hoàn thành";
export enum LegalCheckSheetStatusList {
  LCS_NEW = "LCS: Tạo mới",
  REQUEST_EVALUATION = "Yêu cầu đánh giá",
  REQUEST_INFORMATION = "Yêu cầu bổ sung thông tin",
  INFORMATION_ADDED = "Đã bổ sung thông tin",
  ASSIGNMENT = "Phân công",
  FEEDBACK_EVALUATION = "Phản hồi đánh giá",
  EVALUATED = "Đã đánh giá/nhận xét",
  REQUEST_SIGNING = "Yêu cầu ký duyệt",
  SIGNED = "Ký duyệt",
  SIGN_REJECT = "Ký duyệt: Từ chối",
  SIGN_DONE = "Ký duyệt: Hoàn thành",
  DONE_LCS = "Legal check sheet: Hoàn thành",
  // DONE = "Hoàn thành",
}
export const LegalCheckSheetStatusCodeList = {
  LCS_NEW: 1,
  REQUEST_EVALUATION: 2,
  REQUEST_INFORMATION: 3,
  INFORMATION_ADDED: 4,
  ASSIGNMENT: 5,
  FEEDBACK_EVALUATION: 6,
  EVALUATED: 7,
  REQUEST_SIGNING: 8,
  SIGN_REJECT: 9,
  SIGN_DONE: 10,
  DONE_LCS: 11,
  SIGN_RECALL: 12,
  DONE: 13,
  EVALUATING: 14,
};

export const LCS_DONE_STATUS = 13;

// export const LcsStatusLabels = {
//   1: "LCS: Tạo mới",
//   2: "Yêu cầu đánh giá",
//   3: "Yêu cầu bổ sung thông tin",
//   4: "Đã bổ sung thông tin",
//   5: "Phân công",
//   6: "Phản hồi đánh giá",
//   7: "Đã đánh giá/nhận xét",
//   8: "Yêu cầu ký duyệt",
//   9: "Ký duyệt: Từ chối",
//   10: "Ký duyệt: Hoàn thành",
//   11: "Legal check sheet: Hoàn thành",
//   12: "Hoàn thành",
// };
//     NEW(1, "LCS: Tạo mới"),
//     REQUEST_REVIEW(2, "LCS:Yêu cầu đánh giá"),
//     REQUEST_ADDITIONAL_INFO(3, "Yêu cầu bổ sung thông tin"),
//     INFO_ADDED(4, "Đã bổ sung thông tin"),
//     ASSIGNED(5, "LCS: Phân công"),
//     REVIEW_FEEDBACK(6, "LCS: Phản hồi đánh giá"),
//     REVIEWED(7, "LCS: Đã đánh giá/nhận xét"),
//     REQUEST_SIGNATURE(8, "LCS: Yêu cầu ký duyệt"),
//     SIGNED_REFUSE(9, "LCS: Từ chối ký duyệt"),
//     SIGNED_DONE(10, "LCS: Đã ký duyệt"),
//     DONE_LCS_FEEDBACK(11, "LCS: Hoàn thành ký duyệt"),
//     SIGNED_REVOKE(12, "LCS: Thu hồi ký duyệt"),
//     DONE(13, "Hoàn thành");
export const LcsStatusLabels = {
  1: "LCS: Tạo mới",
  2: "LCS: Yêu cầu đánh giá",
  3: "Yêu cầu bổ sung thông tin",
  4: "Đã bổ sung thông tin",
  5: "LCS: Phân công",
  6: "LCS: Phản hồi đánh giá",
  7: "LCS: Đã đánh giá/nhận xét",
  // 8: "LCS: Yêu cầu ký duyệt",
  8: "LCS: Call eSign",
  9: "LCS: Từ chối ký duyệt",
  10: "LCS: Đã ký duyệt",
  11: "LCS: Hoàn thành ký duyệt",
  12: "LCS: Thu hồi ký duyệt",
  13: "Hoàn thành",
  14: "LCS: Đang thực hiện đánh giá",
};

enum SearchPanelQueries {
  GET_HIERARCHY = "document-review/get-hierarchy",
  SEARCH_DOCUMENT = "document-review/search_document",
  SEARCH_KEY = "documentName",
}
export const documentReviewSearchPanelConfig: GenericSearchPanelProps<any> = {
  completeStatusName: DONE_STATUS,
  getHierarchyFn: (id) => getAllHierarchyById({ id }),
  getItemKey: (item) => item?.documentId ?? item?.id,
  getChildKey: (child) => child?.documentId ?? child?.id,
  getSearchResultFn: getDocumentReviewRequests,
  hierarchyQueryKey: SearchPanelQueries.GET_HIERARCHY,
  searchQueryKey: SearchPanelQueries.SEARCH_DOCUMENT,
  searchKey: SearchPanelQueries.SEARCH_KEY,
  getItemName: (item) => item?.documentName,
  getCreator: (item) => item?.pic ?? item?.createdUser,
  getParentTimeLabel: (item) =>
    item?.createdDate ? formatDate(item?.createdDate, "dd/MM/yyyy HH:mm") : "",
  getParentUsersList: (item) => item?.receiverUsers ?? item?.users,
  // getParentStatus: (item) => item?.status?.name ?? item?.status ?? "",
  getParentStatus: (item) =>
    item?.lcsStatus
      ? (LcsStatusLabels as any)?.[item?.lcsStatus?.toString?.()]
      : item?.status?.name ?? item?.status ?? "",
  // getChildStatus: (child) => child?.status?.name ?? child?.status ?? "",
  getChildStatus: (child) =>
    child?.lcsStatus
      ? (LcsStatusLabels as any)?.[child?.lcsStatus?.toString?.()]
      : child?.status?.name ?? child?.status ?? "",
  getChildTimeLabel: (child) =>
    child?.createdDate
      ? formatDate(child?.createdDate, "dd/MM/yyyy HH:mm")
      : "",
  getChildUsersList: (child) => child?.receiverUsers,
  getChildren: (item) => item?.children ?? [],
  getItemLink: (item) =>
    `/${DOCUMENT_REVIEW_ROOT_PATH}/update/${item?.documentId ?? item?.id}`,
};

export const enum DrrmRoles {
  PIC = 1,
  L_C = 2,
  HEAD_OF_L_C = 3,
  SUPERVISOR = 4,
  RELATED_PERSON = 5,
  VIEWER = 6,
  FORWARD = 7,
  SIGNER = 8,
}
