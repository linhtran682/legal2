import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";

export interface ForwardDocumentReviewRequest {
  userIds: string[];
  deadline?: string;
  content?: string;
  remind?: SaveReminderDTO;
}

export const ForwardDocumentReviewRequestSchema = Yup.object().shape({
  userIds: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  deadline: Yup.date().required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});

export interface ForwardDocumentReviewRequestSchemaI {
  userIds: BasedUser[];
  content?: string | undefined;
  remind?: ReminderSchemaI | undefined;
}

export const enum ForwardDocumentReviewFieldNames {
  DEPARTMENTS = "departments",
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}

export const castForwardDocumentReviewRequestSchemaToDTO = (
  schema: ForwardDocumentReviewRequestSchemaI
): ForwardDocumentReviewRequest => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id),
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
