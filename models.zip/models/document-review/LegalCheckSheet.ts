import { VALIDATION_MSG } from "@/constants/message";
import { BasedUser } from "../user/User";
import * as Yup from "yup";
import { DocumentReviewActionBtnKey } from "./DocumentReviewList";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";

export const enum LcsFields {
  LCS_NAME = "name",
  LCS_DEADLINE = "deadlineLCS",
  LCS_STATUS = "status",
  LCS_TO_SIGN_LIST = "legalCheckSheetToBeSigned",
  LCS_ATTACHMENTS = "attachmentFiles",
  LCS_LAST_ATTACHMENTS = "lastAttachmentFiles",
  LCS_SIGNERS = "signers",
  LCS_SIGNED_ATTACHMENTS = "signedAttachments",

  ASSIGNMENT_USERS = "assignmentUsers",
  EVALUATE_USERS = "evaluateUsers",
}

export interface LegalCheckSheetItemToBeSigned {
  attachmentFiles: {
    fileId: number;
    toBeSigned: boolean;
  }[];
  lastAttachmentFiles: number[];
  signers: {
    order: number;
    signerId: string;
    note: string;
  }[];
}

export interface LegalCheckSheetBodySend {
  drrmId: number;
  confirmedWithManagement: boolean;
  name: string;
  deadlineLCS: string;
  status: number;
  inChangeUserIds: string[];
  legalCheckSheetToBeSigned: LegalCheckSheetItemToBeSigned[];
  attachmentFiles: {
    fileId: number;
    toBeSigned: true;
  }[];
  sharePointAttachmentFiles: {
    fileId: number;
    toBeSigned: true;
  }[];
  otherAttachmentFiles: number[];
}

export interface LcsButtonActions {
  requestEvaluate: number;
  requestSign: number;
  feedbackLC: number;
  finish: number;
  signAndApprove: number;
  confirm: number;
  assignment: number;
  informationRequest: number;
  feedbackEvaluate: number;
  evaluate: number;
  timeExtensionRequest: number;
  timeExtension: number;
  recall: number;
  sendMail: number;
  forward: number;
  requestMeeting: number;
  feedback: number;
}

export interface LcsLastAttachment {
  id: number;
  name: string;
  storagePath: string;
  isDoneLegalCheckSheet: boolean;
  status: number;
  processingDate: string;
}

export interface ToBeSignedItem {
  id: number;
  status: number;
  lastAttachmentFiles: LcsLastAttachment[];
  attachmentFilesWithApprove: {
    id: number;
    name: string;
    storagePath: string;
    status: number;
  }[];
  signers: {
    id: number;
    user: BasedUser;
    position: number;
    status: number;
    processingDate: string;
    note: string;
  }[];
}
export interface LegalCheckSheetBodyReceive {
  confirmedWithManagement: boolean;
  isEnableAddLCS?: boolean;
  name: string;
  deadlineLCS: string;
  status: number;
  sharePointAttachmentFiles: {
    id: number;
    fileName: string;
    sharePointLink: string;
    storePath: string;
    toBeSigned: boolean;
    status: number;
  }[];
  attachmentFiles: (LegalAdviceAttachment & { toBeSigned: boolean })[];
  otherAttachmentFiles: LegalAdviceAttachment[];
  inChangeUsers: BasedUser[];
  legalCheckSheetToBeSigned: ToBeSignedItem[];
  ownerRoles: number[];
  buttonAction: LcsButtonActions;

  assignmentUsers?: BasedUser[];
  evaluateUsers?: BasedUser[];
  reasonForLate?: string | null;
}

export interface LcsSignerListResponse {
  signers: BasedUser[];
}

export const enum LegalCheckSheetItemStatus {
  NEW = 0,
  CALLED_TO_ESIGN = 1,
  RECALLED = 2,
  DONE = 3,
  REFUSE = 4,
}

export const enum ApproverStatus {
  NEW = 0,
  SIGNED = 1,
  REJECT = 2,
}

export const enum FileStatus {
  DONE = 1,
  REJECT = 2,
  REVOKE = 3,
}

export const enum LcsButtonActionStatus {
  SHOW_ENABLE = 1,
  SHOW_DISABLE = 2,
  HIDE = 3,
}

export const enum LcsRoles {
  REQUEST_DEPT = 1,
  SIGNER = 2,
  LC = 3,
  SUPERVISOR = 4,
  RELATED_DEPT = 5,
}

export const PrimaryButtonList = [
  DocumentReviewActionBtnKey.REQUEST_EVALUATE,
  DocumentReviewActionBtnKey.REQUEST_SIGN,
  DocumentReviewActionBtnKey.FEEDBACK_LC,
  DocumentReviewActionBtnKey.SIGN_AND_APPROVE,
  DocumentReviewActionBtnKey.CONFIRM,
  DocumentReviewActionBtnKey.ASSIGNMENT,
  // DocumentReviewActionBtnKey.INFORMATION_REQUEST,
  DocumentReviewActionBtnKey.FEEDBACK_EVALUATE,
  DocumentReviewActionBtnKey.EVALUATE,
  DocumentReviewActionBtnKey.FINISH,
];

export const SecondaryButtonList = [
  DocumentReviewActionBtnKey.RECALL,
  DocumentReviewActionBtnKey.SEND_MAIL,
  DocumentReviewActionBtnKey.FORWARD,
  DocumentReviewActionBtnKey.FEEDBACK,
  // DocumentReviewActionBtnKey.REQUEST_MEETING,
  // DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST,
];

export const signerSchema = Yup.array()
  .of(
    Yup.object().shape({
      signerId: Yup.string().optional().nullable(), // Each signer can optionally have an id
    })
  )
  .test(
    "required-positions",
    "DOCUMENT_REVIEW.messages.requiredPositions",
    (signers: any) => {
      // Validate the id for specific positions
      return !signers
        ? true
        : signers &&
            signers[0]?.signerId && // Position 1 (index 0)
            signers[1]?.signerId && // Position 2 (index 1)
            signers[4]?.signerId && // Position 5 (index 4)
            signers[5]?.signerId && // Position 6 (index 5)
            signers[6]?.signerId; // Position 7 (index 6)
    }
  );

export const LegalCheckSheetSchema = Yup.object().shape({
  [LcsFields.LCS_NAME]: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  // [LcsFields.LCS_DEADLINE]: Yup.mixed().required(VALIDATION_MSG.REQUIRED_FIELD),
  [LcsFields.LCS_STATUS]: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  [LcsFields.LCS_ATTACHMENTS]: Yup.array()
    .min(1, "DOCUMENT_REVIEW.messages.selectLcsFile")
    .required("DOCUMENT_REVIEW.messages.selectLcsFile"),
  // [LcsFields.LCS_TO_SIGN_LIST]: Yup.array()
  //   .of(
  //     Yup.object().shape({
  //       [LcsFields.LCS_SIGNERS]: signerSchema,
  //     })
  //   )
  //   .nullable()
  //   .optional(),
});

export const enum SpPermissionTypes {
  ACC_365_UPLOAD = 1,
  ACC_365_NO_UPLOAD = 2,
  ACC_UPLOAD = 3,
}

export interface SpPermissionResponse {
  result: SpPermissionTypes;
}

export interface LcsFileIdBody {
  fileSharepointId?: number;
  fileNormalId?: number;
  fileOtherId?: number;
}
