import { VALIDATION_MSG } from "@/constants/message";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
} from "../reminder_template/ReminderDTO";
import { BasedUser, BasedUserSchema } from "../user/User";

export interface ReviewAssignment {
  assignUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
}

export interface GetReviewAssignmentResponse {
  assignmentResponseDetails: ReviewAssignment[];
}

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum AssignmentDocumentReviewFieldNames {
  STATUS = "status",
  CONTENT = "content",
  USERS_IDS = "userIds",
  REMIND = "remind",
}
export interface AssignmentDocumentReviewSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export const AssignmentDocumentReviewSchema = Yup.object().shape({
  [AssignmentDocumentReviewFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AssignmentDocumentReviewFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [AssignmentDocumentReviewFieldNames.REMIND]: ReminderSchema,
});

export interface CreateAssignmentDocumentReviewBody {
  documentReviewId?: number;
  lcsId?: number;
  data?: AssignmentDocumentReviewSchemaI;
}

// export interface CreateAssignmentDocumentReviewOptions {
//   config?: MutationConfig<typeof createAssignmentDocumentReviewMutationFn>;
// }

export const castAssignmentDocumentReviewRequestSchemaToDTO = (
  schema: any
): AssignmentDocumentReviewSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
