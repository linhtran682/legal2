import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}
export interface FinishReviewRequest {
  status: number;
  content: string;
  userIds: string[];
  remind: SaveReminderDTO;
}

export const FinishReviewSchema = Yup.object().shape({
  // status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  userIds: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  reminder: ReminderSchema,
});

export const castFinishReviewDTO = (schema: any): FinishReviewRequest => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
