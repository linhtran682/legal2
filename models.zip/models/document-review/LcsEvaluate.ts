import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";

export interface CreateRequestEvaluateBody {
  status: number;
  content: string;
  responseDate: string;
  userIds: string;
  remind?: SaveReminderDTO;
}

export const RequestEvaluateSchema = Yup.object().shape({
  // status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  responseDate: Yup.date().required(VALIDATION_MSG.REQUIRED_FIELD),
  userIds: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});

export interface CreateEvaluateBody {
  status: number;
  content: string;
  responseDate: string;
  userIds: string;
  remind?: SaveReminderDTO;
}

export const EvaluateSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  userIds: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});
export interface CreateFeedbackEvaluateBody {
  status: number;
  content: string;
  responseDate: string;
  userIds: string;
  remind?: SaveReminderDTO;
}

export const FeedbackEvaluateSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  userIds: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});

export const castRequestEvaluateDTO = (
  schema: any
): CreateRequestEvaluateBody => {
  return {
    ...schema,
    responseDate: schema?.responseDate?.toISOString?.(),
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
