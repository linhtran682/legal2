import { FieldValues } from "react-hook-form";
import { ReminderContent } from "../reminder_template/ReminderDTO";
import * as Yup from "yup";
import { ReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createRequestVendorMutationFn } from "@/apis/service/document-review/requestVendorReview";
import { BasedUser, BasedUserSchema } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestVendorFieldNames {
  STATUS = "status",
  DEADLINE = "timeVendorResponse",
  USERS = "userIds",
  REMIND = "remind",
}
export interface RequestVendorSchemaI extends FieldValues {
  status?: number;
  timeVendorResponse?: string;
  userIds?: BasedUser[];
  content?: string;
  remind?: SaveReminderDTO;
}

export const RequestVendorSchema = Yup.object().shape({
  // [RequestVendorFieldNames.STATUS]: Yup.number().required(
  //   VALIDATION_MSG.REQUIRED_FIELD
  // ),
  [RequestVendorFieldNames.DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestVendorFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestVendorFieldNames.REMIND]: ReminderSchema,
});

export interface CreateRequestVendorBody {
  documentReviewId?: number;
  data?: RequestVendorSchemaI;
}

export interface CreateRequestVendorOptions {
  config?: MutationConfig<typeof createRequestVendorMutationFn>;
}
