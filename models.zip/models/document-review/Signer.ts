import { VALIDATION_MSG } from "@/constants/message";
import { Department } from "../department/Department";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";
import * as Yup from "yup";

export interface SignerItem {
  departmentResponse: Department;
  userResponse: BasedUser;
  content: string;
  deadline: string;
  signer: BasedUser;
  status: number;
  createDate: string;
}

export interface TabSignerResponse {
  responses: SignerItem[];
}

export interface CreateRequestSignApproveBody {
  status: number;
  content: string;
  responseDate: string;
  userIds: string[];
  remind?: SaveReminderDTO;
}

export const RequestSignSchema = Yup.object().shape({
  // status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  responseDate: Yup.date().required(VALIDATION_MSG.REQUIRED_FIELD),
  userId: Yup.string().required(VALIDATION_MSG.SELECT),
  // userIds: Yup.array()
  //   .min(1, VALIDATION_MSG.SELECT)
  //   .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});
export const SignSchema = Yup.object().shape({
  status: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  userIds: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  remind: ReminderSchema,
});

export const castSigningDTO = (schema: any): CreateRequestSignApproveBody => {
  return {
    ...schema,
    responseDate: schema?.responseDate?.toISOString?.() ?? undefined,
    userIds: schema?.userId
      ? [schema?.userId]
      : schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
