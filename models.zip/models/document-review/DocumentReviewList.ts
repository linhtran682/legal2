import { CurrencyDTO } from "../currency/Currency";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import { ReminderInput } from "../reminder_template/ReminderDTO";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";

export const enum DocumentReviewTableFields {
  ID = "id",
  DOCUMENT_NAME = "documentName",
  STATUS = "status",
  ATTACHMENTS = "attachments",
  ATTACHMENT_TYPE = "attachmentType",
  SIGNERS = "signers",
  SIGNING_DATE = "signingDate",
  EFFECTIVE_DATE = "effectiveDate",
  EFFECTIVE_END_DATE = "effectiveEndDate",
  SOW_CONTRACT = "sowContract",
  CONTRACT_VALUE = "contractValue",
  SAMPLE = "sample",
  SAMPLE_CONTRACT_TYPE = "sampleContractType",
  LCS_STATUS = "lcsStatus",
  PIC = "pic",
  ACTION = "action",
}

export const ATTACHMENT_TYPES = [
  {
    value: 0,
    label: "Ringi",
  },
  {
    value: 1,
    label: "PR",
  },
  {
    value: 2,
    label: `DOCUMENT_REVIEW.labels.draftContract`,
  },
  {
    value: 3,
    label: `DOCUMENT_REVIEW.labels.debt`,
  },
  {
    value: 4,
    label: "Other",
  },
];

export const SAMPLE_CONTRACT_TYPES = [
  {
    value: 0,
    label: `DOCUMENT_REVIEW.labels.useBlockContract`,
  },
  {
    value: 1,
    label: `DOCUMENT_REVIEW.labels.useSignedContract`,
  },
];

export interface DocumentReviewItem {
  id: number;
  pic?: BasedUser;
  documentName?: string;
  attachmentType?: number;
  attachments: LegalAdviceAttachment[];
  status?: StatusDTO;
  confirmWithManagementLevelFlag?: number;
  vendorResponseDate?: string;
  repaymentDate?: string;
  signerList: BasedUser[];
  signingDate?: string;
  effectiveDate?: string;
  effectiveEndDate?: string;
  backdateApprovalEmailAttachmentType?: number;
  backdateApprovalEmailAttachmentFiles: LegalAdviceAttachment[];
  backdateApprovalEmailDebtDate?: string;
  backdateApprovalEmailDebtReason?: string;
  sowContract?: string;
  contractValue?: number;
  currency?: CurrencyDTO;
  sampleContractType?: number;
  sampleContractContent?: string;
  sampleContractAttachmentFiles: LegalAdviceAttachment[];
  desiredCondition?: string;
  problem?: string;
  opinion?: string;
  responseDeadlineType?: number;
  responseDate?: string;
  urgentResponseReason?: string;
  receiverUsers: BasedUser[];
  relateUsers: BasedUser[];
  isDraft?: boolean;
  bookingFlag: number;
  completeLCSFlag: number;
  completeReviewFlag: number;
  approvedFlag: number;
  checkDivisionFlag?: number;
  checkDeptHeadFlag?: number;
  remind?: ReminderInput;
  createdDate?: string;
  // documentChild: DetailRequestReviewDocumentResponse[];
}

export interface GetDocumentReviewListParams {
  picIds?: string;
  documentName?: string;
  statusList?: string;
  lcsStatus?: string;
  vendorResponseDateFrom?: string;
  vendorResponseDateTo?: string;
  responseDateFrom?: string;
  responseDateTo?: string;
  effectiveDateFrom?: string;
  effectiveDateTo?: string;
  effectiveEndDateFrom?: string;
  effectiveEndDateTo?: string;
  signingDateFrom?: string;
  signingDateTo?: string;
  receiverUserIds?: string;
  signerList?: string;
  sortBy: string;
  orderBy: string;
  page: number;
  size: number;
  tab?: number;
  isEnglish?: boolean;
  isPanelSearch?: boolean;

  departmentIds?: string;
  createFrom?: string;
  createTo?: string;
}

export interface DocumentReviewListResponse {
  total: number;
  data: DocumentReviewItem[];
}

export enum DocumentReviewActionBtnKey {
  REQUEST_EVALUATE = "requestEvaluate",
  REQUEST_SIGN = "requestSign",
  FEEDBACK_LC = "feedbackLC",
  FINISH = "finish",
  SIGN_AND_APPROVE = "signAndApprove",
  CONFIRM = "confirm",
  ASSIGNMENT = "assignment",
  INFORMATION_REQUEST = "informationRequest",
  FEEDBACK_EVALUATE = "feedbackEvaluate",
  EVALUATE = "evaluate",
  TIME_EXTENSION_REQUEST = "timeExtensionRequest",
  TIME_EXTENSION = "timeExtension",
  RECALL = "recall",
  SEND_MAIL = "sendMail",
  FORWARD = "forward",
  REQUEST_MEETING = "requestMeeting",
  FEEDBACK = "feedback",

  REQUEST_VENDOR = "requestVendor",
  FEEDBACK_INSPECTION = "feedbackInspection",
  INSPECTION = "inspection",

  RECHECK = "recheck",
  SHARE = "share",
}
