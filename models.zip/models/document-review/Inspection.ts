import { VALIDATION_MSG } from "@/constants/message";
import { Department } from "../department/Department";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderSchema,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
import { BasedUser } from "../user/User";
import * as Yup from "yup";

export interface DocumentReviewInspectionItem {
  id: number;
  user: BasedUser;
  receivers?: BasedUser;
  department: Department;
  content: string;
  createAt: string;
  type: number;
  attachments: LegalAdviceAttachment[];
  finishFlag: number;
  editAvailable: boolean;
  inspectedBySupervisor: boolean;
}

export interface DocumentReviewInspectionListResponse {
  responses: DocumentReviewInspectionItem[];
}

export interface CreateInspectionRequest {
  type: number;
  userIds: string[];
  status?: number;
  content?: string;
  attachmentIds?: number[];
  remind?: SaveReminderDTO;
  finishFlag: number;
}
export interface CreateInspectionFeedbackRequest {
  type: number;
  userIds: string[];
  status?: number;
  deadlineNew?: string;
  reason?: string;
  // attachmentIds?: number[];
  remind?: SaveReminderDTO;
  // finishFlag: number;
}

export const castInspectionDTO = (schema: any): CreateInspectionRequest => {
  return {
    content: schema.content,
    status: +schema.status,
    type: schema.type,
    finishFlag: schema.finish ? 1 : 0,
    attachmentIds: schema?.attachmentIds ?? [],
    userIds: schema?.userIds?.map((user: any) => user?.id),
    remind: schema?.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
export const castInspectionFeedbackDTO = (
  schema: any
): CreateInspectionFeedbackRequest => {
  return {
    reason: schema.reason,
    status: +schema.status,
    type: schema.type,
    // attachmentIds: schema?.attachmentIds ?? [],
    deadlineNew: schema?.deadlineNew?.toISOString?.(),
    userIds: schema?.userIds?.map((user: any) => user?.id),
    remind: schema?.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export const TypeAdvisorLegal = {
  toPic: 0,
  toUser: 1,
  toSupervisor: 2,
};

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export const InspectionOptions: RadioItem[] = [
  {
    label: "Gửi tới người yêu cầu kiểm tra",
    value: TypeAdvisorLegal.toPic,
  },
  {
    label: "Gửi tới giám sát",
    value: TypeAdvisorLegal.toSupervisor,
  },
];

export const SupervisorInspectionOptions: RadioItem[] = [
  {
    label: "Gửi tới người yêu cầu kiểm tra",
    value: TypeAdvisorLegal.toPic,
  },
  {
    label: "Gửi tới người kiểm tra",
    value: TypeAdvisorLegal.toUser,
  },
];

export enum InspectionStatusList {
  REVIEW = "Kiểm tra",
  SENT_TO_SUPERVISOR = "Yêu cầu giám sát kiểm tra",
  // SENT_TO_SUPERVISOR = ""
  DONE_REVIEW = "Đã kiểm tra",
}
export enum SupervisorInspectionStatusList {
  SUPERVISOR_REVIEWED = "Giám sát đã kiểm tra",
  DONE_REVIEW = "Đã kiểm tra",
}

export const enum InspectionFieldNames {
  CONTENT = "content",
  STATUS = "status",
  DEADLINE_NEW = "deadlineNew",
  REASON = "reason",
  USERS = "userIds",
  ATTACHMENTS = "attachments",
  FINISH = "finish",
  TYPE = "type",
  REMIND = "remind",
}

export const InspectionSchema = Yup.object().shape({
  [InspectionFieldNames.CONTENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  // [InspectionFieldNames.STATUS]: Yup.number().required(VALIDATION_MSG.SELECT),
  [InspectionFieldNames.USERS]: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  [InspectionFieldNames.REMIND]: ReminderSchema,
});
export const InspectionFeedbackSchema = Yup.object().shape({
  [InspectionFieldNames.REASON]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [InspectionFieldNames.DEADLINE_NEW]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  // [InspectionFieldNames.STATUS]: Yup.number().required(VALIDATION_MSG.SELECT),
  [InspectionFieldNames.USERS]: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
  [InspectionFieldNames.REMIND]: ReminderSchema,
});
