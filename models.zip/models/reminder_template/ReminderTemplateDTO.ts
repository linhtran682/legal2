import { RemindReceiverTypeI } from "@/constants/general";
import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";
import { BasedUser, BasedUserSchema } from "../user/User";
import { Department, departmentSchema } from "../department/Department";
import { PositionType } from "./ReminderDTO";
// import { PositionType } from "./ReminderDTO";

export interface ReminderTemplateContent {
  remindReceiverType?: number;
  remindValueType?: number;
  timeStatus?: number;
  vendorResponseStatus?: number;
  time?: number;
  timeUnit?: number;
  legalStatus?: number;
  // basicPosition?:PositionType
}

export const enum ReminderTemplateContentFieldNames {
  REMIND_RECEIVER_TYPE = "remindReceiverType",
  REMIND_VALUE_TYPE = "remindValueType",
  TIME_STATUS = "timeStatus",
  VENDOR_RESPONSE_STATUS = "vendorResponseStatus",
  TIME = "time",
  TIME_TYPE = "timeUnit",
  LEGAL_STATUS = "legalStatus",
}
export const PositionTypeSchema =  Yup.object().shape({
  id: Yup.string().optional(),
  name: Yup.string().optional(),
  nameEnglish: Yup.string().optional()
})
export const ReminderTemplateContentSchema = Yup.object().shape({
  remindReceiverType: Yup.number()
    .integer()
    .min(1)
    .max(8)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  remindValueType: Yup.number()
    .integer()
    .min(0)
    .max(2)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  timeStatus: Yup.number()
    .integer()
    .when(ReminderTemplateContentFieldNames.REMIND_VALUE_TYPE, {
      is: 1,
      then: (schema) =>
        schema.min(0).max(2).required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.nullable().optional(),
    }),
  vendorResponseStatus: Yup.number()
    .integer()
    .when(ReminderTemplateContentFieldNames.REMIND_VALUE_TYPE, {
      is: 1,
      then: (schema) =>
        schema.min(1).max(6).required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.nullable().optional(),
    }),
  time: Yup.number()
    .typeError(VALIDATION_MSG.MUST_BE_A_NUMBER)
    .integer()
    .when(ReminderTemplateContentFieldNames.REMIND_VALUE_TYPE, {
      is: 1,
      then: (schema) =>
        schema
          .min(0, VALIDATION_MSG.NOT_NEGATIVE)
          .required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.nullable().optional(),
    }),
  timeUnit: Yup.number()
    .integer()
    .when(ReminderTemplateContentFieldNames.REMIND_VALUE_TYPE, {
      is: 1,
      then: (schema) =>
        schema.min(1).max(3).required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.nullable().optional(),
    }),
  legalStatus: Yup.number()
    .integer()
    .when(ReminderTemplateContentFieldNames.REMIND_VALUE_TYPE, {
      is: 2,
      then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
      otherwise: (schema) => schema.nullable().optional(),
    }),
});

export interface ReminderTemplateContentSchemaI {
  timeStatus?: number | undefined;
  vendorResponseStatus?: number | undefined;
  time?: number | undefined;
  timeUnit?: number | undefined;
  legalStatus?: number | undefined;
  remindReceiverType: number;
  remindValueType: number;
}

export interface SaveReminderTemplateDTO {
  title?: string;
  module?: number;
  description?: string;
  remindContents?: ReminderTemplateContent[];
  relatedUsers?: string[];
  receivingDepartment?: string[];
  receivedTitle?: string[];
}

export interface GetReminderTemplateDTO {
  title?: string;
  module?: number;
  description?: string;
  remindContents?: Record<RemindReceiverTypeI, ReminderTemplateContent[]>;
  relatedUsers?: BasedUser[];
  receivingDepartment?: Department[];
  receivedTitle?: PositionType[];
}

export const enum SaveReminderTemplateDTOFieldNames {
  TITLE = "title",
  MODULE = "module",
  DESCRIPTION = "description",
  REMIND_CONTENTS = "remindContents",
  RELATED_USERS = "relatedUsers",
  RECEIVING_DEPARTMENT = "receivingDepartment",
  RECEIVED_TITLE = "receivedTitle",
}

export const SaveReminderTemplateSchema = Yup.object()
  .shape({
    title: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
    module: Yup.number()
      .integer()
      .min(1)
      .max(7)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    description: Yup.string().optional(),
    remindContents: Yup.array()
      .of(Yup.array().of(ReminderTemplateContentSchema).required())
      .required()
      .length(8),
    relatedUsers: Yup.array().of(BasedUserSchema).optional(),
    receivingDepartment: Yup.array().of(departmentSchema).optional(),
    // receivedTitle: Yup.array()
    //   .of(Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD))
    //   .optional(),
    receivedTitle: Yup.string().optional(),
  })
  .required();

export interface SaveReminderTemplateSchemaI {
  title: string;
  module: number;
  description?: string | undefined;
  remindContents: ReminderTemplateContentSchemaI[][];
  relatedUsers?: BasedUser[];
  receivingDepartment?: Department[];
  receivedTitle?: string[];
}

export const castReminderTemplateContentToSchema = (
  reminderContentItem: ReminderTemplateContent
): ReminderTemplateContentSchemaI => ({
  ...reminderContentItem,
  remindReceiverType: reminderContentItem.remindReceiverType ?? -1,
  remindValueType: reminderContentItem.remindValueType ?? -1,
});

export const castReminderTemplateContentMapToMapSchema = (
  reminderContent:
    | Record<RemindReceiverTypeI, ReminderTemplateContent[]>
    | undefined
): ReminderTemplateContent[][] => {
  return [
    [
      ...(reminderContent ? reminderContent[1] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[2] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[3] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[4] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[5] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[6] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[7] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[8] ?? [] : []).map((item) =>
        castReminderTemplateContentToSchema(item)
      ),
    ],
  ];
};
