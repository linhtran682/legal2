import { VALIDATION_MSG } from "@/constants/message";
import {
  ReminderTemplateContent,
  ReminderTemplateContentSchemaI,
} from "../reminder_template/ReminderTemplateDTO";
import * as Yup from "yup";
import { RemindReceiverTypeI } from "@/constants/general";
import { BasedUser, BasedUserSchema } from "../user/User";
import {
  Department,
  DepartmentSchema,
  departmentSchema,
} from "../department/Department";

export interface ReminderInput {
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: BasedUser[];
  receivingDepartment?: Department[];
  receivedTitle?: PositionType[];
  remindContents?: Record<RemindReceiverTypeI, ReminderContent[]>;
}

export interface ReminderContent extends ReminderTemplateContent {
  position?: number;
  isSend?: boolean;
}

export const enum ReminderContentFieldNames {
  REMIND_RECEIVER_TYPE = "remindReceiverType",
  REMIND_VALUE_TYPE = "remindValueType",
  TIME_STATUS = "timeStatus",
  VENDOR_RESPONSE_STATUS = "vendorResponseStatus",
  TIME = "time",
  TIME_TYPE = "timeUnit",
  LEGAL_STATUS = "legalStatus",
  POSITION = "position",
  IS_SEND = "isSend",
}

export const ReminderContentSchema = Yup.object()
  .shape({
    remindReceiverType: Yup.number()
      .integer()
      .min(1)
      .max(8)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    remindValueType: Yup.number()
      .integer()
      .min(0)
      .max(2)
      .required(VALIDATION_MSG.REQUIRED_FIELD),
    timeStatus: Yup.number()
      .integer()
      .when(ReminderContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema.min(0).max(2).required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    vendorResponseStatus: Yup.number()
      .integer()
      .when(ReminderContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema.min(1).max(6).required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    time: Yup.number()
      .typeError(VALIDATION_MSG.MUST_BE_A_NUMBER)
      .integer()
      .when(ReminderContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema
            .min(0, VALIDATION_MSG.NOT_NEGATIVE)
            .required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    timeUnit: Yup.number()
      .integer()
      .when(ReminderContentFieldNames.REMIND_VALUE_TYPE, {
        is: 1,
        then: (schema) =>
          schema.min(1).max(3).required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    legalStatus: Yup.number()
      .integer()
      .when(ReminderContentFieldNames.REMIND_VALUE_TYPE, {
        is: 2,
        then: (schema) => schema.required(VALIDATION_MSG.REQUIRED_FIELD),
        otherwise: (schema) => schema.nullable().optional(),
      }),
    position: Yup.number().optional(),
    isSend: Yup.boolean().optional(),
  })
  .required();

export interface ReminderContentSchemaI extends ReminderTemplateContentSchemaI {
  position?: number | undefined;
  isSend?: boolean | undefined;
}

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const ReminderSchema = Yup.object()
  .shape({
    id: Yup.number().optional(),
    title: Yup.string().optional(),
    module: Yup.number().integer().optional(),
    description: Yup.string().optional().nullable(),
    remindContents: Yup.array()
      .of(Yup.array().of(ReminderContentSchema).required())
      .length(8)
      .optional(),
    relatedUsers: Yup.array().of(BasedUserSchema),
    receivingDepartment: Yup.array().of(departmentSchema),
    receivedTitle: Yup.string().optional(),

  })
  .optional();

export interface ReminderSchemaI {
  id?: number;
  remindId?: number;
  title?: string;
  module?: number;
  description?: string | null | undefined;
  remindContents?: ReminderContentSchemaI[][];
  relatedUsers?: BasedUser[] | undefined;
  receivingDepartment?: DepartmentSchema[] | undefined;
  receivedTitle?:  undefined | string;
  receivedTitleCopy?: PositionType[] | undefined
}

export const enum ReminderFieldNames {
  ID = "id",
  TITLE = "title",
  MODULE = "module",
  DESCRIPTION = "description",
  REMIND_CONTENTS = "remindContents",
  RELATED_USERS = "relatedUsers",
  RECEIVING_DEPARTMENT = "receivingDepartment",
  RECEIVED_TITLE = "receivedTitle",
}

export const castReminderContentToSchema = (
  reminderContentItem: ReminderContent
): ReminderContentSchemaI => ({
  ...reminderContentItem,
  remindReceiverType: reminderContentItem.remindReceiverType ?? -1,
  remindValueType: reminderContentItem.remindValueType ?? -1,
  isSend: true,
  position: -1,
});

export const castReminderContentMapToMapSchema = (
  reminderContent: Record<RemindReceiverTypeI, ReminderContent[]> | undefined
): ReminderContentSchemaI[][] => {
  return [
    [
      ...(reminderContent ? reminderContent[1] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[2] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[3] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[4] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[5] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[6] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[7] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
    [
      ...(reminderContent ? reminderContent[8] ?? [] : []).map((item) =>
        castReminderContentToSchema(item)
      ),
    ],
  ];
};

export const castReminderInputToReminderSchema = (
  reminder: ReminderInput
): ReminderSchemaI => {
  return {
    ...reminder,
    remindContents: castReminderContentMapToMapSchema(reminder.remindContents),
    id: -1,
    module: reminder.module ?? -1,
    title: reminder.title ?? "",
    receivedTitle:  reminder.receivedTitle && reminder.receivedTitle?.length > 0 ? reminder.receivedTitle[0].id : undefined,
    receivingDepartment: reminder.receivingDepartment ?? undefined,
    relatedUsers: reminder.relatedUsers ?? undefined,
    receivedTitleCopy: reminder.receivedTitle && reminder.receivedTitle
  };
};

export const castReminderSchemaToSaveReminderDTO = (
  reminder: ReminderSchemaI
): SaveReminderDTO | undefined => {
  if (!reminder.id) {
    return undefined;
  }
  if(reminder.id === undefined){
    return undefined
  }
  return {
    ...reminder,
    remindContents: (reminder.remindContents || []).flat(),
    relatedUsers: (reminder.relatedUsers ?? []).map((user) => user.id),
    receivingDepartment: (reminder.receivingDepartment ?? []).map(
      (department) => department.id
    ),
    description: reminder.description ?? undefined,
    receivedTitle: reminder.receivedTitle? [reminder.receivedTitle]: []
  };
};

interface DepartmentCreate {
  id: string;
  name: string;
  nameEnglish: string;
}

interface UserCreate {
  id: string;
  name: string;
  nameEnglish: string;
  email: string;
  department: DepartmentCreate;
}

export interface RemindPopupDTO {
  id: number;
  type: number;
  userCreate: UserCreate;
  departmentCreate: DepartmentCreate;
  legalDocumentId: number;
  legalDocumentName: string;
  documentId: number;
  documentName: string;
  otherDocumentId: string;
  displayTime: string;
  deadline: string;
  module: number;
  readNotification: boolean;
  stockId: number;
}

export interface RemindPopupResponse {
  reminds: RemindPopupDTO[];
}
export interface RemindUnreadResponse {
  totalUnread: number;
  unreadPerModule: Record<string, number>;
}

export interface PositionType {
  id: string;
  name?: string;
  nameEnglish?: string;
}

