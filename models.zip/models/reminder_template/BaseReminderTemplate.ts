export interface BasedReminderTemplate {
  id: number;
  module: number;
  title: string;
  registerUserName: string;
  registerTime: string;
}

export const enum BasedReminderTemplateFieldNames {
  ID = "id",
  MODULE = "module",
  TITLE = "title",
  REGISTER_USER_NAME = "registerUserName",
  REGISTER_TIME = "registerTime",
}

export interface GetBasedReminderTemplatesParams {
  title?: string;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export interface GetBasedReminderTemplatesResponse {
  total: number;
  remindBaseData: BasedReminderTemplate[];
}
