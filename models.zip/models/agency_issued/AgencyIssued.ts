import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export interface AgencyIssuedDTO {
  id: number;
  name: string;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
}

export const enum AgencyIssuedFieldNames {
  ID = "id",
  NAME = "name",
  DESCRIPTION = "description",
  CREATED_BY = "createdBy",
  CREATED_AT = "createdAt",
}

export interface GetAgencyIssuedsParams {
  name?: string;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export interface GetAgencyIssuedsResponse {
  total: number;
  agencyIssuedResponses: AgencyIssuedDTO[];
}

export interface SaveAgencyIssuedDTO {
  name?: string;
  description?: string;
}

export const enum SaveAgencyIssuedRequestFieldNames {
  NAME = "name",
  DESCRIPTION = "description",
}

export const SaveAgencyIssuedRequestSchema = Yup.object().shape({
  name: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  description: Yup.string().optional(),
});

export interface SaveAgencyIssuedRequestSchemaI {
  description?: string | undefined;
  name: string;
}
