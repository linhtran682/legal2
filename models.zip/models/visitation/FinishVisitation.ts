import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createFinishVisitationMutationFn } from "@/apis/service/visitation/finishVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FinishFieldNames {
  CONTENT = "content",
  USER_IDS = "userIds",
  REMIND = "remind",
}

export interface FinishSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const FinishSchemaVisitation = Yup.object().shape({
  [FinishFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [FinishFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FinishFieldNames.REMIND]: ReminderSchema,
});

export interface CreateFinishVisitationBody {
  visitationId?: number;
  data?: FinishSchemaI;
}

export interface CreateFinishVisitationOptions {
  config?: MutationConfig<typeof createFinishVisitationMutationFn>;
}
