import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createRequestSignVisitationMutationFn } from "@/apis/service/visitation/requestSignVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestSignFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  RECEIVER_USERS = "receiverUsers",
  REMIND = "remind",
}

export interface RequestSignSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  receiverUsers?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const RequestSignSchemaVisitation = Yup.object().shape({
  [RequestSignFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [RequestSignFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [RequestSignFieldNames.RECEIVER_USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [RequestSignFieldNames.REMIND]: ReminderSchema,
});

export interface CreateRequestSignVisitationBody {
  visitationId?: number;
  data?: RequestSignSchemaI;
}

export interface CreateRequestSignVisitationOptions {
  config?: MutationConfig<typeof createRequestSignVisitationMutationFn>;
}
