import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createReceptionResultVisitationMutationFn,
  deleteReceptionResultVisitationMutationFn,
  getReceptionResultVisitationListMutationFn,
  updateReceptionResultVisitationMutationFn,
} from "@/apis/service/visitation/receptionResultVisitation";
import { VALIDATION_MSG } from "@/constants/message";

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

export type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ReceptionResultVisitationFieldNames {
  CONTENT = "content",
  USER_IDS = "userIds",
  REMIND = "remind",
}
export interface ReceptionResultVisitationSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const ReceptionResultSchemaVisitation = Yup.object().shape({
  [ReceptionResultVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [ReceptionResultVisitationFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ReceptionResultVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateReceptionResultVisitationBody {
  visitationId?: number;
  data?: ReceptionResultVisitationSchemaI;
}

export interface CreateReceptionResultVisitationOptions {
  config?: MutationConfig<typeof createReceptionResultVisitationMutationFn>;
}

export interface UpdateReceptionResultVisitationBody {
  visitationId?: number;
  receptionResultId?: number;
  data?: ReceptionResultVisitationSchemaI;
}

export interface UpdateReceptionResultVisitationOptions {
  config?: MutationConfig<typeof updateReceptionResultVisitationMutationFn>;
}

export interface ReceptionResultVisitationDTO {
  id: number;
  createBy: TypeUserDTO;
  content?: string;
  userIds: TypeUserDTO[];
  createTime?: Date | string;
}

export interface ResponsesReceptionResultVisitationListDTO {
  data: ReceptionResultVisitationDTO[];
  total?: number;
}

export type ReceptionResultVisitationListQueryFnTypeList =
  typeof getReceptionResultVisitationListMutationFn;

export type GetReceptionResultVisitationListOptions = {
  config?: QueryConfig<ReceptionResultVisitationListQueryFnTypeList>;
  request: { visitationId?: number };
};

export type DeleteReceptionResultOptions = {
  config?: MutationConfig<typeof deleteReceptionResultVisitationMutationFn>;
};
