import { VALIDATION_MSG } from "@/constants/message";
import {
  ReminderInput,
  ReminderSchema,
  ReminderSchemaI,
  SaveReminderDTO,
} from "../reminder_template/ReminderDTO";
// import { VisitationAttachment } from "./VisitationList";
import * as Yup from "yup";
import { MutationConfig, QueryConfig } from "@/apis";

import { Position, UserProfileDTO } from "../user/User";
import { Department, DepartmentSchema } from "../department/Department";
import { StatusDTO } from "../status/Status";
import { GenericSearchPanelProps } from "@/components/commons/search_panel/GenericSearchPanel";
import {
  LegalAdviceStatusContent,
  LegalAdviceStatusKey,
} from "@/constants/general";
import { formatDate } from "@/utils";
import { getListVisitationQueryFn, getVisitationQueryFn, createVisitationMutationFn, updateVisitationMutationFn, updateBookMeetingVisitationMutationFn, getAllHierarchyById, getStatusVisitationQueryFn } from "@/apis/service/visitation/visitationApi";
import { VISITATION_ROOT_PATH } from "@/constants/paths";
import { InformationRequestDetail } from "../metadata/Metadata";
export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}

export const enum ApproverVisitationStatus {
  NEW = 0,
  SIGNED = 1,
  REJECT = 2,
}

export interface VisitationTabsRef {
  scrollToTab: (tab: number) => void;
}

export interface BasedUser {
  id: string;
  name?: string | undefined;
  nameEnglish?: string | undefined;
  email?: string | undefined;
  departmentName?: string | undefined;
  department: DepartmentSchema;
  basicPosition?: Position;
  position?: Position;
  positionResponse?: Position;
  departmentResponse?: DepartmentSchema;
}
export const enum VisitationDetailFields {
  ID = "id",
  IS_DRAFT = "isDraft",
  NAME = "name",
  // CONFIRM_STATUS = "confirmStatus",
  VISITATION_STATUS = "status",
  SIGN_STATUS = "signStatus",
  RECEPTION_ID = "receptionId",
  RECEPTION_IDS = "receptionIds",
  RECEPTION_NAME = "receptionName",
  DEPARTMENT = "department",
  POSITION = "position",
  GROUP = "group",
  AREA = "area",
  SUPERVISOR_ID = "supervisorId",
  ATTACHMENTS = "attachmentIds",
  FIELD = "field",
  ORGANIZATION_NAME = "organizationName",
  RECEPTION_TIME = "receptionTime",
  RECEPTION_TIME_FROM = "receptionTimeFrom",
  RECEPTION_TIME_TO = "receptionTimeTo",
  PURPOSE = "purpose",
  REQUEST_SUMARY = "requestSummary",
  DEPARTMENT_FEEDBACK = "departmentFeedback",
  PARTICIPANTS = "participants",
  CHECK_DIVISION_FLAG = "checkDivisionFlag",
  CHECK_DEPT_HEAD_FLAG = "checkDeptHeadFlag",
  RECEIVED_USERS = "receiverUsers",
  ASSIGNMENT_USERS = "assignmentUsers",
  CONFIRM_DEADLINE = "confirmDeadline",
  CONFIRM_DEADLINE_FROM = "confirmDeadlineFrom",
  CONFIRM_DEADLINE_TO = "confirmDeadlineTo",
  SHARE_INFORMATION_DEPARTMENT = "shareInformationDepartments",
  SHARE_INFORMATION_DEADLINE = "shareInformationDeadline",
  STAFF_LC_USERS = "staffLCUsers",
  RESPONSE_LC_DEADLINE = "responseLCDeadline",
  RESPONSE_LC_DEADLINE_FROM = "responseLCDeadlineFrom",
  RESPONSE_LC_DEADLINE_TO = "responseLCDeadlineTo",
  REMIND = "remind",
  ACTION_AVAILABLE_AND_ROLE = "actionAvailableAndRole",
  CREATED_AT = "createdAt",
  CREATED_BY = "createdBy",
  ACTION = "action",
}

export type TypeVisitationForm = {
  [VisitationDetailFields.IS_DRAFT]?: boolean;
  [VisitationDetailFields.NAME]?: string;
  [VisitationDetailFields.VISITATION_STATUS]?: number;
  [VisitationDetailFields.RECEPTION_ID]?: string;
  [VisitationDetailFields.RECEPTION_NAME]?: string;
  [VisitationDetailFields.DEPARTMENT]?: string;
  [VisitationDetailFields.POSITION]?: string;
  [VisitationDetailFields.GROUP]?: string;
  [VisitationDetailFields.SUPERVISOR_ID]?: string;
  [VisitationDetailFields.ATTACHMENTS]?: number[];
  [VisitationDetailFields.FIELD]?: string;
  [VisitationDetailFields.ORGANIZATION_NAME]?: string;
  [VisitationDetailFields.RECEPTION_TIME_FROM]?: string;
  [VisitationDetailFields.RECEPTION_TIME_TO]?: string;
  [VisitationDetailFields.PURPOSE]?: string;
  [VisitationDetailFields.REQUEST_SUMARY]?: string;
  [VisitationDetailFields.DEPARTMENT_FEEDBACK]?: string;
  [VisitationDetailFields.PARTICIPANTS]?: string;
  [VisitationDetailFields.CHECK_DIVISION_FLAG]?: boolean;
  [VisitationDetailFields.CHECK_DEPT_HEAD_FLAG]?: boolean;
  [VisitationDetailFields.RECEIVED_USERS]?: string[];
  [VisitationDetailFields.CONFIRM_DEADLINE]?: Date;
  [VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT]?: string[];
  [VisitationDetailFields.SHARE_INFORMATION_DEADLINE]?: string;
  [VisitationDetailFields.STAFF_LC_USERS]?: string[];
  [VisitationDetailFields.RESPONSE_LC_DEADLINE]?: Date;
  [VisitationDetailFields.REMIND]?: ReminderSchemaI;
};

export interface VisitationBodySend {
visitationId?: number; 
[VisitationDetailFields.IS_DRAFT]: boolean;
[VisitationDetailFields.NAME]: string;
[VisitationDetailFields.RECEPTION_ID]: string;
[VisitationDetailFields.RECEPTION_NAME]: string;
[VisitationDetailFields.DEPARTMENT]: string;
[VisitationDetailFields.POSITION]: string;
[VisitationDetailFields.GROUP]: string;
[VisitationDetailFields.SUPERVISOR_ID]: string;
[VisitationDetailFields.ATTACHMENTS]: number[];
[VisitationDetailFields.FIELD]: string;
[VisitationDetailFields.ORGANIZATION_NAME]: string;
[VisitationDetailFields.RECEPTION_TIME_FROM]: string;
[VisitationDetailFields.RECEPTION_TIME_TO]: string;
[VisitationDetailFields.PURPOSE]: string;
[VisitationDetailFields.REQUEST_SUMARY]: string;
[VisitationDetailFields.DEPARTMENT_FEEDBACK]: string;
[VisitationDetailFields.PARTICIPANTS]: string;
[VisitationDetailFields.CHECK_DIVISION_FLAG]: boolean;
[VisitationDetailFields.CHECK_DEPT_HEAD_FLAG]: boolean;
[VisitationDetailFields.RECEIVED_USERS]: string[];
[VisitationDetailFields.CONFIRM_DEADLINE]: string;
[VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT]: string[];
[VisitationDetailFields.SHARE_INFORMATION_DEADLINE]: string;
[VisitationDetailFields.STAFF_LC_USERS]: string[];
[VisitationDetailFields.RESPONSE_LC_DEADLINE]: string;
[VisitationDetailFields.REMIND]: SaveReminderDTO;
sharePointAttachmentFiles?: number[];
}

export interface VisitationAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  toBeSigned?: boolean;
  uploadUser: BasedUser;
}

export interface VisitationBodyReceive {
  id: number;
  name: string;
  status: StatusDTO;
  receptionUser: UserProfileDTO;
  department: string;
  position: string;
  group: string;
  supervisorUser: UserProfileDTO;
  attachmentFiles: VisitationAttachment[];
  field: string;
  organizationName: string;
  receptionTimeFrom: string;
  receptionTimeTo: string;
  purpose: string;
  requestSummary: string;
  departmentFeedback: string;
  participants: string;
  checkDivisionFlag?: boolean;
  checkDeptHeadFlag?: boolean;
  isDraft?: boolean;
  totalBooking?: number;
  isBookingFlag?: boolean;
  isDeptHeadConfirmFlag?: boolean;
  isDivisionHeadConfirmFlag?: boolean;
  isConfirmAll?: boolean;
  totalConfirm?: number;
  totalUserConfirm?: number;
  isLCEvaluateFlag?: boolean;
  isFinishSignFlag?: boolean;
  receiverUsers?: UserProfileDTO[];
  assignmentUsers?: UserProfileDTO[];
  confirmDeadline?: string;
  shareInformationUsers?: UserProfileDTO[];
  shareInformationDeadline?: string;
  shareInformationDepartments?: Department[];
  staffLCUsers?: UserProfileDTO[];
  responseLCDeadline?: string;
  remind?: ReminderInput;
  sharePointAttachmentFiles?: SharePointAttachment[];
  actionAvailableAndRole: {
    roles: number[];
  };
  createdAt: string;
  createdBy?: BasedUser;
}

export const SaveVisitationSchema = Yup.object().shape({
  [VisitationDetailFields.ATTACHMENTS]: Yup.mixed().required(VALIDATION_MSG.SELECT),
  [VisitationDetailFields.NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.VISITATION_STATUS]: Yup.number().optional(),
  hasDepartmentHead: Yup.boolean().optional(),
  [VisitationDetailFields.RECEPTION_NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.DEPARTMENT]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.POSITION]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.SUPERVISOR_ID]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.FIELD]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.ORGANIZATION_NAME]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.RECEPTION_TIME_FROM]: Yup.date().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.RECEPTION_TIME_TO]: Yup.date().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ).min(
    Yup.ref(VisitationDetailFields.RECEPTION_TIME_FROM),
    VALIDATION_MSG.END_DATE_GREATER_THAN_OR_EQUAL_START_DATE),
  [VisitationDetailFields.PURPOSE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.REQUEST_SUMARY]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.DEPARTMENT_FEEDBACK]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.PARTICIPANTS]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  checkSentTo: Yup.string().when("hasDepartmentHead", {
    is: (val?: boolean) => {
      return !!val
    },
    then: () => Yup.string().required(
      VALIDATION_MSG.REQUIRED_FIELD
    ),
    otherwise: () => Yup.string().optional(),
  }),
  [VisitationDetailFields.CONFIRM_DEADLINE]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [VisitationDetailFields.RECEIVED_USERS]: Yup.array().when("hasDepartmentHead", {
    is: (val?: boolean) => {
      return !val
    },
    then: () => Yup.array().min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
    otherwise: () => Yup.array().optional(),
  }),
  [VisitationDetailFields.RESPONSE_LC_DEADLINE]: Yup.string().when(VisitationDetailFields.STAFF_LC_USERS, {
    is: (val: string) => {
      return val?.length > 0
    },
    then: () => Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
    otherwise: () => Yup.string().nullable().optional(),
  }),

  [VisitationDetailFields.STAFF_LC_USERS]: Yup.string().optional(),

  [VisitationDetailFields.SHARE_INFORMATION_DEADLINE]: Yup.string().when(VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT, {
    is: (val: string[]) => {
      return val?.length > 0
    },
    then: () => Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
    otherwise: (schema: any) => schema.optional().nullable(),
  }),
  [VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT]: Yup.array().when(VisitationDetailFields.SHARE_INFORMATION_DEADLINE, {
    is: (val: string) => {
      return val?.length > 0
    },
    then: () => Yup.array().min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
    otherwise: () => Yup.array().optional(),
  }),
  
  [VisitationDetailFields.REMIND]: ReminderSchema,
}, [
  [VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT, VisitationDetailFields.SHARE_INFORMATION_DEADLINE]
]);
enum SearchPanelQueries {
  GET_HIERARCHY = "visitation/get-hierarchy",
  SEARCH_DOCUMENT = "visitation/search_document",
  SEARCH_KEY = "visitationName",
}

export const visitationSearchPanelConfig: GenericSearchPanelProps<any> =
  {
    completeStatusName: LegalAdviceStatusContent.get(
      LegalAdviceStatusKey.DONE
    )!,
    getHierarchyFn: (id) => getAllHierarchyById({ id }),
    getItemKey: (item) => item?.id,
    getChildKey: (child) => child?.id,
    getSearchResultFn: getListVisitationQueryFn,
    hierarchyQueryKey: SearchPanelQueries.GET_HIERARCHY,
    searchQueryKey: SearchPanelQueries.SEARCH_DOCUMENT,
    searchKey: SearchPanelQueries.SEARCH_KEY,
    getItemName: (item) => item?.name,
    getCreator: (item) => item?.createdBy,
    getParentTimeLabel: (item) =>
      item?.createdAt
        ? formatDate(item?.createdAt, "dd/MM/yyyy HH:mm")
        : "",
    getParentUsersList: (item) => item?.receiverUsers ?? [],
    getParentStatus: (item) => {
      // kiểm tra role là người tạo hoặc người xác nhận
      return item?.status?.name ?? ""
    },
    getChildStatus: (item) => {
      // kiểm tra role là người tạo hoặc người xác nhận
      return item?.status?.name ?? ""
    },
    getChildTimeLabel: (child) =>
      child?.createdAt
        ? formatDate(child?.createdAt, "dd/MM/yyyy HH:mm")
        : "",
    getChildUsersList: (child) => child?.receiverUsers,
    getChildren: (item) =>
      item?.children ?? item?.child ?? [],
    getItemLink: (item) =>
      `/${VISITATION_ROOT_PATH}/update/${
        item?.id
      }`,
  };

//api

export type VisitationParams = {
  id?: number;
};

export type QueryVisitationFnType = typeof getVisitationQueryFn;

export type GetVisitationOptions = {
  config?: QueryConfig<QueryVisitationFnType>;
  request: VisitationParams;
};

export interface CreateVisitationOptions {
  config?: MutationConfig<typeof createVisitationMutationFn>;
}

export type UpdateVisitationRequest = {
  id?: number;
  request?: VisitationBodySend;
};

export type UpdateVisitationOptions = {
  config?: MutationConfig<typeof updateVisitationMutationFn>;
};

export type UpdateBookMeetingVisitationOptions = {
  config?: MutationConfig<typeof updateBookMeetingVisitationMutationFn>;
};

export interface VisitationRequestFeedback {
  // Phản hồi đến yêu cầu tư vấn
  feedbackUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
  deadlineNew?: string;
}
export interface GetVisitationRequestFeedbackResponse {
  feedbackResponseDetails: VisitationRequestFeedback[];
}

export interface VisitationExtension {
  user: BasedUser;
  reason: string;
  requestDeadline: string;
  acceptDeadline: string;
  date: string;
  type?: number;
  timeExtensionType?: number;
  id: number;
  showExtension?: boolean;
  enableExtension?: boolean;
}

export interface GetVisitationExtensionResponse {
  timeExtensionResponseDetails: VisitationExtension[];
}
export interface VisitationForward {
  forwardUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  forwardDate: string;
}
export interface GetVisitationForwardResponse {
  forwardResponseDetails: VisitationForward[];
}

export interface VisitationConfirm {
  id: number;
  userResponse: BasedUser;
  content?: string;
  status?: number;
  deadline?: number;
  // attachmentResponses?: VisitationAttachment[];
}
export interface GetConflictConfirmResponse {
  responses: VisitationConfirm[];
}
export interface VisitationSign {
  user: BasedUser;
  status?: number;
  content?: string;
  type?: number;
  deadline?: string;
  receiverUsers?: BasedUser[];
  createAt?: string;
  createBy: BasedUser;
}
export interface GetVisitationSignTabResponse {
  data?: VisitationSign[];
}

export interface VisitationShareInformation {
  user: BasedUser;
  status?: number;
  content?: string;
  type?: number;
  deadline?: string;
  receiverUsers?: BasedUser[];
  createAt?: string;
  createBy: BasedUser;
  editAvailable?: boolean;
  department?: Department;
  attachments?: VisitationAttachment[];
}
export interface GetVisitationShareInformationResponse {
  data?: VisitationShareInformation[];
}

export type GetVisitationStatusRequest = {
  name?: string;
  modules?: number[];
  active?: number;
  tab?: number;
  page: number;
  size: number;
  sortBy: string;
  orderBy: string;
}

export type QueryVisitationStatusFnType = typeof getStatusVisitationQueryFn;

export type GetVisitationStatusOptions = {
  config?: QueryConfig<QueryVisitationStatusFnType>;
  request: GetVisitationStatusRequest;
};

export interface VisitationRequestEvaluate {
  // id: number;
  visitationName: string;
  createBy: BasedUser;
  content?: string;
  department?: Department;
  deadline?: string;
  createTime?: string;
  receiverUsers?: BasedUser[];
}

export interface GetVisitationRequestEvaluateResponse {
  responses: VisitationRequestEvaluate[];
}

export interface Comment {
  userInfo: BasedUser;
  comment: string;
  commentDate: string;
  commentId: string;
}

export interface GetVisitationCommentsResponse {
  data: Comment[];
}


export interface VisitationEvaluateFeedback {
  // id: number;
  visitationName: string;
  createBy: BasedUser;
  content?: string;
  attachments?: VisitationAttachment[];
  department?: Department;
  deadline?: string;
  createTime?: string;
  receiverUsers?: BasedUser[];
  statusEvaluate: number;
}

export interface GetVisitationInformationRequestsResponse {
  data: InformationRequestDetail[];
}

export interface GetVisitationEvaluateResponse {
  data: VisitationEvaluateFeedback[];
}

export enum ConvertPdfEnum {
  LOCAL = 1,
  SHARE_POINT = 2,
}

export enum VisitationStatusEnum {
  VISITATION,
  CONFIRM,
  SIGN,
}

export interface visitationSignFile {
  id?: number;
  order: number;
  fileType: number;
  statusId?: number;
  fileId?: number;
  attachmentId?: number;
  validFile?: boolean;
  fileName?: string;
  storagePath?: string;
}
export interface visitationSignInformationRequest {
  id?: number;
  position?: number;
  fileId?: number;
  // visitationSignESignFileList: visitationSignFile[];
  visitationSignUserApprovedList: visitationSignUserApproved[];
}

export interface VisitationAttachmentTab {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface GetVisitationAttachmentsResponse {
  data: VisitationAttachmentTab[];
}

export interface visitationSignUserApproved {
  id?: number;
  order?: number;
  processDate?: string;
  statusId?: number;
  comment?: string;
  department?: string;
  position?: string;
  // status?: number;
  userId?: string | null;
}

export interface SignApproveBodySend {
  deadline: string;
  statusId: number;
  attachmentIds: number[];
  reason?: string;
  content?: string;
  sharePointAttachmentFiles?: number[];
  visitationSignInformationRequestList?: visitationSignInformationRequest[];
}

export const enum SignApproveFields {
  DEADLINE = "deadline",
  STATUS_ID = "statusId",
  CONTENT = "content",
  SHARE_POINT_ATTACTMENT_FILES = "sharePointAttachmentFiles",
  ATTACHMENTS = "attachmentIds",
  SIGN_INFORMATION_REQUEST = "visitationSignInformationRequestList",
}

export interface SharePointAttachment {
  id: number;
  fileName: string;
  sharePointLink: string;
  sharePointId: string;
  status: StatusDTO;
  createBy: BasedUser;
  createAt: string;
}

export interface VisitationSignESignFile {
  id: number;
  order?: number;
  fileType?: number;
  status: StatusDTO;
  file?: VisitationAttachment;
  returnDate?: string;
}

export interface VisitationSignUserApproved {
  id: number;
  order: number;
  processDate: string;
  status: StatusDTO;
  comment?: string;
  user: BasedUser;
}
export interface VisitationSignInformation {
  id?: number;
  position?: number;
  esignFile?: VisitationSignESignFile[]; // tài liệu cuối
  visitationSignUserApprovedList: VisitationSignUserApproved[];
  attachment: VisitationAttachment[];
  status?: StatusDTO;
}


export interface SignApproveBodyReceived {
  name?: string;
  createBy?: BasedUser;
  deadline?: string;
  status?: StatusDTO;
  reason?: string;
  content?: string;
  attachmentFiles?: VisitationAttachment[];
  sharePointAttachmentFiles?: SharePointAttachment[];
  visitationSignInformationList?: VisitationSignInformation[];
}

const signUserSchema = Yup.array()
  .of(
    Yup.object().shape({
      userId: Yup.string().optional().nullable(), // Each signer can optionally have an id
      comment: Yup.string().optional().nullable(),
      order: Yup.number().optional().nullable(),
      id: Yup.number().optional().nullable(),
      // department: Yup.string().optional().nullable(),

    })
  )
  .test(
    "required-positions",
    "visitation.messages.requiredSignerAndProcessDate",
    (signers: any) => {
      // Validate the id for specific positions
      return !signers
        ? true
        : signers &&
            signers[0]?.userId && // Position 1 (index 0)
            signers[1]?.userId &&// Position 2 (index 1)
            signers[2]?.userId &&// Position 3 (index 2)
            signers[3]?.userId &&// Position 4 (index 3)
            signers[4]?.userId && // Position 5 (index 4)
            signers[5]?.userId; // Position 6 (index 5)
    }
  );

export const SignApproveSchema = Yup.object().shape({
  [SignApproveFields.DEADLINE]: Yup.mixed().required(VALIDATION_MSG.REQUIRED_FIELD),
  [SignApproveFields.STATUS_ID]: Yup.number().required(VALIDATION_MSG.REQUIRED_FIELD),
  [SignApproveFields.CONTENT]: Yup.string().nullable().optional(),
  isCallEsign: Yup.boolean().nullable().optional(),
  [SignApproveFields.ATTACHMENTS]: Yup.array()
    .min(1, "visitation.messages.selectFile")
    .required("visitation.messages.selectFile"),
  [SignApproveFields.SIGN_INFORMATION_REQUEST]: Yup.array().when("isCallEsign", {
    is: (val?: boolean) => {
      return !!val
    },
    then: () => Yup.array()
    .of(
      Yup.object().shape({
        "visitationSignUserApprovedList": signUserSchema,
        // "visitationSignESignFileList": Yup.array()
        // .min(1, "visitation.messages.selectApproveFile")
        // .required("visitation.messages.selectApproveFile"),
        fileId: Yup.number().required("visitation.messages.selectApproveFile"),
      })
    ),
    otherwise: () => Yup.array().nullable().optional(),
  }),
});

// export enum VisitationStatusCode {
//   FINISH = 1,
//   ADDITIONAL_INFORMATION_ADDED = 2,
//   ADDITIONAL_INFORMATION_REQUESTED = 3,
//   CONFIRMATION_REQUESTED = 4,
//   CONFIRMATION_ACCEPTED = 5,
//   CONFIRM = 6,
//   CONFIRM_REJECT = 7,
//   REQUEST_REVIEW = 8,
//   REVIEWED = 9,
//   REVIEW_REJECT = 10,
//   RECEPTION = 11,
//   RESULTS_FILLED = 12,
//   FOLLOW_UP_RESULTS = 13,
//   REQUEST_SIGNING = 14,
//   SIGNED = 15,
//   SIGNED_REJECTED = 16,
//   SIGNED_COMPLETED = 17,
//   RECALL = 18,
//   CALLING_ESIGN = 19,
// }

export const enum VisitationRoles {
  PIC = 1,
  LC = 2,
  SHARE_INFO = 3,
  EVALUATION = 4,
  SIGN = 5,
  VIEWER = 8,
}

export interface VisitationEvaluatedFeedBackReceived {
  id: number;
  createBy: BasedUser;
  department: Department;
  content: string;
  attachments: VisitationAttachment[];
  receiverUsers: BasedUser[];
  createTime: string;
}

export interface VisitationConfirmReceived {
  id: number;
  createBy: BasedUser;
  department: Department;
  content: string;
  type: number;
  attachments: VisitationAttachment[];
  receiverUsers: BasedUser[];
  createTime: string;
}

export interface VisitationFollowReceived {
  id: number;
  deadline: string;
  content: string;
  receiverUsers: BasedUser[];
  remind?: ReminderInput;
  createBy: BasedUser;
  createTime: string;
}

export interface VisitationReceptionResultReceived {
  id: number;
  content: string;
  receiverUsers: BasedUser[];
  remind?: ReminderInput;
  createBy: BasedUser;
  createTime: string;
}

export const enum SpPermissionVisitationTypes {
  ACC_365_UPLOAD = 1,
  ACC_365_NO_UPLOAD = 2,
  ACC_UPLOAD = 3,
}

export interface VisitationSpPermissionResponse {
  result: SpPermissionVisitationTypes;
}

export interface VisitationAssignment {
  assignUser: BasedUser;
  receiveUsers: BasedUser[];
  content: string;
  date: string;
}

export interface GetVisitationAssignmentResponse {
  assignmentResponseDetails: VisitationAssignment[];
}

export interface SignDefaultReceive {
  id?: number;
  order: number;
  processDate: string;
  status: number;
  comment: string;
  user: BasedUser
}

export interface SignDefaultResponse {
  total: number;
  data: SignDefaultReceive[];
}

export interface VisitationConfirmForm {
  content?: string;
  reason?: string;
}