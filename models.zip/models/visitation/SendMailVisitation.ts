import { VALIDATION_MSG } from "@/constants/message";
import * as Yup from "yup";

export const enum SendMailVisitationFieldNames {
  CONTENT = "content",
  SUBJECT = "subject",
  RECEIVERS = "receivers",
}

export interface SendMailVisitationRequest {
  subject?: string;
  content?: string;
  receivers: string[];
}

export const SendMailVisitationRequestSchema = Yup.object().shape({
  subject: Yup.string().required(VALIDATION_MSG.REQUIRED_FIELD),
  content: Yup.string()
    .required(VALIDATION_MSG.REQUIRED_FIELD)
    .test("non-empty", VALIDATION_MSG.REQUIRED_FIELD, (value) => {
      const strippedValue = value?.replace(/<[^>]+>/g, "").trim();
      return strippedValue !== "";
    }),
  receivers: Yup.array()
    .min(1, VALIDATION_MSG.SELECT)
    .required(VALIDATION_MSG.SELECT),
});
