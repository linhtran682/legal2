import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import {
  createSignVisitationMutationFn,
  // getSignListMutationFn,
  // getShareInfoRequestMutationFn,
  // updateSignVisitationMutationFn,
} from "@/apis/service/visitation/signVisitation";
import { VALIDATION_MSG } from "@/constants/message";

// type TypeDepartment = {
//   id?: string;
//   name?: string;
//   nameEnglish?: string;
// };

// type TypeUserDTO = {
//   id?: string;
//   name?: string;
//   nameEnglish?: string;
//   email?: string;
//   department?: TypeDepartment;
// };

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum SignVisitationFieldNames {
  CONTENT = "content",
  RECEIVER_USERS = "receiverUsers",
  REMIND = "remind",
}
export interface SignVisitationSchemaI extends FieldValues {
  content?: string;
  receiverUsers?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const SignSchemaVisitation = Yup.object().shape({
  [SignVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [SignVisitationFieldNames.RECEIVER_USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [SignVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateSignVisitationBody {
  visitationId?: number;
  data?: SignVisitationSchemaI;
}

export interface CreateSignVisitationOptions {
  config?: MutationConfig<typeof createSignVisitationMutationFn>;
}

// export interface UpdateSignVisitationBody {
//   visitationId?: number;
//   shareId?: number;
//   data?: SignVisitationSchemaI;
// }

// export interface UpdateSignVisitationOptions {
//   config?: MutationConfig<typeof createSignVisitationMutationFn>;
// }

// export interface ResponsesShareInfoRequestDTO {
//   createBy: TypeUserDTO;
//   visitationName?: string;
//   department?: TypeDepartment;
//   departments?: TypeDepartment[];
//   content?: string;
//   deadline?: Date | string;
//   createTime?: Date | string;
// }

// export type ShareInfoRequestQueryFnTypeList =
//   typeof createSignVisitationMutationFn;

// export type GetShareInfoRequestOptions = {
//   config?: QueryConfig<ShareInfoRequestQueryFnTypeList>;
//   request: { visitationId?: number };
// };

// export interface SignDTO {
//   id: number;
//   createBy: TypeUserDTO;
//   content?: string;
//   receiverUsers: TypeUserDTO[];
//   department?: TypeDepartment;
//   createTime?: Date | string;
// }

// export interface ResponsesSignListDTO {
//   data: SignDTO[];
//   total?: number;
// }

// export type SignListQueryFnTypeList =
//   typeof createSignVisitationMutationFn;

// export type GetSignListOptions = {
//   config?: QueryConfig<SignListQueryFnTypeList>;
//   request: { visitationId?: number };
// };
