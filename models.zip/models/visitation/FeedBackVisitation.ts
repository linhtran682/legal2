import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createFeedbackVisitationMutationFn } from "@/apis/service/visitation/feedbackVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedbackVisitationFieldNames {
  USERS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface FeedbackVisitationSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateFeedbackVisitationBody {
  visitationId?: number;
  data?: FeedbackVisitationSchemaI;
}

export interface CreateFeedbackVisitationOptions {
  config?: MutationConfig<typeof createFeedbackVisitationMutationFn>;
}

export const FeedbackVisitationSchema = Yup.object().shape({
  [FeedbackVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [FeedbackVisitationFieldNames.USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FeedbackVisitationFieldNames.REMIND]: ReminderSchema,
});

export const castFeedBackVisitationRequestSchemaToDTO = (
  schema: any
): FeedbackVisitationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

export const castRequestApproveNextActionSchemaToDTO = (
  schema: any
): FeedbackVisitationSchemaI => {
  return {
    ...schema,
    approvalUsers: schema.approvalUsers?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
