import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createEvaluateVisitationMutationFn,
  getEvaluateVisitationListMutationFn,
  updateEvaluateVisitationMutationFn,
} from "@/apis/service/visitation/evaluateVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export const EvaluateVisitationType = {
  APPROVE: true,
  REJECT: false,
};
export const EvaluateVisitationOptions: RadioItem[] = [
  {
    label: "visitation.evaluateVisitation.title.approve",
    value: EvaluateVisitationType.APPROVE,
  },
  {
    label: "visitation.evaluateVisitation.title.reject",
    value: EvaluateVisitationType.REJECT,
  },
];

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};

export interface EvaluateVisitationDTO {
  user?: TypeUserDTO;
  department?: TypeDepartment;
  deadLine?: string;
  content?: string;
}

export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}

type TypeAttachmentsDTO = {
  fileId?: number;
  fileName?: string;
  filePath?: string;
  uploadDate?: string;
  uploadUser?: TypeUserDTO;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum EvaluateVisitationFieldNames {
  IS_CONFIRM = "isConfirm",
  CONTENT = "content",
  RECEIVER_USERS = "receiverUsers",
  ATTACHMENTS = "attachments",
  REMIND = "remind",
}
export interface EvaluateVisitationSchemaI extends FieldValues {
  isConfirm?: boolean;
  content?: string;
  receiverUsers?: string[];
  attachmentIds?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const ConfirmSchemaVisitation = Yup.object().shape({
  [EvaluateVisitationFieldNames.IS_CONFIRM]: Yup.boolean().required(
    "Confirm status name is required"
  ),
  [EvaluateVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [EvaluateVisitationFieldNames.RECEIVER_USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [EvaluateVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateEvaluateVisitationBody {
  visitationId?: number;
  data?: EvaluateVisitationSchemaI;
}

export interface CreateEvaluateVisitationOptions {
  config?: MutationConfig<typeof createEvaluateVisitationMutationFn>;
}

export interface UpdateEvaluateVisitationBody {
  visitationId?: number;
  feedbackId?: number;
  data?: EvaluateVisitationSchemaI;
}

export interface UpdateEvaluateVisitationOptions {
  config?: MutationConfig<typeof updateEvaluateVisitationMutationFn>;
}

export interface EvaluateVisitationDTO {
  id: number;
  createBy: TypeUserDTO;
  attachments?: TypeAttachmentsDTO[];
  receiverUsers: TypeUserDTO[];
  department?: TypeDepartment;
  createTime?: Date | string;
}

export interface ResponsesEvaluateVisitationListDTO {
  data: EvaluateVisitationDTO[];
  total?: number;
}

export type EvaluateVisitationListQueryFnTypeList =
  typeof getEvaluateVisitationListMutationFn;

export type GetEvaluateVisitationListOptions = {
  config?: QueryConfig<EvaluateVisitationListQueryFnTypeList>;
  request: { visitationId?: number };
};

// export type DeleteEvaluateVisitationOptions = {
//   config?: MutationConfig<typeof deleteEvaluateVisitationMutationFn>;
// };

export const castEvaluateVisitationSchemaToDTO = (
  schema: any
): EvaluateVisitationSchemaI => {
  return {
    ...schema,
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
