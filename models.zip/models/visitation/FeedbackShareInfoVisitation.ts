import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createFeedbackShareInfoVisitationMutationFn,
  getFeedbackShareInfoListMutationFn,
  getShareInfoRequestMutationFn,
  updateFeedbackShareInfoVisitationMutationFn,
} from "@/apis/service/visitation/feedbackShareInfoVisitation";
import { VALIDATION_MSG } from "@/constants/message";

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FeedbackShareInfoVisitationFieldNames {
  CONTENT = "content",
  RECEIVER_USERS = "receiverUsers",
  REMIND = "remind",
}
export interface FeedbackShareInfoVisitationSchemaI extends FieldValues {
  content?: string;
  receiverUsers?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const FeedbackShareInfoSchemaVisitation = Yup.object().shape({
  [FeedbackShareInfoVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [FeedbackShareInfoVisitationFieldNames.RECEIVER_USERS]: Yup.array(
    BasedUserSchema
  )
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FeedbackShareInfoVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateFeedbackShareInfoVisitationBody {
  visitationId?: number;
  data?: FeedbackShareInfoVisitationSchemaI;
}

export interface CreateFeedbackShareInfoVisitationOptions {
  config?: MutationConfig<typeof createFeedbackShareInfoVisitationMutationFn>;
}

export interface UpdateFeedbackShareInfoVisitationBody {
  visitationId?: number;
  shareId?: number;
  data?: FeedbackShareInfoVisitationSchemaI;
}

export interface UpdateFeedbackShareInfoVisitationOptions {
  config?: MutationConfig<typeof updateFeedbackShareInfoVisitationMutationFn>;
}

export interface ResponsesShareInfoRequestDTO {
  createBy: TypeUserDTO;
  visitationName?: string;
  department?: TypeDepartment;
  departments?: TypeDepartment[];
  content?: string;
  deadline?: Date | string;
  createTime?: Date | string;
}

export type ShareInfoRequestQueryFnTypeList =
  typeof getShareInfoRequestMutationFn;

export type GetShareInfoRequestOptions = {
  config?: QueryConfig<ShareInfoRequestQueryFnTypeList>;
  request: { visitationId?: number };
};

export interface FeedbackShareInfoDTO {
  id: number;
  createBy: TypeUserDTO;
  content?: string;
  receiverUsers: TypeUserDTO[];
  department?: TypeDepartment;
  createTime?: Date | string;
}

export interface ResponsesFeedbackShareInfoListDTO {
  data: FeedbackShareInfoDTO[];
  total?: number;
}

export type FeedbackShareInfoListQueryFnTypeList =
  typeof getFeedbackShareInfoListMutationFn;

export type GetFeedbackShareInfoListOptions = {
  config?: QueryConfig<FeedbackShareInfoListQueryFnTypeList>;
  request: { visitationId?: number };
};
