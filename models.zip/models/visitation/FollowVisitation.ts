import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createFollowVisitationMutationFn,
  deleteFollowVisitationMutationFn,
  getFollowVisitationListMutationFn,
  updateFollowVisitationMutationFn,
} from "@/apis/service/visitation/followVisitation";
import { VALIDATION_MSG } from "@/constants/message";

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum FollowVisitationFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  USER_IDS = "userIds",
  REMIND = "remind",
}
export interface FollowVisitationSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const FollowSchemaVisitation = Yup.object().shape({
  [FollowVisitationFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [FollowVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [FollowVisitationFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [FollowVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateFollowVisitationBody {
  visitationId?: number;
  data?: FollowVisitationSchemaI;
}

export interface CreateFollowVisitationOptions {
  config?: MutationConfig<typeof createFollowVisitationMutationFn>;
}

export interface UpdateFollowVisitationBody {
  visitationId?: number;
  followId?: number;
  data?: FollowVisitationSchemaI;
}

export interface UpdateFollowVisitationOptions {
  config?: MutationConfig<typeof updateFollowVisitationMutationFn>;
}

export interface FollowVisitationDTO {
  id: number;
  createBy: TypeUserDTO;
  content?: string;
  userIds: TypeUserDTO[];
  createTime?: Date | string;
}

export interface ResponsesFollowVisitationListDTO {
  data: FollowVisitationDTO[];
  total?: number;
}

export type FollowVisitationListQueryFnTypeList =
  typeof getFollowVisitationListMutationFn;

export type GetFollowVisitationListOptions = {
  config?: QueryConfig<FollowVisitationListQueryFnTypeList>;
  request: { visitationId?: number };
};

export type DeleteFollowVisitationOptions = {
  config?: MutationConfig<typeof deleteFollowVisitationMutationFn>;
};
