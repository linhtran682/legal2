import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createReceptionVisitationMutationFn } from "@/apis/service/visitation/receptionVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ReceptionFieldNames {
  USER_IDS = "userIds",
  REMIND = "remind",
}

export interface ReceptionSchemaI extends FieldValues {
  status?: number;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const ReceptionSchemaVisitation = Yup.object().shape({
  [ReceptionFieldNames.USER_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ReceptionFieldNames.REMIND]: ReminderSchema,
});

export interface CreateReceptionVisitationBody {
  visitationId?: number;
  data?: ReceptionSchemaI;
}

export interface CreateReceptionVisitationOptions {
  config?: MutationConfig<typeof createReceptionVisitationMutationFn>;
}
