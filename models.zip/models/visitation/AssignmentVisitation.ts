import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createAssignmentVisitationMutationFn } from "@/apis/service/visitation/assignmentVisitation";
import { BasedUser } from "../user/User";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum AssignmentVisitationFieldNames {
  CONTENT = "content",
  USERS_ID = "userId",
  REMIND = "remind",
}
export interface AssignmentVisitationSchemaI extends FieldValues {
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export const AssignmentVisitationSchema = Yup.object().shape({
  [AssignmentVisitationFieldNames.USERS_ID]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [AssignmentVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateAssignmentVisitationBody {
  visitationId?: number;
  data?: AssignmentVisitationSchemaI;
}

export interface CreateAssignmentVisitationOptions {
  config?: MutationConfig<typeof createAssignmentVisitationMutationFn>;
}

export const castAssignmentVisitationRequestSchemaToDTO = (
  schema: any
): AssignmentVisitationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
