import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { BasedUser, BasedUserSchema } from "../user/User";
import { createForwardVisitationMutationFn } from "@/apis/service/visitation/forwardVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ForwardVisitationFieldNames {
  USERS_IDS = "userIds",
  DEADLINE = "deadline",
  CONTENT = "content",
  REMIND = "remind",
}
export interface ForwardVisitationSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  userIds?: string[];
  remind?: SaveReminderDTO;
}

export interface CreateForwardVisitationBody {
  visitationId?: number;
  data?: ForwardVisitationSchemaI;
}

export interface CreateForwardVisitationOptions {
  config?: MutationConfig<typeof createForwardVisitationMutationFn>;
}

export const ForwardVisitationSchema = Yup.object().shape({
  [ForwardVisitationFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [ForwardVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [ForwardVisitationFieldNames.USERS_IDS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ForwardVisitationFieldNames.REMIND]: ReminderSchema,
});

export const castForwardVisitationRequestSchemaToDTO = (
  schema: any
): ForwardVisitationSchemaI => {
  return {
    ...schema,
    userIds: schema.userIds?.map((ele: BasedUser) => ele.id) || [],
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};
