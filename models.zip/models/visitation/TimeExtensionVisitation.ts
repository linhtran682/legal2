import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
  ReminderSchemaI,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import { VALIDATION_MSG } from "@/constants/message";
import {
  createTimeExtensionVisitationMutationFn,
  getTimeExtensionVisitationQueryFn,
  updateTimeExtensionVisitationMutationFn,
} from "@/apis/service/visitation/timeExtensionVisitation";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const enum TimeExtensionRequestVisitationFieldNames {
  DEADLINE = "deadline",
  REASON = "reason",
  REMIND = "remind",
  CONFIRM = "confirm",
  ACCEPTABLE_DEADLINE = "acceptableDeadline",
  ACCEPTABLE_DEADLINE_REASON = "acceptableReason",
  RECEIVER_USERS = "receiverUsers",
}

export const TimeExtensionVisitationType = {
  CONFIRM_DEADLINE: 1,
  SHARE_INFORMATION_DEADLINE: 2,
  RESPONSE_LC_DEADLINE: 3,
};

export const ConfirmExtensionVisitationType = {
  NEW_DEADLINE: 1,
  APPROVE: 0,
};

export const ExtensionVisitationOptions: RadioItem[] = [
  {
    label: "visitation.timeExtension.title.newDeadline",
    value: ConfirmExtensionVisitationType.NEW_DEADLINE,
  },
  {
    label: "visitation.timeExtension.title.approve",
    value: ConfirmExtensionVisitationType.APPROVE,
  },
];

export const TimeExtensionRequestVisitationSchema = Yup.object().shape({
  [TimeExtensionRequestVisitationFieldNames.DEADLINE]: Yup.string().required(
    "Deadline from vendor date is required"
  ),
  [TimeExtensionRequestVisitationFieldNames.REASON]: Yup.string().required(
    "Reason name is required"
  ),
  [TimeExtensionRequestVisitationFieldNames.REMIND]: ReminderSchema,
});

export const ConfirmExtensionRequestVisitationSchema = Yup.object().shape({
  [TimeExtensionRequestVisitationFieldNames.CONFIRM]: Yup.boolean().required(
    "Confirm is required"
  ),
  [TimeExtensionRequestVisitationFieldNames.ACCEPTABLE_DEADLINE]: Yup.string()
    .required("Deadline accept name is required")
    .when(
      TimeExtensionRequestVisitationFieldNames.CONFIRM,
      ([isNewDeadline], schema) => {
        if (isNewDeadline) {
          return schema.required("Deadline accept name is required");
        }
        return schema.notRequired();
      }
    ),
  [TimeExtensionRequestVisitationFieldNames.ACCEPTABLE_DEADLINE_REASON]:
    Yup.string()
      .required("Reason accept name is required")
      .when(
        TimeExtensionRequestVisitationFieldNames.CONFIRM,
        ([isNewDeadline], schema) => {
          if (isNewDeadline) {
            return schema.required("Reason accept name is required");
          }
          return schema.notRequired();
        }
      ),
  [TimeExtensionRequestVisitationFieldNames.RECEIVER_USERS]: Yup.array(
    BasedUserSchema
  )
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [TimeExtensionRequestVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface Department {
  id: string;
  name?: string;
  nameEnglish?: string;
}

export interface TimeExtensionUser {
  id?: string;
  name?: string | undefined;
  nameEnglish?: string;
  email?: string | undefined;
  department?: Department;
}
export interface TimeExtensionRequestVisitationSchemaI extends FieldValues {
  deadline?: string;
  reason?: string;
  remind?: ReminderSchemaI;
}

export interface RequestApprovalDTO {
  id?: number;
  deadline?: string;
  reason?: string | undefined;
  user?: TimeExtensionUser;
  department?: Department;
}

interface TypeAcceptTimeExtension {
  deadlineAccept?: string;
  reason?: string;
  type?: number;
  receiverUsers?: string[];
  remind: SaveReminderDTO;
}
export interface UpdateTimeExtensionVisitationBody {
  visitationId?: number;
  timeExtensionRequestId?: number;
  data?: TypeAcceptTimeExtension;
}

export interface CreateTimeExtensionVisitationBody {
  visitationId?: number;
  data?: TimeExtensionRequestVisitationSchemaI;
}

export interface CreateTimeExtensionVisitationOptions {
  config?: MutationConfig<typeof createTimeExtensionVisitationMutationFn>;
}

export type TimeExtensionVisitationParams = {
  visitationId?: number;
  timeExtensionRequestId?: number;
};

export type QueryFnTypeVisitation = typeof getTimeExtensionVisitationQueryFn;

export type GetTimeExtensionVisitationIdOptions = {
  config?: QueryConfig<QueryFnTypeVisitation>;
  request: TimeExtensionVisitationParams;
};

export type UpdateTimeExtensionVisitationAcceptOptions = {
  config?: MutationConfig<typeof updateTimeExtensionVisitationMutationFn>;
};
