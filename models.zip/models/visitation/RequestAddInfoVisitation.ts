import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createRequestAddInfoVisitationMutationFn } from "@/apis/service/visitation/requestAddInfoVisitation";

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestAddInfoVisitationFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  USERS = "users",
  REMIND = "remind",
}
export interface RequestAddInfoVisitationSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  remind?: SaveReminderDTO;
}

export const RequestAddInfoSchemaVisitation = Yup.object().shape({
  [RequestAddInfoVisitationFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [RequestAddInfoVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [RequestAddInfoVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateRequestAddInfoVisitationBody {
  visitationId?: number;
  data?: RequestAddInfoVisitationSchemaI;
}

export interface CreateRequestAddInfoVisitationOptions {
  config?: MutationConfig<typeof createRequestAddInfoVisitationMutationFn>;
}
