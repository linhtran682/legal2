import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  castReminderSchemaToSaveReminderDTO,
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig, QueryConfig } from "@/apis";
import {
  createConfirmVisitationMutationFn,
  getConfirmVisitationListMutationFn,
  updateConfirmVisitationMutationFn,
} from "@/apis/service/visitation/confirmVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export const ConfirmVisitationType = {
  CONFIRM_APPROVE: true,
  CONFIRM_REJECT: false,
};

export const ConfirmVisitationOptions: RadioItem[] = [
  {
    label: "visitation.confirmVisitation.title.approve",
    value: ConfirmVisitationType.CONFIRM_APPROVE,
  },
  {
    label: "visitation.confirmVisitation.title.reject",
    value: ConfirmVisitationType.CONFIRM_REJECT,
  },
];

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

type TypeUserDTO = {
  id?: string;
  name?: string;
  nameEnglish?: string;
  email?: string;
  department?: TypeDepartment;
};

export interface FileInfo {
  fileId: number;
  fileName: string;
  storagePath: string;
}

type TypeAttachmentsDTO = {
  fileId?: number;
  fileName?: string;
  filePath?: string;
  uploadDate?: string;
  uploadUser?: TypeUserDTO;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ConfirmVisitationFieldNames {
  IS_CONFIRM = "isConfirm",
  CONTENT = "content",
  RECEIVER_USERS = "receiverUsers",
  ATTACHMENTS = "attachments",
  REMIND = "remind",
}
export interface ConfirmVisitationSchemaI extends FieldValues {
  isConfirm?: boolean;
  content?: string;
  receiverUsers?: string[];
  attachmentIds?: string[];
  remind?: SaveReminderDTO;
}

const BasedUserSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
  email: Yup.string().trim().optional(),
  departmentName: Yup.string().trim().nullable(),
});

export const ConfirmSchemaVisitation = Yup.object().shape({
  [ConfirmVisitationFieldNames.IS_CONFIRM]: Yup.boolean().required(
    "Confirm status name is required"
  ),
  [ConfirmVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [ConfirmVisitationFieldNames.RECEIVER_USERS]: Yup.array(BasedUserSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ConfirmVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateConfirmVisitationBody {
  visitationId?: number;
  data?: ConfirmVisitationSchemaI;
}

export interface CreateConfirmVisitationOptions {
  config?: MutationConfig<typeof createConfirmVisitationMutationFn>;
}

export interface UpdateConfirmVisitationBody {
  visitationId?: number;
  confirmId?: number;
  data?: ConfirmVisitationSchemaI;
}

export interface UpdateConfirmVisitationOptions {
  config?: MutationConfig<typeof updateConfirmVisitationMutationFn>;
}

export interface ConfirmVisitationDTO {
  id: number;
  createBy: TypeUserDTO;
  attachments?: TypeAttachmentsDTO[];
  receiverUsers: TypeUserDTO[];
  department?: TypeDepartment;
  createTime?: Date | string;
}

export interface ResponsesConfirmVisitationListDTO {
  data: ConfirmVisitationDTO[];
  total?: number;
}

export type ConfirmVisitationListQueryFnTypeList =
  typeof getConfirmVisitationListMutationFn;

export type GetConfirmVisitationListOptions = {
  config?: QueryConfig<ConfirmVisitationListQueryFnTypeList>;
  request: { visitationId?: number };
};

export const castConfirmVisitationSchemaToDTO = (
  schema: any
): ConfirmVisitationSchemaI => {
  return {
    ...schema,
    remind: schema.remind
      ? castReminderSchemaToSaveReminderDTO(schema.remind)
      : undefined,
  };
};

// export type DeleteConfirmVisitationOptions = {
//   config?: MutationConfig<typeof deleteConfirmVisitationMutationFn>;
// };
