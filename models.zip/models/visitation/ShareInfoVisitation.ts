import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createShareInfoVisitationMutationFn } from "@/apis/service/visitation/shareInfoVisitation";
import { VALIDATION_MSG } from "@/constants/message";

type TypeDepartment = {
  id?: string;
  name?: string;
  nameEnglish?: string;
};

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum ShareInfoVisitationFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  DEPARTMENTS = "departments",
  REMIND = "remind",
}
export interface ShareInfoVisitationSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  department?: TypeDepartment[];
  remind?: SaveReminderDTO;
}

const DepartmentSchema = Yup.object().shape({
  id: Yup.string().trim().required(VALIDATION_MSG.REQUIRED_FIELD),
  name: Yup.string().trim().optional(),
  nameEnglish: Yup.string().trim().optional(),
});

export const ShareInfoSchemaVisitation = Yup.object().shape({
  [ShareInfoVisitationFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [ShareInfoVisitationFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [ShareInfoVisitationFieldNames.DEPARTMENTS]: Yup.array(DepartmentSchema)
    .min(1, VALIDATION_MSG.REQUIRED_FIELD)
    .required(VALIDATION_MSG.REQUIRED_FIELD),
  [ShareInfoVisitationFieldNames.REMIND]: ReminderSchema,
});

export interface CreateShareInfoVisitationBody {
  visitationId?: number;
  data?: ShareInfoVisitationSchemaI;
}

export interface CreateShareInfoVisitationOptions {
  config?: MutationConfig<typeof createShareInfoVisitationMutationFn>;
}
