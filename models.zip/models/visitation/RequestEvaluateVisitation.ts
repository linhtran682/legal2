import { FieldValues } from "react-hook-form";
import * as Yup from "yup";
import {
  ReminderContent,
  ReminderSchema,
} from "@/models/reminder_template/ReminderDTO";
import { MutationConfig } from "@/apis";
import { createRequestEvaluateVisitationMutationFn } from "@/apis/service/visitation/requestEvaluateVisitation";
import { VALIDATION_MSG } from "@/constants/message";

export interface SaveReminderDTO {
  remindId?: number;
  title?: string;
  module?: number;
  description?: string;
  relatedUsers?: string[] | undefined;
  receivingDepartment?: string[];
  receivedTitle?: string[];
  remindContents?: ReminderContent[];
}

export const enum RequestEvaluateFieldNames {
  DEADLINE = "deadline",
  CONTENT = "content",
  RECEIVER_USERS = "receiverUsers",
  REMIND = "remind",
}

export interface RequestEvaluateSchemaI extends FieldValues {
  deadline?: string;
  content?: string;
  receiverUsers?: string[];
  remind?: SaveReminderDTO;
}

export const RequestEvaluateSchemaVisitation = Yup.object().shape({
  [RequestEvaluateFieldNames.DEADLINE]: Yup.string().required(
    "Deadline name is required"
  ),
  [RequestEvaluateFieldNames.CONTENT]: Yup.string().required(
    "Content name is required"
  ),
  [RequestEvaluateFieldNames.RECEIVER_USERS]: Yup.string().required(
    VALIDATION_MSG.REQUIRED_FIELD
  ),
  [RequestEvaluateFieldNames.REMIND]: ReminderSchema,
});

export interface CreateRequestEvaluateVisitationBody {
  visitationId?: number;
  data?: RequestEvaluateSchemaI;
}

export interface CreateRequestEvaluateVisitationOptions {
  config?: MutationConfig<typeof createRequestEvaluateVisitationMutationFn>;
}
