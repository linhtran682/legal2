import { Department } from "../department/Department";
import { LegalAdviceAttachment } from "../legal-advice/LegalAdviceDetail";
import { ReminderInput } from "../reminder_template/ReminderDTO";
import { StatusDTO } from "../status/Status";
import { BasedUser } from "../user/User";
import { VisitationBodyReceive } from "./VisitationDetail";

export interface VisitationAttachment {
  fileId: number;
  fileName: string;
  filePath: string;
  uploadDate: string;
  uploadUser: BasedUser;
}

export interface DetailPosition {
  id: string;
  name: string;
  nameEnglish?: string;
}

// export const enum BaseVisitationFields {
//   ID = "id",
//   NAME = "name",
//   IS_DRAFT = "isDraft",
//   PIC = "pic",
//   VISITATION_STATUS = "visitationStatus",
//   CONFIRM_STATUS = "confirmStatus",
//   RECEPTION_USER = "receptionUser",
//   DEPARTMENT = "department",
//   POSITION = "position",
//   GROUP = "group",
//   SUPERVISOR_USER = "supervisorUser",
//   ATTACHMENT_FILES = "attachmentFiles",
//   FIELD = "field",
//   ORGANIZATION_NAME = "organizationName",
//   RECEPTION_TIME_FROM = "receptionTimeFrom",
//   RECEPTION_TIME_TO = "receptionTimeTo",
//   PURPOSE = "purpose",
//   REQUEST_SUMARY = "requestSummary",
//   DEPARTMENT_FEEDBACK = "departmentFeedback",
//   PARTICIPANTS = "participants",
//   CHECK_DIVISION_FLAG = "checkDivisionFlag",
//   CHECK_DEPT_HEAD_FLAG = "checkDeptHeadFlag",
//   IS_BOOKING_FLAG = "isBookingFlag",
//   IS_DEPT_HEAD_CONFIRM_FLAG = "isDeptHeadConfirmFlag",
//   IS_DIVISION_HEAD_CONFIRM_FLAG = "isDivisionHeadConfirmFlag",
//   IS_LC_EVALUATE_FLAG = "isLCEvaluateFlag",
//   IS_FINISH_SIGN_FLAG = "isFinishSignFlag",
//   RECEIVED_USERS = "receiverUsers",
//   CONFIRM_DEADLINE = "confirmDeadline",
//   SHARE_INFORMATION_DEPARTMENT = "shareInformationDepartments",
//   SHARE_INFORMATION_DEADLINE = "shareInformationDeadline",
//   STAFF_LC_USERS = "staffLCUsers",
//   RESPONSE_LC_DEADLINE = "responseLCDeadline",
//   REMIND = "remind",
//   ACTION_AVAILABLE_AND_ROLE = "actionAvailableAndRole",
//   CREATED_AT = "createdAt",
//   CREATED_BY = "createdBy",
// }
export interface BaseVisitation {
  id: number;
  isDraft: boolean;
  name: string;
  status: StatusDTO;
  employeeInfo: {
    id: number;
    employeeCode: string;
    department?: Department;
    position?: DetailPosition;
    manager?: {
      id: string;
      name: string;
      email: string;
      departmentName: string;
      departmentResponse: {
        id: string;
        code: string;
        name: string;
        nameEnglish?: string;
        description: string;
        departmentType: {
          id: string;
          name: string;
        };
        children: string[];
        status?: string;
      };
      positionResponse?: {
        id: string;
        name: string;
        nameEnglish?: string;
      };
    };
  };
  employeeAttachments: LegalAdviceAttachment[];
  conflictObject: {
    id: number;
    name: string;
    agency: string;
    position: string;
    relation: string;
  };
  natureConflict?: number[];
  reasonConflict: string;
  conflictDetail: string;
  conflictResolution: string;
  employees: BasedUser[];
  confirmationDeadline: string;
  lcEmployees: BasedUser[];
  lcReviewDeadline: string;
  remind: ReminderInput;
  checkDivisionFlag: number;
  checkDeptHeadFlag: number;
}

export type GetVisitationListParams = {
  picIds?: string[];
  receptionName?: string;
  receptionId?: string;
  department?: string;
  position?: string;
  receptionIds?: string[];
  confirmDeadlineFrom?: string;
  confirmDeadlineTo?: string;
  evaluationDeadlineFrom?: string;
  evaluationDeadlineTo?: string;
  status?: number[] | string;
  employeeIds?: string[];
  lcEmployeeIds?: string[];
  from?: string;
  to?: string;
  sortBy: string;
  orderBy: string;
  page: number;
  size: number;
  tab?: number;
  isPanelSearch?: boolean;
  isEnglish?: boolean;
}
export interface GetVisitationListResponse {
  total: number;
  data: VisitationBodyReceive[];
}

export interface VisitationStatisticChartResponse {
  pieChart: {
    data: {
      name: string;
      value: number
    }[];
  }
  barChart: {
    data: {
      name: string;
      value: number
    }[];
  }
}
