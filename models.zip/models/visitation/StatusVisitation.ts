export interface StatusVisitationDTO {
  id: number;
  code: number;
  name: string;
  module: number;
  active: number;
  description?: string;
  createdBy?: string;
  createdAt?: Date;
  tab?: number[];
}

export interface GetStatusVisitationListResponse {
  total: number;
  statusResponses: StatusVisitationDTO[];
}
