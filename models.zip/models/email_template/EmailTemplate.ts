import { QueryConfig } from "@/apis";
import { getEmailTemplateMutationFn } from "@/apis/service/email_template/EmailTemplate";

export interface ResponsesEmailTemplateDTO {
  id: number;
  title?: string;
  content?: string;
  emailType?: string;
}

export type EmailTemplateQueryFnTypeList =
  typeof getEmailTemplateMutationFn;

export type GetEmailTemplateOptions = {
  config?: QueryConfig<EmailTemplateQueryFnTypeList>;
  request: {
    module?: number;
    id?: number;
  };
};
