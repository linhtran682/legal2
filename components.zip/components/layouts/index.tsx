"use client";
import React, { useContext, useEffect, useState } from "react";
import {
  Toolbar,
  Typography,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CssBaseline,
  Box,
  Collapse,
  styled,
  Theme,
  CSSObject,
  Popover,
  IconButton,
} from "@mui/material";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import { Logo } from "@/assets/images/logo";
import { AppBars } from "./AppBar";
import { COLOR_TYPE } from "@/constants/color";
import { MenuItem } from "./Menu";
import { cookieSetting } from "@/utils";
import { useRouter } from "next/router";
import BreadcrumbNavigation, { findBreadcrumb } from "./BreadCrumbs";
import useMenu from "./Menu";
import { LogoResponsive } from "@/assets/logoResponsive";
// import { handleGetTokenWith365, loginWith365 } from "@/apis/auth";
import MuiDrawer from "@mui/material/Drawer";
// import axios from "axios";
// import qs from "qs";
import { AuthorityCheckWrapper } from "../commons/not_authorized_indicator/AuthorityCheckWrapper";
// import RemindPopup from "../commons/remind/RemindPopup";
import { useMsal } from "@azure/msal-react";
import { loginRequest, msalInstance } from "@/authAccess/auth-config";
import { InteractionRequiredAuthError } from "@azure/msal-browser";
import { IconExpand } from "@/assets/iconMenu/IconExpand";
import Head from "next/head";
import RemindPopup from "../commons/remind/RemindPopup";
import { AppContext } from "@/context/AppContext";

const drawerWidth = 249;
type Props = {
  children: React.ReactNode;
  hideHeader?: boolean;
  noFooterBtn?: boolean;
};

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 3px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 3px)`,
  },
});
const DrawerStyle = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  // width: drawerWidth, // Giữ chiều rộng cố định
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": {
      ...openedMixin(theme),
      overflowY: "auto", // Kích hoạt cuộn dọc khi mở
      "&::-webkit-scrollbar": {
        width: "0px", // Độ rộng của thanh cuộn
      },
      "&::-webkit-scrollbar-thumb": {
        backgroundColor: theme.palette.primary.main,
        borderRadius: "10px",
      },
      "&::-webkit-scrollbar-track": {
        backgroundColor: "#f1f1f1",
      },
    },
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": {
      ...closedMixin(theme),
      overflowY: "overlay",
      scrollbarWidth: "thin",
      width: `calc(${drawerWidth}px + 6px)`,
      "&::-webkit-scrollbar": {
        width: "0px",
      },
      "&::-webkit-scrollbar-thumb": {
        backgroundColor: theme.palette.primary.main,
        borderRadius: "10px",
      },
      "&::-webkit-scrollbar-track": {
        backgroundColor: "#f1f1f1",
      },
    },
  }),
}));
function DashboardLayout(props: Props) {
  const MENU = useMenu();
  const { children } = props;
  const router = useRouter();
  const pathName = router.pathname;
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [openSubmenu, setOpenSubmenu] = useState<any>({});
  const [, setSelectedMenu] = useState(null);
  const typeOfLogin = cookieSetting.get("TYPE");
  const appContext = useContext(AppContext);

  const { pathname } = router;
  const nameMenu = findBreadcrumb(MENU, pathname);

  const { instance, accounts } = useMsal();

  useEffect(() => {
    const fetchData = async () => {
      const token = await cookieSetting.get("token");
      if (typeOfLogin === "MS365") {
        if (accounts.length > 0) {
          const account = accounts[0];
          instance
            .acquireTokenSilent({ ...loginRequest, account })
            .then((response) => {
              cookieSetting.set("token", response.idToken);
              cookieSetting.set("ACCESS_TOKEN", response.accessToken);
            })
            .catch((error) => {
              if (error instanceof InteractionRequiredAuthError) {
                msalInstance.acquireTokenRedirect(loginRequest);
              } else {
              }
            });
        } else {
          router.push("/auth/login");
        }
      }
      if (typeOfLogin === "TEMP" && (!token || token === "")) {
        router.push("/auth/login");
      }

      if (typeOfLogin === "" || typeOfLogin === undefined) {
        router.push("/auth/login");
      }
    };

    fetchData();
  }, [accounts, router, instance]);

  const handleMenuItemClick = (text: any) => {
    setSelectedMenu((prevSelectedMenu) =>
      prevSelectedMenu === text ? null : text
    );
    if (openSubmenu[text]) {
      handleSubmenuToggle(text);
    }
  };
  const handleDrawerToggle = () => {
    setDrawerOpen(!drawerOpen);
  };
  const handleSubmenuToggle = (text: any) => {
    setOpenSubmenu((prevOpen: any) => ({
      ...prevOpen,
      [text]: !prevOpen[text],
    }));
  };
  useEffect(() => {
    const autoToggleSubmenus = (items: any[], path: string | any[]) => {
      items.forEach((item) => {
        if (item.subItems && !item.isSingleLevel) {
          const anyMatch = item.subItems.some((subItem: { path: string }) => {
            if (subItem.path) {
              return path?.includes(subItem.path.toString().split("/")[1]);
            }
            return false;
          });
          if (anyMatch) {
            setOpenSubmenu((prevState: any) => ({
              ...prevState,
              [item.text]: true,
            }));
          }
          autoToggleSubmenus(item.subItems, path);
        }
      });
    };
    autoToggleSubmenus(MENU, pathName);
    if (!pathname.includes("list")) {
      setDrawerOpen(false);
    }
  }, [pathName]);
  const isSelected = (item: MenuItem) => {
    if (item?.path) {
      if (item.path === "/") {
        return item.path.toString() === pathName?.toString();
      }
      return pathName?.includes(item.path.toString().split("/")[1]);
    }
    return false;
  };
  const [openPopover, setOpenPopover] = useState<string | null>(null);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const handleIconClick = (
    event: React.MouseEvent<HTMLElement>,
    itemText: string
  ) => {
    setAnchorEl(event.currentTarget);
    setOpenPopover(openPopover === itemText ? null : itemText);
  };

  const handleClose = () => {
    setOpenPopover(null);
    setAnchorEl(null);
  };

  const isOpen = (itemText: string) => openPopover === itemText;
  return (
    <>
      <Head>
        <title>Legal & Compliance System</title>
      </Head>
      {cookieSetting.get("token") && (
        <Box
          className="flex h-screen"
          sx={{
            backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA7}`,
            position: "relative",
          }}
        >
          <CssBaseline />
          <AppBars
            drawerOpen={drawerOpen}
            handleDrawerToggle={handleDrawerToggle}
          />

          <DrawerStyle
            variant="permanent"
            open={drawerOpen}
            sx={{
              width: drawerOpen ? 249 : 80,
              flexShrink: 0,
              position: "relative",
              "& .MuiDrawer-paper": {
                width: drawerOpen ? 249 : 80,
                boxSizing: "border-box",
                display: "flex",
                flexDirection: "column",
                border: "none",
                backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA8}`,
                fontSize: 14,
              },
            }}
          >
            <div className="flex flex-col flex-grow">
              <div
                className="flex items-center justify-center"
                style={{
                  transform: "scale(1.25)",
                  marginTop: `${!drawerOpen ? "-15px" : 0}`,
                  position: "relative",
                }}
              >
                {drawerOpen ? <Logo /> : <LogoResponsive />}
              </div>
              <List>
                {MENU.map((item) => (
                  <div key={item.text}>
                    <ListItem
                      key={item.text}
                      sx={{
                        backgroundColor: isSelected(item)
                          ? "rgba(255, 0, 0, 0.1)"
                          : "transparent",
                      }}
                      button
                      onClick={(e) => {
                        if (item.path) {
                          router.push(`${item.path}`);
                        } else {
                          // if (item.path) {
                          //   router.push(`${item.path}`);
                          // } else {
                          //   !item.subItems ?? handleMenuItemClick(item.text);
                          //   drawerOpen &&
                          //     item.subItems &&
                          //     handleSubmenuToggle(item.text);
                          //   !drawerOpen && item.subItems && handleIconClick(e);
                          // }
                          if (item.subItems && !item.isSingleLevel) {
                            !item.subItems || handleMenuItemClick(item.text);
                            drawerOpen &&
                              item.subItems &&
                              handleSubmenuToggle(item.text);
                            !drawerOpen &&
                              item.subItems &&
                              handleIconClick(e, item.text);
                          }
                        }
                      }}
                    >
                      <ListItemIcon
                        key={item.text}
                        sx={{ color: "black" }}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 6,
                          justifyContent: "flex-start",
                          color: isSelected(item) ? COLOR_TYPE.TOYOTA.TOYOTA1 : "black",
                        }}
                      >
                        {item.icon}
                        {!drawerOpen && (
                          <div
                            style={{
                              width: 5,
                              height: 5,
                              backgroundColor: "black",
                              borderRadius: "50%",
                              marginLeft: 8,
                              verticalAlign: "middle",
                              display: "inline-block",
                            }}
                          />
                        )}
                      </ListItemIcon>
                      {drawerOpen && (
                        <>
                          <ListItemText
                            primary={
                              <Typography
                                variant="subtitle1"
                                sx={{
                                  fontWeight: 700,
                                  color: isSelected(item) ? COLOR_TYPE.TOYOTA.TOYOTA1 : "black",
                                  fontSize: "14px",
                                  marginLeft: "-18px",
                                  overflow: "hidden",
                                  whiteSpace: "nowrap",
                                  textOverflow: "ellipsis",
                                  wordBreak: "break-word",
                                }}
                              >
                                {item.text}
                              </Typography>
                            }
                          />
                          {item.subItems && !item.isSingleLevel && (
                            <button>
                              {openSubmenu[item.text] ? (
                                <ExpandLess
                                  style={{ fontSize: 18, fontWeight: "bold", rotate: '180deg' }}
                                />
                              ) : (
                                <ExpandMore
                                  style={{ fontSize: 18, fontWeight: "bold", rotate: '-90deg' }}
                                />
                              )}
                            </button>
                          )}
                        </>
                      )}
                    </ListItem>
                    {/* Collapse for open drawer */}
                    {drawerOpen && item.subItems && !item.isSingleLevel && (
                      <Collapse
                        in={openSubmenu[item.text]}
                        timeout="auto"
                        unmountOnExit
                      >
                        <List component="div" disablePadding>
                          {item.subItems.map((subItem) => (
                            <ListItem
                              sx={{
                                backgroundColor: isSelected(subItem)
                                  ? "rgba(255, 0, 0, 0.1)"
                                  : "transparent",
                                paddingLeft: 8,
                              }}
                              button
                              key={subItem.text}
                              onClick={() => {
                                if (subItem.path) {
                                  router.push(`${subItem.path}`);
                                }
                                handleMenuItemClick(subItem.text);
                              }}
                            >
                              <ListItemText
                                primary={
                                  <Typography
                                    variant="subtitle1"
                                    sx={{
                                      fontWeight: 700,
                                      color: isSelected(subItem)
                                        ? "red"
                                        : "black",
                                      fontSize: "14px",
                                    }}
                                  >
                                    {subItem.text}
                                  </Typography>
                                }
                              />
                            </ListItem>
                          ))}
                        </List>
                      </Collapse>
                    )}
                  </div>
                ))}
              </List>
              {MENU.map(
                (item) =>
                  item.subItems &&
                  !item.isSingleLevel &&
                  isOpen(item.text) && (
                    <Popover
                      key={item.text}
                      sx={{
                        marginLeft: 1,
                        marginTop: 10,
                        fontSize: "14px !important",
                      }}
                      open={Boolean(anchorEl)}
                      anchorEl={anchorEl}
                      onClose={handleClose}
                      anchorOrigin={{
                        vertical: "bottom",
                        horizontal: "right",
                      }}
                      transformOrigin={{
                        vertical: "bottom",
                        horizontal: "left",
                      }}
                    >
                      <List>
                        {item.subItems.map((subItem) => (
                          <ListItem
                            button
                            key={subItem.text}
                            onClick={() => {
                              if (subItem.path) {
                                router.push(`${subItem.path}`);
                              }
                            }}
                          >
                            <Typography
                              sx={{
                                fontWeight: "bold",
                                color: isSelected(subItem) ? "red" : "black",
                                fontSize: 14,
                              }}
                              variant="subtitle1"
                            >
                              {subItem.text}
                            </Typography>
                          </ListItem>
                        ))}
                      </List>
                    </Popover>
                  )
              )}
            </div>
          </DrawerStyle>

          {drawerOpen ? (
            <IconButton
              onClick={handleDrawerToggle}
              style={{
                position: "absolute",
                top: "14px",
                left: drawerOpen ? 232 : 55,
                backgroundColor: "#ffffff",
                borderRadius: "100%",
                zIndex: 1200,
                boxShadow: "1px 1px 3px 2px #d3d3d3", // Applying shadow with custom color
                padding: "3px",
              }}
            >
              <IconExpand />
            </IconButton>
          ) : (
            <IconButton
              onClick={handleDrawerToggle}
              style={{
                position: "absolute",
                top: "14px",
                left: drawerOpen ? 229 : 66,
                backgroundColor: "#ffffff",
                borderRadius: "100%",
                zIndex: 1200,
                boxShadow: "1px 1px 3px 2px #d3d3d3", // Applying shadow with custom color
                padding: "3px",
                transform: "rotateY(-180deg)",
              }}
            >
              <IconExpand />
            </IconButton>
          )}
          <main
            className="flex-grow transition-all"
            style={{
              height: "100vh",
              maxWidth: "100%",
              transition: "transform 0.2s ease, max-width 0.2s ease",
              overflow: "hidden",
              padding: drawerOpen ? "10px" : "20px",
            }}
          >
            <Toolbar />
            {!props?.hideHeader && <Typography variant="h1" sx={{ fontSize: "24px" }}>
              {nameMenu[nameMenu.length - 1]?.altText ?? nameMenu[nameMenu.length - 1]?.text}
            </Typography>}
            {!props.hideHeader && <BreadcrumbNavigation />}
            {/* <div style={{ height: "39px" }} /> */}

            <div
              className="transition-all"
              style={{
                maxWidth: "100%",
                transition: "max-width 0.2s ease",
                height: `calc(100vh - ${props?.hideHeader ? 140 : (props?.noFooterBtn ? 160 : 200)}px)`,
                overflow: "auto",
                position: "relative",
              }}
            >
              <AuthorityCheckWrapper>{children}</AuthorityCheckWrapper>
            </div>
          </main>
          {appContext?.me && <RemindPopup />}
        </Box>
      )}
    </>
  );
}

export default DashboardLayout;
