/* eslint-disable @next/next/no-img-element */
"use client";
import { IconLogout } from "@/assets/iconMenu/IconLogout";
import { IconSearch } from "@/assets/iconMenu/IconSearch";
import { COLOR_TYPE } from "@/constants/color";
import { ClearTokenCookies, cookieSetting } from "@/utils";

import {
  getTotalUnread
} from "@/apis/service/reminder_template/ReminderTemplate";
import { AppContext } from "@/context/AppContext";
import { useMsal } from "@azure/msal-react";
import {
  AppBar,
  Avatar,
  Badge,
  Box,
  Button,
  IconButton,
  Popover,
  Toolbar,
  Typography
} from "@mui/material";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import NotificationPopup from "../commons/remind/NotificationPopup";
type AppBarProps = {
  drawerOpen: boolean;
  handleDrawerToggle: () => void;
};

type PopoverContent = "notification" | "account";

export const AppBars = (props: AppBarProps) => {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();

  const { drawerOpen, handleDrawerToggle } = props;
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [activeContent, setActiveContent] = useState<PopoverContent>("account");

  const totalUnreadQuery = useQuery({
    queryKey: ["notification/total-unread"],
    queryFn: () => getTotalUnread().catch(() => ({ totalUnread: null })),
    staleTime: 120000,
  });

  // const [user, setUser] = useState<UserProfileDTO | undefined>(undefined);
  const { instance } = useMsal();

  const handleLogout = () => {
    const typeOfLogin = cookieSetting.get("TYPE");
    if (typeOfLogin == "MS365") {
      ClearTokenCookies();
      instance.logoutPopup({
        postLogoutRedirectUri: '/auth/login',
      }).then(() => {
        window.location.href = '/auth/login';
        queryClient.clear();
      }).catch(() => {
        window.location.href = '/auth/login';
        queryClient.clear();
      });
    } else {
      ClearTokenCookies();
      cookieSetting.clear("token");
      cookieSetting.clear("TYPE");
      router.push("/auth/login");
      queryClient.clear();
    }
  };
  const handleChangeLanguage = (type: string) => {
    i18n.changeLanguage(type);
  };
  const handleMenuClick = (
    event: React.MouseEvent<HTMLElement>,
    contentType: PopoverContent
  ) => {
    setAnchorEl(event.currentTarget);
    setActiveContent(contentType);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
    totalUnreadQuery.refetch();
  };
  const currentLanguage = i18n.language;

  return (
    <AppBar
      position="fixed"
      sx={{
        width: "100%", // Full width of the viewport
        transform: `translateX(${drawerOpen ? "15px" : "0px"})`, // Apply transform based on drawer state
        transition: "transform 0.2s ease-out, width 0.2s ease-out", // Smooth transitions
        boxShadow: "4px 0px 10px -2px rgba(0,0,0,0.1)", // Custom shadow
        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
        color: COLOR_TYPE.TOYOTA.TOYOTA2,
      }}
      className="  transition-all"
    >
      <Toolbar className="flex justify-between items-center">
        <div className="flex items-center">
          <IconButton
            edge="start"
            color="inherit"
            aria-label="menu"
            onClick={handleDrawerToggle}
            style={{
              marginLeft: drawerOpen ? 200 : 55,
            }}
          >
          </IconButton>
        </div>
        <div
          style={{
            display: "flex",
            justifyItems: "center",
            gap: 16,
            marginRight: "0.75%",
          }}
        >
          <IconButton
            color="inherit"
            onClick={(event) => handleMenuClick(event, "notification")}
          >
            <Badge
              badgeContent={totalUnreadQuery?.data?.totalUnread || null}
              color="error"
            >
              <IconSearch />
            </Badge>
          </IconButton>
          <Box
            display={"flex"}
            flexDirection={"row"}
            justifyItems={"center"}
            onClick={(event) => handleMenuClick(event, "account")}
          >
            <Avatar
              sx={{
                border: "1px solid #CCCCCC",
                backgroundColor: COLOR_TYPE.BLUE.BLUE6,
              }}
              alt={
                i18n.language === "vi"
                  ? appContext?.me?.name
                  : appContext.me?.nameEnglish
              }
              src={
                i18n.language === "vi"
                  ? appContext?.me?.name
                  : appContext.me?.nameEnglish
              }
            />
            <Box ml={2} className="flex flex-col items-start">
              <Box className="flex items-center">
                <Typography variant={"body2"} color={"primary.dark"}>
                  Welcome!
                </Typography>
              </Box>
              <Typography
                color={"primary.dark"}
                style={{
                  fontFamily:
                    "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
                }}
                variant="h5"
              >
                {i18n.language === "vi"
                  ? appContext?.me?.name
                  : appContext.me?.nameEnglish}
              </Typography>
            </Box>
            <IconButton>
              <svg
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M15.5891 6.91107C15.2637 6.58563 14.736 6.58563 14.4106 6.91107L9.99984 11.3218L5.58909 6.91107C5.26366 6.58563 4.73602 6.58563 4.41058 6.91107C4.08514 7.23651 4.08514 7.76414 4.41058 8.08958L9.70521 13.3842C9.86793 13.5469 10.1317 13.5469 10.2945 13.3842L15.5891 8.08958C15.9145 7.76414 15.9145 7.23651 15.5891 6.91107Z"
                  fill="#808080"
                />
              </svg>
            </IconButton>
          </Box>
        </div>
      </Toolbar>

      <Popover
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleCloseMenu}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          style: {
            // padding: "13px",
            backgroundColor: "white", // White background for the popup
            borderRadius: "8px", // Rounded corners
            boxShadow: "1px 4px 8px rgba(0,0,0,0.2)", // Slight shadow for better visibility
            minWidth: '180px'
          },
        }}
      >
        {activeContent === "account" ? (
          <Box p={'12px'}>
            <Box display="flex" alignItems="center" py={1} px={1} gap={2}>
              <Avatar
                sx={{
                  border: "1px solid #CCCCCC",
                  backgroundColor: COLOR_TYPE.BLUE.BLUE6,
                }}
                alt={
                  i18n.language === "vi"
                    ? appContext?.me?.name
                    : appContext.me?.nameEnglish
                }
                src={
                  i18n.language === "vi"
                    ? appContext?.me?.name
                    : appContext.me?.nameEnglish
                }
              />
              <Box>
                <Typography variant="h5" style={{ fontWeight: 700 }}>
                  {appContext?.me?.name}
                </Typography>
                <Typography variant="body2">{appContext?.me?.email}</Typography>
              </Box>
            </Box>

            <Box my={2} borderBottom="1px solid #ddd" />
            <Typography color="primary.dark" variant="h5">
              Language
            </Typography>
            <Box
              display="flex"
              justifyContent="center"
              flexDirection={"column"}
              gap={2}
            >
              <Button
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  padding: 1.5,
                  gap: 2,
                  width: "100%",

                  backgroundColor:
                    currentLanguage === "vi" ? "rgba(255, 0, 0, 0.1)" : "transparent",
                  textTransform: "none",
                  fontWeight: currentLanguage === "vi" ? "bold" : "normal",
                  color:
                    currentLanguage === "vi" ? "primary.main" : "text.primary", // Optional: adjust color for selected state
                }}
                onClick={() => handleChangeLanguage("vi")}
              >
                <img
                  src="https://flagcdn.com/48x36/vn.png"
                  width="40"
                  height="30"
                  alt="Vietnam"
                />
                <Box
                  sx={{
                    width: "40px",
                  }}
                  whiteSpace={"nowrap"}
                >
                  <Typography color="primary.dark" variant="h5">
                    {t("common.language.vietnamese")}
                  </Typography>
                </Box>
              </Button>
              <Button
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  padding: 1.5,
                  gap: 2,
                  width: "100%",
                  backgroundColor:
                    currentLanguage === "en" ? "rgba(255, 0, 0, 0.1)" : "transparent",
                  textTransform: "none",
                  fontWeight: currentLanguage === "en" ? "bold" : "normal",
                  color:
                    currentLanguage === "en" ? "primary.main" : "text.primary",
                }}
                onClick={() => handleChangeLanguage("en")}
              >
                <img
                  src="https://flagcdn.com/48x36/us.png"
                  width="40"
                  height="30"
                  alt="United States"
                />
                <Box
                  sx={{
                    width: "40px",
                  }}
                  whiteSpace={"nowrap"}
                >
                  <Typography color="primary.dark" variant="h5">
                    {t("common.language.english")}
                  </Typography>
                </Box>
              </Button>
            </Box>
            <Box
              display={"flex"}
              width={"100%"}
              justifyContent={"center"}
              marginTop={5}
            >
              <Button
                sx={{
                  display: "flex",
                  gap: 2,
                  textTransform: "none",
                  fontWeight: currentLanguage === "en" ? "bold" : "normal",
                  color:
                    currentLanguage === "en" ? "primary.main" : "text.primary", // Optional: adjust color for selected state
                }}
                onClick={() => handleLogout()}
              >
                <IconLogout />
                <Typography color="primary.dark" variant="subtitle1">
                  {t("common.button.logout")}
                </Typography>
              </Button>
            </Box>
          </Box>
        ) : (
          <NotificationPopup
            handleCloseMenu={handleCloseMenu}
            unreadData={totalUnreadQuery?.data} />
        )}
      </Popover>
    </AppBar >
  );
};
