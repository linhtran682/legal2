// Breadcrumb.tsx
import React from "react";
import { MenuItem } from "./Menu"; // Ensure proper import
import { useRouter } from "next/router";
import { Box, Link, Typography } from "@mui/material";
import useMenu from "./Menu";
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
interface BreadcrumbItem {
  text: string;
  path?: string;
  altText?: string;
}

export function findBreadcrumb(
  menu: MenuItem[],
  pathname: string
): BreadcrumbItem[] {
  const breadcrumb: BreadcrumbItem[] = [];

  function matchPath(itemPath: string, currentPath: string): boolean {
    const itemSegments = itemPath.split("/").filter(Boolean);
    const currentSegments = currentPath.split("/").filter(Boolean);

    if (itemSegments.length !== currentSegments.length) return false;

    return itemSegments.every((segment, index) => {
      return segment.startsWith(":") || segment === currentSegments[index];
    });
  }

  function traverse(
    menuItems: MenuItem[],
    parentPaths: BreadcrumbItem[] = []
  ): boolean {
    for (const item of menuItems) {
      const currentPaths = [
        ...parentPaths,
        { text: item.text, path: item.path, altText: item.altText },
      ];
      if (item.path && matchPath(item.path, pathname)) {
        breadcrumb.push(...currentPaths);
        if (item.subItems) {
          for (const subItem of item.subItems) {
            if (subItem?.path && matchPath(subItem?.path, pathname)) {
              breadcrumb.push({ text: subItem.text, path: subItem.path, altText: item.altText });
              return true;
            }
          }
        }
        return true;
      }
      if (item.subItems && traverse(item.subItems, currentPaths)) {
        return true;
      }
    }
    return false;
  }

  traverse(menu);
  return breadcrumb;
}
const Breadcrumb: React.FC = () => {
  const router = useRouter();
  const MENU = useMenu();

  const { pathname } = router;
  const breadcrumb = findBreadcrumb(MENU, pathname);
  return (
    <Box
      component="nav"
      aria-label="breadcrumb"
      style={{ marginBottom: 11, fontSize: 16, marginTop: 4 }}
    >
      <Box
        component="ol"
        sx={{
          display: "flex",
          flexWrap: "wrap",
          p: 0,
          m: 0,
          listStyle: "none",
        }}
      >
        {breadcrumb.map((item, index) => (
          <Box
            component="li"
            key={index}
            sx={{
              display: "flex",
              alignItems: "center",
              mr: 0.5,
            }}
          >
            {item.path && index < breadcrumb.length - 1 ? (
              <Link
                href={item.path}
                underline="hover"
                style={{ color: "#808080" }}
              >
                {item.text}
              </Link>
            ) : index < breadcrumb.length - 1 ? (
              <Typography style={{ color: "#808080", fontSize: 16 }}>{item.text}</Typography>
            ) : (
              <Typography color="primary.main" style={{ fontSize: 16 }}>{item.text}</Typography>
            )}
            {index < breadcrumb.length - 1 && (
              <Typography sx={{ mx: 0.5 }} style={{ color: "#808080" }}>
                <KeyboardArrowRightIcon style={{ fontSize: 20 }} />
              </Typography>
            )}
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default Breadcrumb;
