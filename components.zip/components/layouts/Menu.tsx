import { IconCategories } from "@/assets/iconMenu/IconCategories";
import { DepartmentManagementIcon } from "@/assets/iconMenu/IconDepartmentManagement";
import HomeIcon from "@mui/icons-material/Home";
import { useTranslation } from "react-i18next";
import { IconLawDocument } from "@/assets/iconMenu/IconLawDocument";
import { DocumentManagementIcon } from "@/assets/iconMenu/IconDocumentDepartment";

import { IconLegalAdvice } from "@/assets/iconMenu/IconLegalAdvice";
import { IconConflictManagement } from "@/assets/iconMenu/iconConflictManagement";
import { IconDocumentReview } from "@/assets/iconMenu/IconDocumentReview";
import { IconDocumentViolation } from "@/assets/iconMenu/IconDocumentViolation";
import { IconRelationshipDisclosure } from "@/assets/iconMenu/IconRelationshipDisclosure";
import { VisitationtIcon } from "@/assets/iconMenu/IconVisitation";
import { IconSetting } from "@/assets/iconMenu/IconSetting";
export interface MenuItem {
  text: string;
  altText?: string;
  path?: string;
  level?: number;
  icon?: JSX.Element;
  subItems?: MenuItem[];
  isSingleLevel?: boolean;
}
const useMenu = (): MenuItem[] => {
  const { t } = useTranslation();
  return [
    { text: t("menu.home"), icon: <HomeIcon />, path: "/", level: 1 },
    {
      text: t("menu.legalDocument"),
      icon: <IconLawDocument />,
      path: "/legal-document/list",
      level: 1,
      isSingleLevel: true,
      subItems: [
        { text: t("menu.listLawDocument"), path: "/legal-document/list" },
        {
          text: t("menu.createLegalDocument"),
          path: "/legal-document/create",
        },
        {
          text: t("menu.detailLegalDocument"),
          path: "/legal-document/update/[id]",
        },
        {
          text: t("menu.detailLegalDocument"),
          subItems: [
            {
              text: t("menu.legalDocumentAction.requestNextAction"),
              path: "/legal-document/[documentId]/request-next-action/[documentName]",
            },
            {
              text: t("menu.legalDocumentAction.approveNextAction"),
              path: "/legal-document/[documentId]/update-next-action/[id]",
            },
          ],
        },
        {
          text: t("menu.legalDocumentAction.approveNextAction"),
          path: "/legal-document/[documentId]/approve-next-action/[nextActionCreatorId]/[requestApprovalId]",
        },
      ],
    },
    {
      text: t("menu.legalAdvice"),
      icon: <IconLegalAdvice />,
      path: "/legal-advice/list",
      level: 1,
      isSingleLevel: true,
      subItems: [
        { text: t("menu.listLegalAdvice"), path: "/legal-advice/list" },
        {
          text: t("menu.legalAdviceCreate"),
          path: "/legal-advice/create",
        },
        {
          text: t("menu.legalAdviceUpdate"),
          path: "/legal-advice/update/[id]",
        },
      ],
    },
    {
      text: t("menu.documentReviewRequest"),
      icon: <IconDocumentReview />,
      path: "/document-review/list",
      level: 1,
      isSingleLevel: true,
      subItems: [
        { text: t("menu.documentReviewRequestList"), path: "/document-review/list", },
        {
          text: t("menu.documentReviewRequestCreate"),
          path: "/document-review/create",
        },
        {
          text: t("menu.documentReviewRequestUpdate"),
          path: "/document-review/update/[id]",
        }
      ],
    },
    {
      text: t("menu.violationTracking"),
      icon: <IconDocumentViolation />,
      level: 1,
      path: "/violation_tracking/list",
      isSingleLevel: true,
      subItems: [
        {
          text: t("followViolation.title"),
          path: "/violation_tracking/list",
        },
        {
          text: t("menu.followViolationCreate"),
          path: "/violation_tracking/create",
        },
        {
          text: t("menu.followViolationUpdate"),
          path: "/violation_tracking/update/[id]",
        },
      ],
    },
    {
      text: t("menu.documentManagement"),
      icon: <DocumentManagementIcon />,
      level: 1,
      path: "/document_management/list",
      isSingleLevel: true,
      subItems: [
        {
          text: t("menu.documentManagementList"),
          path: "/document_management/list",
        },
        {
          text: t("menu.documentManagementList"),
          path: "/document_management/list/[id]",
        },
        {
          text: t("menu.documentManagementCreate"),
          path: "/document_management/create/[id]",
        },
        {
          text: t("menu.documentManagementUpdate"),
          path: "/document_management/update/[id_Stock]/[id]",
        },
        {
          text: t("menu.stockcreate"),
          path: "/document_management/stock/[id]",
        },
        {
          text: t("menu.stockupdate"),
          path: "/document_management/stock_update/[id]",
        },
      ],
    },
    {
      text: t("menu.visitation"),
      icon: <VisitationtIcon />,
      path: "/visitation/list",
      level: 1,
      isSingleLevel: true,
      subItems: [
        { text: t("menu.visitationList"), path: "/visitation/list" },
        {
          text: t("menu.visitationCreate"),
          path: "/visitation/create",
        },
        {
          text: t("menu.visitationUpdate"),
          path: "/visitation/update/[id]",
        },
      ],
    },
    {
      text: t("menu.conflictManagement"),
      icon: <IconConflictManagement />,
      path: "/conflict-management/list",
      level: 1,
      isSingleLevel: true,
      subItems: [
        { text: t("menu.conflictManagementList"), path: "/conflict-management/list" },
        {
          text: t("menu.conflictManagementCreate"),
          path: "/conflict-management/create",
        },
        {
          text: t("menu.conflictManagementUpdate"),
          path: "/conflict-management/update/[id]",
        },
      ],
    },
    {
      text: t("menu.relationshipDisclosure"),
      icon: <IconRelationshipDisclosure />,
      path: "/relationship-disclosure/list",
      level: 1,
      isSingleLevel: true,
      subItems: [
        { text: t("menu.relationshipDisclosureList"), path: "/relationship-disclosure/list" },
        {
          text: t("menu.relationshipDisclosureCreate"),
          path: "/relationship-disclosure/create",
        },
        {
          text: t("menu.relationshipDisclosureUpdate"),
          path: "/relationship-disclosure/update/[id]",
        },
      ],
    },
    {
      text: t("menu.manageCategories"),
      icon: <IconCategories />,
      level: 1,
      subItems: [
        {
          text: t("menu.documentType"),
          path: "/document-type/list",
          level: 2,
          subItems: [
            { text: t("menu.documentTypeList"), path: "/document-type/list" },
            {
              text: t("menu.documentTypeCreate"),
              path: "/document-type/create",
            },
            {
              text: t("menu.documentTypeUpdate"),
              path: "/document-type/update/[id]",
            },
          ],
        },
        {
          text: t("menu.field"),
          path: "/field/list",
          level: 2,
          subItems: [
            { text: t("menu.fieldList"), path: "/field/list" },
            { text: t("menu.fieldCreate"), path: "/field/create" },
            { text: t("menu.fieldUpdate"), path: "/field/update/[id]" },
          ],
        },
        {
          text: t("menu.agencyIssued"),
          path: "/agency-issued/list",
          level: 2,
          subItems: [
            { text: t("menu.agencyIssuedList"), path: "/agency-issued/list" },
            {
              text: t("menu.agencyIssuedCreate"),
              path: "/agency-issued/create",
            },
            {
              text: t("menu.agencyIssuedUpdate"),
              path: "/agency-issued/update/[id]",
            },
          ],
        },
        {
          text: t("menu.reminder"),
          path: "/reminder-template/list",
          level: 2,
          subItems: [
            { text: t("menu.reminderList"), path: "/reminder-template/list" },
            {
              text: t("menu.reminderCreate"),
              path: "/reminder-template/create",
            },
            {
              text: t("menu.reminderUpdate"),
              path: "/reminder-template/update/[id]",
            },
          ],
        },
        // {
        //   text: t("menu.status"),
        //   path: "/status/list",
        //   level: 2,
        //   subItems: [
        //     { text: t("menu.statusList"), path: "/status/list" },
        //     { text: t("menu.statusCreate"), path: "/status/create" },
        //     { text: t("menu.statusUpdate"), path: "/status/update/[id]" },
        //   ],
        // },
        {
          text: t("menu.help"),
          path: "/help/list",
          level: 2,
          subItems: [
            { text: t("menu.helpList"), path: "/help/list" },
            { text: t("menu.helpCreate"), path: "/help/create" },
            { text: t("menu.helpUpdate"), path: "/help/update/[id]" },
          ],
        },
        {
          text: t("menu.currency"),
          path: "/currency/list",
          level: 2,
          subItems: [
            { text: t("menu.currencyList"), path: "/currency/list" },
            { text: t("menu.currencyCreate"), path: "/currency/create" },
            { text: t("menu.currencyUpdate"), path: "/currency/update/[id]" },
          ],
        },
      ],
    },
    {
      text: t("menu.departmentManagement"),
      icon: <DepartmentManagementIcon />,
      level: 1,
      subItems: [
        {
          text: t("menu.department"),
          path: "/department/list",
          level: 2,
        },
        {
          text: t("menu.assignment"),
          path: "/assignment/list",
          level: 2,
          subItems: [
            { text: t("menu.assignmentList"), path: "/assignment/list" },
            { text: t("menu.assignmentCreate"), path: "/assignment/create" },
            {
              text: t("menu.assignmentUpdate"),
              path: "/assignment/update/[id]",
            },
          ],
        },
        {
          text: t("menu.role"),
          path: "/role/list",
          level: 2,
          subItems: [
            { text: t("menu.roleList"), path: "/role/list" },
            { text: t("menu.roleCreate"), path: "/role/create" },
            { text: t("menu.roleUpdate"), path: "/role/update/[id]" },
          ],
        },
        {
          text: t("menu.user"),
          path: "/user/list",
          level: 2,
          subItems: [
            { text: t("menu.userList"), path: "/user/list" },
            { text: t("menu.userCreate"), path: "/user/create" },
            { text: t("menu.userView"), path: "/user/view/[id]" },
            { text: t("menu.userUpdate"), path: "/user/update/[id]" },
          ],
        },
      ],
    },
    {
      text: t("menu.statistic"),
      icon: <IconCategories />,
      level: 1,
      subItems: [
        {
          text: t("menu.legalDocument"),
          path: "/statistics-legal-doc",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticLegalDocument"),
              path: "/statistics-legal-doc"
            },
            {
              text: t("menu.statisticLegalDocumentReport"),
              path: "/statistics-legal-doc/report"
            },
            {
              text: t("menu.statisticLegalDocumentReportSlowEvaluate"),
              path: "/statistics-legal-doc/report-slow-evaluate"
            },
            {
              text: t("menu.statisticLegalDocumentReportNoEvaluate"),
              path: "/statistics-legal-doc/report-no-evaluate"
            },
            {
              text: t("menu.statisticLegalDocumentReportDone"),
              path: "/statistics-legal-doc/report-done"
            },
            {
              text: t("menu.statisticLegalDocumentReportFollowing"),
              path: "/statistics-legal-doc/report-following"
            },
            {
              text: t("menu.statisticLegalDocumentReportEffective"),
              path: "/statistics-legal-doc/report-effective"
            }
          ]
        },
        {
          text: t("menu.legalAdvice"),
          path: "/statistics-legal-adv",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticLegalAdvice"),
              path: "/statistics-legal-adv"
            },
            {
              text: t("menu.statisticLegalAdviceReport"),
              path: "/statistics-legal-adv/report"
            },
            {
              text: t("menu.statisticLegalAdviceReportDone"),
              path: "/statistics-legal-adv/report-done"
            }
          ]
        },
        {
          text: t("menu.requestReviewDocument"),
          path: "/statistics-document-rev",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticDocumentReview"),
              path: "/statistics-document-rev"
            },
            {
              text: t("menu.statisticDocumentReviewReport"),
              path: "/statistics-document-rev/report"
            },
            {
              text: t("menu.statisticDocumentReviewReportDone"),
              path: "/statistics-document-rev/report-done"
            },
            {
              text: t("menu.statisticDocumentReviewBackdateRequest"),
              path: "/statistics-document-rev/report-backdate-request"
            },
            {
              text: t("menu.statisticDocumentReviewBackdate"),
              path: "/statistics-document-rev/report-backdate"
            }
          ]
        },
        {
          text: t("menu.violationTracking"),
          path: "/statistics-violation-track",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticViolationTracking"),
              path: "/statistics-violation-track"
            },
            {
              text: t("menu.statisticViolationTrackingReport"),
              path: "/statistics-violation-track/report"
            },
            {
              text: t("menu.statisticViolationTrackingReportDone"),
              path: "/statistics-violation-track/report-next-action"
            },
            {
              text: t("menu.statisticViolationTrackingReportDone"),
              path: "/statistics-violation-track/report-done"
            },
            {
              text: t("menu.statisticViolationTrackingReportDone"),
              path: "/statistics-violation-track/report-following"
            }
          ]
        },
        {
          text: t("menu.documentManagement"),
          path: "/statistics-document-mng",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticDocumentManagement"),
              path: "/statistics-document-mng"
            },
            {
              text: t("menu.statisticDocumentManagementReport"),
              path: "/statistics-document-mng/report"
            },
            {
              text: t("menu.statisticDocumentManagementLate"),
              path: "/statistics-document-mng/report-late"
            },
            {
              text: t("menu.statisticDocumentManagementForget"),
              path: "/statistics-document-mng/report-forget"
            }
          ]
        },
        {
          text: t("menu.conflictManagement"),
          path: "/statistics-conflict-mng",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticConflictMng"),
              path: "/statistics-conflict-mng"
            },
            {
              text: t("menu.statisticConflictMngReport"),
              path: "/statistics-conflict-mng/report"
            },
            {
              text: t("menu.statisticConflictMngReportComplete"),
              path: "/statistics-conflict-mng/report-done"
            }
          ]
        },
        {
          text: t("menu.relationshipDisclosure"),
          path: "/statistics-relationship-dis",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticRelationshipMng"),
              path: "/statistics-relationship-dis"
            },
            {
              text: t("menu.statisticRelationshipMngReport"),
              path: "/statistics-relationship-dis/report"
            },
            {
              text: t("menu.statisticRelationshipMngReportComplete"),
              path: "/statistics-relationship-dis/report-done"
            }
          ]
        },
        {
          text: t("menu.visitation"),
          path: "/statistics-visit",
          level: 2,
          subItems: [
            {
              text: t("menu.statisticVisitation"),
              path: "/statistics-visit"
            },
            {
              text: t("menu.statisticVisitationReport"),
              path: "/statistics-visit/report"
            },
            {
              text: t("menu.statisticVisitationReportDone"),
              path: "/statistics-visit/report-done"
            }
          ]
        },
      ]
    },
    {
      text: t("menu.setting"),
      icon: <IconSetting />,
      level: 1,
      subItems: [
        {
          text: t("menu.settingEmail"),
          path: "/setting/mail/list",
          level: 2,
        },
        {
          text: t("menu.settingLog"),
          path: "/log_setting/detail",
          level: 2,
        },
        {
          text: t("menu.auditLog"),
          path: "/audit_log/list",
          level: 2,
          subItems: [
            { text: t("menu.auditLogList"), path: "/audit_log/list" },
            { text: t("menu.auditLogDetail"), path: "/audit_log/view/[id]" },
          ],
        },
      ]
    }
  ];
};

export default useMenu;
