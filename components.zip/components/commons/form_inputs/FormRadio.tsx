import {
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  Radio,
  RadioGroup,
  FormGroup,
  InputLabel,
} from "@mui/material";
import { Control, Controller, FieldValues, Path } from "react-hook-form";
import { useTranslation } from "react-i18next";

// Updated interface to support grouped options
export interface RadioOption {
  value: boolean;
  label: string;
}

export interface RadioGroupOption {
  groupLabel?: string; // Optional group label
  options: RadioOption[];
}

export interface FormRadioProps<T extends FieldValues> {
  name: Path<T>;
  control: Control<T>;
  label?: string;
  radioOptions: Array<RadioOption | RadioGroupOption>; // Either flat options or grouped
  rules?: Record<string, unknown>;
  size?: "small" | "medium";
  required?: boolean;
  explanation?: string;
  disabled?: boolean;
}

export const FormRadio = <T extends FieldValues>({
  name,
  control,
  label,
  radioOptions,
  rules,
  size = "medium",
  required,
  disabled,
}: FormRadioProps<T>) => {
  const [t] = useTranslation();
  const { error } = control.getFieldState(name);

  const renderRadioOptions = (options: Array<RadioOption>, groupLabel?: string) => (
    <>
      {groupLabel && <FormLabel>{groupLabel}</FormLabel>}
      {options.map((option, index) => (
        <FormControlLabel
        style={{paddingLeft: 50}}
          key={index}
          value={option.value}
          control={<Radio size={size} />}
          label={option.label}
        />
      ))}
    </>
  );

  return (
    <FormControl
      component="fieldset"
      fullWidth
      disabled={disabled}
      error={!!error}
    >
      {label && (
        <InputLabel component="legend" required={required} shrink>
          {label}
        </InputLabel>
      )}

      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field }) => (
          <RadioGroup
            {...field}
            onChange={(e) => field.onChange(e.target.value)} // Pass the new value to the field
            value={field.value || ""} // Ensure `field.value` is not undefined
            row={true}
          >
            {radioOptions.map((option, index) =>
              "options" in option ? (
                <FormGroup key={option.groupLabel || "group"}>
                  {renderRadioOptions(option.options, option.groupLabel)}
                </FormGroup>
              ) : (
                <FormControlLabel
                  key={index}
                  value={option.value}
                  control={<Radio size={size} />}
                  label={option.label}
                />
              )
            )}
          </RadioGroup>
        )}
      />

      {error?.message && (
        <FormHelperText>
          {t(error.message, { fieldName: label })}
        </FormHelperText>
      )}
    </FormControl>
  );
};