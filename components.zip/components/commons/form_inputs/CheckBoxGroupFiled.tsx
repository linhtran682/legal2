import * as React from "react";
import {
  Box,
  Checkbox,
  CheckboxProps,
  FormControl,
  FormControlLabel,
  FormHelperText,
  Tooltip,
  Typography,
  styled,
} from "@mui/material";
import { Controller, useFormContext } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { ControllerFieldForm } from "./RadioGroupField";
import HelpIcon from "@mui/icons-material/Help";
import { COLOR_TYPE } from "@/constants/color";

export type CheckboxItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

type CheckboxGroupFieldProps = ControllerFieldForm<CheckboxProps> & {   
  items: CheckboxItem[];
  label?: string;
  required?: boolean;
  disabled?: boolean;
  onChangeCheckboxGroup?: (value: (string | number | boolean)[]) => void;
  isDisabled?: boolean;
  defaultValue?: (string | number | boolean)[];
  explanation?: string;
  errors?: any
};

const TypographyNodataSC = styled(Typography)(() => ({
  marginTop: 10,
}));

export const CheckBoxGroupField = (props: CheckboxGroupFieldProps) => {
  const {
    name,
    label,
    items = [],
    onChangeCheckboxGroup,
    isDisabled = false,
    defaultValue = [],
    explanation,
    disabled,
    required,
    errors
  } = props;
  const { t } = useTranslation();
  const { control } = useFormContext();
  return (
    <FormControl
      component="fieldset"
      fullWidth
      disabled={disabled}
      error={!!errors}
    >
      <label className={label ?? "no-label"}>
        {label}{" "}
        {explanation && (
          <Tooltip title={explanation} placement="top-start">
            <HelpIcon fontSize={"small"} />
          </Tooltip>
        )}
        {required && <span style={{ color: "red" }}>*</span>}
      </label>
      <Controller
        name={name}
        control={control}
        defaultValue={defaultValue}
        render={({ field: { onChange, value = [], ref, ...otherFields } }) => {
          const handleChange = (checkedValue: string | number | boolean) => {
            const newValue = value.includes(checkedValue)
              ? value.filter((val: any) => val !== checkedValue)
              : [...value, checkedValue];

            onChange(newValue);
            onChangeCheckboxGroup?.(newValue);
          };

          return (
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              {items.length > 0 ? (
                items.map(({ value: itemValue, label }, index) => (
                  <FormControlLabel
                    key={index}
                    control={
                      <Checkbox
                        icon={
                          <span
                            style={{
                              width: 20,
                              height: 20,
                              display: "inline-block",
                              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                              border: `2px solid ${COLOR_TYPE.TOYOTA.TOYOTA1}`,
                              borderRadius: "6px",
                            }}
                          />
                        }
                        checkedIcon={
                          <span
                            style={{
                              width: 20,
                              height: 20,
                              backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA1}`,
                              borderRadius: "6px",
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                            }}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 24 24"
                              fill="white"
                              width={`${0.8 * 20}px`}
                              height={`${0.8 * 20}px`}
                            >
                              <path
                                d="M19.77 5.23c.29.3.29.77 0 1.06l-11 11c-.3.3-.77.3-1.06 0l-5-5c-.29-.3-.29-.77 0-1.06s.77-.29 1.06 0l4.47 4.47 10.47-10.47c.29-.29.77-.29 1.06 0z"
                                stroke="white"
                                strokeWidth={1}
                              />
                            </svg>
                          </span>
                        }
                        checked={value.includes(itemValue)}
                        onChange={() => handleChange(itemValue)}
                        disabled={isDisabled}
                        inputRef={ref}
                        {...otherFields}
                      />
                    }
                    label={label}
                  />
                ))
              ) : (
                <TypographyNodataSC>
                  {t("general.common.noDataCheckbox")}
                </TypographyNodataSC>
              )}
            </Box>
          );
        }}
      />
      {errors?.message && (
        <FormHelperText>
          {t(errors?.message, { fieldName: label })}
        </FormHelperText>
      )}
    </FormControl>
  );
};
