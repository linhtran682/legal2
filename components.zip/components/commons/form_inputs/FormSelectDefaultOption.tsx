import React, { useState } from "react";
import { Controller, FieldValues } from "react-hook-form";
import { FormTextFieldProps } from "./FormTextField";
import {
  Button,
  ClickAwayListener,
  Divider,
  IconButton,
  MenuItem,
  Paper,
  Popper,
  Tooltip,
} from "@mui/material";
import HelpIcon from "@mui/icons-material/Help";
// import { useTranslation } from "react-i18next";

import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";

export interface FormSelectProps<T extends FieldValues, Option>
  extends FormTextFieldProps<T> {
  options: Option[];
  getOptionLabel: (option: Option) => string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getOptionKey: (option: Option) => any;
  isClearIcon?: boolean;
}

export const FormSelectDefaultOption = <T extends FieldValues, Option>({
  name,
  control,
  label,
  rules,
  options,
  getOptionKey,
  getOptionLabel,
  required,
  explanation,
  disabled,
}: FormSelectProps<T, Option>) => {
  //   const [t] = useTranslation();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [open, setOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Option | undefined>(
    undefined
  );
  const handleClickAway = () => {
    setAnchorEl(null);
    setOpen(false);
  };
  const handleSelectClick = (event: React.MouseEvent<HTMLElement>) => {
    if (open) {
      setAnchorEl(null);
      setOpen(false);
    } else {
      setAnchorEl(event.currentTarget);
      setOpen(true);
    }
  };
  const handleOptionChange = (
    option: any,
    onChangeCallback: (value: number) => void
  ) => {
    setSelectedItem(option);
    onChangeCallback(option?.value);
    setOpen(false);
  };

  const renderNode = (
    option: Option,
    onChangeCallback: (value: any) => void
  ): JSX.Element => {
    const label = getOptionLabel(option);
    const isSelected =
      selectedItem && getOptionKey(selectedItem) === getOptionKey(option);
    return (
      <>
        <MenuItem
          onClick={() => {
            handleOptionChange(option, onChangeCallback);
          }}
          selected={isSelected ? true : false}
        >
          <Button
            variant="outlined"
            style={{
              background: "none",
              borderRadius: "100px",
              color: "#101010",
              border: "none",
            }}
          >
            {label}
          </Button>
        </MenuItem>
        <Divider
          sx={{ marginTop: "0 !important", marginBottom: "0 !important" }}
        />
      </>
    );
  };
  return (
    <>
      <ClickAwayListener onClickAway={handleClickAway}>
        <div style={{ display: "flex", flexDirection: "row", width: "100%" }}>
          <Controller
            name={name}
            control={control}
            rules={rules}
            render={({ field }) => {
              const findValue = (options ?? []).find(
                (item: any) => item.value === field.value
              );
              if (findValue) {
                setSelectedItem(findValue);
              }

              return (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    width: "100%",
                    alignItems: "center",
                  }}
                >
                  {" "}
                  <label className={label ?? "no-label"}>
                    {label}{" "}
                    {explanation && (
                      <Tooltip title={explanation} placement="top-start">
                        <HelpIcon fontSize={"small"} />
                      </Tooltip>
                    )}
                    {required && <span style={{ color: "red" }}>*</span>}
                  </label>
                  <div
                    onClick={disabled ? undefined : handleSelectClick}
                    style={{
                      marginLeft: 10,
                      display: "flex",
                      flexDirection: "row",
                      gap: "10px",
                      flex: 1,
                    }}
                  >
                    {findValue ? (
                      <Button
                        variant="outlined"
                        style={{
                          background:
                            findValue &&
                            getOptionLabel(findValue)?.includes("Hoàn thành")
                              ? "#E7F4EE"
                              : "#D781001A",
                          borderRadius: "100px",
                          color:
                            findValue &&
                            getOptionLabel(findValue)?.includes("Hoàn thành")
                              ? "#0D894F"
                              : "#D78100",
                          border: "none",
                          padding: "4px 12px",
                        }}
                      >
                        {getOptionLabel(findValue)}
                      </Button>
                    ) : (
                      <Button
                        variant="outlined"
                        style={{
                          background:
                            field.value &&
                            getOptionLabel(field.value)?.includes("Hoàn thành")
                              ? "#E7F4EE"
                              : "#D781001A",
                          borderRadius: "100px",
                          color:
                            field.value &&
                            getOptionLabel(field.value)?.includes("Hoàn thành")
                              ? "#0D894F"
                              : "#D78100",
                          border: "none",
                          padding: "4px 12px",
                        }}
                      >
                        {field.value ? getOptionLabel(field.value) : ""}
                      </Button>
                    )}

                    <IconButton
                      size="small"
                      disabled={disabled}
                      style={{ visibility: disabled ? "hidden" : "visible" }}
                    >
                      {open ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
                    </IconButton>
                  </div>
                  <Popper
                    open={open}
                    anchorEl={anchorEl}
                    placement="bottom-start"
                    style={{
                      width: anchorEl?.clientWidth
                        ? anchorEl?.clientWidth / 2
                        : "auto",
                      zIndex: 1300,
                    }}
                    disablePortal
                  >
                    <Paper
                      elevation={3}
                      sx={{ borderRadius: "4px", width: "100%" }}
                    >
                      {(options ?? []).map((node: any) =>
                        renderNode(node, field.onChange)
                      )}
                    </Paper>
                  </Popper>
                </div>
              );
            }}
          />
        </div>
      </ClickAwayListener>
    </>
  );
};
