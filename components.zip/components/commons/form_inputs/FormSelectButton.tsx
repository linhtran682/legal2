import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  ClickAwayListener,
  Divider,
  IconButton,
  MenuItem,
  Paper,
  Popper,
  Tooltip,
} from "@mui/material";
import { Control, Controller, FieldValues, Path } from "react-hook-form";
import HelpIcon from "@mui/icons-material/Help";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import { useQuery } from "@tanstack/react-query";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
export interface FormAsyncSelectProps<T extends FieldValues, Option> {
  name: Path<T>;
  control: Control<T>;
  label?: string;
  placeholder?: string;
  rules?: Record<string, unknown>;
  variant?: "filled" | "outlined" | "standard";
  keyQuery: string;
  getOptions: (keyword: string | string[]) => Promise<Option[]>;
  getOptionLabel: (option: Option) => string;
  getOptionKey: (option: Option) => string;
  size?: "small" | "medium";
  required?: boolean;
  explanation?: string;
  groupBy?: (option: Option) => string;
  debounceMs?: number;
  minCharLength?: number;
  isOptionEqualToValue?: (option: Option, value: Option) => boolean;

  disabled?: boolean;
  initialValue?: Option;
  isFocus?: boolean;
}

export const FormSelectButton = <T extends FieldValues, Option>({
  name,
  control,
  label,
  keyQuery,
  getOptionKey,
  getOptionLabel,
  getOptions,
  required,
  explanation,
  debounceMs,
  disabled,
}: FormAsyncSelectProps<T, Option>) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [open, setOpen] = useState(false);

  const handleSelectClick = (event: React.MouseEvent<HTMLElement>) => {
    if (open) {
      setAnchorEl(null);
      setOpen(false);
    } else {
      setAnchorEl(event.currentTarget);
      setOpen(true);
    }
  };
  const handleClickAway = () => {
    setAnchorEl(null);
    setOpen(false);
  };
  const [selectedItem, setSelectedItem] = useState<Option | undefined>(
    undefined
  );
  const getOptionsQuery = useQuery({
    enabled: false,
    queryKey: [keyQuery, "suggestion"],
    queryFn: () => getOptions(""),
  });
  const debounceTimeout = useRef<NodeJS.Timeout>();

  const handleOptionChange = (
    option: any,
    onChangeCallback: (value: number) => void
  ) => {
    setSelectedItem(option);
    onChangeCallback(option?.id);
    setOpen(false);
  };
  useEffect(() => {
    clearTimeout(debounceTimeout.current);
    debounceTimeout.current = setTimeout(() => {
      getOptionsQuery.refetch();
    }, debounceMs ?? FILTER_DEBOUNCE_MS);
  }, [debounceMs, keyQuery]);

  const renderNode = (
    option: Option,
    onChangeCallback: (value: any) => void
  ): JSX.Element => {
    const label = getOptionLabel(option);

    const isSelected =
      selectedItem && getOptionKey(selectedItem) === getOptionKey(option);
    return (
      <>
        <MenuItem
          onClick={() => {
            handleOptionChange(option, onChangeCallback);
          }}
          selected={isSelected ? true : false}
        >
          <Button
            variant="outlined"
            style={{
              background: "none",
              borderRadius: "100px",
              color: "#101010",
              border: "none",
            }}
          >
            {label}
          </Button>
        </MenuItem>
        <Divider
          sx={{ marginTop: "0 !important", marginBottom: "0 !important" }}
        />
      </>
    );
  };
  return (
    <ClickAwayListener onClickAway={handleClickAway}>
      <div style={{ display: "flex", flexDirection: "row", width: "100%" }}>
        <Controller
          name={name}
          control={control}
          render={({ field }) => {
            const findValue = (getOptionsQuery.data ?? []).find(
              (item: any) => item.id === field.value
            );
            if (findValue) {
              setSelectedItem(findValue);
            }
            return (
              <div
                style={{ display: "flex", flexDirection: "row", width: "100%", alignItems: 'center' }}
              >
                {label && (
                  <label className={label ?? "no-label"}>
                    {label}
                    {explanation && (
                      <Tooltip title={explanation} placement="top-start">
                        <HelpIcon fontSize={"small"} />
                      </Tooltip>
                    )}
                    {required && <span style={{ color: "red" }}>*</span>}
                  </label>
                )}
                <div
                  onClick={disabled ? undefined : handleSelectClick}
                  style={{
                    marginLeft: 10,
                    display: "flex",
                    flexDirection: "row",
                    gap: "10px",
                    flex: 1,
                  }}
                >
                  {findValue ? (
                    <Button
                      variant="outlined"
                      style={{
                        background:
                          findValue &&
                            getOptionLabel(findValue) === "Hoàn thành"
                            ? "#E7F4EE"
                            : "#D781001A",
                        borderRadius: "100px",
                        color:
                          findValue &&
                            getOptionLabel(findValue) === "Hoàn thành"
                            ? "#0D894F"
                            : "#D78100",
                        border: "none",
                        padding: "4px 12px",
                      }}
                    >
                      {getOptionLabel(findValue)}
                    </Button>
                  ) : (
                    <Button
                      variant="outlined"
                      style={{
                        background:
                          field.value &&
                            getOptionLabel(field.value) === "Hoàn thành"
                            ? "#E7F4EE"
                            : "#D781001A",
                        borderRadius: "100px",
                        color:
                          field.value &&
                            getOptionLabel(field.value) === "Hoàn thành"
                            ? "#0D894F"
                            : "#D78100",
                        border: "none",
                        padding: "4px 12px",
                      }}
                    >
                      {field.value ? getOptionLabel(field.value) : ""}
                    </Button>
                  )}

                  <IconButton size="small" disabled={disabled} style={{ visibility: disabled ? 'hidden' : 'visible' }}>
                    {open ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
                  </IconButton>
                </div>
                <Popper
                  open={open}
                  anchorEl={anchorEl}
                  placement="bottom-start"
                  style={{
                    width: anchorEl?.clientWidth
                      ? anchorEl?.clientWidth / 2
                      : "auto",
                     zIndex: 1300,
                     
                  }}
                >
                  <Paper
                    elevation={3}
                    sx={{ borderRadius: "4px", width: "100%", 
                      maxHeight: "238px", 
                    overflowY: "auto", 
                     }}
                  >
                    {(getOptionsQuery.data ?? []).map((node: any) =>
                      renderNode(node, field.onChange)
                    )}
                  </Paper>
                </Popper>
              </div>
            );
          }}
        />
      </div>
    </ClickAwayListener>
  );
};
