import { COLOR_TYPE } from "@/constants/color";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import CloseIcon from "@mui/icons-material/Close";
import HelpIcon from "@mui/icons-material/Help";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import {
  Box,
  Chip,
  CircularProgress,
  ClickAwayListener,
  IconButton,
  InputAdornment,
  Paper,
  Popper,
  TextField,
  Tooltip
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { cloneDeep } from "lodash";
import React, { Fragment, useEffect, useRef, useState } from "react";
import {
  Control,
  Controller,
  FieldValues,
  Path,
  RegisterOptions,
} from "react-hook-form";
import { useTranslation } from "react-i18next";
import CheckboxInput from "../inputs/checkbox/CheckboxInput";
import { removeVietnameseTones } from "@/utils";

export interface FormSelectTreeViewProps<T extends FieldValues, Option> {
  name: Path<T>;
  control: Control<T>;
  label: string;
  rules?: RegisterOptions;
  placeholder?: string;
  variant?: "standard" | "outlined" | "filled";
  size?: "small" | "medium";
  required?: boolean;
  getOptions: (keyword: string) => Promise<Option[]>;
  getOptionLabel: (option: Option) => string;
  getOptionKey: (option: Option) => string | number;
  getOptionChildren: (option: Option) => Option[] | undefined;
  debounceMs?: number;
  onChange?: (value: Option[]) => void;
  // onChangeInputSearch?: (e: string) => void;
  explanation?: string;
  selectedItemsProp?: Option[];
  disabled?: boolean;
  ignoreChildren?: boolean;
  queryKeyCheck?: string;
  showAllSelected?: boolean;
}

export const FormSelectTreeView = <T extends FieldValues, Option>({
  name,
  control,
  label,
  variant = "outlined",
  size = "small",
  required,
  getOptions,
  getOptionLabel,
  getOptionKey,
  getOptionChildren,
  debounceMs = FILTER_DEBOUNCE_MS,
  onChange,
  // onChangeInputSearch,
  explanation,
  selectedItemsProp,
  disabled,
  ignoreChildren = true,
  queryKeyCheck,
  showAllSelected
}: FormSelectTreeViewProps<T, Option>): JSX.Element => {
  const [t] = useTranslation();
  const [selectedItems, setSelectedItems] = useState<Option[]>([]);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [keyword, setKeyword] = useState<string>("");
  const [open, setOpen] = useState(false);
  const debounceTimeout = useRef<NodeJS.Timeout>();

  const getOptionsQuery = useQuery({
    queryKey: [queryKeyCheck ? queryKeyCheck : "", keyword],
    queryFn: () => getOptions(keyword),
    enabled: false,
  });

  const isInitialRender = useRef(true);

  useEffect(() => {
    if (isInitialRender.current && selectedItemsProp) {
      setSelectedItems(selectedItemsProp);
      onChange?.(selectedItemsProp);
      isInitialRender.current = false;
    }
  }, [selectedItemsProp, onChange]);

  useEffect(() => {
    clearTimeout(debounceTimeout.current);

    debounceTimeout.current = setTimeout(() => {
      if (keyword.length >= 2 && getOptionsQuery) {
        getOptionsQuery.refetch();
      } else if (keyword === "") {
        getOptionsQuery.refetch();
      }
    }, debounceMs);

    return () => {
      clearTimeout(debounceTimeout.current);
    };
  }, [keyword]);

  const handleParentCheckboxChange = async (
    parentOption: Option,
    checked: boolean
  ) => {
    const children = getOptionChildren(parentOption) || [];
    let newSelectedItems: Option[];

    if (checked) {
      newSelectedItems = [
        ...selectedItems,
        parentOption,
        ...(ignoreChildren ? [] : children),
      ];
      // newSelectedItems = [...selectedItems, parentOption, ...children];
    } else {
      newSelectedItems = selectedItems.filter(
        (item) =>
          getOptionKey(item) !== getOptionKey(parentOption) &&
          (ignoreChildren
            ? true
            : !children.some(
              (child) => getOptionKey(child) === getOptionKey(item)
            ))
        // && !children.some((child) => getOptionKey(child) === getOptionKey(item))
      );
    }
    setSelectedItems(newSelectedItems);
    if (onChange) {
      onChange(newSelectedItems);
    }
  };

  const handleSelectClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
    setOpen(!open);
  };

  const handleClickAway = () => {
    setAnchorEl(null);
    setOpen(false);
  };

  const handleChipDelete = (option: Option) => {
    const newSelectedItems = selectedItems.filter(
      (item) => getOptionKey(item) !== getOptionKey(option)
    );
    setSelectedItems(newSelectedItems);
    onChange && onChange(newSelectedItems);
  };

  // const handleToggle = (event: any, nodeId: string) => {
  //   let currentExpandedIds = [...expanded];
  //   if (currentExpandedIds?.includes(nodeId)) {
  //     currentExpandedIds = currentExpandedIds?.filter((id) => id !== nodeId);
  //   } else {
  //     currentExpandedIds.push(nodeId);
  //   }
  //   setExpanded(currentExpandedIds);
  // };

  // const renderTree = (option: Option): JSX.Element => {
  //   const children = getOptionChildren(option) || [];
  //   const isSelected = selectedItems.some(
  //     (item) => getOptionKey(item) === getOptionKey(option)
  //   );

  //   return (
  //     <TreeItem
  //       itemId={String(getOptionKey(option))}
  //       label={
  //         <Box
  //           sx={{
  //             display: "flex",
  //             alignItems: "center",
  //             justifyContent: "space-between",
  //             fontSize: 14,
  //           }}
  //         >
  //           <FormControlLabel
  //             control={
  //               <Checkbox
  //                 checked={isSelected}
  //                 sx={{
  //                   color: COLOR_TYPE.TOYOTA.TOYOTA1,
  //                   "&.Mui-checked": {
  //                     color: COLOR_TYPE.TOYOTA.TOYOTA1,
  //                   },
  //                   "& .MuiCheckbox-outline": {
  //                     borderColor: COLOR_TYPE.TOYOTA.TOYOTA1,
  //                   },
  //                   "& .MuiCheckbox-root": {
  //                     borderColor: COLOR_TYPE.TOYOTA.TOYOTA1,
  //                     borderWidth: "2px",
  //                   },
  //                 }}
  //                 onChange={(event) =>
  //                   handleParentCheckboxChange(option, event.target.checked)
  //                 }
  //               />
  //             }
  //             label={getOptionLabel(option)}
  //             sx={{ margin: 0 }} // Remove extra margin
  //           />
  //         </Box>
  //       }
  //       key={getOptionKey(option)}
  //       sx={{
  //         "& .MuiTreeItem-content": {
  //           display: "flex",
  //           flexDirection: "row-reverse",
  //           fontSize: "14px",
  //           padding: 0,
  //         },
  //         "& .MuiFormControlLabel-label": {
  //           fontSize: "14px", // Specific class for FormControlLabel label
  //         },
  //       }}
  //     >
  //       {children.map((childOption) => renderTree(childOption))}
  //     </TreeItem>
  //   );
  // };

  const renderTreeNode = (option: any): JSX.Element => {
    const children = getOptionChildren(option) || [];
    const label = getOptionLabel(option);
    const isSelected = selectedItems.some(
      (item) => getOptionKey(item) === getOptionKey(option)
    );
    const isHighlight =
      !!keyword?.trim()?.length &&
      removeVietnameseTones(label)
        ?.toLocaleLowerCase()
        ?.includes(removeVietnameseTones(keyword)?.trim()?.toLocaleLowerCase());

    return (
      <Box sx={{ marginLeft: "24px" }}>
        <label
          style={{ display: "flex", marginBottom: "8px", cursor: "pointer" }}
        >
          {/* <input
            type="checkbox"
            style={{
              transform: "scale(1.23)",
              marginRight: 10,
              accentColor: COLOR_TYPE.TOYOTA.TOYOTA1,
              outlineColor: COLOR_TYPE.TOYOTA.TOYOTA1,
            }}
            checked={isSelected}
            onChange={(event) =>
              handleParentCheckboxChange(option, event.target.checked)
            }
          />
          <Typography
            variant={"body2"}
            sx={{ fontWeight: isHighlight ? "bold" : undefined, color:"rgba(0, 0, 0, 0.87)"}}
            component={"span"}
          >
            {label}
          </Typography> */}
          <CheckboxInput
            borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
            size={18}
            borderWidth={1}
            checked={isSelected}
            label={label}
            labelVariant={isHighlight ? 'subtitle1' : undefined}
            onChange={(value) => handleParentCheckboxChange(option, value)}
          />
        </label>
        {children && (
          <div>{children.map((child: any) => renderTreeNode(child))}</div>
        )}
      </Box>
    );
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Backspace' || event.key === 'Delete') {
      const newSelectedItems = cloneDeep(selectedItems);
      newSelectedItems?.pop?.();
      setSelectedItems(newSelectedItems);
      if (onChange) {
        onChange(newSelectedItems);
      }
    }
  };

  return (
    <ClickAwayListener onClickAway={handleClickAway}>
      <div>
        <label className={label ?? "no-label"}>
          {label}
          {explanation && (
            <Tooltip title={explanation} placement="top-start">
              <HelpIcon fontSize={"small"} />
            </Tooltip>
          )}
          {required && <span style={{ color: "red" }}>*</span>}
        </label>
        <Controller
          name={name}
          control={control}
          render={({ field, fieldState: { error } }) => (
            <>
              <TextField
                {...field}
                // label={
                //   <>
                //     {label}
                //     {explanation && (
                //       <Tooltip title={explanation} placement="top-start">
                //         <HelpIcon fontSize={"small"} />
                //       </Tooltip>
                //     )}
                //   </>
                // }
                value={""}
                autoComplete="off"
                variant={variant}
                fullWidth
                error={!!error}
                onKeyDown={handleKeyDown}
                helperText={
                  error?.message
                    ? t(error.message, { fieldName: label })
                    : undefined
                }
                size={size}
                required={required}
                onClick={disabled ? undefined : handleSelectClick}
                InputProps={{
                  endAdornment: (
                    <Fragment>
                      {getOptionsQuery.isFetching ? (
                        <CircularProgress color="inherit" size={20} />
                      ) : (
                        <IconButton
                          onClick={handleSelectClick}
                          size="small"
                          style={{ marginLeft: -24 }}
                          disabled={disabled}
                        >
                          {open ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
                        </IconButton>
                      )}
                    </Fragment>
                  ),
                  startAdornment: selectedItems?.length ? (
                    <SelectedChips
                      disable={disabled}
                      selectedItems={selectedItems}
                      getOptionLabel={getOptionLabel}
                      getOptionKey={getOptionKey}
                      handleChipDelete={handleChipDelete}
                      showAllSelected={showAllSelected}
                    />
                  ) : (
                    <Box
                      sx={{
                        display: "flex",
                        flexWrap: "wrap",
                        gap: 0.5,
                        width: "100%",
                        flex: "none",
                      }}
                    >
                      <span
                        style={{
                          flex: 1,
                          color: "#CCCCCC",
                          fontSize: "1rem",
                          fontWeight: 500,
                        }}
                      >
                        {t("common.place_holder.select_department")}
                      </span>
                    </Box>
                  ),
                }}
                InputLabelProps={{
                  shrink: true,
                }}
                sx={{
                  "& .MuiInputBase-root": {
                    paddingLeft: "6px"
                  }
                }}
                disabled={disabled}
              />
              <Popper
                open={open}
                anchorEl={anchorEl}
                placement="bottom-start"
                style={{
                  width: anchorEl?.clientWidth ?? "auto",
                  zIndex: 1300,
                }}
                modifiers={[
                  {
                    name: "computeStyles",
                    options: {
                      adaptive: false, // Disable adaptive styles
                    },
                  },
                ]}
              >
                <Paper
                  elevation={3}
                  sx={{
                    borderRadius: "4px",
                    width: "100%",
                    pb: 2,
                  }}
                >
                  <Box sx={{ p: 2 }}>
                    <TextField
                      variant={variant}
                      fullWidth
                      size="small"
                      value={keyword}
                      placeholder={t(
                        "common.place_holder.search_department_name"
                      )}
                      // error={!!error}
                      // helperText={error?.message ? t(error.message) : undefined}
                      // size={size}
                      // required={required}
                      onChange={(e) => {
                        setKeyword(e.target.value);
                      }}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SearchOutlinedIcon />
                          </InputAdornment>
                        ),
                      }}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </Box>
                  {/* <SimpleTreeView
                    sx={{
                      flexGrow: 1,
                      overflowY: "auto",
                      // mt: 2,
                      maxHeight: 300,
                    }}
                    expandedItems={expanded}
                    onItemExpansionToggle={handleToggle}
                  >
                    {(getOptionsQuery.data ?? []).map((option) =>
                      renderTree(option)
                    )}
                  </SimpleTreeView> */}
                  <Box
                    sx={{
                      flexGrow: 1,
                      overflowY: "auto",
                      maxHeight: 300,
                    }}
                  >
                    {(getOptionsQuery.data ?? []).map((node: any) =>
                      renderTreeNode(node)
                    )}
                  </Box>
                </Paper>
              </Popper>
            </>
          )}
        />
      </div>
    </ClickAwayListener>
  );
};

interface SelectedChipsProps<Option> {
  selectedItems: Option[];
  getOptionLabel: (option: Option) => string;
  getOptionKey: (option: Option) => string | number;
  handleChipDelete: (option: Option) => void;
  disable?: boolean;
  showAllSelected?: boolean;
}

const SelectedChips = <Option,>({
  selectedItems,
  getOptionLabel,
  getOptionKey,
  handleChipDelete,
  disable,
  showAllSelected = true
}: SelectedChipsProps<Option>): JSX.Element => {
  const visibleTags = showAllSelected ? selectedItems : selectedItems.slice(0, 3); // Show only the first 3 items
  const remainingTagsCount = selectedItems.length - visibleTags.length;

  return (
    <Box
      sx={{
        display: "flex",
        flexWrap: "wrap",
        // gap: 0.5,
        maxWidth: "100%",
        flex: "none",
        paddingLeft: 0,
        "&.MuiInputBase": {
          paddingLeft: "0 !important",
        },
      }}
    >
      {visibleTags &&
        visibleTags.map((option) => (
          <Chip
            disabled={disable}
            key={getOptionKey(option)}
            label={getOptionLabel(option)}
            onDelete={() => handleChipDelete(option)}
            style={{
              backgroundColor: "black",
              color: "white",
              borderRadius: "2px",
              height: "28px",
              margin: "1",
              fontSize: "14px"
            }}
            deleteIcon={
              <CloseIcon
                style={{
                  color: "white",
                  fontSize: "18px",
                  marginLeft: 1,
                  marginTop: 1,
                }}
              />
            }
            sx={{
              margin: 0.25,
              whiteSpace: "nowrap",
            }}
          />
        ))}

      {remainingTagsCount > 0 && (
        <Chip
          disabled={disable}
          key={'others_options'}
          label={`+ ${remainingTagsCount}...`}
          // onDelete={() => handleChipDelete(option)}
          style={{
            backgroundColor: "black",
            color: "white",
            borderRadius: "2px",
            height: "28px",
            margin: "1",
            fontSize: "14px"
          }}
          sx={{
            margin: 0.25,
            whiteSpace: "nowrap",
          }}
        />
      )}
    </Box>
  );
};
