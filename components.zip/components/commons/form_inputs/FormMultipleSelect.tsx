import { Control, Controller, FieldValues, Path } from "react-hook-form";
import { MultipleSelect } from "../inputs/multiple_select/MultipleSelect";
import HelpIcon from "@mui/icons-material/Help";
import { useTranslation } from "react-i18next";
import { Tooltip } from "@mui/material";
import { HTMLAttributes, ReactNode } from "react";

export interface FormMultipleSelectProps<T extends FieldValues, Option> {
  name: Path<T>;
  control: Control<T>;
  label: string;
  placeholder?: string;
  rules?: Record<string, unknown>;
  variant?: "filled" | "outlined" | "standard";
  keyQuery: string;
  getOptions: (keyword: string) => Promise<Option[]>;
  getOptionLabel: (option: Option) => string;
  getSelectedOptionLabel?: (option: Option) => string;
  getOptionKey: (option: Option) => string | number;
  size?: "small" | "medium";
  required?: boolean;
  explanation?: string;
  onChange?: (selectedOption: Option[]) => void;
  disabled?: boolean;
  isFocus?: boolean;
  minCharLength?: number;
  disableCloseOnSelect?: boolean;
  showAllSelected?: boolean;
  renderOption?: (
    optionProps: HTMLAttributes<HTMLLIElement> & {
      key: any;
    },
    option: Option,
    selected: boolean) => ReactNode;
}

export const FormMultipleSelect = <T extends FieldValues, Option>({
  name,
  control,
  label,
  rules,
  variant,
  keyQuery,
  getOptionKey,
  getOptionLabel,
  getSelectedOptionLabel,
  getOptions,
  size = "small",
  required,
  explanation,
  placeholder,
  onChange,
  disabled,
  isFocus,
  minCharLength,
  disableCloseOnSelect,
  showAllSelected,
  renderOption
}: FormMultipleSelectProps<T, Option>) => {
  const [t] = useTranslation();
  return (
    <>
      {label && (
        <label className={label ?? "no-label"}>
          {label}
          {explanation && (
            <Tooltip title={explanation} placement="top-start">
              <HelpIcon fontSize={"small"} />
            </Tooltip>
          )}
          {required && <span style={{ color: "red" }}>*</span>}
        </label>
      )}
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <MultipleSelect
            {...field}
            label={
              <>
                {/* {label}
                {explanation && (
                  <Tooltip title={explanation} placement="top-start">
                    <HelpIcon fontSize={"small"} />
                  </Tooltip>
                )} */}
              </>
            }
            placeholder={
              !field.value?.length && placeholder
                ? t(`common.place_holder.select_value`, {
                  fieldName: placeholder.toLocaleLowerCase(),
                }).replace(/&amp;/g, "&")
                : undefined
            }
            variant={variant}
            fullWidth
            keyQuery={keyQuery}
            getOptionKey={getOptionKey}
            getOptionLabel={getOptionLabel}
            getSelectedOptionLabel={getSelectedOptionLabel}
            disableCloseOnSelect={disableCloseOnSelect}
            showAllSelected={showAllSelected}
            renderOption={renderOption}
            getOptions={getOptions}
            error={!!error}
            helperText={
              error?.message &&
              t(error?.message, {
                fieldName: label
                  ? t(label)
                  : placeholder
                    ? t(placeholder)?.toLowerCase()
                    : "",
              })
            }
            size={size}
            shrink
            onChange={(keys) => {
              onChange && onChange(keys);
              field.onChange(keys);
            }}
            onBlur={field.onBlur}
            disabled={field.disabled || disabled}
            isFocus={isFocus}
            minCharLength={minCharLength}
          />
        )}
      />
    </>
  );
};
