import React, { useState, useEffect, useRef } from "react";
import { Controller, Control, FieldValues, Path } from "react-hook-form";
import {
  TextField,
  Paper,
  Popper,
  ClickAwayListener,
  CircularProgress,
  Box,
  IconButton,
  InputAdornment,
  Tooltip,
} from "@mui/material";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import { SimpleTreeView } from "@mui/x-tree-view";
import { useQuery } from "@tanstack/react-query";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import { COLOR_TYPE } from "@/constants/color";
import { extractIds } from "@/utils";
import { useTranslation } from "react-i18next";
import HelpIcon from "@mui/icons-material/Help";
import CheckboxInput from "../inputs/checkbox/CheckboxInput";

export interface FormSelectTreeViewProps<T extends FieldValues, Option> {
  name: Path<T>;
  control: Control<T>;
  label: string;
  placeholder?: string;
  variant?: "standard" | "outlined" | "filled";
  size?: "small" | "medium";
  required?: boolean;
  getOptions: (keyword: string) => Promise<Option[]>;
  getOptionLabel: (option: Option) => string;
  getOptionKey: (option: Option) => string | number;
  getOptionChildren: (option: Option) => Option[] | undefined;
  debounceMs?: number;
  onChange?: (value: Option[]) => void;
  // onChangeInputSearch?: (e: string) => void;
  explanation?: string;
  selectedItemsProp?: Option[];
  disabled?: boolean;
  ignoreChildren?: boolean;
  queryKey: string;
}

export const FormSelectSingleTreeView = <T extends FieldValues, Option>({
  name,
  control,
  label,
  variant = "outlined",
  size = "small",
  required,
  explanation,
  getOptions,
  getOptionLabel,
  getOptionKey,
  getOptionChildren,
  debounceMs = FILTER_DEBOUNCE_MS,
  onChange,
  selectedItemsProp,
  placeholder,
  disabled,
  queryKey,
}: FormSelectTreeViewProps<T, Option>): JSX.Element => {
  const [t] = useTranslation();
  const [selectedItem, setSelectedItem] = useState<any>(
    undefined
  );
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [keyword, setKeyword] = useState<string>("");
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState<string[]>([]);
  const debounceTimeout = useRef<NodeJS.Timeout>();

  const getOptionsQuery = useQuery({
    queryKey: [queryKey, keyword],
    queryFn: () => getOptions(keyword),
    enabled: false,
  });

  const isInitialRender = useRef(true);

  // Handle setting expanded items after options are fetched
  useEffect(() => {
    if (getOptionsQuery.data) {            
      const allDepartmentIds = extractIds(getOptionsQuery.data);
      allDepartmentIds?.length && setExpanded(allDepartmentIds);
    }
  }, [getOptionsQuery?.data]);

  // Handle form reset or value changes
  useEffect(() => {    
    if (isInitialRender.current && selectedItemsProp?.length) {
      setSelectedItem(selectedItemsProp[0]);
      onChange?.([selectedItemsProp[0]]);
      isInitialRender.current = false;
    }
  }, [selectedItemsProp, onChange]);
  // Update selectedItem when form's value changes due to form.reset or similar actions
  useEffect(() => {
    if (selectedItemsProp) {
      setSelectedItem(selectedItemsProp);
    } else {
      setSelectedItem(undefined);
    }
  }, [selectedItemsProp]);

  useEffect(() => {
    clearTimeout(debounceTimeout.current);

    debounceTimeout.current = setTimeout(() => {
      if (keyword.length >= 2 && getOptionsQuery) {
        getOptionsQuery.refetch();
      } else if (keyword === "") {
        getOptionsQuery.refetch();
      }
    }, debounceMs);

    return () => {
      clearTimeout(debounceTimeout.current);
    };
  }, [keyword]);

  const handleSelectClick = (event: React.MouseEvent<HTMLElement>) => {
    if (open) {
      setAnchorEl(null);
      setOpen(false);
    } else {
      setAnchorEl(event.currentTarget);
      setOpen(true);
    }
  };

  const handleClickAway = () => {
    setAnchorEl(null);
    setOpen(false);
  };

  const handleOptionChange = (
    option: Option,
    onChangeCallback: (value: any) => void
  ) => {
    setSelectedItem(option);
    onChangeCallback(option); 
    onChange?.([option]); 
    setOpen(false); 
  };
  const handleToggle = (event: any, nodeId: string) => {
    let currentExpandedIds = [...expanded];
    if (currentExpandedIds?.includes(nodeId)) {
      currentExpandedIds = currentExpandedIds?.filter((id) => id !== nodeId);
    } else {
      currentExpandedIds.push(nodeId);
    }
    setExpanded(currentExpandedIds);
  };

  const renderTree = (
    option: Option,
    onChangeCallback: (value: any) => void
  ): JSX.Element => {
    const children = getOptionChildren(option) || [];
    // const isSelected =
    //   selectedItem && getOptionKey(selectedItem) === getOptionKey(option); // Kiểm tra xem option có được chọn hay không
    const label = getOptionLabel(option);

    const isSelected =
      selectedItem && getOptionKey(selectedItem) === getOptionKey(option) || false; // Kiểm tra xem option có được chọn hay không
    const isHighlight =
      !!keyword?.trim()?.length &&
      label
        ?.toLocaleLowerCase()
        ?.includes(keyword?.trim()?.toLocaleLowerCase());
    return (
     
      <Box sx={{ marginLeft: "24px" }}>
        <label
          style={{ display: "flex", marginBottom: "10px", cursor: "pointer" }}
        >
          {/* <input
            type="checkbox"
            style={{
              transform: "scale(1.23)",
              marginRight: 10,
              accentColor: COLOR_TYPE.TOYOTA.TOYOTA1,
              outlineColor: COLOR_TYPE.TOYOTA.TOYOTA1,
            }}
            checked={isSelected}
            onChange={() => {
              handleOptionChange(option, onChangeCallback);
            }}
          /> */}
           <CheckboxInput
            borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
            size={18}
            borderWidth={1}
            checked={isSelected}
            label={label}
            labelVariant={isHighlight ? 'subtitle1' : undefined}
            onChange={() => {              
              handleOptionChange(option, onChangeCallback)
            }}
          />
          {/* <Typography
            variant={"body2"}
            sx={{ fontWeight: isHighlight ? "bold" : undefined }}
            component={"span"}
          >
            {label}
          </Typography> */}
        </label>
        {children.map((childOption) =>
          renderTree(childOption, onChangeCallback)
        )}
      </Box>
    );
  };

  return (
    <ClickAwayListener onClickAway={handleClickAway}>
      <Controller
        name={name}
        control={control}
        render={({ field, fieldState: { error } }) => (
          <>
            {label && (
        <label className={label ?? "no-label"}>
          {label}
          {explanation && (
            <Tooltip title={explanation} placement="top-start">
              <HelpIcon fontSize={"small"} />
            </Tooltip>
          )}
          {required && <span style={{ color: "red" }}>*</span>}
        </label>
      )}
            <TextField
              sx={{
                // paddingTop: "0.5rem !important",
                // marginTop: "0.25rem !important",
              }}
              {...field}
              // label={
              //   <>
              //     {label}
              //     {explanation && (
              //       <Tooltip title={explanation} placement="top-start">
              //         <HelpIcon fontSize={"small"} />
              //       </Tooltip>
              //     )}
              //   </>
              // }
              variant={variant}
              fullWidth
              error={!!error}
              helperText={
                error?.message
                  ? t(error.message, { fieldName: label })
                  : undefined
              }
              size={size}
              required={required}
              onClick={disabled ? undefined : handleSelectClick}
              InputProps={{
                endAdornment: (
                  <>
                    {getOptionsQuery.isFetching ? (
                      <CircularProgress color="inherit" size={20} />
                    ) : (
                      <IconButton
                        onClick={disabled ? undefined : handleSelectClick}
                        size="small"
                        style={{ marginLeft: -24 }}
                      >
                        {open ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
                      </IconButton>
                    )}
                  </>
                ),
                // Get the value from field.value instead of selectedItem
                value: field.value ? getOptionLabel(field.value) : "", // Ensures the form's value is displayed
                readOnly: true,
              }}
              InputLabelProps={{
                shrink: true,
              }}
              placeholder={placeholder}
              disabled={disabled}
            />
            <Popper
              open={open}
              anchorEl={anchorEl}
              placement="bottom-start"
              style={{
                width: anchorEl?.clientWidth ?? "auto",
                zIndex: 1300,
              }}
            >
              <Paper elevation={3} sx={{ borderRadius: "4px", width: "100%" }}>
                <Box sx={{ p: 2 }}>
                  <TextField
                    variant={variant}
                    fullWidth
                    size="small"
                    placeholder={t("common.place_holder.select_department")}
                    onChange={(e) => setKeyword(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchOutlinedIcon />
                        </InputAdornment>
                      ),
                    }}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </Box>
                <SimpleTreeView
                  sx={{
                    flexGrow: 1,
                    overflowY: "auto",
                    maxHeight: 300,
                  }}
                  expandedItems={expanded}
                  onItemExpansionToggle={handleToggle}
                >
                  {(getOptionsQuery.data ?? []).map(
                    (option) => renderTree(option, field.onChange) // Pass field.onChange to update the form
                  )}
                </SimpleTreeView>
              </Paper>
            </Popper>
          </>
        )}
      />
    </ClickAwayListener>
  );
};
