import {
  Checkbox,
  FormControl,
  FormControlLabel,
  FormHelperText,
  Tooltip,
} from "@mui/material";
import { Control, Controller, FieldValues, Path } from "react-hook-form";
import HelpIcon from "@mui/icons-material/Help";
import { useTranslation } from "react-i18next";
import { GLOBAL_SPACING } from "@/constants/format";
import { COLOR_TYPE } from "@/constants/color";

export interface FormCheckboxProps<T extends FieldValues, Value> {
  name: Path<T>;
  control: Control<T>;
  label?: string;
  checkboxTitle?: string;
  rules?: Record<string, unknown>;
  variant?: "filled" | "outlined" | "standard";
  size?: "small" | "medium";
  required?: boolean;
  inputTransform?: (value: Value) => boolean;
  outputTransform?: (bool: boolean) => Value;
  explanation?: string;
  noInline?: boolean;
  disabled?: boolean;
}

export const FormCheckbox = <T extends FieldValues, Value>({
  name,
  control,
  label,
  checkboxTitle,
  rules,
  variant,
  size = "medium",
  inputTransform,
  outputTransform,
  explanation,
  noInline,
  disabled,
}: FormCheckboxProps<T, Value>) => {
  const [t] = useTranslation();
  const { error } = control.getFieldState(name);

  return (
    <FormControl
      error={!!error}
      component="fieldset"
      variant={variant}
      className={!label ? "no-label" : undefined}
      fullWidth
      disabled={disabled}
    >
      {label && (
        <label style={{padding:0}}>
          {label}
          {!noInline && (
            <FormControlLabel
              sx={{
                paddingLeft: GLOBAL_SPACING,
              }}
              control={
                <Controller
                  name={name}
                  control={control}
                  rules={rules}
                  render={({ field }) => (
                    <Checkbox
                      icon={
                        <span
                          style={{
                            width: 20,
                            height: 20,
                            display: "inline-block",
                            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                            // backgroundColor: "#fff",
                            border: `2px solid ${COLOR_TYPE.TOYOTA.TOYOTA1}`,
                            borderRadius: "6px",
                          }}
                        />
                      }
                      checkedIcon={
                        <span
                          style={{
                            width: 20,
                            height: 20,
                            backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA1}`,
                            borderRadius: "6px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <svg
                            xmlns="http://www.w3.org/2s000/svg"
                            viewBox="0 0 24 24"
                            fill="white"
                            width="16px"
                            height="16px"
                          >
                            <path
                              d="M19.77 5.23c.29.3.29.77 0 1.06l-11 11c-.3.3-.77.3-1.06 0l-5-5c-.29-.3-.29-.77 0-1.06s.77-.29 1.06 0l4.47 4.47 10.47-10.47c.29-.29.77-.29 1.06 0z"
                              stroke="white"
                              strokeWidth={1}
                            />
                          </svg>
                        </span>
                      }
                      {...field}
                      checked={
                        inputTransform
                          ? inputTransform(field.value)
                          : field.value
                      }
                      onChange={(e) =>
                        field.onChange(
                          outputTransform
                            ? outputTransform(e.target.checked)
                            : e.target.checked
                        )
                      }
                      size={size}
                    />
                  )}
                />
              }
              label={
                <>
                  {checkboxTitle}
                  {explanation && (
                    <Tooltip title={explanation} placement="top-start">
                      <HelpIcon fontSize={"small"} />
                    </Tooltip>
                  )}
                </>
              }
            />
          )}
        </label>
      )}

      {noInline && (
        <FormControlLabel
          sx={{
            paddingLeft: GLOBAL_SPACING,
          }}
          control={
            <Controller
              name={name}
              control={control}
              rules={rules}
              render={({ field }) => (
                <Checkbox
                  {...field}
                  checked={
                    inputTransform ? inputTransform(field.value) : field.value
                  }
                  onChange={(e) =>
                    field.onChange(
                      outputTransform
                        ? outputTransform(e.target.checked)
                        : e.target.checked
                    )
                  }
                  size={size}
                />
              )}
            />
          }
          label={
            <>
              {checkboxTitle}
              {explanation && (
                <Tooltip title={explanation} placement="top-start">
                  <HelpIcon fontSize={"small"} />
                </Tooltip>
              )}
            </>
          }
        />
      )}

      {error?.message && (
        <FormHelperText>
          {t(error.message, { fieldName: label })}
        </FormHelperText>
      )}
    </FormControl>
  );
};
