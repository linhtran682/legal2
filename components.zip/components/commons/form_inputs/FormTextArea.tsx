import React from "react";
import { Controller, FieldValues } from "react-hook-form";
import TextField from "@mui/material/TextField";
import { FormTextFieldProps } from "./FormTextField";
import HelpIcon from "@mui/icons-material/Help";
import { useTranslation } from "react-i18next";
import { TEXT_AREA_MAX_LENGTH } from "@/constants/constraint";
import { Tooltip } from "@mui/material";

interface FormTextAreaProps<T extends FieldValues>
  extends FormTextFieldProps<T> {
  minRows?: number;
}

export const FormTextArea = <T extends FieldValues>({
  name,
  control,
  label,
  rules,
  placeHolder,
  variant,
  minRows = 4,
  size = "small",
  required,
  explanation,
  disabled,
}: FormTextAreaProps<T>) => {
  const [t] = useTranslation();

  return (
    <>
    <label className={label ?? "no-label"}>
        {label}{" "}
        {explanation && (
          <Tooltip title={explanation} placement="top-start">
            <HelpIcon fontSize={"small"} />
          </Tooltip>
        )}
        {required && <span style={{color: 'red'}}>*</span>}
      </label>
      <Controller
      name={name}
      control={control}
      rules={rules}
      render={({ field, fieldState: { error } }) => (
        <TextField
          {...field}
          // label={
          //   <>
          //     {label}
          //     {explanation && (
          //       <Tooltip title={explanation} placement="top-start">
          //         <HelpIcon fontSize={"small"} />
          //       </Tooltip>
          //     )}
          //   </>
          // }
          variant={variant}
          fullWidth
          placeholder={
            placeHolder
              ? t(`common.place_holder.enter_value`, {
                  fieldName: placeHolder.toLocaleLowerCase(),
                })
              : undefined
          }
          error={!!error}
          helperText={
            error?.message
              ? t(error.message, { fieldName: label?.toLowerCase() })
              : undefined
          }
          onChange={(e) => {
            if (
              e.target.value &&
              e.target.value.length > TEXT_AREA_MAX_LENGTH
            ) {
              e.target.value = e.target.value.slice(0, TEXT_AREA_MAX_LENGTH);
            }
            field.onChange(e);
          }}
          multiline={true}
          minRows={minRows}
          size={size}
          required={required}
          InputLabelProps={{
            shrink: true,
          }}
          disabled={disabled || field.disabled}
        />
      )}
    />
    </>
   
  );
};
