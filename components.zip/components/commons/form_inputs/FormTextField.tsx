import React, { HTMLInputTypeAttribute, ReactElement } from "react";
import { Controller, Control, FieldValues, Path } from "react-hook-form";
import TextField from "@mui/material/TextField";
import { InputAdornment, InputBaseProps, SxProps, Tooltip } from "@mui/material";
import HelpIcon from "@mui/icons-material/Help";
import { useTranslation } from "react-i18next";
import { TEXT_FIELD_MAX_LENGTH } from "@/constants/constraint";
import { THOUSAND_SEPARATOR } from "@/constants/regex";

export interface FormTextFieldProps<T extends FieldValues> {
  name: Path<T>;
  control: Control<T>;
  label?: string;
  rules?: Record<string, unknown>;
  placeHolder?: string;
  variant?: "filled" | "outlined" | "standard";
  type?: HTMLInputTypeAttribute | 'integer';
  size?: "small" | "medium";
  required?: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onChange?: (...event: any[]) => void;
  startIcon?: ReactElement;
  sx?: SxProps;
  explanation?: string;
  emptyIsZero?: boolean;
  disabled?: boolean;
  inputProps?: InputBaseProps['inputProps'];
  inputAlign?: string;
}

export const FormTextField = <T extends FieldValues>({
  name,
  control,
  label,
  rules,
  placeHolder,
  variant,
  type,
  size = "small",
  required,
  onChange,
  startIcon,
  sx,
  explanation,
  emptyIsZero,
  disabled,
  inputProps = {},
  inputAlign
}: FormTextFieldProps<T>) => {
  const [t] = useTranslation();

  return (
    <>
      <label className={label ?? "no-label"} style={{ display: 'flex' }}>
        {label}{" "}
        {explanation && (
          <Tooltip title={explanation} placement="top-start">
            <HelpIcon fontSize={"small"} />
          </Tooltip>
        )}
        {required && <span style={{ color: 'red' }}>*</span>}
      </label>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <TextField
            {...field}
            className={label ?? "no-label"}
            variant={variant}
            fullWidth
            type={type}
            placeholder={
              placeHolder && placeHolder !== " "
                ? t(`common.place_holder.enter_value`, {
                  fieldName: placeHolder.toLocaleLowerCase(),
                })
                : placeHolder && placeHolder === " "
                  ? t(`common.place_holder.please_enter`)
                  : undefined
            }
            error={!!error}
            helperText={
              error?.message
                ? t(error.message, { fieldName: label?.toLowerCase() })
                : undefined
            }
            size={size}
            // required={required}
            onChange={(e) => {
              if (
                e.target.value &&
                e.target.value.length > TEXT_FIELD_MAX_LENGTH
              ) {
                e.target.value = e.target.value.slice(0, TEXT_FIELD_MAX_LENGTH);
              }
              if (type == "integer") {
                let value = e.target.value === '' ? e.target.value : e.target.value?.replace(/\D/g, '').toString();
                if (value.startsWith("0") && value?.length > 1) {
                  value = value.substring(1);
                }
                value = value.substring(0, 25);
                value = value?.replace(THOUSAND_SEPARATOR, ",");

                e.target.value = value
              }
              if (type == "number") {
                if (!Boolean(e.target.value?.trim() && emptyIsZero)) {
                  e.target.value = "0";
                }

                e.target.value = Number(e.target.value).toString();
              }

              field.onChange(e);
              onChange && onChange(e);
            }}
            InputProps={{
              sx: {
                "&::placeholder": {
                  flex: 1,
                  color: "#fff !important",
                  fontSize: "0.875rem",
                  fontWeight: 500,
                },
                input: {
                  textAlign: inputAlign ?? "left", // Aligns the value to the right
                  "&::placeholder": {
                    textAlign: "left", // Ensures the placeholder aligns to the left
                  },
                },
              },
              startAdornment: startIcon && (
                <InputAdornment position="start">{startIcon}</InputAdornment>
              ),
            }}
            InputLabelProps={{
              shrink: true,
            }}
            sx={sx}
            disabled={field.disabled || disabled}
            inputProps={inputProps}
          />
        )}
      />
    </>
  );
};
