import React from "react";
import { Controller, FieldValues } from "react-hook-form";
import { FormTextFieldProps } from "./FormTextField";
import {
  IconButton,
  InputAdornment,
  MenuItem,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import HelpIcon from "@mui/icons-material/Help";
import { useTranslation } from "react-i18next";
import { COLOR_TYPE } from "@/constants/color";
import { ClearIcon } from "@mui/x-date-pickers";

export interface FormSelectProps<T extends FieldValues, Option>
  extends FormTextFieldProps<T> {
  options: Option[];
  getOptionLabel: (option: Option) => string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getOptionKey: (option: Option) => any;
  isClearIcon?: boolean;
}

export const FormSelect = <T extends FieldValues, Option>({
  name,
  control,
  label,
  rules,
  placeHolder,
  variant,
  options,
  getOptionKey,
  getOptionLabel,
  size = "small",
  required,
  onChange,
  explanation,
  disabled,
  isClearIcon = false,
}: FormSelectProps<T, Option>) => {
  const [t] = useTranslation();

  return (
    <>
      <label className={label ?? "no-label"}>
        {label}{" "}
        {explanation && (
          <Tooltip title={explanation} placement="top-start">
            <HelpIcon fontSize={"small"} />
          </Tooltip>
        )}
        {required && <span style={{ color: "red" }}>*</span>}
      </label>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <TextField
            {...field}
            className={label ?? "no-label"}
            // label={
            //   <>
            //     {label}
            //     {explanation && (
            //       <Tooltip title={explanation} placement="top-start">
            //         <HelpIcon fontSize={"small"} />
            //       </Tooltip>
            //     )}
            //   </>
            // }
            variant={variant}
            fullWidth
            error={!!error}
            helperText={
              error?.message &&
              t(error?.message, {
                fieldName: label
                  ? t(label)?.toLowerCase()
                  : placeHolder
                  ? t(placeHolder)?.toLowerCase()
                  : "",
              })
            }
            value={field.value ?? ""}
            select
            size={size}
            // required={required}
            onChange={(e) => {
              field.onChange(e);
              onChange && onChange(e);
            }}
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              endAdornment:
                field.value && isClearIcon ? (
                  <InputAdornment position="end" sx={{ marginRight: "20px" }}>
                    <IconButton
                      onClick={() => {
                        field.onChange(null);
                        onChange && onChange(null);
                      }}
                      edge="end"
                      disabled={disabled}
                      sx={{
                        opacity: 0, // hidden by default
                        transition: "opacity 0.3s",
                      }}
                    >
                      <ClearIcon sx={{ width: "20px" }} />
                    </IconButton>
                  </InputAdornment>
                ) : null,
            }}
            SelectProps={{
              displayEmpty: true,
              renderValue:
                field.value !== ""
                  ? undefined
                  : () => {
                      return placeHolder ? (
                        <Typography color={`${COLOR_TYPE.TOYOTA.TOYOTA2}59`}>
                          {t(`common.place_holder.select_value`, {
                            fieldName: placeHolder.toLocaleLowerCase(),
                          })}
                        </Typography>
                      ) : (
                        <></>
                      );
                    },
            }}
            disabled={field.disabled || disabled}
            sx={{
              ...(isClearIcon && {
                ":hover .MuiInputAdornment-root .MuiIconButton-root": {
                  opacity: 1,
                },
                // ".MuiInputAdornment-root .MuiIconButton-root": {
                //   opacity: field.value ? 1 : 0,
                // },
              }),
            }}
          >
            {placeHolder ? (
              <MenuItem
                disabled
                value=""
                sx={{
                  backgroundColor: "transparent",
                  height: "0 !important",
                  opacity: "0 !important",
                }}
              >
                <Typography
                  sx={{ fontSize: "1rem", 
                    color: '#808080 !important',
                    fontWeight: '500 !important',
                    opacity: '1 !important'
                   }}
                  color={`${COLOR_TYPE.TOYOTA.TOYOTA2}59`}
                >
                  {t(`common.place_holder.select_value`, {
                    fieldName: placeHolder?.toLocaleLowerCase(),
                  })}
                </Typography>
              </MenuItem>
            ) : null}
            {(options || []).map((option) => (
              <MenuItem value={getOptionKey(option)} key={getOptionKey(option)}>
                {getOptionLabel(option)}
              </MenuItem>
            ))}
          </TextField>
        )}
      />
    </>
  );
};
