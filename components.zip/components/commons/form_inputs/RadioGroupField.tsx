import * as React from "react";
import {
  BoxProps,
  FormControlLabel,
  FormHelperText,
  GridProps,
  Radio,
  RadioGroup,
  RadioProps,
  Tooltip,
  Typography,
  styled,
} from "@mui/material";
import {
  Controller,
  FieldError,
  UseControllerProps,
  useFormContext,
  UseFormRegisterReturn,
} from "react-hook-form";
import { SwitchProps } from "@mui/material/Switch";
import { useTranslation } from "react-i18next";
import HelpIcon from "@mui/icons-material/Help";

export type RadioItem = {
  value: string | number | boolean;
  label: string | number | boolean;
};

export type FieldWrapperBoxProps = {
  labelValue?: string | React.ReactNode;
  gridProps?: GridProps;
  containerInlineLabel?: BoxProps;
  isUserSetting?: boolean;
};

export type FieldRegistrationWithHookFormProps<T> = Omit<
  T,
  "error" | "label"
> & {
  registration?: Partial<UseFormRegisterReturn>;
  label?: string | React.ReactElement;
  error?: FieldError | undefined;
  placeholder?: string;
};

export type ControllerFieldForm<T> = FieldRegistrationWithHookFormProps<T> &
  FieldWrapperBoxProps &
  UseControllerProps;

export const TypographyNodataSC = styled(Typography)(() => ({
  marginTop: 10,
}));

type RadioFieldProps = ControllerFieldForm<SwitchProps> & {
  items: RadioItem[];
  radioProps?: RadioProps;
  onChangeRadioGroup?: (
    event: React.ChangeEvent<HTMLInputElement>,
    value: string | number | boolean
  ) => void;
  isBoolean?: boolean;
  isNumber?: boolean;
  isDisabled?: boolean;
  defaultValue?: any;
  label?: string;
  showError?: boolean;
  required?: boolean;
  explanation?: string;
};

export const RadioGroupField = (props: RadioFieldProps) => {
  const {
    name,
    defaultValue = false,
    items = [],
    radioProps = {},
    onChangeRadioGroup,
    isBoolean,
    isNumber,
    label,
    isDisabled = false,
    showError = true,
    required,
    explanation,
  } = props;
  const { t } = useTranslation();
  const { control } = useFormContext();

  return (
    <>
      {label && (
        <label className={label ?? "no-label"}>
          {label}
          {explanation && (
            <Tooltip title={explanation} placement="top-start">
              <HelpIcon fontSize={"small"} />
            </Tooltip>
          )}
          {required && <span style={{ color: "red" }}>*</span>}
        </label>
      )}
      <Controller
        name={name}
        control={control}
        defaultValue={defaultValue}
        render={({
          field: { onChange, value, ref, ...otherFields },
          fieldState: { error },
        }) => {
          const onChangeRadio = (
            event: React.ChangeEvent<HTMLInputElement>,
            value: string
          ) => {
            let newValue: string | number | boolean = value;

            if (isBoolean) {
              newValue = value === "true";
            }

            if (isNumber) {
              newValue = +value;
            }

            onChange(newValue);
            onChangeRadioGroup?.(event, newValue);
          };

          return (
            <>
              <RadioGroup
                row
                {...otherFields}
                onChange={onChangeRadio}
                defaultChecked={value}
                value={value}
              >
                {items[0] ? (
                  items.map(({ value, label }, index: number) => {
                    return (
                      <FormControlLabel
                        disabled={isDisabled}
                        inputRef={ref}
                        key={index}
                        value={value}
                        control={<Radio {...radioProps} />}
                        label={t(`${label ?? ""}`)}
                      />
                    );
                  })
                ) : (
                  <TypographyNodataSC>
                    {t("general.common.noDataRadio")}
                  </TypographyNodataSC>
                )}
              </RadioGroup>
              {error?.message && !!showError ? (
                <FormHelperText error>
                  {t(error?.message, { fieldName: label?.toLowerCase() })}
                </FormHelperText>
              ) : null}
            </>
          );
        }}
      />
    </>
  );
};
