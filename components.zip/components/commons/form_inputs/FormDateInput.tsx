import React from "react";
import { Controller, Control, FieldValues, Path } from "react-hook-form";
import { DateField } from "@mui/x-date-pickers";
import { useTranslation } from "react-i18next";

export interface FormDateInputProps<T extends FieldValues> {
  name: Path<T>;
  control: Control<T>;
  label?: string;
  rules?: Record<string, unknown>;
  variant?: "filled" | "outlined" | "standard";
  size?: "small" | "medium";
  required?: boolean;
  placeholder?: string;
}

export const FormDateInput = <T extends FieldValues>({
  name,
  control,
  label,
  rules,
  variant,
  size = "small",
  required,
  placeholder,
}: FormDateInputProps<T>) => {
  const [t] = useTranslation();

  return (
    <Controller
      name={name}
      control={control}
      rules={rules}
      render={({ field, fieldState: { error } }) => (
        <DateField
          {...field}
          className={label ?? "no-label"}
          label={label}
          variant={variant}
          fullWidth
          slotProps={{
            textField: {
              error: !!error,
              size: size,
              required: required,
              placeholder: placeholder,
            },
          }}
          helperText={
            error?.message ? t(error.message, { fieldName: label }) : undefined
          }
          InputLabelProps={{
            shrink: true,
          }}
        />
      )}
    />
  );
};
