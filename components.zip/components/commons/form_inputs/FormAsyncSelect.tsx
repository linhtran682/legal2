import { Control, Controller, FieldValues, Path } from "react-hook-form";
import HelpIcon from "@mui/icons-material/Help";
import { AsyncSelect } from "../inputs/async_select/AsyncSelect";
import { useTranslation } from "react-i18next";
import { Tooltip } from "@mui/material";
import { HTMLAttributes, ReactNode } from "react";

export interface FormAsyncSelectProps<T extends FieldValues, Option> {
  name: Path<T>;
  control: Control<T>;
  label?: string;
  placeholder?: string;
  placeholderFull?: string;
  rules?: Record<string, unknown>;
  variant?: "filled" | "outlined" | "standard";
  keyQuery: string;
  getOptions: (keyword: string | string[]) => Promise<Option[]>;
  getOptionLabel: (option: Option) => string;
  getOptionKey: (option: Option) => string;
  size?: "small" | "medium";
  required?: boolean;
  explanation?: string;
  groupBy?: (option: Option) => string;
  debounceMs?: number;
  minCharLength?: number;
  isOptionEqualToValue?: (option: Option, value: Option) => boolean;
  onChange?: (
    selectedOptionKey: string | undefined,
    option?: Option | null | undefined
  ) => void;
  disabled?: boolean;
  initialValue?: Option;
  isFocus?: boolean;
  noShowErrorNotification?: boolean;
  renderOption?: (
    optionProps: HTMLAttributes<HTMLLIElement> & {
      key: any;
    },
    option: Option,
    selected: boolean) => ReactNode;
}

export const FormAsyncSelect = <T extends FieldValues, Option>({
  name,
  control,
  label,
  rules,
  variant,
  keyQuery,
  getOptionKey,
  getOptionLabel,
  getOptions,
  size = "small",
  required,
  explanation,
  groupBy,
  debounceMs,
  minCharLength,
  isOptionEqualToValue,
  onChange,
  placeholder,
  disabled,
  initialValue,
  isFocus,
  placeholderFull,
  renderOption,
  noShowErrorNotification,
}: FormAsyncSelectProps<T, Option>) => {
  const [t] = useTranslation();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', justifyItems: 'center' }}>
      {label && (
        <label >
          {label}
          {explanation && (
            <Tooltip title={explanation} placement="top-start">
              <HelpIcon fontSize={"small"} />
            </Tooltip>
          )}
          {required && <span style={{ color: "red" }}>*</span>}
        </label>
      )}
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <AsyncSelect
            {...field}
            // label={
            //   label ? (
            //     <>
            //       {label}
            //       {explanation && (
            //         <Tooltip title={explanation} placement="top-start">
            //           <HelpIcon fontSize={"small"} />
            //         </Tooltip>
            //       )}
            //     </>
            //   ) : undefined
            // }
            placeholder={
              placeholderFull ||
              (placeholder
                ? t(`common.place_holder.select_value`, {
                  fieldName: placeholder.toLocaleLowerCase(),
                }).replace(/&amp;/g, "&").replace(/&#x2F;/g, "/")
                : undefined)
            }
            renderOption={renderOption}
            initialValue={initialValue}
            variant={variant}
            fullWidth
            keyQuery={keyQuery}
            getOptionKey={getOptionKey}
            getOptionLabel={getOptionLabel}
            getOptions={getOptions}
            error={!!error}
            helperText={
              error?.message &&
              t(error?.message, {
                fieldName: label
                  ? t(label)?.toLocaleLowerCase()
                  : placeholder?.toLocaleLowerCase()
                    ? t(placeholder)?.toLocaleLowerCase()
                    : "",
              })
            }
            size={size}
            required={required}
            shrink
            groupBy={groupBy}
            debounceMs={debounceMs}
            minCharLength={minCharLength}
            isOptionEqualToValue={isOptionEqualToValue}
            onChange={(selectedKey, option) => {
              field.onChange(selectedKey);
              onChange && onChange(selectedKey, option);
            }}
            disabled={disabled || field.disabled}
            isFocus={isFocus}
            noShowErrorNotification={noShowErrorNotification}
          />
        )}
      />
    </div>
  );
};
