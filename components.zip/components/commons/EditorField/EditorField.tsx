import { Box, FormHelperText, Tooltip } from "@mui/material";
import dynamic from "next/dynamic";
import { LegacyRef, useRef } from "react";
import { Control, FieldValues, Path, useController } from "react-hook-form";
import ReactQuill, { ReactQuillProps } from "react-quill";
import HelpIcon from "@mui/icons-material/Help";
import "react-quill/dist/quill.snow.css";
import { formatsEditorField } from "@/constants/format";
import { useTranslation } from "react-i18next";

interface ReactQuillWrapperProps extends ReactQuillProps {
  forwardedRef: LegacyRef<ReactQuill>;
}

const ReactQuillWrapper = dynamic(
  async () => {
    const { default: RQ } = await import("react-quill");

    const Component = ({ forwardedRef, ...props }: ReactQuillWrapperProps) => {
      return <RQ ref={forwardedRef} {...props} />;
    };
    return Component;
  },
  { ssr: false }
);

export type EditorFieldProps<T extends FieldValues> = {
  name: Path<T>;
  control: Control<T>;
  label?: string;
  required?: boolean;
  explanation?: string;
};

export function EditorField<T extends FieldValues>({
  name,
  control,
  label,
  required = false,
  explanation,
}: EditorFieldProps<T>) {
  const {
    field: { onChange, value },
    fieldState: { error },
  } = useController({
    name,
    control,
  });
  const [t] = useTranslation();
  const editorRef = useRef(null);
  const modules = {
    toolbar: {
      container: [
        [{ header: [1, 2, 3, 4, 5, false] }],
        [{ font: [] }],
        [{ size: ["small", false, "large", "huge"] }],
        ["bold", "italic", "underline", "strike", "blockquote"],
        [{ color: [] }, { background: [] }],
        [
          { align: "" },
          { align: "center" },
          { align: "right" },
          { align: "justify" },
        ],
        [
          { list: "ordered" },
          { list: "bullet" },
          { indent: "-1" },
          { indent: "+1" },
        ],
        ["clean"],
      ],
      handlers: {},
    },
  };

  return (
    <Box sx={{ mb: 1.5 }}>
      {label && (
        <label
          className={label ?? "no-label"}
          style={{ display: "block", marginBottom: "5px" }}
        >
          {label}
          {explanation && (
            <Tooltip title={explanation} placement="top-start">
              <HelpIcon fontSize={"small"} />
            </Tooltip>
          )}
          {required && <span style={{ color: "red" }}>*</span>}
        </label>
      )}
      <Box sx={{ borderRadius: "5px" }}>
        <ReactQuillWrapper
          forwardedRef={editorRef}
          theme="snow"
          modules={modules}
          formats={formatsEditorField}
          value={value}
          onChange={(content) => onChange(content)}
        />
      </Box>

      {error?.message && (
        <FormHelperText sx={{color:"#d32f2f"}}>
          {t(error.message, { fieldName: label })}
        </FormHelperText>
      )}
    </Box>
  );
}
