import { COLOR_TYPE } from '@/constants/color';
import { LANGUAGES } from '@/locales/config-translation';
import { Department } from '@/models/department/Department';
import PeopleRoundedIcon from '@mui/icons-material/PeopleRounded';
import { Stack, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';

interface SharedDepartmentItem {
  department: Department;
}

const SharedDepartmentItem = (props: SharedDepartmentItem) => {
  const { department } = props;
  const { t, i18n } = useTranslation();
  const isEn = i18n.language === LANGUAGES.ENGLISH;

  return (
    <Stack py={1.5} direction={'row'} width={'100%'} alignItems={'center'} gap={2}>
      <Stack width={44} height={44} alignItems={'center'} justifyContent={'center'}>
        <PeopleRoundedIcon />
      </Stack>
      <Typography sx={{ flex: 1, fontWeight: '700' }}>{department?.[isEn ? 'nameEnglish' : 'name']}</Typography>
      <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA4, fontWeight: '700', }}>{t('share.department')}</Typography>
    </Stack>
  )
}

export default SharedDepartmentItem