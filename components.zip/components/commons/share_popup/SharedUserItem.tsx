import { COLOR_TYPE } from '@/constants/color'
import { Box, Stack, Typography } from '@mui/material'
import { TextAvatar } from '../avatar/TextAvatar'
import { BasedUser } from '@/models/user/User';
import { useTranslation } from 'react-i18next';
import { LANGUAGES } from '@/locales/config-translation';


interface SharedUserItemProps {
  user?: BasedUser;
  isOwner?: boolean;

}
export const capsuleSx = {
  backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
  padding: '5px 20px'
}
export const labelSx = {
  fontSize: '14px',
  color: COLOR_TYPE.NEUTRALS.GRAY6
}

const infoSx = {
  fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA4, fontWeight: '700',
}
const SharedUserItem = (props: SharedUserItemProps) => {
  const {
    user,
    isOwner = false
  } = props;
  const { t, i18n } = useTranslation();
  const isEn = i18n.language === LANGUAGES.ENGLISH;


  return <Stack py={1.5} width={'100%'} direction={'row'} alignItems={'center'} gap={2}>
    <TextAvatar size={44} bgColor={COLOR_TYPE.BLUE.BLUE6} name={user?.name} />
    <Stack flex={1}>
      <Typography sx={{ fontWeight: '700' }}>{user?.name}</Typography>
      <Typography sx={{ fontSize: '14px' }}>{user?.email}</Typography>
    </Stack>
    {isOwner ? <Box sx={{
      ...capsuleSx,
      borderRadius: '50px',
    }}>
      <Typography sx={labelSx}>{t('share.owner')}</Typography>
    </Box> :
      ((user?.position?.name || user?.department?.name) ?
        <Typography sx={infoSx}>{`${user?.position ? `${user?.position?.[isEn ? 'nameEnglish' : 'name']}/` : ''}${user?.department?.[isEn ? 'nameEnglish' : 'name'] ?? ''}`}</Typography>
        : null)
    }
  </Stack >
}
export default SharedUserItem