import { getDepartments } from '@/apis/service/department/department'
import { getUsers } from '@/apis/service/user/User'
import { COLOR_TYPE } from '@/constants/color'
import { FILTER_DEBOUNCE_MS } from '@/constants/filter'
import { GLOBAL_SPACING } from '@/constants/format'
import { formInputSxProps } from '@/constants/theme'
import { LANGUAGES } from '@/locales/config-translation'
import { Department } from '@/models/department/Department'
import { BasedUser, UserProfileDTO } from '@/models/user/User'
import LockPersonIcon from '@mui/icons-material/LockPerson'
import { Box, Divider, Grid, Stack, Typography } from '@mui/material'
import { Fragment, useEffect } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { FormActionButtons } from '../action_button/FormActionButtons'
import { FormMultipleSelect } from '../form_inputs/FormMultipleSelect'
import { FormSelect } from '../form_inputs/FormSelect'
import { FormSelectTreeView } from '../form_inputs/FormSelectTreeView'
import CheckboxInput from '../inputs/checkbox/CheckboxInput'
import { ModalCommon } from '../popups/modal/Modal'
import { TextAvatar } from '../search_panel/SearchResultItem'
import SharedDepartmentItem from './SharedDepartmentItem'
import SharedUserItem, { labelSx } from './SharedUserItem'


interface SharePopupProps {
  titlePopup?: string;
  isOpen: boolean;
  owner?: BasedUser;
  pics?: BasedUser[];
  onSubmit?: any;
  initialValue?: any;
  setIsOpen: (isOpen: boolean, reload?: boolean) => void;
}

const dividerSx = { borderColor: COLOR_TYPE.TOYOTA.TOYOTA7 }
const SharePopup = (props: SharePopupProps) => {
  const { t, i18n } = useTranslation();
  const isEn = i18n.language === LANGUAGES.ENGLISH;
  const {
    titlePopup = 'share.title',
    isOpen,
    owner,
    pics,
    onSubmit,
    initialValue,
    setIsOpen
  } = props;

  const form = useForm({
    // defaultValues: {
    //   legalAccessType: 1,
    //   departmentIds: [],
    //   userIds: [],
    //   sharedDepartments: []
    // }
  });

  useEffect(() => {
    if (initialValue) {
      form.reset({
        legalAccessType: initialValue?.legalAccessType ?? 1,
        departmentIds: initialValue?.sharedDepartments?.map((d: Department) => d?.id) ?? [],
        sharedDepartments: initialValue?.sharedDepartments,
        userIds: initialValue?.sharedUsers?.map((user: BasedUser) => ({
          ...user,
          department: user?.departmentResponse,
          position: user?.positionResponse,
        }))
      })
    }
  }, [initialValue])

  const onCloseForm = (reload = false) => {
    setIsOpen(false, reload);
    // form.reset({});
  }
  return (
    <ModalCommon title={t(titlePopup)} open={isOpen} onClose={() => onCloseForm()}>
      <FormProvider {...form}>
        <Grid container className="form-wrapper" width={'100%'}>
          <Box
            // direction={"column"}
            // rowGap={GLOBAL_SPACING}
            alignItems={"center"}
            className="form-section-wrapper"
            sx={{
              ...formInputSxProps, paddingBottom: 0,
              padding: "16px",
              display: 'flex', height: '74vh', flexDirection: 'column',
              gap: 2
            }}
          >
            <Stack width={"100%"} flex="0 0 auto" >
              <FormSelectTreeView
                showAllSelected={false}
                name={"departmentIds"}
                control={form.control}
                label={t("share.department")}
                getOptions={async (keyword) => {
                  try {
                    const response = await getDepartments({
                      searchTerm: keyword,
                    });
                    const first100Departments: Department[] = (
                      response?.departments ?? []
                    ).slice(0, 150);
                    return first100Departments; // Assuming the data is in response.data
                  } catch (e) {
                    return [];
                  }
                }}
                getOptionLabel={(option) => option?.[isEn ? 'nameEnglish' : 'name'] ?? ""}
                getOptionKey={(option) => option.id ?? ""}
                getOptionChildren={(option) => option.children}
                variant='outlined'
                debounceMs={FILTER_DEBOUNCE_MS}
                onChange={(value: Department[]) => {
                  const mappedValue: string[] = value.map(
                    (item) => item.id ?? ""
                  );
                  form.setValue("departmentIds", mappedValue);
                  form.setValue("sharedDepartments", value);
                }}
                rules={{ required: "This field is required" }}
                // required
                selectedItemsProp={
                  props?.initialValue?.sharedDepartments ?? undefined
                }
                ignoreChildren
              />
              <Box height={GLOBAL_SPACING} />
              <FormMultipleSelect<any, UserProfileDTO>
                control={form.control}
                name={"userIds"}
                label={t("share.user")}
                placeholder={t('share.user')}
                getOptions={async (keyword) => {
                  const excludedIds: string[] = [];
                  owner && excludedIds.push(owner.id);
                  pics?.length && excludedIds.push(...(pics.map((p) => p.id)));
                  const response = await getUsers({
                    searchTerm: keyword,
                    page: 0,
                    size: 100,
                    sortBy: "name",
                    sortOrder: "ASC",
                  });

                  return response?.users?.filter((u) => !excludedIds?.includes(u.id)) ?? [];
                }}
                getOptionLabel={(option) =>
                  `${option.name ?? ""} (${option.email ?? ""}) - ${option?.department?.name ?? ""
                  }`
                }
                getSelectedOptionLabel={(option) =>
                  `${option.name ?? ""}`
                }
                getOptionKey={(option) => option.id}
                keyQuery='queryUser-share'
                showAllSelected={false}
                disableCloseOnSelect={true}
                renderOption={(optionProps, option, selected) => {
                  const { key, ...rest } = optionProps;
                  return <li key={key} {...rest} style={{ padding: 0 }}>
                    <Stack direction={'row'} p={1.5} py={0.25} gap={2}
                      width={'100%'}
                    >
                      <CheckboxInput
                        borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
                        borderWidth={1}
                        size={18}
                        checked={selected}
                      />
                      <Stack width={'100%'} direction={'row'} alignItems={'center'} gap={1.5}>
                        <TextAvatar size={32} bgColor={COLOR_TYPE.BLUE.BLUE6} name={option?.name} />
                        <Stack flex={1}>
                          <Typography sx={{ fontWeight: '700', fontSize: '14px' }}>{option?.name}</Typography>
                          <Typography sx={{ fontSize: '12px' }}>{option?.email}</Typography>
                        </Stack>
                        {(option?.position?.name || option?.department?.name) ?
                          <Typography sx={{ ...labelSx, fontSize: '12px', textAlign: 'right' }}>{`${option?.position ? `${option?.position?.[isEn ? 'nameEnglish' : 'name']}/` : ''}${option?.department?.[isEn ? 'nameEnglish' : 'name'] ?? ''}`}</Typography>
                          : null
                        }
                      </Stack >
                    </Stack>
                    <Divider sx={dividerSx} />
                  </li>
                }}
              />

            </Stack>

            {/*  */}
            <Stack width={"100%"} sx={{ overflow: 'auto' }} flex="flex: 1 0 auto">
              <SharedUserItem user={owner} isOwner key={owner?.id} />
              <Divider sx={dividerSx} />
              {
                form.watch('userIds')?.map?.((user: BasedUser) => (
                  <Fragment key={user?.id}>
                    <SharedUserItem user={user} />
                    <Divider sx={dividerSx} />
                  </Fragment>
                ))
              }
              {
                form.watch('sharedDepartments')?.map?.((department: Department) => (
                  <Fragment key={department?.id}>
                    <SharedDepartmentItem department={department} />
                    <Divider sx={dividerSx} />
                  </Fragment>
                ))
              }
            </Stack>


            {/*  */}
            <Stack width={"100%"} flex="0 0 auto">
              <Typography sx={{ fontWeight: "700", mb: '10px' }}>{t('share.generalAccess')}</Typography>
              <Stack width={{ xs: '100%', md: '50%' }} direction={'row'} alignItems={'center'} gap={1} >
                <LockPersonIcon />
                {/* <Box sx={{ width: '400px' }}> */}
                <FormSelect
                  options={[
                    { label: "share.public", value: 2 },
                    { label: "share.private", value: 1 },
                  ]}
                  control={form.control}
                  getOptionKey={(option) => option.value}
                  getOptionLabel={(option) => t(option?.label)}
                  name='legalAccessType'
                />
                {/* </Box> */}
              </Stack>


            </Stack>

          </Box>
        </Grid>
        <FormActionButtons
          formMode={"update"}
          // loading={isPending}
          onCancel={() => onCloseForm()}
          cancelConfirm={form.formState.isDirty}
          onSave={async (data) => {
            const params = {
              userIds: data?.userIds?.map((user: BasedUser) => user?.id) ?? [],
              departmentIds: data?.departmentIds ?? [],
              legalAccessType: data?.legalAccessType
            }
            await onSubmit?.(params);
            onCloseForm(true);
          }}
        />
      </FormProvider>
    </ModalCommon >
  )
}

export default SharePopup




