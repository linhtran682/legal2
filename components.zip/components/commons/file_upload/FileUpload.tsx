import React, { ChangeEvent } from "react";
import {
  FormControl,
  InputLabel,
  IconButton,
  Chip,
  Box,
  Grid,
} from "@mui/material";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import { COLOR_TYPE } from "@/constants/color";
import { IconAdd } from "@/assets/images/icons/iconAdd";

export interface FileDetails {
  name: string;
  file: File;
}
interface FileUploadComponentProps {
  files: FileDetails[];
  setFiles: (files: FileDetails[]) => void;
}

const FileUploadComponent: React.FC<FileUploadComponentProps> = ({
  files,
  setFiles,
}) => {
  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const newFiles = event.target.files;
    if (newFiles) {
      const newFileDetails = Array.from(newFiles).map((file) => ({
        name: file.name,
        file,
      }));
      setFiles([...files, ...newFileDetails]);
    }
  };

  const handleButtonClick = () => {
    document.getElementById("file-input")?.click();
  };

  const handleDelete = (fileName: string) => {
    setFiles(files.filter((file) => file.name !== fileName));
  };

  return (
    <Box sx={{ width: "100%" }}>
      <FormControl fullWidth>
        <InputLabel shrink htmlFor="file-input">
          Tệp
        </InputLabel>
      </FormControl>
      <Grid container alignItems="center" spacing={1}>
        <Grid item xs>
          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
              marginTop: "8px",
            }}
          >
            {files.map((file) => (
              <Chip
                key={file.name}
                icon={
                  <AttachFileIcon
                    style={{
                      color: COLOR_TYPE.TOYOTA.TOYOTA1,
                      transform: "rotate(45deg)",
                    }}
                  />
                }
                label={file.name}
                onDelete={() => handleDelete(file.name)}
                style={{ margin: "4px" }}
              />
            ))}
          </Box>
        </Grid>
        <Grid item>
          <IconButton color="error" onClick={handleButtonClick}>
            <IconAdd />
          </IconButton>
        </Grid>
      </Grid>
      <input
        id="file-input"
        type="file"
        multiple
        onChange={handleFileChange}
        style={{ display: "none" }}
      />
    </Box>
  );
};
export default FileUploadComponent;
