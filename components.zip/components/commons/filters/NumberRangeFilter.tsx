/* eslint-disable @typescript-eslint/no-explicit-any */
import Box from "@mui/material/Box";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useEffect, useRef, useState } from "react";
import { NumberRangeInput } from "../inputs/number_range_input/NumberRangeInput";
import {
  FILTER_DEBOUNCE_MS,
  filterBoxSxProps,
  FilterOperators,
} from "@/constants/filter";

export const NumberRangeFilter = (props: GridFilterInputValueProps) => {
  const { item, applyValue } = props;

  const filterTimeout = useRef<any>();
  const [filterValueState, setFilterValueState] = useState<
    [number | undefined, number | undefined]
  >([undefined, undefined]);

  useEffect(() => {
    return () => {
      clearTimeout(filterTimeout.current);
    };
  }, []);

  useEffect(() => {
    setFilterValueState(item.value ?? [undefined, undefined]);
  }, [item]);

  const updateFilterValue = (
    range: [number | undefined, number | undefined]
  ) => {
    clearTimeout(filterTimeout.current);
    setFilterValueState(range);

    filterTimeout.current = setTimeout(() => {
      applyValue({ ...item, value: range });
    }, FILTER_DEBOUNCE_MS);
  };

  return (
    <Box sx={filterBoxSxProps}>
      <NumberRangeInput
        range={filterValueState}
        onChange={updateFilterValue}
        shrink
      />
    </Box>
  );
};

export const getNumberIntervalOperators = (
  t: any
): GridFilterOperator<any, number>[] => [
  {
    label: t(FilterOperators.NUMBER_RANGE.BETWEEN),
    value: FilterOperators.NUMBER_RANGE.BETWEEN,
    getApplyFilterFn: () => null,
    InputComponent: NumberRangeFilter,
  },
];
