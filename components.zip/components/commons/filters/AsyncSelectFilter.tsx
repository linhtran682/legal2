/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import {
  FILTER_DEBOUNCE_MS,
  filterBoxSxProps,
  FilterOperators,
} from "@/constants/filter";
import { AsyncSelect } from "../inputs/async_select/AsyncSelect";

interface AsyncSelectOperatorProps<T> {
  keyQuery: string;
  getOptions: (keyword: string | string[]) => Promise<T[]>;
  getOptionLabel: (option: T) => string;
  getOptionKey: (option: T) => string;
  label?: string;
}

interface AsyncSelectFilterProps<T>
  extends GridFilterInputValueProps,
    AsyncSelectOperatorProps<T> {}

function AsyncSelectFilter<T>(props: AsyncSelectFilterProps<T>) {
  const { item, applyValue } = props;

  const [selectedOptionKey, setSelectedOptionKey] = useState<string>(
    item.value ?? ""
  );
  
  useEffect(() => {
    setSelectedOptionKey(item.value ?? "");
  }, [item.value]);

  const updateSelecedOptions = (selectedOptionKey: string | undefined) => {
    if (selectedOptionKey) {
      setSelectedOptionKey(selectedOptionKey);
      applyValue({ ...item, value: selectedOptionKey });
    }
  };

  return (
    <Box sx={filterBoxSxProps}>
      <AsyncSelect
        // label={props.label}
        label=""
        keyQuery={props.keyQuery}
        value={selectedOptionKey}
        getOptionKey={props.getOptionKey}
        getOptionLabel={props.getOptionLabel}
        getOptions={props.getOptions}
        onChange={updateSelecedOptions}
        variant="standard"
        shrink
        debounceMs={FILTER_DEBOUNCE_MS}
        fullWidth
      />
    </Box>
  );
}

export function getAsyncSelectOperators<T>(
  props: AsyncSelectOperatorProps<T>,
  t: any
): GridFilterOperator<any, T[]>[] {
  return [
    {
      label: t(FilterOperators.ASYNC_SELECT.IS),
      value: FilterOperators.ASYNC_SELECT.IS,
      getApplyFilterFn: () => null,
      InputComponent: (defaultProps) => (
        <AsyncSelectFilter
          {...defaultProps}
          {...props}
          label={t(FilterOperators.ASYNC_SELECT.IS)}
        />
      ),
    },
  ];
}
