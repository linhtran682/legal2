/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import {
  FILTER_DEBOUNCE_MS,
  filterBoxSxProps,
  FilterOperators,
} from "@/constants/filter";
import { MultipleTreeSelect } from "../inputs/multiple_tree_select/MultipleTreeSelect";

interface MultipleTreeSelectOperatorProps<T> {
  keyQuery: string;
  getOptions: (keyword: string) => Promise<T[]>;
  getOptionChildren: (option: T) => T[] | undefined;
  getOptionLabel: (option: T) => string;
  getOptionKey: (option: T) => string;
  label?: string;
}

interface MultipleTreeSelectFilterProps<T>
  extends GridFilterInputValueProps,
    MultipleTreeSelectOperatorProps<T> {}

function MultipleTreeSelectFilter<T>(props: MultipleTreeSelectFilterProps<T>) {
  const { item, applyValue } = props;

  const [selectedOption, setSelectedOption] = useState<T[]>(item.value ?? []);

  useEffect(() => {
    setSelectedOption(item.value ?? []);
  }, [item.value]);

  const updateSelecedOptions = (selectedOptionKeys: T[]) => {
    setSelectedOption(selectedOptionKeys);
    applyValue({ ...item, value: selectedOptionKeys });
  };

  return (
    <Box sx={filterBoxSxProps}>
      <MultipleTreeSelect
        // label={props.label}
        label={''}
        value={selectedOption}
        getOptions={props.getOptions}
        getOptionChildren={props.getOptionChildren}
        getOptionKey={props.getOptionKey}
        getOptionLabel={props.getOptionLabel}
        onChange={updateSelecedOptions}
        keyQuery='test'
        shrink
        variant='standard'
        size='small'
        fullWidth
        debounceMs={FILTER_DEBOUNCE_MS}
      />
    </Box>
  );
}

export function getMultipleTreeSelectOperators<T>(
  props: MultipleTreeSelectOperatorProps<T>,
  t: any
): GridFilterOperator<any, T[]>[] {
  return [
    {
      label: t(FilterOperators.MULTIPLE_SELECT.EXISTED_IN),
      value: FilterOperators.MULTIPLE_SELECT.EXISTED_IN,
      getApplyFilterFn: () => null,
      InputComponent: (defaultProps) => (
        <MultipleTreeSelectFilter
          {...defaultProps}
          {...props}
          label={t(FilterOperators.MULTIPLE_SELECT.EXISTED_IN)}
        />
      ),
    },
  ];
}
