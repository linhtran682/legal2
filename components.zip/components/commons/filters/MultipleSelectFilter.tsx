/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { MultipleSelect } from "../inputs/multiple_select/MultipleSelect";
import {
  FILTER_DEBOUNCE_MS,
  filterBoxSxProps,
  FilterOperators,
} from "@/constants/filter";

interface MultipleSelectOperatorProps<T> {
  keyQuery: string;
  getOptions: (keyword: string) => Promise<T[]>;
  getOptionLabel: (option: T) => string;
  getOptionKey: (option: T) => string | number;
  label?: string;
}

interface MultipleSelectFilterProps<T>
  extends GridFilterInputValueProps,
    MultipleSelectOperatorProps<T> {}

function MultipleSelectFilter<T>(props: MultipleSelectFilterProps<T>) {
  const { item, applyValue } = props;

  const [selectedOption, setSelectedOption] = useState<T[]>(item.value ?? []);

  useEffect(() => {
    setSelectedOption(item.value ?? []);
  }, [item.value]);

  const updateSelecedOptions = (selectedOption: T[]) => {
    setSelectedOption(selectedOption);
    applyValue({ ...item, value: selectedOption });
  };

  return (
    <Box sx={filterBoxSxProps}>
      <MultipleSelect
        // label={props.label}
        label=""
        keyQuery={props.keyQuery}
        value={selectedOption}
        getOptionKey={props.getOptionKey}
        getOptionLabel={props.getOptionLabel}
        getOptions={props.getOptions}
        onChange={updateSelecedOptions}
        variant='standard'
        shrink
        debounceMs={FILTER_DEBOUNCE_MS}
        fullWidth
      />
    </Box>
  );
}

export function getMultipleSelectOperators<T>(
  props: MultipleSelectOperatorProps<T>,
  t: any
): GridFilterOperator<any, T[]>[] {
  return [
    {
      label: t(FilterOperators.MULTIPLE_SELECT.EXISTED_IN),
      value: FilterOperators.MULTIPLE_SELECT.EXISTED_IN,
      getApplyFilterFn: () => null,
      InputComponent: (defaultProps) => (
        <MultipleSelectFilter
          {...defaultProps}
          {...props}
          label={t(FilterOperators.MULTIPLE_SELECT.EXISTED_IN)}
        />
      ),
    },
  ];
}
