/* eslint-disable @typescript-eslint/no-explicit-any */
import { filterBoxSxProps, FilterOperators } from "@/constants/filter";
import { Box, FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useContext, useEffect, useState } from "react";
import {
  MultipleFilterTableModalContext,
  MultipleFilterTableModalState,
} from "../tables/multiple_filter_table/multiple_filter_table_bar/multiple_filter_table_modal/MultipleFilterTableModal";

interface SelectOperatorProps<T> {
  options: T[];
  getOptions?: (modalState: MultipleFilterTableModalState) => T[];
  getOptionLabel: (option: T) => string;
  getOptionKey: (option: T) => string | number;
  label?: string;
}

interface SelectFilterProps<T>
  extends GridFilterInputValueProps,
    SelectOperatorProps<T> {}

function SelectFilter<T>(props: SelectFilterProps<T>) {
  const { item, applyValue } = props;

  const modalContext = useContext(MultipleFilterTableModalContext);

  const [options, setOptions] = useState(() => props.options);
  const [selectedOption, setSelectedOption] = useState<string>(
    item.value ?? ""
  );

  useEffect(() => {
    modalContext?.filterMap &&
      props.getOptions &&
      setOptions(props.getOptions(modalContext));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modalContext]);

  useEffect(() => {
    setSelectedOption(item.value ?? "");
  }, [item.value]);

  const updateKeyword = (keyword: string) => {
    setSelectedOption(keyword);
    applyValue({ ...item, value: keyword });
  };

  return (
    <Box sx={filterBoxSxProps}>
      <FormControl variant='standard' fullWidth>
        <InputLabel id='select-label' shrink>
          {props.label}
        </InputLabel>
        <Select
          fullWidth
          label={props.label}
          labelId='select-label'
          variant={"standard"}
          size='small'
          value={selectedOption}
          onChange={(e) => updateKeyword(e.target.value ?? "")}
        >
          {(options || []).map((option) => (
            <MenuItem
              value={props.getOptionKey(option)}
              key={props.getOptionKey(option)}
            >
              {props.getOptionLabel(option)}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
}

export function getSelectOperators<T>(
  props: SelectOperatorProps<T>,
  t: any
): GridFilterOperator<any, T[]>[] {
  return [
    {
      label: t(FilterOperators.SELECT.IS),
      value: FilterOperators.SELECT.IS,
      getApplyFilterFn: () => null,
      InputComponent: (defaultProps) => (
        <SelectFilter
          {...defaultProps}
          {...props}
          label={t(FilterOperators.SELECT.IS)}
        />
      ),
    },
  ];
}
