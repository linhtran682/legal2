/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  FILTER_DEBOUNCE_MS,
  filterBoxSxProps,
  FilterOperators,
} from "@/constants/filter";
import { Box, TextField } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useEffect, useRef, useState } from "react";
// import { useTranslation } from "react-i18next";

const KeywordFilter = (props: GridFilterInputValueProps) => {
  // const [t] = useTranslation();
  const { item, applyValue } = props;

  const filterTimeout = useRef<any>();
  const [keyword, setKeyword] = useState<string>(item.value ?? "");

  useEffect(() => {
    return () => {
      clearTimeout(filterTimeout.current);
    };
  }, []);

  useEffect(() => {
    setKeyword(item.value ?? "");
  }, [item.value]);

  const updateKeyword = (keyword: string) => {
    clearTimeout(filterTimeout.current);
    setKeyword(keyword);

    filterTimeout.current = setTimeout(() => {
      applyValue({ ...item, value: keyword });
    }, FILTER_DEBOUNCE_MS);
  };

  return (
    <Box sx={filterBoxSxProps}>
      <TextField
        fullWidth
        // label={t(FilterOperators.KEY_WORD.CONTAINS)}
        label={''}
        variant={"standard"}
        InputLabelProps={{ shrink: true }}
        value={keyword}
        onChange={(e) => updateKeyword(e.target.value ?? "")}
      />
    </Box>
  );
};

export const getKeywordOperators = (
  t: any
): GridFilterOperator<any, Date>[] => [
  {
    label: t(FilterOperators.KEY_WORD.CONTAINS),
    value: FilterOperators.KEY_WORD.CONTAINS,
    getApplyFilterFn: () => null,
    InputComponent: KeywordFilter,
  },
];
