/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  FilterOperators
} from "@/constants/filter";
import { formInputSxProps } from "@/constants/theme";
import { Box, Grid } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useEffect, useRef, useState } from "react";
import { Range } from "react-date-range";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import DateInput from "../inputs/date_input/DateInput";

const DateRangeFilter = (props: GridFilterInputValueProps) => {
  const [t] = useTranslation();
  const { item, applyValue } = props;

  const filterTimeout = useRef<any>();
  const [dateRange, setDateRange] = useState<Range>(item.value);

  useEffect(() => {
    setDateRange(item.value);
    form?.reset({
      from: item.value?.startDate,
      to: item.value?.endDate,
    })
  }, [item.value]);

  useEffect(() => {
    return () => {
      clearTimeout(filterTimeout.current);
    };
  }, []);

  // const updateDateRange = (dateRange: Range) => {
  //   clearTimeout(filterTimeout.current);
  //   setDateRange(dateRange);

  //   filterTimeout.current = setTimeout(() => {
  //     applyValue({ ...item, value: dateRange });
  //   }, FILTER_DEBOUNCE_MS);
  // };
  const updateStartDate = (date?: Date | undefined) => {
    const newDateRange = { ...(dateRange ?? {}) }
    newDateRange.startDate = date;
    clearTimeout(filterTimeout.current);
    setDateRange(newDateRange);

    applyValue({ ...item, value: newDateRange });
  };
  const updateEndDate = (date?: Date | undefined) => {
    const newDateRange = { ...(dateRange ?? {}) }
    newDateRange.endDate = date;
    clearTimeout(filterTimeout.current);
    setDateRange(newDateRange);

    applyValue({ ...item, value: newDateRange });
  };

  const form = useForm();
  return (
    <Box sx={{ ...formInputSxProps, marginTop: '-42px' }}>
      <Grid container spacing={2}>
        {/* <DateRangeInput
        // label={t(FilterOperators.DATE_RANGE.BETWEEN)}
        label=""
        value={dateRange}
        onChange={updateDateRange}
        variant="standard"
        shrink
      /> */}
        <Grid item xs={6} >
          <DateInput
            control={form.control}
            name="from"
            label=""
            placeholder={t("common.input.number_range.from")}
            maxDate={dateRange?.endDate}
            value={dateRange?.startDate}
            onChange={updateStartDate}
            shouldRemove
          />
        </Grid>
        <Grid item xs={6}>
          <DateInput
            control={form.control}
            name="to"
            label=""
            placeholder={t("common.input.number_range.to")}
            minDate={dateRange?.startDate}
            value={dateRange?.endDate}
            onChange={updateEndDate}
            shouldRemove
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export const getDateRangeOperators = (
  t: any
): GridFilterOperator<any, Date>[] => [
    {
      label: t(FilterOperators.DATE_RANGE.BETWEEN),
      value: FilterOperators.DATE_RANGE.BETWEEN,
      getApplyFilterFn: () => null,
      InputComponent: DateRangeFilter,
    },
  ];
