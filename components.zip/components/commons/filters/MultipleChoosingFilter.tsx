/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, Chip, Grid } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterOperator,
} from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { filterBoxSxProps, FilterOperators } from "@/constants/filter";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { COLOR_TYPE } from "@/constants/color";

interface MultipleChoosingOperatorProps<T> {
  options: T[];
  getOptionLabel: (option: T) => string;
  getOptionKey: (option: T) => string | number;
}

interface MultipleChoosingFilterProps<T>
  extends GridFilterInputValueProps,
    MultipleChoosingOperatorProps<T> {}

function MultipleChoosingFilter<T>(props: MultipleChoosingFilterProps<T>) {
  const { item, applyValue } = props;

  const [selectedOptionKeys, setSelectedOptionKeys] = useState<
    (string | number)[]
  >(item.value ?? []);

  useEffect(() => {
    setSelectedOptionKeys(item.value ?? []);
  }, [item.value]);

  const updateSelecedOption = (selectedOptionKey: string | number) => {
    let newSelectedOptionKeys;

    if (selectedOptionKeys.includes(selectedOptionKey)) {
      newSelectedOptionKeys = selectedOptionKeys.filter(
        (optionKey) => optionKey != selectedOptionKey
      );
    } else {
      newSelectedOptionKeys = [...selectedOptionKeys, selectedOptionKey];
    }
    setSelectedOptionKeys(newSelectedOptionKeys);
    applyValue({ ...item, value: newSelectedOptionKeys });
  };

  return (
    <Box sx={filterBoxSxProps}>
      <Grid container direction={"row"} spacing={GLOBAL_SMALL_SPACING}>
        {props.options.map((option) => (
          <Grid item key={props.getOptionKey(option)}>
            <Chip
              variant='outlined'
              label={props.getOptionLabel(option)}
              sx={
                selectedOptionKeys.includes(props.getOptionKey(option))
                  ? {
                      borderRadius: 0,
                      backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA2,
                      color: COLOR_TYPE.TOYOTA.TOYOTA8,
                      "&.MuiChip-root:hover": {
                        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA4,
                      },
                      "&.MuiChip-root.MuiChip-clickable:hover": {
                        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA4,
                      },
                    }
                  : {
                      borderRadius: 0,
                    }
              }
              clickable
              onClick={() => updateSelecedOption(props.getOptionKey(option))}
            />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export function getMultipleChoosingOperators<T>(
  props: MultipleChoosingOperatorProps<T>,
  t: any
): GridFilterOperator<any, T[]>[] {
  return [
    {
      label: t(FilterOperators.MULTIPLE_SELECT.EXISTED_IN),
      value: FilterOperators.MULTIPLE_SELECT.EXISTED_IN,
      getApplyFilterFn: () => null,
      InputComponent: (defaultProps) => (
        <MultipleChoosingFilter {...defaultProps} {...props} />
      ),
    },
  ];
}
