import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
type TypeLabelBarChart = {
  x?: string | number;
  y?: string | number;
  value?: string | number;
};
/* TODO: fake data test */
// const data = [
//   {
//     name: "Phân công",
//     value: 24,
//   },
//   {
//     name: "Yêu cầu vendor làm bằng khuyến nghị",
//     value: 5.1,
//   },
//   {
//     name: "Cần gửi đi",
//     value: 11,
//   },
//   {
//     name: "Yêu cầu đánh giá",
//     value: 16.3,
//   },
//   {
//     name: "Đánh giá: Yêu cầu duyệt",
//     value: 17,
//   },
//   {
//     name: "Đánh giá: Duyệt",
//     value: 22,
//   },
//   {
//     name: "Phản hồi L&C",
//     value: 16.3,
//   },
//   {
//     name: "Done",
//     value: 22,
//   },
//   {
//     name: "Next action",
//     value: 22,
//   },
//   {
//     name: "Next Action: Yêu cầu duyệt",
//     value: 22,
//   },
//   {
//     name: "Đã đủ impact, next action",
//     value: 22,
//   },
//   {
//     name: "Theo dõi next action",
//     value: 22,
//   },
//   {
//     name: "Kiểm tra lại",
//     value: 22,
//   },
// ]

const Label = (props: TypeLabelBarChart) => {
  const { x, y, value } = props;

  return (
    <text
      x={x}
      y={y}
      dx="0.5%"
      dy="-3%"
      fontSize="14"
      fill="#181818"
      textAnchor="left"
    >
      {value}
    </text>
  );
};
type TypeItemBarChart = {
  name: string;
  value: number;
};
type TypeBarChartCommon = {
  data: TypeItemBarChart[];
  bars?: { dataKey: string; fill: string }[];
  dataKey?: string;
  strokeDasharray?: string;
  isTooltip?: boolean;
  height?: number;
  isLabel?: boolean;
  barSize?: number;
  barGap?: number | string;
  yAxisProps?: any;
  tooltipProps?: any;
};
export const BarChartCommon = (props: TypeBarChartCommon) => {
  const {
    data,
    bars = [{ dataKey: "value", fill: "rgba(40, 181, 25, 1)" }],
    dataKey = "name",
    strokeDasharray = "none",
    isTooltip,
    height = 350,
    isLabel = true,
    barSize = 32,
    barGap = 10,
    yAxisProps,
    tooltipProps,
  } = props;
  const maxDataValue = Math.max(...data?.map((d: any) => d?.value));
  const ticks = Array.from(
    { length: Math.ceil(maxDataValue / 5) + 1 },
    (_, i) => i * 5
  );
  return (
    <ResponsiveContainer width="100%" maxHeight={height} height={height}>
      <BarChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 90,
        }}
        barGap={barGap}
      >
        <CartesianGrid vertical={false} strokeDasharray={strokeDasharray} />
        <XAxis
          angle={-45}
          textAnchor="end"
          dataKey={dataKey}
          tickLine={false}
          tick={({ x, y, payload }) => {
            const textWidth = 55;
            const words = payload.value.split(" ");
            const lines = [];
            let currentLine = "";

            words.forEach((word: string) => {
              const testLine = currentLine ? `${currentLine} ${word}` : word;
              if (testLine.length * 7 > textWidth) {
                lines.push(currentLine);
                currentLine = word;
              } else {
                currentLine = testLine;
              }
            });

            if (currentLine) lines.push(currentLine);

            return (
              <text
                x={x}
                y={y + 15}
                fontSize={14}
                fill="#333"
                textAnchor="middle"
              >
                {lines.map((line, index) => (
                  <tspan key={index} x={x} dy={index === 0 ? 0 : 18}>
                    {line}
                  </tspan>
                ))}
              </text>
            );
          }}
        />
        <YAxis
          domain={[0, Math.max(...ticks)]}
          width={50}
          style={{ fontSize: 16 }}
          ticks={ticks}
          {...yAxisProps}
        />
        {isTooltip && <Tooltip {...tooltipProps} />}
        {bars?.map(({ dataKey, fill }: any, index: number) => (
          <Bar
            key={index}
            dataKey={dataKey}
            fill={fill}
            label={isLabel ? <Label /> : false}
            barSize={barSize}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
};
