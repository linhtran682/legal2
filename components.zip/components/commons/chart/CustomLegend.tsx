export const CustomLegend = ({ payload }: any) => {
  return (
    <ul>
      {payload?.map((entry: any, index: number) => (
        <li
          key={`item-${index}`}
          style={{
            listStyleType: "none",
            marginBottom: "15px",
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <span
            style={{
              backgroundColor: entry?.color,
              width: "24px",
              height: "24px",
              display: "inline-block",
              marginRight: "10px",
            }}
          ></span>
          <span style={{ fontSize: "14px" }}>
            {entry?.value ?? ""}
            <span style={{ fontWeight: "600" }}> ({entry?.payload?.value}%)</span>
          </span>
        </li>
      ))}
    </ul>
  );
};
