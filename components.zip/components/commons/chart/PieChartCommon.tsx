import React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts";
import { CustomLegend } from "./CustomLegend";

/* TODO: fake data test */
// data=[
//   {
//     name: "Theo dõi next action",
//     value: 20,
//     fill: "rgba(215, 215, 215, 1)",
//   },
//   {
//     name: "Hoàn thành",
//     value: 60,
//     fill: "rgba(59, 0, 237, 1)",
//   },
//   {
//     name: "Chưa hoàn thành",
//     value: 9,
//     fill: "rgba(216, 27, 96, 1)",
//   },
//   {
//     name: "Kiểm tra lại",
//     value: 11,
//     fill: "rgba(255, 152, 0, 1)",
//   },
// ]
type TypeItemDataPieChart = {
  name: string;
  value: number;
  fill?: string;
};
type TypePieChartCommon = {
  data: TypeItemDataPieChart[];
  height?: number | string;
  width?: number | string;
};
export const PieChartCommon = (props: TypePieChartCommon) => {
  const { data, height = 300, width = "100%", ...pieProps } = props;
  const renderCustomLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
  }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        fontWeight="bold"
        fontSize={14}
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
      >
        {percent ? `${(percent * 100).toFixed(0)}` : ""}
      </text>
    );
  };
  return (
    <ResponsiveContainer width={width} height={height}>
      <PieChart margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
        <Pie
          dataKey="value"
          data={data}
          cx="50%"
          cy="50%"
          outerRadius={80}
          label={renderCustomLabel}
          labelLine={false}
          {...pieProps}
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.fill} stroke="0" />
          ))}
        </Pie>
        <Legend
          content={<CustomLegend />}
          layout="vertical"
          align="right"
          verticalAlign="middle"
        />
      </PieChart>
    </ResponsiveContainer>
  );
};
