import { EmptyIcon } from "@/assets/images/icons/iconEmpty";
import { GLOBAL_SPACING } from "@/constants/format";
import { Stack, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";

interface EmptyIndicatorProps {
  bgColor?: string;
}

export const EmptyIndicator = (props: EmptyIndicatorProps) => {
  const [t] = useTranslation();
  const { bgColor } = props

  return (
    <Stack
      width={"100%"}
      height={"100%"}
      direction={"column"}
      alignItems={"center"}
      justifyContent={"center"}
      spacing={GLOBAL_SPACING}
      sx={{ backgroundColor: bgColor }}
    >
      <EmptyIcon />
      <Typography variant='h1'>{t("common.message.empty_title")}</Typography>
      <Typography variant='body2'>
        {t("common.message.empty_description")}
      </Typography>
    </Stack>
  );
};
