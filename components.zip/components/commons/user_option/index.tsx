import { COLOR_TYPE } from '@/constants/color';
import { Divider, Stack, Typography } from '@mui/material';
import CheckboxInput from '../inputs/checkbox/CheckboxInput';
import { TextAvatar } from '../search_panel/SearchResultItem';
export const labelSx = {
  fontSize: '14px',
  color: COLOR_TYPE.NEUTRALS.GRAY6
}
const dividerSx = { borderColor: COLOR_TYPE.TOYOTA.TOYOTA7 }

const renderUserOptions = (optionProps: any, option: any, selected: any, isEn: boolean, hasCheckbox: boolean = true) => {
  const { key, ...rest } = optionProps;
  return <li key={key} {...rest} style={{ padding: 0 }}>
    <Stack direction={'row'} p={1.5} py={0.25} gap={2}
      width={'100%'}
    >
      {hasCheckbox ? <CheckboxInput
        borderColor={COLOR_TYPE.TOYOTA.TOYOTA1}
        borderWidth={1}
        size={18}
        checked={selected}
      /> : null}
      <Stack width={'100%'} direction={'row'} alignItems={'center'} gap={1.5}>
        <TextAvatar size={32} bgColor={COLOR_TYPE.BLUE.BLUE6} name={option?.name} />
        <Stack flex={1}>
          <Typography sx={{ fontWeight: '700', fontSize: '14px' }}>{option?.name}</Typography>
          <Typography sx={{ fontSize: '12px' }}>{option?.email}</Typography>
        </Stack>
        {(option?.position?.name || option?.department?.name) ?
          <Typography sx={{ ...labelSx, fontSize: '12px', textAlign: 'right' }}>{`${option?.position ? `${option?.position?.[isEn ? 'nameEnglish' : 'name']}/` : ''}${option?.department?.[isEn ? 'nameEnglish' : 'name'] ?? ''}`}</Typography>
          : null
        }
      </Stack >
    </Stack>
    <Divider sx={dividerSx} />
  </li>
}

export default renderUserOptions