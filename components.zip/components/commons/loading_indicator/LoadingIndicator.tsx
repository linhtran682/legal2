import { GLOBAL_SPACING } from "@/constants/format";
import { CircularProgress, Grid } from "@mui/material";

export const LoadingIndicator = () => {
  return (
    <Grid
      container
      width={"100%"}
      height={"100%"}
      direction={"column"}
      alignItems={"center"}
      justifyContent={"center"}
      spacing={GLOBAL_SPACING}
    >
      <Grid item>
        <CircularProgress color='primary' />
      </Grid>
    </Grid>
  );
};
