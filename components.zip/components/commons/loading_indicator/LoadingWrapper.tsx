import { ReactNode } from "react";
import { LoadingIndicator } from "../loading_indicator/LoadingIndicator";

export interface LoadingWrapperProps {
  children: ReactNode | ReactNode[];
  loading: boolean;
}

export const LoadingWrapper = (props: LoadingWrapperProps) => {
  return (
    <>
      {props.loading && <LoadingIndicator />}
      {!props.loading && props.children}
    </>
  );
};
