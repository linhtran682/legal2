import { COLOR_TYPE } from "@/constants/color";
import { RemindPopupDTO } from "@/models/reminder_template/ReminderDTO";
import { Box, Divider, Stack, Typography } from "@mui/material";
import { FC } from "react";
import { getRedirectLink, moduleIconMap } from "./RemindPopup";
import Link from "next/link";
import { formatDate } from "@/utils";

interface NotificationRowProps {
  item: RemindPopupDTO;
  t: any;
  router: any;
  cb?: () => void;
}
const NotificationRow: FC<NotificationRowProps> = (props) => {
  const { item, cb, t } = props;
  return (
    <> <Link
      href={getRedirectLink(item)}
      onClick={cb}
    >
      <Stack
        direction={"column"}
        gap={0.25}
        sx={{
          position: 'relative',
          padding: "16px 16px 16px 36px",
          backgroundColor: item?.readNotification ? COLOR_TYPE.TOYOTA.TOYOTA7 : undefined,
          "&:hover": {
            backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA1}10`
          }
        }}>
        {!item?.readNotification && <Box sx={{
          position: 'absolute',
          width: 8,
          height: 8,
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
          borderRadius: '10px',
          left: 16,
          top: 48
        }} />}
        <Stack
          direction={"row"}
          justifyContent={"space-between"}
          alignItems={'center'}
          sx={{ opacity: item?.readNotification ? 0.5 : 1 }}
        >
          <Stack direction={'row'} alignItems={'center'} gap={1.5} >
            {moduleIconMap?.[item.module] ?? null}
            {/* <Link
              rel="noopener noreferrer"
              target="_blank"
              href={getRedirectLink(item)}
              onClick={cb}
              style={{ width: "fit-content" }}
            > */}
            <Typography
              variant="h5"
              fontSize={14}
            >
              {/* {item.module ? t(`notification.module.${item.module}`) : ''} */}
              {item?.userCreate?.name} - {item?.type ? t(`notification.actionType.${item?.type}`) : ""}
            </Typography>
            {/* </Link> */}
          </Stack>
          <Typography
            variant="subtitle2"
            fontSize={14}
            color={item?.readNotification ? COLOR_TYPE.TOYOTA.TOYOTA2 : COLOR_TYPE.BLUE.BLUE6}
          >
            {item?.displayTime
              ? formatDate(item?.displayTime, 'dd/MM/yyyy HH:mm')
              : ""}
          </Typography>
        </Stack>
        {/* <Typography
          title={t(`notification.remindType.${item.type}`, {
            userName: item?.userCreate?.email,
            deadline: item?.deadline ? formatDate(item?.deadline) : "",
            deadlineTime: item?.deadline
              ? formatDate(item?.deadline, "dd/MM/yyyy HH:mm")
              : "",
          })}
          variant="body2"
          sx={{
            overflow: "hidden",
            textOverflow: "ellipsis",
            display: "-webkit-box",
            WebkitLineClamp: "1",
            WebkitBoxOrient: "vertical",
            wordBreak: "break-all",
            color: item?.readNotification
              ? COLOR_TYPE.TOYOTA.TOYOTA4
              : undefined,
          }}
        >
          {t(`notification.remindType.${item.type}`, {
            userName: item?.userCreate?.email,
            deadline: item?.deadline ? formatDate(item?.deadline) : "",
            deadlineTime: item?.deadline
              ? formatDate(item?.deadline, "dd/MM/yyyy HH:mm")
              : "",
          })}
        </Typography> */}
        {/* <Link
          rel="noopener noreferrer"
          target="_blank"
          href={getRedirectLink(item)}
          onClick={cb}
          style={{ width: "fit-content" }}
        > */}
        <Typography
          display={"inline"}
          variant="body2"
          sx={{
            // color: COLOR_TYPE.BLUE.BLUE6,
            overflow: "hidden",
            textOverflow: "ellipsis",
            display: "-webkit-box",
            WebkitLineClamp: "1",
            WebkitBoxOrient: "vertical",
            wordBreak: 'break-all',
            opacity: item?.readNotification ? 0.5 : 1

          }}
        >
          {item.documentName}
        </Typography>
        {item?.deadline ? <Typography
          display={"inline"}
          variant="body2"
          sx={{
            overflow: "hidden",
            textOverflow: "ellipsis",
            display: "-webkit-box",
            WebkitLineClamp: "1",
            WebkitBoxOrient: "vertical",
            wordBreak: 'break-all',
            opacity: item?.readNotification ? 0.5 : 1
          }}
        >
          {t("notification.deadlineTemplate", {
            deadline: item?.deadline
              ? (
                formatDate(item?.deadline, "dd/MM/yyyy HH:mm")?.includes("00:00")
                  ? formatDate(item?.deadline, "dd/MM/yyyy")
                  : formatDate(item?.deadline, "dd/MM/yyyy HH:mm")
              )
              : ""
          })}
        </Typography> : null}
        {/* </Link> */}
      </Stack>
    </Link>
      <Divider sx={{ borderColor: COLOR_TYPE.NEUTRALS.GRAY15 }} />
    </>
  );
};

export default NotificationRow