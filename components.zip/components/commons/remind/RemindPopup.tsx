"use client";
import { getRemindPopup, markSingleAsReadFn } from "@/apis/service/reminder_template/ReminderTemplate";
import { IconConflictManagement } from "@/assets/iconMenu/iconConflictManagement";
import { DocumentManagementIcon } from "@/assets/iconMenu/IconDocumentDepartment";
import { IconDocumentReview } from "@/assets/iconMenu/IconDocumentReview";
import { IconDocumentViolation } from "@/assets/iconMenu/IconDocumentViolation";
import { IconLawDocument } from "@/assets/iconMenu/IconLawDocument";
import { IconLegalAdvice } from "@/assets/iconMenu/IconLegalAdvice";
import { IconRelationshipDisclosure } from "@/assets/iconMenu/IconRelationshipDisclosure";
import { VisitationtIcon } from "@/assets/iconMenu/IconVisitation";
import { COLOR_TYPE } from "@/constants/color";
import { CONFLICT_MANAGEMENT_ROOT_PATH, DOCUMENT_MANAGEMENT_ROOT_PATH, DOCUMENT_REVIEW_ROOT_PATH, LEGAL_ADVICE_ROOT_PATH, LEGAL_DOCUMENT_ROOT_PATH, LEGAL_VIOLATION_TRACKING_ROOT_PATH, RELATIONSHIP_DISCLOSURE_ROOT_PATH, VISITATION_ROOT_PATH } from "@/constants/paths";
import { useAppContext } from "@/context/AppContext";
import { ButtonAction } from "@/features/legal-document/legal_document_table/legal_document_table_actions/LegalDocumentTableActionsText";
import { RemindPopupDTO } from "@/models/reminder_template/ReminderDTO";
import { formatDate } from "@/utils";
import CloseIcon from "@mui/icons-material/Close";
import {
  Box,
  Divider,
  IconButton,
  Modal,
  Stack,
  Typography
} from "@mui/material";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  minWidth: { sm: 600, md: 700 },
  maxWidth: { xs: "90%", sm: "80%" },
  maxHeight: { xs: "90%", sm: "80%" },
  width: "max-content",
  bgcolor: "background.paper",
  borderRadius: "8px !important",
  boxShadow: 24,
  outline: "none",
  pt: 3,
  pr: 1,
  pl: 1,
  pb: 3,
  display: "flex",
  flexDirection: "column",
  gap: "20px",
};

export const TypesWithAction: Record<string, string> = {
  "3": ButtonAction.EVALUATE,
  "8": ButtonAction.NEXT_ACTION,
  "10": ButtonAction.CONFIRM,
};

export const moduleUrlMap: Record<string, string> = {
  1: LEGAL_DOCUMENT_ROOT_PATH,
  2: LEGAL_ADVICE_ROOT_PATH,
  3: DOCUMENT_REVIEW_ROOT_PATH,
  4: LEGAL_VIOLATION_TRACKING_ROOT_PATH,
  5: DOCUMENT_MANAGEMENT_ROOT_PATH,
  6: VISITATION_ROOT_PATH,
  7: CONFLICT_MANAGEMENT_ROOT_PATH,
  8: RELATIONSHIP_DISCLOSURE_ROOT_PATH,
}
export const moduleIconMap: Record<number, JSX.Element> = {
  1: <IconLawDocument />,
  2: <IconLegalAdvice />,
  3: <IconDocumentReview />,
  4: <IconDocumentViolation />,
  5: <DocumentManagementIcon />,
  6: <VisitationtIcon />, // QLTD
  7: <IconConflictManagement />, // QLXD
  8: <IconRelationshipDisclosure />, // KKMQH
}
export const getRedirectLink = (item: RemindPopupDTO) => {
  if (item.module === 5) {
    return `/${DOCUMENT_MANAGEMENT_ROOT_PATH}/update/${item?.stockId}/${item.documentId}`
  }
  return `/${moduleUrlMap?.[item.module]}/update/${item.documentId}`
  // return item?.type === 8
  //   ? `/${LEGAL_DOCUMENT_ROOT_PATH}/${item?.legalDocumentId}/update-next-action/${item?.otherDocumentId}`
  //   : `/${LEGAL_DOCUMENT_ROOT_PATH}/update/${item?.legalDocumentId}?action=${TypesWithAction?.[item.type]}`
}

const RemindPopup = () => {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const appContext = useAppContext();
  // const isEn = i18n.language === LANGUAGES.ENGLISH;
  const handleClose = () => {
    queryClient.setQueryData(["remind/popup/seen"], { seen: true });
    queryClient.setQueryData(["remind/popup"], { reminds: null });
  };

  useEffect(() => {
    if (!!appContext?.me?.id) {
      query.refetch();
    }
  }, [appContext?.me?.id]);

  const seenQuery = useQuery({
    queryKey: ["remind/popup/seen"],
    queryFn: () => ({ seen: false }),
    enabled: false,
  });

  const query = useQuery({
    queryKey: ["remind/popup"],
    queryFn: () => {
      return getRemindPopup().catch(() => ({ reminds: [] }));
    },
    placeholderData: (prevData) => prevData,
    // staleTime: 60000,
    // refetchInterval: 60000,
    staleTime: Infinity,
    enabled: false
    // enabled: !!appContext?.me?.id
  });

  const markSingleAsReadMutation = useMutation({
    mutationFn: markSingleAsReadFn,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["notification/total-unread"],
      });
    }
  });

  return (
    <Modal
      open={!!query?.data?.reminds?.length && !seenQuery?.data?.seen}
      onClose={handleClose}
    >
      <Box sx={style}>
        <Box sx={{ width: "100%", textAlign: "center", position: "relative" }}>
          <Typography color='primary.dark' variant='h1'>
            {t("notification.remind")}
          </Typography>
          <IconButton
            onClick={handleClose}
            sx={{
              position: "absolute",
              right: 12,
              top: -8,
            }}
          >
            <CloseIcon color={"inherit"} />
          </IconButton>
        </Box>
        <Box
          sx={{
            width: "100%",
            position: "relative",
            display: "flex",
            flexDirection: "column",
            overflowY: "scroll",
          }}
        >
          {query?.data?.reminds?.map((ele: RemindPopupDTO, index: number) => {
            return (
              <Link
                // rel='noopener noreferrer'
                // target='_blank'
                key={`popup_remind_${index}`}
                href={getRedirectLink(ele)}
                style={{ cursor: 'pointer' }}
                passHref
                onClick={() => {
                  markSingleAsReadMutation.mutate(ele.id);
                  handleClose();
                }}
              >
                <Box
                  width={"100%"}
                  p={2}

                  sx={{
                    cursor: 'pointer',
                    "&:hover": {
                      backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA1}10`,
                      borderRadius: '6px',
                    }
                  }}
                >
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Stack direction={"column"}>
                      <Typography variant="h5">
                        {t(`notification.module.${ele.module}`)}: {ele?.userCreate?.name} - {ele?.type ? t(`notification.actionType.${ele?.type}`) : ""}
                        {/* {t(`notification.remindType.${ele.type}`, {
                          userName: getUserLabel(ele.userCreate, isEn, true),
                          deadline: ele?.deadline ? formatDate(ele?.deadline) : "",
                          deadlineTime: ele?.deadline ? formatDate(ele?.deadline, 'dd/MM/yyyy HH:mm') : "",
                        })} */}
                      </Typography>
                      {/* <Link
                        rel='noopener noreferrer'
                        target='_blank'
                        href={getRedirectLink(ele)}
                        passHref
                        onClick={() => markSingleAsReadMutation.mutate(ele.id)}
                      > */}
                      <Typography
                        sx={{
                          // color: COLOR_TYPE.BLUE.BLUE6,
                          // textDecoration: "underline",
                          whiteSpace: "nowrap",
                          cursor: "pointer",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                        }}
                      >
                        {ele.documentName}
                      </Typography>
                      {ele?.deadline ? <Typography>
                        {t("notification.deadlineTemplate", {
                          deadline: ele?.deadline
                            ? (
                              formatDate(ele?.deadline, "dd/MM/yyyy HH:mm")?.includes("00:00")
                                ? formatDate(ele?.deadline, "dd/MM/yyyy")
                                : formatDate(ele?.deadline, "dd/MM/yyyy HH:mm")
                            )
                            : ""
                        })}
                      </Typography> : null}
                      {/* </Link> */}
                    </Stack>
                    {/* {TypesWithAction?.[ele.type] ? (
                    <Link
                      rel='noopener noreferrer'
                      target='_blank'
                      href={getRedirectLink(ele)}
                    >
                      <Button
                        sx={{ height: "fix-content" }}
                        variant='contained'
                      >
                        {t("common.button.reply")}
                      </Button>
                    </Link>
                  ) : null} */}
                  </Stack>
                </Box>
                {index < Number(query?.data?.reminds?.length ?? 0) - 1 ? (
                  <Divider
                    sx={{ mx: 2, borderColor: COLOR_TYPE.TOYOTA.TOYOTA6 }}
                  />
                ) : null}
              </Link>
            );
          })}
        </Box>
      </Box>
    </Modal>
  );
};

export default RemindPopup;
