

import { getNotificationPopup, markAllAsReadFn, markSingleAsReadFn } from '@/apis/service/reminder_template/ReminderTemplate'
import { IconReadAll } from '@/assets/iconMenu/iconReadAll'
import { COLOR_TYPE } from '@/constants/color'
import { Box, CircularProgress, List, ListItem, Stack, styled, Tab, TabProps, Tabs, tabsClasses, Tooltip, Typography } from '@mui/material'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { uniqueId } from 'lodash'
import { useRouter } from 'next/navigation'
import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useInView } from 'react-intersection-observer'
import NotificationRow from './NotificationRow'


interface NotificationPopupProps {
  unreadData: any;
  handleCloseMenu: () => void;

}
const NotificationPopup = (props: NotificationPopupProps) => {

  const { unreadData, handleCloseMenu } = props

  const { t } = useTranslation();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [value, setValue] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const { ref, inView } = useInView();

  useEffect(() => {
    notificationQuery.refetch();
  }, [])

  useEffect(() => {
    if (inView && !isLoadingMore) {
      loadMoreNotifications();
    }
  }, [inView]);

  const notificationQuery = useQuery({
    queryKey: ["notification/list", value],
    queryFn: () => {
      const params = {
        page: 0,
        size: 10,
        module: value > 0 ? value : undefined
      };
      const response = getNotificationPopup(params);
      queryClient.invalidateQueries({
        queryKey: ["notification/total-unread"],
      });
      return response;
    },
    enabled: false,
  });

  const loadMoreNotifications = async () => {
    setIsLoadingMore(true);
    const params = {
      page: currentPage + 1,
      size: 10,
      module: value > 0 ? value : undefined
    };
    try {
      const response = await getNotificationPopup(params);
      if (response?.reminds?.length) {
        queryClient.setQueryData(["notification/list", value], (prevData: any) => {
          setCurrentPage(currentPage + 1);
          return {
            reminds: [...(prevData?.reminds ?? []), ...response?.reminds],
          };
        });
      }
    } catch (error) {
    } finally {
      setIsLoadingMore(false);
    }
  };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    setCurrentPage(0);
    setTimeout(() => {
      notificationQuery.refetch();
    }, 100)
  };

  const markAllAsReadMutation = useMutation({
    mutationFn: markAllAsReadFn,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["notification/total-unread"],
      });
      notificationQuery.refetch();
    }
  });

  const markSingleAsReadMutation = useMutation({
    mutationFn: markSingleAsReadFn,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["notification/total-unread"],
      });
      notificationQuery.refetch();
    }
  });

  return (
    <Box
      width={600}
      display={"flex"}
      flexDirection={"column"}
    >
      <Box
        position={"relative"}
        width={"100%"}
        display="flex"
        justifyContent="center"
        gap={2}
      >
        <Typography sx={{ p: '12px', pb: 0 }} color="primary.dark" variant="h5">
          {t("notification.notification")}
        </Typography>
        <Tooltip placement="top" title={t('notification.markAll')}>
          <Box
            alignItems={"center"}
            gap={1}
            position={"absolute"}
            top={10}
            bottom={0}
            right={16}
            sx={{ cursor: "pointer" }}
            onClick={() => {
              !markAllAsReadMutation.isPending
                && markAllAsReadMutation.mutate()
            }}
          >
            <IconReadAll />
          </Box>
        </Tooltip>
      </Box>
      <Tabs
        value={value}
        onChange={handleChange}
        variant="scrollable"
        selectionFollowsFocus
        sx={{
          borderBottom: '1px solid #e8e8e8',
          [`& .${tabsClasses.scrollButtons}`]: {
            '&.Mui-disabled': { opacity: 0.4 },
            width: 20
          },

        }}
      >
        <CustomTab
          label={<Stack direction={'row'} alignItems={'center'} gap={1}>
            {t("notification.all")}
            <UnreadNumber num={unreadData?.totalUnread ?? 0} />
          </Stack>}
          key={uniqueId('all_')} />
        {Array.from({ length: 8 }).map((item, index) => <CustomTab
          label={
            <Stack direction={'row'} alignItems={'center'} gap={1}>
              {t(`notification.module.${index + 1}`)}
              <UnreadNumber num={unreadData?.unreadPerModule?.[index + 1] ?? 0} />
            </Stack>
          }
          key={uniqueId()}
        />)}
      </Tabs>
      {notificationQuery.isFetching ||
        (!notificationQuery.isFetching &&
          !notificationQuery?.data?.reminds?.length) ? (
        <Box
          width={"100%"}
          height={100}
          display={"flex"}
          justifyContent={"center"}
          alignItems={"center"}
        >
          {notificationQuery.isFetching ? (
            <CircularProgress color="primary" sx={{ margin: "auto" }} />
          ) : null}
          {!notificationQuery.isFetching &&
            !notificationQuery?.data?.reminds?.length ? (
            <Typography textAlign={"center"} mt={2} mb={2}>
              {t("notification.noNotification")}
            </Typography>
          ) : null}
        </Box>
      ) : null}
      {notificationQuery?.data?.reminds?.length &&
        !notificationQuery.isFetching ? (
        <Box
          display={"flex"}
          flexDirection={"column"}
          minHeight={84}
          maxHeight={'80vh'}
          sx={{ overflowY: 'auto' }}
        >
          <List disablePadding>
            {notificationQuery?.data?.reminds?.map((item, index) => (
              <NotificationRow
                key={`n_row_${index}`}
                item={item}
                t={t}
                router={router}
                cb={() => {
                  markSingleAsReadMutation.mutate(item.id);
                  handleCloseMenu();
                }}
              />
            ))}
            <ListItem
              ref={ref}
              sx={{ justifyContent: "center", minHeight: "28px" }}
            >
              {isLoadingMore ? (
                <CircularProgress size={28} color="primary" />
              ) : null}
            </ListItem>
          </List>
        </Box>
      ) : null}
    </Box>
  )
}

export default NotificationPopup


const CustomTab = styled((props: TabProps) => <Tab {...props} />)(
  ({ }) => ({
    minWidth: 0,
    padding: "0 12px",
    fontSize: '14px',
    textTransform: "none",
    backgroundColor: "transparent",
    zIndex: 1,
    color: COLOR_TYPE.TOYOTA.TOYOTA2,
    fontFamily: "'Toyota-Text-Regular', 'Roboto-Regular', sans-serif !important",
    "&.Mui-selected": {
      color: COLOR_TYPE.TOYOTA.TOYOTA2,
      fontFamily: "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
      fontWeight: 700,
    },
  })
);

const UnreadNumber = (props: { num: number }) => {
  const { num } = props;
  return +num > 0 ? <Box sx={{
    width: 24,
    height: 24,
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
    borderRadius: '100px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }}>
    <Typography sx={{ fontSize: '14px', color: 'white' }}>
      {+num > 99 ? '99+' : num}
    </Typography>
  </Box> : null
}