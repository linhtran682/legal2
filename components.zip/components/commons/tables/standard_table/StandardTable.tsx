import {
  DataGrid,
  GridCellClassNamePropType,
  gridClasses,
  GridColDef,
  GridColumnVisibilityModel,
  GridFilterModel,
  GridFilterOperator,
  GridPaginationModel,
  GridRenderCellParams,
  GridRowClassNameParams,
  GridRowHeightParams,
  GridRowHeightReturnValue,
  GridRowParams,
  GridRowSelectionModel,
  GridSortModel,
} from "@mui/x-data-grid";
import { TablePagination } from "./pagination/TablePagination";
import { COLOR_TYPE } from "@/constants/color";
import { Grid, SxProps, Theme, Typography } from "@mui/material";
import { ReactNode, useEffect, useState } from "react";
import style from "./StandardTable.module.css";
import { useTranslation } from "react-i18next";
import { getDateRangeOperators } from "../../filters/DateRangeFilter";
import { getNumberIntervalOperators } from "../../filters/NumberRangeFilter";
import { getKeywordOperators } from "../../filters/KeywordFilter";
import {
  EXPECTED_DATE_TIME_LOCALE,
  GLOBAL_SMALL_SPACING,
} from "@/constants/format";
import { EmptyIndicator } from "../../empty_idicator/EmptyIndicator";
import { formatSingleDigitNumber } from "@/utils";

export const DEFAULT_PAGE_MODAL: GridPaginationModel = {
  page: 0,
  pageSize: 10,
};

export interface StandardTableColumn {
  key: string;
  label: string;
  type: "date" | "number" | "string" | undefined;
  filterOperators?: GridFilterOperator[];
  filterable?: boolean;
  sortable?: boolean;
  hideable?: boolean;
  cellClassName?: GridCellClassNamePropType;
  headerClassName?: string;
  renderCell?: (params: GridRenderCellParams) => React.ReactNode;
  flex?: number;
  disableColumnMenu?: boolean;
  minWidth?: number;
  maxWidth?: number;
  align?: string;
}

const dataGridSxProps: SxProps<Theme> = {
  backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
  "& .MuiDataGrid-checkboxInput": {
    color: COLOR_TYPE.TOYOTA.TOYOTA1,
  },
  "& .MuiDataGrid-columnHeader": {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
    fontFamily: "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
    "&:focus-within": {
      outline: "none",
    },
  },
  "& .MuiDataGrid-cell:focus": {
    outline: "none",
  },
  [`& .${gridClasses.cell}:focus, & .${gridClasses.cell}:focus-within`]:
  {
    outline: 'none',
  },
  "& .MuiDataGrid-filler": {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
  },
  "& .MuiDataGrid-scrollbarFiller--header": {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
  },
  // "& .MuiDataGrid-cell:focus-within": {
  //   outline: "none",
  // },
  "& .MuiDataGrid-sortIcon": {
    color: COLOR_TYPE.TOYOTA.TOYOTA1,
  },
  "& .MuiDataGrid-sortIcon[data-testid='ArrowUpwardIcon'] path": {
    "& path": {
      d: "path('M12 7C12.2652 7 12.5196 7.10536 12.7071 7.29289L19.7071 14.2929C20.0976 14.6834 20.0976 15.3166 19.7071 15.7071C19.3166 16.0976 18.6834 16.0976 18.2929 15.7071L12 9.41421L5.70711 15.7071C5.31658 16.0976 4.68342 16.0976 4.29289 15.7071C3.90237 15.3166 3.90237 14.6834 4.29289 14.2929L11.2929 7.29289C11.4804 7.10536 11.7348 7 12 7Z')",
    },
  },
  "& .MuiDataGrid-sortIcon[data-testid='ArrowDownwardIcon'] path": {
    "& path": {
      d: "path('M4.29289 8.29289C4.68342 7.90237 5.31658 7.90237 5.70711 8.29289L12 14.5858L18.2929 8.29289C18.6834 7.90237 19.3166 7.90237 19.7071 8.29289C20.0976 8.68342 20.0976 9.31658 19.7071 9.70711L12.7071 16.7071C12.3166 17.0976 11.6834 17.0976 11.2929 16.7071L4.29289 9.70711C3.90237 9.31658 3.90237 8.68342 4.29289 8.29289Z')",
    },
  },
  "& .MuiDataGrid-row.Mui-selected": {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA7,
  },
  "& .MuiDataGrid-row.Mui-selected:hover": {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
  },
  "& .MuiDataGrid-selectedRowCount": {
    display: "none",
  },
  "& .MuiTablePagination-root": {
    width: "100%",
  },
  "& .vilation_draft": {
    backgroundColor: "rgb(128,128,128, 0.5)",
    "&:hover": {
      backgroundColor: "rgb(128,128,128, 0.5)",
    },
  },
};

export interface StandardTableState {
  filterModel: GridFilterModel | undefined;
  sorterModel: GridSortModel | undefined;
  paginationModel: GridPaginationModel;
  columnVisibilityModel: GridColumnVisibilityModel | undefined;
}

export interface StandardTableProps<T> {
  recordName?: string;
  data: T[];
  getRowId: (data: T) => string;
  columns: StandardTableColumn[];
  loading?: boolean;
  initialFilterModel?: GridFilterModel;
  initialSorterModel?: GridSortModel;
  initialPaginationModel?: GridPaginationModel;
  filterModel?: GridFilterModel;
  sorterModel?: GridSortModel;
  paginationModel?: GridPaginationModel;
  rowCount?: number;
  onChange?: (state: StandardTableState) => void;
  columnVisibilityModel?: GridColumnVisibilityModel;
  initalColumnVisibilityModel?: GridColumnVisibilityModel;
  onChangeColumnVisibility?: (model: GridColumnVisibilityModel) => void;
  onRowSelectionModelChange?: (model: GridRowSelectionModel) => void;
  groupedActions?: (
    selectedModel: GridRowSelectionModel
  ) => ReactNode | ReactNode[];
  enableColumnMenu?: boolean;
  onRowClick?: (params: GridRowParams) => void;
  hideRowCheckbox?: boolean;
  hideFooter?: boolean;
  disableRowSelectionOnClick?: boolean;
  getRowHeight?: (params: GridRowHeightParams) => GridRowHeightReturnValue;
  getRowClassName?: (params: GridRowClassNameParams) => string;
  styleDataGridSxProps?: any
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const getGridFilterOperators = (column: StandardTableColumn, t: any) => {
  return column.filterOperators
    ? column.filterOperators
    : column.type == "date"
    ? getDateRangeOperators(t)
    : column.type == "number"
    ? getNumberIntervalOperators(t)
    : getKeywordOperators(t);
};

export default function StandardTable<T>(
  props: Readonly<StandardTableProps<T>>
) {
  const [t, i18n] = useTranslation();

  const [gridColumns, setGridColumns] = useState<GridColDef[]>([]);
  const [data, setData] = useState<T[]>([]);

  useEffect(() => {
    setData(
      props.data.map((data, index) => ({
        ...data,
        uiOrderId:
          tableState.paginationModel.page *
            tableState.paginationModel.pageSize +
          index +
          1,
      }))
    );
  }, [props.data]);

  const handleRenderOrderNumber = (params: GridRenderCellParams) => {
    return formatSingleDigitNumber(params.row.uiOrderId);
  };

  useEffect(() => {
    setGridColumns(
      props.columns.map(
        (column) =>
          ({
            field: column.key,
            headerName: column.label && t(column.label),
            filterOperators: getGridFilterOperators(column, t),
            filterable: column.filterable,
            sortable: column.key == "id" ? false : column.sortable,
            hideable: column.hideable,
            renderCell:
              column.key == "id" ? handleRenderOrderNumber : column.renderCell,
            cellClassName: column.cellClassName,
            headerClassName: column.headerClassName,
            disableColumnMenu: column.disableColumnMenu,
            flex: column.flex,
            valueFormatter: (value) =>
              column.type === "date"
                ? value
                  ? Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                      dateStyle: "short",
                      timeStyle: "medium",
                    }).format(new Date(value))
                  : undefined
                : column.type === "number"
                ? formatSingleDigitNumber(value)
                : undefined,
            renderHeader: (params) =>
              params.colDef.headerName && (
                <div style={{ fontWeight: "bold" }}>
                  {params.colDef.headerName}
                </div>
              ),
            align:
              column.key == "id" || column?.type === "date"
                ? "center"
                : column?.align
                ? column?.align
                : ["number"].includes(column.type ?? "")
                ? "right"
                : "left",
            minWidth: column?.minWidth ?? 0,
            maxWidth: column.key == "id" ? 52 : column?.maxWidth ?? 1000,
          } as GridColDef)
      )
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i18n.language]);

  const [tableState, setTableState] = useState<StandardTableState>(() => ({
    filterModel: props.initialFilterModel,
    sorterModel: props.initialSorterModel,
    paginationModel: props.initialPaginationModel || DEFAULT_PAGE_MODAL,
    columnVisibilityModel: props.initalColumnVisibilityModel,
  }));

  const [rowSelectionModel, setRowSelectionModel] =
    useState<GridRowSelectionModel>([]);

  useEffect(() => {
    setTableState((oldState) => ({
      ...oldState,
      filterModel: props.filterModel,
      sorterModel: props.sorterModel,
      paginationModel: props.paginationModel ?? DEFAULT_PAGE_MODAL,
      columnVisibilityModel: props.columnVisibilityModel,
    }));
  }, [
    props.filterModel,
    props.sorterModel,
    props.paginationModel,
    props.columnVisibilityModel,
  ]);

  const handleChangeTableState = (state: StandardTableState) => {
    setTableState(state);

    props.onChange && props.onChange(state);
  };

  const handleChangeColumnVisibility = (model: GridColumnVisibilityModel) => {
    setTableState((oldState) => ({
      ...oldState,
      columnVisibilityModel: model,
    }));
    props.onChangeColumnVisibility && props.onChangeColumnVisibility(model);
  };

  const handleChangeRowSelection = (model: GridRowSelectionModel) => {
    setRowSelectionModel(model);

    props.onRowSelectionModelChange && props.onRowSelectionModelChange(model);
  };
  return (
    <>
      {(!props.data || props.data.length == 0) && !props.loading ? (
        <EmptyIndicator />
      ) : (
        <>
          {rowSelectionModel.length > 0 && (
            <Grid
              container
              direction={"row"}
              columnGap={GLOBAL_SMALL_SPACING}
              alignItems={"center"}
              sx={{ pt: 1, pb: 1 }}
            >
              <Grid item>
                <Typography variant="body2" fontWeight={"bold"}>
                  {rowSelectionModel.length}
                </Typography>
              </Grid>
              <Grid item>
                <Typography variant="body2">
                  {t("common.table.records_selected", {
                    recordName: props.recordName ?? t("common.table.record"),
                  })}
                </Typography>
              </Grid>
              {props.groupedActions && (
                <Grid item flex={1}>
                  <div>{props.groupedActions(rowSelectionModel)}</div>
                </Grid>
              )}
            </Grid>
          )}
          <DataGrid
            className={style.standardTable}
            columns={gridColumns}
            rows={props.loading ? [] : data}
            getRowId={props.getRowId}
            checkboxSelection={!props.hideRowCheckbox}
            slots={{
              pagination: TablePagination,
            }}
            getRowClassName={(params) => {
              if (props.getRowClassName) {
                props.getRowClassName(params);
              } else if (params.row.isDraft) {
                return "colorRow";
              }
              return "";
            }}
            // eslint-disable-next-line
            sx={{...dataGridSxProps,...props.styleDataGridSxProps}}
            filterMode="server"
            filterModel={tableState.filterModel}
            onFilterModelChange={(model) =>
              handleChangeTableState({
                ...tableState,
                filterModel: model,
                paginationModel: { ...tableState.paginationModel, page: 0 },
              })
            }
            sortingMode="server"
            sortModel={tableState.sorterModel}
            onSortModelChange={(model) => {
              handleChangeTableState({
                ...tableState,
                sorterModel: model,
                paginationModel: { ...tableState.paginationModel, page: 0 },
              });
            }}
            paginationMode="server"
            paginationModel={tableState.paginationModel}
            onPaginationModelChange={(model) => {
              handleChangeTableState({
                ...tableState,
                paginationModel: model,
              });
            }}
            columnVisibilityModel={tableState.columnVisibilityModel}
            onColumnVisibilityModelChange={handleChangeColumnVisibility}
            rowSelectionModel={rowSelectionModel}
            onRowSelectionModelChange={handleChangeRowSelection}
            rowCount={props.rowCount ?? (props.data || []).length}
            loading={props.loading}
            pagination
            pageSizeOptions={[10, 20, 50, 100]}
            disableVirtualization
            showCellVerticalBorder
            sortingOrder={["asc", "desc", null]}
            disableColumnMenu={!props.enableColumnMenu}
            onRowClick={(params) => {
              props.onRowClick && props.onRowClick(params);
            }}
            disableRowSelectionOnClick
            hideFooter={props.hideFooter}
            getRowHeight={props?.getRowHeight}
          />
        </>
      )}
    </>
  );
}
