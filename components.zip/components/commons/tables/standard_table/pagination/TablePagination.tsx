import { TablePaginationProps } from "@mui/material";
import {
  gridPageCountSelector,
  GridPagination,
  useGridApiContext,
  useGridSelector,
} from "@mui/x-data-grid";
import MuiPagination from "@mui/material/Pagination";
import { MouseEvent } from "react";

export const PagePickerPagination = ({
  page,
  onPageChange,
  className,
}: Pick<TablePaginationProps, "page" | "onPageChange" | "className">) => {
  const apiRef = useGridApiContext();
  const pageCount = useGridSelector(apiRef, gridPageCountSelector);

  return (
    <MuiPagination
      color='primary'
      shape='rounded'
      className={className}
      count={pageCount}
      page={page + 1}
      onChange={(event, newPage) => {
        onPageChange(
          event as MouseEvent<HTMLButtonElement> | null,
          newPage - 1
        );
      }}
    />
  );
};

export const TablePagination = (props: Partial<TablePaginationProps>) => {
  return <GridPagination {...props} ActionsComponent={PagePickerPagination} />;
};
