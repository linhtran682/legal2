import { Stack } from "@mui/material";
import StandardTable, {
  DEFAULT_PAGE_MODAL,
  StandardTableColumn,
  StandardTableProps,
  StandardTableState,
} from "../standard_table/StandardTable";
import { MultipleFilterTableBar } from "./multiple_filter_table_bar/MultipleFilterTableBar";
import { ReactNode, useEffect, useState } from "react";
import { GridColumnVisibilityModel, GridFilterModel } from "@mui/x-data-grid";
import { GLOBAL_SPACING } from "@/constants/format";

export interface MultipleFilterTableColumn extends StandardTableColumn {
  quickFilter?: boolean;
  filterLabel?: string;
  filterRank?: number;
}

export const enum FilterType {
  QUICK = "quick",
  MODAL = "modal",
}

export interface MultipleFilterTableProps<T> extends StandardTableProps<T> {
  columns: MultipleFilterTableColumn[];
  quickFilterProps?: {
    defaultSelectedOptionKey?: string;
    quickFilterMode?: "multiple";
    placeHolder?: (selectedOptionKey: string) => string;
  };
  multipleFilter?: boolean;
  exportFile?: ReactNode;
  sortButton?: ReactNode;
}

export default function MultipleFilterTable<T>(
  props: Readonly<MultipleFilterTableProps<T>>
) {
  const [tableState, setTableState] = useState<StandardTableState>(() => ({
    filterModel: props.initialFilterModel,
    sorterModel: props.initialSorterModel,
    paginationModel: props.initialPaginationModel || DEFAULT_PAGE_MODAL,
    columnVisibilityModel: props.initalColumnVisibilityModel,
  }));

  useEffect(() => {
    setTableState((oldState) => ({
      ...oldState,
      filterModel: props.filterModel,
      sorterModel: props.sorterModel,
      paginationModel: props.paginationModel ?? DEFAULT_PAGE_MODAL,
      columnVisibilityModel: props.columnVisibilityModel,
    }));
  }, [
    props.filterModel,
    props.sorterModel,
    props.paginationModel,
    props.columnVisibilityModel,
  ]);

  const handleChangeTableState = (state: StandardTableState) => {
    !props.onChange && setTableState(state);

    props.onChange && props.onChange(state);
  };

  const handleChangeColumnVisibility = (model: GridColumnVisibilityModel) => {
    !props.columnVisibilityModel &&
      setTableState((oldState) => ({
        ...oldState,
        columnVisibilityModel: model,
      }));
    props.onChangeColumnVisibility && props.onChangeColumnVisibility(model);
  };

  const handleReset = () => {
    setTableState({
      filterModel: props.initialFilterModel,
      sorterModel: props.initialSorterModel,
      paginationModel: props.initialPaginationModel || DEFAULT_PAGE_MODAL,
      columnVisibilityModel: props.initalColumnVisibilityModel,
    });

    props.onChange &&
      props.onChange({
        filterModel: props.initialFilterModel,
        sorterModel: props.initialSorterModel,
        paginationModel: props.initialPaginationModel || DEFAULT_PAGE_MODAL,
        columnVisibilityModel: props.initalColumnVisibilityModel,
      });
  };

  return (
    <Stack
      spacing={GLOBAL_SPACING}
      sx={{
        height: "100%",
      }}
    >
      <MultipleFilterTableBar
        columns={props.columns}
        filterModel={tableState.filterModel}
        sorterModel={tableState.sorterModel}
        columnVisibilityModel={tableState.columnVisibilityModel}
        onChangeQuickFilter={(filterModel) => {
          handleChangeTableState({
            ...tableState,
            filterModel: filterModel,
            paginationModel: { ...tableState.paginationModel, page: 0 },
          });
        }}
        onChange={(modalState) => {
          handleChangeTableState({
            filterModel: { items: Array.from(modalState.filterMap.values()) },
            sorterModel: Array.from(modalState.sorterMap.values()),
            paginationModel: { ...tableState.paginationModel, page: 0 },
            columnVisibilityModel: modalState.columnVisibilityModel,
          });
        }}
        loading={props.loading}
        onReset={handleReset}
        quickFilterProps={props.quickFilterProps}
        multipleFilter={props.multipleFilter}
        exportFile={props?.exportFile}
        sortButton={props?.sortButton}
      />
      <StandardTable
        {...props}
        sorterModel={tableState.sorterModel}
        paginationModel={tableState.paginationModel}
        filterModel={{
          ...(tableState.filterModel || {}),
          items: (tableState.filterModel?.items || []).filter(
            (item) => item.id != FilterType.MODAL && item.id != FilterType.QUICK
          ),
        }}
        onChange={(state) => {
          const filterModel: GridFilterModel = state.filterModel ?? {
            items: [],
          };

          filterModel.items.push(
            ...(tableState.filterModel?.items || []).filter(
              (item) =>
                item.id == FilterType.MODAL || item.id == FilterType.QUICK
            )
          );

          handleChangeTableState({ ...state, filterModel: filterModel });
        }}
        columnVisibilityModel={tableState.columnVisibilityModel}
        onChangeColumnVisibility={handleChangeColumnVisibility}
      />
    </Stack>
  );
}
