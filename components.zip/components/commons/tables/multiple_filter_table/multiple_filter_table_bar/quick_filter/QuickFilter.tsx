import { COLOR_TYPE } from "@/constants/color";
import { Grid, IconButton, MenuItem, Select, TextField } from "@mui/material";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import SearchIcon from "@mui/icons-material/Search";
import { TEXT_FIELD_MAX_LENGTH } from "@/constants/constraint";

export interface FilterOption {
  key: string;
  label: string;
}

export interface QuickFilterProps {
  filterOptions: FilterOption[];
  selectedOptionKey?: string;
  searchValue?: string;
  onChange?: (selectedOptionKey: string, searchValue: string) => void;
  defaultSelectedOptionKey?: string;
  quickFilterMode?: "multiple";
  placeHolder?: (selectedOptionKey: string) => string;
}

export const QuickFilter = (props: QuickFilterProps) => {
  const [t] = useTranslation();
  const [selectedOptionKey, setSelectedOptionKey] = useState(
    props.defaultSelectedOptionKey ?? ""
  );
  const [searchValue, setSearchValue] = useState("");

  useEffect(() => {
    setSelectedOptionKey(
      props.selectedOptionKey ?? props.defaultSelectedOptionKey ?? ""
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.selectedOptionKey]);

  useEffect(() => {
    setSearchValue(props.searchValue ?? "");
  }, [props.searchValue]);

  const handleOptionChange = (optionKey: string) => {
    setSelectedOptionKey(optionKey);

    if (props.onChange && selectedOptionKey != "" && searchValue != "") {
      props.onChange(optionKey, searchValue);
    }
  };

  const handleSearchChange = (searchValue: string) => {
    setSearchValue(searchValue);
  };

  const handleSearch = () => {
    if (props.onChange && selectedOptionKey != "") {
      props.onChange!(selectedOptionKey, searchValue.trim());
    }
  };

  return (
    <Grid
      container
      columnSpacing={0.5}
      width={"100%"}
      direction='row'
      justifyContent='space-evenly'
      alignItems='center'
      wrap='nowrap'
    >
      {props.quickFilterMode == "multiple" && (
        <Grid item flex={0.2}>
          <Select
            size='small'
            fullWidth
            sx={{
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
              "& fieldset": { border: "none" },
            }}
            value={selectedOptionKey}
            onChange={(e) => handleOptionChange(e.target.value?.trim())}
          >
            {props.filterOptions.map((option) => (
              <MenuItem value={option.key} key={option.key}>
                {t(option.label)}
              </MenuItem>
            ))}
          </Select>
        </Grid>
      )}
      <Grid item flex={1}>
        <TextField
          size='small'
          fullWidth
          color='primary'
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
            "& fieldset": { border: "none" },
          }}
          value={searchValue}
          onChange={(e) => {
            if (
              e.target.value &&
              e.target.value.length > TEXT_FIELD_MAX_LENGTH
            ) {
              e.target.value = e.target.value.slice(0, TEXT_FIELD_MAX_LENGTH);
            }

            handleSearchChange(e.target.value);
          }}
          onKeyDown={(e) => {
            if (e.key == "Enter") {
              handleSearch();
            }
          }}
          placeholder={
            props.placeHolder && props.placeHolder(selectedOptionKey)
          }
        />
      </Grid>
      <Grid item>
        <IconButton
          sx={{
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
          onClick={handleSearch}
        >
          <SearchIcon />
        </IconButton>
      </Grid>
    </Grid>
  );
};
