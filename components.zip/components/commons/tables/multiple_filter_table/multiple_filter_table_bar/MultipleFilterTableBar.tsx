import { COLOR_TYPE } from "@/constants/color";
import { Grid } from "@mui/material";

import { ReactNode, useEffect, useState } from "react";
import {
  GridColumnVisibilityModel,
  GridFilterModel,
  GridSortModel,
} from "@mui/x-data-grid";
import { FilterOption, QuickFilter } from "./quick_filter/QuickFilter";
import { FilterType, MultipleFilterTableColumn } from "../MultipleFilterTable";
import {
  MultipleFilterTableModal,
  MultipleFilterTableModalState,
} from "./multiple_filter_table_modal/MultipleFilterTableModal";
import { mergeArraysByKey } from "@/utils";

export interface MultipleFilterTableBarProps {
  columns: MultipleFilterTableColumn[];
  filterModel?: GridFilterModel;
  sorterModel?: GridSortModel;
  columnVisibilityModel?: GridColumnVisibilityModel;
  onChange?: (modalState: MultipleFilterTableModalState) => void;
  onChangeQuickFilter?: (filter: GridFilterModel) => void;
  // onSort?: (sorter: GridSortModel) => void;
  // onChangeVisibility?: (columnVisibleModel: GridColumnVisibilityModel) => void;
  onReset?: () => void;
  loading?: boolean;
  quickFilterProps?: {
    defaultSelectedOptionKey?: string;
    quickFilterMode?: "multiple";
    placeHolder?: (selectedOptionKey: string) => string;
  };
  multipleFilter?: boolean;
  exportFile?: ReactNode;
  sortButton?: ReactNode;
}

export const MultipleFilterTableBar = (props: MultipleFilterTableBarProps) => {
  const [quickFilterOptions, setQuickFilterOptions] = useState<FilterOption[]>(
    []
  );

  const [filterModel, setFilterModel] = useState<GridFilterModel | undefined>();

  useEffect(() => {
    setQuickFilterOptions([
      ...props.columns
        .filter((column) => column.quickFilter && column.type == "string")
        .map((column) => ({ key: column.key, label: column.label })),
    ]);
  }, [props.columns]);

  const getQuickFilterItem = () => {
    const filterItems = filterModel?.items.filter(
      (item) => item.id == FilterType.QUICK
    );

    return filterItems && filterItems.length > 0 ? filterItems[0] : undefined;
  };

  const handleQuickFilter = (key: string, value: string) => {
    const newFilterModel: GridFilterModel = {
      items: mergeArraysByKey([
        props?.filterModel?.items ?? [],
        [
          {
            field: key,
            operator: "contains",
            value: value,
            id: FilterType.QUICK,
          },
        ]
      ], (item) => item?.field),
    };

    !props.filterModel && setFilterModel(newFilterModel);

    props.onChangeQuickFilter && props.onChangeQuickFilter(newFilterModel);
  };

  return (
    <Grid
      container
      sx={{
        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
        padding: "0.5em",
      }}
      columnSpacing={0.5}
      width={"100%"}
      direction='row'
      justifyContent='space-evenly'
      alignItems='center'
      wrap='nowrap'
    >
      <Grid item width={"100%"}>
        <QuickFilter
          filterOptions={quickFilterOptions}
          selectedOptionKey={getQuickFilterItem()?.field}
          searchValue={getQuickFilterItem()?.value}
          onChange={handleQuickFilter}
          {...(props.quickFilterProps ?? {})}
        />
      </Grid>
      {props.exportFile ? props?.exportFile : null}
      {props?.sortButton ? props?.sortButton : null}
      {props.multipleFilter && (
        <Grid item>
          <MultipleFilterTableModal {...props} />
        </Grid>
      )}
    </Grid>
  );
};
