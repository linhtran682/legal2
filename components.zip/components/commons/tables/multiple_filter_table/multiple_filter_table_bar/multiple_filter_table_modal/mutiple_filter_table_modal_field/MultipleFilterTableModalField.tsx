/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, Grid, Typography } from "@mui/material";
import {
  GridFilterInputValueProps,
  GridFilterItem,
  GridFilterOperator,
  GridSortDirection,
  useGridApiRef,
} from "@mui/x-data-grid";
import { ReactElement, useEffect, useState } from "react";
import { MultipleFilterTableColumn } from "../../../MultipleFilterTable";
// import ClearIcon from "@mui/icons-material/Clear";
// import SwapVertIcon from "@mui/icons-material/SwapVert";
// import VisibilityIcon from "@mui/icons-material/Visibility";
// import NorthIcon from "@mui/icons-material/North";
// import SouthIcon from "@mui/icons-material/South";
import { useTranslation } from "react-i18next";

export interface MultipleFilterTableModalFieldProps<T>
  extends GridFilterOperator<any, T> {
  column: MultipleFilterTableColumn;
  filter?: GridFilterItem;
  sort?: GridSortDirection | undefined;
  visible?: boolean;

  onFilterChange?: (value: GridFilterItem) => void;
  onSort?: (sortDirection: GridSortDirection | undefined) => void;
  onChangeVisibility?: (visible: boolean) => void;
  InputComponent: (
    props: GridFilterInputValueProps
  ) => ReactElement | ReactElement[];
}

export default function MultipleFilterTableModalField<T>(
  props: Readonly<MultipleFilterTableModalFieldProps<T>>
) {
  const apiRef = useGridApiRef();
  const [t] = useTranslation();

  const [item, setItem] = useState<GridFilterItem>(
    props.filter ?? { field: "", operator: "" }
  );
  // const [sort, setSort] = useState<GridSortDirection | undefined>();
  // const [visible, setVisible] = useState<boolean>(true);

  useEffect(() => {
    setItem(props.filter ?? { field: "", operator: "" });
  }, [props.filter]);

  // useEffect(() => {
  //   setSort(props.sort);
  // }, [props.sort]);

  // useEffect(() => {
  //   setVisible(props.visible ?? true);
  // }, [props.visible]);

  const handleChange = (item: GridFilterItem) => {
    !props.filter && setItem({ ...item });
    props.onFilterChange && props.onFilterChange(item);
  };

  // const handleSort = () => {
  //   const newSort =
  //     sort == undefined ? "asc" : sort == "asc" ? "desc" : undefined;

  //   !props.sort && setSort(newSort);
  //   props.onSort && props.onSort(newSort);
  // };

  // const handleToggleVisible = () => {
  //   props.visible == undefined || props.visible
  //     ? setVisible(false)
  //     : setVisible(true);
  //   props.onChangeVisibility && props.onChangeVisibility(!visible);
  // };

  // const handleClear = () => {
  //   handleChange({ ...item, value: undefined });
  // };

  return (
    <Box width={"100%"}>
      <Grid
        container
        direction="row"
        wrap="nowrap"
        spacing={10}
        alignItems={"center"}
        justifyContent={"space-between"}
      >
        <Grid item>
          <Typography className="label-body2" mb={1}>
            {t(props.column.filterLabel ?? props.column.label)}
          </Typography>
        </Grid>
        <Grid item>
          {/* {props.column.filterable && (
            <IconButton onClick={handleClear}>
              <ClearIcon />
            </IconButton>
          )}

          {props.column.sortable && (
            <IconButton
              color={sort ? "primary" : "default"}
              onClick={handleSort}
            >
              {!sort && <SwapVertIcon />}
              {sort == "asc" && <NorthIcon />}
              {sort == "desc" && <SouthIcon />}
            </IconButton>
          )}

          {props.column.hideable && (
            <IconButton
              color={visible ? "primary" : "default"}
              onClick={handleToggleVisible}
            >
              <VisibilityIcon />
            </IconButton>
          )} */}
        </Grid>
      </Grid>
      <div style={{ marginTop: -6 }}>
        {props.column.filterable && (
          <props.InputComponent
            apiRef={apiRef}
            applyValue={handleChange}
            item={item}
          />
        )}
      </div>
    </Box>
  );
}
