import {
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Popover,
} from "@mui/material";
import { MultipleFilterTableBarProps } from "../MultipleFilterTableBar";
import { createContext, ReactElement, useEffect, useState } from "react";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import MultipleFilterTableModalField from "./mutiple_filter_table_modal_field/MultipleFilterTableModalField";
import { getGridFilterOperators } from "../../../standard_table/StandardTable";
import {
  GridColumnVisibilityModel,
  GridFilterInputValueProps,
  GridFilterItem,
  GridSortDirection,
  GridSortItem,
} from "@mui/x-data-grid";
import { FilterType } from "../../MultipleFilterTable";
import { useTranslation } from "react-i18next";
import { COLOR_TYPE } from "@/constants/color";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import { GLOBAL_SMALL_SPACING, GLOBAL_SPACING } from "@/constants/format";

export interface MultipleFilterTableModalState {
  filterMap: Map<string, GridFilterItem>;
  sorterMap: Map<string, GridSortItem>;
  columnVisibilityModel: GridColumnVisibilityModel;
}

export interface MultipleFilterTableModalProps
  extends MultipleFilterTableBarProps { }

export const MultipleFilterTableModalContext = createContext({
  filterMap: new Map(),
  sorterMap: new Map(),
  columnVisibilityModel: {},
} as MultipleFilterTableModalState);

export const MultipleFilterTableModal = (
  props: MultipleFilterTableModalProps
) => {
  const [t] = useTranslation();

  const [modalState, setModalState] = useState<MultipleFilterTableModalState>({
    filterMap: new Map(),
    sorterMap: new Map(),
    columnVisibilityModel: {},
  });

  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const handlePopoverOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  useEffect(() => {
    setModalState((oldState) => ({
      ...oldState,
      filterMap: new Map(
        (props.filterModel?.items || []).map((item) => [item.field, item])
      ),
      sorterMap: new Map(
        (props.sorterModel || []).map((item) => [item.field, item])
      ),
      columnVisibilityModel: props.columnVisibilityModel || {},
    }));
  }, [props.filterModel, props.sorterModel, props.columnVisibilityModel]);

  const handleClose = () => setAnchorEl(null);

  const handleChangeColumnVisibility = (key: string, visible: boolean) => {
    const newVisibilityModel = { ...(modalState.columnVisibilityModel || {}) };
    newVisibilityModel[key] = visible;

    setModalState((oldState) => ({
      ...oldState,
      columnVisibilityModel: newVisibilityModel,
    }));
  };

  const handleSort = (key: string, sortDirection: GridSortDirection) => {
    const sorterMap = new Map(modalState.sorterMap);

    if (sortDirection) {
      sorterMap.clear();
      sorterMap.set(key, { field: key, sort: sortDirection });
    } else {
      sorterMap.delete(key);
    }

    setModalState((oldState) => ({
      ...oldState,
      sorterMap: sorterMap,
    }));
  };

  const handleFilterChange = (filterItem: GridFilterItem) => {
    const newFilterMap = new Map(modalState.filterMap);

    newFilterMap.set(filterItem.field, { ...filterItem, id: FilterType.MODAL });

    setModalState((oldState) => ({
      ...oldState,
      filterMap: newFilterMap,
    }));
  };

  const handleConfirm = () => {
    // props.onChangeVisibility &&
    //   props.onChangeVisibility(modalState.columnVisibilityModel);
    // props.onSort && props.onSort(Array.from(modalState.sorterMap.values()));
    // props.onChangeFilter &&
    //   props.onChangeFilter({
    //     items: Array.from(modalState.filterMap.values()),
    //   });

    props.onChange && props.onChange(modalState);
    handleClose();
  };

  return (
    <MultipleFilterTableModalContext.Provider value={modalState}>
      <IconButton
        onClick={handlePopoverOpen}
        disabled={props.loading}
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
        }}
      >
        <FilterAltIcon />
      </IconButton>
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        sx={{height: "100%"}}
      >
        <DialogTitle
          variant="h5"
          sx={{
            position: "sticky",
            top: 0,
            zIndex: 100,
            backgroundColor: "inherit",
          }}
        >
          {t("common.table.enhanced_filter")}
        </DialogTitle>
        <DialogContent sx={{ width: 600 }}>
          <Grid
            container
            display='flex'
            direction='column'
            justifyContent={"start"}
            alignItems={"flex-start"}
            rowSpacing={GLOBAL_SMALL_SPACING}
            width={"100%"}
          // width={"max-content"}
          >
            {props.columns
              .filter((column) => column.filterable || column.hideable)
              .sort((a, b) => (a?.filterRank ?? 100) - (b?.filterRank ?? 100))
              .map((column) =>
                getGridFilterOperators(column, t).map((operator) => (
                  <Grid key={column.key} item width={"100%"}>
                    <MultipleFilterTableModalField
                      column={column}
                      value={operator.value}
                      label={operator.label}
                      getApplyFilterFn={operator.getApplyFilterFn}
                      visible={modalState.columnVisibilityModel[column.key]}
                      sort={modalState.sorterMap.get(column.key)?.sort}
                      filter={modalState.filterMap.get(column.key)}
                      InputComponent={
                        operator.InputComponent as (
                          props: GridFilterInputValueProps
                        ) => ReactElement | ReactElement[]
                      }
                      onChangeVisibility={(visible) =>
                        handleChangeColumnVisibility(column.key, visible)
                      }
                      onSort={(direction) => handleSort(column.key, direction)}
                      onFilterChange={(item) =>
                        handleFilterChange({
                          ...item,
                          field: column.key,
                          operator: operator.value,
                        })
                      }
                    />
                  </Grid>
                ))
              )}
          </Grid>
        </DialogContent>
        <DialogActions
          sx={{
            position: "sticky",
            bottom: 0,
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
          }}
        >
          <Grid
            container
            justifyContent={"space-between"}
            spacing={GLOBAL_SPACING}
          >
            <Grid item>
              <Button startIcon={<RestartAltIcon />} onClick={props.onReset}>
                {t("common.button.reset")}
              </Button>
            </Grid>
            <Grid item>
              <Grid container spacing={GLOBAL_SPACING}>
                <Grid item>
                  <Button
                    onClick={handleClose}
                    variant='contained'
                    color='primary'
                    className='cancel'
                  >
                    {t("common.button.cancel")}
                  </Button>
                </Grid>
                <Grid item>
                  <Button onClick={handleConfirm} variant='contained'>
                    {t("common.button.filter")}
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </DialogActions>
      </Popover>
    </MultipleFilterTableModalContext.Provider>
  );
};
