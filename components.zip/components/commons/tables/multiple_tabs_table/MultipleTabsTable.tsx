import {
  GridColumnVisibilityModel,
  GridFilterModel,
  GridPaginationModel,
  GridRowClassNameParams,
  GridRowParams,
  GridSortModel,
} from "@mui/x-data-grid";
import StandardTable, {
  DEFAULT_PAGE_MODAL,
  StandardTableColumn,
  StandardTableState,
} from "../standard_table/StandardTable";
import { Stack } from "@mui/material";
import { ReactNode, useState } from "react";
import { MultipleFilterTableBar } from "../multiple_filter_table/multiple_filter_table_bar/MultipleFilterTableBar";
import { TabNav } from "../../tab-nav/TabNav";
import { FilterType } from "../multiple_filter_table/MultipleFilterTable";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { mergeArraysByKey } from "@/utils";

export interface TableTab<T> {
  tabName: string;
  tabKey: string;
  data: T[];
  loading?: boolean;
  rowCount?: number;
  onChange?: (state: StandardTableState) => void;
}

export interface MultipleTabsTableProps<T> {
  defaultOpenedTabIndex?: number;
  tableTabs: TableTab<T>[];
  getRowId: (data: T) => string;
  columns: StandardTableColumn[];
  initialFilterModel?: GridFilterModel;
  initialSorterModel?: GridSortModel;
  initialPaginationModel?: GridPaginationModel;
  initalColumnVisibilityModel?: GridColumnVisibilityModel;
  multipleFilter?: boolean;
  exportFile?: ReactNode;
  quickFilterProps?: {
    defaultSelectedOptionKey?: string;
    quickFilterMode?: "multiple";
    placeHolder?: (selectedOptionKey: string) => string;
  };
  onRowClick?: (row: GridRowParams) => void;
  groupedActions?: any;
  onTabChange?: (index: number) => void;
  getRowClassName?: (params: GridRowClassNameParams) => string;
}

export default function MultipleTabsTable<T>(
  props: Readonly<MultipleTabsTableProps<T>>
) {
  const [openedTabIndex, setOpenedTabIndex] = useState(
    props.defaultOpenedTabIndex ?? 0
  );

  const [tableBarState, setTableBarState] = useState<{
    mainState: StandardTableState;
    isTabStateUpdated: boolean[];
    isTabColumnVisibilityUpdated: boolean[];
  }>(() => ({
    mainState: {
      filterModel: props.initialFilterModel,
      sorterModel: props.initialSorterModel,
      columnVisibilityModel: props.initalColumnVisibilityModel,
      paginationModel: props.initialPaginationModel || DEFAULT_PAGE_MODAL,
    },
    isTabStateUpdated: Array(props.tableTabs.length).fill(true),
    isTabColumnVisibilityUpdated: Array(props.tableTabs.length).fill(true),
  }));

  const [tableStates] = useState<Map<string, StandardTableState>>(() => {
    const map = new Map<string, StandardTableState>();

    props.tableTabs.forEach((tableTab) =>
      map.set(tableTab.tabKey, {
        filterModel: props.initialFilterModel,
        sorterModel: props.initialSorterModel,
        columnVisibilityModel: props.initalColumnVisibilityModel,
        paginationModel: props.initialPaginationModel || DEFAULT_PAGE_MODAL,
      })
    );

    return map;
  });

  const handleChangeTableBarState = (mainState: StandardTableState) => {
    const tableTab = props.tableTabs[openedTabIndex];
    tableStates.set(tableTab.tabKey, mainState);

    setTableBarState((oldState) => ({
      ...oldState,
      mainState: mainState,
      isTabStateUpdated: Array(props.tableTabs.length).fill(false),
    }));
    tableTab?.onChange && tableTab.onChange(mainState);
  };

  const handleChangeTabIndex = (tabIndex: number) => {
    const tableTab = props.tableTabs[tabIndex];

    if (tableBarState.isTabColumnVisibilityUpdated[tabIndex]) {
      tableStates.set(tableTab.tabKey, tableBarState.mainState);

      tableBarState.isTabColumnVisibilityUpdated[tabIndex] = true;
    }

    if (tableBarState.isTabStateUpdated[tabIndex]) {
      tableStates.set(tableTab.tabKey, tableBarState.mainState);
      tableStates.has(tableTab.tabKey) &&
        tableTab?.onChange &&
        tableTab.onChange(tableStates.get(tableTab.tabKey)!);

      tableBarState.isTabStateUpdated[tabIndex] = true;
    }

    setOpenedTabIndex(tabIndex);
    props?.onTabChange && props?.onTabChange(tabIndex);
  };

  const handleReset = () => {
    const mainState: StandardTableState = {
      filterModel: props.initialFilterModel,
      sorterModel: props.initialSorterModel,
      columnVisibilityModel: props.initalColumnVisibilityModel,
      paginationModel: props.initialPaginationModel || DEFAULT_PAGE_MODAL,
    };

    const tableTab = props.tableTabs[openedTabIndex];
    tableStates.set(tableTab.tabKey, mainState);

    setTableBarState((oldState) => ({
      ...oldState,
      mainState: mainState,
      isTabStateUpdated: Array(props.tableTabs.length).fill(false),
    }));

    tableTab?.onChange && tableTab.onChange(mainState);
  };

  const handleChangeTableState = (
    state: StandardTableState,
    tabKey: string,
    index: number
  ) => {
    const newState: StandardTableState = {
      columnVisibilityModel: state?.columnVisibilityModel,
      sorterModel: state.sorterModel,
      paginationModel: state.paginationModel,
      filterModel: {
        ...tableStates.get(tabKey)?.filterModel,
        items: mergeArraysByKey([
          tableStates.get(tabKey)?.filterModel?.items ?? [],
          state.filterModel?.items ?? []
        ], (item) => item.field)
      }
    }
    // tableStates.set(tabKey, state);
    // props.tableTabs[index]?.onChange && props.tableTabs[index].onChange(state);
    tableStates.set(tabKey, newState);
    props.tableTabs[index]?.onChange && props.tableTabs[index].onChange(newState);
  };

  const handleChangeTableColumnVisibility = (
    model: GridColumnVisibilityModel,
    tabKey: string
  ) => {
    const state = tableStates.get(tabKey);

    if (state) {
      state.columnVisibilityModel = { ...model };
      tableBarState.mainState.columnVisibilityModel =
        props.initalColumnVisibilityModel;
    }
  };

  return (
    <Stack spacing={GLOBAL_SMALL_SPACING} height={"100%"}>
      <MultipleFilterTableBar
        columns={props.columns}
        filterModel={tableBarState.mainState.filterModel}
        sorterModel={tableBarState.mainState.sorterModel}
        columnVisibilityModel={tableBarState.mainState.columnVisibilityModel}
        onChangeQuickFilter={(filterModel) =>
          handleChangeTableBarState({
            ...tableBarState.mainState,
            filterModel: filterModel,
            paginationModel: {
              ...tableBarState.mainState.paginationModel,
              page: 0,
            },
          })
        }
        onChange={(modalState) => {
          handleChangeTableBarState({
            filterModel: { items: Array.from(modalState.filterMap.values()) },
            sorterModel: Array.from(modalState.sorterMap.values()),
            paginationModel: {
              ...tableBarState.mainState.paginationModel,
              page: 0,
            },
            columnVisibilityModel: modalState.columnVisibilityModel,
          });
        }}
        loading={props.tableTabs.some((item) => item.loading)}
        onReset={handleReset}
        multipleFilter={props.multipleFilter}
        exportFile={props?.exportFile}
        quickFilterProps={props.quickFilterProps}
      />
      <TabNav
        index={openedTabIndex}
        onChangeTabIndex={handleChangeTabIndex}
        tabItems={props.tableTabs.map((tableTab, index) => ({
          key: tableTab.tabKey + index.toString(),
          label: tableTab.tabName,
          content: (
            <StandardTable
              groupedActions={props?.groupedActions}
              columns={props.columns}
              getRowId={props.getRowId}
              initialFilterModel={props.initialFilterModel}
              initialSorterModel={props.initialSorterModel}
              initialPaginationModel={props.initialPaginationModel}
              initalColumnVisibilityModel={props.initalColumnVisibilityModel}
              key={tableTab.tabKey}
              data={tableTab.data}
              loading={tableTab.loading}
              rowCount={tableTab.rowCount}
              sorterModel={tableStates.get(tableTab.tabKey)?.sorterModel}
              paginationModel={
                tableStates.get(tableTab.tabKey)?.paginationModel
              }
              filterModel={{
                ...(tableStates.get(tableTab.tabKey)?.filterModel || {}),
                items: (
                  tableStates.get(tableTab.tabKey)?.filterModel?.items || []
                ).filter(
                  (item) =>
                    item.id != FilterType.MODAL && item.id != FilterType.QUICK
                ),
              }}
              onChange={(state) =>
                handleChangeTableState(state, tableTab.tabKey, index)
              }
              columnVisibilityModel={
                tableStates.get(tableTab.tabKey)?.columnVisibilityModel
              }
              onChangeColumnVisibility={(model) =>
                handleChangeTableColumnVisibility(model, tableTab.tabKey)
              }
              onRowClick={props.onRowClick}
              getRowClassName={props.getRowClassName}
            />
          ),
        }))}
      />
    </Stack>
  );
}
