import { COLOR_TYPE } from "@/constants/color";
import { EXPECTED_DATE_TIME_LOCALE } from "@/constants/format";
import { formatSingleDigitNumber } from "@/utils";
import {
  Checkbox,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@mui/material";
import { useTranslation } from "react-i18next";

// Define a custom type for renderCell parameters
export interface CustomRenderCellParams<T> {
  id: string;
  value: any;
  field: string;
  row: T;
}

export interface StandardSimpleTableColumn<T> {
  key: string;
  label: string;
  type: "date" | "number" | "string" | "checkbox" | undefined;
  flex?: number;
  renderCell?: (params: CustomRenderCellParams<T>) => React.ReactNode;
}

export interface StandardSimpleTableProps<T> {
  recordName?: string;
  data: T[];
  getRowId: (data: T, index: number) => string;
  columns: StandardSimpleTableColumn<T>[];
  loading?: boolean;
}

export function StandardSimpleTable<T>(props: StandardSimpleTableProps<T>) {
  const [t] = useTranslation();

  return (
    <Table>
      <TableHead>
        <TableRow>
          {props.columns.map((column) => (
            <TableCell
              key={column.key}
              sx={{
                border: `solid 1px ${COLOR_TYPE.TOYOTA.TOYOTA4}80`,
                backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA5}80`,
              }}
            >
              {t(column.label)}
            </TableCell>
          ))}
        </TableRow>
      </TableHead>
      <TableBody>
        {props.data.map((item, index) => (
          <TableRow key={props.getRowId(item, index)}>
            {props.columns.map((column) => (
              <TableCell
                key={`${column.key}-${props.getRowId(item, index)}`}
                component='th'
                scope='row'
                sx={{
                  border: `solid 1px ${COLOR_TYPE.TOYOTA.TOYOTA4}80`,
                  backgroundColor:
                    index % 2 !== 0
                      ? `${COLOR_TYPE.TOYOTA.TOYOTA6}80`
                      : COLOR_TYPE.TOYOTA.TOYOTA8,
                }}
                align={
                  ["date", "number"].includes(column.type ?? "")
                    ? "right"
                    : "left"
                }
              >
                {column.renderCell ? (
                  column.renderCell({
                    id: props.getRowId(item, index),
                    value: (item as any)[column.key],
                    field: column.key,
                    row: item,
                  })
                ) : column.type === "date" ? (
                  Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                    dateStyle: "short",
                    timeStyle: "medium",
                  }).format(new Date((item as any)[column.key]))
                ) : column.type === "number" ? (
                  formatSingleDigitNumber((item as any)[column.key])
                ) : column.type === "checkbox" ? (
                  <Checkbox checked={(item as any)[column.key]} />
                ) : (
                  (item as any)[column.key]
                )}
              </TableCell>
            ))}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
