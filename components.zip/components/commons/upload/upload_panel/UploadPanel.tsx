import {
  Grid,
  IconButton,
  List,
  ListItem,
  ListItemAvatar,
  ListItemButton,
  ListItemText,
  Typography,
} from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { COLOR_TYPE } from "@/constants/color";
import {
  EXPECTED_DATE_TIME_LOCALE,
  GLOBAL_SMALL_SPACING,
  GLOBAL_SPACING,
} from "@/constants/format";
import { useTranslation } from "react-i18next";
import { ChangeEvent, DragEvent, useState } from "react";
import { PDFIcon } from "@/assets/images/icons/iconPDF";
import DeleteIcon from "@mui/icons-material/Delete";
import { DefaultFileIcon } from "@/assets/images/icons/iconDefaultFile";
import { toast } from "react-toastify";
import { FileUploadResponse } from "@/apis/service/files_upload/files";
import { useMutation, useQuery } from "@tanstack/react-query";

export interface UploadPanelProps {
  queryKey: string;
  onGetFiles: () => Promise<FileUploadResponse[]>;
  onUpload: (files: File[]) => Promise<void>;
  onDelete: (fileId: number) => Promise<void>;
  disabled?: boolean;
}

const ALLOWED_FILE_TYPE = [".pdf", ".docx", ".txt", ".xlsx"];

const getFileExtension = (fileName: string) => {
  const lastDotIndex = fileName.lastIndexOf(".");
  if (lastDotIndex === -1 || lastDotIndex === 0) {
    return "";
  }
  return fileName.substring(lastDotIndex + 1);
};

const getFileIcon = (fileExtension: string) => {
  if (fileExtension == "pdf") {
    return <PDFIcon />;
  }

  return <DefaultFileIcon />;
};

export const UploadPanel = (props: UploadPanelProps) => {
  const [t] = useTranslation();

  const [files, setFiles] = useState<FileUploadResponse[]>([]);

  const getFilesQuery = useQuery({
    queryKey: [props.queryKey],
    queryFn: () =>
      props.onGetFiles().then((files) => {
        setFiles(files);
        return files;
      }),
  });

  const uploadQuery = useMutation({
    mutationFn: props.onUpload,
    onSuccess: () => {
      getFilesQuery.refetch();
    },
  });

  const deleteQuery = useMutation({
    mutationFn: props.onDelete,
    onSuccess: () => {
      getFilesQuery.refetch();
    },
  });

  const loading =
    getFilesQuery.isLoading || uploadQuery.isPending || deleteQuery.isPending;

  const validateFile = (file: File) => {
    if (!ALLOWED_FILE_TYPE.includes(`.${getFileExtension(file.name)}`)) {
      toast.error(
        t("common.upload.message_type_not_support", { fileName: file.name })
      );
      return false;
    }

    if (Math.round(file.size / 1024) > 1024 * 5) {
      toast.error(
        t("common.upload.message_exceed_max_size", { fileName: file.name })
      );
      return false;
    }

    return true;
  };

  const handleUpload = (files: File[]) => {
    const validatedFiles = files.filter((file) => validateFile(file));

    if (validatedFiles.length > 0) {
      uploadQuery.mutate(validatedFiles);
    }
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    handleUpload(Array.from(event.dataTransfer.files));
  };

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    handleUpload(Array.from(event.target.files ?? []));
  };

  const handleDeleteFile = (fileId: number) => {
    deleteQuery.mutate(fileId);
  };

  return (
    <Grid container direction={"column"} padding={GLOBAL_SPACING}>
      {!props.disabled && (
        <Grid item width={"100%"}>
          <Grid
            container
            className='upload-area'
            direction={"column"}
            justifyContent={"center"}
            alignItems={"center"}
            sx={{
              backgroundColor: `${COLOR_TYPE.TOYOTA.TOYOTA1}1A`,
              border: `solid 1px ${COLOR_TYPE.TOYOTA.TOYOTA1}`,
            }}
            padding={GLOBAL_SPACING}
            rowGap={GLOBAL_SMALL_SPACING}
            onDrop={handleDrop}
            onDragOver={(event) => event.preventDefault()}
          >
            <Grid item className='upload-icon'>
              <label
                htmlFor='file-upload'
                style={{
                  cursor: "pointer",
                }}
              >
                <CloudUploadIcon
                  fontSize='large'
                  color='primary'
                  sx={{ opacity: 1 }}
                />
              </label>
            </Grid>
            <Grid item className='upload-input'>
              <Typography variant='body2'>
                {t("common.upload.title_drop_or")}{" "}
                <label
                  htmlFor='file-upload'
                  style={{
                    fontWeight: "bold",
                    color: COLOR_TYPE.TOYOTA.TOYOTA1,
                    cursor: "pointer",
                  }}
                >
                  {t("common.upload.title_choose_file")}
                </label>{" "}
                {t("common.upload.title_to_upload")}
              </Typography>
            </Grid>
            <Grid item className='upload-desc'>
              <Typography variant='body2'>
                {t("common.upload.description", {
                  fileType: ALLOWED_FILE_TYPE.join(", "),
                })}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      )}

      <Grid item width={"100%"}>
        <List dense>
          {files.map((file) => (
            <ListItem
              key={file.fileId}
              alignItems='center'
              secondaryAction={
                false ? (
                  <IconButton
                    edge='end'
                    onClick={() => handleDeleteFile(file.fileId)}
                  >
                    <DeleteIcon />
                  </IconButton>
                ) : undefined
              }
              disablePadding
            >
              <ListItemButton disabled={loading} onClick={() => {}}>
                <ListItemAvatar>
                  {getFileIcon(getFileExtension(file.fileName))}
                </ListItemAvatar>
                <ListItemText
                  primary={file.fileName}
                  secondary={
                    file.uploadDate ??
                    Intl.DateTimeFormat(EXPECTED_DATE_TIME_LOCALE, {
                      dateStyle: "short",
                      timeStyle: "medium",
                    }).format(new Date(file.uploadDate!))
                  }
                  secondaryTypographyProps={{
                    variant: "caption",
                  }}
                />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Grid>

      <input
        type='file'
        hidden
        id='file-upload'
        accept={ALLOWED_FILE_TYPE.join(",")}
        multiple
        onChange={handleInputChange}
        disabled={props.disabled || loading}
      />
    </Grid>
  );
};
