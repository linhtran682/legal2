import { GetListIdFile, uploadFileToLegalCheckSheet } from "@/apis/service/files_upload/files";
import { IconAdd } from "@/assets/images/icons/iconAdd";
import { ExcelIcon } from "@/assets/images/icons/iconExcel";
import { ImageIcon } from "@/assets/images/icons/iconImage";
import { PDFIcon } from "@/assets/images/icons/iconPDF";
import { PPTIcon } from "@/assets/images/icons/iconPPT";
import { WordIcon } from "@/assets/images/icons/iconWord";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { FileInfo } from "@/models/law_document/LawDocument";
import ArrowOutwardRoundedIcon from "@mui/icons-material/ArrowOutwardRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import RemoveRedEyeOutlinedIcon from "@mui/icons-material/RemoveRedEyeOutlined";
import {
  Box,
  CircularProgress,
  FormControl,
  FormHelperText,
  Grid,
  IconButton,
  // InputLabel,
  Radio,
  Stack,
  Tooltip,
  Typography,
} from "@mui/material";
// import Image from "next/image";
import React, { ChangeEvent, DragEvent, useCallback, useState } from "react";
import { Controller } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { ModalCommon } from "../../popups/modal/Modal";
import {
  addFileButtonSx,
  checkBoxWrapperSx,
  dropInstructionSx,
  fileIconButtonSx,
  fileItemSx,
  indexWrapperSx,
  radioOutlineSx,
} from "./styles";
import { AxiosError } from "axios";
import { ResponseWrapper } from "@/apis";
import CheckboxInput from "../../inputs/checkbox/CheckboxInput";
import { ListItemLabel, RedItalicLabel } from "./LabelWithBox";
import { ConfirmPopup, ConfirmPopupProps, DefaultConfirmPopupState } from "../../popups/confirm_popup/ConfirmPopup";
import { SpPermissionTypes } from "@/models/document-review/LegalCheckSheet";
import { ErrorPopup, ErrorPopupProps } from "../../popups/confirm_popup/ErrorPopup";

export interface FileDetails {
  id?: number;
  name: string;
  file?: File;
  path?: string;
  uploadDate?: string;
  accessLink?: string;
  sharePointLink?: string;
  isEvaluateFile?: boolean;

  isSharepoint?: boolean;
}

export interface LcsFileResponse {
  id: number;
  sharePointId: string;
  sharePointLink: string;
  fileName: string;
}
interface FileUploadComponentProps {
  name?: string;
  control?: any;
  files: FileDetails[];
  setFiles: (files: FileDetails[]) => void;
  disabled?: boolean;
  title?: string;
  inputId?: string;

  hasRadio?: boolean;
  setSelectedId?: (id: number) => void;
  selectionId?: number;
  disableRadio?: boolean;

  isSharepoint?: boolean;
  accept?: string[];
  required?: boolean;
  dropView?: boolean;
  preview?: boolean;
  preventOnchange?: boolean;

  isLcs?: boolean;
  maxNumFiles?: number;

  hasCheckBox?: boolean;
  disableCheckbox?: boolean;
  onItemCheck?: (item: any) => void;
  checkSelected?: (item: any) => boolean;

  radioPurpose?: string;
  checkboxPurpose?: string;
  onFileDelete?: (file?: any, index?: number) => void;

  additionNote?: string;

  spPermission?: number; // Quyền truy cập sharepoint
  spFolder?: string; // Folder cần quyền truy cập
  typeUpload?: string;

  addFileToRecordCb?: (fileList: any) => Promise<any>; // Callback update file trực tiếp vào bản ghi sau khi upload
}

const IMAGE_TYPES = [".jpeg", ".jpg", ".png"];
const ALLOWED_FILE_TYPE = [
  ".pdf",
  ".xlsx",
  ".ppt",
  ".pptx",
  ".doc",
  ".docx",
  ".png",
  ".jpeg",
  ".jpg",
];
export const ALLOWED_DOCUMENT_TYPE = [
  ".pdf",
  ".xlsx",
  ".ppt",
  ".pptx",
  ".doc",
  ".docx",
  // ".png",
  // ".jpeg",
  // ".jpg",
];
// const FILE_TYPE = "pdf, xlsx, ppt, pptx, doc, docx, png, jpeg, jpg";

export const getFileExtension = (fileName: string) => {
  const lastDotIndex = fileName?.lastIndexOf(".");
  if (lastDotIndex === -1 || lastDotIndex === 0) {
    return "";
  }
  return fileName?.substring?.(lastDotIndex + 1)?.toLowerCase?.();
};

export const getFileIcon = (fileExtension: string) => {
  if (fileExtension == "pdf") {
    return <PDFIcon />;
  }
  if (["docx", "doc"].includes(fileExtension)) {
    return <WordIcon />;
  }
  if (["xlsx", "xls"].includes(fileExtension)) {
    return <ExcelIcon />;
  }
  if (["ppt", "pptx"].includes(fileExtension)) {
    return <PPTIcon />;
  }
  return <ImageIcon />;
};

export const isImage = (file: any) => {
  return IMAGE_TYPES?.includes(`.${getFileExtension(file?.name)}`);
};

const DropPreviewFileUploadComponent: React.FC<FileUploadComponentProps> = ({
  name = "files",
  control,
  files,
  setFiles,
  disabled,
  title,
  inputId,
  setSelectedId,
  selectionId,
  isSharepoint,
  hasRadio,
  // accept = ALLOWED_FILE_TYPE.join(","),
  accept = ALLOWED_FILE_TYPE,
  required,
  dropView,
  preview,
  disableRadio,
  preventOnchange = false,
  checkSelected,
  hasCheckBox,
  additionNote,
  onItemCheck,
  // isLcs = false,
  maxNumFiles,
  onFileDelete,
  disableCheckbox,
  radioPurpose = 'DOCUMENT_REVIEW.labels.toUploadToSharepoint',
  checkboxPurpose = 'DOCUMENT_REVIEW.labels.toUploadToSharepoint',
  spFolder,
  spPermission,
  typeUpload,
  addFileToRecordCb
}) => {
  const { t } = useTranslation();
  const [showInstruction, setShowInstruction] = useState(false);
  const [previewFile, setPreviewFile] = useState<FileDetails | null>(null);
  const [uploading, setUploading] = useState(false);
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const [warningPopupState, setWarningPopupState] = useState<ErrorPopupProps>({
    open: false,
    title: "",
    textCancel: t("common.button.close"),
    onClose: () => {},
  })

  const handleDrop = async (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setShowInstruction(false);
    if (disabled || uploading) return;
    const droppedFiles = event.dataTransfer.files;

    const validatedFiles: any = [];
    let hasInvalidFormats = false;

    Array.from(droppedFiles).forEach((file) => {
      // if (!ALLOWED_FILE_TYPE.includes(`.${getFileExtension(file.name)}`)) {
      if (!accept.includes(`.${getFileExtension(file.name)}`)) {
        hasInvalidFormats = true;
      } else {
        validatedFiles.push(file);
      }
    });
    if (hasInvalidFormats) {
      toast.error(
        t("common.upload.description", {
          // fileType: FILE_TYPE,
          fileType: accept.map((a) => a.replace('.', '')).join(', ')
        })
      );
    }
    if (!validatedFiles.length) return;

    if (validatedFiles.length) {
      const newFileDetails = validatedFiles?.map((file: any) => ({
        name: file.name,
        file,
      }));
      await handleUploadFiles(newFileDetails);
    }
  };

  const handleFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const newFiles = event.target.files;
    const validatedFiles: any = [];
    let hasInvalidFormats = false;
    if (newFiles) {
      Array.from(newFiles).forEach((file) => {
        if (!accept.includes(`.${getFileExtension(file.name)}`)) {
          hasInvalidFormats = true;
        } else {
          validatedFiles.push(file);
        }
      });
      if (hasInvalidFormats) {
        toast.error(
          t("common.upload.description", {
            // fileType: FILE_TYPE,
            fileType: accept.map((a) => a.replace('.', '')).join(', '),
          })
        );
      }
      const newFileDetails = validatedFiles.map((file: any) => ({
        name: file.name,
        file,
      }));

      if (typeUpload === 'lcs') {
        if (spPermission === SpPermissionTypes.ACC_365_UPLOAD) {
          newFileDetails?.length && (await handleUploadFiles(newFileDetails, 'lcs'));
          return;
        }
  
        if (spPermission === SpPermissionTypes.ACC_365_NO_UPLOAD) {
          setConfirmPopupState({
            open: true,
            icon: <></>,
            title: t("common.message.sp_folder", { folder: `'${spFolder}'` }),
            handleConfirm: async () => {
              setConfirmPopupState(DefaultConfirmPopupState);
              newFileDetails?.length && (await handleUploadFiles(newFileDetails))
            },
            handleCancel: () => {
              setConfirmPopupState(DefaultConfirmPopupState);
            },
          })
          return;
        }
  
        if (spPermission === SpPermissionTypes.ACC_UPLOAD) {
          setConfirmPopupState({
            open: true,
            icon: <></>,
            title: t("common.message.sp_tmv"),
            handleConfirm: async () => {
              setConfirmPopupState(DefaultConfirmPopupState);
              newFileDetails?.length && (await handleUploadFiles(newFileDetails))
            },
            handleCancel: () => {
              setConfirmPopupState(DefaultConfirmPopupState);
            },
          })
          return;
        }
      }

      // return;
      newFileDetails?.length && (await handleUploadFiles(newFileDetails));
    }
  };

  const handleUploadFiles = async (uploadedFiles: any, type?: 'lcs' | undefined) => {
    try {
      setUploading(true);
      let newFileList: any = [];
      let appendedList: any = [];
      if (!type) { // Không có type thì upload bình thường
        const response = await GetListIdFile(uploadedFiles);
        const formatResponse: FileDetails[] = response.fileUploadResponses.map(
          (item: FileInfo, index: number) => {
            const fileItem: FileDetails = {
              ...item,
              id: item.fileId,
              name: item.fileName,
              path: item.storagePath,
            }

            if (typeUpload === "visitation-sharepoint") {
              fileItem.file = uploadedFiles?.[index].file;
            }
            return fileItem;
          }
        );
        newFileList = [...files, ...formatResponse];
        appendedList = [...formatResponse];
      }

      if (type === 'lcs') {
        const responseLcs = await uploadFileToLegalCheckSheet(uploadedFiles);
        const formatLcsResponse: FileDetails[] = responseLcs?.fileUploadSharePointResponses?.map?.(
          (item: LcsFileResponse) => ({
            ...item,
            id: item.id,
            name: item.fileName,
            accessLink: item.sharePointLink,
            isSharepoint: true
          })
        );
        newFileList = [...files, ...formatLcsResponse];
        appendedList = [...formatLcsResponse];
      }
      // Case update files vào record ngay sau khi upload
      addFileToRecordCb && await addFileToRecordCb(appendedList);
      setFiles(newFileList);
    } catch (error) {
      const code = (error as AxiosError<ResponseWrapper<any>>)?.response?.data
        ?.error?.code;
      if (code === 40900901) {
        toast.error(t(`common.error_code.${code}`));
      } else {
        toast.error(t("common.message.upload_error"));
      }
    } finally {
      setUploading(false);
    }
  };

  const handleButtonClick = () => {
    if (disabled || uploading) return;
    document.getElementById(inputId ?? "file-input")?.click();
  };

  const handleDelete = (e: any, fileIndex: number, file?: any) => {
    e.stopPropagation();
    setFiles(files.filter((_, index) => index !== fileIndex));
    onFileDelete && onFileDelete?.(file, fileIndex)
  };
  // const [selectedFile, setSelectedFile] = useState(null);

  const handleRadioChange = (fileId: number) => {
    // setSelectedFile(fileName);
    !!fileId && setSelectedId?.(fileId);
  };

  const onDownloadClick = (e: any, file: any) => {
    e.stopPropagation();
    const a = document.createElement("a");
    a.href = file?.path ?? file?.accessLink;
    a.download = file.name;
    a.click();
  };
  const onViewClick = async (e: any, file: any) => {
    e.stopPropagation();
    setPreviewFile(file);
  };
  const onOpenAccessLinkClick = async (e: any, file: any) => {
    e.stopPropagation();
    if (file?.accessLink) {
      window.open(file.accessLink, "_blank");
    } else if (file?.sharePointLink) {
      window.open(file.sharePointLink, "_blank");
    }
  };

  const showAddBtn = useCallback(() => {
    if (disabled) return false;
    if (dropView && !(files ?? []).length) return false;
    if (maxNumFiles && files.length === maxNumFiles) return false;
    return true;
  }, [maxNumFiles, dropView, preview, disabled, files])

  return (
    <Box sx={{ width: "100%" }}>
      {title && (
        <FormControl fullWidth>
          <Stack width={'100%'} direction={'row'} alignItems={'center'} gap={0.5}>
            <label>
              {title}
              {required && <span style={{ color: "red" }}>*</span>}
            </label>
            {(hasRadio && !hasCheckBox && !additionNote) && <RedItalicLabel type="circle" purpose={radioPurpose} />}
            {(!hasRadio && hasCheckBox && !additionNote) && <RedItalicLabel type="square" purpose={checkboxPurpose} />}
          </Stack>
          {(hasRadio && (hasCheckBox || additionNote)) &&
            <Stack gap={1} pt={1} pb={2}>
              <ListItemLabel type="circle" purpose={radioPurpose} />
              {hasCheckBox ? <ListItemLabel type="square" purpose={checkboxPurpose} /> : null}
              {additionNote ? <ListItemLabel type="text" purpose={additionNote ?? ''} /> : null}
            </Stack>}
        </FormControl>
      )}
      {
        dropView && !disabled && !files?.length ? (
          <Grid item width={"100%"}>
            <label htmlFor={inputId ?? "file-input"}>
              <Grid
                container
                className="upload-area"
                direction={"column"}
                justifyContent={"center"}
                alignItems={"center"}
                sx={{
                  backgroundColor: "#FFF5F6",
                  border: `solid 1px #FAB2C1`,
                  borderRadius: "10px",
                  cursor: "pointer",
                  minHeight: "110px",
                }}
                padding={GLOBAL_SMALL_SPACING}
                rowGap={GLOBAL_SMALL_SPACING}
                onDrop={handleDrop}
                onDragOver={(event) => event.preventDefault()}
              >
                {!uploading ? (
                  <>
                    <Grid item className="upload-icon">
                      <label
                        htmlFor="file-upload"
                        style={{
                          cursor: "pointer",
                        }}
                      >
                        <CloudUploadIcon
                          fontSize="large"
                          color="primary"
                          sx={{ opacity: 1 }}
                        />
                      </label>
                    </Grid>
                    <Grid item className="upload-input">
                      <Typography variant="body2">
                        {t("common.upload.title_drop_or")}{" "}
                        <label
                          htmlFor={inputId ?? "file-input"}
                          style={{
                            fontWeight: "bold",
                            color: COLOR_TYPE.TOYOTA.TOYOTA1,
                            cursor: "pointer",
                          }}
                        >
                          {t("common.upload.title_choose_file")}
                        </label>{" "}
                        {t("common.upload.title_to_upload")}
                      </Typography>
                    </Grid>
                    <Grid item className="upload-desc">
                      <Typography variant="body2">
                        {t("common.upload.description", {
                          fileType: accept.map((a) => a.replace('.', '')).join(', ')
                        })}
                      </Typography>
                    </Grid>
                  </>
                ) : (
                  <>
                    <CircularProgress size={"24px"} />
                    <Typography variant="body2">
                      {t("common.upload.uploading")}
                    </Typography>
                  </>
                )}
              </Grid>
            </label>
          </Grid>
        ) : null
      }

      <Grid
        container
        sx={{
          position: "relative",
        }}
        onDrop={handleDrop}
        onDragLeave={(event: any) => {
          event.preventDefault();
          setShowInstruction(false);
        }}
        onDragEnd={(event: any) => {
          event.preventDefault();
          setShowInstruction(false);
        }}
        onDragOver={(event: any) => {
          event.preventDefault();
          if (disabled) return;
          setShowInstruction(true);
        }}
        alignItems="flex-start"
      >
        {showInstruction && (
          <Box sx={dropInstructionSx}>
            <Typography variant="body2">
              {t("common.upload.drop_here")}
            </Typography>
          </Box>
        )}
        <Grid item xs>
          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
            }}
          >
            {files.map((file, index) => (
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "column",
                }}
                key={index}
              >
                <Tooltip title={file.name}>
                  <Box
                    sx={{
                      ...fileItemSx,
                    }}
                  >
                    <Stack
                      direction={'row'}
                      justifyContent={'space-between'}
                      width={'100%'}
                      sx={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        p: '6px'
                      }}>
                      <Box sx={indexWrapperSx}>
                        <Typography
                          sx={{
                            fontSize: "12px",
                            color: "white",
                            fontWeight: "600",
                          }}
                        >
                          {index + 1}
                        </Typography>
                      </Box>
                      {
                        hasRadio && !isImage(file) && (
                          <Box sx={{
                            ...radioOutlineSx,
                            border: `2px solid ${disabled || disableRadio ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}`,
                            cursor: disabled || disableRadio ? 'default' : 'pointer'
                          }}
                            onClick={() => {
                              if (disabled || disableRadio) return;
                              handleRadioChange(file.id as number)
                            }}
                          >
                            {selectionId === file.id && <Box sx={{
                              width: 10,
                              height: 10,
                              borderRadius: '30px',
                              backgroundColor: disabled || disableRadio ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1
                            }} />}
                          </Box>
                        )
                      }
                      {hasCheckBox && !isImage(file) && <Box sx={checkBoxWrapperSx}>
                        <CheckboxInput
                          borderColor={disableCheckbox || disabled ? COLOR_TYPE.TOYOTA.TOYOTA5 : COLOR_TYPE.TOYOTA.TOYOTA1}
                          disabled={disableCheckbox || disabled}
                          checked={!!checkSelected?.(file)}
                          onChange={() => {
                            if (disableCheckbox || disabled) {
                              return
                            }

                            if (spPermission === SpPermissionTypes.ACC_365_NO_UPLOAD && typeUpload === "visitation-sharepoint") {
                              setWarningPopupState({
                                open: true,
                                title: t("common.message.sp_folder_warning", { folder: `'${spFolder}'` }),
                                onClose: () => {
                                  setWarningPopupState(pre => ({...pre, open: false}));
                                },
                              })
                              return;
                            }

                            onItemCheck?.(file)
                          }
                          }
                        />
                      </Box>}
                    </Stack>

                    {isImage(file) ? (
                      <ImageComponent src={(file?.path ?? "") as string} />
                    ) : (
                      getFileIcon(getFileExtension(file.name))
                    )}
                    {!disabled ? (
                      <IconButton
                        onClick={(e) => handleDelete(e, index, file)}
                        sx={{ ...fileIconButtonSx, left: 0 }}
                      >
                        <DeleteOutlineRoundedIcon fontSize="small" />
                      </IconButton>
                    ) : null}

                    <IconButton
                      onClick={(e) => onDownloadClick(e, file)}
                      sx={{ ...fileIconButtonSx, right: 0 }}
                    >
                      <FileDownloadOutlinedIcon fontSize="small" />
                    </IconButton>
                    {isImage(file) ? (
                      <IconButton
                        onClick={(e) => onViewClick(e, file)}
                        sx={{ ...fileIconButtonSx, left: "32px" }}
                      >
                        <RemoveRedEyeOutlinedIcon fontSize="small" />
                      </IconButton>
                    ) : null}
                    {(!!file?.accessLink || !!file?.sharePointLink) ? (
                      <IconButton
                        onClick={(e) => onOpenAccessLinkClick(e, file)}
                        sx={{ ...fileIconButtonSx, left: "32px" }}
                      >
                        <ArrowOutwardRoundedIcon fontSize="small" />
                      </IconButton>
                    ) : null}

                  </Box>
                </Tooltip>

                {isSharepoint && !isImage(file) && (
                  <Radio
                    onChange={() => handleRadioChange(file.id as number)}
                    checked={selectionId === file.id}
                    value={file.name}
                    name="file-radio-group"
                    disabled={disabled || disableRadio}
                    sx={{ marginTop: -0.75 }}
                  />
                )}
              </Box>
            ))}

            {
              showAddBtn()
                ? (
                  <IconButton
                    disableRipple
                    disabled={uploading}
                    sx={addFileButtonSx}
                    onClick={handleButtonClick}
                  >
                    {!uploading ? (
                      <IconAdd />
                    ) : (
                      <>
                        <CircularProgress size={"24px"} />
                        <Typography variant="body2">
                          {t("common.upload.uploading")}
                        </Typography>
                      </>
                    )}
                  </IconButton>
                ) : null}
          </Box>
        </Grid>
      </Grid>
      <Controller
        name={name}
        control={control}
        render={({ field: { onChange }, fieldState: { error } }) => {
          return (
            <>
              <input
                id={inputId ?? "file-input"}
                type="file"
                multiple
                onChange={(e) => {
                  !preventOnchange && onChange(e.target.files);
                  handleFileChange(e);
                  e.target.value = "";
                }}
                style={{ display: "none" }}
                disabled={disabled}
                accept={accept?.join(',')}
              />
              {error && (
                <FormHelperText sx={{ color: "#d32f2f", marginLeft: "14px" }}>
                  {t(error?.message ?? name, {
                    fieldName: title ? title?.toLocaleLowerCase() : "",
                  })}
                </FormHelperText>
              )}
            </>
          )
        }}
      />
      <ModalCommon
        isHeader={false}
        containerProps={{
          sx: {
            maxHeight: "90%",
            overflow: "hidden",
            padding: 1,
            borderRadius: "4px",
          },
        }}
        open={!!previewFile}
        onClose={() => setPreviewFile(null)}
        allowClickOutside
      >
        <Box sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
          <Box
            sx={{
              backgroundColor: "white",
              display: "flex",
              flexDirection: "row-reverse",
              mb: 0.5,
            }}
          >
            <IconButton size="small" onClick={() => setPreviewFile(null)}>
              <CloseRoundedIcon />
            </IconButton>
          </Box>
          <Box
            sx={{
              width: "max-content",
              minWidth: "500px",
              maxWidth: "700px",
              maxHeight: "80vh",
              overflowY: "auto",
            }}
          >
            <img
              src={previewFile?.path ?? ""}
              alt=""
              loading="lazy"
              style={{ objectFit: "cover", height: "auto", width: "100%" }}
            // onError={() => setHideImage(true)}
            />
          </Box>
        </Box>
      </ModalCommon>

      <ConfirmPopup {...confirmPopupState} />
      {warningPopupState?.open && <ErrorPopup {...warningPopupState} />}
      
    </Box >
  );
};

export default DropPreviewFileUploadComponent;

type ImageProps = {
  src: string;
};

const ImageComponent = ({ src }: ImageProps) => {
  const [hideImage, setHideImage] = useState(false);
  return (
    <img
      alt={""}
      src={src}
      loading="lazy"
      style={{
        opacity: hideImage ? 0 : 1,
        objectFit: "cover",
        height: "100%",
        width: "100%",
      }}
      onError={() => setHideImage(true)}
    />
  );
};
