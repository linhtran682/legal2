import { COLOR_TYPE } from "@/constants/color";
import {
  Box,
  Stack,
  Typography
} from "@mui/material";
import { useTranslation } from "react-i18next";
// import Image from "next/image";

interface Props {
  type: 'circle' | 'square' | 'text';
  purpose: string;
}

export const RedItalicLabel = ({ type, purpose }: Props) => {
  const { t } = useTranslation();
  return (
    <>
      <Typography sx={{ fontSize: '12px', fontStyle: 'italic', color: COLOR_TYPE.TOYOTA.TOYOTA1, whiteSpace: 'nowrap' }}>
        ({t(`DOCUMENT_REVIEW.labels.select`)}</Typography>
      <Box sx={{ width: 14, height: 14, borderRadius: type === 'circle' ? '100px' : "4px", border: `1px solid ${COLOR_TYPE.TOYOTA.TOYOTA1}` }} />
      <Typography sx={{ fontSize: '12px', fontStyle: 'italic', color: COLOR_TYPE.TOYOTA.TOYOTA1, whiteSpace: 'nowrap' }}>
        {t(purpose)})
      </Typography>
    </>
  );
};
export const ListItemLabel = ({ type, purpose }: Props) => {
  const { t } = useTranslation();
  return (
    <Stack direction={'row'} alignItems={'center'} gap={0.5} width={"100%"}>
      <Box sx={{ m: 0.5, width: 2, height: 2, borderRadius: '100px', backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1 }} />
      {
        type === 'text' ?
          <Typography sx={{ fontSize: '14px', flex: 1, color: COLOR_TYPE.TOYOTA.TOYOTA1, fontStyle: 'italic' }}>
            {purpose}
          </Typography>
          : <>
            <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA1, whiteSpace: 'nowrap', fontStyle: 'italic' }}>
              {t(`DOCUMENT_REVIEW.labels.select`)}</Typography>
            <Box sx={{ width: 16, height: 16, borderRadius: type === 'circle' ? '100px' : "4px", border: `1.5px solid ${COLOR_TYPE.TOYOTA.TOYOTA1}` }} />
            <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA1, whiteSpace: 'nowrap', fontStyle: 'italic' }}>
              {t(purpose)}
            </Typography>
          </>}
    </Stack>
  );
};
