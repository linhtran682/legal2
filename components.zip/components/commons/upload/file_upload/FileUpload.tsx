import React, { ChangeEvent } from "react";
import {
  FormControl,
  InputLabel,
  IconButton,
  Chip,
  Box,
  Grid,
  Radio,
  FormHelperText,
} from "@mui/material";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import { COLOR_TYPE } from "@/constants/color";
import { IconAdd } from "@/assets/images/icons/iconAdd";
import { Controller } from "react-hook-form";
import { useTranslation } from "react-i18next";
// import { useTranslation } from "react-i18next";

export interface FileDetails {
  id?: number;
  name: string;
  file?: File;
  path?: string;
  uploadDate?: string;
  accessLink?: string;
  isEvaluateFile?: boolean;
}
interface FileUploadComponentProps {
  name?: string;
  control?: any;
  files: FileDetails[];
  setFiles: (files: FileDetails[]) => void;
  disabled?: boolean;
  title?: string;
  inputId?: string;
  setSelectedName?: (name: string) => void;
  selectionName?: string;
  isSharepoint?: boolean;
  accept?: string;
  required?: boolean;
}

const FileUploadComponent: React.FC<FileUploadComponentProps> = ({
  name = "files",
  control,
  files,
  setFiles,
  disabled,
  title,
  inputId,
  setSelectedName,
  selectionName,
  isSharepoint,
  accept = ".xlsx,.doc,.pdf,.ppt,.jpeg,.jpg,.docx,.pptx",
  required,
}) => {
  const { t } = useTranslation();

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const newFiles = event.target.files;
    if (newFiles) {
      const newFileDetails = Array.from(newFiles).map((file) => ({
        name: file.name,
        file,
      }));
      setFiles([...files, ...newFileDetails]);
    }
  };

  const handleButtonClick = () => {
    document.getElementById(inputId ?? "file-input")?.click();
  };

  const handleDelete = (fileName: string) => {
    setFiles(files.filter((file) => file.name !== fileName));
  };
  // const [selectedFile, setSelectedFile] = useState(null);

  const handleRadioChange = (fileName: string) => {
    // setSelectedFile(fileName);
    setSelectedName && fileName && setSelectedName(fileName);
  };
  return (
    <Box sx={{ width: "100%" }}>
      {title && (
        <FormControl fullWidth>
          <InputLabel required={required} htmlFor={inputId ?? "file-input"}>
            {title}
          </InputLabel>
        </FormControl>
      )}
      <Grid container alignItems="center" spacing={1}>
        <Grid item xs>
          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
              marginTop: "8px",
            }}
          >
            {files.map((file, index) => (
              <div key={index}>
                <Chip
                  key={file.name}
                  icon={
                    <AttachFileIcon
                      style={{
                        color: COLOR_TYPE.TOYOTA.TOYOTA1,
                        transform: "rotate(45deg)",
                      }}
                    />
                  }
                  label={file.name} // Ensure the name is displayed correctly
                  onDelete={
                    disabled ? undefined : () => handleDelete(file.name)
                  }
                  style={{ margin: "4px" }}
                  onClick={() => {
                    if (file.accessLink) {
                      window.open(file.accessLink, "_blank");
                    }
                    if (file.path) {
                      window.open(file.path, "_blank");
                    }
                  }}
                />
                {isSharepoint && (
                  <Radio
                    onChange={() => handleRadioChange(file.name)}
                    checked={selectionName === file.name}
                    value={file.name}
                    name="file-radio-group"
                    disabled={disabled}
                  />
                )}
                {/* {file.isEvaluateFile && (
                  <Radio
                    checked={true}
                    value={file.name}
                    name="file-radio-group"
                  />
                )} */}
              </div>
            ))}
          </Box>
        </Grid>
        <Grid item>
          {!disabled && (
            <IconButton color="error" onClick={handleButtonClick}>
              <IconAdd />
            </IconButton>
          )}
        </Grid>
      </Grid>
      <Controller
        name={name}
        control={control}
        render={({ field: { onChange }, fieldState: { error } }) => (
          <>
            <input
              id={inputId ?? "file-input"}
              type="file"
              multiple
              onChange={(e) => {
                onChange(e.target.files);
                handleFileChange(e);
              }}
              style={{ display: "none" }}
              disabled={disabled}
              accept={accept}
            />
            {error && (
              <FormHelperText sx={{ color: "#d32f2f", marginLeft: "14px" }}>
                {t(error?.message ?? name, {
                  fieldName: title ? title?.toLocaleLowerCase() : "",
                })}
              </FormHelperText>
            )}
          </>
        )}
      />
    </Box>
  );
};

export default FileUploadComponent;
