export const fileIconButtonSx = {
  width: "32px",
  height: "32px",
  position: "absolute",
  bottom: 0,
  zIndex: 1,
};

export const radioOutlineSx = {
  width: 20,
  height: 20,
  borderRadius: "30px",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
};
export const fileItemSx = {
  width: "100px",
  height: "100px",
  border: "1px solid #00000030",
  borderRadius: "10px",
  m: 0.75,
  position: "relative",
  overflow: "hidden",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  backgroundColor: "white",
};
export const dropInstructionSx = {
  width: "100%",
  height: "100%",
  zIndex: 2,
  position: "absolute",
  backgroundColor: "#FFF5F699",
  border: `solid 1px #FAB2C1`,
  borderRadius: "10px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
};

export const checkBoxWrapperSx = {
  // position: "absolute",
  // top: "6px",
  // right: "6px",
};

export const indexWrapperSx = {
  // position: "absolute",
  // top: "6px",
  // left: "6px",
  width: "1.25rem",
  height: "1.25rem",
  backgroundColor: "black",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: "100px",
  zIndex: 1,
};

export const previewImgWrapperSx = {
  position: "absolute",
  top: "6px",
  left: "6px",
  width: "1rem",
  height: "1rem",
  backgroundColor: "black",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: "100px",
  zIndex: 1,
};

export const addFileButtonSx = {
  m: 0.75,
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  alignItems: "center",
  gap: "8px",
  width: "100px",
  height: "100px",
  border: "1px dashed #00000030",
  borderRadius: "10px",
  "&:hover": {
    border: "1px dashed red",
  },
};
