import { ExcelIcon } from "@/assets/images/icons/iconExcel";
import { ImageIcon } from "@/assets/images/icons/iconImage";
import { PDFIcon } from "@/assets/images/icons/iconPDF";
import { PPTIcon } from "@/assets/images/icons/iconPPT";
import { WordIcon } from "@/assets/images/icons/iconWord";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import ArrowOutwardRoundedIcon from "@mui/icons-material/ArrowOutwardRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import RemoveRedEyeOutlinedIcon from "@mui/icons-material/RemoveRedEyeOutlined";
import {
  Box,
  FormControl,
  Grid,
  IconButton,
  Stack,
  Tooltip,
  Typography,
} from "@mui/material";
// import Image from "next/image";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  fileIconButtonSx,
  fileItemSx,
  indexWrapperSx,
} from "./styles";
import { ModalCommon } from "../popups/modal/Modal";


interface FileDetails {
  id?: number;
  name: string;
  file?: File;
  path?: string;
  uploadDate?: string;
  accessLink?: string;
  sharePointLink?: string;
  isEvaluateFile?: boolean;
}

interface FileUploadComponentProps {
  files: FileDetails[];
  disabled?: boolean;
  title?: string;
  inputId?: string;

  required?: boolean;
  dropView?: boolean;
  preview?: boolean;

  onItemCheck?: (item: any) => void;
}

const IMAGE_TYPES = [".jpeg", ".jpg", ".png"];

export const isImage = (file: any) => {
  return IMAGE_TYPES?.includes(`.${getFileExtension(file?.name)}`);
};

// const FILE_TYPE = "pdf, xlsx, ppt, pptx, doc, docx, png, jpeg, jpg";

export const getFileExtension = (fileName: string) => {
  const lastDotIndex = fileName?.lastIndexOf(".");
  if (lastDotIndex === -1 || lastDotIndex === 0) {
    return "";
  }
  return fileName?.substring?.(lastDotIndex + 1)?.toLowerCase?.();
};

export const getFileIcon = (fileExtension: string) => {
  if (fileExtension == "pdf") {
    return <PDFIcon />;
  }
  if (["docx", "doc"].includes(fileExtension)) {
    return <WordIcon />;
  }
  if (["xlsx", "xls"].includes(fileExtension)) {
    return <ExcelIcon />;
  }
  if (["ppt", "pptx"].includes(fileExtension)) {
    return <PPTIcon />;
  }
  return <ImageIcon />;
};

const PreviewFiles: React.FC<FileUploadComponentProps> = ({
  files,
  disabled,
  title,
  inputId,
  required,
  dropView,
}) => {
  const { t } = useTranslation();
  const [previewFile, setPreviewFile] = useState<FileDetails | null>(null);

  const onDownloadClick = (e: any, file: any) => {
    e.stopPropagation();
    const a = document.createElement("a");
    a.href = file?.path ?? file?.accessLink;
    a.download = file.name;
    a.click();
  };
  const onViewClick = async (e: any, file: any) => {
    e.stopPropagation();
    setPreviewFile(file);
  };
  const onOpenAccessLinkClick = async (e: any, file: any) => {
    e.stopPropagation();
    if (file?.accessLink) {
      window.open(file.accessLink, "_blank");
    } else if (file?.sharePointLink) {
      window.open(file.sharePointLink, "_blank");
    }
  };

  return (
    <Box sx={{ width: "100%" }}>
      {title && (
        <FormControl fullWidth>
          <Stack width={'100%'} direction={'row'} alignItems={'center'} gap={0.5}>
            <label>
              {title}
              {required && <span style={{ color: "red" }}>*</span>}
            </label>
          </Stack>
        </FormControl>
      )}
      {
        dropView && !disabled && !files?.length ? (
          <Grid item width={"100%"}>
            <label htmlFor={inputId ?? "file-input"}>
              <Grid
                container
                className="upload-area"
                direction={"column"}
                justifyContent={"center"}
                alignItems={"center"}
                sx={{
                  backgroundColor: "#FFF5F6",
                  border: `solid 1px #FAB2C1`,
                  borderRadius: "10px",
                  cursor: "pointer",
                  minHeight: "110px",
                }}
                padding={GLOBAL_SMALL_SPACING}
                rowGap={GLOBAL_SMALL_SPACING}
              >
                
                  <>
                    <Grid item className="upload-icon">
                      <label
                        htmlFor="file-upload"
                        style={{
                          cursor: "pointer",
                        }}
                      >
                        <CloudUploadIcon
                          fontSize="large"
                          color="primary"
                          sx={{ opacity: 1 }}
                        />
                      </label>
                    </Grid>
                    <Grid item className="upload-input">
                      <Typography variant="body2">
                        {t("common.upload.title_drop_or")}{" "}
                        <label
                          htmlFor={inputId ?? "file-input"}
                          style={{
                            fontWeight: "bold",
                            color: COLOR_TYPE.TOYOTA.TOYOTA1,
                            cursor: "pointer",
                          }}
                        >
                          {t("common.upload.title_choose_file")}
                        </label>{" "}
                        {t("common.upload.title_to_upload")}
                      </Typography>
                    </Grid>
                  </>
               
              </Grid>
            </label>
          </Grid>
        ) : null
      }

      <Grid
        container
        sx={{
          position: "relative",
        }}
        alignItems="flex-start"
      >
        <Grid item xs>
          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
            }}
          >
            {files.map((file, index) => (
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "column",
                }}
                key={index}
              >
                <Tooltip title={file.name}>
                  <Box
                    sx={{
                      ...fileItemSx,
                    }}
                  >
                    <Stack
                      direction={'row'}
                      justifyContent={'space-between'}
                      width={'100%'}
                      sx={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        p: '6px'
                      }}>
                      <Box sx={indexWrapperSx}>
                        <Typography
                          sx={{
                            fontSize: "12px",
                            color: "white",
                            fontWeight: "600",
                          }}
                        >
                          {index + 1}
                        </Typography>
                      </Box>
                    </Stack>

                    {isImage(file) ? (
                      <ImageComponent src={(file?.path ?? "") as string} />
                    ) : (
                      getFileIcon(getFileExtension(file.name))
                    )}

                    <IconButton
                      onClick={(e) => onDownloadClick(e, file)}
                      sx={{ ...fileIconButtonSx, right: 0 }}
                    >
                      <FileDownloadOutlinedIcon fontSize="small" />
                    </IconButton>
                    {isImage(file) ? (
                      <IconButton
                        onClick={(e) => onViewClick(e, file)}
                        sx={{ ...fileIconButtonSx, left: "32px" }}
                      >
                        <RemoveRedEyeOutlinedIcon fontSize="small" />
                      </IconButton>
                    ) : null}
                    {(!!file?.accessLink || !!file?.sharePointLink) ? (
                      <IconButton
                        onClick={(e) => onOpenAccessLinkClick(e, file)}
                        sx={{ ...fileIconButtonSx, left: "32px" }}
                      >
                        <ArrowOutwardRoundedIcon fontSize="small" />
                      </IconButton>
                    ) : null}

                  </Box>
                </Tooltip>
              </Box>
            ))}
          </Box>
        </Grid>
      </Grid>
      <ModalCommon
        isHeader={false}
        containerProps={{
          sx: {
            maxHeight: "90%",
            overflow: "hidden",
            padding: 1,
            borderRadius: "4px",
          },
        }}
        open={!!previewFile}
        onClose={() => setPreviewFile(null)}
        allowClickOutside
      >
        <Box sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
          <Box
            sx={{
              backgroundColor: "white",
              display: "flex",
              flexDirection: "row-reverse",
              mb: 0.5,
            }}
          >
            <IconButton size="small" onClick={() => setPreviewFile(null)}>
              <CloseRoundedIcon />
            </IconButton>
          </Box>
          <Box
            sx={{
              width: "max-content",
              minWidth: "500px",
              maxWidth: "700px",
              maxHeight: "80vh",
              overflowY: "auto",
            }}
          >
            <img
              src={previewFile?.path ?? ""}
              alt=""
              loading="lazy"
              style={{ objectFit: "cover", height: "auto", width: "100%" }}
            // onError={() => setHideImage(true)}
            />
          </Box>
        </Box>
      </ModalCommon>
    </Box >
  );
};

export default PreviewFiles;

type ImageProps = {
  src: string;
};

const ImageComponent = ({ src }: ImageProps) => {
  const [hideImage, setHideImage] = useState(false);
  return (
    <img
      alt={""}
      src={src}
      loading="lazy"
      style={{
        opacity: hideImage ? 0 : 1,
        objectFit: "cover",
        height: "100%",
        width: "100%",
      }}
      onError={() => setHideImage(true)}
    />
  );
};
