import { GLOBAL_SPACING } from "@/constants/format";
import { Button, Dialog, Grid, Typography } from "@mui/material";
import { ReactNode } from "react";
import { useTranslation } from "react-i18next";

export interface ConfirmPopupProps {
  icon: ReactNode;
  title?: string;
  open: boolean;
  handleCancel: () => void;
  handleConfirm?: () => void;
  loading?:boolean
}

export const DefaultConfirmPopupState: ConfirmPopupProps = {
  open: false,
  handleConfirm: () => {},
  handleCancel: () => {},
  icon: <></>,
  title: "",
};

export const ConfirmPopup = (props: ConfirmPopupProps) => {
  const [t] = useTranslation();
  return (
    <Dialog open={props.open}>
      <Grid
        container
        direction={"column"}
        alignItems={"center"}
        spacing={GLOBAL_SPACING}
        padding={"2rem"}
      >
        <Grid item>{props.icon}</Grid>
        <Grid item>
          <Typography variant='h5'>{props.title}</Typography>
        </Grid>
        <Grid item width={"100%"}>
          <Grid
            container
            direction={"row"}
            spacing={GLOBAL_SPACING}
            justifyContent={"center"}
          >
            <Grid item flex={1}>
              <Button
                variant='contained'
                color='primary'
                className='cancel'
                onClick={props.handleCancel}
                fullWidth
              >
                {t("common.button.cancel")}
              </Button>
            </Grid>
            <Grid item flex={1}>
              <Button
                onClick={props.handleConfirm}
                variant='contained'
                className='confirm'
                fullWidth
                disabled={props.loading}
              >
                {t("common.button.confirm")}
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Dialog>
  );
};
