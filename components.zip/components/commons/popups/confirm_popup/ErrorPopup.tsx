import { ReactNode } from "react";
import { GLOBAL_SPACING } from "@/constants/format";
import { Button, Dialog, Grid, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";

export interface ErrorPopupProps {
  open?: boolean;
  icon?: ReactNode;
  title?: string;
  textCancel?: string;
  onClose?: () => void;
}
export const ErrorPopup = (props: ErrorPopupProps) => {
  const {
    icon,
    textCancel = "common.button.close",
    title = "common.message.error_module",
    onClose,
  } = props;
  const [t] = useTranslation();
  return (
    <Dialog open>
      <Grid
        container
        direction={"column"}
        alignItems={"center"}
        spacing={GLOBAL_SPACING}
        padding={"2rem"}
        borderRadius={"5px"}
      >
        {icon && <Grid item>{icon}</Grid>}
        <Grid item>
          <Typography variant="h5">{t(title)}</Typography>
        </Grid>
        <Grid item width={"100%"}>
          <Grid
            container
            direction={"row"}
            spacing={GLOBAL_SPACING}
            justifyContent={"center"}
          >
            <Grid item flex={1}>
              <Button
                variant="contained"
                color="primary"
                className="cancel"
                onClick={onClose}
                fullWidth
              >
                {t(textCancel)}
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Dialog>
  );
};
