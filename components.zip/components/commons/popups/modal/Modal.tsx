import { IconClose } from "@/assets/iconMenu/iconClose";
import {
  Box,
  IconButton,
  styled,
  Typography,
  Modal,
  ModalProps,
  BoxProps,
} from "@mui/material";
import React, { ReactElement } from "react";

const ModalSC = styled(Modal)(({ theme }) => ({
  "& .MuiDialog-paper": {
    minWidth: theme.spacing(50),
  },
}));

const ContainerSC = styled(Box)(({ theme }) => ({
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "fit-content",
  background: theme.palette.background.default,
  padding: theme.spacing(4),
  paddingBottom: theme.spacing(6),
  borderRadius: theme.spacing(2),
}));

export type ModalCommonProps = ModalProps & {
  titleSize?: number;
  title?: string | number | ReactElement;
  onClose: () => void;
  children: React.ReactNode;
  headerProps?: BoxProps;
  containerProps?: BoxProps;
  isHeader?: boolean;
  allowClickOutside?: boolean;
};

export const ModalCommon = ({
  children,
  title,
  titleSize = 24,
  onClose,
  isHeader = true,
  headerProps = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },
  containerProps = {
    sx: {
      width: "80%",
      height: "fit-content",
      maxHeight: "90%",
      overflow: "hidden",
      maxWidth: {
        md: "900px"
      },
      borderRadius: "8px"
    },
  },
  allowClickOutside = false,
  ...modalProps
}: ModalCommonProps) => {
  return (
    <ModalSC
      onClose={allowClickOutside ? onClose : undefined}
      {...modalProps}>
      <ContainerSC {...containerProps}>
        {isHeader && (
          <Box {...headerProps}>
            <Typography
              variant="h2"
              fontWeight="bold"
              fontSize={titleSize}
              color="rgba(26, 28, 33, 1)"
            >
              {title}
            </Typography>
            <IconButton
              sx={{ position: "absolute", right: 5 }}
              onClick={onClose}
            >
              <IconClose />
            </IconButton>
          </Box>
        )}
        <div style={{ maxHeight: "75vh", overflowY: "auto" }}>{children}</div>
      </ContainerSC>
    </ModalSC>
  );
};
