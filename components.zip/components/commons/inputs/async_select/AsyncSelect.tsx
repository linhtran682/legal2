/* eslint-disable @typescript-eslint/no-explicit-any */
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { mergeArraysByKey } from "@/utils";
import { Autocomplete, CircularProgress, TextField } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import {
  ForwardedRef,
  forwardRef,
  Fragment,
  HTMLAttributes,
  ReactNode,
  useEffect,
  useRef,
  useState,
} from "react";
import { toast } from "react-toastify";

export interface AsyncSelectProps<T> {
  label?: ReactNode;
  keyQuery: string;
  getOptions: (keyword: string | string[]) => Promise<T[]>;
  getOptionLabel: (option: T) => string;
  getOptionKey: (option: T) => string;
  initialValue?: T;
  value?: string;
  onChange?: (selectedOptionKey: string | undefined, option?: T | null) => void;
  placeholder?: string;
  variant?: "standard" | "filled" | "outlined";
  shrink?: boolean;
  minCharLength?: number;
  debounceMs?: number;
  fullWidth?: boolean;
  disabled?: boolean;
  onBlur?: () => void;
  error?: boolean;
  helperText?: string;
  size?: "small" | "medium";
  required?: boolean;
  groupBy?: (option: T) => string;
  isOptionEqualToValue?: (option: T, value: T) => boolean;
  isFocus?: boolean;
  noShowErrorNotification?: boolean;
  renderOption?: (
    optionProps: HTMLAttributes<HTMLLIElement> & {
      key: any;
    },
    option: T,
    selected: boolean) => ReactNode;
}

export const AsyncSelect = forwardRef(function AsyncSelect<T>(
  props: Readonly<AsyncSelectProps<T>>,
  ref: ForwardedRef<any>
) {
  const [keyword, setKeyword] = useState<string>("");
  const [options, setOptions] = useState<T[]>([]);
  const [selectedOption, setSelectedOption] = useState<T | null>(
    () => props.initialValue ?? null
  );
  const debounceTimeout = useRef<NodeJS.Timeout>();

  const getOptionsQuery = useQuery({
    enabled: false,
    queryKey: [props.keyQuery, "suggestion"],
    queryFn: () => props.getOptions(
      (!!keyword && !!selectedOption && isSameKeyword(keyword, props?.getOptionLabel(selectedOption)))
        ? ''
        : keyword
    )
  });

  const getSelectedOptionQuery = useQuery({
    enabled: false,
    queryKey: [props.keyQuery],
    queryFn: () => props.getOptions([props.value!]),
  });

  useEffect(() => {
    return () => {
      clearTimeout(debounceTimeout.current);
    };
  }, []);

  useEffect(() => {
    props.initialValue && setSelectedOption(props.initialValue);
  }, [props.initialValue]);

  useEffect(() => {
    if (props.value) {
      if (
        selectedOption == null ||
        props.value != props.getOptionKey(selectedOption)
      ) {
        getSelectedOptionQuery.refetch().then((response) => {
          if (response.data && response.data.length == 1) {
            setSelectedOption(response.data[0]);
            setOptions(
              mergeArraysByKey(
                [response.data || [], options],
                props.getOptionKey
              )
            );
          } else {
            !props?.noShowErrorNotification &&
              toast.error(JSON.stringify(response.data));
          }
        });
      }
    } else {
      setSelectedOption(props.initialValue ?? null);
      setOptions(props.initialValue ? [props.initialValue] : []);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.value, props?.noShowErrorNotification]);

  useEffect(() => {
    clearTimeout(debounceTimeout.current);
    debounceTimeout.current = setTimeout(() => {
      if (keyword === "" || keyword.length >= (props.minCharLength ?? 2)) {
        getOptionsQuery
          .refetch()
          .then((response) =>
            setOptions(
              selectedOption
                ? mergeArraysByKey(
                  [[selectedOption], response.data ?? []],
                  props.getOptionKey
                )
                : response.data ?? []
            )
          );
      }
    }, props.debounceMs ?? FILTER_DEBOUNCE_MS);
  }, [keyword, props.debounceMs, selectedOption]);

  const handleChange = (option: T | null) => {
    setSelectedOption(option ?? null);
    props.onChange &&
      props.onChange(
        option == null ? undefined : props.getOptionKey(option),
        option
      );
    // setKeyword("");
  };

  const onfocus = () => {
    // setKeyword("");
    if (props?.isFocus) {
      debounceTimeout.current = setTimeout(() => {
        getOptionsQuery
          .refetch()
          .then((response) =>
            setOptions(
              selectedOption
                ? mergeArraysByKey(
                  [[selectedOption], response.data ?? []],
                  props.getOptionKey
                )
                : response.data ?? []
            )
          );
      }, props.debounceMs ?? FILTER_DEBOUNCE_MS);
    }
  };

  return (
    <Autocomplete
      options={options}
      value={selectedOption}
      onChange={(_, value) => handleChange(value)}
      onBlur={props.onBlur}
      inputValue={keyword}
      onInputChange={(_, newKeyWord) => {
        setKeyword(newKeyWord);
      }}
      filterOptions={(x) => x}
      getOptionLabel={props.getOptionLabel}
      disabled={props.disabled}
      onFocus={onfocus}
      ref={ref}
      renderInput={(params) => (
        <TextField
          {...params}
          className={props.label ? undefined : "no-label"}
          variant={props.variant}
          label={props.label}
          ref={ref}
          placeholder={props.placeholder}
          InputLabelProps={{ shrink: props.shrink }}
          error={props.error}
          helperText={props.helperText}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <Fragment>
                {getOptionsQuery.isFetching ? (
                  <CircularProgress color="inherit" size={20} />
                ) : null}
                {params.InputProps.endAdornment}
              </Fragment>
            ),
          }}
          size={props.size}
          required={props.required}
        />
      )}
      renderOption={(optionProps, option,) => {
        const { key, ...rest } = optionProps;
        return props.renderOption ?
          props?.renderOption?.(optionProps, option, false)
          : (
            <li key={key} {...rest}>
              {props.getOptionLabel(option)}
            </li>
          );
      }}
      loading={getSelectedOptionQuery.isFetching || getOptionsQuery.isFetching}
      fullWidth={props.fullWidth}
      groupBy={props.groupBy}
      isOptionEqualToValue={props.isOptionEqualToValue}
    />
  );
}) as <T>(
  props: Readonly<AsyncSelectProps<T>>,
  ref: ForwardedRef<unknown>
) => JSX.Element;


const isSameKeyword = (keyword: string, selectedLabel: string) => {
  return (keyword)?.trim()
    === (selectedLabel)?.trim()
}
