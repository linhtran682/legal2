import {
  Button,
  Grid,
  InputAdornment,
  Popover,
  TextField,
} from "@mui/material";
import { MouseEvent, useEffect, useState } from "react";
import { DateRange, Range } from "react-date-range";
import DateRangeIcon from "@mui/icons-material/DateRange";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import vi from "date-fns/locale/vi";
import { COLOR_TYPE } from "@/constants/color";
import styles from "./DateRangeInput.module.css";
import { VIVN_DATE_FORMAT, VIVN_INTL_LOCALE } from "@/constants/format";
import { useTranslation } from "react-i18next";
import { LANGUAGES } from "@/locales/config-translation";

export interface DateRangeInputProps {
  label: string;
  value?: Range;
  onChange?: (range: Range) => void;
  placeholder?: string;
  variant?: "standard" | "filled" | "outlined";
  shrink?: boolean;
  helperText?: string;
}

export const DateRangeInput = (props: DateRangeInputProps) => {
  const { t, i18n } = useTranslation();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [dateRange, setDateRange] = useState<Range>({
    startDate: undefined,
    endDate: undefined,
  });

  useEffect(() => {
    setDateRange(
      props.value ?? {
        startDate: undefined,
        endDate: undefined,
      }
    );

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.value]);

  const handleTextFieldClick = (event: MouseEvent<HTMLDivElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleChange = (range: Range) => {
    if (
      range &&
      (range.startDate != dateRange.startDate ||
        range.endDate != dateRange.endDate)
    ) {
      if (!props.value) {
        setDateRange(range);
      }
      props.onChange && props.onChange(range);
    }
  };

  const handleReset = () => {
    handleChange({
      startDate: undefined,
      endDate: undefined,
    });

    handleClose();
  };

  const pickerOpen = Boolean(anchorEl);

  return (
    <>
      <TextField
        label={props.label}
        placeholder={props.placeholder}
        variant={props.variant}
        InputLabelProps={{ shrink: props.shrink }}
        onClick={handleTextFieldClick}
        value={
          dateRange.startDate || dateRange.endDate
            ? [
                dateRange.startDate?.toLocaleDateString(VIVN_INTL_LOCALE),
                dateRange.endDate?.toLocaleDateString(VIVN_INTL_LOCALE),
              ].join(" - ")
            : ""
        }
        InputProps={{
          endAdornment: (
            <InputAdornment position='end'>
              <DateRangeIcon />
            </InputAdornment>
          ),
        }}
        fullWidth
        helperText={props.helperText && t(props.helperText)}
      />
      <Popover
        open={pickerOpen}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
      >
        <DateRange
          className={styles.dateRangeInput}
          ranges={
            dateRange.startDate && dateRange.endDate
              ? [{ ...dateRange, color: COLOR_TYPE.TOYOTA.TOYOTA1 }]
              : [
                  {
                    startDate: new Date(),
                    endDate: new Date(),
                    color: COLOR_TYPE.TOYOTA.TOYOTA1,
                  },
                ]
          }
          onChange={(ranges) => handleChange(ranges.range1)}
          locale={i18n.language == LANGUAGES.VIETNAMESE ? vi : undefined}
          dateDisplayFormat={VIVN_DATE_FORMAT}
        />
        <Grid
          padding={0.5}
          container
          direction='row'
          justifyContent={"end"}
          width={"100%"}
        >
          <Grid item>
            <Button size='small' variant='contained' onClick={handleReset}>
              {t("common.button.reset")}
            </Button>
          </Grid>
        </Grid>
      </Popover>
    </>
  );
};
