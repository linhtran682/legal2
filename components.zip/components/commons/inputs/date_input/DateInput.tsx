import {
  Button,
  Grid,
  InputAdornment,
  Popover,
  TextField,
  Tooltip,
} from "@mui/material";
import { MouseEvent, useEffect, useState } from "react";
import { Calendar } from "react-date-range";
import DateRangeIcon from "@mui/icons-material/DateRange";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import vi from "date-fns/locale/vi";
import { COLOR_TYPE } from "@/constants/color";
import { VIVN_DATE_FORMAT, VIVN_INTL_LOCALE } from "@/constants/format";
import { useTranslation } from "react-i18next";
import { LANGUAGES } from "@/locales/config-translation";
import { Controller, FieldValues, Path } from "react-hook-form";
import HelpIcon from "@mui/icons-material/Help";
import { REGEX_FORMAT_DATE } from "@/constants/regex";
import { isAfter, isBefore, startOfDay } from "date-fns";

export interface DateInputProps<T extends FieldValues> {
  label?: string;
  value?: Date;
  onChange?: (date?: Date) => void;
  placeholder?: string;
  variant?: "standard" | "filled" | "outlined";
  required?: boolean;
  helperText?: string;
  control: any;
  explanation?: string;
  name: Path<T>;
  size?: "medium" | "small";
  disabled?: boolean;
  minDate?: Date | string; // Added
  maxDate?: Date | string; // Added
  shouldRemove?: boolean;
  isVisibleHidden?: boolean;
  watchValue?: boolean;
}

const DateInput = <T extends FieldValues>({
  explanation,
  control,
  name,
  label,
  placeholder,
  variant,
  required,
  helperText,
  onChange,
  size,
  disabled,
  minDate,
  maxDate,
  shouldRemove = false,
  isVisibleHidden = true,
  value,
  watchValue
}: DateInputProps<T>) => {
  const { t, i18n } = useTranslation();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [date, setDate] = useState<string>();
  const handleTextFieldClick = (event: MouseEvent<HTMLDivElement>) => {
    if (disabled) return;
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleReset = () => {
    handleClose();
  };

  useEffect(() => {
    if (!value && watchValue) {
      setDate(undefined)
    }
    if (!!value && watchValue) {
      setDate(value?.toLocaleDateString?.(VIVN_INTL_LOCALE))
    }
  }, [value, watchValue])

  const pickerOpen = Boolean(anchorEl);
  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <Controller
        name={name}
        control={control}
        render={({ field, fieldState: { error } }) => (
          <>
            {label ? (
              <label className={label ?? "no-label"}>
                {label}
                {explanation && (
                  <Tooltip title={explanation} placement="top-start">
                    <HelpIcon fontSize={"small"} />
                  </Tooltip>
                )}
                {required && <span style={{ color: "red" }}>*</span>}
              </label>
            ) : (
              isVisibleHidden ? <div style={{ visibility: 'hidden' }}>empty</div> : null
            )}
            <TextField
              {...field}
              className={label ?? "no-label"}
              // label={
              //   label ? (
              //     <>
              //       {label}
              //       {explanation && (
              //         <Tooltip title={explanation} placement="top-start">
              //           <HelpIcon fontSize={"small"} />
              //         </Tooltip>
              //       )}
              //     </>
              //   ) : undefined
              // }
              placeholder={placeholder}
              variant={variant}
              InputLabelProps={{
                shrink: true,
              }}
              onClick={handleTextFieldClick}
              value={
                date ??
                (field.value
                  ? new Date(field.value).toLocaleDateString(VIVN_INTL_LOCALE)
                  : "")
              }
              onChange={(e) => {
                setDate(e.target.value);
              }}
              onBlur={() => {
                if (pickerOpen) return;
                // if (!date) return;
                const isValidateDateFormat =
                  !!date && REGEX_FORMAT_DATE.test(date);
                if (isValidateDateFormat) {
                  const [day, month, year] = date?.split("/").map(Number);
                  const dateObject = new Date(year, month - 1, day);
                  const isInvalid =
                    shouldRemove &&
                    ((maxDate &&
                      isAfter(
                        startOfDay(dateObject),
                        startOfDay(new Date(maxDate))
                      )) ||
                      (minDate &&
                        isBefore(
                          startOfDay(dateObject),
                          startOfDay(new Date(minDate))
                        )));
                  if (isInvalid) {
                    setDate(undefined);
                    field.onChange(undefined);
                    field.onBlur?.();
                    onChange?.(undefined);
                    return;
                  }
                  field.onChange(dateObject);
                  field?.onBlur();
                  onChange && onChange(dateObject);
                  return;
                }
                setDate(undefined);
                field.onChange(undefined);
                field?.onBlur();
                onChange && onChange(undefined);
              }}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <DateRangeIcon />
                  </InputAdornment>
                ),
              }}
              fullWidth
              required={required}
              helperText={
                error?.message
                  ? t(error.message, { fieldName: label })
                  : helperText
                    ? t(helperText)
                    : undefined
              }
              error={!!error}
              size={size ?? "small"}
              disabled={disabled || field.disabled}
            />
            <Popover
              open={pickerOpen}
              anchorEl={anchorEl}
              onClose={handleClose}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
            >
              <Calendar
                date={field.value ?? new Date()}
                onChange={(date) => {
                  handleClose();
                  field.onChange(date);
                  onChange && onChange(date);
                  field?.onBlur();
                  setDate(date?.toLocaleDateString(VIVN_INTL_LOCALE));
                }}
                locale={i18n.language === LANGUAGES.VIETNAMESE ? vi : undefined}
                color={COLOR_TYPE.TOYOTA.TOYOTA1}
                dateDisplayFormat={VIVN_DATE_FORMAT}
                minDate={minDate ? new Date(minDate) : undefined}
                maxDate={maxDate ? new Date(maxDate) : undefined}
              />
              <Grid
                padding={0.5}
                container
                direction="row"
                justifyContent={"end"}
                width={"100%"}
              >
                <Grid item>
                  <Button
                    size="small"
                    variant="contained"
                    onClick={() => {
                      handleReset();
                      field.onChange(undefined);
                      field?.onBlur();
                      setDate("");
                    }}
                  >
                    {t("common.button.reset")}
                  </Button>
                </Grid>
              </Grid>
            </Popover>
          </>
        )}
      />
    </div>
  );
};

export default DateInput;
