import { Grid, TextField } from "@mui/material";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

export interface NumberRangeInputProps {
  range?: [number | undefined, number | undefined];
  onChange?: (range: [number | undefined, number | undefined]) => void;
  shrink?: boolean;
}

export const NumberRangeInput = (props: NumberRangeInputProps) => {
  const [t] = useTranslation();
  const [range, setRange] = useState<[number | undefined, number | undefined]>([
    undefined,
    undefined,
  ]);

  useEffect(() => {
    setRange(props.range ?? [undefined, undefined]);
  }, [props.range]);

  const handleChangeRange = (
    range: [number | undefined, number | undefined]
  ) => {
    setRange(range);
    if (
      props.onChange &&
      (range[0] == range[1] || (range[0] && range[1] && range[0] > range[1]))
    ) {
      props.onChange(range);
    }
  };

  return (
    <Grid container wrap='nowrap' alignItems={"center"}>
      <Grid item width={"50%"}>
        <TextField
          placeholder={t("common.input.number_range.from")}
          label={t("common.input.number_range.from")}
          variant='standard'
          value={Number(range[0])}
          onChange={(e) =>
            handleChangeRange([
              e.target.value ? Number(e.target.value) : undefined,
              range[1],
            ])
          }
          type='number'
          InputLabelProps={{ shrink: props.shrink }}
        />
      </Grid>
      <Grid item width={"50%"}>
        <TextField
          placeholder={t("common.input.number_range.to")}
          label={t("common.input.number_range.to")}
          variant='standard'
          value={Number(range[1])}
          onChange={(e) =>
            handleChangeRange([
              range[0],
              e.target.value ? Number(e.target.value) : undefined,
            ])
          }
          type='number'
          InputLabelProps={{ shrink: props.shrink }}
        />
      </Grid>
    </Grid>
  );
};
