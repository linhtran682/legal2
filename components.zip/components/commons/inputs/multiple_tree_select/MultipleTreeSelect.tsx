import { Box, Chip, FormControl, InputLabel, Select, Typography } from "@mui/material";
import {
  ReactNode,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import { useQuery } from "@tanstack/react-query";
import { QuickFilter } from "../../tables/multiple_filter_table/multiple_filter_table_bar/quick_filter/QuickFilter";
import { COLOR_TYPE } from "@/constants/color";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import CloseIcon from "@mui/icons-material/Close";

export interface MultipleTreeSelectProps<T> {
  label: ReactNode | string;
  keyQuery: string;
  getOptions: (keyword: string) => Promise<T[]>;
  getOptionChildren: (option: T) => T[] | undefined;
  getOptionLabel: (option: T) => string;
  getOptionKey: (option: T) => string;
  value?: T[];
  onChange?: (selectedOptions: T[]) => void;
  placeholder?: string;
  variant?: "standard" | "filled" | "outlined";
  shrink?: boolean;
  minCharLength?: number;
  debounceMs?: number;
  fullWidth?: boolean;
  disabled?: boolean;
  onBlur?: (e: any) => void;
  error?: boolean;
  helperText?: string;
  size?: "small" | "medium";
  required?: boolean;
}

export const MultipleTreeSelect = <T,>(props: MultipleTreeSelectProps<T>) => {
  const [keyword, setKeyword] = useState<string>("");
  const [options, setOptions] = useState<T[]>([]);
  const [selectedOptions, setSelectedOptions] = useState<T[]>([]);
  const [optionMap] = useState(new Map<string, T>());
  const debounceTimeout = useRef<NodeJS.Timeout>();

  const getOptionsQuery = useQuery({
    enabled: false,
    queryKey: [props.keyQuery, "suggestion"],
    queryFn: () => props.getOptions(keyword),
  });
  useMemo(() => {
    const value = props.value ?? [];
    value.forEach((item) => {
      optionMap.set(props.getOptionKey(item), item);
    });
    setSelectedOptions(value);
    if (props.onChange) {
      props.onChange(value);
    }
    return value;
  }, [props.value]);
  useEffect(() => {
    clearTimeout(debounceTimeout.current);

    debounceTimeout.current = setTimeout(() => {
      if (keyword == "" || keyword.length > (props.minCharLength ?? 2)) {
        getOptionsQuery.refetch().then((response) => {
          setOptions(response.data ?? []);
        });
      }
    }, props.debounceMs ?? FILTER_DEBOUNCE_MS);

    return () => {
      clearTimeout(debounceTimeout.current);
    };
  }, [keyword]);
  // useEffect(() => {
  // }, [selectedOptions]);
  const [selectedItems, setSelectedItems] = useState<any[]>([]);
  const handleParentCheckboxChange = async (
    parentOption: any,
    checked: boolean
  ) => {
    const children = props.getOptionChildren(parentOption) || [];
    let newSelectedItems: any[];

    if (checked) {
      newSelectedItems = [
        ...selectedItems,
        parentOption,
        ...( children),
      ];
      // newSelectedItems = [...selectedItems, parentOption, ...children];
    } else {
      newSelectedItems = selectedItems.filter(
        (item) =>
          props.getOptionKey(item) !== props.getOptionKey(parentOption) &&
           !children.some(
                (child: T) => props.getOptionKey(child) === props.getOptionKey(item)
              )
        // && !children.some((child) => getOptionKey(child) === getOptionKey(item))
      );
    }
    setSelectedItems(newSelectedItems);
    if (props.onChange) {
      props.onChange(newSelectedItems);
    }
  };
  const renderTreeItem = (option: any) => {
    // const children = props.getOptionChildren(item);

    // optionMap.set(props.getOptionKey(item), item);
    const children = props.getOptionChildren(option) || [];
    const label = props.getOptionLabel(option);
    const isSelected = selectedItems.some(
      (item) => props.getOptionKey(item) === props.getOptionKey(option)
    );
    const isHighlight =
      !!keyword?.trim()?.length &&
      label
        ?.toLocaleLowerCase()
        ?.includes(keyword?.trim()?.toLocaleLowerCase());
    return (
      // <TreeItem
      //   key={props.getOptionKey(item)}
      //   itemId={props.getOptionKey(item)}
      //   label={props.getOptionLabel(item)}
      //   spellCheck
      //   sx={{
      //     "& .MuiTreeItem-iconContainer": { order: 3 },
      //   }}
      // >
      //   {children &&
      //     children.length > 0 &&
      //     children.map((child) => renderTreeItem(child))}
      // </TreeItem>
      <Box sx={{ marginLeft: "24px" }}>
        <label
          style={{ display: "flex", marginBottom: "10px", cursor: "pointer" }}
        >
          <input
            type="checkbox"
            style={{
              transform: "scale(1.23)",
              marginRight: 10,
              accentColor: COLOR_TYPE.TOYOTA.TOYOTA1,
              outlineColor: COLOR_TYPE.TOYOTA.TOYOTA1,
            }}
            checked={isSelected}
            onChange={(event) =>
              handleParentCheckboxChange(option, event.target.checked)
            }
          />
          <Typography
            variant={"body2"}
            sx={{ fontWeight: isHighlight ? "bold" : undefined, color:"rgba(0, 0, 0, 0.87)"}}
            component={"span"}
          >
            {label}
          </Typography>
        </label>
        {children && (
          <div>{children.map((child: any) => renderTreeItem(child))}</div>
        )}
      </Box>
    );
  };


 
  return (
    <FormControl
      fullWidth={props.fullWidth}
      error={props.error}
      disabled={props.disabled}
      variant={props.variant}
    >
      <InputLabel id="demo-multiple-chip-label" shrink={props.shrink}>
        {props.label}
      </InputLabel>
      <Select
        labelId="demo-multiple-chip-label"
        id="demo-multiple-chip"
        multiple
        size={props.size}
        value={selectedOptions}
        onChange={() => true}
        renderValue={(selected) => (
          <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
            {selected.map((value) => (
              <Chip
                sx={{
                  zIndex: 100,
                }}
                key={props.getOptionKey(value)}
                label={props.getOptionLabel(value)}
                size={props.variant == "standard" ? "small" : undefined}
                style={{
                  backgroundColor: "black",
                  color: "white",
                  borderRadius: "4px", // Square shape
                  height: "28px",
                  position: "relative",
                  fontSize: "14px"
                }}
                deleteIcon={
                  <CloseIcon
                    onMouseDown={(event) => event.stopPropagation()}
                    style={{
                      color: "white",
                      fontSize: "18px",
                      marginLeft: 3,
                      marginTop: -9,
                    }}
                  />
                }
                onDelete={() => {
                  !props.onChange
                    ? setSelectedOptions((prevOptions) =>
                        prevOptions.filter(
                          (option) =>
                            props.getOptionKey(option) !==
                            props.getOptionKey(value)
                        )
                      )
                    : props.onChange(
                        selectedOptions.filter(
                          (option) =>
                            props.getOptionKey(option) !==
                            props.getOptionKey(value)
                        )
                      );
                }}
              />
            ))}
          </Box>
        )}
      >
        <div
          style={{
            height: "100%",
            overflow: "auto",
            position: "relative",
          }}
        >
          <div
            style={{
              position: "sticky",
              top: 0,
              zIndex: 100,
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6,
              padding: GLOBAL_SMALL_SPACING,
            }}
          >
            <QuickFilter
              filterOptions={[{ key: "name", label: "name" }]}
              defaultSelectedOptionKey="name"
              placeHolder={(key) => key}
              onChange={(_, searchValue) => setKeyword(searchValue)}
            />
          </div>

          {/* {options.map((item) => (
            <SimpleTreeView
              key={props.getOptionKey(item)}
              checkboxSelection
              multiSelect={true}
              expandedItems={expandedIds}
              sx={{
                "& .Mui-selected": {
                  backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
                  color: COLOR_TYPE.TOYOTA.TOYOTA1,
                },
              }}
              selectedItems={(selectedOptions || []).map((option) =>
                props.getOptionKey(option)
              )}
              onSelectedItemsChange={(_, id) => {
                !props.onChange
                  ? setSelectedOptions(
                      id
                        .map((key) => optionMap.get(key)!)
                        .filter((item) => Boolean(item))
                    )
                  : props.onChange(
                      id
                        .map((key) => optionMap.get(key)!)
                        .filter((item) => Boolean(item))
                    );
              }}
            >
              {renderTreeItem(item)}
            </SimpleTreeView>
          ))} */}
           <Box
                    sx={{
                      flexGrow: 1,
                      overflowY: "auto",
                      maxHeight: 300,
                    }}
                  >
                    {(options ?? []).map((node: any) =>
                      renderTreeItem(node)
                    )}
                  </Box>
        </div>
      </Select>
    </FormControl>
  );
};
