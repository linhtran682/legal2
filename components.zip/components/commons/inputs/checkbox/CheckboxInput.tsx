import React from "react";
import { Checkbox, Typography } from "@mui/material";
import { IconClose } from "@/assets/iconMenu/iconClose";

interface CustomCheckboxProps {
  checked: boolean;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
  label?: string;
  labelColor?: string;
  borderColor?: string;
  checkboxBg?: string;
  labelVariant?: 'body2' | 'subtitle1';
  wraperStyles?: React.CSSProperties;
  size?: number;
  borderWidth?: number;
  fontSize?: string | number;
  onLabelClick?: () => void;
  isSuccess?: boolean
}

const CheckboxInput: React.FC<CustomCheckboxProps> = ({
  checked,
  disabled,
  onChange,
  label,
  labelColor = "#000",
  borderColor,
  checkboxBg,
  labelVariant = 'body2',
  wraperStyles = {},
  size = 20,
  borderWidth = 2,
  fontSize = '0.875rem',
  onLabelClick,
  isSuccess = true
}) => {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        ...wraperStyles,
      }}
    >
      <Checkbox
        icon={
          <span
            style={{
              width: size,
              height: size,
              display: "inline-block",
              backgroundColor: checkboxBg,
              // backgroundColor: "#fff",
              border: `${borderWidth}px solid ${borderColor}`,
              borderRadius: "6px",
            }}
          />
        }
        checkedIcon={
          <span
            style={{
              width: size,
              height: size,
              backgroundColor: `${borderColor}`,
              borderRadius: "6px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {isSuccess ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="white"
                width={`${0.8 * size}px`}
                height={`${0.8 * size}px`}
              >
                <path
                  d="M19.77 5.23c.29.3.29.77 0 1.06l-11 11c-.3.3-.77.3-1.06 0l-5-5c-.29-.3-.29-.77 0-1.06s.77-.29 1.06 0l4.47 4.47 10.47-10.47c.29-.29.77-.29 1.06 0z"
                  stroke="white"
                  strokeWidth={1}
                />
              </svg>
            ) : (
              <IconClose
                width={`${0.8 * size}px`}
                height={`${0.8 * size}px`}
                color="white"
                viewBox="0 0 24 24"
              />
            )}
          </span>
        }
        sx={{
          padding: "0",
        }}
        checked={checked}
        disabled={disabled}
        onChange={(e) => {
          if (onChange) {
            onChange(e.target.checked);
          }
        }}
      />
      {label && (
        <Typography
          onClick={onLabelClick}
          style={{ color: labelColor }}
          sx={{
            fontSize: fontSize,
            lineHeight: "1.25rem",
            cursor: onLabelClick ? "pointer" : "default",
          }}
          variant={labelVariant}
        >
          {label}
        </Typography>
      )}
    </div>
  );
};

export default CheckboxInput;
