import { InputAdornment, SxProps, TextField } from "@mui/material";
import React, { ReactElement } from "react";

interface Props {
  label?: string;
  value?: string | number;
  required?: boolean;
  disabled?: boolean;
  placeholder?: string;
  size?: "small" | "medium";
  sx?: SxProps;
  startIcon?: ReactElement;
  minRows?: number;
  multiline?: boolean;
}
function TextFieldInput({
  label = "",
  placeholder,
  value,
  required,
  disabled,
  size = "small",
  startIcon,
  sx,
  minRows = 1,
  multiline = false,
}: Props) {
  return (
    <>
      <label className={label ?? "no-label"} style={{ display: "flex" }}>
        {label} {required && <span style={{ color: "red" }}>*</span>}
      </label>
      <TextField
        className={label ?? "no-label"}
        fullWidth
        placeholder={placeholder}
        value={value}
        size={size}
        multiline={multiline}
        minRows={minRows}
        // required={required}

        InputProps={{
          sx: {
            "&::placeholder": {
              flex: 1,
              color: "#fff !important",
              fontSize: "0.875rem",
              fontWeight: 500,
            },
          },
          startAdornment: startIcon && (
            <InputAdornment position="start">{startIcon}</InputAdornment>
          ),
        }}
        InputLabelProps={{
          shrink: true,
        }}
        sx={sx}
        disabled={disabled}
      />
    </>
  );
}

export default TextFieldInput;
