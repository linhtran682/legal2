import { LANGUAGES } from '@/locales/config-translation'
import DateRangeIcon from "@mui/icons-material/DateRange"
import HelpIcon from "@mui/icons-material/Help"
import { Button, DialogActions, TextField, Tooltip } from '@mui/material'
import { DateTimePicker, LocalizationProvider, PickersActionBarProps } from '@mui/x-date-pickers'
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFnsV3'
import { format } from 'date-fns'
import vi from "date-fns/locale/vi"
import { useRef } from 'react'
import { Controller, FieldValues, Path } from 'react-hook-form'
import { useTranslation } from 'react-i18next'

export interface DateTimeInputProps<T extends FieldValues> {
  label?: string;
  value?: Date;
  defaultValue?: Date;
  onChange?: (date?: Date | null) => void;
  placeholder?: string;
  placeholderInput?: string;
  variant?: "standard" | "filled" | "outlined";
  required?: boolean;
  helperText?: string;
  control: any;
  explanation?: string;
  name: Path<T>;
  size?: "medium" | "small";
  disabled?: boolean;
  minDate?: Date; // Added
  maxDate?: Date; // Added
}


const DateTimeInput = <T extends FieldValues>(props: DateTimeInputProps<T>) => {
  const { control, name, helperText, label, onChange, disabled, required, placeholder, placeholderInput = "dd/mm/yyyy hh:mm", explanation, minDate } = props;
  const { t, i18n } = useTranslation();
  const openRef = useRef<any>({
    onclick: null
  });
  const openCalendar = (event: any) => {
    if (!disabled) {
      openRef?.current?.onClick?.(event);
    }
  }
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => {
        return (
          <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={vi}>
            <label className={label ?? "no-label"}>
              {label}{" "}
              {explanation && (
                <Tooltip title={explanation} placement="top-start">
                  <HelpIcon fontSize={"small"} />
                </Tooltip>
              )}
              {required && <span style={{ color: "red" }}>*</span>}
            </label>
            {/* <ClickAwayListener onClickAway={() => setVisible(false)} > */}
            <DateTimePicker
              sx={{ width: '100%' }}
              inputRef={field.ref}
              disabled={disabled}
              disableOpenPicker={disabled}
              format='dd/MM/yyyy HH:mm'

              // open={visible}
              // label={label && t(label)}
              dayOfWeekFormatter={(date) => `${format(date, 'EEE', {
                locale: i18n.language === LANGUAGES.VIETNAMESE ? vi : undefined
              })}`}
              ampm={false}
              closeOnSelect={false}
              showDaysOutsideCurrentMonth={true}
              value={field.value}
              timeSteps={{
                hours: 1,
                minutes: 1
              }}
              onChange={(date) => {
                field.onChange(date);
                onChange && onChange(date);
                field.onBlur();
              }}
              slots={{
                openPickerButton: (props: any) => {
                  openRef.current.onClick = props?.onClick;
                  return <DateRangeIcon {...props} />
                },
                textField: TextField,
                actionBar: CustomActionBar,
              }}
              slotProps={{
                actionBar: {
                  actions: ['clear']
                },
                textField: {
                  ...field,
                  required: required,
                  size: 'small',
                  placeholder: placeholderInput,
                  InputLabelProps: {
                    shrink: true
                  },
                  inputProps: {
                    mask: "dd/mm/yyyy hh:mm",
                  },
                  onClick: (e) => openCalendar(e),
                  helperText:
                    error?.message && (helperText || t(error?.message, {
                      fieldName: label ? t(label)?.toLocaleLowerCase()
                        : placeholder?.toLocaleLowerCase() ? t(placeholder)?.toLocaleLowerCase() : "",
                    }))
                  ,
                  error: !!error
                },
              }}
              minDate={minDate}
            />
            {/* </ClickAwayListener> */}
          </LocalizationProvider>
        )
      }}
    />
  )
}

export default DateTimeInput

function CustomActionBar(props: PickersActionBarProps) {
  const { onClear, className } = props;
  const { t } = useTranslation();

  return (
    <DialogActions className={className}>
      <Button
        size='small'
        variant='contained'
        onClick={() => {
          onClear()
        }}
      >
        {t("common.button.reset")}
      </Button>
    </DialogActions>
  );
}