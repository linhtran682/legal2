/* eslint-disable @typescript-eslint/no-explicit-any */
import { FILTER_DEBOUNCE_MS } from "@/constants/filter";
import { mergeArraysByKey } from "@/utils";
import { Autocomplete, Chip, CircularProgress, TextField } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import {
  ForwardedRef,
  forwardRef,
  Fragment,
  HTMLAttributes,
  ReactNode,
  useEffect,
  useRef,
  useState,
} from "react";
import CloseIcon from '@mui/icons-material/Close';
export interface MultipleSelectProps<T> {
  label: ReactNode | string;
  keyQuery: string;
  getOptions: (keyword: string) => Promise<T[]>;
  getOptionLabel: (option: T) => string;
  getSelectedOptionLabel?: (option: T) => string;
  getOptionKey: (option: T) => string | number;
  value?: T[];
  onChange?: (selectedOption: T[]) => void;
  placeholder?: string;
  variant?: "standard" | "filled" | "outlined";
  shrink?: boolean;
  minCharLength?: number;
  debounceMs?: number;
  fullWidth?: boolean;
  disabled?: boolean;
  onBlur?: (e: any) => void;
  error?: boolean;
  helperText?: string;
  size?: "small" | "medium";
  required?: boolean;
  isFocus?: boolean;
  disableCloseOnSelect?: boolean;
  showAllSelected?: boolean;
  renderOption?: (
    optionProps: HTMLAttributes<HTMLLIElement> & {
      key: any;
    },
    option: T,
    selected: boolean) => ReactNode;
}

export const MultipleSelect = forwardRef(function MultipleSelect<T>(
  props: Readonly<MultipleSelectProps<T>>,
  ref: ForwardedRef<any>
) {
  const { showAllSelected = true } = props;
  const [keyword, setKeyword] = useState<string>("");
  const [options, setOptions] = useState<T[]>([]);
  const [selectedOptions, setSelectedOptions] = useState<T[]>([]);
  const debounceTimeout = useRef<NodeJS.Timeout>();

  const getOptionsQuery = useQuery({
    enabled: false,
    queryKey: [props.keyQuery, "suggestion"],
    queryFn: () => props.getOptions(keyword),
  });

  useEffect(() => {
    return () => {
      clearTimeout(debounceTimeout.current);
    };
  }, []);

  useEffect(() => {
    if (props.value) {
      setSelectedOptions(props.value);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.value]);

  useEffect(() => {
    clearTimeout(debounceTimeout.current);

    debounceTimeout.current = setTimeout(() => {
      if (keyword.length == 0 || keyword.length >= (props.minCharLength || 2)) {
        getOptionsQuery
          .refetch()
          .then((response) =>
            setOptions(
              mergeArraysByKey(
                [selectedOptions, response.data ?? []],
                props.getOptionKey
              )
            )
          );
      }
    }, props.debounceMs ?? FILTER_DEBOUNCE_MS);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [keyword]);

  const handleChange = (options: T[]) => {
    options = mergeArraysByKey([options], props.getOptionKey);

    setSelectedOptions(options);
    props.onChange && props.onChange(options);
  };
  const onFocus = () => {
    if (props.isFocus) {
      debounceTimeout.current = setTimeout(() => {
        if (
          keyword.length == 0 ||
          keyword.length >= (props.minCharLength || 2)
        ) {
          getOptionsQuery
            .refetch()
            .then((response) =>
              setOptions(
                mergeArraysByKey(
                  [selectedOptions, response.data ?? []],
                  props.getOptionKey
                )
              )
            );
        }
      }, props.debounceMs ?? FILTER_DEBOUNCE_MS);
    }
  };
  return (
    <Autocomplete
      multiple
      options={options}
      value={selectedOptions}
      onChange={(_, value) => handleChange(value)}
      onBlur={props.onBlur}
      inputValue={keyword}
      onInputChange={(_, newKeyWord) => setKeyword(newKeyWord)}
      filterOptions={(x) => x}
      getOptionLabel={props.getOptionLabel}
      disabled={props.disabled}
      ref={ref}
      size={props.size}
      onFocus={onFocus}
      disableCloseOnSelect={props?.disableCloseOnSelect}
      renderInput={(params) => (
        <TextField
          {...params}
          variant={props.variant}
          label={props.label}
          ref={ref}
          placeholder={props.placeholder}
          InputLabelProps={{ shrink: props.shrink }}
          error={props.error}
          helperText={props.helperText}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <Fragment>
                {getOptionsQuery.isFetching ? (
                  <CircularProgress color="inherit" size={20} />
                ) : null}
                {params.InputProps.endAdornment}
              </Fragment>
            ),
          }}
          size={props.size}
          required={props.required}
        />
      )}
      isOptionEqualToValue={(option, value: any) => {
        return props.getOptionKey(option) === props.getOptionKey(value);
      }}
      renderOption={(optionProps, option, { selected }) => {
        const { key, ...rest } = optionProps;
        return props.renderOption ?
          props?.renderOption?.(optionProps, option, selected)
          : (
            <li key={key} {...rest}>
              {props.getOptionLabel(option)}
            </li>
          );
      }}
      renderTags={(selected, getTagProps) => {
        const visibleTags = showAllSelected ? selected : selected.slice(0, 3); // Show only the first 3 items
        const remainingTagsCount = selected.length - visibleTags.length;

        return <>{visibleTags.map((option, index) => (
          // eslint-disable-next-line react/jsx-key
          <Chip
            {...getTagProps({ index })}
            label={props?.getSelectedOptionLabel
              ? props.getSelectedOptionLabel(option)
              : props.getOptionLabel(option)}
            style={{
              backgroundColor: "black",
              color: "white",
              borderRadius: "2px", // Square shape
              height: "28px", // Height for square chip
              marginTop: 0,
              marginBottom: 0,
              fontSize: "14px"
            }}
            deleteIcon={
              <CloseIcon style={{ color: "white", fontSize: "18px", marginLeft: 3 }} />
            }
          />

        ))}
          {remainingTagsCount > 0 && (
            <Chip
              key={'others_options'}
              label={`+ ${remainingTagsCount}...`}
              style={{
                backgroundColor: "black",
                color: "white",
                borderRadius: "2px", // Square shape
                height: "28px", // Height for square chip
                marginTop: 0,
                marginBottom: 0,
                fontSize: "14px"
              }}
              sx={{
                whiteSpace: "nowrap",
              }}
            />
          )}
        </>
      }
      }
      loading={getOptionsQuery.isFetching}
      fullWidth={props.fullWidth}
    />
  );
}) as <T>(
  props: Readonly<MultipleSelectProps<T>>,
  ref: ForwardedRef<unknown>
) => JSX.Element;
