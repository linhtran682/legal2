import { getMonthByDate, getMonthRange, getQuarterByDate, getQuarterRange, getWeekByDate, getYearByDate, getYearRange } from '@/utils';
import { Box, Grid } from '@mui/material';
import { useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { FormSelect } from '../form_inputs/FormSelect';
import DateInput from '../inputs/date_input/DateInput';
import { add } from 'date-fns';

const currentYear = new Date().getFullYear();

const ReportTypeSelect = () => {
  const { t } = useTranslation();

  useEffect(() => {
    form?.setValue?.('year', currentYear);
  }, []);

  const form = useFormContext();

  const setFromToFields = (startDate: any, endDate: any) => {
    form.setValue('from', startDate);
    form.setValue('to', endDate);
  }

  const onReportTypeChange = (event: any) => {
    const value = event?.target?.value;
    const today = new Date();
    if (!value) {
      setFromToFields(undefined, undefined)
    }
    if (value === 'week') {
      const { endDate, startDate } = getWeekByDate(today);
      setFromToFields(startDate, endDate)
    }
    if (value === 'month') {
      const { endDate, startDate, month } = getMonthByDate(today);
      form.setValue('month', month)
      setFromToFields(startDate, endDate)
    }
    if (value === 'quarter') {
      const { endDate, startDate, quarter } = getQuarterByDate(today);
      form.setValue('quarter', quarter)
      setFromToFields(startDate, endDate)
    }
    if (value === 'year') {
      const { endDate, startDate, year } = getYearByDate(today);
      form.setValue('year', year)
      setFromToFields(startDate, endDate)
    }
  };

  const onMonthChange = (event: any) => {
    const value = event?.target?.value;
    const year = form.getValues('year');
    const { endDate, startDate } = getMonthRange(value as number, year);
    setFromToFields(startDate, endDate)
  }

  const onQuarterChange = (event: any) => {
    const value = event?.target?.value;
    const year = form.getValues('year');
    const { endDate, startDate } = getQuarterRange(value as number, year);
    setFromToFields(startDate, endDate)
  }

  const onYearChange = (event: any) => {
    const year = event?.target?.value;
    const type = form.getValues('reportType');
    const month = form.getValues('month');
    const quarter = form.getValues('quarter');
    if (type === "month") {
      const { endDate, startDate } = getMonthRange(month as number, year);
      setFromToFields(startDate, endDate)
    }
    if (type === "quarter") {
      const { endDate, startDate } = getQuarterRange(quarter as number, year);
      setFromToFields(startDate, endDate)
    }
    if (type === "year") {
      const { endDate, startDate } = getYearRange(year);
      setFromToFields(startDate, endDate)
    }
  }

  const reportType = form.watch("reportType");

  const onFromDateChange = (date?: Date) => {
    form.setValue('from', date);

    if (reportType === 'week' && date) {
      const toDate = add(date, { days: 6 });
      form.setValue('to', toDate);
    }
  }
  return (
    <>
      <Grid item xs={12} md={6}>
        <FormSelect
          control={form.control}
          name={"reportType"}
          label={t(`report.reportType`)}
          placeHolder={t(`report.reportType`)}
          isClearIcon
          options={
            [
              {
                "value": "week",
              },
              {
                "value": "month",
              },
              {
                "value": "quarter",
              },
              {
                "value": "year",
              }
            ]
          }
          getOptionKey={(option) => option.value}
          getOptionLabel={(option) => t(`report.reportTypes.${option.value}`)}
          onChange={onReportTypeChange}
        />
      </Grid>
      {!reportType || reportType === 'week' ? <Grid item xs={12} display={'flex'} direction={"row"} gap={1} md={6}>
        <Box flex={1}>
          <DateInput
            control={form.control}
            name="from"
            label={t("common.input.number_range.from")}
            placeholder={"dd/mm/yyyy"}
            maxDate={form.watch('to')}
            onChange={onFromDateChange}
            value={form.watch('from')}
            watchValue
            shouldRemove
          />
        </Box>
        <Box flex={1}>
          <DateInput
            control={form.control}
            name="to"
            label={t("common.input.number_range.to")}
            placeholder={"dd/mm/yyyy"}
            minDate={form.watch('from')}
            onChange={(date) => form.setValue('to', date)}
            value={form.watch('to')}
            watchValue
            shouldRemove
          />
        </Box>
      </Grid> : null}
      {(!reportType || reportType === 'week') ? null : <Grid item xs={12} display={'flex'} direction={"row"} gap={1} md={6}>
        {reportType === 'year' ? null : <Box flex={1}>
          {reportType === 'month' ? <FormSelect
            control={form.control}
            name={"month"}
            label={t(`report.reportTypes.month`)}
            placeHolder={t(`report.reportTypes.month`)}
            options={
              Array.from({ length: 12 }).map((_, index) => ({
                value: index + 1
              }))
            }
            getOptionKey={(option) => option.value}
            getOptionLabel={(option) => option.value?.toString()}
            onChange={onMonthChange}

          /> : null}
          {
            reportType === 'quarter' ? <FormSelect
              control={form.control}
              name={"quarter"}
              label={t(`report.reportTypes.quarter`)}
              placeHolder={t(`report.reportTypes.quarter`)}
              options={
                Array.from({ length: 4 }).map((_, index) => ({
                  value: index + 1
                }))
              }
              getOptionKey={(option) => option.value}
              getOptionLabel={(option) => option.value?.toString()}
              onChange={onQuarterChange}
            /> : null
          }
        </Box>}
        <Box flex={1}>
          <FormSelect
            control={form.control}
            name={"year"}
            label={t(`report.reportTypes.year`)}
            placeHolder={t(`report.reportTypes.year`)}
            options={
              Array.from({ length: currentYear - 2019 }, (_, i) => ({ value: currentYear - i }))
            }
            getOptionKey={(option) => option.value}
            getOptionLabel={(option) => option.value?.toString()}
            onChange={onYearChange}
          />
        </Box>
      </Grid>}
    </>
  )
}

export default ReportTypeSelect