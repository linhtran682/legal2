import { Button, Grid } from "@mui/material";
import { useTranslation } from "react-i18next";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "../popups/confirm_popup/ConfirmPopup";
import { useContext, useEffect, useState } from "react";
import { GLOBAL_SPACING } from "@/constants/format";
import { SaveRecordDialogIcon } from "@/assets/images/icons/iconSaveRecordDialog";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import { CreateRecordDialogIcon } from "@/assets/images/icons/iconCreateRecordDialog";
import { FieldValues, useFormContext } from "react-hook-form";
import { AppContext } from "@/context/AppContext";

export interface FormActionButtonsProps<T extends FieldValues> {
  loading?: boolean;
  formMode?: "create" | "update";
  onCancel: () => void;
  cancelConfirm?: boolean;
  onDelete?: () => void;
  onSave: (data: T) => void;
  onSaveDraft?: (data: T) => void;
  allowDraft?: boolean;
  textSave?: string;
  isShowConfirm?: boolean,
  isDisableButonSave?: boolean
  defaultConfirmPopupState?: ConfirmPopupProps;
  textDescription?: string;
}

export function FormActionButtons<T extends FieldValues>(
  props: FormActionButtonsProps<T>
) {
  const { defaultConfirmPopupState = DefaultConfirmPopupState } = props;
  const [t] = useTranslation();
  const formContext = useFormContext<T>();
  const appContext = useContext(AppContext);
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => defaultConfirmPopupState
  );

  useEffect(() => {
    if (defaultConfirmPopupState) {
      setConfirmPopupState(defaultConfirmPopupState)
    }
  }, [defaultConfirmPopupState])

  const handleCancel = () => {
    props.cancelConfirm &&
      setConfirmPopupState({
        open: true,
        handleConfirm: props.onCancel,
        handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
        icon: <SaveRecordDialogIcon />,
        title: t("common.message.confirm_cancel"),
      });

    !props.cancelConfirm && props.onCancel();
  };

  const handleDelete = () => {
    setConfirmPopupState({
      open: true,
      handleConfirm: props.onDelete,
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
      icon: <DeleteRecordDialogIcon />,
      title: t("common.message.confirm_delete"),
    });
  };

  const handleSave = (data: T) => {
    if (props?.isShowConfirm) {
      props.onSave(data);
      return;
    }
    setConfirmPopupState({
      open: true,
      handleConfirm: () => props.onSave(data),
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
      icon:
        props.formMode == "create" ? (
          <CreateRecordDialogIcon />
        ) : (
          <SaveRecordDialogIcon />
        ),
      title: t(
        props.formMode == "create" && props.textDescription == undefined
          ? "common.message.confirm_create"
          : props.formMode == "create" && props.textDescription
            ? props.textDescription
            : "common.message.confirm_update"
      ),
      loading: props.loading
    });
  };

  useEffect(() => {
    if (props.loading) {
      setConfirmPopupState({
        open: false,
        handleConfirm: () => { },
        handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
        icon:
          props.formMode == "create" ? (
            <CreateRecordDialogIcon />
          ) : (
            <SaveRecordDialogIcon />
          ),
        title: t(
          props.formMode == "create" && props.textDescription == undefined
            ? "common.message.confirm_create"
            : props.formMode == "create" && props.textDescription
              ? props.textDescription
              : "common.message.confirm_update"
        ),
        loading: true
      });
    }
  }, [props.loading])
  const handleSaveDraft = (data: T) => {
    setConfirmPopupState({
      open: true,
      handleConfirm: () => props?.onSaveDraft?.(data),
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
      icon:
        props.formMode == "create" ? (
          <CreateRecordDialogIcon />
        ) : (
          <SaveRecordDialogIcon />
        ),
      title: t(
        props.formMode == "create"
          ? "common.message.confirm_create_draft"
          : "common.message.confirm_update"
      ),
    });
  };
  const styleBtn = { minWidth: "168px" };

  return (
    <>
      {appContext.meCanWrite && (
        <Grid
          container
          justifyContent={"end"}
          style={{ position: 'fixed', bottom: 0 }}
        >
          <Grid item style={{ position: "sticky", right: 0 }}>
            <Grid container padding={'6px 30px'} spacing={GLOBAL_SPACING}>
              <Grid item>
                <Button
                  onClick={handleCancel}
                  variant="contained"
                  color="primary"
                  className="cancel"
                  disabled={props.loading}
                  sx={styleBtn}
                >
                  {t("common.button.cancel")}
                </Button>
              </Grid>

              {props.formMode == "update" && props.onDelete && (
                <Grid item>
                  <Button
                    onClick={handleDelete}
                    disabled={props.loading || props.isDisableButonSave}
                    variant="contained"
                    color="primary"
                    className="delete"
                    sx={styleBtn}
                  >
                    {t("common.button.delete")}
                  </Button>
                </Grid>
              )}

              {props?.allowDraft ? (
                <Grid item>
                  <Button
                    onClick={formContext.handleSubmit((data) =>
                      handleSaveDraft(data)
                    )}
                    variant="contained"
                    disabled={props.loading}
                    className="saveDraft"
                    sx={styleBtn}
                  >
                    {t("common.button.saveDraft")}
                  </Button>
                </Grid>
              ) : null}
              <Grid item>
                <Button
                  onClick={formContext.handleSubmit((data) => handleSave(data))}
                  variant="contained"
                  disabled={props.loading || props.isDisableButonSave}
                  className="confirm"
                  sx={styleBtn}
                >
                  {t(props?.textSave ?? "common.button.save")}
                </Button>
              </Grid>
            </Grid>
          </Grid>
          <ConfirmPopup {...confirmPopupState} />
        </Grid>
      )}
    </>
  );
}
