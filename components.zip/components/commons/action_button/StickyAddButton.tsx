import { SpeedDial, SpeedDialProps, Typography } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { COLOR_TYPE } from "@/constants/color";
import { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import { AppContext } from "@/context/AppContext";

export interface StickyAddButtonProps extends SpeedDialProps {}

export const StickyAddButton = (props: StickyAddButtonProps) => {
  const appContext = useContext(AppContext);
  const [t] = useTranslation();
  const [showTitle, setShowTitle] = useState(false);
  return (
    <>
      {appContext.meCanWrite && (
        <>
          <SpeedDial
            {...props}
            ariaLabel="add_document_type"
            sx={{
              position: "absolute",
              bottom: "4rem",
              right: "2rem",
              "& .MuiButtonBase-root:hover": {
                backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
              },
            }}
            color={COLOR_TYPE.TOYOTA.TOYOTA1}
            icon={<AddIcon />}
            onMouseEnter={() => setShowTitle(true)}
            onMouseLeave={() => setShowTitle(false)}
          />
          {showTitle && (
            <Typography
              variant="h5"
              sx={{
                position: "absolute",
                bottom: "8rem",
                right: "1.5rem",
              }}
              color={COLOR_TYPE.TOYOTA.TOYOTA1}
            >
              {t("common.button.create")}
            </Typography>
          )}
        </>
      )}
    </>
  );
};
