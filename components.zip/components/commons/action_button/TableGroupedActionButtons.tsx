import { Grid, IconButton } from "@mui/material";
import { useTranslation } from "react-i18next";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "../popups/confirm_popup/ConfirmPopup";
import { useState } from "react";
import { GLOBAL_SMALL_SPACING } from "@/constants/format";
import { DeleteRecordDialogIcon } from "@/assets/images/icons/iconDeleteRecordDialog";
import DeleteIcon from "@mui/icons-material/Delete";
import { GridRowSelectionModel } from "@mui/x-data-grid";

export interface TableGroupedActionButtonsProps {
  loading?: boolean;
  selectModel: GridRowSelectionModel;
  onDelete?: (selectedModel: number[]) => void;
}

export const TableGroupedActionButtons = (
  props: TableGroupedActionButtonsProps
) => {
  const [t] = useTranslation();
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const handleDelete = () => {
    setConfirmPopupState({
      open: true,
      handleConfirm: () =>
        props.onDelete && props.onDelete(props.selectModel as number[]),
      handleCancel: () => setConfirmPopupState(DefaultConfirmPopupState),
      icon: <DeleteRecordDialogIcon />,
      title: t("common.message.confirm_delete_many", {
        quantity: props.selectModel.length,
      }),
    });
  };

  return (
    <>
      <Grid
        container
        direction={"row"}
        columnGap={GLOBAL_SMALL_SPACING}
        alignItems={"center"}
      >
        <Grid item>
          <IconButton
            onClick={handleDelete}
            disabled={props.loading}
            style={{ padding: 0 }}
          >
            <DeleteIcon fontSize='small' />
          </IconButton>
        </Grid>
      </Grid>

      <ConfirmPopup {...confirmPopupState} />
    </>
  );
};
