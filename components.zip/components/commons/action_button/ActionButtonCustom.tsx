import { Box, SpeedDial, SpeedDialAction } from "@mui/material";
import WidgetsIcon from "@mui/icons-material/Widgets";
import { ReactElement, ReactNode, useContext, useState } from "react";
import { GridRenderCellParams } from "@mui/x-data-grid";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "../popups/confirm_popup/ConfirmPopup";
import { AppContext } from "@/context/AppContext";
import { TypeActionsRole } from "@/models/law_document/LawDocument";
import { COLOR_TYPE } from "@/constants/color";

export interface ActionButtonItem {
  key: string;
  icon: ReactElement | string;
  iconDisable?: ReactElement | string;
  tooltipTitle: string;
  onClick?: (param?: any) => void;
  confirmPopupProps?: {
    icon: ReactNode;
    title: string;
  };
  children?: any;
  styleBtn?: any;
  disable?: boolean;
  secondaryBtn?: number;
  textBtn?: string;
  isSecondaryBtn?: boolean;
  order?: number;
}

export interface ActionButtonProps {
  params: GridRenderCellParams | any;
  actionButtonItems: ActionButtonItem[];
  listActions?: TypeActionsRole[];
  isShowHoverAction?: boolean;
}

export const ActionButtonCustom = (props: ActionButtonProps) => {
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const appContext = useContext(AppContext);
  return (
    <Box
      width={"2rem"}
      sx={{
        ...((!props.actionButtonItems?.length ||
          !props?.listActions?.length ||
          !appContext?.meCanWrite) && { display: "none" }),
      }}
    >
      <SpeedDial
        ariaLabel="action-btn"
        icon={
          <WidgetsIcon
            color="primary"
            sx={{ ...(props?.isShowHoverAction && { pointerEvents: "none" }) }}
          />
        }
        direction="left"
        sx={{ overflow: "visible" }}
        openIcon={<WidgetsIcon color="primary" />}
      >
        {(props.actionButtonItems || []).map((item) => (
          <SpeedDialAction
            key={item.key}
            icon={item?.disable ? item.iconDisable ?? item.icon : item.icon}
            tooltipTitle={item.tooltipTitle}
            sx={{
              // padding: "4px 12px",
              // width: "auto",
              // height: "auto",
              // borderRadius: 0,
              ...(item?.disable && { cursor: "no-drop", zIndex: 100 }),
              // ...item?.styleBtn,
              "&.MuiButtonBase-root:hover": {
                color: COLOR_TYPE.TOYOTA.TOYOTA2,
              },
            }}
            onClick={(e) => {
              e.stopPropagation();

              if (item.disable) {
                e.preventDefault();
                return;
              }

              item.confirmPopupProps
                ? setConfirmPopupState({
                  open: true,
                  icon: item.confirmPopupProps.icon,
                  title: item.confirmPopupProps.title,
                  handleConfirm: () => {
                    if (item?.onClick) {
                      item?.onClick();
                      setConfirmPopupState(DefaultConfirmPopupState);
                    }
                  },
                  handleCancel: () =>
                    setConfirmPopupState(DefaultConfirmPopupState),
                })
                : item?.onClick && item?.onClick();
            }}
          />
        ))}
      </SpeedDial>
      <ConfirmPopup {...confirmPopupState} />
    </Box>
  );
};
