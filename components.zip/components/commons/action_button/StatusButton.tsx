import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import React from "react";

type Props = {
  status?: string;
  label?: string;
};
function StatusButton({ status, label }: Props) {
  if (!status) return null;
  return (
    <Box sx={{ display: "flex", alignItems: "center" }}>
      {label && <Box component={"label"} sx={{ mr: 2 }}>
        {label}
      </Box>}
      <Button
        variant="outlined"
        style={{
          background: status === "Hoàn thành" ? "#E7F4EE" : "#D781001A",
          borderRadius: "100px",
          color: status === "Hoàn thành" ? "#0D894F" : "#D78100",
          border: "none",
          padding: "4px 12px",
        }}
      >
        {status}
      </Button>
    </Box>
  );
}

export default StatusButton;
