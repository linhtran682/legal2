import React, { useMemo, useRef, useState } from "react";
import { ActionButtonProps } from "./ActionButtonCustom";
import { Box, Button, Stack, Typography } from "@mui/material";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "../popups/confirm_popup/ConfirmPopup";
import { COLOR_TYPE } from "@/constants/color";
import ActionButtonToolTip from "./ActionButtonToolTip";
// import GridViewIcon from "@mui/icons-material/GridView";
import { IconOption } from "@/assets/iconMenu/IconOption";

export const ActionButtonDetail = (props: ActionButtonProps) => {
  const { actionButtonItems = [] } = props;
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const scrollContainerRef = useRef(null);

  const actionsButtonItemsResult = useMemo(() => {
    const actionsButtonItemsActive = actionButtonItems?.filter(
      (action) => !action?.secondaryBtn
    )?.sort(
      (aAction: any, bAction: any) =>
        aAction?.order - bAction?.order
    );
    const actionsButtonItemsSecondary = actionButtonItems
      ?.filter((action) => action?.secondaryBtn)
      ?.sort(
        (aAction: any, bAction: any) =>
          aAction?.secondaryBtn - bAction?.secondaryBtn
      );
    return {
      actionsButtonItemsActive,
      actionsButtonItemsSecondary,
    };
  }, [actionButtonItems]);

  if (
    !actionsButtonItemsResult?.actionsButtonItemsActive?.length &&
    !actionsButtonItemsResult?.actionsButtonItemsSecondary?.length
  ) {
    return null;
  }

  return (
    <Stack direction={'row'} alignItems={'start'}>
      <>
        <Box
          width={'100%'}
          whiteSpace={'nowrap'}
          ref={scrollContainerRef}
          // display="flex"
          sx={{ overflowY: 'hidden', paddingBottom: `${actionsButtonItemsResult?.actionsButtonItemsActive?.length ? 16 : 0}px`, flexWrap: 'nowrap' }}
        >
          {(actionsButtonItemsResult?.actionsButtonItemsActive ?? []).map(
            (item) => (
              <>
                {item?.children ? (
                  <ActionButtonToolTip
                    listBtn={item?.children}
                    disableHoverListener={item?.disable}
                  >
                    <Typography
                      component="span"
                      key={item?.key}
                      sx={{
                        display:"inline-block",
                        cursor: "pointer",
                        height: "36px",
                        maxWidth:"85px",
                        padding: "4px 12px",
                        ...item?.styleBtn,
                        ...(item?.disable && {
                          zIndex: 100,
                          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA5,
                          cursor: "no-drop",
                        }),
                        "&:hover": {
                          ...item?.styleBtn,
                          color: COLOR_TYPE.TOYOTA.TOYOTA5,
                          ...(item?.disable && {
                            color: COLOR_TYPE.TOYOTA.TOYOTA8,
                          }),
                        },
                        mr: 1,
                      }}
                    >
                      {item?.textBtn}
                    </Typography>
                  </ActionButtonToolTip>
                ) : (
                  <Button
                    key={item?.key}
                    variant="contained"
                    sx={{
                      height: "36px",
                      padding: "4px 12px",
                      ...item?.styleBtn,
                      ...(item?.disable && {
                        backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA5,
                        // color: COLOR_TYPE.TOYOTA.TOYOTA5,
                        // pointerEvents: "none",
                        zIndex: 100,
                        cursor: "no-drop",
                      }),
                      "&:hover": {
                        ...item?.styleBtn,
                        color: COLOR_TYPE.TOYOTA.TOYOTA5,
                        ...(item?.disable && {
                          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA5,
                          color: COLOR_TYPE.TOYOTA.TOYOTA8,
                        }),
                      },
                      mr: 1,
                    }}
                    onClick={(e) => {
                      if (item.disable) {
                        e.preventDefault();
                        e.stopPropagation();
                        return;
                      }
                      item.confirmPopupProps
                        ? setConfirmPopupState({
                          open: true,
                          icon: item.confirmPopupProps.icon,
                          title: item.confirmPopupProps.title,
                          handleConfirm: () => {
                            if (item.onClick) {
                              item.onClick();
                              setConfirmPopupState(DefaultConfirmPopupState);
                            }
                          },
                          handleCancel: () =>
                            setConfirmPopupState(DefaultConfirmPopupState),
                        })
                        : item.onClick && item.onClick();
                    }}
                  >
                    {item?.textBtn}
                  </Button>
                )}
              </>
            )
          )}
        </Box>
        {actionsButtonItemsResult?.actionsButtonItemsSecondary?.length > 0 && (
          <ActionButtonToolTip
            listBtn={actionsButtonItemsResult?.actionsButtonItemsSecondary}
          >
            <Box
              sx={{ padding: 0, "&:hover": { background: "transparent", cursor: "pointer" }, mb: 1 }}
            >
              <IconOption />
            </Box>
          </ActionButtonToolTip>
        )}
      </>
      <ConfirmPopup {...confirmPopupState} />
    </Stack>

  );
};
