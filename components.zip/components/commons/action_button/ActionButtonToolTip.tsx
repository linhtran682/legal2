import { COLOR_TYPE } from "@/constants/color";
import { Box, Button, ButtonProps, styled, Tooltip } from "@mui/material";
import React, { ReactElement, useState } from "react";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "../popups/confirm_popup/ConfirmPopup";
import { ActionButtonItem } from "./ActionButtonCustom";
type TypePropsActionBtnToolTip = {
  children: ReactElement;
  listBtn?: ActionButtonItem[];
  disableHoverListener?: boolean
};
const ActionButtonToolTip = (props: TypePropsActionBtnToolTip) => {
  const { children, listBtn, disableHoverListener=false } = props;
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const ColorButton = styled(Button)<ButtonProps>(({}) => ({
    height: "36px",
    color: "black",
    backgroundColor: "transparent",
    padding: "4px 12px",
    justifyContent: "flex-start",
    boxShadow: "none",
    "&:hover": {
      backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
      color: COLOR_TYPE.TOYOTA.TOYOTA8,
    },
  }));

  return (
    <>
      <Tooltip
        placement="bottom"
        disableHoverListener={disableHoverListener}
        componentsProps={{
          tooltip: {
            sx: {
              minWidth: "200px",
              backgroundColor: "white",
              boxShadow:
                "0px 3px 5px -1px rgba(0, 0, 0, 0.2), 0px 6px 10px 0px rgba(0, 0, 0, 0.14), 0px 1px 18px 0px rgba(0, 0, 0, 0.12)",
              "& .MuiTooltip-arrow": {
                color: COLOR_TYPE.TOYOTA.TOYOTA8,
                left:"20px !important"
              },
              transform: "translateX(-20px) !important",
            },
          },
        }}
        title={
          <Box display="flex" flexDirection="column">
            {listBtn?.map((btn) => (
              <ColorButton
                key={btn.key}
                variant="contained"
                sx={{
                  ...(btn?.disable && {
                    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA5,
                    color: COLOR_TYPE.TOYOTA.TOYOTA8,
                    cursor: "no-drop",
                    zIndex: 100,
                  }),
                  "&:hover":{
                    ...(btn?.disable && {
                      color: COLOR_TYPE.TOYOTA.TOYOTA8,
                    })
                  }
                }}
                onClick={(e) => {
                  if (btn.disable) {
                    e.preventDefault();
                    e.stopPropagation();
                    return;
                  }
                  btn.confirmPopupProps
                    ? setConfirmPopupState({
                        open: true,
                        icon: btn.confirmPopupProps.icon,
                        title: btn.confirmPopupProps.title,
                        handleConfirm: () => {
                          if (btn.onClick) {
                            btn.onClick();
                            setConfirmPopupState(DefaultConfirmPopupState);
                          }
                        },
                        handleCancel: () =>
                          setConfirmPopupState(DefaultConfirmPopupState),
                      })
                    : btn.onClick && btn.onClick();
                }}
              >
                {btn?.textBtn}
              </ColorButton>
            ))}
          </Box>
        }
        arrow
      >
        {children}
      </Tooltip>
      <ConfirmPopup {...confirmPopupState} />
    </>
  );
};

export default ActionButtonToolTip;
