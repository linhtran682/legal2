import { Box, SpeedDial, SpeedDialProps, Typography } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { COLOR_TYPE } from "@/constants/color";
import { useTranslation } from "react-i18next";
import { useState } from "react";

export interface AddButtonProps extends SpeedDialProps {
  width?: number;
  height?: number;
}

export const AddButton = ({width = 40, height = 40, ... rest}: AddButtonProps) => {
  const [t] = useTranslation();
  const [showTitle, setShowTitle] = useState(false);
  return (
    <Box>
      <Box sx={{position: "relative"}} >
      <SpeedDial
        {...rest}
        ariaLabel="add_button"
        sx={{
          bottom: "4rem",
          right: "2rem",
          "& .MuiButtonBase-root:hover": {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
          },
          "& button": {
            width,
            height,
          }
        }}
        color={COLOR_TYPE.TOYOTA.TOYOTA1}
        icon={<AddIcon />}
        onMouseEnter={() => setShowTitle(true)}
        onMouseLeave={() => setShowTitle(false)}
      />
      {showTitle && (
        <Typography
          variant="h5"
          sx={{
            position: "absolute",
            bottom: "3rem",
            left: "-8px",
            zIndex: 9999
          }}
          color={COLOR_TYPE.TOYOTA.TOYOTA1}
        >
          {t("common.button.create")}
        </Typography>
      )}
      </Box>
      
    </Box>
  );
};
