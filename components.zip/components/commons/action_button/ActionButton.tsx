import { Box, SpeedDial, SpeedDialAction } from "@mui/material";
import WidgetsIcon from "@mui/icons-material/Widgets";
import { ReactElement, ReactNode, useContext, useState } from "react";
import { GridRenderCellParams } from "@mui/x-data-grid";
import {
  ConfirmPopup,
  ConfirmPopupProps,
  DefaultConfirmPopupState,
} from "../popups/confirm_popup/ConfirmPopup";
import { AppContext } from "@/context/AppContext";

export interface ActionButtonItem {
  key: string;
  icon: ReactElement | string;
  tooltipTitle: string;
  onClick: (params: GridRenderCellParams) => void;
  confirmPopupProps?: {
    icon: ReactNode;
    title: string;
  };
  styleBtn?: any;
}

export interface ActionButtonProps {
  params: GridRenderCellParams;
  actionButtomItems: ActionButtonItem[];
  isShowHoverAction?: boolean;
}

export const ActionButton = (props: ActionButtonProps) => {
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );
  const appContext = useContext(AppContext);

  return (
    <Box width={"2rem"}>
      <SpeedDial
        ariaLabel='action-btn'
        icon={
          <WidgetsIcon
            color='primary'
            sx={{ ...((props?.isShowHoverAction || !appContext?.meCanWrite) && { pointerEvents: "none" }) }}
          />
        }
        direction='left'
        sx={{ overflow: "visible" }}
        openIcon={<WidgetsIcon color='primary' />}
      >
        {(props.actionButtomItems || []).map((item) => (
          <SpeedDialAction
            key={item.key}
            icon={item.icon}
            tooltipTitle={item.tooltipTitle}
            onClick={(e) => {
              e.stopPropagation();
              item.confirmPopupProps
                ? setConfirmPopupState({
                    open: true,
                    icon: item.confirmPopupProps.icon,
                    title: item.confirmPopupProps.title,
                    handleConfirm: () => item.onClick(props.params),
                    handleCancel: () =>
                      setConfirmPopupState(DefaultConfirmPopupState),
                  })
                : item.onClick(props.params);
            }}
          />
        ))}
      </SpeedDial>
      <ConfirmPopup {...confirmPopupState} />
    </Box>
  );
};
