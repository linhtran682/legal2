import React from "react";
import Button from "@mui/material/Button";
import { ButtonProps as MuiButtonProps } from "@mui/material/Button";

// Định nghĩa kiểu tùy chỉnh cho các thuộc tính của nút
interface CustomButtonProps extends MuiButtonProps {
  customText?: string;
  textColor?: string; // Thuộc tính mới để tùy chỉnh màu chữ
  bgColor?: string; // Thuộc tính mới để tùy chỉnh màu nền
  borderColor?: string; // Thuộc tính mới để tùy chỉnh màu viền
}

// Component nút tùy chỉnh
const FormButton: React.FC<CustomButtonProps> = ({
  customText = "Button Custom",
  textColor = "white",
  bgColor = "primary.main", // Sử dụng màu nền mặc định từ theme nếu không có giá trị
  borderColor = "transparent",
  ...muiButtonProps
}) => {
  return (
    <Button
      {...muiButtonProps}
      sx={{
        fontSize: 14,
        borderRadius: 0,
        border: `1px solid ${borderColor}`, // Tùy chỉnh màu viền
        backgroundColor: bgColor, // Tùy chỉnh màu nền
        color: textColor, // Tùy chỉnh màu chữ
        textTransform: 'none', // Bỏ viết hoa văn bản
        '&:hover': {
          backgroundColor: bgColor === 'primary.main' ? 'primary.dark' : bgColor, // Thay đổi màu nền khi hover nếu cần
        },
      }}
    >
      {customText}
    </Button>
  );
};

export default FormButton;