// import { IconClock } from "@/assets/iconMenu/IconClock";
import { COLOR_TYPE } from "@/constants/color";
import { LANGUAGES } from "@/locales/config-translation";
import { BasedUser } from "@/models/user/User";
import { getUserLabel } from "@/utils";
import { Box, Chip, Divider, IconButton, Stack, Tooltip, Typography } from "@mui/material";
import { uniqueId } from "lodash";
import Link from "next/link";
import { ReactNode, useState } from "react";
import { useTranslation } from "react-i18next";
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import { useRouter } from "next/router";

export interface SearchResultItemProps<T> {
  item?: T;
  completeStatusName: string;
  // getCreatorUserName: (item: T, isEnglish: boolean) => string;
  getItemKey: (item: any) => number | string;
  getItemLink: (item: any) => string;
  getChildKey: (item: any) => number | string;

  getCreator: (item: T) => BasedUser;
  getItemName: (item: any) => string;
  getParentTimeLabel: (item: any) => string;
  getParentStatus: (item: any) => string;
  getParentUsersList: (item: T) => BasedUser[];

  getChildren: (item: any) => any[];
  getChildTimeLabel: (item: any) => string;
  getChildUsersList: (item: T) => BasedUser[];
  getChildStatus: (item: any) => string;
  getIsDraft?: (item: any) => boolean;
  openNewTab?: boolean;
  activeId?: number;
  isLast?: boolean;
}

const dividerSx = {
  borderColor: COLOR_TYPE.TOYOTA.TOYOTA7,
  borderStyle: 'dashed'
}

export const SearchResultItem = <T,>(props: SearchResultItemProps<T>) => {
  const {
    item,
    getCreator,
    getItemName,
    getParentTimeLabel,
    getChildStatus,
    getChildTimeLabel,
    getChildUsersList,
    getParentStatus,
    getParentUsersList,
    completeStatusName,
    getChildren,
    activeId,
    getChildKey,
    getItemKey,
    getItemLink,
    openNewTab = false,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    getIsDraft = (item: any) => !!item?.isDraft || !!item?.draft,
    isLast = false,
  } = props;
  const router = useRouter();
  const { i18n, t } = useTranslation();
  const isEnglish = i18n.language === LANGUAGES.ENGLISH;
  const [isExpanded, setIsExpanded] = useState(openNewTab ? true : getChildren?.(item)?.find((ele) => getItemKey(ele) === activeId));

  return (
    <Stack sx={{
      borderTop: `1px solid ${COLOR_TYPE.TOYOTA.TOYOTA7}`,
      borderBottom: isLast ? undefined : `0px`,
      width: '100%'
    }}>
      {/* <LinkWrapper
        href={getItemLink?.(item)}
        openNewTab={openNewTab}
      > */}
      <Stack
        sx={{
          backgroundColor: activeId === getItemKey(item) ? '#FFE5E5' : undefined,
          cursor: 'pointer',
          "&:hover": {
            backgroundColor: activeId === getItemKey(item) ? '#FFE5E5' : '#FFE5E550',
          }
        }}
        onClick={() => {
          if (!openNewTab) {
            router.push(getItemLink?.(item))
          } else {
            window.open(getItemLink?.(item), '_blank');
          }
        }}
      >
        <Stack direction={"row"}
          width={'100%'}
          sx={{
            pl: 1,
          }}
        >
          {!openNewTab && <IconButton
            onClick={(event) => {
              event.stopPropagation();
              setIsExpanded((prev: boolean) => !prev)
            }}
            sx={{
              width: 16, height: 16, mt: '16px',
              opacity: getChildren?.(item)?.length ? 1 : 0
            }}>
            {
              isExpanded
                ? <ExpandMoreRoundedIcon sx={{ fontSize: 18 }} />
                : <ChevronRightRoundedIcon sx={{ fontSize: 18 }} />
            }
          </IconButton>}

          <Stack
            width={'100%'}
            flex={1}
            direction={'row'} gap={1} alignItems={'center'}
            sx={{
              p: 1,
              pr: 2,
              pb: 0,
              backgroundColor: activeId === getItemKey(item) ? '#FFE5E5' : undefined,
            }}>
            <TextAvatar
              size={34}
              name={getCreator?.(item!)?.name ?? ""}
              tooltipTitle={getUserLabel(getCreator?.(item!), isEnglish)}
            />
            <Box sx={{ flex: 1 }}>
              <Tooltip title={getItemName?.(item) ?? ""} placement="top-start">
                <Typography
                  variant="h5"
                  sx={{
                    fontSize: '14px',
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    display: "-webkit-box",
                    WebkitLineClamp: "1",
                    WebkitBoxOrient: "vertical",
                    wordBreak: 'break-word',
                    title: getItemName?.(item),
                    width: "fit-content"
                  }}
                >
                  {getItemName?.(item) ?? ""}
                </Typography>
              </Tooltip>
            </Box>


            <Stack direction={'row-reverse'} alignItems={"center"} gap={0.25}>
              {/* {getIsDraft?.(item) ? <Typography sx={{
                color: COLOR_TYPE.TOYOTA.TOYOTA1,
                fontSize: '12px',
                flex: 1
              }}>*{t('common.label.draft')}</Typography>
                :  */}
              <Typography sx={{ fontSize: '10px', color: COLOR_TYPE.BLUE.BLUE6 }}>
                {t(getParentTimeLabel?.(item), { defaultValue: getParentTimeLabel?.(item) })}
              </Typography>
              {/* } */}
            </Stack>

          </Stack>
          {/* </LinkWrapper> */}
          {/* </Box> */}
        </Stack >
        <Stack
          direction={'row'}
          gap={2}
          alignItems={'center'}
          width={'100%'}
          sx={{ pl: 9, pr: 2, pb: 1 }}
        >
          <Stack sx={{ flex: 1, overflow: 'hidden', rowGap: 0.5 }}>
            <StatusChip
              label={getIsDraft?.(item) ? t("common.label.draft") : getParentStatus(item)}
              bgColor={getParentStatus(item) === completeStatusName ? '#E7F4EE' : undefined}
              color={getParentStatus(item) === completeStatusName ? '#0D894F' : undefined}
            />
          </Stack>
          <AvatarStack
            isEnglish={isEnglish}
            users={getParentUsersList?.(item!)}
          />

        </Stack>
      </Stack>
      {/* </LinkWrapper> */}
      {getChildren?.(item)?.length && isExpanded ? <Divider sx={dividerSx} /> : null}
      {
        isExpanded && getChildren?.(item)?.map((child, index) => (
          <LinkWrapper key={uniqueId("child_item_")} openNewTab={openNewTab} href={getItemLink?.(child)}>
            <Box sx={{
              backgroundColor: activeId === getChildKey?.(child) ? '#FFE5E5' : undefined,
              "&:hover": {
                backgroundColor: activeId === getChildKey(child) ? '#FFE5E5' : '#FFE5E550',
              }
            }}>
              <Stack direction={"row"}
                alignItems={'center'}
                position={'relative'}
                justifyContent={'space-between'}
                sx={{
                  p: 2,
                  pb: 0,
                  mb: 1,
                  // pl: openNewTab ? 4 : 6,
                  pl: 9,
                  pt: 1,
                }}
              >
                {/* <Box position={'absolute'} sx={{ width: '1px', height: 32, backgroundColor: '#D9D9D9', left: 44, top: 2 }} /> */}
                <Typography sx={{ fontSize: '14px', color: COLOR_TYPE.TOYOTA.TOYOTA2 }}>{t(`searchPanel.reviewRound`, { value: index + 2 })}</Typography>
                <Stack direction={'row'} alignItems={"center"} gap={0.25}>
                  {/* <IconClock /> */}
                  <Typography sx={{ fontSize: '10px', color: COLOR_TYPE.BLUE.BLUE6 }}>
                    {t(getChildTimeLabel?.(child), { defaultValue: getChildTimeLabel?.(child) })}
                  </Typography>
                </Stack>
              </Stack>
              <Stack
                key={child.id}
                direction={'row'}
                alignItems={'center'}
                justifyContent={'space-between'}
                gap={2}
                sx={{
                  p: 2,
                  pt: 0,
                  pb: 1,
                  // pl: openNewTab ? 4 : 6,
                  pl: 9,
                }}>
                <Stack sx={{ flexShrink: 1, overflow: 'hidden', rowGap: 0.5 }}>
                  <StatusChip
                    label={getIsDraft?.(child) ? t("common.label.draft") : getChildStatus(child)}
                    bgColor={getChildStatus(child) === completeStatusName ? '#E7F4EE' : undefined}
                    color={getChildStatus(child) === completeStatusName ? '#0D894F' : undefined}
                  />
                </Stack>
                <AvatarStack
                  isEnglish={isEnglish}
                  users={getChildUsersList?.(child)}
                />
              </Stack>
              {index === getChildren?.(item)?.length - 1 ? null : <Divider sx={dividerSx} />}
            </Box>
          </LinkWrapper>
        ))
      }
    </Stack >
  )
}

const AvatarStack = (props: {
  users: BasedUser[];
  isEnglish: boolean;
}) => {
  const { users, isEnglish } = props;
  const renderAvatars = () => {
    if (users?.length <= 3) {
      return <>
        {
          users.map((user) => <TextAvatar
            size={18}
            type="secondary"
            key={uniqueId("child_user_item_")}
            name={user?.name ?? ""}
            tooltipTitle={getUserLabel(user, isEnglish)}
          />)
        }
      </>
    } else {
      const displayedUsers = users?.slice(0, 2);
      const hiddenUsers = users?.slice(2);
      const remainingCount = users?.length - 2;

      return <>
        {
          displayedUsers?.map((user) => <TextAvatar
            key={uniqueId("child_user_item_")}
            size={18}
            type="secondary"
            name={user?.name ?? ""}
            tooltipTitle={getUserLabel(user, isEnglish)}
          />)
        }
        <TextAvatar
          size={18}
          type="secondary"
          key={uniqueId("child_user_item_")}
          title={`+${remainingCount}`}
          tooltipTitle={<Stack gap={0.5}>
            {hiddenUsers?.map((user) => (
              <p key={uniqueId("hidden_user_")}>{getUserLabel(user, isEnglish)}</p>
            ))}
          </Stack>
          }
          bgColor={COLOR_TYPE.TOYOTA.TOYOTA7}
          color={COLOR_TYPE.TOYOTA.TOYOTA4}
        />
      </>
    }
  }
  return <Stack direction={"row"} gap={0.25}>{renderAvatars()}</Stack>
}

export const TextAvatar = (props: {
  name?: string;
  title?: string;
  size?: number;
  tooltipTitle?: any;
  bgColor?: string;
  color?: string;
  type?: 'primary' | 'secondary';
}) => {
  const { name, size = 24, tooltipTitle = "", title,
    bgColor = COLOR_TYPE.BLUE.BLUE6,
    color = "white",
    type = 'primary'
  } = props;
  return <Tooltip
    title={tooltipTitle}>
    <Stack
      alignItems={'center'}
      justifyContent={"center"}
      sx={{
        backgroundColor: bgColor,
        width: size,
        height: size,
        borderRadius: '100px',
        border: `1px solid ${type === 'primary' ? '#dcdfe6' : '#f3f4fa'}`,
        boxShadow: type === 'secondary' ? '0px 2px 4px rgba(0, 0, 0, 0.1), 0px 4px 8px rgba(0, 0, 0, 0.1)' : undefined,
      }}
    >
      <Typography sx={{ fontSize: `${size / 2}px`, color: color }}>{title ?? name?.charAt(0)}</Typography>
    </Stack>
  </Tooltip>
}

const StatusChip = (props: {
  label: string;
  bgColor?: string;
  color?: string;
}) => {
  const { label, bgColor = '#FAF3E6', color = '#D78100' } = props;
  return <Chip
    label={label}
    // label={"Yêu cầu vendor làm bảng khuyến nghị"}
    sx={{
      width: 'fit-content',
      height: 'fit-content',
      padding: '4px 0',
      maxWidth: '100%',
      backgroundColor: bgColor,
      color: color,
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      fontSize: '14px'
    }}
  />
}

const LinkWrapper = (props: {
  href: string,
  openNewTab?: boolean;
  children: ReactNode;
}) => {
  const { href, openNewTab, children } = props
  return <Link
    href={href}
    rel={openNewTab ? "noopener noreferrer" : ""}
    target={openNewTab ? "_blank" : "_self"}
    // passHref={openNewTab}
    passHref={true}
  >{children}</Link>
}