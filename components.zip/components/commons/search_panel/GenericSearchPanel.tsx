import { COLOR_TYPE } from "@/constants/color";
import { mergeArraysByKey } from "@/utils";
import SearchIcon from "@mui/icons-material/Search";
import { Box, CircularProgress, IconButton, ListItem, TextField } from "@mui/material";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { Fragment, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useInView } from "react-intersection-observer";
import { SearchResultItem, SearchResultItemProps } from "./SearchResultItem";


type SearchListParams = {
  orderBy?: string;
  isPanelSearch?: boolean;
  tab?: number;
}
export interface GenericSearchPanelProps<T> extends SearchResultItemProps<T> {
  hierarchyQueryKey: string;
  searchQueryKey: string;
  searchKey: string;
  getHierarchyFn: (id: number) => Promise<any>;
  getSearchResultFn: (params: any) => Promise<any>;
  setIsResultSearchPanel?: (value: boolean) => void;
  searchListParams?: SearchListParams
}

const defaultParams: any = {
  orderBy: "DESC",
  page: 0,
  size: 10,
  sortBy: "id",
  isPanelSearch: true,
  tab: 0,
};

export const GenericSearchPanel = <T,>(props: GenericSearchPanelProps<T>) => {
  const { hierarchyQueryKey,
    searchQueryKey, getHierarchyFn,
    getSearchResultFn,
    setIsResultSearchPanel,
    getItemKey,
    searchKey,
    searchListParams = {},
  } = props;
  const { ref, inView } = useInView();
  const [searchString, setSearchString] = useState<string>("");
  const router = useRouter();
  const queryClient = useQueryClient();
  const id = router.query.id;
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [initialLoading, setInitialLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [searched, setSearched] = useState(false);
  const { t } = useTranslation();
  const [initialId, setInitialId] = useState<number | null>(null);
  const topRef = useRef<HTMLDivElement>(null);

  const allHierarchyQuery = useQuery({
    queryKey: [hierarchyQueryKey],
    queryFn: () => getHierarchyFn(typeof id == "string" ? Number(id) : Number((id || [])[0])),
    placeholderData: (prevData) => prevData,
    enabled: false,
  });
  const searchPanelQuery = useQuery({
    queryKey: [searchQueryKey],
    queryFn: () => {
      const params: any = {
        ...defaultParams,
        ...searchListParams,
        [searchKey]: searchString,
      };
      return getSearchResultFn(params);
    },
    enabled: false,
  });

  useEffect(() => {
    return () => {
      queryClient.resetQueries({
        queryKey: [hierarchyQueryKey]
      })
    }
  }, [])


  useEffect(() => {
    const getId = typeof id == "string" ? Number(id) : Number((id || [])[0]);
    if (getId && !searched && !initialId) {
      setInitialId(getId)
      allHierarchyQuery.refetch();
      searchPanelQuery.refetch();
    }
  }, [id]);

  useEffect(() => {
    if (inView && !isLoadingMore) {
      loadMoreDocuments();
    }
  }, [inView]);

  const loadMoreDocuments = async () => {
    setIsLoadingMore(true);
    // const params: GetBasedLegalDocumentsParams = { // TODO: Get List params
    const params: any = {
      ...defaultParams,
      ...searchListParams,
      page: currentPage + 1,
      [searchKey]: searchString,
    };
    try {
      const response = await getSearchResultFn(params);
      if (response?.data?.length) {
        queryClient.setQueryData(
          [searchQueryKey],
          // (prevData: GetBasedLegalDocumentsResponse) => {
          (prevData: any) => { // Get List Response
            const mergedData = [
              ...mergeArraysByKey(
                [[...(prevData?.data || [])], [...response?.data]],
                // (ele: any) => ele?.id
                getItemKey
              ),
            ];
            const hasIncreased = prevData?.data?.length < mergedData?.length;
            hasIncreased && setCurrentPage(currentPage + 1);
            return {
              ...(prevData ?? {}),
              data: mergedData,
            };
          }
        );
      }
    } catch (error) {
    } finally {
      setIsLoadingMore(false);
    }
  };
  const [searchValue, setSearchValue] = useState("");
  const handleSearch = () => {
    const value = searchValue.trim();
    setSearchString(value);
    setCurrentPage(() =>
      // value === searchString ? prevValue : 0
      0
    );
    // if (!!value.length) {
    setInitialLoading(true);
    setTimeout(() => searchPanelQuery.refetch().then((response) => {
      // const shouldUpdateSearch = !(!value?.length && !searched);
      setSearched(true);
      setIsResultSearchPanel?.(!!response?.data?.data?.length);
      setInitialLoading(false);
      if (response?.data?.data?.length) {
        // if (response?.data?.data?.length) {
        router.push(props.getItemLink(response?.data?.data[0]));
        topRef?.current?.scrollIntoView({ behavior: 'smooth' });
      }
    }), 100);
    // }
    if (!value.length) {
      setIsResultSearchPanel?.(true);
    }
  }

  return <Box
    width={370}
    sx={{
      backgroundColor: "white",
      height: '100%',
      mr: 2,
      display: 'flex',
      flexDirection: 'column',
      pb: 2
    }}
  >
    <Box sx={{ p: 2, display: 'flex', flexDirection: 'row', gap: 2 }}>
      <TextField
        size='small'
        fullWidth
        color='primary'
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA7,
          "& fieldset": { border: "none" },
        }}
        autoComplete="off"
        value={searchValue}
        onChange={(e) => {
          if (
            e.target.value &&
            e.target.value.length > 255
          ) {
            e.target.value = e.target.value.slice(0, 255);
          }
          setSearchValue(e.target.value);
        }}
        onKeyDown={(e) => {
          if (e.key == "Enter") {
            handleSearch()
          }
        }}
        placeholder={t("common.place_holder.enter_search_value")}
      />
      <IconButton
        sx={{
          backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
          '&:hover': {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
          }
        }}
        onClick={handleSearch}
      >
        <SearchIcon sx={{ color: 'white' }} />
      </IconButton>
    </Box>
    <Box sx={{
      flex: 1,
      // p: 2,
      pt: 0,
      pb: 0,
      overflowY: 'auto',
    }}>
      <Box ref={topRef} />
      {initialLoading && <ListItem
        sx={{ justifyContent: "center", height: 28, marginTop: 2, marginBottom: 2 }}
      >
        <CircularProgress size={28} color="primary" />
      </ListItem>}
      {!searchString.length && allHierarchyQuery.data && !searched ? (
        <>
          <SearchResultItem<T>
            {...props}
            activeId={typeof id == "string" ? Number(id) : Number((id || [])[0])}
            item={allHierarchyQuery.data}
            key={getItemKey(allHierarchyQuery.data)?.toString?.()}
          />
        </>
      ) : null}
      {/* {(searchPanelQuery?.data?.data?.length && !searchPanelQuery.isFetching) ? ( */}
      {(searchPanelQuery?.data?.data?.length) ? (
        <>
          {searchPanelQuery?.data?.data?.map((item: any, index: number) => {
            if (getItemKey?.(item) === getItemKey?.(allHierarchyQuery.data) && !searched) return null
            return (
              <Fragment key={item.id}>
                <SearchResultItem<T>
                  {...props}
                  key={getItemKey(item)?.toString?.()}
                  activeId={typeof id == "string" ? Number(id) : Number((id || [])[0])}
                  item={item}
                  isLast={index === searchPanelQuery?.data?.data?.length - 1}
                />
              </Fragment>
            )
          })}
          <ListItem
            ref={ref}
            sx={{ justifyContent: "center", height: 28, marginTop: 2 }}
          >
            {isLoadingMore ? (
              <CircularProgress size={28} color="primary" />
            ) : null}
          </ListItem>
        </>
      ) : null}
    </Box>
  </Box>
}

