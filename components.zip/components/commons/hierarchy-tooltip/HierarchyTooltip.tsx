'use client'
import { SearchResultItem } from '@/components/commons/search_panel/SearchResultItem';
import { COLOR_TYPE } from '@/constants/color';
import { Box, styled, Tooltip, tooltipClasses, TooltipProps } from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { ReactElement, useCallback } from 'react';
import { GenericSearchPanelProps } from '../search_panel/GenericSearchPanel';

const CustomizedTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 320,
    fontSize: theme.typography.pxToRem(12),
    border: `1px solid ${COLOR_TYPE.TOYOTA.TOYOTA7}`,
    padding: 0
  },
}));


interface HierarchyTooltipProps<T> extends GenericSearchPanelProps<T> {
  children: ReactElement;
  targetId: number;
  previewTitle?: string
}
const HierarchyToolTip = <T,>(props: HierarchyTooltipProps<T>) => {
  const { children, hierarchyQueryKey, targetId, getHierarchyFn, previewTitle } = props;
  const { isFetching, data, refetch } = useQuery({
    queryKey: [hierarchyQueryKey, targetId],
    queryFn: () => getHierarchyFn(targetId),
    enabled: false
  })
  const handleOpen = () => {
    refetch();
  };
  const renderTooltipContent = useCallback(() => {
    if (isFetching || !data?.children?.length) return null;
    return <Box sx={{ width: 320 }}><SearchResultItem<any>
      {...props}
      openNewTab
      activeId={targetId}
      item={data}
      isLast
    />
    </Box>
  }, [isFetching, data])
  return (
    <CustomizedTooltip
      title={renderTooltipContent()}
      placement={'left'}
      onOpen={handleOpen}
    >
      <div style={{ maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        <Tooltip title={data?.children?.length ? null : previewTitle} placement='bottom-start'>
          {children}
        </Tooltip>
      </div>
    </CustomizedTooltip>
  )
}

export default HierarchyToolTip