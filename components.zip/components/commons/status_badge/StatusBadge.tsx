

import { Button } from "@mui/material";
export interface StatusBadgeProps {
  label?: string;
}
export const StatusBadge = ({
  label,
}: StatusBadgeProps) => {
  return (
    <Button
      variant="outlined"
      disableFocusRipple
      style={{
        width: 'fit-content',
        background:
          label === "Hoàn thành" ? "#E7F4EE" : "#D781001A",
        // label === "Hoàn thành" ? "#E7F4EE" : "#FAF3E6",
        borderRadius: "100px",
        color: label === "Hoàn thành" ? "#0D894F" : "#D78100",
        border: "none",
        padding: "4px 12px",
        cursor: 'default'
      }}
    >
      {label}
    </Button>
  );
};
