import { NotAuthorizedIcon } from "@/assets/images/icons/iconNotAuthorized";
import { GLOBAL_SPACING } from "@/constants/format";
import { Grid, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";

export const NotAuthorizedIndicator = () => {
  const [t] = useTranslation();

  return (
    <Grid
      container
      width={"100%"}
      height={"100%"}
      direction={"column"}
      alignItems={"center"}
      justifyContent={"center"}
      spacing={GLOBAL_SPACING}
    >
      <Grid item>
        <NotAuthorizedIcon />
      </Grid>
      <Grid item>
        <Typography variant='h1'>{t("common.message.empty_title")}</Typography>
      </Grid>
      <Grid item>
        <Typography variant='body2'>
          {t("common.message.not_authorized_description")}
        </Typography>
      </Grid>
    </Grid>
  );
};
