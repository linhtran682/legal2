import { AppContext } from "@/context/AppContext";
import { ReactNode, useContext } from "react";
import { LoadingWrapper } from "../loading_indicator/LoadingWrapper";
import { NotAuthorizedIndicator } from "./NotAuthorizedIndicator";

export interface AuthorityCheckWrapperProps {
  children: ReactNode | ReactNode[];
}

export const AuthorityCheckWrapper = (props: AuthorityCheckWrapperProps) => {
  const appContext = useContext(AppContext);

  return (
    <LoadingWrapper loading={appContext.loading}>
      {!appContext.loading && !appContext.meCanAccessTheRoute && (
        <NotAuthorizedIndicator />
      )}
      {
      !appContext.loading && appContext.meCanAccessTheRoute &&
      
      props.children}
    </LoadingWrapper>
  );
};
