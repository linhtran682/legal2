import { Tab, Tabs, Typography } from "@mui/material";
import { ReactNode, useEffect, useState } from "react";

export interface TabItem {
  label: ReactNode;
  key: string;
  content: ReactNode;
  disabled?: boolean;
}

export interface TabNavProps {
  index?: number;
  onChangeTabIndex?: (index: number) => void;
  tabItems: TabItem[];
}

export const TabNav = (props: TabNavProps) => {
  const [openedIndex, setOpenedIndex] = useState(() => props.index ?? 0);

  useEffect(() => {
    setOpenedIndex(props.index ?? 0);
  }, [props.index]);

  const handleChangeTabIndex = (index: number) => {
    !props.index && setOpenedIndex(index);
    props.onChangeTabIndex && props.onChangeTabIndex(index);
  };

  return (
    <>
      <Tabs
        value={openedIndex}
        onChange={(_, i) => handleChangeTabIndex(i)}
        variant='scrollable'
        textColor="inherit"
      >
        {props.tabItems.map((tabItem) => (
          <Tab
            label={<Typography variant='h5'>{tabItem.label}</Typography>}
            key={tabItem.key}
            id={`tab-label-${tabItem.key}`}
            aria-controls={`tab-panel-${tabItem.key}`}
            sx={{ textTransform: "none" }}
            disabled={tabItem.disabled}
          />
        ))}
      </Tabs>

      <div
        role='tabpanel'
        id={`tab-panel-${props.tabItems[openedIndex].key}`}
        key={props.tabItems[openedIndex].key}
        aria-labelledby={`tab-label-${props.tabItems[openedIndex].key}`}
        style={{ height: "100%", overflow: "hidden" }}
      >
        {props.tabItems[openedIndex].content}
      </div>
    </>
  );
};
