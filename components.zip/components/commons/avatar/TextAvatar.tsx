import { COLOR_TYPE } from "@/constants/color";
import { Stack, Tooltip, Typography } from "@mui/material";

export const TextAvatar = (props: {
  name?: string;
  title?: string;
  size?: number;
  tooltipTitle?: any;
  bgColor?: string;
  color?: string;
}) => {
  const { name, size = 24, tooltipTitle = "", title,
    bgColor = COLOR_TYPE.BLUE.BLUE6,
    color = "white"
  } = props;
  return <Tooltip
    title={tooltipTitle}>
    <Stack
      alignItems={'center'}
      justifyContent={"center"}
      sx={{
        backgroundColor: bgColor,
        width: size,
        height: size,
        borderRadius: '100px',
      }}
    >
      <Typography sx={{ fontSize: `${size / 2}px`, color: color }}>{title ?? name?.charAt(0)}</Typography>
    </Stack>
  </Tooltip>
}
