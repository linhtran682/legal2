import { COLOR_TYPE } from "@/constants/color";
import React from "react";
type TypeIconExtendDeadlineProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconExtendDeadline = (props: TypeIconExtendDeadlineProps) => {
  const { width = "22", height = "22", color = COLOR_TYPE.TOYOTA.TOYOTA1 } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 22 22"
      fill="none"
    >
      <path
        d="M20.9208 12.265C20.9731 11.8507 21 11.4285 21 11C21 5.47715 16.5228 1 11 1C5.47715 1 1 5.47715 1 11C1 16.5228 5.47715 21 11 21C11.4354 21 11.8643 20.9722 12.285 20.9182M11 5V11L14.7384 12.8692M18 21V15M15 18H21"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
