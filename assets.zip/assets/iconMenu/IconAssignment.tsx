import { COLOR_TYPE } from "@/constants/color";
import React from "react";
type TypeIconAssignmentProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconAssignment = (props: TypeIconAssignmentProps) => {
  const { width = "22", height = "20", color = COLOR_TYPE.TOYOTA.TOYOTA1 } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 22 20"
      fill="none"
    >
      <path
        d="M15 16L17 18L21 14M11 13H7C5.13623 13 4.20435 13 3.46927 13.3045C2.48915 13.7105 1.71046 14.4892 1.30448 15.4693C1 16.2044 1 17.1362 1 19M14.5 1.29076C15.9659 1.88415 17 3.32131 17 5C17 6.67869 15.9659 8.11585 14.5 8.70924M12.5 5C12.5 7.20914 10.7091 9 8.5 9C6.29086 9 4.5 7.20914 4.5 5C4.5 2.79086 6.29086 1 8.5 1C10.7091 1 12.5 2.79086 12.5 5Z"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
