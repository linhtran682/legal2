type TypeIconReadAllProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconReadAll = (props: TypeIconReadAllProps) => {
  const { width = "24", height = "24" } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
    >
      <path d="M19 7H22" stroke="#101010" strokeWidth="1.5" strokeLinecap="round" />
      <path
        d="M16 12H19"
        stroke="#101010"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M12 17H15"
        stroke="#101010"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M2 14.5L6.1304 18.6304C6.57893 19.0789 7.32634 19.0019 7.67396 18.4713L16.5 5"
        stroke="#101010"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
};
