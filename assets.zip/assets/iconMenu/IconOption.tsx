import React from "react";
type TypeIconRecallProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconOption = (props: TypeIconRecallProps) => {
  const { width = "24", height = "24", color = "#808080", ...rest } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      {...rest}
    >
      <g clip-path="url(#clip0_2614_74553)">
        <path
          d="M11.9987 5.33333C12.9192 5.33333 13.6654 4.58714 13.6654 3.66667C13.6654 2.74619 12.9192 2 11.9987 2C11.0782 2 10.332 2.74619 10.332 3.66667C10.332 4.58714 11.0782 5.33333 11.9987 5.33333Z"
          fill={color}
        />
        <path
          d="M11.9987 13.6666C12.9192 13.6666 13.6654 12.9205 13.6654 12C13.6654 11.0795 12.9192 10.3333 11.9987 10.3333C11.0782 10.3333 10.332 11.0795 10.332 12C10.332 12.9205 11.0782 13.6666 11.9987 13.6666Z"
          fill={color}
        />
        <path
          d="M11.9987 22C12.9192 22 13.6654 21.2538 13.6654 20.3334C13.6654 19.4129 12.9192 18.6667 11.9987 18.6667C11.0782 18.6667 10.332 19.4129 10.332 20.3334C10.332 21.2538 11.0782 22 11.9987 22Z"
          fill={color}
        />
      </g>
      <defs>
        <clipPath id="clip0_2614_74553">
          <rect
            width="20"
            height="20"
            fill="white"
            transform="translate(2 2)"
          />
        </clipPath>
      </defs>
    </svg>
  );
};
