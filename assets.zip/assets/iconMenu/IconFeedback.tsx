import { COLOR_TYPE } from "@/constants/color";
import React from "react";
type TypeIconFeedbackProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconFeedback = (props: TypeIconFeedbackProps) => {
  const { width = "20", height = "19", color = COLOR_TYPE.TOYOTA.TOYOTA1 } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 20 19"
      fill="none"
    >
      <path
        d="M19 16.0002L17.9999 17.0943C17.4695 17.6744 16.7501 18.0002 16.0001 18.0002C15.2501 18.0002 14.5308 17.6744 14.0004 17.0943C13.4692 16.5154 12.75 16.1903 12.0002 16.1903C11.2504 16.1903 10.5311 16.5154 9.99997 17.0943M1 18.0002H2.67454C3.16372 18.0002 3.40832 18.0002 3.63849 17.945C3.84256 17.896 4.03765 17.8152 4.2166 17.7055C4.41843 17.5818 4.59138 17.4089 4.93729 17.063L17.5 4.50023C18.3285 3.6718 18.3285 2.32865 17.5 1.50023C16.6716 0.671799 15.3285 0.6718 14.5 1.50023L1.93726 14.063C1.59136 14.4089 1.4184 14.5818 1.29472 14.7837C1.18506 14.9626 1.10425 15.1577 1.05526 15.3618C1 15.5919 1 15.8365 1 16.3257V18.0002Z"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
