import React from "react";
type TypeIconEvaluateProps = {
  width?: string;
  height?: string;
};
export const IconEvaluate = (props: TypeIconEvaluateProps) => {
  const { width = "18", height = "18" } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 18 18"
      fill="none"
    >
      <path
        d="M1 5H11C14.3137 5 17 7.68629 17 11C17 14.3137 14.3137 17 11 17H1M1 5L5 1M1 5L5 9"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
