export const IconFolder = () => (
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M7.63281 15.0859H16.3678"
      stroke="#101010"
      stroke-width="1.5"
      stroke-linecap="square"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M21.25 20.3249H2.75V3.67188H9.71326L11.9749 6.4508H21.25V20.3249Z"
      stroke="#101010"
      stroke-width="1.5"
      stroke-linecap="square"
    />
  </svg>
);
