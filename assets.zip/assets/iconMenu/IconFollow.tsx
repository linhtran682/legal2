import { COLOR_TYPE } from "@/constants/color";
import React from "react";
type TypeIconRequestConfirmProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconFollow = (props: TypeIconRequestConfirmProps) => {
  const {
    width = "24",
    height = "24",
    color = COLOR_TYPE.TOYOTA.TOYOTA1,
  } = props;
  return (
    <svg
    width={width}
    height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M8 3H6.2C5.0799 3 4.51984 3 4.09202 3.21799C3.71569 3.40973 3.40973 3.71569 3.21799 4.09202C3 4.51984 3 5.0799 3 6.2V8M8 21H6.2C5.0799 21 4.51984 21 4.09202 20.782C3.71569 20.5903 3.40973 20.2843 3.21799 19.908C3 19.4802 3 18.9201 3 17.8V16M21 8V6.2C21 5.0799 21 4.51984 20.782 4.09202C20.5903 3.71569 20.2843 3.40973 19.908 3.21799C19.4802 3 18.9201 3 17.8 3H16M21 16V17.8C21 18.9201 21 19.4802 20.782 19.908C20.5903 20.2843 20.2843 20.5903 19.908 20.782C19.4802 21 18.9201 21 17.8 21H16M12 17L12 7M7 12H17"
        stroke={color}

        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
