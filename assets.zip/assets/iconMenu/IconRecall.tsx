import { COLOR_TYPE } from "@/constants/color";
import React from "react";
type TypeIconRecallProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconRecall = (props: TypeIconRecallProps) => {
  const { width = "18", height = "18", color=COLOR_TYPE.TOYOTA.TOYOTA1} = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 18 18"
      fill="none"
    >
      <path
        d="M1 5H11C14.3137 5 17 7.68629 17 11C17 14.3137 14.3137 17 11 17H1M1 5L5 1M1 5L5 9"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
