import { COLOR_TYPE } from "@/constants/color";
import React from "react";
type TypeIconForwardProps = {
  width?: string;
  height?: string;
  color?: string;
};
export const IconForward = (props: TypeIconForwardProps) => {
  const { width = "21", height = "21", color = COLOR_TYPE.TOYOTA.TOYOTA1 } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 22 21"
      fill="none"
      color="red"
    >
      <path
        d="M12 17H16.2942C18.1594 17 19.092 17 19.6215 16.6092C20.0832 16.2685 20.3763 15.7459 20.4263 15.1743C20.4836 14.5187 19.9973 13.7229 19.0247 12.1313L18.0278 10.5M5.13014 8.60522L2.97528 12.1314C2.00267 13.7229 1.51637 14.5187 1.57372 15.1743C1.62372 15.7459 1.91681 16.2685 2.37846 16.6092C2.90799 17 3.84059 17 5.70578 17H7.5M15.8889 6.99999L13.7305 3.46808C12.8277 1.99079 12.3763 1.25214 11.7952 1.00033C11.2879 0.780489 10.7121 0.780489 10.2048 1.00033C9.62369 1.25214 9.17229 1.99079 8.2695 3.46809L7.24967 5.13689M17 3.00006L15.9019 7.09813L11.8038 6.00006M1 9.59807L5.09808 8.49999L6.19615 12.5981M14.5 20L11.5 17L14.5 14"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
