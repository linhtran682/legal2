import React from "react";
type TypeIconClockProps = {
  width?: string;
  height?: string;
};
export const IconClock = (props: TypeIconClockProps) => {
  const { width = "16", height = "16" } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 17 16"
      fill="none"
    >
      <g clipPath="url(#clip0_2144_59788)">
        <path
          d="M8.21094 14C4.90244 14 2.21094 11.3085 2.21094 8C2.21094 4.6915 4.90244 2 8.21094 2C11.5194 2 14.2109 4.6915 14.2109 8C14.2109 11.3085 11.5194 14 8.21094 14ZM8.21094 3C5.45394 3 3.21094 5.243 3.21094 8C3.21094 10.757 5.45394 13 8.21094 13C10.9679 13 13.2109 10.757 13.2109 8C13.2109 5.243 10.9679 3 8.21094 3ZM10.7109 8C10.7109 7.7235 10.4874 7.5 10.2109 7.5H8.71094V5C8.71094 4.7235 8.48694 4.5 8.21094 4.5C7.93494 4.5 7.71094 4.7235 7.71094 5V8C7.71094 8.2765 7.93494 8.5 8.21094 8.5H10.2109C10.4874 8.5 10.7109 8.2765 10.7109 8Z"
          fill="#007AFF"
        />
      </g>
      <defs>
        <clipPath id="clip0_2144_59788">
          <rect
            width={12}
            height={12}
            fill="white"
            transform="translate(2.21094 2)"
          />
        </clipPath>
      </defs>
    </svg>


  );
};
