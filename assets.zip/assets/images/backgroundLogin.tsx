export const BackgroundLogin = () => (
  <svg
    width="1440"
    height="1024"
    viewBox="0 0 1440 1024"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect opacity="0.5" width="1440" height="1024" fill="#101010" />
  </svg>
);
