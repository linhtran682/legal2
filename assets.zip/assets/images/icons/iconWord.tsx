export const WordIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={30}
      height={40}
      viewBox="0 0 30 40"
      fill="none"
    >
      <g clipPath="url(#clip0_203_808)">
        <mask
          id="mask0_203_808"
          style={{ maskType: "luminance" }}
          maskUnits="userSpaceOnUse"
          x={0}
          y={0}
          width={30}
          height={40}
        >
          <path
            d="M30 0H0V40H30V0Z"
            fill="white"
            style={{ fill: "white", fillOpacity: 1 }}
          />
        </mask>
        <g mask="url(#mask0_203_808)">
          <path
            d="M0 4C0 1.79086 1.79086 0 4 0H17L30 13V36C30 38.2092 28.2092 40 26 40H4C1.79086 40 0 38.2092 0 36V4Z"
            fill="#3873FF"
            style={{
              fill: "color(display-p3 0.2196 0.4510 1.0000)",
              fillOpacity: 1
            }}
          />
          <path
            d="M20 13H30L17 0V10C17 11.6568 18.3432 13 20 13Z"
            fill="white"
            fillOpacity="0.5"
            style={{ fill: "white", fillOpacity: "0.5" }}
          />
        </g>
        <path
          d="M10.3418 28.5001L7.01221 16.8638H9.69971L11.6259 24.949H11.7225L13.8475 16.8638H16.1486L18.2679 24.966H18.3702L20.2963 16.8638H22.9838L19.6543 28.5001H17.2566L15.0407 20.8922H14.9497L12.7395 28.5001H10.3418Z"
          fill="white"
          style={{ fill: "white", fillOpacity: 1 }}
        />
      </g>
      <defs>
        <clipPath id="clip0_203_808">
          <rect
            width={30}
            height={40}
            fill="white"
            style={{ fill: "white", fillOpacity: 1 }}
          />
        </clipPath>
      </defs>
    </svg>

  );
};
