export const ExcelIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={30}
      height={40}
      viewBox="0 0 30 40"
      fill="none"
    >
      <g clipPath="url(#clip0_203_816)">
        <mask
          id="mask0_203_816"
          style={{ maskType: "luminance" }}
          maskUnits="userSpaceOnUse"
          x={0}
          y={0}
          width={30}
          height={40}
        >
          <path
            d="M30 0H0V40H30V0Z"
            fill="white"
            style={{ fill: "white", fillOpacity: 1 }}
          />
        </mask>
        <g mask="url(#mask0_203_816)">
          <path
            d="M0 4C0 1.79086 1.79086 0 4 0H17L30 13V36C30 38.2092 28.2092 40 26 40H4C1.79086 40 0 38.2092 0 36V4Z"
            fill="#0DB664"
            style={{
              fill: "color(display-p3 0.0520 0.7128 0.3934)",
              fillOpacity: 1
            }}
          />
          <path
            d="M20 13H30L17 0V10C17 11.6568 18.3432 13 20 13Z"
            fill="white"
            fillOpacity="0.5"
            style={{ fill: "white", fillOpacity: "0.5" }}
          />
        </g>
        <path
          d="M12.3496 16.8638L14.6962 20.8297H14.7871L17.1451 16.8638H19.9235L16.3723 22.6819L20.003 28.5001H17.1735L14.7871 24.5285H14.6962L12.3098 28.5001H9.4917L13.1337 22.6819L9.55985 16.8638H12.3496Z"
          fill="white"
          style={{ fill: "white", fillOpacity: 1 }}
        />
      </g>
      <defs>
        <clipPath id="clip0_203_816">
          <rect
            width={30}
            height={40}
            fill="white"
            style={{ fill: "white", fillOpacity: 1 }}
          />
        </clipPath>
      </defs>
    </svg>
  );
};
