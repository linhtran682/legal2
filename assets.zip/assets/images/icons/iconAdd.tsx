export const IconAdd = () => (
  <svg
    width="44"
    height="44"
    viewBox="0 0 44 44"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect width="44" height="44" rx="22" fill="#EB0A1E" fill-opacity="0.1" />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M22 12C21.4477 12 21 12.4477 21 13V20.5H13.5C12.9477 20.5 12.5 20.9477 12.5 21.5C12.5 22.0523 12.9477 22.5 13.5 22.5H21V30C21 30.5523 21.4477 31 22 31C22.5523 31 23 30.5523 23 30V22.5H30.5C31.0523 22.5 31.5 22.0523 31.5 21.5C31.5 20.9477 31.0523 20.5 30.5 20.5H23V13C23 12.4477 22.5523 12 22 12Z"
      fill="#EB0A1E"
    />
  </svg>
);
