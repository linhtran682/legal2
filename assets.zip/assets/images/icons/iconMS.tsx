export const IconMs = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clipPath="url(#clip0_352_17793)">
      <path d="M7.60412 7.60412H0V0H7.60412V7.60412Z" fill="#F1511B" />
      <path d="M15.9996 7.60412H8.39551V0H15.9996V7.60412Z" fill="#80CC28" />
      <path d="M7.60394 16.0001H0V8.396H7.60394V16.0001Z" fill="#00ADEF" />
      <path
        d="M15.9996 16.0001H8.39551V8.396H15.9996V16.0001Z"
        fill="#FBBC09"
      />
    </g>
    <defs>
      <clipPath id="clip0_352_17793">
        <rect width="16" height="16" fill="white" />
      </clipPath>
    </defs>
  </svg>
);
