/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  env: {
    SERVER_URL: process.env.SERVER_URL,
    CLIENT_ID: process.env.CLIENT_ID,
    REDIRECT_URL: process.env.REDIRECT_URL,
    CODE_CHALLENGE_METHOD: process.env.CODE_CHALLENGE_METHOD,
    REACT_APP_TENANT_ID: process.env.REACT_APP_TENANT_ID,
    REACT_APP_CLIENT_ID: process.env.REACT_APP_CLIENT_ID,
    REACT_APP_REDIRECT_URI: process.env.REACT_APP_REDIRECT_URI,
    REACT_APP_SCOPES: process.env.REACT_APP_SCOPES,
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
  eslint: {
    ignoreDuringBuilds: false, // Build không bị dừng dù có lỗi ESLint
  },
};

const withTM = require("next-transpile-modules")(["@mui/x-data-grid/"]);

module.exports = withTM(nextConfig);
