module.exports = {
    apps: [
      {
        name: 'front-legal',
        script: 'npm',
        args: 'start',
        interpreter: 'node',  // Specify the interpreter as node
        env: {
          NODE_ENV: 'production',
        },
      },
    ],
  };