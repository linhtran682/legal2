import { getMe } from "@/apis/service/user/User";
import { PermissionAction, PermissionRouteMap } from "@/constants/general";
import { UI_PATH } from "@/constants/paths";
import { UserProfileDTO } from "@/models/user/User";
import { cookieSetting } from "@/utils";
import { useRouter } from "next/router";
import { createContext, useEffect, useState } from "react";

export interface AppContextI {
  loading: boolean;
  me?: UserProfileDTO;
  meCanWrite: boolean;
  meCanRead: boolean;
  meCanAccessTheRoute: boolean;
  isCallingEsign: boolean;
  setIsCallingEsign: (state: boolean) => void;
}

export const AppContext = createContext<AppContextI>({
  loading: false,
  me: {
    id: "",
  },
  meCanWrite: false,
  meCanRead: false,
  meCanAccessTheRoute: false,
  isCallingEsign: false,
  setIsCallingEsign: () => {},
});

export const useAppContext = (): AppContextI => {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [me, setMe] = useState<UserProfileDTO | undefined>();
  const [canRead, setCanRead] = useState(false);
  const [canWrite, setCanWrite] = useState(false);
  const [isCallingEsign, setIsCallingEsign] = useState(false);

  const handleGetMe = async () => {
    setLoading(true);
    getMe()
      .then((me) => {
        setMe(me);
        setCanRead(checkCanRead(me));
        setCanWrite(checkCanWrite(me));
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  const handleClearMe = () => {
    setMe(undefined);
    setCanRead(false);
    setCanWrite(false);
  };

  useEffect(() => {
    if (!router.pathname.includes("auth")) {
      if (cookieSetting.get("token")) {
        handleGetMe();
      }
    }

    if (me) {
      setCanRead(checkCanRead(me));
      setCanWrite(checkCanWrite(me));
    }

    if (!cookieSetting.get("token")) {
      handleClearMe();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router.pathname, cookieSetting.get("token")]);

  const checkCanWrite = (me: UserProfileDTO | undefined) => {
    for (const role of me?.roles || []) {
      for (const permission of role?.permissions || []) {
        const [permissionKey, permissionAction] = permission.split(":");
        if (
          PermissionRouteMap.has(permissionKey) &&
          router.pathname.includes(PermissionRouteMap.get(permissionKey)!) &&
          permissionAction == PermissionAction.WRITE
        ) {
          return true;
        }
      }
    }

    return false;
  };

  const checkCanRead = (me: UserProfileDTO | undefined) => {
    for (const role of me?.roles || []) {
      for (const permission of role?.permissions || []) {
        const [permissionKey, permissionAction] = permission.split(":");

        if (
          PermissionRouteMap.has(permissionKey) &&
          router.pathname.includes(PermissionRouteMap.get(permissionKey)!) &&
          (permissionAction == PermissionAction.WRITE ||
            permissionAction == PermissionAction.READ)
        ) {
          return true;
        }
      }
    }

    return true;
  };

  const checkCanAccessTheRoute = (canRead: boolean, canWrite: boolean) => {
    if (router.pathname == "/") {
      return true;
    }

    if (!canRead && !canWrite) {
      return false;
    }

    if (
      canRead &&
      !canWrite &&
      [UI_PATH.LIST, UI_PATH.VIEW, UI_PATH.UPDATE].some((action) =>
        router.pathname.includes(action)
      )
    ) {
      return true;
    }

    return canWrite;
  };

  return {
    loading: loading,
    me: me,
    meCanWrite: canWrite,
    meCanRead: canRead,
    meCanAccessTheRoute: checkCanAccessTheRoute(canRead, canWrite),
    isCallingEsign,
    setIsCallingEsign,
  };
};
