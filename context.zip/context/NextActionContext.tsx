
import { ApproveType } from "@/models/follow_violation/FormType";

import { createContext, ReactNode, useState } from "react";

export interface ApproveI {
  status?: ApproveType | null;
  values: number[];
}

export interface NextActionContextI {
  approve: ApproveI,
  selectApproveItems: (status: ApproveType | null, items: number[]) => void
}

export const NextActionContext = createContext<NextActionContextI>({
  approve: { status: undefined, values: [] },
  selectApproveItems: () => {}  // Default function to avoid error when not used.
});

export const NextActionProvider = ({ children }: { children: ReactNode }) => {
  const [approve, setApprove] = useState<ApproveI>({
    values: [],
  })

  const selectApproveItems = (status: ApproveType | null, items: number[]) => {
    setApprove({status, values: items});
  }

  return (
    <NextActionContext.Provider
      value={{ approve, selectApproveItems }}
    >
    {children}
    </NextActionContext.Provider>
  )
}
