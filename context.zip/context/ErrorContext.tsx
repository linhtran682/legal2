import { ErrorPopup } from "@/components/commons/popups/confirm_popup/ErrorPopup";
import { useRouter } from "next/router";
import React, { createContext, useContext, useState } from "react";
interface ErrorContextType {
  error: string | null;
  showError: (message: string | null) => void;
  clearError: () => void;
}
const defaultValue: ErrorContextType = {
  error: null,
  showError: () => {},
  clearError: () => {},
};
interface Props {
  children: React.ReactNode;
}
const ErrorContext = createContext<ErrorContextType>(defaultValue);

export const ErrorProvider = ({ children }: Props) => {
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const showError = (errorMessage: string | null) => {
    setError(errorMessage);
  };

  const clearError = () => {
    setError(null);
  };

  const handleClose = () => {
    clearError();
    router.back();
  };
  return (
    <ErrorContext.Provider value={{ error, showError, clearError }}>
      {children}
      {error && <ErrorPopup onClose={handleClose} />}
    </ErrorContext.Provider>
  );
};

export const useError = () => useContext(ErrorContext);
