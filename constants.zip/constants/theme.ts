import { SxProps, ThemeOptions, tooltipClasses } from "@mui/material";
import { viVN as dataGridViVN } from "../components/commons/tables/standard_table/locale";
import { viVN as pickersViVN } from "@mui/x-date-pickers/locales";
import { viVN as coreViVN } from "@mui/material/locale";
import { COLOR_TYPE } from "./color";
import { GLOBAL_SPACING } from "./format";

// export const toyotaTextRegularFont = localFont({
//   src: [
//     {
//       path: "../../public/fonts/Toyota-Text-Regular.ttf",
//     },
//   ],
// });

// export const toyotaTextBoldFont = localFont({
//   src: [
//     {
//       path: "../../public/fonts/Toyota-Text-Bold.ttf",
//     },
//   ],
// });

export const muiThemeOptions: ThemeOptions = {
  components: {
    MuiInputLabel: {
      styleOverrides: {
        root: {
          fontSize: "1rem",
          "&.Mui-disabled": {
            color: "#808080 !important",
          },
        },
      },
    },
    MuiCssBaseline: {
      styleOverrides: {
        "*": {
          scrollbarWidth: "thin",
          "&::-webkit-scrollbar": {
            width: "7px",
            height: "7px",
          },
          "&::-webkit-scrollbar-thumb": {
            backgroundColor: "#888",
            borderRadius: "3px",
          },
          "&::-webkit-scrollbar-thumb:hover": {
            backgroundColor: "#555",
          },
          [`& .${tooltipClasses.tooltip}`]: {
            backgroundColor: "#fff !important",
            color: "rgba(0, 0, 0, 0.87) !important",
            // boxShadow: theme.shadows[1],
            fontSize: "0.875rem !important",
          },
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          borderRadius: 0,
        },
      },
      variants: [
        {
          props: {
            className: "red-round",
          },
          style: {
            borderRadius: 100,
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
            // opacity: 0.4,
            color: COLOR_TYPE.TOYOTA.TOYOTA8,
            ":hover": {
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
              opacity: 1,
            },
          },
        },
      ],
    },
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
        },
      },
      variants: [
        {
          props: {
            variant: "contained",
            color: "primary",
            className: "cancel",
          },
          style: {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA2,
          },
        },
        {
          props: {
            variant: "contained",
            color: "primary",
            className: "delete",
          },
          style: {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
            color: COLOR_TYPE.TOYOTA.TOYOTA1,
            border: `1px solid ${COLOR_TYPE.TOYOTA.TOYOTA1}`,
            ":hover": {
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
              color: COLOR_TYPE.TOYOTA.TOYOTA8,
            },
            "&.Mui-disabled": {
              border: "none",
            },
          },
        },
        {
          props: {
            variant: "contained",
            className: "confirm",
          },
          style: {
            ":hover": {
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1,
              color: COLOR_TYPE.TOYOTA.TOYOTA8,
            },
          },
        },
        {
          props: {
            variant: "contained",
            color: "primary",
            className: "saveDraft",
          },
          style: {
            backgroundColor: COLOR_TYPE.WARNING.YELLOW11,
            ":hover": {
              backgroundColor: COLOR_TYPE.WARNING.YELLOW11,
            },
          },
        },
        {
          props: {
            variant: "contained",
            color: "primary",
            className: "information",
          },
          style: {
            backgroundColor: COLOR_TYPE.BLUE.BLUE6,
            ":hover": {
              backgroundColor: COLOR_TYPE.BLUE.BLUE6,
            },
          },
        },
      ],
    },
    MuiGrid: {
      variants: [
        {
          props: {
            className: "form-section-wrapper",
          },
          style: {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
            padding: GLOBAL_SPACING,
          },
        },
        {
          props: {
            className: "form-sub-section-wrapper",
          },
          style: {
            backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA8,
            padding: GLOBAL_SPACING,
            border: `solid 1px ${COLOR_TYPE.TOYOTA.TOYOTA5}`,
          },
        },
        {
          props: {
            container: true,
            className: "form-wrapper",
          },
          style: {
            minWidth: "fit-content",
            width: "100%",
            display: "block",
          },
        },
      ],
    },
    MuiInputBase: {
      styleOverrides: {
        root: {
          "&.Mui-disabled": {
            color: "#808080 !important",
            // backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA6 + " !important",
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        input: {
          "&::placeholder": {
            fontSize: "1rem !important",
            fontWeight: 500,
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        select: {
          fontSize: "0.875rem",
        },
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        listbox: {
          fontSize: "0.875rem",
        },
      },
    },
    MuiMenuItem: {
      styleOverrides: {
        root: {
          fontSize: "0.875rem",
          "&.Mui-selected": {
            color: COLOR_TYPE.TOYOTA.TOYOTA1 + " !important",
          },
          "&.MuiMultiSectionDigitalClockSection-item[aria-selected='true']": {
            color: COLOR_TYPE.TOYOTA.TOYOTA8 + " !important",
            ":hover": {
              backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA1 + " !important",
            },
          },
        },
      },
    },
  },
  typography: {
    fontFamily:
      "'Toyota-Text-Regular', 'Roboto-Regular', sans-serif !important",
    h1: {
      fontSize: "1.25rem",
      lineHeight: "1.75rem",
      fontFamily: "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
      fontWeight: 700,
    },
    h2: {
      fontSize: "1.125rem",
      lineHeight: "1.5rem",
      fontFamily: "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
      fontWeight: 700,
    },
    h5: {
      fontSize: "1rem",
      lineHeight: "1.5rem",
      fontFamily: "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
      fontWeight: 700,
    },
    h6: {
      fontSize: "0.8125rem",
      lineHeight: "1.5rem",
      fontFamily:
        "'Toyota-Text-Regular', 'Roboto-Regular', sans-serif !important",
    },
    body2: {
      fontSize: "0.875rem",
      lineHeight: "1.25rem",
    },
    subtitle1: {
      fontSize: "0.875",
      lineHeight: "1.25rem",
      fontFamily: "'Toyota-Text-Bold', 'Roboto-Regular', sans-serif !important",
      fontWeight: 700,
    },
  },
  palette: {
    primary: {
      light: COLOR_TYPE.TOYOTA.TOYOTA7,
      main: COLOR_TYPE.TOYOTA.TOYOTA1,
      dark: COLOR_TYPE.TOYOTA.TOYOTA2,
      contrastText: COLOR_TYPE.TOYOTA.TOYOTA8,
    },
  },
  shape: { borderRadius: 0 },
};

export const formInputSxProps: SxProps = {
  "& .MuiInputBase-root": {
    fontFamily:
      "'Toyota-Text-Regular', 'Roboto-Regular', sans-serif !important",
    backgroundColor: COLOR_TYPE.TOYOTA.TOYOTA7,
    fontSize: "1rem",
    "& fieldset": { borderColor: "rgba(0, 0, 0, 0)" },
    "&:hover fieldset": {
      borderColor: COLOR_TYPE.TOYOTA.TOYOTA5,
    },
    "& fieldset legend": { width: 0 },
    "&.Mui-focused fieldset": {
      borderColor: COLOR_TYPE.TOYOTA.TOYOTA5,
      color: COLOR_TYPE.TOYOTA.TOYOTA3,
    },
  },
  "& .MuiFormLabel-root.Mui-focused": {
    color: COLOR_TYPE.TOYOTA.TOYOTA2,
  },
  "& .MuiFormLabel-asterisk": {
    color: COLOR_TYPE.TOYOTA.TOYOTA1,
  },
  // "& .MuiInputLabel-shrink": {
  //   top: 0,
  //   left: "-0.75rem",
  //   // fontSize: "1.125rem !important",
  //   lineHeight: "1.6rem",
  //   fontWeight: 400,
  //   fontFamily: "Toyota-Text-Regular, Roboto-Regular, sans-serif !important",
  //   color: "#808080",
  // },
  "& .MuiFormControl-root": {
    // paddingTop: "1rem",
    // marginTop: "0.5rem",
  },
  "& .no-label": {
    paddingTop: "0 !important",
    marginTop: "0 !important",
  },
};

export const MuiViVNLocaleSet = [dataGridViVN, pickersViVN, coreViVN];
