export const VALIDATION_MSG = {
  REQUIRED_FIELD: "common.validation_msg.required",
  SELECT: "common.validation_msg.select",
  SELECT_FILE: "common.validation_msg.select_file",
  GREATER_THAN_0: "common.validation_msg.greater_than_0",
  NOT_NEGATIVE: "common.validation_msg.not_negative",
  MUST_BE_A_NUMBER: "common.validation_msg.must_be_number",
  MUST_BE_A_VALID_EMAIL: "common.validation_msg.must_be_email",
  MUST_BE_A_VALID_URL: "common.validation_msg.must_be_url",
  SELECT_DEPARTMENT: "common.validation_msg.select_department",
  END_DATE_GREATER_THAN_OR_EQUAL_START_DATE: "common.validation_msg.end_date_greater_than_or_equal_start_date",
  ENTER_VALID_VALUE: "common.validation_msg.enter_valid_value",
  ENTER_GREATER_THAN_0: "common.validation_msg.enter_greater_than_0",
};
