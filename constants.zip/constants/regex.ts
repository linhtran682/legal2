export const REGEX_FORMAT_DATE = /^(\d{1,2})\/(0?[1-9]|1[0-2])\/(\d{4})$/;
export const REGEX_LINK =
  /^(https?:\/\/)?([\w-]+(\.[\w-]+)+)(\/[\w-._~:/?#[\]@!$&'()*+,;=]*)?$/;
export const THOUSAND_SEPARATOR = /\B(?=(\d{3})+(?!\d))/g;
