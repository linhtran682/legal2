import {
  AGENCY_ISSUED_ROOT_PATH,
  ASSIGNMENT_ROOT_PATH,
  CONFLICT_MANAGEMENT_ROOT_PATH,
  CURRENCY_ROOT_PATH,
  DEPARTMENT_MANAGEMENT_ROOT_PATH,
  DEPARTMENT_ROOT_PATH,
  DOCUMENT_MANAGEMENT_ROOT_PATH,
  DOCUMENT_REVIEW_ROOT_PATH,
  DOCUMENT_TYPE_ROOT_PATH,
  FIELD_ROOT_PATH,
  HELP_ROOT_PATH,
  LEGAL_ADVICE_ROOT_PATH,
  LEGAL_DOCUMENT_ROOT_PATH,
  LEGAL_VIOLATION_TRACKING_ROOT_PATH,
  MANAGE_CATEGORIES_ROOT_PATH,
  RELATIONSHIP_DISCLOSURE_ROOT_PATH,
  REMINDER_TEMPLATE_ROOT_PATH,
  ROLE_ROOT_PATH,
  SETTING_ROOT_PATH,
  STATISTIC_VIOLATION_TRACK_ROOT_PATH,
  STATISTICS_CONFLICT_MANAGEMENT,
  STATISTICS_DOCUMENT_MANAGEMENT,
  STATISTICS_DOCUMENT_REVIEW,
  STATISTICS_LEGAL_ADVICE,
  STATISTICS_LEGAL_DOCUMENT,
  STATISTICS_RELATIONSHIP_DISCLOSURE,
  STATISTICS_VISITATION,
  STATUS_ROOT_PATH,
  USER_ROOT_PATH,
  VISITATION_ROOT_PATH,
} from "./paths";

// Define the string constants
export const ModuleKeys = {
  LEGISLATION: "LEGISLATION",
  ADVISE: "ADVISE",
  DOCUMENT: "DOCUMENT",
  VIOLATE: "VIOLATE",
  DOCUMENT_MANAGEMENT: "DOCUMENT_MANAGEMENT",
  GIFT_MANAGEMENT: "GIFT_MANAGEMENT",
  CONFLICT_MANAGEMENT: "CONFLICT_MANAGEMENT",
  VISITATION: "VISITATION",
  DECLARE_RELATIONSHIP: "DECLARE_RELATIONSHIP",
  RECEPTION_MANAGEMENT: "RECEPTION_MANAGEMENT",
  REQUEST_REVIEW_DOCUMENT: "REQUEST_REVIEW_DOCUMENT",
};

export const TimeStatusKeys = {
  BEFORE: "BEFORE",
  EQUAL: "EQUAL",
  AFTER: "AFTER",
};

export const TimeUnitKeys = {
  MINUTE: "MINUTE",
  HOUR: "HOUR",
  DAY: "DAY",
  MONTH: "MONTH",
};

export const VendorResponseStatusKeys = {
  DATE_RECEIVED_FROM_VENDOR: "DATE_RECEIVED_FROM_VENDOR",
  VENDOR_RESPONSE_DATE: "VENDOR_RESPONSE_DATE",
  DEADLINE_FOR_SENDING: "DEADLINE_FOR_SENDING",
  DATE_REQUIRED_FOR_DEPARTMENT_RESPONSE:
    "DATE_REQUIRED_FOR_DEPARTMENT_RESPONSE",
  DATE_ISSUED: "DATE_ISSUED",
  EFFECTIVE_DATE: "EFFECTIVE_DATE",
  CONSULTING_PAYMENT_DEADLINE: "CONSULTING_PAYMENT_DEADLINE",
  ISSUE_DATE: "ISSUE_DATE",
  MODIFICATION_DATE: "MODIFICATION_DATE",
  EXPIRATION_DATE: "EXPIRATION_DATE",
  DEADLINE_FOR_RESPONSE: "DEADLINE_FOR_RESPONSE",
  APPROVE_DEADLINE: "APPROVE_DEADLINE",
  DEADLINE_IMPROVE_INFO: "DEADLINE_IMPROVE_INFO",
  DEADLINE_NEXT_ACTION: "DEADLINE_NEXT_ACTION",
  TRANSITION_PERIOD: "TRANSITION_PERIOD",
};

export const RemindReceiverTypeKeys = {
  DEPT_HEAD_OF_THE_SENDER: "DEPT_HEAD_OF_THE_SENDER",
  DIVISION_HEAD_OF_THE_SENDER: "DIVISION_HEAD_OF_THE_SENDER",
  RECEIVER: "RECEIVER",
  DEPT_HEAD_OF_THE_RECIPIENT: "DEPT_HEAD_OF_THE_RECIPIENT",
  DIVISION_HEAD_OF_THE_RECIPIENT: "DIVISION_HEAD_OF_THE_RECIPIENT",
  PEOPLE_INVOLVED: "PEOPLE_INVOLVED",
  RECEIVING_DEPARTMENT: "RECEIVING_DEPARTMENT",
  RECEIVED_TITLE: "RECEIVED_TITLE",
};

export const RemindValueTypeKeys = {
  NOW: "NOW",
  TIME: "TIME",
  STATUS: "STATUS",
};

// Build the maps using the constants
export const Module: Map<string, number> = new Map([
  [ModuleKeys.LEGISLATION, 1],
  [ModuleKeys.ADVISE, 2],
  [ModuleKeys.DOCUMENT, 3],
  [ModuleKeys.VIOLATE, 4],
  [ModuleKeys.DOCUMENT_MANAGEMENT, 5],
  [ModuleKeys.DECLARE_RELATIONSHIP, 8],
  [ModuleKeys.CONFLICT_MANAGEMENT, 7],
  [ModuleKeys.RECEPTION_MANAGEMENT, 8],
  [ModuleKeys.VISITATION, 6],
  [ModuleKeys.REQUEST_REVIEW_DOCUMENT, 9],
]);

export const ModuleR: Map<number, string> = new Map([
  [1, ModuleKeys.LEGISLATION],
  [2, ModuleKeys.ADVISE],
  [3, ModuleKeys.DOCUMENT],
  [4, ModuleKeys.VIOLATE],
  [5, ModuleKeys.DOCUMENT_MANAGEMENT],
  [8, ModuleKeys.DECLARE_RELATIONSHIP],
  [7, ModuleKeys.CONFLICT_MANAGEMENT],
  [8, ModuleKeys.RECEPTION_MANAGEMENT],
  [9, ModuleKeys.REQUEST_REVIEW_DOCUMENT],
]);

export const TimeStatus: Map<string, number> = new Map([
  [TimeStatusKeys.BEFORE, 0],
  [TimeStatusKeys.EQUAL, 1],
  [TimeStatusKeys.AFTER, 2],
]);

export const TimeStatusR: Map<number, string> = new Map([
  [0, TimeStatusKeys.BEFORE],
  [1, TimeStatusKeys.EQUAL],
  [2, TimeStatusKeys.AFTER],
]);

export const TimeUnit: Map<string, number> = new Map([
  [TimeUnitKeys.MINUTE, 1],
  [TimeUnitKeys.HOUR, 2],
  [TimeUnitKeys.DAY, 3],
]);
export const LegalTimeUnit: Map<string, number> = new Map([
  [TimeUnitKeys.DAY, 0],
  [TimeUnitKeys.MONTH, 1],
]);

export const TimeUnitR: Map<number, string> = new Map([
  [1, TimeUnitKeys.MINUTE],
  [2, TimeUnitKeys.HOUR],
  [3, TimeUnitKeys.DAY],
]);

export const VendorResponseStatus: Map<string, number> = new Map([
  [VendorResponseStatusKeys.DATE_RECEIVED_FROM_VENDOR, 1],
  [VendorResponseStatusKeys.VENDOR_RESPONSE_DATE, 2],
  [VendorResponseStatusKeys.DEADLINE_FOR_SENDING, 3],
  [VendorResponseStatusKeys.DATE_REQUIRED_FOR_DEPARTMENT_RESPONSE, 4],
  [VendorResponseStatusKeys.DATE_ISSUED, 5],
  [VendorResponseStatusKeys.EFFECTIVE_DATE, 6],
  [VendorResponseStatusKeys.CONSULTING_PAYMENT_DEADLINE, 3],
  [VendorResponseStatusKeys.ISSUE_DATE, 1],
  [VendorResponseStatusKeys.MODIFICATION_DATE, 2],
  [VendorResponseStatusKeys.EXPIRATION_DATE, 3],
  //
  [VendorResponseStatusKeys.TRANSITION_PERIOD, 7],
  [VendorResponseStatusKeys.DEADLINE_FOR_RESPONSE, 8],
  [VendorResponseStatusKeys.APPROVE_DEADLINE, 9],
  [VendorResponseStatusKeys.DEADLINE_IMPROVE_INFO, 4],
  [VendorResponseStatusKeys.DEADLINE_NEXT_ACTION, 6],
]);

export const VendorResponseStatusR: Map<number, string> = new Map([
  [1, VendorResponseStatusKeys.DATE_RECEIVED_FROM_VENDOR],
  [2, VendorResponseStatusKeys.VENDOR_RESPONSE_DATE],
  [3, VendorResponseStatusKeys.DEADLINE_FOR_SENDING],
  [4, VendorResponseStatusKeys.DATE_REQUIRED_FOR_DEPARTMENT_RESPONSE],
  [5, VendorResponseStatusKeys.DATE_ISSUED],
  [6, VendorResponseStatusKeys.EFFECTIVE_DATE],
  [3, VendorResponseStatusKeys.CONSULTING_PAYMENT_DEADLINE],
  [1, VendorResponseStatusKeys.ISSUE_DATE],
  [2, VendorResponseStatusKeys.MODIFICATION_DATE],
  [3, VendorResponseStatusKeys.EXPIRATION_DATE],
  //
  [7, VendorResponseStatusKeys.TRANSITION_PERIOD],
  [8, VendorResponseStatusKeys.DEADLINE_FOR_RESPONSE],
  [9, VendorResponseStatusKeys.APPROVE_DEADLINE],
  [4, VendorResponseStatusKeys.DEADLINE_IMPROVE_INFO],
  [6, VendorResponseStatusKeys.DEADLINE_NEXT_ACTION],
]);

export type RemindReceiverTypeI = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export const RemindReceiverType: Map<string, RemindReceiverTypeI> = new Map([
  [RemindReceiverTypeKeys.DEPT_HEAD_OF_THE_SENDER, 1],
  [RemindReceiverTypeKeys.DIVISION_HEAD_OF_THE_SENDER, 2],
  [RemindReceiverTypeKeys.RECEIVER, 3],
  [RemindReceiverTypeKeys.DEPT_HEAD_OF_THE_RECIPIENT, 4],
  [RemindReceiverTypeKeys.DIVISION_HEAD_OF_THE_RECIPIENT, 5],
  [RemindReceiverTypeKeys.PEOPLE_INVOLVED, 6],
  [RemindReceiverTypeKeys.RECEIVING_DEPARTMENT, 7],
  [RemindReceiverTypeKeys.RECEIVED_TITLE, 8],
]);

export const RemindValueType: Map<string, number> = new Map([
  [RemindValueTypeKeys.NOW, 0],
  [RemindValueTypeKeys.TIME, 1],
  [RemindValueTypeKeys.STATUS, 2],
]);

export interface ModuleFieldItem {
  module: number;
  fieldName: string;
}

export const ModuleFields = {
  LEGISLATION_NAME: {
    module: 1,
    fieldName: `${ModuleKeys.LEGISLATION}.column.documentName`,
  },
  ADVISE_NAME: {
    module: 2,
    fieldName: `${ModuleKeys.ADVISE}.field_name.name`,
  },
  VIOLATE_NAME: {
    module: 4,
    fieldName: `${ModuleKeys.VIOLATE}.field_name.name`,
  },
  DOCUMENT_MANAGEMENT: {
    module: 5,
    fieldName: `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.name`,
  },
  VISITATION_NAME: {
    module: 6,
    fieldName: `${ModuleKeys.VISITATION}.field_name.name`,
  },
  CONFLICT_MANAGEMENT: {
    module: 7,
    fieldName: `${ModuleKeys.CONFLICT_MANAGEMENT}.field_name.name`,
  },
  DOCUMENT_REVIEW: {
    module: 3,
    fieldName: `${ModuleKeys.DOCUMENT}.field_name.name`,
  },
  DECLARE_RELATIONSHIP: {
    module: 6,
    fieldName: `RELATION_SHIP_DISCLOSURE.label.documentName`,
  },
};
export const ModuleFieldsHelp: Record<
  string,
  { module: number; fieldName: string }
> = {
  SENDER: {
    module: 1,
    fieldName: "1_SENDER",
  },
  RECEIVER: {
    module: 1,
    fieldName: "1_RECEIVER",
  },
  STATUS: {
    module: 1,
    fieldName: "1_STATUS",
  },
  USER: {
    module: 1,
    fieldName: "1_USER",
  },
  DEPARTMENTS: {
    module: 1,
    fieldName: "1_DEPARTMENTS",
  },
  DEPARTMENT: {
    module: 1,
    fieldName: "1_DEPARTMENT",
  },
  EFFECTIVE_DATE: {
    module: 1,
    fieldName: "1_EFFECTIVE_DATE",
  },
  PUBLISH_DATE: {
    module: 1,
    fieldName: "1_PUBLISH_DATE",
  },
  DEPARTMENT_RESPONSE_DATE: {
    module: 1,
    fieldName: "1_DEPARTMENT_RESPONSE_DATE",
  },
  SUBMISSION_DEADLINE: {
    module: 1,
    fieldName: "1_SUBMISSION_DEADLINE",
  },
  VENDOR_RESPONSE_DATE: {
    module: 1,
    fieldName: "1_VENDOR_RESPONSE_DATE",
  },
  RECEIVE_FROM_VENDOR_DATE: {
    module: 1,
    fieldName: "1_RECEIVE_FROM_VENDOR_DATE",
  },
  FIELD: {
    module: 1,
    fieldName: "1_FIELD",
  },
  TEXT_NUMBER: {
    module: 1,
    fieldName: "1_TEXT_NUMBER",
  },
  AGENCY_ISSUED: {
    module: 1,
    fieldName: "1_AGENCY_ISSUED",
  },
  DOCUMENT_NAME: {
    module: 1,
    fieldName: "1_DOCUMENT_NAME",
  },
  DOCUMENT_TYPE: {
    module: 1,
    fieldName: "1_DOCUMENT_TYPE",
  },
  CONTENT: {
    module: 1,
    fieldName: "1_CONTENT",
  },
  PERSON_RESPONSIBLE: {
    module: 1,
    fieldName: "1_PERSON_RESPONSIBLE",
  },
  EXTEND_DATE_ALLOW_DEADLINE: {
    module: 1,
    fieldName: "1_EXTEND_DATE_ALLOW_DEADLINE",
  },
  EXTEND_DEADLINE: {
    module: 1,
    fieldName: "1_EXTEND_DEADLINE",
  },
  FOLDER_ID: {
    module: 5,
    fieldName: "5_FOLDER_ID",
  },
  DOCUMENT_TYPE_DOCUMENT_MANAGEMENT: {
    module: 5,
    fieldName: "5_DOCUMENT_TYPE",
  },
  NAME: {
    module: 5,
    fieldName: "5_NAME",
  },
  STATUS_DOCUMENT_MANAGEMENT: {
    module: 5,
    fieldName: "5_STATUS",
  },
  AGENCY_ISSUED_DOCUMENT_MANAGEMENT: {
    module: 5,
    fieldName: "5_AGENCY_ISSUED",
  },
  DATE_ISSUED: {
    module: 5,
    fieldName: "5_DATE_ISSUED",
  },
  DOCUMENT_CHANGE_DATE: {
    module: 5,
    fieldName: "5_DOCUMENT_CHANGE_DATE",
  },
  EXPIRY_DATE: {
    module: 5,
    fieldName: "5_EXPIRY_DATE",
  },
  NOTE_UPDATE_TIME: {
    module: 5,
    fieldName: "5_NOTE_UPDATE_TIME",
  },
  COMPANY_SCOPE: {
    module: 5,
    fieldName: "5_COMPANY_SCOPE",
  },
  DEPARTMENT_SCOPE: {
    module: 5,
    fieldName: "5_DEPARTMENT_SCOPE",
  },
  SENDER_DOCUMENT_MANAGEMENT: {
    module: 5,
    fieldName: "5_SENDER",
  },
  RECEIVERS: {
    module: 5,
    fieldName: "5_RECEIVERS",
  },
  RELATED_DEPARTMENTS: {
    module: 5,
    fieldName: "5_RELATED_DEPARTMENTS",
  },
  MANAGEMENT_DEPARTMENTS: {
    module: 5,
    fieldName: "5_MANAGEMENT_DEPARTMENTS",
  },
  LEGAL_ADVICE_NAME: {
    module: 2,
    fieldName: "2_LEGAL_ADVICE_NAME",
  },
  FIELD_ADVISE: {
    module: 2,
    fieldName: "2_FIELD",
  },
  REASON: {
    module: 2,
    fieldName: "2_REASON",
  },
  STATUS_ADVISE: {
    module: 2,
    fieldName: "2_STATUS",
  },
  DEADLINE: {
    module: 2,
    fieldName: "2_DEADLINE",
  },
  RETURN_DATE_ALL: {
    module: 2,
    fieldName: "2_RETURN_DATE_ALL",
  },
  SENDER_ADVISE: {
    module: 2,
    fieldName: "2_SENDER",
  },
  RECEIVER_ADVISE: {
    module: 2,
    fieldName: "2_RECEIVER",
  },
  ACTION: {
    module: 2,
    fieldName: "2_ACTION",
  },
  VENDOR_RESPONSE_DATE_ADVISE: {
    module: 2,
    fieldName: "2_VENDOR_RESPONSE_DATE",
  },
  SUMMARY_ISSUE: {
    module: 2,
    fieldName: "2_SUMMARY_ISSUE",
  },
  PROBLEM: {
    module: 2,
    fieldName: "2_PROBLEM",
  },
  OPINION: {
    module: 2,
    fieldName: "2_OPINION",
  },
  CONSULTING_DEADLINE_TYPE: {
    module: 2,
    fieldName: "2_CONSULTING_DEADLINE_TYPE",
  },
  URGENT_RESPONSE_DATE: {
    module: 2,
    fieldName: "2_URGENT_RESPONSE_DATE",
  },
  RECEIVER_USERS: {
    module: 2,
    fieldName: "2_RECEIVER_USERS",
  },
  SUPERVISOR_ADVISOR: {
    module: 2,
    fieldName: "2_SUPERVISOR_ADVISOR",
  },
  RELATED_USERS: {
    module: 2,
    fieldName: "2_RELATED_USERS",
  },
  CONTENT_ADVISE: {
    module: 2,
    fieldName: "2_CONTENT",
  },
  // YCKTTL
  RRD_SAMPLE_CONTRACT_CONTENT: {
    module: 3,
    fieldName: "3_SAMPLE_CONTRACT_CONTENT",
  },
};
export const ModuleFieldsPaths: Record<string, string> = {
  "1_SENDER": `${ModuleKeys.LEGISLATION}.field_name.sender`,
  "1_RECEIVER": `${ModuleKeys.LEGISLATION}.field_name.receiver`,
  "1_STATUS": `${ModuleKeys.LEGISLATION}.field_name.status`,
  "1_USER": `${ModuleKeys.LEGISLATION}.field_name.user`,
  "1_DEPARTMENTS": `${ModuleKeys.LEGISLATION}.field_name.departments`,
  "1_DEPARTMENT": `${ModuleKeys.LEGISLATION}.field_name.department`,
  "1_EFFECTIVE_DATE": `${ModuleKeys.LEGISLATION}.field_name.effectiveDate`,
  "1_PUBLISH_DATE": `${ModuleKeys.LEGISLATION}.field_name.publishDate`,
  "1_DEPARTMENT_RESPONSE_DATE": `${ModuleKeys.LEGISLATION}.field_name.departmentResponseDate`,
  "1_SUBMISSION_DEADLINE": `${ModuleKeys.LEGISLATION}.field_name.submissionDeadline`,
  "1_VENDOR_RESPONSE_DATE": `${ModuleKeys.LEGISLATION}.field_name.vendorResponseDate`,
  "1_RECEIVE_FROM_VENDOR_DATE": `${ModuleKeys.LEGISLATION}.field_name.receiveFromVendorDate`,
  "1_FIELD": `${ModuleKeys.LEGISLATION}.field_name.field`,
  "1_TEXT_NUMBER": `${ModuleKeys.LEGISLATION}.field_name.textNumber`,
  "1_AGENCY_ISSUED": `${ModuleKeys.LEGISLATION}.field_name.agencyIssued`,
  "1_DOCUMENT_NAME": `${ModuleKeys.LEGISLATION}.field_name.documentName`,
  "1_DOCUMENT_TYPE": `${ModuleKeys.LEGISLATION}.field_name.documentType`,
  "1_CONTENT": `${ModuleKeys.LEGISLATION}.field_name.content`,
  "1_PERSON_RESPONSIBLE": `${ModuleKeys.LEGISLATION}.field_name.personResponsible`,
  "1_EXTEND_DATE_ALLOW_DEADLINE": `${ModuleKeys.LEGISLATION}.field_name.extendDateAllowDeadline`,
  "1_EXTEND_DEADLINE": `${ModuleKeys.LEGISLATION}.field_name.extendDeadline`,

  "5_FOLDER_ID": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.folderId`,
  "5_DOCUMENT_TYPE_DOCUMENT_MANAGEMENT": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.documentType`,
  "5_NAME": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.name`,
  "5_STATUS_DOCUMENT_MANAGEMENT": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.status`,
  "5_AGENCY_ISSUED_DOCUMENT_MANAGEMENT": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.agencyIssued`,
  "5_DATE_ISSUED": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.dateIssued`,
  "5_DOCUMENT_CHANGE_DATE": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.documentChangeDate`,
  "5_EXPIRY_DATE": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.expiryDate`,
  "5_NOTE_UPDATE_TIME": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.noteUpdateTime`,
  "5_COMPANY_SCOPE": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.companyScope`,
  "5_DEPARTMENT_SCOPE": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.departmentScope`,
  "5_SENDER_DOCUMENT_MANAGEMENT": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.sender`,
  "5_RECEIVERS": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.receivers`,
  "5_RELATED_DEPARTMENTS": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.relatedDepartments`,
  "5_MANAGEMENT_DEPARTMENTS": `${ModuleKeys.DOCUMENT_MANAGEMENT}.field_name.managementDepartments`,

  "2_LEGAL_ADVICE_NAME": `legalAdvice.fields.legalAdviceName`,
  "2_FIELD_ADVISE": `legalAdvice.fields.field`,
  "2_REASON": `legalAdvice.fields.reason`,
  "2_STATUS_ADVISE": `legalAdvice.fields.status`,
  "2_DEADLINE": `legalAdvice.fields.deadline`,
  "2_RETURN_DATE_ALL": `legalAdvice.fields.returnDateAll`,
  "2_SENDER_ADVISE": `legalAdvice.fields.sender`,
  "2_RECEIVER_ADVISE": `legalAdvice.fields.receiver`,
  "2_ACTION": `legalAdvice.fields.action`,
  "2_VENDOR_RESPONSE_DATE_ADVISE": `legalAdvice.fields.vendorResponseDate`,
  "2_SUMMARY_ISSUE": `legalAdvice.fields.summaryIssue`,
  "2_PROBLEM": `legalAdvice.fields.problem`,
  "2_OPINION": `legalAdvice.fields.opinion`,
  "2_CONSULTING_DEADLINE_TYPE": `legalAdvice.fields.consultingDeadlineType`,
  "2_URGENT_RESPONSE_DATE": `legalAdvice.fields.urgentResponseDate`,
  "2_RECEIVER_USERS": `legalAdvice.fields.receiverUsers`,
  "2_SUPERVISOR_ADVISOR": `legalAdvice.fields.supervisorAdvisor`,
  "2_RELATED_USERS": `legalAdvice.fields.relatedUsers`,
  "2_CONTENT_ADVISE": `legalAdvice.fields.content`,

  "3_SAMPLE_CONTRACT_CONTENT": `DOCUMENT_REVIEW.field_name.contractContent`,
};
export const BACKGROUND_IMAGE =
  "https://s3-alpha-sig.figma.com/img/3914/12bc/5e6e8a2816d20510e85454c1d95f8f61?Expires=1721606400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=qM949~EM2QnLYwHwN85H6rbpFFWM-kvtMJ~7MrXl~7cH0ADXGL~6eoSaASA2rYr9LrihF3lOutyT3A0GNRRi8IcblRTvaqM4yQOKa67hoJzbdHNTPy6gvpR3xT8NrPOHmiCOaRMaXhJCD65GwFbyIYE1Ry~4oIlmXw7pdkp8t1kDPJLzf1qPD6TnMasSICj5w3cba9Djcq0Geb7r3jXqcyiqEwxS5W2t1sVmkCrJfKxKvDb4sN9tbxIShiYv05Z0kLN7-t5DGXSwGXbZh3GclVVx0fi5YQtteXOHVvVc0e9p-E3ZCk5dTGJ77togmFg6bgc4ahss8x~Gmw1tHtotUQ__";

export const UserStatus = {
  ACTIVE: "ACTIVE",
  DEACTIVE: "INACTIVE",
};

export const UserType = {
  GUEST: "GUEST",
  TMV: "TMV",
};

export const PermissionKey = {
  MANAGE_CATEGORIES: "manage_categories",
  DOCUMENT_TYPE: "document_type",
  FIELD: "field",
  AGENCY: "agency",
  REMINDER: "reminder",
  STATUS: "status",
  HELP: "help",
  CURRENCY: "currency",
  DEPARTMENT_MANAGEMENT: "department_management",
  DEPARTMENT: "department",
  ASSIGNMENT: "assignment",
  USER: "user",
  ROLE: "role",
  LEGAL_DOCUMENT: "legal_document",
  LEGAL_ADVICE: "legal_advice",
  DOCUMENT_MANAGEMENT: "document_management",
  VIOLATION_TRACKING: "violation_tracking",
  DOCUMENT_REVIEW: "request_review_document",
  FOLLOW_VIOLATION: "follow_violation",
  VISITATION: "visitation",
  CONFLICT_MANAGEMENT: "conflict_management",
  REQUEST_REVIEW_DOCUMENT: "request_review_document",
  RELATIONSHIP_DISCLOSURE: "relationship_disclosure",
  STATISTICS_LEGAL_DOCUMENT: "statistics-legal-doc",
  STATISTICS_LEGAL_ADVICE: "statistics-legal-adv",
  STATISTICS_DOCUMENT_MANAGEMENT: "statistics-document-mng",
  STATISTICS_DOCUMENT_REVIEW: "statistics-document-rev",
  STATISTICS_VISITATION: "statistics-visit",
  STATISTICS_CONFLICT_MANAGEMENT: "statistics-conflict-mng",
  STATISTICS_RELATIONSHIP_DISCLOSURE: "statistics-relationship-dis",
  STATISTICS_VIOLATION_TRACK: "statistics-violation-track",
  SETTING: "log_setting",
};

export const PermissionRouteMap = new Map<string, string>([
  [PermissionKey.MANAGE_CATEGORIES, MANAGE_CATEGORIES_ROOT_PATH],
  [PermissionKey.DOCUMENT_TYPE, DOCUMENT_TYPE_ROOT_PATH],
  [PermissionKey.FIELD, FIELD_ROOT_PATH],
  [PermissionKey.AGENCY, AGENCY_ISSUED_ROOT_PATH],
  [PermissionKey.REMINDER, REMINDER_TEMPLATE_ROOT_PATH],
  [PermissionKey.STATUS, STATUS_ROOT_PATH],
  [PermissionKey.HELP, HELP_ROOT_PATH],
  [PermissionKey.CURRENCY, CURRENCY_ROOT_PATH],
  [PermissionKey.DEPARTMENT_MANAGEMENT, DEPARTMENT_MANAGEMENT_ROOT_PATH],
  [PermissionKey.DEPARTMENT, DEPARTMENT_ROOT_PATH],
  [PermissionKey.ASSIGNMENT, ASSIGNMENT_ROOT_PATH],
  [PermissionKey.USER, USER_ROOT_PATH],
  [PermissionKey.ROLE, ROLE_ROOT_PATH],
  [PermissionKey.LEGAL_DOCUMENT, LEGAL_DOCUMENT_ROOT_PATH],
  [PermissionKey.LEGAL_ADVICE, LEGAL_ADVICE_ROOT_PATH],
  [PermissionKey.DOCUMENT_MANAGEMENT, DOCUMENT_MANAGEMENT_ROOT_PATH],
  [PermissionKey.VIOLATION_TRACKING, LEGAL_VIOLATION_TRACKING_ROOT_PATH],
  [PermissionKey.CONFLICT_MANAGEMENT, CONFLICT_MANAGEMENT_ROOT_PATH],
  [PermissionKey.DOCUMENT_REVIEW, DOCUMENT_REVIEW_ROOT_PATH],
  [PermissionKey.VISITATION, VISITATION_ROOT_PATH],
  [PermissionKey.RELATIONSHIP_DISCLOSURE, RELATIONSHIP_DISCLOSURE_ROOT_PATH],
  [PermissionKey.SETTING, SETTING_ROOT_PATH],
  [PermissionKey.STATISTICS_VIOLATION_TRACK, STATISTIC_VIOLATION_TRACK_ROOT_PATH],
  [PermissionKey.STATISTICS_LEGAL_DOCUMENT, STATISTICS_LEGAL_DOCUMENT],
  [PermissionKey.STATISTICS_LEGAL_ADVICE, STATISTICS_LEGAL_ADVICE],
  [PermissionKey.STATISTICS_DOCUMENT_MANAGEMENT, STATISTICS_DOCUMENT_MANAGEMENT],
  [PermissionKey.STATISTICS_DOCUMENT_REVIEW, STATISTICS_DOCUMENT_REVIEW],
  [PermissionKey.STATISTICS_VISITATION, STATISTICS_VISITATION],
  [PermissionKey.STATISTICS_CONFLICT_MANAGEMENT, STATISTICS_CONFLICT_MANAGEMENT],
  [PermissionKey.STATISTICS_RELATIONSHIP_DISCLOSURE, STATISTICS_RELATIONSHIP_DISCLOSURE],
]);

export const Permission = {
  [PermissionKey.MANAGE_CATEGORIES]: "menu.manageCategories",
  [PermissionKey.DOCUMENT_TYPE]: "menu.documentType",
  [PermissionKey.FIELD]: "menu.field",
  [PermissionKey.AGENCY]: "menu.agencyIssued",
  [PermissionKey.REMINDER]: "menu.reminder",
  [PermissionKey.STATUS]: "menu.status",
  [PermissionKey.HELP]: "menu.help",
  [PermissionKey.CURRENCY]: "menu.currency",
  [PermissionKey.DEPARTMENT_MANAGEMENT]: "menu.departmentManagement",
  [PermissionKey.DEPARTMENT]: "menu.department",
  [PermissionKey.ASSIGNMENT]: "menu.assignment",
  [PermissionKey.USER]: "menu.userPermission",
  [PermissionKey.ROLE]: "menu.rolePermission",
  [PermissionKey.LEGAL_DOCUMENT]: "menu.legalDocument",
  [PermissionKey.LEGAL_ADVICE]: "menu.legalAdvice",
  [PermissionKey.DOCUMENT_MANAGEMENT]: "menu.documentManagement",
  [PermissionKey.VIOLATION_TRACKING]: "menu.violationTracking",
  [PermissionKey.CONFLICT_MANAGEMENT]: "menu.conflictManagement",
  [PermissionKey.DOCUMENT_REVIEW]: "menu.documentReviewRequest",
  [PermissionKey.VISITATION]: "menu.visitation",
  [PermissionKey.REQUEST_REVIEW_DOCUMENT]: "menu.requestReviewDocument",
  [PermissionKey.CONFLICT_MANAGEMENT]: "menu.conflictManagement",
  [PermissionKey.RELATIONSHIP_DISCLOSURE]: "menu.relationshipDisclosure",
  [PermissionKey.STATISTICS_LEGAL_DOCUMENT]: "menu.statisticLegalDocument",
  [PermissionKey.STATISTICS_LEGAL_ADVICE]: "menu.statisticLegalAdvice",
  [PermissionKey.STATISTICS_DOCUMENT_MANAGEMENT]: "menu.statisticDocumentManagement",
  [PermissionKey.STATISTICS_DOCUMENT_REVIEW]: "menu.statisticDocumentReview",
  [PermissionKey.STATISTICS_VISITATION]: "menu.statisticVisitation",
  [PermissionKey.STATISTICS_CONFLICT_MANAGEMENT]: "menu.statisticDocumentConflict",
  [PermissionKey.STATISTICS_RELATIONSHIP_DISCLOSURE]: "menu.statisticDocumentRelationship",
  [PermissionKey.STATISTICS_VIOLATION_TRACK]: "menu.statisticViolationTracking",
  [PermissionKey.SETTING]: "menu.setting",
};

export const enum PermissionAction {
  READ = "read",
  WRITE = "write",
}

export const RoleSystem = ["Read Only", "Administrator", "User"];
export const RoleAdminSystem = [
  PermissionKey.LEGAL_DOCUMENT,
  PermissionKey.LEGAL_ADVICE,
  PermissionKey.VIOLATION_TRACKING,
  PermissionKey.VISITATION,
  PermissionKey.REQUEST_REVIEW_DOCUMENT,
  PermissionKey.CONFLICT_MANAGEMENT,
  PermissionKey.RELATIONSHIP_DISCLOSURE,
];

export const LegalDocumentUserRoleKey = {
  PIC_LC: "PIC_LC",
  PERSON_CHARGE: "PERSON_CHARGE", // Người chịu trách nhiệm
  RELATED_DEPARTMENT: "RELATED_DEPARTMENT", // Phòng ban liên quan
  EVALUATED_DEPARTMENT: "EVALUATED_DEPARTMENT", // Phòng ban đánh giá
  HEAD_EVALUATED_DEPARTMENT: "HEAD_EVALUATED_DEPARTMENT", // Head của phòng ban đánh giá
  PERSON_RESPONSIBLE_FORWARD: "PERSON_RESPONSIBLE_FORWARD", // Người phụ trách chuyển tiếp
  RELATED_PERSON: "RELATED_PERSON", // Người liên quan
};

export const LegalDocumentUserStatusKey = {
  ASSIGNMENT: "ASSIGNMENT", //Phân công
  VENDOR: "VENDOR", // Yêu cầu vendor làm bảng khuyến nghị
  SENT: "SENT", // Cần gửi đi
  REQUEST_REVIEW: "REQUEST_REVIEW", // Yêu cầu đánh giá
  RESPONSE_LC: "RESPONSE_LC", // Phản hồi cho L&C
  DONE: "DONE", // Done
  NEXT_ACTION: "NEXT_ACTION", // Next action
  NEXT_ACTION_REVIEW: "NEXT_ACTION_EVALUATE", // Next action: Đã đánh giá
  EVALUATE: "EVALUATE", // Đánh giá
  EVALUATE_REQUEST_APPROVAL: "EVALUATE_REQUEST_APPROVAL", // Đánh giá: Yêu cầu duyệt
  EVALUATE_APPROVAL: "EVALUATE_APPROVAL", // Đánh giá: Duyệt
  NEXT_ACTION_REQUEST_APPROVAL: "NEXT_ACTION_REQUEST_APPROVAL", // Next action: Yêu cầu duyệt
  NEXT_ACTION_APPROVAL: "NEXT_ACTION_APPROVAL", // Next action: Duyệt
  MONITOR_NEXT_ACTION: "MONITOR_NEXT_ACTION", // Theo dõi Next action
  ASSIGNMENT_RESPONSIBILITIES: "ASSIGNMENT_RESPONSIBILITIES", // Phân công trách nhiệm
  REQUEST_VENDOR: "REQUEST_VENDOR" // Yêu cầu vendor làm bảng khuyến nghị
};

export const ActionButtonKey = {
  CREATE_NEW: "CREATE_NEW", // Tạo mới
  REQUEST_EVALUATION: "REQUEST_EVALUATION", // Y/C đánh giá
  DEPARTMENT_EVALUATION_UPDATE: "DEPARTMENT_EVALUATION_UPDATE", // Phòng ban đánh giá update Trạng thái VBPL
  LEGAL_REQUEST_EVALUATION: "LEGAL_REQUEST_EVALUATION", // VBPL được Y/C đánh giá
  EVALUATION: "EVALUATION", // Đánh giá
  REQUEST_APPROVAL: "REQUEST_APPROVAL", // Y/C Duyệt
  EXTEND_TIME: "EXTEND_TIME", // Gia hạn thời gian
  GENERATE_NEXT_ACTION: "GENERATE_NEXT_ACTION", // Phát sinh Next action
  REQUEST_MEETING: "REQUEST_MEETING", // Y/C họp
  HEAD_UPDATE_STATUS: "HEAD_UPDATE_STATUS", // Head update trạng thái
  APPROVAL: "APPROVAL", // Duyệt
  LC_FEEDBACK: "LC_FEEDBACK", // Phản hồi L&C
  LC_PIC_UPDATE_STATUS: "LC_PIC_UPDATE_STATUS", // PIC L&C update trạng thái: Theo dõi Next action (khác DONE)
  FORWARD: "FORWARD", // Chuyển tiếp
  REVOKE: "REVOKE", // Thu hồi
  FEEDBACK: "FEEDBACK", // Phản hồi
  DONE: "DONE", // Hoàn thành
};

export const ButtonConditionKey = {
  RECALL_NO_IMPACT: "RECALL_NO_IMPACT", // Thu hồi chưa có bên thứ 3 tác động VBPL
  RECALL_IMPACT: "RECALL_IMPACT", // Thu hồi có bên thứ 3 tác động VBPL
  FEEDBACK_NO_RESPONSE: "FEEDBACK_NO_RESPONSE", // Phản hồi (chưa có phản hồi PBLQ)
  FEEDBACK_RESPONSE: "FEEDBACK_RESPONSE", // Phản hồi (có phản hồi PBLQ)
  EVALUATION_APPROVAL: "EVALUATION_APPROVAL", // TT: Y/C đánh giá, Đánh giá, Đánh giá: Duyệt
  EVALUATION_APPROVAL_REQUEST: "EVALUATION_APPROVAL_REQUEST", // TT: Đánh giá Yêu cầu duyệt
  NEXT_ACTION_EVALUATION_REQUEST: "NEXT_ACTION_EVALUATION_REQUEST", // TT: Yêu cầu ĐG
  NEXT_ACTION_EVALUATION: "NEXT_ACTION_EVALUATION", // TT: Đánh giá
  // NEXT_ACTION_APPROVAL_REQUEST: "NEXT_ACTION_APPROVAL_REQUEST", // TT: Phát sinh Next action, Đánh giá: Duyệt, Next action: Yêu cầu duyệt,
  OTHER_STATUS_NOT_EVALUATED: "OTHER_STATUS_NOT_EVALUATED", // Các trạng thái khác và chưa được [Đánh giá]
  OTHER_STATUS_EVALUATED: "OTHER_STATUS_EVALUATED", // Các trạng thái khác và được [Đánh giá]
  LC_FEEDBACK_REQUEST: "LC_FEEDBACK_REQUEST", // Y/C đánh giá, Đánh giá, Next action, Đánh giá: Từ chối, Đánh giá yêu cầu duyệt,Next action: Yêu cầu duyệt,
  EVALUATED_DECLINED: "EVALUATED_DECLINED", // Đánh giá: từ chối, Next action: Từ chối
  EVALUATED_REQUEST: "EVALUATED_REQUEST", // Đánh giá yêu cầu duyệt, Đánh giá: Duyệt, Phản hồi L&C
  NEXT_ACTION_EVALUATED: "NEXT_ACTION_EVALUATED", // Next action: Yêu cầu duyệt, Next action: Duyệt, Next action: Đã đánh giá
};

export const StatusNextActionsKey = {
  GENERATE_NEXT_ACTION: "GENERATE_NEXT_ACTION", // Phát sinh Next action
  REQUEST_APPROVAL: "REQUEST_APPROVAL", // Yêu cầu duyệt
  NEXT_ACTION_APPROVAL: "NEXT_ACTION_APPROVAL", // Next action: Duyệt
  NEXT_ACTION_REJECT: "NEXT_ACTION_REJECT", // Next action: Từ chối
  MONITOR_NEXT_ACTION: "MONITOR_NEXT_ACTION", // Theo dõi Next action
  FEEDBACK_LC: "FEEDBACK_LC", // Phản hồi L&C
  FEEDBACK_EVALUATED: "FEEDBACK_EVALUATED", // Phản hồi đánh giá
  COMPLETE_EVALUATED: "COMPLETE_EVALUATED", // Hoàn thành đánh giá
};

export const StatusEvaluatedTableKey = {
  REQUEST_EVALUATE: "REQUEST_EVALUATE",
  EVALUATE: "EVALUATE",
  REQUEST_APPROVAL: "REQUEST_APPROVAL",
  APPROVAL: "APPROVAL",
  NEXT_ACTION: "NEXT_ACTION",
  REQUEST_APPROVAL_NEXT_ACTION: "REQUEST_APPROVAL_NEXT_ACTION",
  APPROVAL_NEXT_ACTION: "APPROVAL_NEXT_ACTION",
  FEEDBACK_LC: "FEEDBACK_LC",
  FEEDBACK_EVALUATE: "FEEDBACK_EVALUATE",
  FINISH_EVALUATE: "FINISH_EVALUATE",
  FOLLOW_NEXT_ACTION: "FOLLOW_NEXT_ACTION",
  NEXT_ACTION_REJECT: "NEXT_ACTION_REJECT",
  EVALUATE_REJECT: "EVALUATE_REJECT",
};

export const StatusTabConfirmKey = {
  REVIEW_APPROVAL_REQUEST: "REVIEW_APPROVAL_REQUEST",
  NEXT_ACTION_APPROVAL_REQUEST: "NEXT_ACTION_APPROVAL_REQUEST",
  REVIEW_APPROVED: "REVIEW_APPROVED",
  REVIEW_REJECTED: "REVIEW_REJECTED",
  NEXT_ACTION_APPROVED: "NEXT_ACTION_APPROVED",
  NEXT_ACTION_REJECTED: "NEXT_ACTION_REJECTED",
};

export const StatusEvaluatedTable: Map<string, number> = new Map([
  [StatusEvaluatedTableKey.REQUEST_EVALUATE, 0],
  [StatusEvaluatedTableKey.EVALUATE, 1],
  [StatusEvaluatedTableKey.REQUEST_APPROVAL, 2],
  [StatusEvaluatedTableKey.APPROVAL, 3],
  [StatusEvaluatedTableKey.NEXT_ACTION, 4],
  [StatusEvaluatedTableKey.REQUEST_APPROVAL_NEXT_ACTION, 5],
  [StatusEvaluatedTableKey.APPROVAL_NEXT_ACTION, 6],
  [StatusEvaluatedTableKey.FEEDBACK_LC, 7],
  [StatusEvaluatedTableKey.FEEDBACK_EVALUATE, 8],
  [StatusEvaluatedTableKey.FINISH_EVALUATE, 9],
  [StatusEvaluatedTableKey.FOLLOW_NEXT_ACTION, 10],
  [StatusEvaluatedTableKey.NEXT_ACTION_REJECT, 11],
  [StatusEvaluatedTableKey.EVALUATE_REJECT, 12],
]);

export const StatusEvaluatedTableR: Map<number, string> = new Map([
  [0, StatusEvaluatedTableKey.REQUEST_EVALUATE],
  [1, StatusEvaluatedTableKey.EVALUATE],
  [2, StatusEvaluatedTableKey.REQUEST_APPROVAL],
  [3, StatusEvaluatedTableKey.APPROVAL],
  [4, StatusEvaluatedTableKey.NEXT_ACTION],
  [5, StatusEvaluatedTableKey.REQUEST_APPROVAL_NEXT_ACTION],
  [6, StatusEvaluatedTableKey.APPROVAL_NEXT_ACTION],
  [7, StatusEvaluatedTableKey.FEEDBACK_LC],
  [8, StatusEvaluatedTableKey.FEEDBACK_EVALUATE],
  [9, StatusEvaluatedTableKey.FINISH_EVALUATE],
  [10, StatusEvaluatedTableKey.FOLLOW_NEXT_ACTION],
  [11, StatusEvaluatedTableKey.NEXT_ACTION_REJECT],
  [12, StatusEvaluatedTableKey.EVALUATE_REJECT],
]);

export const StatusTabConfirm: Map<string, number> = new Map([
  [StatusTabConfirmKey.REVIEW_APPROVAL_REQUEST, 0],
  [StatusTabConfirmKey.NEXT_ACTION_APPROVAL_REQUEST, 1],
  [StatusTabConfirmKey.REVIEW_APPROVED, 2],
  [StatusTabConfirmKey.REVIEW_REJECTED, 3],
  [StatusTabConfirmKey.NEXT_ACTION_APPROVED, 4],
  [StatusTabConfirmKey.NEXT_ACTION_REJECTED, 5],
]);

export const StatusTabConfirmR: Map<number, string> = new Map([
  [0, StatusTabConfirmKey.REVIEW_APPROVAL_REQUEST],
  [1, StatusTabConfirmKey.NEXT_ACTION_APPROVAL_REQUEST],
  [2, StatusTabConfirmKey.REVIEW_APPROVED],
  [3, StatusTabConfirmKey.REVIEW_REJECTED],
  [4, StatusTabConfirmKey.NEXT_ACTION_APPROVED],
  [5, StatusTabConfirmKey.NEXT_ACTION_REJECTED],
]);

export const LegalDocumentUserRole: Map<string, number> = new Map([
  [LegalDocumentUserRoleKey.PIC_LC, 1],
  [LegalDocumentUserRoleKey.PERSON_CHARGE, 2],
  [LegalDocumentUserRoleKey.RELATED_DEPARTMENT, 3],
  [LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT, 4],
  [LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT, 5],
  [LegalDocumentUserRoleKey.PERSON_RESPONSIBLE_FORWARD, 6],
  [LegalDocumentUserRoleKey.RELATED_PERSON, 7],
]);

export const LegalDocumentUserRoleR: Map<number, string> = new Map([
  [1, LegalDocumentUserRoleKey.PIC_LC], // PIC L&C
  [2, LegalDocumentUserRoleKey.PERSON_CHARGE], // Người chịu trách nhiệm
  [3, LegalDocumentUserRoleKey.RELATED_DEPARTMENT], //Phòng ban liên quan
  [4, LegalDocumentUserRoleKey.EVALUATED_DEPARTMENT], // Phòng ban đánh giá
  [5, LegalDocumentUserRoleKey.HEAD_EVALUATED_DEPARTMENT], // Head của phòng ban đánh giá
  [6, LegalDocumentUserRoleKey.PERSON_RESPONSIBLE_FORWARD], // Người phụ trách chuyển tiếp
  [7, LegalDocumentUserRoleKey.RELATED_PERSON], // Người liên quan
]);

export const LegalDocumentUserStatusR: Map<number, string> = new Map([
  [1, LegalDocumentUserStatusKey.ASSIGNMENT],
  [2, LegalDocumentUserStatusKey.VENDOR],
  [3, LegalDocumentUserStatusKey.SENT],
  [4, LegalDocumentUserStatusKey.REQUEST_REVIEW],
  [5, LegalDocumentUserStatusKey.RESPONSE_LC],
  [6, LegalDocumentUserStatusKey.DONE],
  [7, LegalDocumentUserStatusKey.NEXT_ACTION],
  [8, LegalDocumentUserStatusKey.NEXT_ACTION_REVIEW],
  [9, LegalDocumentUserStatusKey.EVALUATE],
  [10, LegalDocumentUserStatusKey.EVALUATE_REQUEST_APPROVAL],
  [11, LegalDocumentUserStatusKey.EVALUATE_APPROVAL],
  [12, LegalDocumentUserStatusKey.NEXT_ACTION_REQUEST_APPROVAL],
  [13, LegalDocumentUserStatusKey.NEXT_ACTION_APPROVAL],
  [14, LegalDocumentUserStatusKey.MONITOR_NEXT_ACTION],
]);

export const LegalDocumentStatusContent: Map<string, string> = new Map([
  [LegalDocumentUserStatusKey.ASSIGNMENT, "Phân công"],
  [LegalDocumentUserStatusKey.VENDOR, "Yêu cầu vendor làm bảng khuyến nghị"],
  [LegalDocumentUserStatusKey.SENT, "Cần gửi đi"],
  [LegalDocumentUserStatusKey.REQUEST_REVIEW, "Yêu cầu đánh giá"],
  [LegalDocumentUserStatusKey.RESPONSE_LC, "Phản hồi L&C"],
  [LegalDocumentUserStatusKey.DONE, "Hoàn thành"],
  [LegalDocumentUserStatusKey.NEXT_ACTION, "Next action"],
  [LegalDocumentUserStatusKey.NEXT_ACTION_REVIEW, "Next action: Đã đánh giá"],
  [LegalDocumentUserStatusKey.EVALUATE, "Đánh giá"],
  [
    LegalDocumentUserStatusKey.EVALUATE_REQUEST_APPROVAL,
    "Đánh giá: Yêu cầu duyệt",
  ],
  [LegalDocumentUserStatusKey.EVALUATE_APPROVAL, "Đánh giá: Duyệt"],
  [
    LegalDocumentUserStatusKey.NEXT_ACTION_REQUEST_APPROVAL,
    "Next action: Yêu cầu duyệt",
  ],
  [LegalDocumentUserStatusKey.NEXT_ACTION_APPROVAL, "Next action: Duyệt"],
  [LegalDocumentUserStatusKey.MONITOR_NEXT_ACTION, "Theo dõi Next action"],
  [LegalDocumentUserStatusKey.ASSIGNMENT_RESPONSIBILITIES, "Phân công trách nhiệm"],
  [LegalDocumentUserStatusKey.REQUEST_VENDOR, "Yêu cầu vendor làm bảng khuyến nghị"],
]);

export const LegalDocumentUserStatus: Map<string, number> = new Map([
  [LegalDocumentUserStatusKey.ASSIGNMENT, 1],
  [LegalDocumentUserStatusKey.VENDOR, 2],
  [LegalDocumentUserStatusKey.SENT, 3],
  [LegalDocumentUserStatusKey.REQUEST_REVIEW, 4],
  [LegalDocumentUserStatusKey.RESPONSE_LC, 5],
  [LegalDocumentUserStatusKey.DONE, 6],
  [LegalDocumentUserStatusKey.NEXT_ACTION, 7],
  [LegalDocumentUserStatusKey.NEXT_ACTION_REVIEW, 8],
  [LegalDocumentUserStatusKey.EVALUATE, 9],
  [LegalDocumentUserStatusKey.EVALUATE_REQUEST_APPROVAL, 10],
  [LegalDocumentUserStatusKey.EVALUATE_APPROVAL, 11],
  [LegalDocumentUserStatusKey.NEXT_ACTION_REQUEST_APPROVAL, 12],
  [LegalDocumentUserStatusKey.NEXT_ACTION_APPROVAL, 13],
  [LegalDocumentUserStatusKey.MONITOR_NEXT_ACTION, 14],
]);

export const ActionButtonR: Map<number, string> = new Map([
  [1, ActionButtonKey.CREATE_NEW],
  [2, ActionButtonKey.REQUEST_EVALUATION],
  [3, ActionButtonKey.DEPARTMENT_EVALUATION_UPDATE],
  [4, ActionButtonKey.LEGAL_REQUEST_EVALUATION],
  [5, ActionButtonKey.EVALUATION],
  [6, ActionButtonKey.REQUEST_APPROVAL],
  [7, ActionButtonKey.EXTEND_TIME],
  [8, ActionButtonKey.GENERATE_NEXT_ACTION],
  [9, ActionButtonKey.REQUEST_MEETING],
  [10, ActionButtonKey.HEAD_UPDATE_STATUS],
  [11, ActionButtonKey.APPROVAL],
  [12, ActionButtonKey.LC_FEEDBACK],
  [13, ActionButtonKey.LC_PIC_UPDATE_STATUS],
  [14, ActionButtonKey.FORWARD],
  [15, ActionButtonKey.REVOKE],
  [16, ActionButtonKey.FEEDBACK],
  [17, ActionButtonKey.DONE],
]);

export const ActionButton: Map<string, number> = new Map([
  [ActionButtonKey.CREATE_NEW, 1],
  [ActionButtonKey.REQUEST_EVALUATION, 2],
  [ActionButtonKey.DEPARTMENT_EVALUATION_UPDATE, 3],
  [ActionButtonKey.LEGAL_REQUEST_EVALUATION, 4],
  [ActionButtonKey.EVALUATION, 5],
  [ActionButtonKey.REQUEST_APPROVAL, 6],
  [ActionButtonKey.EXTEND_TIME, 7],
  [ActionButtonKey.GENERATE_NEXT_ACTION, 8],
  [ActionButtonKey.REQUEST_MEETING, 9],
  [ActionButtonKey.HEAD_UPDATE_STATUS, 10],
  [ActionButtonKey.APPROVAL, 11],
  [ActionButtonKey.LC_FEEDBACK, 12],
  [ActionButtonKey.LC_PIC_UPDATE_STATUS, 13],
  [ActionButtonKey.FORWARD, 14],
  [ActionButtonKey.REVOKE, 15],
  [ActionButtonKey.FEEDBACK, 16],
  [ActionButtonKey.DONE, 17],
]);

export const ButtonCondition: Map<string, number> = new Map([
  [ButtonConditionKey.RECALL_NO_IMPACT, 1],
  [ButtonConditionKey.RECALL_IMPACT, 2],
  [ButtonConditionKey.FEEDBACK_NO_RESPONSE, 3],
  [ButtonConditionKey.FEEDBACK_RESPONSE, 4],
  [ButtonConditionKey.EVALUATION_APPROVAL, 5],
  [ButtonConditionKey.EVALUATION_APPROVAL_REQUEST, 6],
  [ButtonConditionKey.NEXT_ACTION_EVALUATION_REQUEST, 7],
  [ButtonConditionKey.NEXT_ACTION_EVALUATION, 8],
  [ButtonConditionKey.OTHER_STATUS_NOT_EVALUATED, 13],
  [ButtonConditionKey.OTHER_STATUS_EVALUATED, 14],
  [ButtonConditionKey.LC_FEEDBACK_REQUEST, 10],
  [ButtonConditionKey.EVALUATED_DECLINED, 11],
  [ButtonConditionKey.EVALUATED_REQUEST, 12],
  [ButtonConditionKey.NEXT_ACTION_EVALUATED, 15],
]);

export const ButtonConditionR: Map<number, string> = new Map([
  [1, ButtonConditionKey.RECALL_NO_IMPACT],
  [2, ButtonConditionKey.RECALL_IMPACT],
  [3, ButtonConditionKey.FEEDBACK_NO_RESPONSE],
  [4, ButtonConditionKey.FEEDBACK_RESPONSE],
  [5, ButtonConditionKey.EVALUATION_APPROVAL],
  [6, ButtonConditionKey.EVALUATION_APPROVAL_REQUEST],
  [7, ButtonConditionKey.NEXT_ACTION_EVALUATION_REQUEST],
  [8, ButtonConditionKey.NEXT_ACTION_EVALUATION],
  [13, ButtonConditionKey.OTHER_STATUS_NOT_EVALUATED],
  [14, ButtonConditionKey.OTHER_STATUS_EVALUATED],
  [10, ButtonConditionKey.LC_FEEDBACK_REQUEST],
  [11, ButtonConditionKey.EVALUATED_DECLINED],
  [12, ButtonConditionKey.EVALUATED_REQUEST],
  [15, ButtonConditionKey.NEXT_ACTION_EVALUATED],
]);

export const StatusNextActions: Map<string, number> = new Map([
  [StatusNextActionsKey.GENERATE_NEXT_ACTION, 4],
  [StatusNextActionsKey.REQUEST_APPROVAL, 5],
  [StatusNextActionsKey.NEXT_ACTION_APPROVAL, 6],
  [StatusNextActionsKey.NEXT_ACTION_REJECT, 11],
  [StatusNextActionsKey.MONITOR_NEXT_ACTION, 10],
  [StatusNextActionsKey.FEEDBACK_LC, 7],
  [StatusNextActionsKey.FEEDBACK_EVALUATED, 8],
  [StatusNextActionsKey.COMPLETE_EVALUATED, 9],
]);

export const StatusNextActionsR: Map<number, string> = new Map([
  [4, StatusNextActionsKey.GENERATE_NEXT_ACTION],
  [5, StatusNextActionsKey.REQUEST_APPROVAL],
  [6, StatusNextActionsKey.NEXT_ACTION_APPROVAL],
  [11, StatusNextActionsKey.NEXT_ACTION_REJECT],
  [10, StatusNextActionsKey.MONITOR_NEXT_ACTION],
  [7, StatusNextActionsKey.FEEDBACK_LC],
  [8, StatusNextActionsKey.FEEDBACK_EVALUATED],
  [9, StatusNextActionsKey.COMPLETE_EVALUATED],
]);

export const enum MIME_TYPES {
  XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}

export const DocumentManagementKey = {
  CREATE_NEW: "createNew",
  SUPPLEMENTING_INFORMATION: "supplementingInformation",
  CHANGE_DOCUMENT: "changeDocument",
  DONE: "done",
};
export const DocumentUserRole: Map<string, number> = new Map([
  [DocumentManagementKey.CREATE_NEW, 1],
  [DocumentManagementKey.SUPPLEMENTING_INFORMATION, 2],
  [DocumentManagementKey.CHANGE_DOCUMENT, 3],
  [DocumentManagementKey.DONE, 4],
]);

export const reverseDocumentStatus = new Map([
  [1, DocumentManagementKey.CREATE_NEW], // 1 => 'Create New'
  [2, DocumentManagementKey.SUPPLEMENTING_INFORMATION], // 2 => 'Supplementing Information'
  [3, DocumentManagementKey.CHANGE_DOCUMENT], // 3 => 'Change Document'
  [4, DocumentManagementKey.DONE], // 4 => 'Done'
]);

export const OwnerActionDocumentManagementKey = {
  CREATE_NEW: "createNew",
  FORWARD: "forward",
  EXTEND_DEADLINE: "extendDeadline",
  REQUEST_ADDITIONAL: "requestAdditional",
};

export const OwnerActionDocumentManagement: Map<string, number> = new Map([
  [OwnerActionDocumentManagementKey.CREATE_NEW, 1],
  [OwnerActionDocumentManagementKey.REQUEST_ADDITIONAL, 2],
  [OwnerActionDocumentManagementKey.EXTEND_DEADLINE, 3],
  [OwnerActionDocumentManagementKey.FORWARD, 4],
]);

export const OwnerRoleDocumentManagementKey = {
  AUTHORIZED_PERSON: "authorizedPerson", // Người được phân quyền
  ASSIGNMENT_DOUCMENT: "forward", // Assign trên Tài liệu (chỉ sửa, xóa tài liệu assign)
  ASSIGNMENT_POPUP: "extendDeadline", //Assign trên pop-up (chỉ sửa, xóa tài liệu assign)
  FORWARD: "forward", //Người chuyển tiếp
  VIEWER: "viewer", //Các user khác không có liên quan tới kho
};

export const OwnerRoleDocumentManagement: Map<string, number> = new Map([
  [OwnerRoleDocumentManagementKey.AUTHORIZED_PERSON, 1],
  [OwnerRoleDocumentManagementKey.ASSIGNMENT_DOUCMENT, 2],
  [OwnerRoleDocumentManagementKey.ASSIGNMENT_POPUP, 3],
  [OwnerRoleDocumentManagementKey.FORWARD, 4],
  [OwnerRoleDocumentManagementKey.VIEWER, 5],
]);

export const OwnerRoleDocumentManagementR: Map<number, string> = new Map([
  [1, OwnerRoleDocumentManagementKey.AUTHORIZED_PERSON],
  [2, OwnerRoleDocumentManagementKey.ASSIGNMENT_DOUCMENT],
  [3, OwnerRoleDocumentManagementKey.ASSIGNMENT_POPUP],
  [4, OwnerRoleDocumentManagementKey.FORWARD],
  [5, OwnerRoleDocumentManagementKey.VIEWER],
]);

// Legal Advice
export const LegalAdviceStatusKey = {
  REQUEST_ADVICE: "REQUEST_ADVICE", // Yêu cầu tư vấn
  REQUEST_ADDITIONAL: "REQUEST_ADDITIONAL", // Yêu cầu bổ sung thông tin
  ADDITIONAL_INFORMATION: "ADDITIONAL_INFORMATION", // Đã bổ sung thông tin
  ASSIGNMENT: "ASSIGNMENT", // Phân công
  REQUEST_VENDOR: "REQUEST_VENDOR", // Yêu cầu vendor tư vấn
  ADVICE: "ADVICE", // Tư vấn
  SENT_SUPERVISOR: "SENT_SUPERVISOR", // Gửi tới giám sát tư vấn
  SUPERVISOR_CONSULTED: "SUPERVISOR_CONSULTED", // Giám sát đã tư vấn
  CONSULTATION_COMPLETED: "CONSULTATION_COMPLETED", // Hoàn thành tư vấn
  FEEDBACK_ADVICE: "FEEDBACK_ADVICE", // Phản hồi tư vấn
  FEEDBACK: "FEEDBACK", // Phản hồi
  DONE: "DONE", // Done
};

export const LegalAdviceUserRoleKey = {
  PIC: "PIC",
  L_C: "L_C",
  HEAD_OF_L_C: "HEAD_OF_L_C",
  SUPERVISOR: "SUPERVISOR",
  RELATED_PERSON: "RELATED_PERSON",
  FORWARD: "FORWARD",
  VIEWER: "VIEWER",
};

export const LegalAdviceActionsBtnKey = {
  CREATE_NEW: "create", // Tạo mới
  RECALL: "recall", // Thu hồi
  FORWARD: "forward", // Chuyển tiếp
  FEEDBACK: "feedback", // Phản hồi
  REQUEST_MEETING: "requestMeeting", // Y/C họp
  SEND_MAIL: "sendMail",
  REQUEST_TIME_EXTENSION: "requestTimeExtension", // Yêu cầu gia hạn thời gian
  CONFIRM: "confirm", // Xác nhận
  ASSIGNMENT: "assignment", // Phân công
  REQUEST_VENDOR: "requestVendor",
  FEEDBACK_ADVISE: "feedbackAdvise", // Phản hồi tư vấn,
  REQUEST_ADDITIONAL: "requestAdditional", // Yêu cầu bổ sung thông tin
  ADVISE: "advise", // Tư vấn
  DONE: "done", // Hoàn thành
  NOT_AVAILABLE: "notAvailable", // Đang không ở trạng thái của role
  SHARE: "share",
  RECHECK: "recheck",
  INFO_ADDED: "infoAdded",
};

export const LegalAdviceStatusContent: Map<string, string> = new Map([
  [LegalAdviceStatusKey.REQUEST_ADVICE, "Yêu cầu tư vấn"],
  [LegalAdviceStatusKey.REQUEST_ADDITIONAL, "Yêu cầu bổ sung thông tin"],
  [LegalAdviceStatusKey.ADDITIONAL_INFORMATION, "Đã bổ sung thông tin"],
  [LegalAdviceStatusKey.ASSIGNMENT, "Phân công"],
  [LegalAdviceStatusKey.REQUEST_VENDOR, "Yêu cầu vendor tư vấn"],
  [LegalAdviceStatusKey.ADVICE, "Tư vấn"],
  [LegalAdviceStatusKey.SENT_SUPERVISOR, "Yêu cầu giám sát tư vấn"],
  [LegalAdviceStatusKey.SUPERVISOR_CONSULTED, "Giám sát đã tư vấn"],
  [LegalAdviceStatusKey.CONSULTATION_COMPLETED, "Đã tư vấn"],
  [LegalAdviceStatusKey.FEEDBACK_ADVICE, "Phản hồi tư vấn"],
  [LegalAdviceStatusKey.FEEDBACK, "Phản hồi"],
  [LegalAdviceStatusKey.DONE, "Hoàn thành"],
]);

export const LegalAdviceStatus: Map<string, number> = new Map([
  [LegalAdviceStatusKey.REQUEST_ADVICE, 1002],
  [LegalAdviceStatusKey.REQUEST_ADDITIONAL, 1003],
  [LegalAdviceStatusKey.ADDITIONAL_INFORMATION, 1004],
  [LegalAdviceStatusKey.ASSIGNMENT, 1005],
  [LegalAdviceStatusKey.REQUEST_VENDOR, 1006],
  [LegalAdviceStatusKey.ADVICE, 1007],
  [LegalAdviceStatusKey.SENT_SUPERVISOR, 1008],
  [LegalAdviceStatusKey.SUPERVISOR_CONSULTED, 1009],
  [LegalAdviceStatusKey.CONSULTATION_COMPLETED, 1010],
  [LegalAdviceStatusKey.FEEDBACK, 1011],
  [LegalAdviceStatusKey.DONE, 1013],
]);

export const LegalAdviceStatusR: Map<number, string> = new Map([
  [1002, LegalAdviceStatusKey.REQUEST_ADVICE],
  [1003, LegalAdviceStatusKey.REQUEST_ADDITIONAL],
  [1004, LegalAdviceStatusKey.ADDITIONAL_INFORMATION],
  [1005, LegalAdviceStatusKey.ASSIGNMENT],
  [1006, LegalAdviceStatusKey.REQUEST_VENDOR],
  [1007, LegalAdviceStatusKey.ADVICE],
  [1008, LegalAdviceStatusKey.SENT_SUPERVISOR],
  [1009, LegalAdviceStatusKey.SUPERVISOR_CONSULTED],
  [1010, LegalAdviceStatusKey.CONSULTATION_COMPLETED],
  [1011, LegalAdviceStatusKey.FEEDBACK],
  [1013, LegalAdviceStatusKey.DONE],
]);

export const LegalAdviceUserRole: Map<string, number> = new Map([
  [LegalAdviceUserRoleKey.PIC, 1],
  [LegalAdviceUserRoleKey.L_C, 2],
  [LegalAdviceUserRoleKey.HEAD_OF_L_C, 3],
  [LegalAdviceUserRoleKey.SUPERVISOR, 4],
  [LegalAdviceUserRoleKey.RELATED_PERSON, 5],
  [LegalAdviceUserRoleKey.VIEWER, 6],
  [LegalAdviceUserRoleKey.FORWARD, 7],
]);

export const LegalAdviceUserRoleR: Map<number, string> = new Map([
  [1, LegalAdviceUserRoleKey.PIC],
  [2, LegalAdviceUserRoleKey.L_C],
  [3, LegalAdviceUserRoleKey.HEAD_OF_L_C],
  [4, LegalAdviceUserRoleKey.SUPERVISOR],
  [5, LegalAdviceUserRoleKey.RELATED_PERSON],
  [6, LegalAdviceUserRoleKey.VIEWER],
  [7, LegalAdviceUserRoleKey.FORWARD],
]);

export const LegalAdviceActionsBtn = new Map<string, number | number[]>([
  [LegalAdviceActionsBtnKey.CREATE_NEW, 1],
  [LegalAdviceActionsBtnKey.RECALL, 11],
  [LegalAdviceActionsBtnKey.FORWARD, 6],
  [LegalAdviceActionsBtnKey.FEEDBACK, 19],
  [LegalAdviceActionsBtnKey.REQUEST_MEETING, 13],
  [LegalAdviceActionsBtnKey.SEND_MAIL, 12],
  [LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION, 9],
  [LegalAdviceActionsBtnKey.CONFIRM, 20],
  [LegalAdviceActionsBtnKey.ASSIGNMENT, 5],
  [LegalAdviceActionsBtnKey.REQUEST_VENDOR, 15],
  [LegalAdviceActionsBtnKey.FEEDBACK_ADVISE, 4],
  [LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL, 7],
  [LegalAdviceActionsBtnKey.ADVISE, [3, 16]],
  [LegalAdviceActionsBtnKey.DONE, 10],
  [LegalAdviceActionsBtnKey.NOT_AVAILABLE, 0],
]);

export const LegalAdviceActionsBtnR: Map<number, string> = new Map([
  [1, LegalAdviceActionsBtnKey.CREATE_NEW],
  [11, LegalAdviceActionsBtnKey.RECALL],
  [6, LegalAdviceActionsBtnKey.FORWARD],
  [19, LegalAdviceActionsBtnKey.FEEDBACK],
  [13, LegalAdviceActionsBtnKey.REQUEST_MEETING],
  [12, LegalAdviceActionsBtnKey.SEND_MAIL],
  [9, LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION],
  [20, LegalAdviceActionsBtnKey.CONFIRM],
  [5, LegalAdviceActionsBtnKey.ASSIGNMENT],
  [15, LegalAdviceActionsBtnKey.REQUEST_VENDOR],
  [4, LegalAdviceActionsBtnKey.FEEDBACK_ADVISE],
  [7, LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL],
  [3, LegalAdviceActionsBtnKey.ADVISE],
  [16, LegalAdviceActionsBtnKey.ADVISE],
  [10, LegalAdviceActionsBtnKey.DONE],
  [0, LegalAdviceActionsBtnKey.NOT_AVAILABLE],
]);

export const LegalAdviceBtnCondition: Map<string, string> = new Map([
  [LegalAdviceActionsBtnKey.RECALL, "otherActionsAvailableFlag"],
  [LegalAdviceActionsBtnKey.FEEDBACK, "feedbackAvailableFlag"],
  [
    LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
    "requestTimeExtensionAvailableFlag",
  ],
  [LegalAdviceActionsBtnKey.DONE, "legalAdviceDoneFlag"],
]);

//Conflict
export const ConflictActionsBtnKey = {
  RECALL: "recall", // Thu hồi
  FORWARD: "forward", // Chuyển tiếp
  REQUEST_MEETING: "requestMeeting", // Y/C họp
  SEND_MAIL: "sendMail",
  REQUEST_TIME_EXTENSION: "requestTimeExtension", // Yêu cầu gia hạn thời gian
  CONFIRM: "confirm", // Xác nhận
  REQUEST_ADDITIONAL: "informationRequest", // Yêu cầu bổ sung thông tin
  DONE: "finish", // Hoàn thành
  REQUEST_EVALUATE: "requestEvaluate", // yêu cầu đánh giá
  REQUEST_CONFIRM: "requestApprove", // yêu cầu duyệt
  CONFLICT_MONITORING: "follow", // theo doi xung dot
  FEEDBACK: "feedback", // Phản hồi
  TIME_EXTENSION_EVALUATE: "timeExtensionEvaluate", // GIA HẠN THỜI GIAN ĐÁNH GIÁ
  TIME_EXTENTSION_CONFIRM: "timeExtensionConfirm", //GIA HẠN THỜI GIAN XÁC NHẬN
  EVALUATE: "evaluate", // Đánh giá
  APPROVE: "approve",
  SHARE: "share",
};
export const ConflictManagementRoleKey = {
  EMPLOYEE_CONFLICT: "EMPLOYEE_CONFLICT", // Nhân viên kê khai xung đột
  DEPT_HEAD_EMPLOYEE_CONFLICT: "DEPT_HEAD_EMPLOYEE_CONFLICT", // Dept head nhân viên kê kkhai xung đột
  LC: "LC", // L&C
  DEPT_DIVISION_LC: "DEPT_DIVISION_LC", // Dept/Dvision Head L&C
  RELATED_DEPARTMENT: "RELATED_DEPARTMENT", // Phòng ban liên quan
};

export const ConflictManagementRole: Map<string, number> = new Map([
  [ConflictManagementRoleKey.EMPLOYEE_CONFLICT, 1],
  [ConflictManagementRoleKey.DEPT_HEAD_EMPLOYEE_CONFLICT, 2],
  [ConflictManagementRoleKey.LC, 3],
  [ConflictManagementRoleKey.DEPT_DIVISION_LC, 4],
  [ConflictManagementRoleKey.RELATED_DEPARTMENT, 5],
]);

export const ConflictManagementRoleR: Map<number, string> = new Map([
  [1, ConflictManagementRoleKey.EMPLOYEE_CONFLICT],
  [2, ConflictManagementRoleKey.DEPT_HEAD_EMPLOYEE_CONFLICT],
  [3, ConflictManagementRoleKey.LC],
  [4, ConflictManagementRoleKey.DEPT_DIVISION_LC],
  [5, ConflictManagementRoleKey.RELATED_DEPARTMENT],
]);

export const NatureConflictKey = {
  OWNER_SHIP: "OWNER_SHIP",
  PARTICIPATION: "PARTICIPATION",
  EXECUTION: "EXECUTION",
  PROVIDING_TMV: "PROVIDING_TMV",
  PERFORMING_ANOTHER: "PERFORMING_ANOTHER",
  ORTHER: "ORTHER",
};

export const NatureConflict: Map<string, number> = new Map([
  [NatureConflictKey.OWNER_SHIP, 0],
  [NatureConflictKey.PARTICIPATION, 1],
  [NatureConflictKey.EXECUTION, 2],
  [NatureConflictKey.PROVIDING_TMV, 3],
  [NatureConflictKey.PERFORMING_ANOTHER, 4],
  [NatureConflictKey.ORTHER, 5],
]);

export const NatureConflictR: Map<number, string> = new Map([
  [0, NatureConflictKey.OWNER_SHIP],
  [1, NatureConflictKey.PARTICIPATION],
  [2, NatureConflictKey.EXECUTION],
  [3, NatureConflictKey.PROVIDING_TMV],
  [4, NatureConflictKey.PERFORMING_ANOTHER],
  [5, NatureConflictKey.ORTHER],
]);

export const ConflictManagementStatusKey = {
  REQUEST_ADDITIONAL: "REQUEST_ADDITIONAL",
  INFORMATION_PROVIDED: "INFORMATION_PROVIDED",
  REQUEST_CONFIRMATION: "REQUEST_CONFIRMATION",
  CONFIRM: "CONFIRM",
  CONFIRM_REJECTED: "CONFIRM_REJECTED",
  REQUEST_REVIEW: "REQUEST_REVIEW",
  REVIEW_COMMENTED: "REVIEW_COMMENTED",
  REVIEW_REJECTED: "REVIEW_REJECTED",
  REQUEST_APPROVAL: "REQUEST_APPROVAL",
  APPROVAL: "APPROVAL",
  APPROVAL_REQUEST_FOLLOW: "APPROVAL_REQUEST_FOLLOW",
  APPROVAL_REJECTED: "APPROVAL_REJECTED",
  CONFLICT_MONITORING: "CONFLICT_MONITORING",
  COMPLETED: "COMPLETED",
  FEEDBACK: "FEEDBACK",
};

export const ConflictManagementStatusContent: Map<string, string> = new Map([
  [ConflictManagementStatusKey.REQUEST_ADDITIONAL, "Yêu cầu bổ sung thông tin"],
  [ConflictManagementStatusKey.INFORMATION_PROVIDED, "Đã bổ sung thông tin"],
  [ConflictManagementStatusKey.REQUEST_CONFIRMATION, "Yêu cầu xác nhận"],
  [ConflictManagementStatusKey.CONFIRM, "Xác nhận"],
  [ConflictManagementStatusKey.CONFIRM_REJECTED, "Xác nhận: Từ chối"],
  [ConflictManagementStatusKey.REQUEST_REVIEW, "Yêu cầu đánh giá"],
  [ConflictManagementStatusKey.REVIEW_COMMENTED, "Đã đánh giá/nhận xét"],
  [ConflictManagementStatusKey.REVIEW_REJECTED, "Đánh giá: Từ chối"],
  [ConflictManagementStatusKey.REQUEST_APPROVAL, "Yêu cầu Duyệt"],
  [ConflictManagementStatusKey.APPROVAL, "Đã ký duyệt"],
  [
    ConflictManagementStatusKey.APPROVAL_REQUEST_FOLLOW,
    "Đã ký duyệt + Yêu cầu theo dõi",
  ],
  [ConflictManagementStatusKey.APPROVAL_REJECTED, "Ký duyệt: Từ chối"],
  [ConflictManagementStatusKey.CONFLICT_MONITORING, "Theo dõi xung đột"],
  [ConflictManagementStatusKey.COMPLETED, "Hoàn thành"],
  [ConflictManagementStatusKey.FEEDBACK, "Phản hồi"],
]);

// Relationship disclosure
export const RelationshipDisclosureRoleKey = {
  RELATION_SHIP_DECLATION: "STAFF_RELATION_SHIP_DECLATION", // Nhân viên kê khai quan hệ
  DEPT_HEAD_RELATION_SHIP_DECLATION: "DEPT_HEAD_RELATION_SHIP_DECLATION", // Dept head nhân viên kê khai quan hệ
  LC: "LC", // L&C
  DEPT_DIVISION_LC: "DEPT_DIVISION_LC", // Dept/Dvision Head L&C
  RELATED_DEPARTMENT: "RELATED_DEPARTMENT", // Phòng ban liên quan
};

export const RelationshipDisclosureRole: Map<string, number> = new Map([
  [RelationshipDisclosureRoleKey.RELATION_SHIP_DECLATION, 1],
  [RelationshipDisclosureRoleKey.DEPT_HEAD_RELATION_SHIP_DECLATION, 2],
  [RelationshipDisclosureRoleKey.LC, 3],
  [RelationshipDisclosureRoleKey.DEPT_DIVISION_LC, 4],
  [RelationshipDisclosureRoleKey.RELATED_DEPARTMENT, 5],
]);

export const RelationshipDisclosureRoleR: Map<number, string> = new Map([
  [1, RelationshipDisclosureRoleKey.RELATION_SHIP_DECLATION],
  [2, RelationshipDisclosureRoleKey.DEPT_HEAD_RELATION_SHIP_DECLATION],
  [3, RelationshipDisclosureRoleKey.LC],
  [4, RelationshipDisclosureRoleKey.DEPT_DIVISION_LC],
  [5, RelationshipDisclosureRoleKey.RELATED_DEPARTMENT],
]);

export const RelationshipDisclosureStatusKey = {
  REQUEST_ADDITIONAL: "REQUEST_ADDITIONAL",
  INFORMATION_PROVIDED: "INFORMATION_PROVIDED",
  REQUEST_CONFIRMATION: "REQUEST_CONFIRMATION",
  CONFIRM: "CONFIRM",
  CONFIRM_REJECTED: "CONFIRM_REJECTED",
  REQUEST_REVIEW: "REQUEST_REVIEW",
  REVIEW_COMMENTED: "REVIEW_COMMENTED",
  REVIEW_REJECTED: "REVIEW_REJECTED",
  REQUEST_APPROVAL: "REQUEST_APPROVAL",
  APPROVAL_REJECTED: "APPROVAL_REJECTED",
  APPROVAL: "APPROVAL",
  APPROVAL_REQUEST_FOLLOW: "APPROVAL_REQUEST_FOLLOW",
  DECLARATION_MONITORING: "DECLARATION_MONITORING",
  DONE: "DONE",
  FEEDBACK: "FEEDBACK",
};

export const RelationshipDisclosureStatusContent: Map<string, string> = new Map(
  [
    [RelationshipDisclosureStatusKey.REQUEST_CONFIRMATION, "Yêu cầu xác nhận"],
    [
      RelationshipDisclosureStatusKey.REQUEST_ADDITIONAL,
      "Yêu cầu bổ sung thông tin",
    ],
    [
      RelationshipDisclosureStatusKey.INFORMATION_PROVIDED,
      "Đã bổ sung thông tin",
    ],
    [RelationshipDisclosureStatusKey.CONFIRM, "Xác nhận"],
    [RelationshipDisclosureStatusKey.CONFIRM_REJECTED, "Xác nhận: Từ chối"],
    [RelationshipDisclosureStatusKey.REQUEST_REVIEW, "Yêu cầu đánh giá"],
    [RelationshipDisclosureStatusKey.REVIEW_REJECTED, "Đánh giá: Từ chối"],
    [RelationshipDisclosureStatusKey.REVIEW_COMMENTED, "Đã đánh giá/nhận xét"],
    [RelationshipDisclosureStatusKey.REQUEST_APPROVAL, "Yêu cầu Duyệt"],
    [RelationshipDisclosureStatusKey.APPROVAL_REJECTED, "Ký duyệt: Từ chối"],
    [RelationshipDisclosureStatusKey.APPROVAL, "Đã duyệt"],
    [
      RelationshipDisclosureStatusKey.APPROVAL_REQUEST_FOLLOW,
      "Đã duyệt + Yêu cầu theo dõi thêm",
    ],
    [
      RelationshipDisclosureStatusKey.DECLARATION_MONITORING,
      "Theo dõi kết quả",
    ],
    [RelationshipDisclosureStatusKey.DONE, "Hoàn thành"],
    [ConflictManagementStatusKey.FEEDBACK, "Phản hồi"],
  ]
);

export const enum ReferenceFileTypes {
  LEGAL_DOCUMENT = 1,
  LEGAL_DOCUMENT_TAB = 2,
  LEGAL_ADVICE = 3,
  LEGAL_ADVICE_TAB = 4,
  LEGAL_ADVICE_ADVISE = 5,
  DM_DOCUMENT = 6,
  VIOLATION_TRACKING = 7,
  VIOLATION_TRACKING_ADVICE = 8,
  VIOLATION_NEXT_ACTION = 9,
  VIOLATION_FEEDBACK_ADVISE = 10,
  REQUEST_REVIEW_DOCUMENT_ATTACHMENT = 11,
  BACKDATE_APPROVAL_EMAIL_ATTACHMENT = 12,
  SAMPLE_CONTRACT_ATTACHMENT = 13,
  REQUEST_REVIEW_DOCUMENT_INSPECTION_ATTACHMENT = 14,
  REQUEST_REVIEW_DOCUMENT_ATTACHMENT_TAB = 15,
  LEGAL_CHECK_SHEET = 16,
  VISITATION_DETAIL = 17,
}

export type TypeActionRole = {
  typeBtn: string;
  disable?: boolean;
};

export const KNOWN_ERROR_CODES = [
  4000000, 4000001, 4010000, 4030000, 4030001, 4030002, 4050000, 4010001,
  4010002, 4010003, 5000000, 4010004, 4010005, 4090000, 4090101, 4090102,
  4090103, 4090104, 4090105, 4090106, 4090107, 4090108, 4090109, 4090110,
  4090111, 4090112, 4090113, 4090114, 4090099, 4010006, 40900140, 40900141,
  40900142, 40900143, 40900901, 4030004,
];
