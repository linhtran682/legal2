import {
  FollowViolationDetail,
  ViolationNextActionResponse,
} from "@/models/follow_violation/FormType";
import { uniqueCheck } from "@/utils";
import { TypeActionRole } from "./general";

export const FollowViolationStatusKey = {
  REQUEST_ADVICE: "REQUEST_ADVICE", // Yêu cầu tư vấn
  CONFIRM: "CONFIRM", // Xác nhận
  ASSIGNMENT: "ASSIGNMENT", // Phân công
  REQUEST_VENDOR: "REQUEST_VENDOR", // Yêu cầu vendor tư vấn
  REQUEST_SUPERVISOR: "requestSupervisor", // Yêu cầu giám sát tư vấn
  REQUEST_ADDITIONAL: "REQUEST_ADDITIONAL", // Yêu cầu bổ sung thông tin
  ADDITIONAL_INFORMATION: "ADDITIONAL_INFORMATION", // Đã bổ sung thông tin
  ADVICE: "ADVICE", // Tư vấn
  ADVISING: "advising", // Đang thực hiện tư vấn
  SENT_SUPERVISOR: "SENT_SUPERVISOR", // Gửi tới Giám sát
  SUPERVISION_ADVISED: "SUPERVISION_ADVISED", // Giám sát đã tư vấn
  DONE_ADVICE: "DONE_ADVICE", // Done: Tư vấn
  FEEDBACK_ADVICE: "FEEDBACK_ADVICE", // Phản hồi tư vấn
  ADVICE_FINISHED: "ADVICE_FINISHED", // Hoàn thành tư vấn
  REPORT_AND_NEXT_ACTION: "REPORT_AND_NEXT_ACTION", // Báo cáo + Next action
  REQUEST_APPROVAL_DEPT_HEAD: "REQUEST_APPROVAL_DEPT_HEAD", // Yêu cầu Dept/Division Head duyệt
  APPROVAL_DEPT_HEAD: "APPROVAL_DEPT_HEAD", // Dept/Division Head: Duyệt
  DENIED_DEPT_HEAD: "DENIED_DEPT_HEAD", // Dept/Division Head: Từ chối
  REQUEST_APPROVAL_GROUP_HEAD: "REQUEST_APPROVAL_GROUP_HEAD", // Yêu cầu Group Head duyệt
  GROUP_HEAD_APPROVE: "GROUP_HEAD_APPROVE", // Group Head: Duyệt
  DENIED_GROUP_HEAD: "DENIED_GROUP_HEAD", // Group Head: Từ chối
  REQUEST_APPROVAL_TOP_HEAD: "REQUEST_APPROVAL_TOP_HEAD", // Yêu cầu TOP duyệt
  TOP_HEAD_APPROVAL: "TOP_HEAD_APPROVAL", // TOP: duyệt
  DENIED_TOP_HEAD: "DENIED_TOP_HEAD", // TOP: Từ chối
  DONE_NEXT_ACTION: "DONE_NEXT_ACTION", // Done: Next action
  FEEDBACK_NEXT_ACTION: "FEEDBACK_NEXT_ACTION", // Phản hồi Next action
  TRACK_NEXT_ACTION: "TRACK_NEXT_ACTION", // Theo dõi Next action
  FINISH: "FINISH", // Hoàn thành
};

export const FollowViolationUserRoleKey = {
  PIC: "PIC",
  L_C: "L_C",
  SUPERVISOR: "SUPERVISOR",
  RELATED_PERSON: "RELATED_PERSON",
  DEPT_HEAD: "DEPT_HEAD",
  GROUP_HEAD: "GROUP_HEAD",
  TOP_HEAD: "TOP_HEAD",
  VIEWER: "VIEWER",
};

export const FollowViolationActionsBtnKey = {
  NOT_AVAILABLE: "notAvailable", // Đang không ở trạng thái của role
  CREATE_VIOLATION_TRACKING_DOCUMENT: "createViolationTrackingDocument", // Tạo mới
  UPDATE_VIOLATION_TRACKING_DOCUMENT: "updateViolationTrackingDocument", // Cập nhật
  SEND_MAIL: "sendMail",
  REQUEST_MEETING: "requestMeeting", // Yêu cầu họp
  TIME_EXTENSION_REQUEST: "timeExtensionRequest", // Yêu cầu gia hạn thời gian
  ACCEPT_TIME_EXTENSION: "acceptTimeExtension", // Chấp nhận gia hạn thời gian
  TIME_EXTENSION: "timeExtension", // Gia hạn thời gian
  RECALL: "recall", // Thu hồi
  CREATE_NEXT_ACTION: "createNextAction", // Tạo next action
  UPDATE_NEXT_ACTION: "updateNextAction", // Cập nhật next action
  FEEDBACK: "feedback", // Phản hồi
  FEEDBACK_LC: "feedbackLc", // Phản hồi L&C
  FORWARD: "forward", // Chuyển tiếp
  MEETING: "meeting", // Họp
  SHARE: "share", // Chia sẻ
  ASSIGNMENT: "assignment", // Phân công
  REQUEST_VENDOR: "requestVendor", // Yêu cầu vendor tư vấn
  REQUEST_SUPERVISOR: "requestSupervisor", // Yêu cầu giám sát tư vấn
  REQUEST_ADDITIONAL: "requestAdditional", // Yêu cầu bổ sung thông tin
  ADDITIONAL_INFORMATION: "additionalInformation", // Đã bổ sung thông tin
  ADVICE: "advice", // Tư vấn
  ADVISING: "advising", // Đang thực hiện tư vấn
  SENT_SUPERVISOR: "sentSupervisor", // Gửi tới Giám sát
  CONFIRM: "confirm", // Xác nhận
  UPDATE_ADVICE: "updateAdvice", // Cập nhật tư vấn
  FINISH: "finish", // Hoàn thành
  // REQUEST_APPROVAL_DEPT_HEAD: "requestApprovalDeptHead", // Yêu cầu Dept/Division Head duyệt
  // REQUEST_APPROVAL_GROUP_HEAD: "requestApprovalGroupHead", // Yêu cầu Group Head duyệt
  // REQUEST_APPROVAL_TOP_HEAD: "requestApprovalTopHead", // Yêu cầu Top duyệt
  // APPROVAL_DEPT_HEAD: "approvalDeptHead", // Dept/Division Head duyệt
  // APPROVAL_GROUP_HEAD: "approvalGroupHead", // Group Head duyệt
  // APPROVAL_TOP_HEAD: "approvalTopHead", // Top duyệt
  // DENIED_DEPT_HEAD: "deniedDeptHead", // Dept/Division Head từ chối
  // DENIED_GROUP_HEAD: "deniedGroupHead", // Group Head từ chối
  // DENIED_TOP_HEAD: "deniedTopHead", // Top từ chối
  TRACK_NEXT_ACTION: "trackNextAction", // Theo dõi next action
  FEEDBACK_NEXT_ACTION: "feedbackNextAction", // Phản hồi next action
  REQUEST_USER: "requestUser", // Yêu cầu user
  DONE_ADVICE: "doneAdvice", // Done: tư vấn
  ADVICE_FINISHED: "adviceFinished", // Hoàn thành tư vấn
  FEEDBACK_ADVICE: "feedbackAdvice", // Phản hồi tư vấn
  CONFIRM_FINISH_ADVICE: "confirmFinishAdvice", // Xác nhận hoàn thành tư vấn
  REQUEST_RECHECK: "requestRecheck", // Yêu cầu kiểm tra lại
  REQUEST_APPROVAL_NEXT_ACTION_AGAIN: "requestApprovalNextActionAgain", // Yêu cầu duyệt Next action lại
};

export const FollowViolationStatus: Map<string, number> = new Map([
  [FollowViolationStatusKey.REQUEST_ADVICE, 1],
  [FollowViolationStatusKey.CONFIRM, 28],
  [FollowViolationStatusKey.ASSIGNMENT, 2],
  [FollowViolationStatusKey.REQUEST_VENDOR, 3],
  [FollowViolationStatusKey.REQUEST_SUPERVISOR, 27],
  [FollowViolationStatusKey.REQUEST_ADDITIONAL, 4],
  [FollowViolationStatusKey.ADDITIONAL_INFORMATION, 5],
  [FollowViolationStatusKey.ADVICE, 6],
  [FollowViolationStatusKey.ADVISING, 26],
  [FollowViolationStatusKey.SENT_SUPERVISOR, 8],
  [FollowViolationStatusKey.SUPERVISION_ADVISED, 9],
  [FollowViolationStatusKey.DONE_ADVICE, 7],
  [FollowViolationStatusKey.FEEDBACK_ADVICE, 10],
  [FollowViolationStatusKey.ADVICE_FINISHED, 11],
  [FollowViolationStatusKey.REPORT_AND_NEXT_ACTION, 13],
  [FollowViolationStatusKey.REQUEST_APPROVAL_DEPT_HEAD, 14],
  [FollowViolationStatusKey.APPROVAL_DEPT_HEAD, 15],
  [FollowViolationStatusKey.DENIED_DEPT_HEAD, 16],
  [FollowViolationStatusKey.REQUEST_APPROVAL_GROUP_HEAD, 17],
  [FollowViolationStatusKey.GROUP_HEAD_APPROVE, 18],
  [FollowViolationStatusKey.DENIED_GROUP_HEAD, 19],
  [FollowViolationStatusKey.REQUEST_APPROVAL_TOP_HEAD, 20],
  [FollowViolationStatusKey.TOP_HEAD_APPROVAL, 21],
  [FollowViolationStatusKey.DENIED_TOP_HEAD, 22],
  [FollowViolationStatusKey.DONE_NEXT_ACTION, 23],
  [FollowViolationStatusKey.FEEDBACK_NEXT_ACTION, 24],
  [FollowViolationStatusKey.TRACK_NEXT_ACTION, 25],
  [FollowViolationStatusKey.FINISH, 12],
]);

export const FollowViolationStatusR: Map<number, string> = new Map([
  [1, FollowViolationStatusKey.REQUEST_ADVICE],
  [28, FollowViolationStatusKey.CONFIRM],
  [2, FollowViolationStatusKey.ASSIGNMENT],
  [3, FollowViolationStatusKey.REQUEST_VENDOR],
  [27, FollowViolationStatusKey.REQUEST_SUPERVISOR],
  [4, FollowViolationStatusKey.REQUEST_ADDITIONAL],
  [5, FollowViolationStatusKey.ADDITIONAL_INFORMATION],
  [6, FollowViolationStatusKey.ADVICE],
  [26, FollowViolationStatusKey.ADVISING],
  [8, FollowViolationStatusKey.SENT_SUPERVISOR],
  [9, FollowViolationStatusKey.SUPERVISION_ADVISED],
  [7, FollowViolationStatusKey.DONE_ADVICE],
  [10, FollowViolationStatusKey.FEEDBACK_ADVICE],
  [11, FollowViolationStatusKey.ADVICE_FINISHED],
  [13, FollowViolationStatusKey.REPORT_AND_NEXT_ACTION],
  [14, FollowViolationStatusKey.REQUEST_APPROVAL_DEPT_HEAD],
  [15, FollowViolationStatusKey.APPROVAL_DEPT_HEAD],
  [16, FollowViolationStatusKey.DENIED_DEPT_HEAD],
  [17, FollowViolationStatusKey.REQUEST_APPROVAL_GROUP_HEAD],
  [18, FollowViolationStatusKey.GROUP_HEAD_APPROVE],
  [19, FollowViolationStatusKey.DENIED_GROUP_HEAD],
  [20, FollowViolationStatusKey.REQUEST_APPROVAL_TOP_HEAD],
  [23, FollowViolationStatusKey.DONE_NEXT_ACTION],
  [24, FollowViolationStatusKey.FEEDBACK_NEXT_ACTION],
  [25, FollowViolationStatusKey.TRACK_NEXT_ACTION],
  [12, FollowViolationStatusKey.FINISH],
]);

export const FollowViolationUserRole: Map<string, number> = new Map([
  [FollowViolationUserRoleKey.PIC, 1],
  [FollowViolationUserRoleKey.L_C, 2],
  [FollowViolationUserRoleKey.SUPERVISOR, 3],
  [FollowViolationUserRoleKey.RELATED_PERSON, 4],
  [FollowViolationUserRoleKey.DEPT_HEAD, 5],
  [FollowViolationUserRoleKey.GROUP_HEAD, 6],
  [FollowViolationUserRoleKey.TOP_HEAD, 7],
  [FollowViolationUserRoleKey.VIEWER, 8],
]);

export const FollowViolationUserRoleR: Map<number, string> = new Map([
  [1, FollowViolationUserRoleKey.PIC],
  [2, FollowViolationUserRoleKey.L_C],
  [3, FollowViolationUserRoleKey.SUPERVISOR],
  [4, FollowViolationUserRoleKey.RELATED_PERSON],
  [5, FollowViolationUserRoleKey.DEPT_HEAD],
  [6, FollowViolationUserRoleKey.GROUP_HEAD],
  [7, FollowViolationUserRoleKey.TOP_HEAD],
  [8, FollowViolationUserRoleKey.VIEWER],
]);

export const FollowViolationActionsBtn = new Map<string, number>([
  [FollowViolationActionsBtnKey.NOT_AVAILABLE, 0],
  [FollowViolationActionsBtnKey.CREATE_VIOLATION_TRACKING_DOCUMENT, 1],
  [FollowViolationActionsBtnKey.UPDATE_VIOLATION_TRACKING_DOCUMENT, 2],
  [FollowViolationActionsBtnKey.SEND_MAIL, 3],
  [FollowViolationActionsBtnKey.REQUEST_MEETING, 4],
  [FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST, 5],
  [FollowViolationActionsBtnKey.ACCEPT_TIME_EXTENSION, 6],
  [FollowViolationActionsBtnKey.TIME_EXTENSION, 7],
  [FollowViolationActionsBtnKey.RECALL, 8],
  [FollowViolationActionsBtnKey.CREATE_NEXT_ACTION, 11],
  [FollowViolationActionsBtnKey.UPDATE_NEXT_ACTION, 12],
  [FollowViolationActionsBtnKey.FEEDBACK, 13],
  [FollowViolationActionsBtnKey.FEEDBACK_LC, 14],
  [FollowViolationActionsBtnKey.FORWARD, 15],
  [FollowViolationActionsBtnKey.MEETING, 16],
  [FollowViolationActionsBtnKey.ASSIGNMENT, 19],
  [FollowViolationActionsBtnKey.REQUEST_VENDOR, 20],
  [FollowViolationActionsBtnKey.REQUEST_ADDITIONAL, 21],
  [FollowViolationActionsBtnKey.ADVICE, 22],
  [FollowViolationActionsBtnKey.SENT_SUPERVISOR, 23],
  [FollowViolationActionsBtnKey.CONFIRM, 24],
  [FollowViolationActionsBtnKey.UPDATE_ADVICE, 25],
  [FollowViolationActionsBtnKey.FINISH, 26],
  [FollowViolationActionsBtnKey.TRACK_NEXT_ACTION, 36],
  [FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION, 37],
  [FollowViolationActionsBtnKey.REQUEST_USER, 38],
  [FollowViolationActionsBtnKey.DONE_ADVICE, 39],
  [FollowViolationActionsBtnKey.FEEDBACK_ADVICE, 40],
  [FollowViolationActionsBtnKey.CONFIRM_FINISH_ADVICE, 41],
  [FollowViolationActionsBtnKey.REQUEST_RECHECK, 42],
  [FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN, 43],
  [FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION, 44],
]);

export const FollowViolationActionsBtnR = new Map<number, string>([
  [0, FollowViolationActionsBtnKey.NOT_AVAILABLE],
  [1, FollowViolationActionsBtnKey.CREATE_VIOLATION_TRACKING_DOCUMENT],
  [2, FollowViolationActionsBtnKey.UPDATE_VIOLATION_TRACKING_DOCUMENT],
  [3, FollowViolationActionsBtnKey.SEND_MAIL],
  [4, FollowViolationActionsBtnKey.REQUEST_MEETING],
  [5, FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST],
  [6, FollowViolationActionsBtnKey.ACCEPT_TIME_EXTENSION],
  [7, FollowViolationActionsBtnKey.TIME_EXTENSION],
  [8, FollowViolationActionsBtnKey.RECALL],
  [11, FollowViolationActionsBtnKey.CREATE_NEXT_ACTION],
  [12, FollowViolationActionsBtnKey.UPDATE_NEXT_ACTION],
  [13, FollowViolationActionsBtnKey.FEEDBACK],
  [14, FollowViolationActionsBtnKey.FEEDBACK_LC],
  [15, FollowViolationActionsBtnKey.FORWARD],
  [16, FollowViolationActionsBtnKey.MEETING],
  [19, FollowViolationActionsBtnKey.ASSIGNMENT],
  [20, FollowViolationActionsBtnKey.REQUEST_VENDOR],
  [21, FollowViolationActionsBtnKey.REQUEST_ADDITIONAL],
  [22, FollowViolationActionsBtnKey.ADVICE],
  [23, FollowViolationActionsBtnKey.SENT_SUPERVISOR],
  [24, FollowViolationActionsBtnKey.CONFIRM],
  [25, FollowViolationActionsBtnKey.UPDATE_ADVICE],
  [26, FollowViolationActionsBtnKey.FINISH],
  [36, FollowViolationActionsBtnKey.TRACK_NEXT_ACTION],
  [37, FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION],
  [38, FollowViolationActionsBtnKey.REQUEST_USER],
  [39, FollowViolationActionsBtnKey.DONE_ADVICE],
  [40, FollowViolationActionsBtnKey.FEEDBACK_ADVICE],
  [41, FollowViolationActionsBtnKey.CONFIRM_FINISH_ADVICE],
  [42, FollowViolationActionsBtnKey.REQUEST_RECHECK],
  [43, FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN],
  [44, FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION],
]);

export enum ViolationStatusCode {
  REQUEST_ADVISE = 1,
  ASSIGNMENT = 2,
  REQUEST_VENDOR_ADVISE = 3,
  REQUEST_ADDITIONAL_ADVISE = 4,
  ADDITIONAL_INFORMATION_ADDED = 5,
  ADVISE = 6,
  ADVISE_DONE = 7,
  SEND_SUPERVISOR = 8,
  SUPERVISOR_HAS_ADVISE = 9,
  FEEDBACK_ADVISE = 10,
  COMPLETE_ADVISE = 11,
  FINISH = 12,
  REPORT_AND_NEXT_ACTION = 13,
  REQUEST_APPROVAL_DEPT_HEAD = 14,
  DEPT_HEAD_APPROVE = 15,
  DEPT_HEAD_DENIED = 16,
  REQUEST_APPROVAL_GROUP_HEAD = 17,
  GROUP_HEAD_APPROVE = 18,
  GROUP_HEAD_DENIED = 19,
  REQUEST_APPROVAL_TOP_HEAD = 20,
  TOP_HEAD_APPROVE = 21,
  TOP_HEAD_DENIED = 22,
  NEXT_ACTION_DONE = 23,
  FEEDBACK_NEXT_ACTION = 24,
  TRACK_NEXT_ACTION = 25,
}

export const getButtonListViolation = (
  row: FollowViolationDetail | undefined
) => {
  const currentRowStatus = FollowViolationStatusR.get(
    row?.status?.code as number
  );

  const btnCondition = {
    [FollowViolationActionsBtnKey.FEEDBACK]:
      row?.lastActionAndRole?.requestFeedbackAvailableFlag,
    [FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST]:
      currentRowStatus !== FollowViolationStatusKey.CONFIRM,
    [FollowViolationActionsBtnKey.ASSIGNMENT]:
      currentRowStatus === FollowViolationStatusKey.CONFIRM ||
      currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE,
    [FollowViolationActionsBtnKey.REQUEST_VENDOR]:
      currentRowStatus === FollowViolationStatusKey.CONFIRM ||
      currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADDITIONAL ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_VENDOR ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE,
    [FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]:
      currentRowStatus === FollowViolationStatusKey.CONFIRM ||
      currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
      currentRowStatus === FollowViolationStatusKey.ADVICE ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.ASSIGNMENT ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADDITIONAL ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_VENDOR ||
      currentRowStatus === FollowViolationStatusKey.SENT_SUPERVISOR ||
      currentRowStatus === FollowViolationStatusKey.SUPERVISION_ADVISED,
    [FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]:
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADDITIONAL,
    [FollowViolationActionsBtnKey.CONFIRM]:
      !row?.lastActionAndRole?.requestConfirmAvailableFlag &&
      (currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
        currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE ||
        currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
        currentRowStatus === FollowViolationStatusKey.ASSIGNMENT ||
        currentRowStatus === FollowViolationStatusKey.REQUEST_VENDOR ||
        currentRowStatus === FollowViolationStatusKey.SENT_SUPERVISOR),
    [FollowViolationActionsBtnKey.ADVICE]:
      currentRowStatus === FollowViolationStatusKey.CONFIRM ||
      currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
      currentRowStatus === FollowViolationStatusKey.ASSIGNMENT ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_VENDOR ||
      currentRowStatus === FollowViolationStatusKey.SENT_SUPERVISOR ||
      currentRowStatus === FollowViolationStatusKey.SUPERVISION_ADVISED ||
      currentRowStatus === FollowViolationStatusKey.FEEDBACK_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.ADVICE ||
      currentRowStatus === FollowViolationStatusKey.DONE_ADVICE,
    [FollowViolationActionsBtnKey.ADVICE_FINISHED]:
      currentRowStatus === FollowViolationStatusKey.DONE_ADVICE,
    [FollowViolationActionsBtnKey.FEEDBACK_ADVICE]:
      currentRowStatus === FollowViolationStatusKey.DONE_ADVICE,
    [FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION]:
      currentRowStatus === FollowViolationStatusKey.DONE_NEXT_ACTION,
    [FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]:
      currentRowStatus === FollowViolationStatusKey.DONE_NEXT_ACTION,
    [FollowViolationActionsBtnKey.FEEDBACK_LC]:
      row?.lastActionAndRole?.violationApprovalFlag ||
      currentRowStatus === FollowViolationStatusKey.FEEDBACK_NEXT_ACTION,
    [FollowViolationActionsBtnKey.FINISH]:
      currentRowStatus === FollowViolationStatusKey.ADVICE ||
      currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED ||
      currentRowStatus === FollowViolationStatusKey.TRACK_NEXT_ACTION,
  };

  return btnCondition;
};

export const listActionDefaultNotOwnerAction = new Map<
  number,
  TypeActionRole[]
>([
  [
    FollowViolationUserRole.get(FollowViolationUserRoleKey.PIC)!,
    [
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
      // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
      { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
    ],
  ],
  [
    FollowViolationUserRole.get(FollowViolationUserRoleKey.L_C)!,
    [
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
      // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
      { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
      { typeBtn: FollowViolationActionsBtnKey.REQUEST_ADDITIONAL },
    ],
  ],
  [
    FollowViolationUserRole.get(FollowViolationUserRoleKey.SUPERVISOR)!,
    [
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
      // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
      { typeBtn: FollowViolationActionsBtnKey.REQUEST_ADDITIONAL },
    ],
  ],
  [
    FollowViolationUserRole.get(FollowViolationUserRoleKey.RELATED_PERSON)!,
    [
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    ],
  ],
  [
    FollowViolationUserRole.get(FollowViolationUserRoleKey.DEPT_HEAD)!,
    [
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
      // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    ],
  ],
  [
    FollowViolationUserRole.get(FollowViolationUserRoleKey.GROUP_HEAD)!,
    [
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
      // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    ],
  ],
  [
    FollowViolationUserRole.get(FollowViolationUserRoleKey.TOP_HEAD)!,
    [
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
      // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    ],
  ],
  [FollowViolationUserRole.get(FollowViolationUserRoleKey.VIEWER)!, []],
]);

export const authorizedActionMapCallBack = (
  followViolationActions: any,
  params: any
) => {
  const btnCondition = getButtonListViolation(params?.row);

  // For item
  const listItemActionsPic = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    ...(btnCondition[FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]
      ? [{ typeBtn: FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION }]
      : []),
    {
      typeBtn: FollowViolationActionsBtnKey.ADVICE_FINISHED,
      disable: !btnCondition[FollowViolationActionsBtnKey.ADVICE_FINISHED],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_ADVICE],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FINISH,
      disable: !btnCondition[FollowViolationActionsBtnKey.FINISH],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_RECHECK,
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN,
    },
  ];

  const listItemActionsLc = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
      disable:
        !btnCondition[FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.CONFIRM,
      disable: !btnCondition[FollowViolationActionsBtnKey.CONFIRM],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.ASSIGNMENT,
      disable: !btnCondition[FollowViolationActionsBtnKey.ASSIGNMENT],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_VENDOR,
      disable: !btnCondition[FollowViolationActionsBtnKey.REQUEST_VENDOR],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
      disable: !btnCondition[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.ADVICE,
      disable: !btnCondition[FollowViolationActionsBtnKey.ADVICE],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION],
    },
  ];

  const listItemActionsSupervisor = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
      disable:
        !btnCondition[FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
      disable: !btnCondition[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.ADVICE,
      disable: !btnCondition[FollowViolationActionsBtnKey.ADVICE],
    },
  ];

  const listItemActionsRelatedPerson = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    { typeBtn: FollowViolationActionsBtnKey.FEEDBACK },
  ];

  const listItemActionsDeptHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
      disable:
        !btnCondition[FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION],
    },
  ];

  const listItemActionsGroupHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
      disable:
        !btnCondition[FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST],
    },
  ];

  const listItemActionsTopHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
      disable:
        !btnCondition[FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST],
    },
  ];

  // For list
  const listActionsPic = {
    [FollowViolationActionsBtnKey.CREATE_VIOLATION_TRACKING_DOCUMENT]: [
      { typeBtn: FollowViolationActionsBtnKey.FORWARD },
      { typeBtn: FollowViolationActionsBtnKey.RECALL },
      ...(!btnCondition[FollowViolationActionsBtnKey.FEEDBACK]
        ? [
            {
              typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
              disable: true,
            },
          ]
        : []),
      // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
      { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
      ...(!btnCondition[FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST]
        ? [
            {
              typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
              disable: true,
            },
          ]
        : []),
      {
        typeBtn: FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
        disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_ADVICE],
      },
      {
        typeBtn: FollowViolationActionsBtnKey.FINISH,
        disable: !btnCondition[FollowViolationActionsBtnKey.FINISH],
      },
    ],
    [FollowViolationActionsBtnKey.RECALL]: listItemActionsPic,
    [FollowViolationActionsBtnKey.FORWARD]: listItemActionsPic,
    [FollowViolationActionsBtnKey.FEEDBACK]: listItemActionsPic,
    [FollowViolationActionsBtnKey.SEND_MAIL]: listItemActionsPic,
    // [FollowViolationActionsBtnKey.REQUEST_MEETING]: listItemActionsPic,
    [FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]: listItemActionsPic,
    [FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]: listItemActionsPic,
    [FollowViolationActionsBtnKey.ADVICE]: listItemActionsPic,
    [FollowViolationActionsBtnKey.DONE_ADVICE]: listItemActionsPic,
    [FollowViolationActionsBtnKey.ADVICE_FINISHED]: listItemActionsPic,
    [FollowViolationActionsBtnKey.FEEDBACK_ADVICE]: listItemActionsPic,
    [FollowViolationActionsBtnKey.CREATE_NEXT_ACTION]: listItemActionsPic,
    [FollowViolationActionsBtnKey.UPDATE_NEXT_ACTION]: listItemActionsPic,
    [FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]: listItemActionsPic,
    [FollowViolationActionsBtnKey.FINISH]: listItemActionsPic,
    [FollowViolationActionsBtnKey.NOT_AVAILABLE]: listItemActionsPic,
  };

  const listActionsLc = {
    [FollowViolationActionsBtnKey.CREATE_VIOLATION_TRACKING_DOCUMENT]:
      listItemActionsLc,
    [FollowViolationActionsBtnKey.RECALL]: listItemActionsLc,
    [FollowViolationActionsBtnKey.FORWARD]: listItemActionsLc,
    [FollowViolationActionsBtnKey.FEEDBACK]: listItemActionsLc,
    // [FollowViolationActionsBtnKey.REQUEST_MEETING]: listItemActionsLc,
    [FollowViolationActionsBtnKey.SEND_MAIL]: listItemActionsLc,
    [FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST]: listItemActionsLc,
    [FollowViolationActionsBtnKey.CONFIRM]: listItemActionsLc,
    [FollowViolationActionsBtnKey.ASSIGNMENT]: listItemActionsLc,
    [FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]: listItemActionsLc,
    [FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]: listItemActionsLc,
    [FollowViolationActionsBtnKey.REQUEST_VENDOR]: listItemActionsLc,
    [FollowViolationActionsBtnKey.ADVICE]: listItemActionsLc,
    [FollowViolationActionsBtnKey.FEEDBACK_ADVICE]: listItemActionsLc,
    [FollowViolationActionsBtnKey.DONE_ADVICE]: listItemActionsLc,
    [FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION]: listItemActionsLc,
    [FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]: listItemActionsLc,
    [FollowViolationActionsBtnKey.NOT_AVAILABLE]: listItemActionsLc,
  };

  const listActionsSupervisor = {
    [FollowViolationActionsBtnKey.RECALL]: listItemActionsSupervisor,
    [FollowViolationActionsBtnKey.FORWARD]: listItemActionsSupervisor,
    [FollowViolationActionsBtnKey.FEEDBACK]: listItemActionsSupervisor,
    // [FollowViolationActionsBtnKey.REQUEST_MEETING]: listItemActionsSupervisor,
    [FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST]:
      listItemActionsSupervisor,
    [FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]:
      listItemActionsSupervisor,
    [FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]:
      listItemActionsSupervisor,
    [FollowViolationActionsBtnKey.FEEDBACK_ADVICE]: listItemActionsSupervisor,
    [FollowViolationActionsBtnKey.ADVICE]: listItemActionsSupervisor,
  };

  const listActionsRelatedPerson = {
    [FollowViolationActionsBtnKey.CREATE_VIOLATION_TRACKING_DOCUMENT]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.RECALL]: listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.FORWARD]: listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.FEEDBACK]: listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.SEND_MAIL]: listItemActionsRelatedPerson,
    // [FollowViolationActionsBtnKey.REQUEST_MEETING]: listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.ADVICE]: listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.DONE_ADVICE]: listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.ADVICE_FINISHED]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.FEEDBACK_ADVICE]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.CREATE_NEXT_ACTION]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.UPDATE_NEXT_ACTION]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]:
      listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.FINISH]: listItemActionsRelatedPerson,
    [FollowViolationActionsBtnKey.NOT_AVAILABLE]: listItemActionsRelatedPerson,
  };

  const listActionsDeptHead = {
    [FollowViolationActionsBtnKey.RECALL]: listItemActionsDeptHead,
    [FollowViolationActionsBtnKey.FORWARD]: listItemActionsDeptHead,
    [FollowViolationActionsBtnKey.FEEDBACK]: listItemActionsDeptHead,
    // [FollowViolationActionsBtnKey.REQUEST_MEETING]: listItemActionsDeptHead,
    [FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST]:
      listItemActionsDeptHead,
    [FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]: listItemActionsDeptHead,
  };

  const listActionsGroupHead = {
    [FollowViolationActionsBtnKey.RECALL]: listItemActionsGroupHead,
    [FollowViolationActionsBtnKey.FORWARD]: listItemActionsGroupHead,
    [FollowViolationActionsBtnKey.FEEDBACK]: listItemActionsGroupHead,
    // [FollowViolationActionsBtnKey.REQUEST_MEETING]: listItemActionsGroupHead,
    [FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST]:
      listItemActionsGroupHead,
  };

  const listActionsTopHead = {
    [FollowViolationActionsBtnKey.RECALL]: listItemActionsTopHead,
    [FollowViolationActionsBtnKey.FORWARD]: listItemActionsTopHead,
    [FollowViolationActionsBtnKey.FEEDBACK]: listItemActionsTopHead,
    // [FollowViolationActionsBtnKey.REQUEST_MEETING]: listItemActionsTopHead,
    [FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST]:
      listItemActionsTopHead,
  };

  const authorizedActionMap = new Map<number | string, any>([
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.PIC)!,
      listActionsPic,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.L_C)!,
      listActionsLc,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.SUPERVISOR)!,
      listActionsSupervisor,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.RELATED_PERSON)!,
      listActionsRelatedPerson,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.DEPT_HEAD)!,
      listActionsDeptHead,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.GROUP_HEAD)!,
      listActionsGroupHead,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.TOP_HEAD)!,
      listActionsTopHead,
    ],
    [FollowViolationUserRole.get(FollowViolationUserRoleKey.VIEWER)!, []],
  ]);

  let listActionAuthorizedMap: TypeActionRole[] = [];

  if (params?.row.name === "Test 12") {
    // console.log("authorizedActionMap", params?.row.name, params?.row);
    // console.log("authorizedActionMap", params?.row.name, authorizedActionMap);
  }

  followViolationActions.forEach((item: any) => {
    const authorizedAction =
      authorizedActionMap?.get(item?.role)?.[
        FollowViolationActionsBtnR.get(item?.lastAction) as string
      ] || [];

    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });

  listActionAuthorizedMap = uniqueCheck(listActionAuthorizedMap);

  return listActionAuthorizedMap;
};

export const getButtonsDetailViolation = (
  row: FollowViolationDetail | undefined
) => {
  const currentRowStatus = FollowViolationStatusR.get(
    row?.status?.code as number
  );

  const btnCondition = {
    [FollowViolationActionsBtnKey.FEEDBACK]:
      row?.lastActionAndRole?.requestFeedbackAvailableFlag,
    [FollowViolationActionsBtnKey.REQUEST_VENDOR]:
      currentRowStatus === FollowViolationStatusKey.CONFIRM ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADDITIONAL ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_VENDOR ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE,
    [FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]:
      currentRowStatus === FollowViolationStatusKey.CONFIRM ||
      currentRowStatus === FollowViolationStatusKey.ADVICE ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.ASSIGNMENT ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADDITIONAL ||
      currentRowStatus === FollowViolationStatusKey.REQUEST_VENDOR ||
      currentRowStatus === FollowViolationStatusKey.SENT_SUPERVISOR ||
      currentRowStatus === FollowViolationStatusKey.SUPERVISION_ADVISED,
    [FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]:
      currentRowStatus === FollowViolationStatusKey.REQUEST_ADDITIONAL,
    [FollowViolationActionsBtnKey.FEEDBACK_ADVICE]:
      currentRowStatus === FollowViolationStatusKey.DONE_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.FEEDBACK_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED,
    [FollowViolationActionsBtnKey.FEEDBACK_LC]:
      currentRowStatus === FollowViolationStatusKey.DONE_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.FEEDBACK_NEXT_ACTION,
    [FollowViolationActionsBtnKey.CONFIRM]:
      !row?.lastActionAndRole?.requestConfirmAvailableFlag &&
      (currentRowStatus === FollowViolationStatusKey.REQUEST_ADVICE ||
        currentRowStatus === FollowViolationStatusKey.ADDITIONAL_INFORMATION ||
        currentRowStatus === FollowViolationStatusKey.ASSIGNMENT ||
        currentRowStatus === FollowViolationStatusKey.REQUEST_VENDOR ||
        currentRowStatus === FollowViolationStatusKey.SENT_SUPERVISOR),
    [FollowViolationActionsBtnKey.ADVICE_FINISHED]:
      currentRowStatus === FollowViolationStatusKey.DONE_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.FEEDBACK_ADVICE ||
      currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED,
    [FollowViolationActionsBtnKey.REQUEST_RECHECK]:
      currentRowStatus === FollowViolationStatusKey.FINISH,
    [FollowViolationActionsBtnKey.FINISH]:
      currentRowStatus === FollowViolationStatusKey.ADVICE_FINISHED,
  };

  return btnCondition;
};

export const authorizedDetailActionMapCallBack = (
  followViolationActions: any,
  params: any
) => {
  const btnCondition = getButtonsDetailViolation(params?.row);

  // For item
  const listItemActionsPic = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    ...(btnCondition[FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION]
      ? [{ typeBtn: FollowViolationActionsBtnKey.ADDITIONAL_INFORMATION }]
      : []),
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_RECHECK,
      disable: !btnCondition[FollowViolationActionsBtnKey.REQUEST_RECHECK],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_ADVICE],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_ADVICE],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.ADVICE_FINISHED,
      disable: !btnCondition[FollowViolationActionsBtnKey.ADVICE_FINISHED],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FINISH,
      disable: !btnCondition[FollowViolationActionsBtnKey.FINISH],
    },
  ];

  const listItemActionsLc = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
    },
    {
      typeBtn: FollowViolationActionsBtnKey.CONFIRM,
      disable: !btnCondition[FollowViolationActionsBtnKey.CONFIRM],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.ASSIGNMENT,
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_VENDOR,
      disable: !btnCondition[FollowViolationActionsBtnKey.REQUEST_VENDOR],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
      disable: !btnCondition[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.ADVICE,
    },
  ];

  const listItemActionsSupervisor = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
      disable: !btnCondition[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.ADVICE,
    },
  ];

  const listItemActionsRelatedPerson = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    { typeBtn: FollowViolationActionsBtnKey.FEEDBACK },
  ];

  const listItemActionsDeptHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
  ];

  const listItemActionsGroupHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
  ];

  const listItemActionsTopHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    { typeBtn: FollowViolationActionsBtnKey.SHARE },
  ];

  const authorizedActionMap = new Map<number | string, any>([
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.PIC)!,
      listItemActionsPic,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.L_C)!,
      listItemActionsLc,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.SUPERVISOR)!,
      listItemActionsSupervisor,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.RELATED_PERSON)!,
      listItemActionsRelatedPerson,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.DEPT_HEAD)!,
      listItemActionsDeptHead,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.GROUP_HEAD)!,
      listItemActionsGroupHead,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.TOP_HEAD)!,
      listItemActionsTopHead,
    ],
    [FollowViolationUserRole.get(FollowViolationUserRoleKey.VIEWER)!, []],
  ]);

  let listActionAuthorizedMap: TypeActionRole[] = [];

  followViolationActions.forEach((item: any) => {
    const authorizedAction = authorizedActionMap?.get(item?.role) || [];

    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });

  listActionAuthorizedMap = uniqueCheck(listActionAuthorizedMap);

  return listActionAuthorizedMap;
};

export const getButtonNextActionViolation = (
  row: FollowViolationDetail | undefined,
  nextAction?: ViolationNextActionResponse
) => {
  const currentRowStatus = FollowViolationStatusR.get(
    nextAction?.status?.code as number
  );

  const currentDetailStatus = FollowViolationStatusR.get(
    row?.status?.code as number
  );

  const btnCondition = {
    [FollowViolationActionsBtnKey.FEEDBACK_LC]:
      currentRowStatus === FollowViolationStatusKey.FEEDBACK_NEXT_ACTION ||
      currentRowStatus === FollowViolationStatusKey.REPORT_AND_NEXT_ACTION ||
      currentRowStatus === FollowViolationStatusKey.APPROVAL_DEPT_HEAD ||
      currentRowStatus === FollowViolationStatusKey.GROUP_HEAD_APPROVE ||
      currentRowStatus === FollowViolationStatusKey.TOP_HEAD_APPROVAL,

    [FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]:
      currentRowStatus === FollowViolationStatusKey.DONE_NEXT_ACTION,

    [FollowViolationActionsBtnKey.FINISH]:
      currentRowStatus === FollowViolationStatusKey.TRACK_NEXT_ACTION,

    [FollowViolationActionsBtnKey.FEEDBACK]:
      row?.lastActionAndRole?.requestFeedbackAvailableFlag,

    [FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION]:
      currentRowStatus === FollowViolationStatusKey.DONE_NEXT_ACTION,

    [FollowViolationActionsBtnKey.FINISH]:
      currentRowStatus === FollowViolationStatusKey.TRACK_NEXT_ACTION,

    [FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN]:
      currentDetailStatus === FollowViolationStatusKey.FINISH,
  };

  return btnCondition;
};

export const authorizedNextlActionMapCallBack = (
  followViolationActions: any,
  params: any
) => {
  const btnCondition = getButtonNextActionViolation(
    params?.row,
    params.nextAction
  );

  // For item
  const listItemActionsPic = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK_LC,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_LC],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN,
      disable:
        !btnCondition[
          FollowViolationActionsBtnKey.REQUEST_APPROVAL_NEXT_ACTION_AGAIN
        ],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FINISH,
      disable: !btnCondition[FollowViolationActionsBtnKey.FINISH],
    },
  ];

  const listItemActionsLc = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.SEND_MAIL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FINISH,
      disable: !btnCondition[FollowViolationActionsBtnKey.FINISH],
    },
  ];

  const listItemActionsSupervisor = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },

    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
    },
  ];

  const listItemActionsRelatedPerson = [
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
  ];

  const listItemActionsDeptHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
    },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK_LC,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK_LC],
    },
    {
      typeBtn: FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
      disable: !btnCondition[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION],
    },
  ];

  const listItemActionsGroupHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },

    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
    },
  ];

  const listItemActionsTopHead = [
    { typeBtn: FollowViolationActionsBtnKey.RECALL },
    { typeBtn: FollowViolationActionsBtnKey.FORWARD },
    {
      typeBtn: FollowViolationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[FollowViolationActionsBtnKey.FEEDBACK],
    },
    // { typeBtn: FollowViolationActionsBtnKey.REQUEST_MEETING },
    {
      typeBtn: FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
    },
  ];

  const authorizedActionMap = new Map<number | string, any>([
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.PIC)!,
      listItemActionsPic,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.L_C)!,
      listItemActionsLc,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.SUPERVISOR)!,
      listItemActionsSupervisor,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.RELATED_PERSON)!,
      listItemActionsRelatedPerson,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.DEPT_HEAD)!,
      listItemActionsDeptHead,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.GROUP_HEAD)!,
      listItemActionsGroupHead,
    ],
    [
      FollowViolationUserRole.get(FollowViolationUserRoleKey.TOP_HEAD)!,
      listItemActionsTopHead,
    ],
    [FollowViolationUserRole.get(FollowViolationUserRoleKey.VIEWER)!, []],
  ]);

  let listActionAuthorizedMap: TypeActionRole[] = [];

  followViolationActions.forEach((item: any) => {
    const authorizedAction = authorizedActionMap?.get(item?.role) || [];

    listActionAuthorizedMap = listActionAuthorizedMap.concat(
      authorizedAction?.length
        ? authorizedAction
        : listActionDefaultNotOwnerAction.get(item?.role)
    );
  });

  listActionAuthorizedMap = uniqueCheck(listActionAuthorizedMap);

  return listActionAuthorizedMap;
};
