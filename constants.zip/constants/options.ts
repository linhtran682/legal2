import { RadioItem } from "@/models/law_document/RequestApproval";
export const StatusTimeExtension: RadioItem[] = [
  {
    label: "Đồng ý",
    value: 0,
  },
  {
    label: "Thời gian mới",
    value: 1,
  },
  {
    label: "Y/C gia hạn thời gian",
    value: 2,
  },
];