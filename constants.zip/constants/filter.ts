import { SxProps } from "@mui/material";

export const FILTER_DEBOUNCE_MS = 1000;

export const filterBoxSxProps: SxProps = {
  // display: "inline-flex",
  // flexDirection: "row",
  // alignItems: "end",
  minHeight: 48,
  minWidth: 190,
  width: "100%",
};

export const FilterOperators = {
  DATE_RANGE: {
    BETWEEN: "common.filter_operator.date_range.between",
  },
  KEY_WORD: {
    CONTAINS: "common.filter_operator.keyword.contains",
  },
  MULTIPLE_SELECT: {
    EXISTED_IN: "common.filter_operator.multiple_select.existed_in",
  },
  NUMBER_RANGE: {
    BETWEEN: "common.filter_operator.number_range.between",
  },
  SELECT: {
    IS: "common.filter_operator.select.is",
  },
  ASYNC_SELECT: {
    IS: "common.filter_operator.select.is",
  },
};
