export const TEXT_FIELD_MAX_LENGTH = 255;
export const TEXT_AREA_MAX_LENGTH = 1000;
export const URL_OUTLOOK = "https://teams.microsoft.com/_#/calendarv2";
export const CODE_LIST = {
    ERROR_CODES_4030004: 4030004,
    ERROR_CODES_4030000: 4030000,
}
