export const VIVN_DATE_FORMAT = "dd/MM/yyyy";
export const VIVN_DATE_TIME_FORMAT = "dd/MM/yyyy hh:mm:ss";
export const VIVN_INTL_LOCALE = "vi-VN";
export const EXPECTED_DATE_TIME_LOCALE = "fr-FR";
export const GLOBAL_SPACING = "1rem";
export const GLOBAL_SMALL_SPACING = "0.5rem";
export const GLOBAL_LARGE_SPACING = "2rem";
export const formatsEditorField = [
    "header",
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "blockquote",
    "align",
    "list",
    "bullet",
    "indent",
    "link",
    "color",
    "background",
  ];