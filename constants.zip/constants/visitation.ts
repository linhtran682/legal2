import { uniqueCheck } from "@/utils";
import { TypeActionRole } from "./general";

// Visitation
export const VisitationUserRoleKey = {
  PIC: "PIC", // Người tạo
  CONFIRM: "CONFIRM", // Người xác nhận
  SHARE_INFO: "SHARE_INFO", // Người chia sẻ
  EVALUATION: "EVALUATION", // Người đánh giá
  SIGN: "SIGN", // Người ký duyệt
  RELATED: "RELATED", // Người liên quan
  VIEWER: "VIEWER",
};

export const VisitationUserRole: Map<string, number> = new Map([
  [VisitationUserRoleKey.PIC, 1],
  [VisitationUserRoleKey.CONFIRM, 2],
  [VisitationUserRoleKey.SHARE_INFO, 3],
  [VisitationUserRoleKey.EVALUATION, 4],
  [VisitationUserRoleKey.SIGN, 5],
  [VisitationUserRoleKey.RELATED, 6],
  [VisitationUserRoleKey.VIEWER, 8],
]);

export const VisitationUserRoleR: Map<number, string> = new Map([
  [1, VisitationUserRoleKey.PIC],
  [2, VisitationUserRoleKey.CONFIRM],
  [3, VisitationUserRoleKey.SHARE_INFO],
  [4, VisitationUserRoleKey.EVALUATION],
  [5, VisitationUserRoleKey.SIGN],
  [8, VisitationUserRoleKey.VIEWER],
]);

export const VisitationStatusKey = {
  REQUEST_CONFIRMATION: "REQUEST_CONFIRMATION", // Yêu cầu xác nhận
  INFORMATION_REQUEST: "INFORMATION_REQUEST", // Yêu cầu bổ sung thông tin
  ADDITIONAL_INFORMATION: "ADDITIONAL_INFORMATION", // Đã bổ sung thông tin
  CONFIRM_APPROVE: "CONFIRM_APPROVE", // Đồng ý xác nhận
  CONFIRM_REJECT: "CONFIRM_REJECT", // Từ chối xác nhận
  EVALUATE_REQUEST: "EVALUATE_REQUEST", // Yêu cầu đánh giá
  EVALUATING: "EVALUATING", // Đang thực hiện đánh giá
  ASSIGNMENT: "ASSIGNMENT", // Phân công
  EVALUATED: "EVALUATED", // Đã đánh giá/nhận xét
  EVALUATE_FEEDBACK_REJECT: "EVALUATE_FEEDBACK_REJECT", // Từ chối đánh giá
  RECEPTION: "RECEPTION", // Tiếp đón
  RECEPTION_RESULT: "RECEPTION_RESULT", // Đã điền kết quả tiếp đón
  FOLLOW: "FOLLOW", // Theo dõi kết quả tiếp đón
  REQUEST_SIGN: "REQUEST_SIGN", // Yêu cầu ký duyệt
  SIGNED: "SIGNED", // Đã ký
  SIGN_REJECT: "SIGN_REJECT", // Ký duyệt: Từ chối
  APPROVAL_FINISHED: "APPROVAL_FINISHED", // Ký duyệt: Hoàn thành
  APPROVAL_RECALLED: "APPROVAL_RECALLED", // Ký duyệt: Thu hồi
  FINISH: "FINISH", // Hoàn thành
  CALL_ESIGN: "CALL_ESIGN", // Tạo ký duyệt
};

export const VisitationStatus: Map<string, number> = new Map([
  [VisitationStatusKey.REQUEST_CONFIRMATION, 4],
  [VisitationStatusKey.INFORMATION_REQUEST, 3],
  [VisitationStatusKey.ADDITIONAL_INFORMATION, 2],
  [VisitationStatusKey.CONFIRM_APPROVE, 5],
  [VisitationStatusKey.CONFIRM_REJECT, 7],
  [VisitationStatusKey.EVALUATE_REQUEST, 8],
  [VisitationStatusKey.EVALUATING, 20],
  [VisitationStatusKey.ASSIGNMENT, 21],
  [VisitationStatusKey.EVALUATED, 9],
  [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT, 10],
  [VisitationStatusKey.RECEPTION, 11],
  [VisitationStatusKey.RECEPTION_RESULT, 12],
  [VisitationStatusKey.FOLLOW, 13],
  [VisitationStatusKey.REQUEST_SIGN, 14],
  [VisitationStatusKey.SIGNED, 15],
  [VisitationStatusKey.SIGN_REJECT, 16],
  [VisitationStatusKey.APPROVAL_FINISHED, 17],
  [VisitationStatusKey.APPROVAL_RECALLED, 18],
  [VisitationStatusKey.FINISH, 1],
  [VisitationStatusKey.CALL_ESIGN, 19],
]);

export const VisitationStatusR: Map<number, string> = new Map([
  [4, VisitationStatusKey.REQUEST_CONFIRMATION],
  [3, VisitationStatusKey.INFORMATION_REQUEST],
  [2, VisitationStatusKey.ADDITIONAL_INFORMATION],
  [5, VisitationStatusKey.CONFIRM_APPROVE],
  [7, VisitationStatusKey.CONFIRM_REJECT],
  [20, VisitationStatusKey.EVALUATING],
  [21, VisitationStatusKey.ASSIGNMENT],
  [8, VisitationStatusKey.EVALUATE_REQUEST],
  [9, VisitationStatusKey.EVALUATED],
  [10, VisitationStatusKey.EVALUATE_FEEDBACK_REJECT],
  [11, VisitationStatusKey.RECEPTION],
  [12, VisitationStatusKey.RECEPTION_RESULT],
  [13, VisitationStatusKey.FOLLOW],
  [14, VisitationStatusKey.REQUEST_SIGN],
  [15, VisitationStatusKey.SIGNED],
  [16, VisitationStatusKey.SIGN_REJECT],
  [17, VisitationStatusKey.APPROVAL_FINISHED],
  [18, VisitationStatusKey.APPROVAL_RECALLED],
  [1, VisitationStatusKey.FINISH],
  [19, VisitationStatusKey.CALL_ESIGN],
]);

export enum VisitationStatusCode {
  REQUEST_CONFIRMATION = 4,
  INFORMATION_REQUEST = 3,
  ADDITIONAL_INFORMATION = 2,
  CONFIRM_APPROVE = 5,
  CONFIRM_REJECT = 7,
  EVALUATE_REQUEST = 8,
  EVALUATING = 20,
  ASSIGNMENT = 21,
  EVALUATED = 9,
  EVALUATE_FEEDBACK_REJECT = 10,
  RECEPTION = 11,
  RECEPTION_RESULT = 12,
  FOLLOW = 13,
  REQUEST_SIGN = 14,
  SIGNED = 15,
  SIGN_REJECT = 16,
  APPROVAL_FINISHED = 17,
  APPROVAL_RECALLED = 18,
  FINISH = 1,
  CALL_ESIGN = 19,
}

export const VisitationActionsBtnKey = {
  NOT_AVAILABLE: "notAvailable", // Đang không ở trạng thái của role
  CREATE: "create", // Tạo mới
  UPDATE: "update", // Cập nhật
  INFORMATION_REQUEST: "informationRequest", // Yêu cầu bổ sung thông tin
  ADDITIONAL_INFORMATION: "additionalInformation", // Đã bổ sung thông tin
  FORWARD: "forward", // Chuyển tiếp
  CONFIRM_APPROVED: "confirmApproved", // Xác nhận
  CONFIRM_REJECT: "confirmReject", // Từ chối xác nhận
  REQUEST_EXTENSION_CONFIRM_DEADLINE: "requestExtensionConfirmDeadline", // Yêu cầu gia hạn thời gian xác nhận
  ACCEPT_TIME_EXTENSION_CONFIRM_DEADLINE: "acceptTimeExtensionConfirmDeadline", // Chấp nhận gia hạn thời gian xác nhận
  TIME_EXTENSION_CONFIRM_DEADLINE: "timeExtensionConfirmDeadline", // Gia hạn thời gian xác nhận
  REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE:
    "requestExtensionShareInformationDeadline", // Yêu cầu gia hạn thời gian thông tin chia sẻ
  ACCEPT_TIME_EXTENSION_SHARE_INFORMATION_DEADLINE:
    "acceptTimeExtensionShareInformationDeadline", // Chấp nhận gia hạn thời gian thông tin chia sẻ
  TIME_EXTENSION_SHARE_INFORMATION_DEADLINE:
    "timeExtensionShareInformationDeadline", // Gia hạn thời gian thông tin chia sẻ
  REQUEST_EXTENSION_RESPONSE_LC_DEADLINE: "requestExtensionResponseLcDeadline", // Yêu cầu gia hạn thời gian đánh giá
  ACCEPT_TIME_EXTENSION_RESPONSE_LC_DEADLINE:
    "acceptTimeExtensionResponseLcDeadline", // Chấp nhận gia hạn thời gian đánh giá
  TIME_EXTENSION_RESPONSE_LC_DEADLINE: "timeExtensionResponseLcDeadline", // Gia hạn thời gian đánh giá
  ASSIGNMENT: "assignment", // Phân công
  EVALUATE_REQUEST: "evaluateRequest", // Yêu cầu đánh giá
  EVALUATE_FEEDBACK_CONFIRM: "evaluateFeedbackConfirm", // Đánh giá
  SHARE_INFO_REQUEST: "shareInfoRequest", // Yêu cầu chia sẻ thông tin
  SHARE_INFO_FEEDBACK: "shareInfoFeedback", // Phản hồi chia sẻ
  FEEDBACK: "feedback", // Phản hồi văn bản
  MEETING: "meeting", // Yêu cầu họp
  SAVE_SIGN: "saveSign", // Thay đổi ký duyệt
  REQUEST_SIGN: "requestSign", // Yêu cầu ký duyệt
  SIGN: "sign", // Ký duyệt
  SIGN_REJECT: "signReject", // Ký duyệt: Từ chối
  RECEPTION: "reception", // Tiếp đón
  RECEPTION_RESULT: "receptionResult", // Đã điền kết quả tiếp đón
  FOLLOW: "follow", // Theo dõi kết quả tiếp đón
  FINISH: "finish", // Hoàn thành tiếp đón
  EVALUATE_FEEDBACK_REJECT: "evaluateFeedbackReject", // Từ chối đánh giá
  SEND_MAIL: "sendMail", // Gửi mail
  CHANGE_EVALUATE: "changeEvaluate", // Thay đổi đánh giá
  DELETE_EVALUATE: "deleteEvaluate", // Xóa đánh giá
  CHANGE_SHARE_INFO: "changeShareInfo", // Thay đổi chia sẻ
  DELETE_SHARE_INFO: "deleteShareInfo", // Xóa chia sẻ
  CALL_ESIGN: "callEsign", // Tạo ký duyệt
  REVOKE_ESIGN: "revokeEsign", // Đã thu hồi action ký duyệt
  DELETE_ESIGN: "deleteEsign", // Xóa thông tin gửi phê duyệt
  RECALL: "recall", // Thu hồi
  UPDATE_CONFIRM: "updateConfirm", // Thay đổi xác nhận
  REQUEST_REVIEW_AGAIN: "requestReviewAgain", // Yêu cầu đánh giá lại
  REQUEST_SIGN_AGAIN: "requestSignAgain", // Yêu cầu ký duyệt lại
  SHARE: "share", // Chia sẻ
};

export const VisitationActionsBtn = new Map<string, number>([
  [VisitationActionsBtnKey.NOT_AVAILABLE, 1],
  [VisitationActionsBtnKey.CREATE, 2],
  [VisitationActionsBtnKey.UPDATE, 3],
  [VisitationActionsBtnKey.INFORMATION_REQUEST, 4],
  [VisitationActionsBtnKey.FORWARD, 5],
  [VisitationActionsBtnKey.CONFIRM_APPROVED, 6],
  [VisitationActionsBtnKey.CONFIRM_REJECT, 7],
  [VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE, 8],
  [VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE, 9],
  [VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE, 10],
  [VisitationActionsBtnKey.ACCEPT_TIME_EXTENSION_CONFIRM_DEADLINE, 11],
  [
    VisitationActionsBtnKey.ACCEPT_TIME_EXTENSION_SHARE_INFORMATION_DEADLINE,
    12,
  ],
  [VisitationActionsBtnKey.ACCEPT_TIME_EXTENSION_RESPONSE_LC_DEADLINE, 13],
  [VisitationActionsBtnKey.TIME_EXTENSION_CONFIRM_DEADLINE, 14],
  [VisitationActionsBtnKey.TIME_EXTENSION_SHARE_INFORMATION_DEADLINE, 15],
  [VisitationActionsBtnKey.TIME_EXTENSION_RESPONSE_LC_DEADLINE, 16],
  [VisitationActionsBtnKey.EVALUATE_REQUEST, 17],
  [VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM, 18],
  [VisitationActionsBtnKey.SHARE_INFO_REQUEST, 19],
  [VisitationActionsBtnKey.SHARE_INFO_FEEDBACK, 20],
  [VisitationActionsBtnKey.FEEDBACK, 21],
  [VisitationActionsBtnKey.MEETING, 22],
  [VisitationActionsBtnKey.SAVE_SIGN, 23],
  [VisitationActionsBtnKey.REQUEST_SIGN, 24],
  [VisitationActionsBtnKey.SIGN, 25],
  [VisitationActionsBtnKey.RECEPTION, 26],
  [VisitationActionsBtnKey.RECEPTION_RESULT, 27],
  [VisitationActionsBtnKey.FOLLOW, 28],
  [VisitationActionsBtnKey.FINISH, 29],
  [VisitationActionsBtnKey.EVALUATE_FEEDBACK_REJECT, 30],
  [VisitationActionsBtnKey.SEND_MAIL, 31],
  [VisitationActionsBtnKey.CHANGE_EVALUATE, 32],
  [VisitationActionsBtnKey.DELETE_EVALUATE, 33],
  [VisitationActionsBtnKey.CHANGE_SHARE_INFO, 34],
  [VisitationActionsBtnKey.DELETE_SHARE_INFO, 35],
  [VisitationActionsBtnKey.CALL_ESIGN, 36],
  [VisitationActionsBtnKey.REVOKE_ESIGN, 37],
  [VisitationActionsBtnKey.DELETE_ESIGN, 38],
  [VisitationActionsBtnKey.RECALL, 39],
  [VisitationActionsBtnKey.UPDATE_CONFIRM, 40],
  [VisitationActionsBtnKey.SHARE, 41],
]);

export const VisitationActionsBtnR = new Map<number, string>([
  [1, VisitationActionsBtnKey.NOT_AVAILABLE],
  [2, VisitationActionsBtnKey.CREATE],
  [3, VisitationActionsBtnKey.UPDATE],
  [4, VisitationActionsBtnKey.INFORMATION_REQUEST],
  [5, VisitationActionsBtnKey.FORWARD],
  [6, VisitationActionsBtnKey.CONFIRM_APPROVED],
  [7, VisitationActionsBtnKey.CONFIRM_REJECT],
  [8, VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE],
  [9, VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE],
  [10, VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE],
  [11, VisitationActionsBtnKey.ACCEPT_TIME_EXTENSION_CONFIRM_DEADLINE],
  [
    12,
    VisitationActionsBtnKey.ACCEPT_TIME_EXTENSION_SHARE_INFORMATION_DEADLINE,
  ],
  [13, VisitationActionsBtnKey.ACCEPT_TIME_EXTENSION_RESPONSE_LC_DEADLINE],
  [14, VisitationActionsBtnKey.TIME_EXTENSION_CONFIRM_DEADLINE],
  [15, VisitationActionsBtnKey.TIME_EXTENSION_SHARE_INFORMATION_DEADLINE],
  [16, VisitationActionsBtnKey.TIME_EXTENSION_RESPONSE_LC_DEADLINE],
  [17, VisitationActionsBtnKey.EVALUATE_REQUEST],
  [18, VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM],
  [19, VisitationActionsBtnKey.SHARE_INFO_REQUEST],
  [20, VisitationActionsBtnKey.SHARE_INFO_FEEDBACK],
  [21, VisitationActionsBtnKey.FEEDBACK],
  [22, VisitationActionsBtnKey.MEETING],
  [23, VisitationActionsBtnKey.SAVE_SIGN],
  [24, VisitationActionsBtnKey.REQUEST_SIGN],
  [25, VisitationActionsBtnKey.SIGN],
  [26, VisitationActionsBtnKey.RECEPTION],
  [27, VisitationActionsBtnKey.RECEPTION_RESULT],
  [28, VisitationActionsBtnKey.FOLLOW],
  [29, VisitationActionsBtnKey.FINISH],
  [30, VisitationActionsBtnKey.EVALUATE_FEEDBACK_REJECT],
  [31, VisitationActionsBtnKey.SEND_MAIL],
  [32, VisitationActionsBtnKey.CHANGE_EVALUATE],
  [33, VisitationActionsBtnKey.DELETE_EVALUATE],
  [34, VisitationActionsBtnKey.CHANGE_SHARE_INFO],
  [35, VisitationActionsBtnKey.DELETE_SHARE_INFO],
  [36, VisitationActionsBtnKey.CALL_ESIGN],
  [37, VisitationActionsBtnKey.REVOKE_ESIGN],
  [38, VisitationActionsBtnKey.DELETE_ESIGN],
  [39, VisitationActionsBtnKey.RECALL],
  [40, VisitationActionsBtnKey.UPDATE_CONFIRM],
  [41, VisitationActionsBtnKey.SHARE],
]);

export const getButtonListVisitation = (row: any | undefined) => {
  const code = row?.status?.code;
  const hasLC =
    Array.isArray(row?.staffLCUsers) && row?.staffLCUsers.length > 0;

  const btnCondition = {
    [VisitationActionsBtnKey.FEEDBACK]:
      row?.actionAvailableAndRole?.requestFeedbackAvailableFlag,
    [VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE]:
      code !== VisitationStatusCode.FINISH,
    [VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE]:
      code !== VisitationStatusCode.FINISH,
    [VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE]:
      code !== VisitationStatusCode.FINISH,
    [VisitationActionsBtnKey.INFORMATION_REQUEST]:
      code === VisitationStatusCode.EVALUATE_REQUEST ||
      code === VisitationStatusCode.INFORMATION_REQUEST ||
      code === VisitationStatusCode.ADDITIONAL_INFORMATION,
    [VisitationActionsBtnKey.ADDITIONAL_INFORMATION]:
      code === VisitationStatusCode.INFORMATION_REQUEST,
    [VisitationActionsBtnKey.CONFIRM_APPROVED]:
      !row?.actionAvailableAndRole?.requestConfirmAvailableFlag,
    [VisitationActionsBtnKey.EVALUATE_REQUEST]:
      row?.actionAvailableAndRole?.isEnableEvaluateFlag &&
      code !== VisitationStatusCode.EVALUATING &&
      code !== VisitationStatusCode.EVALUATED,
    [VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM]:
      row?.actionAvailableAndRole?.requestConfirmAvailableFlag &&
      (code === VisitationStatusCode.EVALUATE_REQUEST ||
        code === VisitationStatusCode.INFORMATION_REQUEST ||
        code === VisitationStatusCode.ADDITIONAL_INFORMATION ||
        (code === VisitationStatusCode.REQUEST_CONFIRMATION && hasLC)),
    [VisitationActionsBtnKey.ASSIGNMENT]:
      code === VisitationStatusCode.EVALUATE_REQUEST ||
      code === VisitationStatusCode.INFORMATION_REQUEST ||
      code === VisitationStatusCode.ADDITIONAL_INFORMATION ||
      (code === VisitationStatusCode.REQUEST_CONFIRMATION && hasLC),
    [VisitationActionsBtnKey.REQUEST_SIGN]:
      code === VisitationStatusCode.EVALUATED ||
      code === VisitationStatusCode.SIGN_REJECT ||
      code === VisitationStatusCode.APPROVAL_RECALLED ||
      code === VisitationStatusCode.CALL_ESIGN,
    [VisitationActionsBtnKey.SIGN]: code === VisitationStatusCode.REQUEST_SIGN,
    [VisitationActionsBtnKey.SIGN_REJECT]:
      code === VisitationStatusCode.REQUEST_SIGN,
    [VisitationActionsBtnKey.RECEPTION]:
      code === VisitationStatusCode.APPROVAL_FINISHED ||
      code === VisitationStatusCode.RECEPTION,
    [VisitationActionsBtnKey.RECEPTION_RESULT]:
      code === VisitationStatusCode.RECEPTION ||
      code === VisitationStatusCode.RECEPTION_RESULT,
    [VisitationActionsBtnKey.FOLLOW]:
      code === VisitationStatusCode.RECEPTION_RESULT ||
      code === VisitationStatusCode.FOLLOW,
    [VisitationActionsBtnKey.FINISH]:
      code === VisitationStatusCode.RECEPTION_RESULT ||
      code === VisitationStatusCode.FOLLOW,
  };

  return btnCondition;
};

export const authorizedActionMapCallBackListVisitation = (
  roles: any,
  params: any
) => {
  const btnCondition = getButtonListVisitation(params?.row);

  // For item
  const listItemActionsPic = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE },
    { typeBtn: VisitationActionsBtnKey.SHARE_INFO_REQUEST },
    {
      typeBtn: VisitationActionsBtnKey.EVALUATE_REQUEST,
      disable: !btnCondition[VisitationActionsBtnKey.EVALUATE_REQUEST],
    },
    {
      typeBtn: VisitationActionsBtnKey.ADDITIONAL_INFORMATION,
      disable: !btnCondition[VisitationActionsBtnKey.ADDITIONAL_INFORMATION],
    },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_SIGN,
      disable: !btnCondition[VisitationActionsBtnKey.REQUEST_SIGN],
    },
    {
      typeBtn: VisitationActionsBtnKey.RECEPTION,
      disable: !btnCondition[VisitationActionsBtnKey.RECEPTION],
    },
    {
      typeBtn: VisitationActionsBtnKey.RECEPTION_RESULT,
      disable: !btnCondition[VisitationActionsBtnKey.RECEPTION_RESULT],
    },
  ];

  const listItemActionsConfirmer = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
      disable:
        !btnCondition[
          VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE
        ],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE },
    { typeBtn: VisitationActionsBtnKey.SHARE_INFO_REQUEST },
    {
      typeBtn: VisitationActionsBtnKey.CONFIRM_APPROVED,
      disable: !btnCondition[VisitationActionsBtnKey.CONFIRM_APPROVED],
    },
  ];

  const listItemActionsShareInfo = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    {
      typeBtn:
        VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
      disable:
        !btnCondition[
          VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE
        ],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE },
    { typeBtn: VisitationActionsBtnKey.SHARE_INFO_FEEDBACK },
  ];

  const listItemActionsEvaluation = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: VisitationActionsBtnKey.INFORMATION_REQUEST },
    { typeBtn: VisitationActionsBtnKey.SHARE },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
      disable:
        !btnCondition[
          VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE
        ],
    },
    {
      typeBtn: VisitationActionsBtnKey.ASSIGNMENT,
      disable: !btnCondition[VisitationActionsBtnKey.ASSIGNMENT],
    },
    {
      typeBtn: VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
      disable: !btnCondition[VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM],
    },
    {
      typeBtn: VisitationActionsBtnKey.FOLLOW,
      disable: !btnCondition[VisitationActionsBtnKey.FOLLOW],
    },
    {
      typeBtn: VisitationActionsBtnKey.FINISH,
      disable: !btnCondition[VisitationActionsBtnKey.FINISH],
    },
  ];

  const listItemActionsRelated = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
    },
  ];

  const listItemActionsSign = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE },
    {
      typeBtn: VisitationActionsBtnKey.SIGN,
      disable: !btnCondition[VisitationActionsBtnKey.SIGN],
    },
    {
      typeBtn: VisitationActionsBtnKey.SIGN_REJECT,
      disable: !btnCondition[VisitationActionsBtnKey.SIGN_REJECT],
    },
  ];

  // For list
  const listStatusActionsPic = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsPic,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsPic,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsPic,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsPic,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsPic,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsPic,
    [VisitationStatusKey.EVALUATING]: listItemActionsPic,
    [VisitationStatusKey.EVALUATED]: listItemActionsPic,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsPic,
    [VisitationStatusKey.RECEPTION]: listItemActionsPic,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsPic,
    [VisitationStatusKey.FOLLOW]: listItemActionsPic,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsPic,
    [VisitationStatusKey.SIGNED]: listItemActionsPic,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsPic,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsPic,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsPic,
    [VisitationStatusKey.FINISH]: listItemActionsPic,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsPic,
  };

  const listStatusActionsConfirmer = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsConfirmer,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsConfirmer,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsConfirmer,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsConfirmer,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsConfirmer,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsConfirmer,
    [VisitationStatusKey.EVALUATING]: listItemActionsConfirmer,
    [VisitationStatusKey.EVALUATED]: listItemActionsConfirmer,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsConfirmer,
    [VisitationStatusKey.RECEPTION]: listItemActionsConfirmer,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsConfirmer,
    [VisitationStatusKey.FOLLOW]: listItemActionsConfirmer,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsConfirmer,
    [VisitationStatusKey.SIGNED]: listItemActionsConfirmer,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsConfirmer,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsConfirmer,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsConfirmer,
    [VisitationStatusKey.FINISH]: listItemActionsConfirmer,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsConfirmer,
  };

  const listStatusActionsShareInfo = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsShareInfo,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsShareInfo,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsShareInfo,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsShareInfo,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATING]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATED]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.RECEPTION]: listItemActionsShareInfo,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsShareInfo,
    [VisitationStatusKey.FOLLOW]: listItemActionsShareInfo,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsShareInfo,
    [VisitationStatusKey.SIGNED]: listItemActionsShareInfo,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsShareInfo,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsShareInfo,
    [VisitationStatusKey.FINISH]: listItemActionsShareInfo,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsShareInfo,
  };

  const listStatusActionsEvaluation = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsEvaluation,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsEvaluation,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsEvaluation,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsEvaluation,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsEvaluation,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsEvaluation,
    [VisitationStatusKey.EVALUATING]: listItemActionsEvaluation,
    [VisitationStatusKey.EVALUATED]: listItemActionsEvaluation,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsEvaluation,
    [VisitationStatusKey.RECEPTION]: listItemActionsEvaluation,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsEvaluation,
    [VisitationStatusKey.FOLLOW]: listItemActionsEvaluation,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsEvaluation,
    [VisitationStatusKey.SIGNED]: listItemActionsEvaluation,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsEvaluation,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsEvaluation,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsEvaluation,
    [VisitationStatusKey.FINISH]: listItemActionsEvaluation,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsEvaluation,
  };

  const listStatusActionsSign = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsSign,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsSign,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsSign,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsSign,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsSign,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsSign,
    [VisitationStatusKey.EVALUATING]: listItemActionsSign,
    [VisitationStatusKey.EVALUATED]: listItemActionsSign,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsSign,
    [VisitationStatusKey.RECEPTION]: listItemActionsSign,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsSign,
    [VisitationStatusKey.FOLLOW]: listItemActionsSign,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsSign,
    [VisitationStatusKey.SIGNED]: listItemActionsSign,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsSign,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsSign,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsSign,
    [VisitationStatusKey.FINISH]: listItemActionsSign,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsSign,
  };

  const listStatusActionsRelated = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsRelated,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsRelated,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsRelated,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsRelated,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATING]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATED]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.RECEPTION]: listItemActionsRelated,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsRelated,
    [VisitationStatusKey.FOLLOW]: listItemActionsRelated,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsRelated,
    [VisitationStatusKey.SIGNED]: listItemActionsRelated,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsRelated,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsRelated,
    [VisitationStatusKey.FINISH]: listItemActionsRelated,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsRelated,
  };

  const authorizedActionMap = new Map<number | string, any>([
    [VisitationUserRole.get(VisitationUserRoleKey.PIC)!, listStatusActionsPic],
    [
      VisitationUserRole.get(VisitationUserRoleKey.CONFIRM)!,
      listStatusActionsConfirmer,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.SHARE_INFO)!,
      listStatusActionsShareInfo,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.EVALUATION)!,
      listStatusActionsEvaluation,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.SIGN)!,
      listStatusActionsSign,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.RELATED)!,
      listStatusActionsRelated,
    ],
    [VisitationUserRole.get(VisitationUserRoleKey.VIEWER)!, []],
  ]);

  let listActionAuthorizedMap: TypeActionRole[] = [];

  roles.forEach((item: any) => {
    const authorizedAction =
      authorizedActionMap?.get(item)?.[
        VisitationStatusR.get(params?.row?.status?.code) as string
      ] || [];

    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });

  listActionAuthorizedMap = uniqueCheck(listActionAuthorizedMap);

  return listActionAuthorizedMap;
};

export const listActionDefaultNotOwnerActionVisitation = new Map<
  number,
  TypeActionRole[]
>([
  [
    VisitationUserRole.get(VisitationUserRoleKey.PIC)!,
    [
      { typeBtn: VisitationActionsBtnKey.RECALL },
      { typeBtn: VisitationActionsBtnKey.FORWARD },
      { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    ],
  ],
  [VisitationUserRole.get(VisitationUserRoleKey.CONFIRM)!, []],
  [VisitationUserRole.get(VisitationUserRoleKey.VIEWER)!, []],
]);

export const getButtonInforVisitation = (row: any | undefined) => {
  const code = row?.status?.code;
  const hasLC =
    Array.isArray(row?.staffLCUsers) && row?.staffLCUsers.length > 0;

  const btnCondition = {
    [VisitationActionsBtnKey.FEEDBACK]:
      row?.actionAvailableAndRole?.requestFeedbackAvailableFlag,
    [VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE]:
      code !== VisitationStatusCode.FINISH,
    [VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE]:
      code !== VisitationStatusCode.FINISH,
    [VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE]:
      code !== VisitationStatusCode.FINISH,
    [VisitationActionsBtnKey.INFORMATION_REQUEST]:
      code === VisitationStatusCode.EVALUATE_REQUEST ||
      code === VisitationStatusCode.INFORMATION_REQUEST ||
      code === VisitationStatusCode.ADDITIONAL_INFORMATION,
    [VisitationActionsBtnKey.ADDITIONAL_INFORMATION]:
      code === VisitationStatusCode.INFORMATION_REQUEST,
    [VisitationActionsBtnKey.CONFIRM_APPROVED]:
      !row?.actionAvailableAndRole?.requestConfirmAvailableFlag,
    [VisitationActionsBtnKey.EVALUATE_REQUEST]:
      row?.actionAvailableAndRole?.isEnableEvaluateFlag &&
      code !== VisitationStatusCode.EVALUATING &&
      code !== VisitationStatusCode.EVALUATED,
    [VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM]:
      row?.actionAvailableAndRole?.requestConfirmAvailableFlag &&
      (code === VisitationStatusCode.EVALUATE_REQUEST ||
        code === VisitationStatusCode.INFORMATION_REQUEST ||
        code === VisitationStatusCode.ADDITIONAL_INFORMATION ||
        (code === VisitationStatusCode.REQUEST_CONFIRMATION && hasLC)),
    [VisitationActionsBtnKey.ASSIGNMENT]:
      code === VisitationStatusCode.EVALUATE_REQUEST ||
      code === VisitationStatusCode.INFORMATION_REQUEST ||
      code === VisitationStatusCode.ADDITIONAL_INFORMATION ||
      (code === VisitationStatusCode.REQUEST_CONFIRMATION && hasLC),
    [VisitationActionsBtnKey.REQUEST_SIGN]:
      code === VisitationStatusCode.EVALUATED ||
      code === VisitationStatusCode.SIGN_REJECT ||
      code === VisitationStatusCode.APPROVAL_RECALLED ||
      code === VisitationStatusCode.CALL_ESIGN,
    [VisitationActionsBtnKey.SIGN]: code === VisitationStatusCode.REQUEST_SIGN,
    [VisitationActionsBtnKey.SIGN_REJECT]:
      code === VisitationStatusCode.REQUEST_SIGN,
    [VisitationActionsBtnKey.RECEPTION]:
      code === VisitationStatusCode.APPROVAL_FINISHED ||
      code === VisitationStatusCode.RECEPTION,
    [VisitationActionsBtnKey.RECEPTION_RESULT]:
      code === VisitationStatusCode.RECEPTION ||
      code === VisitationStatusCode.RECEPTION_RESULT,
    [VisitationActionsBtnKey.FOLLOW]:
      code === VisitationStatusCode.RECEPTION_RESULT ||
      code === VisitationStatusCode.FOLLOW,
    [VisitationActionsBtnKey.FINISH]:
      code === VisitationStatusCode.RECEPTION_RESULT ||
      code === VisitationStatusCode.FOLLOW,
  };

  return btnCondition;
};

export const authorizedInforVisitationActionMapCallBack = (
  roles: any,
  params: any
) => {
  const btnCondition = getButtonInforVisitation(params?.row);

  // người tạo/người chịu trách nhiệm
  const listItemActionsPic = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE_INFO_REQUEST },
    { typeBtn: VisitationActionsBtnKey.SHARE },
    {
      typeBtn: VisitationActionsBtnKey.ADDITIONAL_INFORMATION,
      disable: !btnCondition[VisitationActionsBtnKey.ADDITIONAL_INFORMATION],
    },
    {
      typeBtn: VisitationActionsBtnKey.EVALUATE_REQUEST,
      disable: !btnCondition[VisitationActionsBtnKey.EVALUATE_REQUEST],
    },
    {
      typeBtn: VisitationActionsBtnKey.RECEPTION,
      disable: !btnCondition[VisitationActionsBtnKey.RECEPTION],
    },
    {
      typeBtn: VisitationActionsBtnKey.RECEPTION_RESULT,
      disable: !btnCondition[VisitationActionsBtnKey.RECEPTION_RESULT],
    },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_REVIEW_AGAIN,
    },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_SIGN_AGAIN,
    },
  ];

  // role L&C
  const listItemActionsEvaluated = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
      disable:
        !btnCondition[
          VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE
        ],
    },
    {
      typeBtn: VisitationActionsBtnKey.ASSIGNMENT,
      disable: !btnCondition[VisitationActionsBtnKey.ASSIGNMENT],
    },
    {
      typeBtn: VisitationActionsBtnKey.INFORMATION_REQUEST,
      disable: !btnCondition[VisitationActionsBtnKey.INFORMATION_REQUEST],
    },
    {
      typeBtn: VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
      disable: !btnCondition[VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM],
    },
    {
      typeBtn: VisitationActionsBtnKey.FOLLOW,
      disable: !btnCondition[VisitationActionsBtnKey.FOLLOW],
    },
    {
      typeBtn: VisitationActionsBtnKey.FINISH,
      disable: !btnCondition[VisitationActionsBtnKey.FINISH],
    },
  ];

  //  role người chia sẻ
  const listItemActionsShareInfo = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    {
      typeBtn:
        VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
      disable:
        !btnCondition[
          VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE
        ],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE_INFO_FEEDBACK },
  ];

  // role người xác nhận
  const listItemActionsConfirmed = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
      disable:
        !btnCondition[
          VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE
        ],
    },
    {
      typeBtn: VisitationActionsBtnKey.CONFIRM_APPROVED,
      disable: !btnCondition[VisitationActionsBtnKey.CONFIRM_APPROVED],
    },
    {
      typeBtn: VisitationActionsBtnKey.RECEPTION,
      disable: !btnCondition[VisitationActionsBtnKey.RECEPTION],
    },
    {
      typeBtn: VisitationActionsBtnKey.RECEPTION_RESULT,
      disable: !btnCondition[VisitationActionsBtnKey.RECEPTION_RESULT],
    },
  ];

  // role người ký duyệt
  const listItemActionsSign = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
  ];

  // role người liên quan
  const listItemActionsRelated = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
    },
  ];

  const listStatusActionsPic = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsPic,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsPic,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsPic,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsPic,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsPic,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsPic,
    [VisitationStatusKey.EVALUATING]: listItemActionsPic,
    [VisitationStatusKey.EVALUATED]: listItemActionsPic,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsPic,
    [VisitationStatusKey.RECEPTION]: listItemActionsPic,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsPic,
    [VisitationStatusKey.FOLLOW]: listItemActionsPic,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsPic,
    [VisitationStatusKey.SIGNED]: listItemActionsPic,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsPic,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsPic,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsPic,
    [VisitationStatusKey.FINISH]: listItemActionsPic,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsPic,
  };

  const listStatusActionsEvaluated = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsEvaluated,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsEvaluated,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsEvaluated,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsEvaluated,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsEvaluated,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsEvaluated,
    [VisitationStatusKey.EVALUATING]: listItemActionsEvaluated,
    [VisitationStatusKey.EVALUATED]: listItemActionsEvaluated,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsEvaluated,
    [VisitationStatusKey.RECEPTION]: listItemActionsEvaluated,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsEvaluated,
    [VisitationStatusKey.FOLLOW]: listItemActionsEvaluated,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsEvaluated,
    [VisitationStatusKey.SIGNED]: listItemActionsEvaluated,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsEvaluated,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsEvaluated,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsEvaluated,
    [VisitationStatusKey.FINISH]: listItemActionsEvaluated,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsEvaluated,
  };

  const listStatusActionsShareInfo = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsShareInfo,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsShareInfo,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsShareInfo,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsShareInfo,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATING]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATED]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.RECEPTION]: listItemActionsShareInfo,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsShareInfo,
    [VisitationStatusKey.FOLLOW]: listItemActionsShareInfo,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsShareInfo,
    [VisitationStatusKey.SIGNED]: listItemActionsShareInfo,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsShareInfo,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsShareInfo,
    [VisitationStatusKey.FINISH]: listItemActionsShareInfo,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsShareInfo,
  };

  const listStatusActionsConfirmed = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsConfirmed,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsConfirmed,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsConfirmed,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsConfirmed,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsConfirmed,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsConfirmed,
    [VisitationStatusKey.EVALUATING]: listItemActionsConfirmed,
    [VisitationStatusKey.EVALUATED]: listItemActionsConfirmed,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsConfirmed,
    [VisitationStatusKey.RECEPTION]: listItemActionsConfirmed,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsConfirmed,
    [VisitationStatusKey.FOLLOW]: listItemActionsConfirmed,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsConfirmed,
    [VisitationStatusKey.SIGNED]: listItemActionsConfirmed,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsConfirmed,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsConfirmed,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsConfirmed,
    [VisitationStatusKey.FINISH]: listItemActionsConfirmed,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsConfirmed,
  };

  const listStatusActionsSign = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsSign,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsSign,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsSign,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsSign,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsSign,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsSign,
    [VisitationStatusKey.EVALUATING]: listItemActionsSign,
    [VisitationStatusKey.EVALUATED]: listItemActionsSign,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsSign,
    [VisitationStatusKey.RECEPTION]: listItemActionsSign,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsSign,
    [VisitationStatusKey.FOLLOW]: listItemActionsSign,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsSign,
    [VisitationStatusKey.SIGNED]: listItemActionsSign,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsSign,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsSign,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsSign,
    [VisitationStatusKey.FINISH]: listItemActionsSign,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsSign,
  };

  const listStatusActionsRelated = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsRelated,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsRelated,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsRelated,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsRelated,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATING]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATED]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.RECEPTION]: listItemActionsRelated,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsRelated,
    [VisitationStatusKey.FOLLOW]: listItemActionsRelated,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsRelated,
    [VisitationStatusKey.SIGNED]: listItemActionsRelated,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsRelated,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsRelated,
    [VisitationStatusKey.FINISH]: listItemActionsRelated,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsRelated,
  };

  const authorizedActionMap = new Map<number | string, any>([
    [VisitationUserRole.get(VisitationUserRoleKey.PIC)!, listStatusActionsPic],
    [
      VisitationUserRole.get(VisitationUserRoleKey.CONFIRM)!,
      listStatusActionsConfirmed,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.SHARE_INFO)!,
      listStatusActionsShareInfo,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.EVALUATION)!,
      listStatusActionsEvaluated,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.SIGN)!,
      listStatusActionsSign,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.RELATED)!,
      listStatusActionsRelated,
    ],
    [VisitationUserRole.get(VisitationUserRoleKey.VIEWER)!, []],
  ]);

  let listActionAuthorizedMap: TypeActionRole[] = [];

  roles.forEach((item: any) => {
    const authorizedAction =
      authorizedActionMap?.get(item)?.[
        VisitationStatusR.get(params?.row?.status?.code) as string
      ] || [];

    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });

  listActionAuthorizedMap = uniqueCheck(listActionAuthorizedMap);

  return listActionAuthorizedMap;
};

export const authorizedSignActionMapCallBack = (roles: any, params: any) => {
  const btnCondition = getButtonInforVisitation(params?.row);

  // người tạo/người chịu trách nhiệm
  const listItemActionsPic = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    {
      typeBtn: VisitationActionsBtnKey.REQUEST_SIGN,
    },
  ];

  // role L&C
  const listItemActionsEvaluated = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE },
  ];

  //  role người chia sẻ
  const listItemActionsShareInfo = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
  ];

  // role người xác nhận
  const listItemActionsConfirmed = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE },
  ];

  // role người ký duyệt
  const listItemActionsSign = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.SEND_MAIL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
      disable: !btnCondition[VisitationActionsBtnKey.FEEDBACK],
    },
    { typeBtn: VisitationActionsBtnKey.SHARE },
    { typeBtn: VisitationActionsBtnKey.SIGN },
  ];

  // role người liên quan
  const listItemActionsRelated = [
    { typeBtn: VisitationActionsBtnKey.RECALL },
    { typeBtn: VisitationActionsBtnKey.FORWARD },
    {
      typeBtn: VisitationActionsBtnKey.FEEDBACK,
    },
  ];

  const listStatusActionsPic = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsPic,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsPic,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsPic,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsPic,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsPic,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsPic,
    [VisitationStatusKey.EVALUATED]: listItemActionsPic,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsPic,
    [VisitationStatusKey.RECEPTION]: listItemActionsPic,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsPic,
    [VisitationStatusKey.FOLLOW]: listItemActionsPic,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsPic,
    [VisitationStatusKey.SIGNED]: listItemActionsPic,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsPic,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsPic,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsPic,
    [VisitationStatusKey.FINISH]: listItemActionsPic,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsPic,
  };

  const listStatusActionsEvaluated = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsEvaluated,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsEvaluated,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsEvaluated,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsEvaluated,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsEvaluated,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsEvaluated,
    [VisitationStatusKey.EVALUATED]: listItemActionsEvaluated,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsEvaluated,
    [VisitationStatusKey.RECEPTION]: listItemActionsEvaluated,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsEvaluated,
    [VisitationStatusKey.FOLLOW]: listItemActionsEvaluated,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsEvaluated,
    [VisitationStatusKey.SIGNED]: listItemActionsEvaluated,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsEvaluated,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsEvaluated,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsEvaluated,
    [VisitationStatusKey.FINISH]: listItemActionsEvaluated,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsEvaluated,
  };

  const listStatusActionsShareInfo = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsShareInfo,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsShareInfo,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsShareInfo,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsShareInfo,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATED]: listItemActionsShareInfo,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.RECEPTION]: listItemActionsShareInfo,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsShareInfo,
    [VisitationStatusKey.FOLLOW]: listItemActionsShareInfo,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsShareInfo,
    [VisitationStatusKey.SIGNED]: listItemActionsShareInfo,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsShareInfo,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsShareInfo,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsShareInfo,
    [VisitationStatusKey.FINISH]: listItemActionsShareInfo,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsShareInfo,
  };

  const listStatusActionsConfirmed = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsConfirmed,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsConfirmed,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsConfirmed,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsConfirmed,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsConfirmed,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsConfirmed,
    [VisitationStatusKey.EVALUATED]: listItemActionsConfirmed,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsConfirmed,
    [VisitationStatusKey.RECEPTION]: listItemActionsConfirmed,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsConfirmed,
    [VisitationStatusKey.FOLLOW]: listItemActionsConfirmed,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsConfirmed,
    [VisitationStatusKey.SIGNED]: listItemActionsConfirmed,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsConfirmed,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsConfirmed,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsConfirmed,
    [VisitationStatusKey.FINISH]: listItemActionsConfirmed,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsConfirmed,
  };

  const listStatusActionsSign = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsSign,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsSign,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsSign,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsSign,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsSign,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsSign,
    [VisitationStatusKey.EVALUATED]: listItemActionsSign,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsSign,
    [VisitationStatusKey.RECEPTION]: listItemActionsSign,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsSign,
    [VisitationStatusKey.FOLLOW]: listItemActionsSign,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsSign,
    [VisitationStatusKey.SIGNED]: listItemActionsSign,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsSign,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsSign,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsSign,
    [VisitationStatusKey.FINISH]: listItemActionsSign,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsSign,
  };

  const listStatusActionsRelated = {
    [VisitationStatusKey.REQUEST_CONFIRMATION]: listItemActionsRelated,
    [VisitationStatusKey.INFORMATION_REQUEST]: listItemActionsRelated,
    [VisitationStatusKey.ADDITIONAL_INFORMATION]: listItemActionsRelated,
    [VisitationStatusKey.CONFIRM_APPROVE]: listItemActionsRelated,
    [VisitationStatusKey.CONFIRM_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATE_REQUEST]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATED]: listItemActionsRelated,
    [VisitationStatusKey.EVALUATE_FEEDBACK_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.RECEPTION]: listItemActionsRelated,
    [VisitationStatusKey.RECEPTION_RESULT]: listItemActionsRelated,
    [VisitationStatusKey.FOLLOW]: listItemActionsRelated,
    [VisitationStatusKey.REQUEST_SIGN]: listItemActionsRelated,
    [VisitationStatusKey.SIGNED]: listItemActionsRelated,
    [VisitationStatusKey.SIGN_REJECT]: listItemActionsRelated,
    [VisitationStatusKey.APPROVAL_FINISHED]: listItemActionsRelated,
    [VisitationStatusKey.APPROVAL_RECALLED]: listItemActionsRelated,
    [VisitationStatusKey.FINISH]: listItemActionsRelated,
    [VisitationStatusKey.CALL_ESIGN]: listItemActionsRelated,
  };

  const authorizedActionMap = new Map<number | string, any>([
    [VisitationUserRole.get(VisitationUserRoleKey.PIC)!, listStatusActionsPic],
    [
      VisitationUserRole.get(VisitationUserRoleKey.CONFIRM)!,
      listStatusActionsConfirmed,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.SHARE_INFO)!,
      listStatusActionsShareInfo,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.EVALUATION)!,
      listStatusActionsEvaluated,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.SIGN)!,
      listStatusActionsSign,
    ],
    [
      VisitationUserRole.get(VisitationUserRoleKey.RELATED)!,
      listStatusActionsRelated,
    ],
    [VisitationUserRole.get(VisitationUserRoleKey.VIEWER)!, []],
  ]);

  let listActionAuthorizedMap: TypeActionRole[] = [];

  roles.forEach((item: any) => {
    const authorizedAction =
      authorizedActionMap?.get(item)?.[
        VisitationStatusR.get(params?.row?.status?.code) as string
      ] || [];

    listActionAuthorizedMap = listActionAuthorizedMap.concat(authorizedAction);
  });

  listActionAuthorizedMap = uniqueCheck(listActionAuthorizedMap);

  return listActionAuthorizedMap;
};
