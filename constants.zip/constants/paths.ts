export const enum UI_PATH {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  VIEW = "view",
}

export const enum LEGAL_DOCUMENT_PATH {
  SEND = "send",
  FORWARD = "forward",
}
export const MANAGE_CATEGORIES_ROOT_PATH = "manage_categories";

export const REMINDER_TEMPLATE_ROOT_PATH = "reminder-template";

export const FIELD_ROOT_PATH = "field";

export const AGENCY_ISSUED_ROOT_PATH = "agency-issued";

export const STATUS_ROOT_PATH = "status";

export const CURRENCY_ROOT_PATH = "currency";

export const DEPARTMENT_MANAGEMENT_ROOT_PATH = "department_management";

export const DOCUMENT_TYPE_ROOT_PATH = "document-type";

export const HELP_ROOT_PATH = "help";

export const LEGAL_DOCUMENT_ROOT_PATH = "legal-document";

export const DOCUMENT_ROOT_PATH = "document";

export const ROLE_ROOT_PATH = "role";

export const USER_ROOT_PATH = "user";

export const ASSIGNMENT_ROOT_PATH = "assignment";

export const DEPARTMENT_ROOT_PATH = "department";

export const DOCUMENT_MANAGEMENT_ROOT_PATH = "document_management";

export const LEGAL_ADVICE_ROOT_PATH = "legal-advice";

export const LEGAL_VIOLATION_TRACKING_ROOT_PATH = "violation_tracking";

export const CONFLICT_MANAGEMENT_ROOT_PATH = "conflict-management";

export const DOCUMENT_REVIEW_ROOT_PATH = "document-review";

export const VISITATION_ROOT_PATH = "visitation";

export const RELATIONSHIP_DISCLOSURE_ROOT_PATH = "relationship-disclosure";

export const STATISTIC_VIOLATION_TRACK_ROOT_PATH = "statistics-violation-track";

export const STATISTICS_LEGAL_DOCUMENT = "statistics-legal-doc";

export const STATISTICS_LEGAL_ADVICE = "statistics-legal-adv";

export const STATISTICS_DOCUMENT_MANAGEMENT = "statistics-document-mng";

export const STATISTICS_DOCUMENT_REVIEW = "statistics-document-rev";

export const STATISTICS_VISITATION = "statistics-visit";

export const STATISTICS_CONFLICT_MANAGEMENT = "statistics-conflict-mng";

export const STATISTICS_RELATIONSHIP_DISCLOSURE = "statistics-relationship-dis";

export const SETTING_ROOT_PATH = "log_setting";
export const AUDIT_LOG_ROOT_PATH = "audit_log";


export const EMAIL_TEMPLATE_ROOT_PATH = "email_template";
