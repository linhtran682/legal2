import { getStatusList } from "@/apis/service/status/Status";
import { ModuleFields } from "@/constants/general";
import { StatusFieldNames } from "@/models/status/Status";
import { useQuery } from "@tanstack/react-query";

type TypeSearchStatus = {
  keyword?: string;
  modules?: number;
  form?: any;
  queryKey?: string;
};

export const useSearchStatus = (props: TypeSearchStatus) => {
  const {
    keyword,
    modules = ModuleFields.LEGISLATION_NAME.module,
    form,
    queryKey = "GET_LIST_STATUS",
  } = props;
  const getSearchStatusQuery = useQuery({
    queryKey: [queryKey],
    queryFn: async () => {
      try {
        const response = await getStatusList({
          name: keyword,
          modules: [modules],
          page: 0,
          size: 100,
          sortBy: StatusFieldNames.NAME,
          orderBy: "ASC",
          active: 1,
        });
        if (
          response?.statusResponses &&
          response?.statusResponses?.length > 0 && form
        ) {
          form.setValue("status", response?.statusResponses?.[0]?.id);
        }
        return response?.statusResponses || [];
      } catch (error) {}
      return null;
    },
    enabled: !!keyword,
  });
  return getSearchStatusQuery;
};
