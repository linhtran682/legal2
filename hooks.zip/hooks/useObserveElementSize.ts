import { useEffect, useRef, useState } from "react";

const useObserveElementSize = () => {
  const [size, setSize] = useState({ width: 0, height: 0 });
  const elementRef = useRef(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    // Create a ResizeObserver instance
    const resizeObserver = new ResizeObserver((entries) => {
      // Access the element's dimensions
      for (const entry of entries) {
        setSize({
          width: entry.contentRect.width,
          height: entry.contentRect.height,
        });
      }
    });

    // Observe the element
    resizeObserver.observe(element);

    // Cleanup on component unmount
    return () => resizeObserver.unobserve(element);
  }, []);

  return { size, elementRef };
};

export default useObserveElementSize;
