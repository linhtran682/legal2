import i18next from "i18next";
import { initReactI18next } from "react-i18next";
import translationEN from "../en/translate.json";
import translationVI from "../vi/translation.json";

const resources = {
  en: { translation: translationEN },
  vi: { translation: translationVI },
};

export const LANGUAGES = {
  VIETNAMESE: "vi",
  ENGLISH: "en",
};

i18next.use(initReactI18next).init({
  lng: LANGUAGES.VIETNAMESE, // if you're using a language detector, do not define the lng option
  debug: false,
  resources,
});
