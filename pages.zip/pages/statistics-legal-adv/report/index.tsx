import DashboardLayout from '@/components/layouts'
import LegalAdviceReport from '@/features/statistics-legal-advice/legal-advice-report/LegalAdviceReport'
import React from 'react'

const LegalAdviceReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalAdviceReport />
    </DashboardLayout>
  )
}

export default LegalAdviceReportPage