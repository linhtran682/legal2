import DashboardLayout from '@/components/layouts'
import LegalAdviceReportDone from '@/features/statistics-legal-advice/legal-advice-report-done/LegalAdviceReportDone'

const LegalAdviceReportDonePage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalAdviceReportDone />
    </DashboardLayout>
  )
}

export default LegalAdviceReportDonePage