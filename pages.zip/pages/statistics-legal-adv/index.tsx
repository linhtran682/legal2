import DashboardLayout from "@/components/layouts";
import LegalAdviceOverview from "@/features/statistics-legal-advice/legal-advice-overview/LegalAdviceOverview";
// import { useRouter } from "next/router";

export default function LegalAdviceReport() {
  // const router = useRouter();

  return (
    <DashboardLayout noFooterBtn>
      <LegalAdviceOverview />
    </DashboardLayout>
  );
}
