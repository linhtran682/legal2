import { createRole, getRolesDefault } from "@/apis/service/role/Role";
import DashboardLayout from "@/components/layouts";
import { ROLE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveRoleForm } from "@/features/role/save_role_form/SaveRoleForm";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function RolesPage() {
  const router = useRouter();
  const [t] = useTranslation();

  const createRoleQuery = useMutation({
    mutationFn: createRole,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.role"),
        })
      );
      router.push(`/${ROLE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const getRolesDefaultQuery = useQuery({
    queryKey: ["rolesDefault"],
    queryFn: getRolesDefault,
  });
  return (
    <DashboardLayout>
      <SaveRoleForm
        formMode="create"
        onSubmit={createRoleQuery.mutate}
        onCancel={() => router.back()}
        loading={createRoleQuery.isPending || getRolesDefaultQuery.isPending}
        initialValue={{
          permissions: getRolesDefaultQuery.data?.permissions,
          defaultRole: false,
        }}
      />
    </DashboardLayout>
  );
}
