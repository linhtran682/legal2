import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { ROLE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { RoleTable } from "@/features/role/role_table/RoleTable";
import { useRouter } from "next/router";

export default function RolesPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <RoleTable />
      <StickyAddButton
        ariaLabel='add_status'
        onClick={() => router.push(`/${ROLE_ROOT_PATH}/${UI_PATH.CREATE}`)}
      />
    </DashboardLayout>
  );
}
