import { deleteRole, getRole, updateRole } from "@/apis/service/role/Role";
import DashboardLayout from "@/components/layouts";
import { ROLE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveRoleForm } from "@/features/role/save_role_form/SaveRoleForm";
import { RoleDTO } from "@/models/role/Role";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

function UpdateRolePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialRole, setInitialRole] = useState<RoleDTO | undefined>(
    undefined
  );

  const getRoleQuery = useQuery({
    queryKey: ["get_initial_role"],
    queryFn: () =>
      getRole(typeof id == "string" ? String(id) : String((id || [])[0])),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getRoleQuery.refetch().then((response) => {
        setInitialRole(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateRoleQuery = useMutation({
    mutationFn: updateRole,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.role"),
        })
      );
      router.push(`/${ROLE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteRoleListQuery = useMutation({
    mutationFn: deleteRole,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.status"),
        })
      );
      router.push(`/${ROLE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveRoleForm
        formMode="update"
        initialValue={initialRole ?? initialRole}
        onSubmit={(data) =>
          id &&
          updateRoleQuery.mutate({
            request: data,
            id: typeof id == "string" ? String(id) : String(id[0]),
          })
        }
        onDelete={() =>
          id &&
          deleteRoleListQuery.mutate(
            typeof id == "string" ? String(id) : String(id[0])
          )
        }
        onCancel={() => router.back()}
        loading={getRoleQuery.isFetching}
      />
    </DashboardLayout>
  );
}
export default UpdateRolePage;
