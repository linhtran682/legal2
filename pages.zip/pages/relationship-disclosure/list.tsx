import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { RELATIONSHIP_DISCLOSURE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import RelationshipDisclosureTable from "@/features/relationship_disclosure/relationship_disclosure_table/RelationshipDisclosureTable";
import { useRouter } from "next/router";

export default function RelationshipDisclosurePage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <RelationshipDisclosureTable />
      <StickyAddButton
        ariaLabel="add_reminder_template"
        onClick={() =>
          router.push(`/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
