import { useCreateRelationShipDisclosure } from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";
import DashboardLayout from "@/components/layouts";
import {
  Module,
  ModuleKeys,
  RelationshipDisclosureStatusContent,
  RelationshipDisclosureStatusKey,
} from "@/constants/general";
import { RELATIONSHIP_DISCLOSURE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import RelationshipDisclosureForm from "@/features/relationship_disclosure/relationship_disclosure_form/RelationshipDisclosureForm";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { RelationshipDisclosureDetailFields } from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import moment from "moment";
import { useRouter } from "next/router";
import React from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const RelationshipDisclosureCreatePage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const { mutateAsync: createRelationshipDisclosure, isPending } =
    useCreateRelationShipDisclosure({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("legalAdvice.label.legalAdviceRequest"),
            })
          );
          router.push(`/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/${UI_PATH.LIST}`);
        },
      },
    });
  const getSearchStatusQuery = useSearchStatus({
    keyword: "Yêu cầu",
    modules: Module.get(ModuleKeys.DECLARE_RELATIONSHIP)!,
    queryKey: "RELATION_SHIP_DISCLOSURE_CREATE",
  });
  return (
    <DashboardLayout>
      <RelationshipDisclosureForm
        formMode="create"
        defaultValues={{
          ...(getSearchStatusQuery?.data && {
            [RelationshipDisclosureDetailFields.STATUS_CONFIRM]:
              getSearchStatusQuery?.data?.find(
                (status) =>
                  status?.name ===
                  RelationshipDisclosureStatusContent.get(
                    RelationshipDisclosureStatusKey.REQUEST_CONFIRMATION
                  )!  
              )?.id,
            [RelationshipDisclosureDetailFields.STATUS_EVALUATED]:
              getSearchStatusQuery?.data?.find(
                (status) =>
                  status?.name ===
                  RelationshipDisclosureStatusContent.get(
                    RelationshipDisclosureStatusKey.REQUEST_REVIEW
                  )!
              )?.id,
          }),
          [RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]: true,
          [RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG]: true,
          [RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE]: moment()
            .add(3, "days")
            .toDate(),
          [RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE]: moment()
            .add(3, "days")
            .toDate(),
        }}
        onSubmit={createRelationshipDisclosure}
        onSubmitDraft={createRelationshipDisclosure}
        onCancel={() => router.back()}
        loading={isPending}
      />
    </DashboardLayout>
  );
};

export default RelationshipDisclosureCreatePage;
