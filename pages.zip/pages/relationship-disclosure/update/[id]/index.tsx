import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { Box, Stack, Typography } from "@mui/material";
import { AppContext } from "@/context/AppContext";
import {
  GET_CONFIRM_INFORMATION_MANAGEMENT,
  GET_EVALUATE_COMMENT_LIST,
  GET_FOLLOW_MANAGEMENT,
  GET_INITIAL_RELATION_SHIP,
  shareRelationshipDisclosureFn,
  useCreateRelationShipDisclosure,
  useGetRelationShipDisclosure,
  useUpdateBookMeetingRelationshipId,
  useUpdateRelationShipDisclosure,
} from "@/apis/service/relationship_disclosure/relationshipDisclosureForm";
import DashboardLayout from "@/components/layouts";
import { ConflictActionsBtnKey, RelationshipDisclosureStatusContent, RelationshipDisclosureStatusKey } from "@/constants/general";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import { RELATIONSHIP_DISCLOSURE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { castReminderInputToReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { useRecallConflict } from "@/apis/service/conflict_management/conflictMngFormPopup";
import SendMailConflictForm from "@/features/conflict_management/conflict _management_dialog/sendmail_conflict_form";
import { RelationshipDisclosureDetailFields } from "@/models/relationship-disclosure/RelationshipDisclosureDetail";
import { RelationshipDisclosureLayout } from "@/features/relationship_disclosure/layout/RelationshipDisclosureLayout";
import OverviewHeader from "@/features/relationship_disclosure/overview_header/OverviewHeader";
import RelationshipDisclosureForm from "@/features/relationship_disclosure/relationship_disclosure_form/RelationshipDisclosureForm";
import RelationshipDisclosureTabs from "@/features/relationship_disclosure/relationship_disclosure_tabs/RelationshipDisclosureTabs";
import { RequestAdditionalRelationshipForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/request_additional_information_form";
import { ForwardRelationshipMngForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/forward_conflict_mng_form";
import { ConfirmRelationshipMngForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/confirm_relationship_form";
import { RequestEvaluateRelationshipForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/RequestEvaluateRelationshipForm";
import { EvaluateRelationshipMngForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/evaluate_form";
import { FollowRelationshipForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/follow_relationship_mng_form";
import { RelationMngActions } from "@/features/relationship_disclosure/relationship_disclosure_table/RelationMngActions/RelationMngActions";
import { RequestApprovalRelationshipForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/request_approval_form";
import { SignApprovalRelationshipMngForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/sign_approval_conflict_form";
import { FinishRelationshipForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/finish_conflict_mng_form";
import { TimeExtensionRelationshipMngForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/time_extension_conflict_mng_form";
import { FeedbackRelationshipForm } from "@/features/relationship_disclosure/relationship_disclosure_dialog/feedback_conflict_mng_form";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import { ConflictStatusCustom } from "@/features/conflict_management/conflict_management_form/ConflictStatusCustom";

const RelationshipDisclosureDetailPage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const routeAction = router.query.action;
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();
  const [initialRelationshipDisclosure, setInitialRelationshipDisclosure] =
    useState<any>(undefined);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});
  const { data: getRelationshipDisclosure, refetch, isLoading } =
    useGetRelationShipDisclosure({
      request: {
        id: typeof id == "string" ? Number(id) : Number((id || [])[0]),
      },
      config: {
        enabled: !!id,
      },
    });
  const {
    mutate: createRelationshipDisclosure,
    isPending: isPendingCreateRelationship,
  } = useCreateRelationShipDisclosure({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t("menu.relationshipDisclosure"),
          })
        );
        router.push(`/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/${UI_PATH.LIST}`);
      },
    },
  });

  const { mutate: updateBookMeeting, isPending: isPendingBookMeetingRelationship } =
    useUpdateBookMeetingRelationshipId({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t("menu.relationshipDisclosure"),
            })
          );
        },
      },
    });

  const {
    mutate: updateRelationshipDisclosure,
    isPending: isPendingUpdateRelationship,
  } = useUpdateRelationShipDisclosure({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t("menu.relationshipDisclosure"),
          })
        );
        router.push(`/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/${UI_PATH.LIST}`);
      },
    },
  });

  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (reload) {
      queryClient.invalidateQueries({
        queryKey: [GET_INITIAL_RELATION_SHIP],
      });
      queryClient.invalidateQueries({
        queryKey: [GET_EVALUATE_COMMENT_LIST],
      });
      queryClient.invalidateQueries({
        queryKey: [GET_CONFIRM_INFORMATION_MANAGEMENT],
      });
      queryClient.invalidateQueries({
        queryKey: [GET_FOLLOW_MANAGEMENT],
      });
    }
    if (!state) {
      router.replace(`/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/update/${id}`);
      setPopupVisibleState({});
    }
  };

  useEffect(() => {
    if (id && getRelationshipDisclosure && !isLoading) {
      setInitialRelationshipDisclosure({
        ...getRelationshipDisclosure,
        [RelationshipDisclosureDetailFields.FILES]: getRelationshipDisclosure
          ?.receptionStaffInfoAttachments?.length
          ? getRelationshipDisclosure?.receptionStaffInfoAttachments
          : null,
        [RelationshipDisclosureDetailFields.DOCUMENT_NAME]:
          getRelationshipDisclosure?.[
          RelationshipDisclosureDetailFields.DOCUMENT_NAME
          ] ?? "",
        [RelationshipDisclosureDetailFields.STATUS_CONFIRM]:
          getRelationshipDisclosure?.statusConfirm?.id,
        [RelationshipDisclosureDetailFields.STATUS_EVALUATED]:
          getRelationshipDisclosure?.statusEvaluate?.id,
        [RelationshipDisclosureDetailFields.EMPLOYEE_ID]:
          getRelationshipDisclosure?.employeeInfoResponse?.employee?.id ?? "",
        [RelationshipDisclosureDetailFields.EMPLOYEE_NAME]:
          getRelationshipDisclosure?.employeeInfoResponse?.employee?.id ?? "",
        [RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM]:
          getRelationshipDisclosure?.employeeInfoResponse?.[
          RelationshipDisclosureDetailFields.DEPARTMENT_NAME_CUSTOM
          ] ?? "",
        [RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM]:
          getRelationshipDisclosure?.employeeInfoResponse?.[
          RelationshipDisclosureDetailFields.POSITION_NAME_CUSTOM
          ] ?? "",
        [RelationshipDisclosureDetailFields.GROUP_NAME]:
          getRelationshipDisclosure?.employeeInfoResponse?.[
          RelationshipDisclosureDetailFields.GROUP_NAME
          ] ?? "",
        [RelationshipDisclosureDetailFields.WORKING_AREA]:
          getRelationshipDisclosure?.employeeInfoResponse?.[
          RelationshipDisclosureDetailFields.WORKING_AREA
          ] ?? "",
        [RelationshipDisclosureDetailFields.MANAGER_ID]:
          getRelationshipDisclosure?.employeeInfoResponse?.manager?.id,
        [RelationshipDisclosureDetailFields.NAME]:
          getRelationshipDisclosure?.officerInfoResponse?.[
          RelationshipDisclosureDetailFields.NAME
          ] ?? "",
        [RelationshipDisclosureDetailFields.AGENCY]:
          getRelationshipDisclosure?.officerInfoResponse?.[
          RelationshipDisclosureDetailFields.AGENCY
          ] ?? "",
        [RelationshipDisclosureDetailFields.POSITION]:
          getRelationshipDisclosure?.officerInfoResponse?.[
          RelationshipDisclosureDetailFields.POSITION
          ] ?? "",
        [RelationshipDisclosureDetailFields.ROLE_DESCRIPTION]:
          getRelationshipDisclosure?.officerInfoResponse?.[
          RelationshipDisclosureDetailFields.ROLE_DESCRIPTION
          ] ?? "",
        [RelationshipDisclosureDetailFields.CHARACTERISTIC]:
          getRelationshipDisclosure?.officerInfoResponse?.[
          RelationshipDisclosureDetailFields.CHARACTERISTIC
          ] ?? "",
        [RelationshipDisclosureDetailFields.RELATION_SHIP]:
          getRelationshipDisclosure?.[
          RelationshipDisclosureDetailFields.RELATION_SHIP
          ] ?? [],
        [RelationshipDisclosureDetailFields.REASON_RELATION_SHIP]:
          getRelationshipDisclosure?.[
          RelationshipDisclosureDetailFields.REASON_RELATION_SHIP
          ],
        [RelationshipDisclosureDetailFields.EMPLOYEE_IDS]:
          getRelationshipDisclosure?.employees?.[0]?.id ?? "",
        [RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE]:
          getRelationshipDisclosure?.[
            RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE
          ]
            ? new Date(
              getRelationshipDisclosure?.[
              RelationshipDisclosureDetailFields.CONFIRMATION_DEADLINE
              ]
            )
            : undefined,
        [RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG]:
          !!getRelationshipDisclosure?.[
          RelationshipDisclosureDetailFields.CHECK_DEPT_HEAD_FLAG
          ],
        [RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG]:
          !!getRelationshipDisclosure?.[
          RelationshipDisclosureDetailFields.CHECK_DIVISION_FLAG
          ],
        [RelationshipDisclosureDetailFields.LC_EMPLOYEE_IDS]:
          getRelationshipDisclosure?.[
            RelationshipDisclosureDetailFields.LC_EMPLOYEES
          ]?.[0]?.id ?? "",
        [RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE]:
          getRelationshipDisclosure?.[
            RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE
          ]
            ? new Date(
              getRelationshipDisclosure?.[
              RelationshipDisclosureDetailFields.LC_REVIEW_DEADLINE
              ]
            )
            : undefined,
        [RelationshipDisclosureDetailFields.REMIND]: getRelationshipDisclosure
          ?.remind?.title
          ? castReminderInputToReminderSchema(getRelationshipDisclosure?.remind)
          : undefined,
      });
    }
  }, [id, getRelationshipDisclosure, isLoading]);

  const handleClick = (type: any) => {
    if (type) {
      router.replace(
        `/${RELATIONSHIP_DISCLOSURE_ROOT_PATH}/update/${id}?action=${type}`
      );
    }
  };
  const { mutateAsync: recallConflictMutationFn } = useRecallConflict({
    config: {
      onSuccess: () => {
        toast.success(
          t("RELATION_SHIP_DISCLOSURE.recallConflict.message.recall_success")
        );
      },
    },
  });
  useEffect(() => {
    if (routeAction) {
      changePopupVisible(routeAction, true);
    }
  }, [routeAction]);

  const shareMutation = useMutation({
    mutationFn: shareRelationshipDisclosureFn,
    onSuccess: () => {
      toast.success(
        t(`RELATION_SHIP_DISCLOSURE.messages.shareSuccess`)
      );
    },
  });
  useEffect(() => {
    if (id) {
      refetch();
    }
  }, [id, refetch]);

  return (
    <DashboardLayout hideHeader>
      <RelationshipDisclosureLayout>
        <Stack direction={"column"} sx={{ height: "100%" }}>
          <Breadcrumb />
          <Typography variant="h1" sx={{ fontSize: "24px", mb: 2 }}>
            {getRelationshipDisclosure?.documentName}
          </Typography>
          {getRelationshipDisclosure && (
            <Box display="flex" flexDirection="column" gap={1} mb={2}>
              <ConflictStatusCustom
                label=""
                optionItem={
                  getRelationshipDisclosure?.statusEvaluate ??
                  getRelationshipDisclosure?.statusConfirm
                }
              />
            </Box>
          )}
          {getRelationshipDisclosure &&
            !getRelationshipDisclosure?.isDraft &&
            getRelationshipDisclosure?.statusConfirm?.name !==
              RelationshipDisclosureStatusContent.get(
                RelationshipDisclosureStatusKey.DONE
              )! && (
              <RelationMngActions
                actionButtonItemValidate={Object.entries(
                  // eslint-disable-next-line @typescript-eslint/no-non-null-asserted-optional-chain
                  getRelationshipDisclosure?.buttonAction!
                )
                  // eslint-disable-next-line @typescript-eslint/no-unused-vars
                  .filter(([_, value]) => value !== 3)
                  .map(([key, value]) => ({
                    typeBtn: key,
                    disable: value === 2,
                  }))}
                params={initialRelationshipDisclosure}
                isActionDetail
                handleClickRecall={async () =>
                  await recallConflictMutationFn(Number(id))
                }
                handleClickForWard={() =>
                  handleClick(ConflictActionsBtnKey.FORWARD)
                }
                handleClickExtendTime={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_TIME_EXTENSION)
                }
                handleClickConfirm={async () =>
                  handleClick(ConflictActionsBtnKey.CONFIRM)
                }
                handleClickRequestAdditional={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_ADDITIONAL)
                }
                handleClickRequestEvaluate={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_EVALUATE)
                }
                handleClickDone={() => handleClick(ConflictActionsBtnKey.DONE)}
                handleClickRequestConfirm={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_CONFIRM)
                }
                handleClickConflictMonitor={() => {
                  handleClick(ConflictActionsBtnKey.CONFLICT_MONITORING);
                }}
                handleClickSendMail={() =>
                  handleClick(ConflictActionsBtnKey.SEND_MAIL)
                }
                handleClickFeedBack={() =>
                  handleClick(ConflictActionsBtnKey.FEEDBACK)
                }
                handleClickExtendTimeConfirm={() =>
                  handleClick(ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM)
                }
                handleClickEvaluate={() =>
                  handleClick(ConflictActionsBtnKey.EVALUATE)
                }
                handleClickSignApprove={() => {
                  handleClick(ConflictActionsBtnKey.APPROVE);
                }}
                handleClickShare={() =>
                  handleClick(ConflictActionsBtnKey.SHARE)
                }
              />
            )}
          <Box sx={{ flex: 1, overflowY: "auto" }}>
            <OverviewHeader
              initialValueReceive={initialRelationshipDisclosure}
              handleUpdateBookMeeting={updateBookMeeting}
              isLoading={isPendingBookMeetingRelationship}
            />
            <RelationshipDisclosureForm
              formMode="update"
              defaultValues={initialRelationshipDisclosure}
              initialValue={getRelationshipDisclosure}
              onCancel={() => router.back()}
              loading={
                isLoading ||
                isPendingCreateRelationship ||
                isPendingUpdateRelationship
              }
              onSubmitDraft={(data) => {
                if (id) {
                  updateRelationshipDisclosure({
                    request: data,
                    id: typeof id == "string" ? Number(id) : Number(id[0]),
                  });
                }
              }}
              onSubmit={(data: any) => {
                if (id && initialRelationshipDisclosure?.isDraft) {
                  createRelationshipDisclosure({
                    ...data,
                    isDraft: false,
                    legalAdviceId: initialRelationshipDisclosure.id,
                  });
                }
                if (id && !initialRelationshipDisclosure?.isDraft) {
                  updateRelationshipDisclosure({
                    request: data,
                    id: typeof id == "string" ? Number(id) : Number(id[0]),
                  });
                }
              }}
            />
            {getRelationshipDisclosure?.id && (
              <>
                <Box height={16} />
                <RelationshipDisclosureTabs
                  relationshipDisclosureId={getRelationshipDisclosure?.id}
                  relationshipDisclosure={getRelationshipDisclosure}
                />
              </>
            )}
          </Box>
        </Stack>
      </RelationshipDisclosureLayout>
      {popupVisibleState?.[ConflictActionsBtnKey.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialRelationshipDisclosure?.pic}
          pics={initialRelationshipDisclosure?.responsibleUsers}
          onSubmit={async (data: any) => {
            const params = {
              id: initialRelationshipDisclosure?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
          initialValue={{
            legalAccessType: initialRelationshipDisclosure?.legalAccessType,
            sharedDepartments: initialRelationshipDisclosure?.sharedDepartments,
            sharedUsers: initialRelationshipDisclosure?.sharedUsers,
          }}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAdditionalRelationshipForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_ADDITIONAL,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL]}
          conflictId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialRelationshipDisclosure?.pic],
          }}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FORWARD] && (
        <ForwardRelationshipMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FORWARD, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FORWARD]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {initialRelationshipDisclosure &&
        popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION] && (
          <TimeExtensionRelationshipMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.REQUEST_TIME_EXTENSION,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION]
            }
            ciId={initialRelationshipDisclosure?.id}
            name={initialRelationshipDisclosure?.documentName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialRelationshipDisclosure?.pic],
              timeExtensionType: 2,
            }}
          />
        )}
      {initialRelationshipDisclosure &&
        popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM] && (
          <TimeExtensionRelationshipMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM]
            }
            ciId={initialRelationshipDisclosure?.id}
            name={initialRelationshipDisclosure?.documentName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialRelationshipDisclosure?.pic],
              timeExtensionType: 1,
            }}
          />
        )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE] && (
        <RequestEvaluateRelationshipForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_EVALUATE,
              state,
              reload
            )
          }
          ciId={initialRelationshipDisclosure?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE]}
          name={initialRelationshipDisclosure?.documentName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM] && (
        <RequestApprovalRelationshipForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_CONFIRM,
              state,
              reload
            )
          }
          ciId={initialRelationshipDisclosure?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM]}
          name={initialRelationshipDisclosure?.documentName}
          initialValue={{
            deadline: initialRelationshipDisclosure.lcReviewDeadline,
          }}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFIRM] && (
        <ConfirmRelationshipMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.CONFIRM, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.CONFIRM]}
          drId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.DONE] && (
        <FinishRelationshipForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.DONE]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL] && (
        <SendMailConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.SEND_MAIL, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL]}
          conflictId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          legalAdvice={initialRelationshipDisclosure}
          senderDocumentManagement ={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFLICT_MONITORING] && (
        <FollowRelationshipForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.CONFLICT_MONITORING,
              state,
              reload
            )
          }
          isOpen={true}
          drId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK] && (
        <FeedbackRelationshipForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FEEDBACK, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderConflict={appContext?.me}
        />
      )}
      {/* Ký duyệt */}
      {popupVisibleState?.[ConflictActionsBtnKey.APPROVE] && (
        <SignApprovalRelationshipMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.APPROVE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.APPROVE]}
          ciId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderDocumentManagement={appContext?.me}
        />
      )}

      {/* Đánh giá nhận xét */}
      {popupVisibleState?.[ConflictActionsBtnKey.EVALUATE] && (
        <EvaluateRelationshipMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.EVALUATE, state, reload)
          }
          isOpen={true}
          drId={initialRelationshipDisclosure?.id}
          name={initialRelationshipDisclosure?.documentName}
          senderDocumentManagement={appContext?.me}
        />
      )}
    </DashboardLayout>
  );
};

export default RelationshipDisclosureDetailPage;
