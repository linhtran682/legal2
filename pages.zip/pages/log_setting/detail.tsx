import DashboardLayout from "@/components/layouts";
import { SettingLogForm } from "@/features/setting-log/SettingLogForm";

  
export default function SettingLogPage() {
  return (
    <DashboardLayout>
      <SettingLogForm />
    </DashboardLayout>
  );
}
