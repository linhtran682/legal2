import DashboardLayout from "@/components/layouts";

export default function Home() {
  return (
    <DashboardLayout>
      <></>
    </DashboardLayout>
  );
}
