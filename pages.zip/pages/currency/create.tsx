import { createCurrency } from "@/apis/service/currency/Currency";
import DashboardLayout from "@/components/layouts";
import { CURRENCY_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveCurrencyForm } from "@/features/currency/save_currency_form/SaveCurrencyForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateCurrencyPage() {
  const [t] = useTranslation();
  const router = useRouter();

  const createCurrencyQuery = useMutation({
    mutationFn: createCurrency,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.currency"),
        })
      );
      router.push(`/${CURRENCY_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveCurrencyForm
        formMode='create'
        onSubmit={createCurrencyQuery.mutate}
        onCancel={() => router.back()}
        loading={createCurrencyQuery.isPending}
      />
    </DashboardLayout>
  );
}
