import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { CURRENCY_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { CurrencyTable } from "@/features/currency/currency_table/CurrencyTable";
import { useRouter } from "next/navigation";

export default function CurrencyListPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <CurrencyTable />
      <StickyAddButton
        ariaLabel='add_currency'
        onClick={() => router.push(`/${CURRENCY_ROOT_PATH}/${UI_PATH.CREATE}`)}
      />
    </DashboardLayout>
  );
}
