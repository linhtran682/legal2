import {
  deleteCurrencies,
  getCurrency,
  updateCurrency,
} from "@/apis/service/currency/Currency";
import DashboardLayout from "@/components/layouts";
import { CURRENCY_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveCurrencyForm } from "@/features/currency/save_currency_form/SaveCurrencyForm";
import { CurrencyDTO } from "@/models/currency/Currency";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateCurrencyPage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialCurrency, setInitialCurrency] = useState<
    CurrencyDTO | undefined
  >(undefined);

  const getCurrencyQuery = useQuery({
    queryKey: ["get_initial_currency"],
    queryFn: () =>
      getCurrency(typeof id == "string" ? Number(id) : Number((id || [])[0])),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getCurrencyQuery
        .refetch()
        .then((response) => {
          setInitialCurrency(response.data);
        })
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateCurrencyQuery = useMutation({
    mutationFn: updateCurrency,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.currency"),
        })
      );
      router.push(`/${CURRENCY_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteCurrenciesQuery = useMutation({
    mutationFn: deleteCurrencies,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.currency"),
        })
      );
      router.push(`/${CURRENCY_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveCurrencyForm
        formMode='update'
        initialValue={initialCurrency}
        onSubmit={(data) =>
          id &&
          updateCurrencyQuery.mutate({
            request: data,
            id: typeof id == "string" ? Number(id) : Number(id[0]),
          })
        }
        onDelete={() =>
          id &&
          deleteCurrenciesQuery.mutate(
            typeof id == "string" ? [Number(id)] : [Number(id[0])]
          )
        }
        onCancel={() => router.back()}
        loading={
          updateCurrencyQuery.isPending ||
          getCurrencyQuery.isFetching ||
          deleteCurrenciesQuery.isPending
        }
      />
    </DashboardLayout>
  );
}
