import DashboardLayout from '@/components/layouts'
import ConflictMngReport from '@/features/statistics-conflict-mng/conflict-mng-report/ConflictMngReport'
import React from 'react'

const ConflictReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <ConflictMngReport/>
    </DashboardLayout>
  )
}

export default ConflictReportPage