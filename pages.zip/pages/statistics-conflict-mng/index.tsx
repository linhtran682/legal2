import DashboardLayout from "@/components/layouts";
import ConflictMngOverview from "@/features/statistics-conflict-mng/conflict-mng-overview/ConflictMngOverview";

export default function ConflictMngReport() {

  return (
    <DashboardLayout noFooterBtn>
      <ConflictMngOverview />
    </DashboardLayout>
  );
}
