import DashboardLayout from '@/components/layouts'
import ConflictMngReportDone from '@/features/statistics-conflict-mng/conflict-mng-report-done/ConflictMngReportDone'

const LegalAdviceReportDonePage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <ConflictMngReportDone />
    </DashboardLayout>
  )
}

export default LegalAdviceReportDonePage