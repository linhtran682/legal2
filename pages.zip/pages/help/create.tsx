import { createHelp } from "@/apis/service/help/Help";
import DashboardLayout from "@/components/layouts";
import { HELP_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveHelpForm } from "@/features/help/save_help_form/SaveHelpForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateHelpPage() {
  const [t] = useTranslation();
  const router = useRouter();

  const createHelpQuery = useMutation({
    mutationFn: createHelp,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.help"),
        })
      );
      router.push(`/${HELP_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveHelpForm
        formMode='create'
        onSubmit={createHelpQuery.mutate}
        onCancel={() => router.back()}
        loading={createHelpQuery.isPending}
      />
    </DashboardLayout>
  );
}
