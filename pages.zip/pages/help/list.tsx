import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { HELP_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { HelpTable } from "@/features/help/help_table/HelperTable";
import { useRouter } from "next/navigation";

export default function HelpListPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <HelpTable />
      <StickyAddButton
        ariaLabel='add_help'
        onClick={() => router.push(`/${HELP_ROOT_PATH}/${UI_PATH.CREATE}`)}
      />
    </DashboardLayout>
  );
}
