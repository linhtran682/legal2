import { deleteHelps, getHelp, updateHelp } from "@/apis/service/help/Help";
import DashboardLayout from "@/components/layouts";
import { HELP_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveHelpForm } from "@/features/help/save_help_form/SaveHelpForm";
import { HelpDTO } from "@/models/help/Help";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateHelpPage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialHelp, setInitialHelp] = useState<HelpDTO | undefined>(
    undefined
  );

  const getHelpQuery = useQuery({
    queryKey: ["get_initial_help"],
    queryFn: () =>
      getHelp(typeof id == "string" ? Number(id) : Number((id || [])[0])),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getHelpQuery
        .refetch()
        .then((response) => {
          setInitialHelp(response.data);
        })
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateHelpQuery = useMutation({
    mutationFn: updateHelp,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.help"),
        })
      );
      router.push(`/${HELP_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteHelpsQuery = useMutation({
    mutationFn: deleteHelps,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.help"),
        })
      );
      router.push(`/${HELP_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveHelpForm
        formMode='update'
        initialValue={initialHelp}
        onSubmit={(data) =>
          id &&
          updateHelpQuery.mutate({
            request: data,
            id: typeof id == "string" ? Number(id) : Number(id[0]),
          })
        }
        onDelete={() =>
          id &&
          deleteHelpsQuery.mutate(
            typeof id == "string" ? [Number(id)] : [Number(id[0])]
          )
        }
        onCancel={() => router.back()}
        loading={
          updateHelpQuery.isPending ||
          getHelpQuery.isFetching ||
          deleteHelpsQuery.isPending
        }
      />
    </DashboardLayout>
  );
}
