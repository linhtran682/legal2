import DashboardLayout from "@/components/layouts";
import { MailDetail } from "@/features/setting/mail/detail/MailDetail";
import { MailPanel } from "@/features/setting/mail/panel/MailPanel";
import { MailItem } from "@/models/setting/Mail";
import { Grid } from "@mui/material";
import { useState } from "react";

export default function SettingMailListPage() {
    const [mail, setMail] = useState<MailItem>();

  return (
    <DashboardLayout>
      <Grid
        container
        direction={"row"}
        sx={{ overflow: "hidden", height: "100%" }}
        columnGap={2}
      >
        <Grid item xs={3}>
          <MailPanel onSelect={setMail} />
        </Grid>
        <Grid item flex={1}>
          {mail && <MailDetail mail={mail} />}
        </Grid>
      </Grid>
    </DashboardLayout>
  );
}
