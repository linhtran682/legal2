import DashboardLayout from '@/components/layouts'
import VisitationReportDone from '@/features/statistics-visitation/report-done/VisitationReportDone'

const VisitationReportDonePage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <VisitationReportDone />
    </DashboardLayout>
  )
}

export default VisitationReportDonePage