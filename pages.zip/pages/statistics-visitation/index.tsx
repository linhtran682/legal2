import DashboardLayout from "@/components/layouts";
import VisitationOverview from "@/features/statistics-visitation/overview/VisitationOverview";

export default function VisitationReport() {

  return (
    <DashboardLayout noFooterBtn>
      <VisitationOverview />
    </DashboardLayout>
  );
}
