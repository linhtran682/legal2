import DashboardLayout from '@/components/layouts'
import VisitationReport from '@/features/statistics-visitation/report/VisitationReport'
import React from 'react'

const VisitationReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <VisitationReport />
    </DashboardLayout>
  )
}

export default VisitationReportPage