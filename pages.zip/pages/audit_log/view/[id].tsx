import { getLogDetail } from "@/apis/service/setting/LogApi";
import DashboardLayout from "@/components/layouts";
import AuditLogForm from "@/features/audit_log/form/DetailForm";
import { AuditLog } from "@/models/setting/Log";
import {  useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";

export default function AuditLogDetailPage() {
  const router = useRouter();
  const id = router.query.id;

  const getLogDetailQuery = useQuery({
    queryKey: ["get_initial_log"],
    queryFn: () =>
      getLogDetail(typeof id == "string" ? id : (id || [])[0]),
    enabled: !!id,
  });


  return (
    <DashboardLayout>
      <AuditLogForm initialValue={getLogDetailQuery.data as AuditLog } />
    </DashboardLayout>
  );
}
