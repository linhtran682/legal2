import DashboardLayout from "@/components/layouts";
import AuditLogList from "@/features/audit_log/AuditLogList";

export default function AuditLogsPage() {

  return (
    <DashboardLayout noFooterBtn>
      <AuditLogList />
    </DashboardLayout>
  );
}
