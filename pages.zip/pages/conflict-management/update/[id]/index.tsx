import {
  GET_CONFIRM_INFORMATION_MANAGEMENT,
  GET_EVALUATE_COMMENT_LIST,
  GET_FOLLOW_MANAGEMENT,
  GET_INITIAL_CONFLICT_MANAGEMENT,
  shareConflictFn,
  useCreateConflictManagement,
  useGetConflictManagement,
  useUpdateBookMeetingConflict,
  useUpdateConflictManagement,
} from "@/apis/service/conflict_management/conflictManagementForm";
import DashboardLayout from "@/components/layouts";
import { ConflictActionsBtnKey, ConflictManagementStatusContent, ConflictManagementStatusKey } from "@/constants/general";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import { CONFLICT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import { ConfirmConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/confirm_conflict_mng_form";
import { FinishConflictForm } from "@/features/conflict_management/conflict _management_dialog/finish_conflict_mng_form";
import { ForwardConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/forward_conflict_mng_form";
import { RequestAdditionalForm } from "@/features/conflict_management/conflict _management_dialog/request_additional_information_form";
import { RequestApprovalConflictForm } from "@/features/conflict_management/conflict _management_dialog/request_approval_form";
import { RequestEvaluateConflictForm } from "@/features/conflict_management/conflict _management_dialog/RequestEvalueteConfictForm";
import { TimeExtensionConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/time_extension_conflict_mng_form";
import ConflictManagementTabs from "@/features/conflict_management/conflict-management-tabs/ConflictManagementTabs";
import ConflictManagementForm from "@/features/conflict_management/conflict_management_form/ConflictManagementForm";
import { ConflictMngActions } from "@/features/conflict_management/conflict_management_table/ConflictMngActions/ConflictMngActions";
import { ConflictManagementLayout } from "@/features/conflict_management/layout/ConflictManagementLayout";
import { ConflictManagementDetailFields } from "@/models/conflict_management/ConflictManagementDetail";
import { castReminderInputToReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { Box, Stack, Typography } from "@mui/material";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { useRecallConflict } from "@/apis/service/conflict_management/conflictMngFormPopup";
import SendMailConflictForm from "@/features/conflict_management/conflict _management_dialog/sendmail_conflict_form";
import { FollowConflictForm } from "@/features/conflict_management/conflict _management_dialog/follow_conflict_mng_form";
import { FeedbackConflictForm } from "@/features/conflict_management/conflict _management_dialog/feedback_conflict_mng_form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import OverviewHeader from "@/features/conflict_management/overview_header/OverviewHeader";
import { EvaluateConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/evaluate_form";
import { SignApprovalConflictMngForm } from "@/features/conflict_management/conflict _management_dialog/sign_approval_conflict_form";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import { ConflictStatusCustom } from "@/features/conflict_management/conflict_management_form/ConflictStatusCustom";

const ConflictManagementDetailPage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const routeAction = router.query.action;
  const appContext = useContext(AppContext);
  const queryClient = useQueryClient();
  const [initialConflictManagement, setInitialConflictManagement] =
    useState<any>(undefined);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});
  const { data: getConflictManagement, refetch, isLoading } = useGetConflictManagement({
    request: { id: typeof id == "string" ? Number(id) : Number((id || [])[0]) },
    config: {
      enabled: !!id,
    },
  });
  const {
    mutate: createConflictManagement,
    isPending: isPendingCreateConflictManagement,
  } = useCreateConflictManagement({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t("menu.conflictManagement"),
          })
        );
        router.push(`/${CONFLICT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
      },
    },
  });

  const { mutate: updateBookMeeting, isPending: isPendingBookMeetingConflict } =
    useUpdateBookMeetingConflict({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t("menu.conflictManagement"),
            })
          );
        },
      },
    });

  const {
    mutate: updateConflictManagement,
    isPending: isPendingUpdateConflictManagement,
  } = useUpdateConflictManagement({
    config: {
      onSuccess: () => {
        toast.success(
          t("common.message.update_success", {
            recordName: t("menu.conflictManagement"),
          })
        );
        router.push(`/${CONFLICT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
      },
    },
  });

  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (reload) {
      queryClient.invalidateQueries({
        queryKey: [GET_INITIAL_CONFLICT_MANAGEMENT],
      });
      queryClient.invalidateQueries({
        queryKey: [GET_EVALUATE_COMMENT_LIST],
      });
      queryClient.invalidateQueries({
        queryKey: [GET_CONFIRM_INFORMATION_MANAGEMENT],
      });
      queryClient.invalidateQueries({
        queryKey: [GET_FOLLOW_MANAGEMENT],
      });
    }
    if (!state) {
      router.replace(`/${CONFLICT_MANAGEMENT_ROOT_PATH}/update/${id}`);
      setPopupVisibleState({});
    }
  };

  useEffect(() => {
    if (id && getConflictManagement && !isLoading) {
      setInitialConflictManagement({
        ...getConflictManagement,
        [ConflictManagementDetailFields.FILES]: getConflictManagement
          ?.employeeAttachments?.length
          ? getConflictManagement?.employeeAttachments
          : null,
        [ConflictManagementDetailFields.CONFLICT_NAME]:
          getConflictManagement?.[
          ConflictManagementDetailFields.CONFLICT_NAME
          ] ?? "",
        [ConflictManagementDetailFields.STATUS_CONFIRM]:
          getConflictManagement?.statusConfirm?.id,
        [ConflictManagementDetailFields.STATUS_EVALUATED]:
          getConflictManagement?.statusEvaluate?.id,
        [ConflictManagementDetailFields.EMPLOYEE_CODE]:
          getConflictManagement?.employeeInfo?.employee?.id ?? "",
        [ConflictManagementDetailFields.EMPLOYEE_NAME]:
          getConflictManagement?.employeeInfo?.employee?.id ?? "",
        [ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM]:
          getConflictManagement?.employeeInfo?.[
          ConflictManagementDetailFields.DEPARTMENT_NAME_CUSTOM
          ] ?? "",
        [ConflictManagementDetailFields.POSITION_NAME_CUSTOM]:
          getConflictManagement?.employeeInfo?.[
          ConflictManagementDetailFields.POSITION_NAME_CUSTOM
          ] ?? "",
        [ConflictManagementDetailFields.MANAGER_ID]:
          getConflictManagement?.employeeInfo?.manager?.id ?? "",
        [ConflictManagementDetailFields.CONFLICT_OBJECT_NAME]:
          getConflictManagement?.conflictObject?.name ?? "",
        [ConflictManagementDetailFields.CONFLICT_OBJECT_AGENCY]:
          getConflictManagement?.conflictObject?.agency ?? "",
        [ConflictManagementDetailFields.CONFLICT_OBJECT_POSITION]:
          getConflictManagement?.conflictObject?.position ?? "",
        [ConflictManagementDetailFields.CONFLICT_OBJECT_RELATION]:
          getConflictManagement?.conflictObject?.relation ?? "",
        [ConflictManagementDetailFields.NATURE_CONFLICT]:
          getConflictManagement?.[
          ConflictManagementDetailFields.NATURE_CONFLICT
          ] ?? [],
        [ConflictManagementDetailFields.REASON_CONFLICT]:
          getConflictManagement?.[
          ConflictManagementDetailFields.REASON_CONFLICT
          ],
        [ConflictManagementDetailFields.CONFLICT_DETAIL]:
          getConflictManagement?.[
          ConflictManagementDetailFields.CONFLICT_DETAIL
          ],
        [ConflictManagementDetailFields.CONFLICT_RESOLUTION]:
          getConflictManagement?.[
          ConflictManagementDetailFields.CONFLICT_RESOLUTION
          ],
        [ConflictManagementDetailFields.EMPLOYEE_IDS]:
          getConflictManagement?.employees?.[0]?.id ?? "",
        [ConflictManagementDetailFields.CONFIRMATION_DEADLINE]:
          getConflictManagement?.[
            ConflictManagementDetailFields.CONFIRMATION_DEADLINE
          ]
            ? new Date(
              getConflictManagement?.[
              ConflictManagementDetailFields.CONFIRMATION_DEADLINE
              ]
            )
            : undefined,
        [ConflictManagementDetailFields.LC_EMPLOYEES]:
          getConflictManagement?.[
            ConflictManagementDetailFields.LC_EMPLOYEES
          ]?.[0]?.id ?? "",
        [ConflictManagementDetailFields.LC_REVIEW_DEADLINE]:
          getConflictManagement?.[
            ConflictManagementDetailFields.LC_REVIEW_DEADLINE
          ]
            ? new Date(
              getConflictManagement?.[
              ConflictManagementDetailFields.LC_REVIEW_DEADLINE
              ]
            )
            : undefined,
        [ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG]:
          !!getConflictManagement?.[
          ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG
          ],
        [ConflictManagementDetailFields.CHECK_DIVISION_FLAG]:
          !!getConflictManagement?.[
          ConflictManagementDetailFields.CHECK_DIVISION_FLAG
          ],
        [ConflictManagementDetailFields.REMIND]: getConflictManagement?.remind
          ?.title
          ? castReminderInputToReminderSchema(getConflictManagement?.remind)
          : undefined,
      });
    }
  }, [id, getConflictManagement, isLoading]);

  const handleClick = (type: any) => {
    if (type) {
      router.replace(
        `/${CONFLICT_MANAGEMENT_ROOT_PATH}/update/${id}?action=${type}`
      );
    }
  };
  const { mutateAsync: recallConflictMutationFn } = useRecallConflict({
    config: {
      onSuccess: () => {
        toast.success(
          t("CONFLICT_MANAGEMENT.recallConflict.message.recall_success")
        );
      },
    },
  });
  useEffect(() => {
    if (routeAction) {
      changePopupVisible(routeAction, true);
    }
  }, [routeAction]);

  const shareMutation = useMutation({
    mutationFn: shareConflictFn,
    onSuccess: () => {
      toast.success(
        t(`CONFLICT_MANAGEMENT.messages.shareSuccess`)
      );
    },
  });

  useEffect(() => {
    if (id) {
      refetch();
    }
  }, [id, refetch]);

  return (
    <DashboardLayout hideHeader>
      <ConflictManagementLayout>
        <Stack direction={"column"} sx={{ height: "100%" }}>
          <Breadcrumb />
          <Typography variant="h1" sx={{ fontSize: "24px", mb: 2 }}>
            {getConflictManagement?.conflictName}
          </Typography>
          {getConflictManagement && (
            <Box display="flex" flexDirection="column" gap={1} mb={2}>
              <ConflictStatusCustom
                label=""
                optionItem={
                  getConflictManagement?.statusEvaluate ??
                  getConflictManagement?.statusConfirm
                }
              />
            </Box>
          )}
          {getConflictManagement &&
            !getConflictManagement?.isDraft &&
            getConflictManagement?.statusConfirm?.name !==
            ConflictManagementStatusContent.get(
              ConflictManagementStatusKey.COMPLETED
            )! && (
              <ConflictMngActions
                actionButtonItemValidate={Object.entries(
                  // eslint-disable-next-line @typescript-eslint/no-non-null-asserted-optional-chain
                  getConflictManagement?.buttonAction!
                )
                  // eslint-disable-next-line @typescript-eslint/no-unused-vars
                  .filter(([_, value]) => value !== 3)
                  .map(([key, value]) => ({
                    typeBtn: key,
                    disable: value === 2,
                  }))}
                params={initialConflictManagement}
                isActionDetail
                handleClickRecall={async () =>
                  await recallConflictMutationFn(Number(id))
                }
                handleClickForWard={() =>
                  handleClick(ConflictActionsBtnKey.FORWARD)
                }
                handleClickExtendTime={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_TIME_EXTENSION)
                }
                handleClickConfirm={async () =>
                  handleClick(ConflictActionsBtnKey.CONFIRM)
                }
                handleClickRequestAdditional={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_ADDITIONAL)
                }
                handleClickRequestEvaluate={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_EVALUATE)
                }
                handleClickDone={() => handleClick(ConflictActionsBtnKey.DONE)}
                handleClickRequestConfirm={() =>
                  handleClick(ConflictActionsBtnKey.REQUEST_CONFIRM)
                }
                handleClickConflictMonitor={() => {
                  handleClick(ConflictActionsBtnKey.CONFLICT_MONITORING);
                }}
                handleClickSendMail={() =>
                  handleClick(ConflictActionsBtnKey.SEND_MAIL)
                }
                handleClickFeedBack={() =>
                  handleClick(ConflictActionsBtnKey.FEEDBACK)
                }
                handleClickExtendTimeConfirm={() =>
                  handleClick(ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM)
                }
                handleClickEvaluate={() =>
                  handleClick(ConflictActionsBtnKey.EVALUATE)
                }
                handleClickSignApprove={() => {
                  handleClick(ConflictActionsBtnKey.APPROVE);
                }}
                handleClickShare={() =>
                  handleClick(ConflictActionsBtnKey.SHARE)
                }
              />
            )}
          <Box sx={{ flex: 1, overflowY: "auto" }}>
            <OverviewHeader
              initialValueReceive={initialConflictManagement}
              handleUpdateBookMeeting={updateBookMeeting}
              isLoading={isPendingBookMeetingConflict}
            />
            <ConflictManagementForm
              formMode="update"
              defaultValues={initialConflictManagement}
              initialValue={getConflictManagement}
              onCancel={() => router.back()}
              loading={
                isLoading ||
                isPendingCreateConflictManagement ||
                isPendingUpdateConflictManagement
              }
              onSubmitDraft={(data) => {
                if (id) {
                  updateConflictManagement({
                    request: data,
                    id: typeof id == "string" ? Number(id) : Number(id[0]),
                  });
                }
              }}
              onSubmit={(data: any) => {
                if (id && initialConflictManagement?.isDraft) {
                  createConflictManagement({
                    ...data,
                    isDraft: false,
                    legalAdviceId: initialConflictManagement.id,
                  });
                }
                if (id && !initialConflictManagement?.isDraft) {
                  updateConflictManagement({
                    request: data,
                    id: typeof id == "string" ? Number(id) : Number(id[0]),
                  });
                }
              }}
            />
            {getConflictManagement?.id && (
              <>
                <Box height={16} />
                <ConflictManagementTabs
                  conflictManagementId={getConflictManagement?.id}
                  conflictManagement={getConflictManagement}
                />
              </>
            )}
          </Box>
        </Stack>
      </ConflictManagementLayout>
      {popupVisibleState?.[ConflictActionsBtnKey.SHARE] && <SharePopup
        setIsOpen={(state, reload) =>
          changePopupVisible(ConflictActionsBtnKey.SHARE, state, reload)
        }
        isOpen={true}
        owner={initialConflictManagement?.pic}
        pics={initialConflictManagement?.responsibleUsers}
        onSubmit={async (data: any) => {
          const params = {
            id: initialConflictManagement?.id as number,
            data
          }
          await shareMutation.mutateAsync(params)
        }}
        initialValue={{
          legalAccessType: initialConflictManagement?.legalAccessType,
          sharedDepartments: initialConflictManagement?.sharedDepartments,
          sharedUsers: initialConflictManagement?.sharedUsers
        }}
      />}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAdditionalForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_ADDITIONAL,
              state,
              reload
            )
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_ADDITIONAL]}
          conflictId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialConflictManagement?.pic],
          }}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FORWARD] && (
        <ForwardConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FORWARD, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FORWARD]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {initialConflictManagement &&
        popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION] && (
          <TimeExtensionConflictMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.REQUEST_TIME_EXTENSION,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.REQUEST_TIME_EXTENSION]
            }
            ciId={initialConflictManagement?.id}
            name={initialConflictManagement?.conflictName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialConflictManagement?.pic],
              timeExtensionType: 2,
            }}
            deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}

          />
        )}
      {initialConflictManagement &&
        popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM] && (
          <TimeExtensionConflictMngForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM,
                state,
                reload
              )
            }
            isOpen={
              popupVisibleState?.[ConflictActionsBtnKey.TIME_EXTENTSION_CONFIRM]
            }
            ciId={initialConflictManagement?.id}
            name={initialConflictManagement?.conflictName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              users: [initialConflictManagement?.pic],
              timeExtensionType: 1,
            }}
            deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}
          />
        )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE] && (
        <RequestEvaluateConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_EVALUATE,
              state,
              reload
            )
          }
          ciId={initialConflictManagement?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_EVALUATE]}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
           deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}
           evaluater={getConflictManagement?.[
            ConflictManagementDetailFields.LC_EMPLOYEES
          ]?.[0]}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM] && (
        <RequestApprovalConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.REQUEST_CONFIRM,
              state,
              reload
            )
          }
          ciId={initialConflictManagement?.id}
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.REQUEST_CONFIRM]}
          name={initialConflictManagement?.conflictName}
          initialValue={{
            deadline: initialConflictManagement.lcReviewDeadline,
          }}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFIRM] && (
        <ConfirmConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.CONFIRM, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.CONFIRM]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
          evaluater={getConflictManagement?.pic}
          deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}

        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.DONE] && (
        <FinishConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.DONE]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL] && (
        <SendMailConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.SEND_MAIL, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.SEND_MAIL]}
          conflictId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          legalAdvice={initialConflictManagement}
          senderDocumentManagement ={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.CONFLICT_MONITORING] && (
        <FollowConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              ConflictActionsBtnKey.CONFLICT_MONITORING,
              state,
              reload
            )
          }
          isOpen={true}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK] && (
        <FeedbackConflictForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.FEEDBACK, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.FEEDBACK]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderConflict={appContext?.me}
        />
      )}
      {/* Ký duyệt */}
      {popupVisibleState?.[ConflictActionsBtnKey.APPROVE] && (
        <SignApprovalConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.APPROVE, state, reload)
          }
          isOpen={popupVisibleState?.[ConflictActionsBtnKey.APPROVE]}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
        />
      )}

      {/* Đánh giá nhận xét */}
      {popupVisibleState?.[ConflictActionsBtnKey.EVALUATE] && (
        <EvaluateConflictMngForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ConflictActionsBtnKey.EVALUATE, state, reload)
          }
          isOpen={true}
          ciId={initialConflictManagement?.id}
          name={initialConflictManagement?.conflictName}
          senderDocumentManagement={appContext?.me}
          deadlineEvaluate={initialConflictManagement?.lcReviewDeadline}
          evaluater={getConflictManagement?.pic}
        />
      )}
    </DashboardLayout>
  );
};

export default ConflictManagementDetailPage;
