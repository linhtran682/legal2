import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { CONFLICT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import ConflictManagementTable from "@/features/conflict_management/conflict_management_table/ConflictManagementTable";
import { useRouter } from "next/router";

export default function ConflictManagementPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <ConflictManagementTable />
      <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${CONFLICT_MANAGEMENT_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
