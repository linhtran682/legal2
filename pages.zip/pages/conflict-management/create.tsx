import { useCreateConflictManagement } from "@/apis/service/conflict_management/conflictManagementForm";
import DashboardLayout from "@/components/layouts";
import {
  ConflictManagementStatusContent,
  ConflictManagementStatusKey,
  Module,
  ModuleKeys,
} from "@/constants/general";
import { CONFLICT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import ConflictManagementForm from "@/features/conflict_management/conflict_management_form/ConflictManagementForm";
import { useSearchStatus } from "@/hooks/useSearchStatus";
import { ConflictManagementDetailFields } from "@/models/conflict_management/ConflictManagementDetail";
import moment from "moment";
import { useRouter } from "next/router";
import React from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const ConflictManagementCreatePage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const { mutateAsync: createConflictManagement, isPending } =
    useCreateConflictManagement({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("legalAdvice.label.legalAdviceRequest"),
            })
          );
          router.push(`/${CONFLICT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
        },
      },
    });
  const getSearchStatusQuery = useSearchStatus({
    keyword: "Yêu cầu",
    modules: Module.get(ModuleKeys.CONFLICT_MANAGEMENT)!,
    queryKey: "CONFLICT_MANAGEMENT_CREATE",
  });
  return (
    <DashboardLayout>
      <ConflictManagementForm
        formMode="create"
        defaultValues={{
          ...(getSearchStatusQuery?.data && {
            [ConflictManagementDetailFields.STATUS_CONFIRM]:
              getSearchStatusQuery?.data?.find(
                (status) =>
                  status?.name ===
                  ConflictManagementStatusContent.get(
                    ConflictManagementStatusKey.REQUEST_CONFIRMATION
                  )!
              )?.id,
            [ConflictManagementDetailFields.STATUS_EVALUATED]:
              getSearchStatusQuery?.data?.find(
                (status) =>
                  status?.name ===
                  ConflictManagementStatusContent.get(
                    ConflictManagementStatusKey.REQUEST_REVIEW
                  )!
              )?.id,
          }),
          [ConflictManagementDetailFields.CHECK_DEPT_HEAD_FLAG]: true,
          [ConflictManagementDetailFields.CHECK_DIVISION_FLAG]: true,
          [ConflictManagementDetailFields.NATURE_CONFLICT]: [],
          [ConflictManagementDetailFields.CONFIRMATION_DEADLINE]: moment()
            .add(3, "days")
            .toDate(),
          [ConflictManagementDetailFields.LC_REVIEW_DEADLINE]: moment()
            .add(3, "days")
            .toDate(),
        }}
        onSubmit={createConflictManagement}
        onSubmitDraft={createConflictManagement}
        onCancel={() => router.back()}
        loading={isPending}
      />
    </DashboardLayout>
  );
};

export default ConflictManagementCreatePage;
