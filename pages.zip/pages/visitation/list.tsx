import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { UI_PATH, VISITATION_ROOT_PATH } from "@/constants/paths";
import VisitationTable from "@/features/visitation/table/VisitationTable";
import { useRouter } from "next/router";

export default function VisitationListPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <VisitationTable />
      <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${VISITATION_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
