import moment from "moment";
import { useAdditionalInformationVisitation } from "@/apis/service/visitation/additionalInformationVisitation";
import { useRecallVisitation } from "@/apis/service/visitation/recallVisitation";
import {
  useGetVisitationDetail,
  useCreateVisitation,
  useUpdateVisitation,
  useUpdateBookMeetingVisitation,
  useGetSignApproveTab,
  shareVisitationFn,
  checkSharePointPermissionVisitationFn,
  useGetSignDefault,
} from "@/apis/service/visitation/visitationApi";
import StatusButton from "@/components/commons/action_button/StatusButton";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import DashboardLayout from "@/components/layouts";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import { URL_OUTLOOK } from "@/constants/constraint";
import { VISITATION_ROOT_PATH, UI_PATH } from "@/constants/paths";
import {
  VisitationActionsBtnKey,
  VisitationStatusCode,
} from "@/constants/visitation";
import { AppContext } from "@/context/AppContext";
import { ConfirmVisitationForm } from "@/features/visitation/action-popup/confirm_form/ConfirmVisitationForm";
import { EvaluateVisitationForm } from "@/features/visitation/action-popup/evaluate_form/EvaluateVisitationForm";
import { FeedBackVisitationForm } from "@/features/visitation/action-popup/feedback_form/FeedBackVisitationForm";
import { FeedbackShareInfoVisitationForm } from "@/features/visitation/action-popup/feedback_share_info_form/FeedbackShareInfoVisitationForm";
import { FinishVisitationForm } from "@/features/visitation/action-popup/finish_form/FinishVisitationForm";
import { FollowVisitationForm } from "@/features/visitation/action-popup/follow_form/FollowVisitationForm";
import { ForwardVisitationForm } from "@/features/visitation/action-popup/forward_form/ForwardVisitationForm";
import { ReceptionVisitationForm } from "@/features/visitation/action-popup/reception_form/ReceptionVisitationForm";
import { ReceptionResultVisitationForm } from "@/features/visitation/action-popup/reception_result_form/ReceptionResultVisitationForm";
import { RequestAddInfoVisitationForm } from "@/features/visitation/action-popup/request_add_info_form/RequestAddInfoVisitationForm";
import { RequestEvaluateVisitationForm } from "@/features/visitation/action-popup/request_evaluate_form/RequestEvaluateVisitationForm";
import { RequestSignVisitationForm } from "@/features/visitation/action-popup/request_sign_form/RequestSignVisitationForm";
import SendMailVisitationForm from "@/features/visitation/action-popup/send_mail_form/SendMailVisitationForm";
import { ShareInfoVisitationForm } from "@/features/visitation/action-popup/share_info_form/ShareInfoVisitationForm";
import { SignVisitationForm } from "@/features/visitation/action-popup/sign_form/SignVisitationForm";
import { TimeExtensionVisitationForm } from "@/features/visitation/action-popup/time_extension_form/TimeExtensionVisitationForm";
import SignApproveForm from "@/features/visitation/form/SignApproveForm";
import VisitationForm from "@/features/visitation/form/VisitationForm";
import OverviewHeader from "@/features/visitation/header/OverviewHeader";
import { VisitationLayout } from "@/features/visitation/layout/VisitationLayout";
import { VisitationTableActions } from "@/features/visitation/table/VisitationTableActions";
import VisitationTabs from "@/features/visitation/tabs/VisitationTabs";
import useObserveElementSize from "@/hooks/useObserveElementSize";
import { Department } from "@/models/department/Department";
import { castReminderInputToReminderSchema } from "@/models/reminder_template/ReminderDTO";
import { TimeExtensionVisitationType } from "@/models/visitation/TimeExtensionVisitation";
import {
  VisitationDetailFields,
  VisitationTabsRef,
} from "@/models/visitation/VisitationDetail";
import { Box, Stack, Tab, Tabs, Typography } from "@mui/material";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { AssignmentVisitationForm } from "@/features/visitation/action-popup/assignment_form/AssignmentVisitationForm";

type TabItemType = {
  label: string;
  key: "visitation-detail" | "sign-approve-tabs";
};

const TabItems: TabItemType[] = [
  {
    label: "visitation.tabs.detail",
    key: "visitation-detail",
  },
  {
    label: "visitation.tabs.sign",
    key: "sign-approve-tabs",
  },
];

const VisitationDetailPage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const [currentId, setCurrentId] = useState("");
  const [activeTab, setActiveTab] = useState(0);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});
  const tabRef = useRef<VisitationTabsRef>(null);
  const { elementRef, size } = useObserveElementSize();
  const [initialVisitation, setInitialVisitation] = useState<any>(undefined);
  const queryClient = useQueryClient();
  const appContext = useContext(AppContext);

  const { data: getVisitation, isLoading } = useGetVisitationDetail({
    request: { id: typeof id == "string" ? Number(id) : Number((id || [])[0]) },
    config: {
      enabled: !!id,
    },
  });

  const { data: signApproveData } = useGetSignApproveTab({
    request: { id: typeof id == "string" ? Number(id) : Number((id || [])[0]) },
    config: {
      enabled: !!id,
    },
  });

  const { data: signDefault } = useGetSignDefault({
    id: Number(id),
  });

  const checkSharepointPermission = useQuery({
    queryKey: ["sharepoint-permission-visitation", appContext?.me?.id],
    queryFn: () => checkSharePointPermissionVisitationFn(),
    enabled: !!appContext?.me?.id,
  });

  useEffect(() => {
    if (id) {
      if (id !== currentId) {
        setActiveTab(0);
      }

      setCurrentId(id as string);
    }
  }, [currentId, id]);

  const { mutate: createVisitation, isPending: isPendingCreateVisitation } =
    useCreateVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t("menu.visitation"),
            })
          );
          router.push(`/${VISITATION_ROOT_PATH}/${UI_PATH.LIST}`);
        },
      },
    });

  const { mutate: updateBookMeeting, isPending: isPendingBookMeeting } =
    useUpdateBookMeetingVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t("menu.visitation"),
            })
          );
        },
      },
    });

  const { mutate: updateVisitation, isPending: isPendingUpdateVisitation } =
    useUpdateVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.update_success", {
              recordName: t("menu.visitation"),
            })
          );
          router.push(`/${VISITATION_ROOT_PATH}/${UI_PATH.LIST}`);
        },
      },
    });

  useEffect(() => {
    if (id && getVisitation && !isLoading) {
      if (getVisitation?.actionAvailableAndRole?.roles?.length) {
        const {
          actionAvailableAndRole: { roles },
        } = getVisitation;
        const roleList = roles?.map((role) => role);
        setOwnRole(roleList);
      }

      setInitialVisitation({
        ...getVisitation,
        [VisitationDetailFields.ATTACHMENTS]:
          getVisitation?.attachmentFiles || null,
        [VisitationDetailFields.NAME]: getVisitation?.name ?? "",
        [VisitationDetailFields.VISITATION_STATUS]: getVisitation?.status?.id,
        [VisitationDetailFields.RECEPTION_ID]:
          getVisitation?.receptionUser.id ?? "",
        [VisitationDetailFields.RECEPTION_NAME]:
          getVisitation?.receptionUser.id ?? "",
        [VisitationDetailFields.DEPARTMENT]: getVisitation?.department,
        [VisitationDetailFields.POSITION]: getVisitation?.position,
        [VisitationDetailFields.GROUP]: getVisitation?.group,
        [VisitationDetailFields.SUPERVISOR_ID]:
          getVisitation?.supervisorUser?.id ?? "",
        [VisitationDetailFields.FIELD]: getVisitation?.field,
        [VisitationDetailFields.ORGANIZATION_NAME]:
          getVisitation?.organizationName,
        [VisitationDetailFields.RECEPTION_TIME_FROM]:
          getVisitation?.receptionTimeFrom
            ? new Date(getVisitation?.receptionTimeFrom)
            : undefined,
        [VisitationDetailFields.RECEPTION_TIME_TO]:
          getVisitation?.receptionTimeTo
            ? new Date(getVisitation?.receptionTimeTo)
            : undefined,
        [VisitationDetailFields.PURPOSE]: getVisitation?.purpose,
        [VisitationDetailFields.REQUEST_SUMARY]: getVisitation?.requestSummary,
        [VisitationDetailFields.DEPARTMENT_FEEDBACK]:
          getVisitation?.departmentFeedback,
        [VisitationDetailFields.PARTICIPANTS]: getVisitation?.participants,
        [VisitationDetailFields.CHECK_DIVISION_FLAG]:
          !!getVisitation?.checkDivisionFlag,
        [VisitationDetailFields.CHECK_DEPT_HEAD_FLAG]:
          !!getVisitation?.checkDeptHeadFlag,
        [VisitationDetailFields.RECEIVED_USERS]:
          getVisitation?.receiverUsers?.map((user: any) => ({
            ...user,
          })),
        [VisitationDetailFields.ASSIGNMENT_USERS]:
          getVisitation?.assignmentUsers?.map((user: any) => ({
            ...user,
          })),
        [VisitationDetailFields.CONFIRM_DEADLINE]:
          getVisitation?.confirmDeadline
            ? moment.utc(getVisitation?.confirmDeadline).local().toDate()
            : undefined,
        [VisitationDetailFields.SHARE_INFORMATION_DEPARTMENT]:
          getVisitation?.shareInformationDepartments?.map(
            (department: Department) => ({
              ...department,
            })
          ),
        [VisitationDetailFields.SHARE_INFORMATION_DEADLINE]:
          getVisitation?.shareInformationDeadline
            ? moment
                .utc(getVisitation?.shareInformationDeadline)
                .local()
                .toDate()
            : undefined,
        [VisitationDetailFields.STAFF_LC_USERS]:
          getVisitation?.staffLCUsers?.[0]?.id,
        [`origin${VisitationDetailFields.STAFF_LC_USERS}`]:
          getVisitation?.staffLCUsers,
        [VisitationDetailFields.RESPONSE_LC_DEADLINE]:
          getVisitation?.responseLCDeadline
            ? moment.utc(getVisitation?.responseLCDeadline).local().toDate()
            : undefined,
        [VisitationDetailFields.REMIND]: getVisitation?.remind?.title
          ? castReminderInputToReminderSchema(getVisitation?.remind)
          : undefined,
      });
    }
  }, [id, getVisitation, isLoading]);

  const checkDisableTab = (tabItem: TabItemType) => {
    if (tabItem.key === "visitation-detail") {
      return false;
    }

    if (tabItem.key === "sign-approve-tabs") {
      if (
        signApproveData?.deadline ||
        (ownRole.includes(1) &&
          getVisitation?.status?.code === VisitationStatusCode.EVALUATED)
      ) {
        return false;
      }
    }

    return true;
  };

  const handleClick = (type: any) => {
    if (type) {
      changePopupVisible(type, true);
    }
  };

  const changePopupVisible = (
    type: any,
    state: boolean = false,
    reload: boolean = false
  ) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));

    // if (!state) {
    //   setInitialVisitation(undefined);
    // }

    if (reload) {
      queryClient.invalidateQueries({
        queryKey: ["get_sign_approve_tab"],
      });
      queryClient.invalidateQueries({
        queryKey: ["get_initial_visitation_detail"],
      });
      queryClient.invalidateQueries({
        queryKey: ["visitation/get-department-heads"],
      });
    }
  };

  const scrollToTab = (tab: number) => {
    tabRef?.current?.scrollToTab(tab);
  };

  const { mutateAsync: recallVisitation } = useRecallVisitation({
    config: {
      onSuccess: () => {
        toast.success(t("visitation.recallVisitation.message.recall_success"));
        queryClient.invalidateQueries({
          queryKey: ["get_sign_approve_tab"],
        });
        queryClient.invalidateQueries({
          queryKey: ["get_initial_visitation_detail"],
        });
        queryClient.invalidateQueries({
          queryKey: ["visitation/get-department-heads"],
        });
      },
    },
  });

  const { mutateAsync: additionalInformationVisitation } =
    useAdditionalInformationVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t(
              "visitation.additionalInformationVisitation.message.additionalInformationSuccess"
            )
          );
          queryClient.invalidateQueries({
            queryKey: ["get_sign_approve_tab"],
          });
          queryClient.invalidateQueries({
            queryKey: ["get_initial_visitation_detail"],
          });
        },
      },
    });

  const shareMutation = useMutation({
    mutationFn: shareVisitationFn,
    onSuccess: () => {
      toast.success(t(`visitation.messages.shareSuccess`));
    },
  });

  return (
    <DashboardLayout hideHeader>
      <VisitationLayout>
        <Stack direction={"column"} sx={{ height: "100%" }}>
          <Breadcrumb />
          <Typography
            variant="h1"
            sx={{
              fontSize: "24px",
              mb: 1,
              overflow: "hidden",
              whiteSpace: "nowrap",
              textOverflow: "ellipsis",
              width: "80%",
            }}
            component={"div"}
            title={getVisitation?.name}
          >
            {getVisitation?.name}
          </Typography>
          <Box sx={{ mb: 1, display: "flex", columnGap: 3 }}>
            {getVisitation?.status && (
              <StatusButton
                status={
                  getVisitation?.status?.name ??
                  t("visitation.label.requestComfirmationStatus")
                }
                label={""}
              />
            )}
          </Box>
          <Tabs
            value={activeTab}
            onChange={(_, i) => setActiveTab(i)}
            // variant='scrollable'
          >
            {TabItems.map((tabItem: TabItemType) => (
              <Tab
                label={<Typography variant="h5">{t(tabItem.label)}</Typography>}
                key={tabItem.key}
                id={`tab-label-${tabItem.key}`}
                aria-controls={`tab-panel-${tabItem.key}`}
                sx={{
                  textTransform: "none",
                  // backgroundColor: 'white'
                }}
                disabled={checkDisableTab(tabItem)}
              />
            ))}
          </Tabs>
          <Box height={12} component={"div"}></Box>
          {!getVisitation?.isDraft && (
            <VisitationTableActions
              isActionDetail
              params={{
                row: getVisitation,
                sign: signApproveData,
              }}
              isEditSignTab={!!signApproveData?.deadline}
              activeTab={activeTab}
              handleClickRecall={async () => {
                await recallVisitation(Number(getVisitation?.id));
              }}
              handleClickSendMail={() =>
                handleClick(VisitationActionsBtnKey.SEND_MAIL)
              }
              handleClickForWard={() =>
                handleClick(VisitationActionsBtnKey.FORWARD)
              }
              handleClickFeedBack={() =>
                handleClick(VisitationActionsBtnKey.FEEDBACK)
              }
              handleClickRequestMeeting={() => {
                window.open(URL_OUTLOOK, "_blank");
              }}
              handleClickRequestInformation={() =>
                handleClick(VisitationActionsBtnKey.INFORMATION_REQUEST)
              }
              handleClickAdditionalInformation={async () => {
                await additionalInformationVisitation(
                  Number(getVisitation?.id)
                );
              }}
              handleClickRequestShareInfo={() =>
                handleClick(VisitationActionsBtnKey.SHARE_INFO_REQUEST)
              }
              handleClickFeedbackShareInfo={() =>
                handleClick(VisitationActionsBtnKey.SHARE_INFO_FEEDBACK)
              }
              handleClickShare={() =>
                handleClick(VisitationActionsBtnKey.SHARE)
              }
              handleClickConfirm={() =>
                handleClick(VisitationActionsBtnKey.CONFIRM_APPROVED)
              }
              handleClickRequestEvaluate={() =>
                handleClick(VisitationActionsBtnKey.EVALUATE_REQUEST)
              }
              handleClickAssignment={() =>
                handleClick(VisitationActionsBtnKey.ASSIGNMENT)
              }
              handleClickConfirmEvaluateFeedback={() =>
                handleClick(VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM)
              }
              handleClickRequestSign={() =>
                handleClick(VisitationActionsBtnKey.REQUEST_SIGN)
              }
              handleClickSign={() => handleClick(VisitationActionsBtnKey.SIGN)}
              handleClickRejectSign={() =>
                handleClick(VisitationActionsBtnKey.SIGN_REJECT)
              }
              handleClickReception={() =>
                handleClick(VisitationActionsBtnKey.RECEPTION)
              }
              handleClickReceptionResult={() =>
                handleClick(VisitationActionsBtnKey.RECEPTION_RESULT)
              }
              handleClickExtendTime={() =>
                handleClick(
                  VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE
                )
              }
              handleClickExtendTimeShareInfo={() =>
                handleClick(
                  VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE
                )
              }
              handleClickExtendTimeResponseLc={() =>
                handleClick(
                  VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE
                )
              }
              handleClickFollow={() =>
                handleClick(VisitationActionsBtnKey.FOLLOW)
              }
              handleClickFinish={() =>
                handleClick(VisitationActionsBtnKey.FINISH)
              }
            />
          )}
          <Box sx={{ flex: 1, overflowY: "auto" }} ref={elementRef}>
            <OverviewHeader
              scrollToTab={scrollToTab}
              initialValueReceive={getVisitation}
              handleUpdateBookMeeting={updateBookMeeting}
              isLoading={isPendingBookMeeting}
            />
            <Box sx={{ display: activeTab === 0 ? "block" : "none" }}>
              <VisitationForm
                formMode="update"
                ownRole={ownRole}
                defaultValues={initialVisitation}
                initialValue={getVisitation}
                checkSharepointPermission={
                  checkSharepointPermission?.data?.result
                }
                onCancel={() => router.back()}
                visitationId={(id as string) ?? ""}
                loading={
                  isLoading ||
                  isPendingCreateVisitation ||
                  isPendingUpdateVisitation
                }
                onSubmitDraft={(data) => {
                  if (id) {
                    updateVisitation({
                      request: data,
                      id: typeof id == "string" ? Number(id) : Number(id[0]),
                    });
                  } else {
                    createVisitation(data);
                  }
                }}
                onSubmit={(data: any) => {
                  if (id) {
                    updateVisitation({
                      request: data,
                      id: typeof id == "string" ? Number(id) : Number(id[0]),
                    });
                  }
                }}
              />
            </Box>
            <Box sx={{ display: activeTab === 1 ? "block" : "none" }}>
              <SignApproveForm
                initialSignApprove={signApproveData}
                initialValueReceive={getVisitation}
                visitationId={initialVisitation?.id}
                formMode={!!signApproveData?.deadline ? "update" : "create"}
                ownRole={ownRole}
                checkSharepointPermission={
                  checkSharepointPermission?.data?.result
                }
                signDefault={signDefault?.data}
                activeTab={activeTab}
              />
            </Box>
            {getVisitation?.id && (
              <>
                <Box height={16} />
                <VisitationTabs
                  ownRole={ownRole}
                  ref={tabRef}
                  containerHeight={size.height}
                  visitationId={getVisitation?.id}
                  visitation={getVisitation}
                />
              </>
            )}
          </Box>
        </Stack>
      </VisitationLayout>

      {popupVisibleState?.[VisitationActionsBtnKey.SEND_MAIL] && (
        <SendMailVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.SEND_MAIL, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.SEND_MAIL]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FORWARD] && (
        <ForwardVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FORWARD, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FORWARD]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FEEDBACK] && (
        <FeedBackVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FEEDBACK, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FEEDBACK]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.INFORMATION_REQUEST] && (
        <RequestAddInfoVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.INFORMATION_REQUEST,
              state
            )
          }
          isOpen={
            popupVisibleState?.[VisitationActionsBtnKey.INFORMATION_REQUEST]
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_REQUEST] && (
        <ShareInfoVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.SHARE_INFO_REQUEST,
              state
            )
          }
          isOpen={
            popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_REQUEST]
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          deadline={
            initialVisitation?.shareInformationDeadline
              ? initialVisitation?.shareInformationDeadline
              : moment(new Date())
                  .add(3 * 24, "hours")
                  .toDate()
          }
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_FEEDBACK] && (
        <FeedbackShareInfoVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.SHARE_INFO_FEEDBACK,
              state
            )
          }
          isOpen={
            popupVisibleState?.[VisitationActionsBtnKey.SHARE_INFO_FEEDBACK]
          }
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(VisitationActionsBtnKey.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialVisitation?.createdBy}
          onSubmit={async (data: any) => {
            const params = {
              id: initialVisitation?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.CONFIRM_APPROVED] && (
        <ConfirmVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.CONFIRM_APPROVED, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.CONFIRM_APPROVED]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          createdBy={initialVisitation?.createdBy}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.EVALUATE_REQUEST] && (
        <RequestEvaluateVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.EVALUATE_REQUEST, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.EVALUATE_REQUEST]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          staffLCUsers={initialVisitation?.originstaffLCUsers}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.ASSIGNMENT] && (
        <AssignmentVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.ASSIGNMENT, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.ASSIGNMENT]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM
      ] && (
        <EvaluateVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey.EVALUATE_FEEDBACK_CONFIRM
            ]
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.REQUEST_SIGN] && (
        <RequestSignVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.REQUEST_SIGN, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.REQUEST_SIGN]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.SIGN] && (
        <SignVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.SIGN, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.SIGN]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.RECEPTION] && (
        <ReceptionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.RECEPTION, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.RECEPTION]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.RECEPTION_RESULT] && (
        <ReceptionResultVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.RECEPTION_RESULT, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.RECEPTION_RESULT]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE
      ] && (
        <TimeExtensionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey.REQUEST_EXTENSION_CONFIRM_DEADLINE
            ]
          }
          timeExtensionVisitationType={
            TimeExtensionVisitationType.CONFIRM_DEADLINE
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE
      ] && (
        <TimeExtensionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey
                .REQUEST_EXTENSION_SHARE_INFORMATION_DEADLINE
            ]
          }
          timeExtensionVisitationType={
            TimeExtensionVisitationType.SHARE_INFORMATION_DEADLINE
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[
        VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE
      ] && (
        <TimeExtensionVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(
              VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              VisitationActionsBtnKey.REQUEST_EXTENSION_RESPONSE_LC_DEADLINE
            ]
          }
          timeExtensionVisitationType={
            TimeExtensionVisitationType.RESPONSE_LC_DEADLINE
          }
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
          createdBy={initialVisitation?.createdBy}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FOLLOW] && (
        <FollowVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FOLLOW, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FOLLOW]}
          visitationId={initialVisitation?.id}
          visitation={initialVisitation}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}

      {popupVisibleState?.[VisitationActionsBtnKey.FINISH] && (
        <FinishVisitationForm
          setIsOpen={(state) =>
            changePopupVisible(VisitationActionsBtnKey.FINISH, state)
          }
          isOpen={popupVisibleState?.[VisitationActionsBtnKey.FINISH]}
          visitationId={initialVisitation?.id}
          name={initialVisitation?.name}
          sender={appContext?.me}
        />
      )}
    </DashboardLayout>
  );
};

export default VisitationDetailPage;
