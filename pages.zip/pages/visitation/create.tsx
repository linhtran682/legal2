import { checkSharePointPermissionVisitationFn, useCreateVisitation } from "@/apis/service/visitation/visitationApi";
import DashboardLayout from "@/components/layouts";
import { UI_PATH, VISITATION_ROOT_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import VisitationForm from "@/features/visitation/form/VisitationForm";
import { VisitationDetailFields } from "@/models/visitation/VisitationDetail";
import { useQuery } from "@tanstack/react-query";
import moment from "moment";
import { useRouter } from "next/router";
import React, { useContext } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const VisitationCreatePage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const appContext = useContext(AppContext);

  const { mutateAsync: createVisitation, isPending } =
  useCreateVisitation({
      config: {
        onSuccess: () => {
          toast.success(
            t("common.message.create_success", {
              recordName: t("legalAdvice.label.legalAdviceRequest"),
            })
          );
          router.push(`/${VISITATION_ROOT_PATH}/${UI_PATH.LIST}`);
        },
      },
    });

    const checkSharepointPermission = useQuery({
      queryKey: ['sharepoint-permission-visitation', appContext?.me?.id],
      queryFn: () => checkSharePointPermissionVisitationFn(),
      enabled: !!appContext?.me?.id
    })
  
  return (
    <DashboardLayout>
      <VisitationForm
        formMode="create"
        onSubmit={createVisitation}
        onSubmitDraft={createVisitation}
        checkSharepointPermission={checkSharepointPermission?.data?.result}
        onCancel={() => router.back()}
        loading={isPending}
        defaultValues={{
          [VisitationDetailFields.CHECK_DEPT_HEAD_FLAG]: true,
          [VisitationDetailFields.CHECK_DIVISION_FLAG]: true,
          [VisitationDetailFields.CONFIRM_DEADLINE]: moment()
            .add(3, "days")
            .toDate(),
          // [VisitationDetailFields.RESPONSE_LC_DEADLINE]: moment()
          //   .add(3, "days")
          //   .toDate(),
        }}
      />
    </DashboardLayout>
  );
};

export default VisitationCreatePage;
