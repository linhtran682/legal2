import { createAssignment, createAssignmentDraft } from "@/apis/service/assignment/Assignment";
import DashboardLayout from "@/components/layouts";
import { ASSIGNMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import SaveAssignmentForm from "@/features/assignment/save_assignment_form/SaveAssignmentForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateAssignmentPage() {
  const router = useRouter();
  const [t] = useTranslation();
  const createAssignmentQuery = useMutation({
    mutationFn: createAssignment,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.assignment"),
        })
      );
      router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const createAssignmentDraftQuery = useMutation({
    mutationFn: createAssignmentDraft,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.assignment"),
        })
      );
      router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  return <DashboardLayout>
    <SaveAssignmentForm
      formMode="create"
      onSubmit={createAssignmentQuery.mutate}
      onSubmitDraft={createAssignmentDraftQuery.mutate}
      onCancel={() => router.back()}
      loading={createAssignmentDraftQuery.isPending || createAssignmentQuery.isPending}

    />
  </DashboardLayout>
}