import { createAssignment, deleteAssignment, getAssignment, updateAssignment } from '@/apis/service/assignment/Assignment';
import DashboardLayout from '@/components/layouts';
import { ASSIGNMENT_ROOT_PATH, UI_PATH } from '@/constants/paths';
import SaveAssignmentForm from '@/features/assignment/save_assignment_form/SaveAssignmentForm';
import { AssignmentDTO } from '@/models/assignment/Assignment';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';

const UpdateAssignmentPage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const updateAssignmentQuery = useMutation({
    mutationFn: updateAssignment,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.assignment"),
        })
      );
      router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const createAssignmentQuery = useMutation({
    mutationFn: createAssignment,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.assignment"),
        })
      );
      router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteAssignmentQuery = useMutation({
    mutationFn: deleteAssignment,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.assignment"),
        })
      );
      router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const getAssignmentQuery = useQuery({
    queryKey: ["get_initial_assignment"],
    queryFn: () =>
      getAssignment(typeof id == "string" ? Number(id) : Number((id || [])[0])),
    enabled: false,
  });

  const [initialAssignment, setInitialAssignment] = useState<AssignmentDTO | undefined>(
    undefined
  );
  useEffect(() => {
    id &&
      getAssignmentQuery.refetch().then((response) => {
        setInitialAssignment(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  return (
    <DashboardLayout>
      <SaveAssignmentForm
        formMode="update"
        initialValue={initialAssignment ?? initialAssignment}
        onSubmitDraft={(data) => {
          if (initialAssignment?.id) {
            updateAssignmentQuery.mutate({
              request: data,
              id: initialAssignment?.id,
            })
          }
        }}
        onSubmit={(data) => {
          if (initialAssignment?.id && !initialAssignment?.draft) {
            updateAssignmentQuery.mutate({
              request: data,
              id: initialAssignment?.id,
            })
          }
          if (initialAssignment?.id && initialAssignment?.draft) {
            createAssignmentQuery.mutate({
              ...data,
              assignmentDraftId: initialAssignment?.id,
            })
          }
        }}
        onDelete={() =>
          id &&
          deleteAssignmentQuery.mutate(
            typeof id == "string" ? Number(id) : Number(id[0]),
          )
        }
        onCancel={() => router.back()}
        loading={updateAssignmentQuery.isPending || deleteAssignmentQuery.isPending || getAssignmentQuery.isPending}

      />
    </DashboardLayout>
  )
}

export default UpdateAssignmentPage