import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { ASSIGNMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import AssignmentTable from "@/features/assignment/assignment_table/AssignmentTable";
import { useRouter } from "next/navigation";

export default function AssignmentsPage() {
  const router = useRouter();
  return <DashboardLayout>
    <AssignmentTable />
    <StickyAddButton
      ariaLabel='add_document_type'
      onClick={() =>
        router.push(`/${ASSIGNMENT_ROOT_PATH}/${UI_PATH.CREATE}`)
      }
    />
  </DashboardLayout>
}