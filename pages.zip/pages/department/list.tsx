import DashboardLayout from "@/components/layouts";
import { DepartmentPicker } from "@/features/department/department_picker/DepartmentPicker";
import { ViewDepartmentPanel } from "@/features/department/view_department_panel/ViewDepartmentPanel";
import { Department } from "@/models/department/Department";
import { Grid } from "@mui/material";
import { useState } from "react";

export default function DepartmentsPage() {
  const [department, setDepartment] = useState<Department>();
  
  return (
    <DashboardLayout>
      <Grid
        container
        direction={"row"}
        sx={{ overflow: "hidden", height: "100%" }}
        columnGap={2}
      >
        <Grid item xs={4}>
          <DepartmentPicker onSelect={setDepartment} />
        </Grid>
        <Grid item flex={1}>
          <ViewDepartmentPanel department={department} />
        </Grid>
      </Grid>
    </DashboardLayout>
  );
}
