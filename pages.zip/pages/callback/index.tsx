import DashboardLayout from "@/components/layouts";
import { Grid } from "@mui/material";

export default function DepartmentsPage() {
  
  return (
    <DashboardLayout>
      <Grid
        container
        direction={"row"}
        sx={{ overflow: "hidden", height: "100%" }}
        columnGap={2}
      >
        <h1>WELLCOME TO THIS PROJECT</h1>
      </Grid>
    </DashboardLayout>
  );
}
