import { createDocumentMngStock } from "@/apis/service/document_management/DocumentManagement";
import DashboardLayout from "@/components/layouts";
import { DOCUMENT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
// import { LayoutDocumentMng } from "@/features/document_management/layout/LayoutDocumnentMng";
import { StockCreateManagement } from "@/features/document_management/stock_management/StockCreateManagement";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function StockCreatePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const createStockQuery = useMutation({
    mutationFn: createDocumentMngStock,
    onSuccess: () => {
      toast.success(t("menu.createSuccessStock"));
      router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      {/* <LayoutDocumentMng isShowAddICon={true}> */}
      {id && (
        <StockCreateManagement
          folderId={+id}
          onSubmit={createStockQuery.mutate}
          onCancel={() => router.back()}
        />
      )}
      {/* <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      /> */}
      {/* </LayoutDocumentMng> */}
    </DashboardLayout>
  );
}
