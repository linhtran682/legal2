import {
  deleteDocumentMngStock,
  getDetailDocumentStock,
  updateDocumentMngStock,
} from "@/apis/service/document_management/DocumentManagement";
import DashboardLayout from "@/components/layouts";
import { DOCUMENT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { DocumentManagementTable } from "@/features/document_management/document_management_table/DocumentManagementTable";
// import { LayoutDocumentMng } from "@/features/document_management/layout/LayoutDocumnentMng";
import { StockCreateManagement } from "@/features/document_management/stock_management/StockCreateManagement";
import { DepartmentStockModelDetail } from "@/models/document_management/DocumentManagement";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function StockUpdatePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const [initialDocument, setInitialDocument] = useState<
    DepartmentStockModelDetail | undefined
  >(undefined);
  const [idFolder, setIdFolder] = useState<number | undefined>(undefined);
  const [isFirstLoad, setIsFirstLoad] = useState(true)
  const getDetailDocumentStockQuery = useQuery({
    queryKey: ["get_initial_documentmng "],
    queryFn: () => {
      if (typeof idFolder === "number") {
        return getDetailDocumentStock(idFolder);
      }
      // Handle the case where idFolder is undefined, if necessary
      return Promise.reject(new Error("idFolder is undefined"));
    },
    enabled: false,
  });
  const updateStockQuery = useMutation({
    mutationFn: updateDocumentMngStock,
    onSuccess: () => {
      toast.success(
        t("menu.stockUpdate")
      );
      router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  useEffect(() => {
    id && setIdFolder(+id);
    setIsFirstLoad(true)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, router]);
  useEffect(() => {
    idFolder &&
      getDetailDocumentStockQuery.refetch().then((response) => {
        setInitialDocument(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idFolder]);
  const deleteDocumentMngStockQuery = useMutation({
    mutationFn: deleteDocumentMngStock,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("DOCUMENT_MANAGEMENT.field_name.folderId"),
        })
      );
      router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  // console.log('isFirstLoad', isFirstLoad)
  return (
    <DashboardLayout>
      {/* <LayoutDocumentMng
        isShowAddICon={true}
        handleItemClickDetail={(e) => {
          setIdFolder(e);
          setIsFirstLoad(false)
        }}
      > */}
        {id  && idFolder && isFirstLoad ?  (
          <StockCreateManagement
            formMode="update"
            loading={
              getDetailDocumentStockQuery.isPending ||
              updateStockQuery.isPending
            }
            folderId={idFolder && +idFolder}
            onSubmit={(data) => {
              idFolder &&
                updateStockQuery.mutate({
                  request: data,
                  id: idFolder,
                });
            }}
            onCancel={() => router.back()}
            initialValueReceive={initialDocument}
            onDelete={() => {
              idFolder && deleteDocumentMngStockQuery.mutate(idFolder);
            }}
          />
        ): idFolder &&  id && !isFirstLoad ? <DocumentManagementTable folderId={idFolder} /> : <div></div>}
      {/* </LayoutDocumentMng> */}
    </DashboardLayout>
  );
}
