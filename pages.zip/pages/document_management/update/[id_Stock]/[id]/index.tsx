import {
  deleteDocumentManagement,
  getDocumentManagement,
  shareDocumentMgmtFn,
  updateDocumentManagement,
} from "@/apis/service/document_management/DocumentManagement";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import DashboardLayout from "@/components/layouts";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import { DOCUMENT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import { DocumentManagementForm } from "@/features/document_management/document_management_form/DocumentManagementForm";
import DocumentManagementTableActions, {
  ButtonActionDocumentManagement,
} from "@/features/document_management/document_management_table/document_management_table_actions/DocumentManagementTableActions";
import DocumentManagementTab from "@/features/document_management/DocumentManagementTab/DocumentManagementTab";
import { ForwardDocumentManagementForm } from "@/features/document_management/forward_legal_advice_form/ForwardDocumentManagementForm";
// import { LayoutDocumentMng } from "@/features/document_management/layout/LayoutDocumnentMng";
import { RequestAdditionalForm } from "@/features/document_management/request_additional_information_form/RequestAdditionalForm";
import { TimeExtensionDocumentForm } from "@/features/document_management/time_extension_document_form/TimeExtensionDocumentForm";
import { BasedDocumentManagementBodyReceive } from "@/models/document_management/DocumentManagement";
import { Box, Stack, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function DocumentManagementUpdatePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const id_Stock = router.query.id_Stock;
  const appContext = useContext(AppContext);
  const routeAction = router.query.action;

  const [initialDocument, setInitialDocument] = useState<
    BasedDocumentManagementBodyReceive | undefined
  >(undefined);
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});
  const getDocumentManagementQuery = useQuery({
    queryKey: ["get_initial_documentmng "],
    queryFn: () =>
      getDocumentManagement(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: false,
  });
  const updateDocumentManagementQuery = useMutation({
    mutationFn: updateDocumentManagement,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.document"),
        })
      );
      router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const handleClick = (type: any) => {
    if (type) {
      changePopupVisible(type, true)
      router.replace(
        `/${DOCUMENT_MANAGEMENT_ROOT_PATH}/update/${id_Stock}/${id}?action=${type}`
      );
    }
  };

  const changePopupVisible = (type: any, state: boolean = false, reload: boolean = false) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state) {
      router.replace(
        `/${DOCUMENT_MANAGEMENT_ROOT_PATH}/update/${id_Stock}/${id}`
      );
    }
    if (reload) {
      getDocumentManagementQuery.refetch().then((response) => {
        setInitialDocument(response.data);
      });
    }
  };

  useEffect(() => {
    if (routeAction) {
      changePopupVisible(routeAction, true);
    }
  }, [routeAction]);

  useEffect(() => {
    id &&
      getDocumentManagementQuery.refetch().then((response) => {
        setInitialDocument(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  const deleteDocumentManagementQuery = useMutation({
    mutationFn: deleteDocumentManagement,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.document"),
        })
      );
      router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const shareMutation = useMutation({
    mutationFn: shareDocumentMgmtFn,
    onSuccess: () => {
      toast.success(
        t(`DOCUMENT_MANAGEMENT.messages.shareSuccess`)
      );
      // router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  return (
    <>
      <DashboardLayout hideHeader>
        {/* <LayoutDocumentMng isShowAddICon={true}> */}
        <Stack sx={{ height: "100%" }}>
          {/* <Grid
            direction={"row"}
            wrap="nowrap"
            sx={{ display: "flex", overflow: "hidden", height: "100%" }}
          >
            <Grid
              item
              flex={1}
              style={{
                maxWidth: "100%",
                transition: "max-width 0.2s ease",
                height: "100%",
                overflow: "hidden",
                position: "relative",
                paddingBottom: "50px",
              }}
            > */}
          <Breadcrumb />
          <Typography variant="h1" sx={{ fontSize: "24px", mb: 2 }}>
            {initialDocument?.name}
          </Typography>
          {id_Stock && (
            <DocumentManagementTableActions
              params={{
                row: initialDocument,
              }}
              handleClickForward={() =>
                handleClick(ButtonActionDocumentManagement.FORWARD)
              }
              handleClickExtendDeadline={() =>
                handleClick(ButtonActionDocumentManagement.EXTEND_DEADLINE)
              }
              handleClickRequestAdditional={() =>
                handleClick(
                  ButtonActionDocumentManagement.REQUEST_ADDITIONAL
                )
              }
              handleClickShare={() => {
                handleClick(
                  ButtonActionDocumentManagement.SHARE
                )
              }}
              isActionDetail
            />
          )}
          <Box
            sx={{ overflowY: "auto", height: "100%", position: "relative" }}
          >
            {id_Stock && (
              <DocumentManagementForm
                initialValueReceive={initialDocument}
                formMode="update"
                onSubmit={(data) => {
                  id &&
                    updateDocumentManagementQuery.mutate({
                      request: data,
                      id:
                        typeof id == "string" ? Number(id) : Number(id[0]),
                    });
                }}
                onDelete={() => {
                  id &&
                    deleteDocumentManagementQuery.mutate({
                      id:
                        typeof id == "string" ? Number(id) : Number(id[0]),
                    });
                }}
                onCancel={() => router.back()}
                folderId={+id_Stock}
              />
            )}
            {id && (
              <DocumentManagementTab
                documentManagementId={+id}
                documentManagement={initialDocument}
              />
            )}
          </Box>
          {/* </Grid>
          </Grid> */}
        </Stack>
        {/* </LayoutDocumentMng> */}
        {popupVisibleState?.[ButtonActionDocumentManagement.SHARE] && <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonActionDocumentManagement.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialDocument?.createdBy}
          pics={initialDocument?.receivers}
          onSubmit={async (data: any) => {
            const params = {
              id: initialDocument?.id as number,
              data
            }
            await shareMutation.mutateAsync(params)
          }}
          initialValue={{
            legalAccessType: initialDocument?.legalAccessType,
            sharedDepartments: initialDocument?.sharedDepartments,
            sharedUsers: initialDocument?.sharedUsers
          }}
        />}
        {popupVisibleState?.[
          ButtonActionDocumentManagement.EXTEND_DEADLINE
        ] && (
            <TimeExtensionDocumentForm
              setIsOpen={(state, reload) =>
                changePopupVisible(
                  ButtonActionDocumentManagement.EXTEND_DEADLINE,
                  state,
                  reload
                )
              }
              documentId={initialDocument?.id}
              isOpen={
                popupVisibleState?.[
                ButtonActionDocumentManagement.EXTEND_DEADLINE
                ]
              }
              name={initialDocument?.name}
              senderDocumentManagement={appContext?.me}
              initialValue={{
                users: initialDocument?.receivers,
              }}
            />
          )}
        {popupVisibleState?.[ButtonActionDocumentManagement.FORWARD] && (
          <ForwardDocumentManagementForm
            setIsOpen={(state, reload) =>
              changePopupVisible(
                ButtonActionDocumentManagement.FORWARD,
                state,
                reload
              )
            }
            documentId={initialDocument?.id}
            isOpen={popupVisibleState?.[ButtonActionDocumentManagement.FORWARD]}
            name={initialDocument?.name}
            senderDocumentManagement={appContext?.me}
          />
        )}
        {popupVisibleState?.[
          ButtonActionDocumentManagement.REQUEST_ADDITIONAL
        ] && (
            <RequestAdditionalForm
              setIsOpen={(state, reload) =>
                changePopupVisible(
                  ButtonActionDocumentManagement.REQUEST_ADDITIONAL,
                  state,
                  reload
                )
              }
              documentId={initialDocument?.id}
              isOpen={
                popupVisibleState?.[
                ButtonActionDocumentManagement.REQUEST_ADDITIONAL
                ]
              }
              name={initialDocument?.name}
              senderDocumentManagement={appContext?.me}
              initialValue={{
                users: initialDocument?.receivers,
              }}
            />
          )}
      </DashboardLayout>
    </>
  );
}
