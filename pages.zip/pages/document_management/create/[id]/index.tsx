import { createDocumentManagement } from "@/apis/service/document_management/DocumentManagement";
import DashboardLayout from "@/components/layouts";
import { ModuleFields } from "@/constants/general";
import { DOCUMENT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { DocumentManagementForm } from "@/features/document_management/document_management_form/DocumentManagementForm";
import { useSearchStatus } from "@/hooks/useSearchStatus";
// import { LayoutDocumentMng } from "@/features/document_management/layout/LayoutDocumnentMng";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function DocumentManagementCreatePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const createDocumentManagementQuery = useMutation({
    mutationFn: createDocumentManagement,
    onSuccess: () => {
      toast.success(t("menu.createSuccessDocument"));
      router.push(`/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: "Tạo mới",
    modules: ModuleFields.DOCUMENT_MANAGEMENT.module,
    queryKey: "DOCUMENT_MANAGEMENT_CREATE_FORM",
  });

  return (
    <>
      <DashboardLayout>
        {/* <LayoutDocumentMng isShowAddICon={true}> */}
        {id && (
          <DocumentManagementForm
            folderId={+id}
            formMode="create"
            onSubmit={createDocumentManagementQuery.mutate}
            onCancel={() => router.back()}
            initialValue={{
              status: getSearchStatusQuery?.data?.find(
                (status) => status?.name === "Tạo mới"
              )?.id,
            }}
          />
        )}
        {/* </LayoutDocumentMng> */}
      </DashboardLayout>
    </>
  );
}
