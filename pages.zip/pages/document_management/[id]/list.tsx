import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { DOCUMENT_MANAGEMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { DocumentManagementTable } from "@/features/document_management/document_management_table/DocumentManagementTable";
import { LayoutDocumentMng } from "@/features/document_management/layout/LayoutDocumnentMng";
import { useRouter } from "next/router";
import { useState } from "react";

export default function DocumentsManagementPage() {
  const router = useRouter();
  const [idFolder, setIdFolder] = useState<number | undefined>(undefined);
  const [isAllowCreateStock, setIsAllowCreateStock] = useState<boolean>(true);
  const handleGetIdFolder = (id: number, isAllowCreateStocks: boolean) => {
    setIdFolder(id);    
    setIsAllowCreateStock(isAllowCreateStocks);        
  };

  return (
    <DashboardLayout>
      <LayoutDocumentMng
        handleItemClick={handleGetIdFolder}
        isShowAddICon={true}
      >
        {idFolder && <DocumentManagementTable folderId={idFolder} />}
        {isAllowCreateStock && (
          <StickyAddButton
            ariaLabel="add_documment_template"
            onClick={() =>
              idFolder &&
              router.push(
                `/${DOCUMENT_MANAGEMENT_ROOT_PATH}/${UI_PATH.CREATE}/${idFolder}`
              )
            }
          />
        )}
      </LayoutDocumentMng>
    </DashboardLayout>
  );
}
