import { createLegalAdvice } from '@/apis/service/legal-advice/legalAdvice';
import DashboardLayout from '@/components/layouts'
import { LegalAdviceStatusContent, LegalAdviceStatusKey, ModuleFields } from '@/constants/general';
import { LEGAL_ADVICE_ROOT_PATH, UI_PATH } from '@/constants/paths';
import LegalAdviceForm from '@/features/legal-advice/legal-advice-form/LegalAdviceForm'
import { useSearchStatus } from '@/hooks/useSearchStatus';
import { useMutation } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import React from 'react'
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';

const LegalAdviceCreatePage = () => {

  const [t] = useTranslation();
  const router = useRouter();

  const createLegalAdviceQuery = useMutation({
    mutationFn: createLegalAdvice,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("legalAdvice.label.legalAdviceRequest"),
        })
      );
      router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const getSearchStatusQuery = useSearchStatus({
    keyword: LegalAdviceStatusContent.get(LegalAdviceStatusKey.REQUEST_ADVICE)!,
    modules: ModuleFields.ADVISE_NAME.module,
    queryKey: "LEGAL_ADVICE_LEGAL_ADVICE_FORM",
  });

  return (
    <DashboardLayout>
      <LegalAdviceForm
        formMode='create'
        onSubmit={createLegalAdviceQuery.mutate}
        onSubmitDraft={createLegalAdviceQuery.mutate}
        onCancel={() => router.back()}
        loading={createLegalAdviceQuery?.isPending}
        initialValue={{
          status: getSearchStatusQuery?.data?.find(
            (status) => status?.name === LegalAdviceStatusContent.get(LegalAdviceStatusKey.REQUEST_ADVICE)!
          )?.id,
          checkDeptHeadFlag: true,
          checkDivisionFlag: true,
          legalAccessType: 2,
        }}
      />
    </DashboardLayout>
  )
}

export default LegalAdviceCreatePage