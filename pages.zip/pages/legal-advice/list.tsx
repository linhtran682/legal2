import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { LEGAL_ADVICE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import LegalAdviceTable from "@/features/legal-advice/legal-advice-table/LegalAdviceTable";
import { useRouter } from "next/router";

export default function LegalDocumentsPage() {
  const router = useRouter();

  return (
    <DashboardLayout noFooterBtn>
      <LegalAdviceTable />
      <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
