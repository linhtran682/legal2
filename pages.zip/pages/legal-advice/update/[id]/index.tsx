import { useConfirmLegalAdvice } from "@/apis/service/legal-advice/confirmLegalAdvice";
import {
  cloneLegalAdvice,
  createLegalAdvice,
  getLegalAdviceById,
  shareLegalAdviceFn,
  updateBookMeeting,
  updateLegalAdvice,
} from "@/apis/service/legal-advice/legalAdvice";
import { useRecallLegalAdvice } from "@/apis/service/legal-advice/recallLegalAdvice";
import { getStatusList } from "@/apis/service/status/Status";
import IconRecheck from "@/assets/iconMenu/IconRecheck";
import { ConfirmPopup, ConfirmPopupProps, DefaultConfirmPopupState } from "@/components/commons/popups/confirm_popup/ConfirmPopup";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import { StatusBadge } from "@/components/commons/status_badge/StatusBadge";
import DashboardLayout from "@/components/layouts";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import { URL_OUTLOOK } from "@/constants/constraint";
import { LegalAdviceActionsBtnKey, LegalAdviceStatusContent, LegalAdviceStatusKey, ModuleFields } from "@/constants/general";
import { LEGAL_ADVICE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import { AdvisorLegalAdviceForm } from "@/features/legal-advice/advisor_legal_advice_form/AdvisorLegalAdviceForm";
import { FeedbackAdviceForm } from "@/features/legal-advice/advisor_legal_advice_form/FeedbackAdviceForm";
import { SupervisorAdviceForm } from "@/features/legal-advice/advisor_legal_advice_form/SupervisorAdviceForm";
import { AssignmentLegalAdviceForm } from "@/features/legal-advice/assignment_legal_advice_form/AssignmentLegalAdviceForm";
import { FeedbackLegalAdviceForm } from "@/features/legal-advice/feedback_legal_advice_form/FeedbackLegalAdviceForm";
import { FinishLegalAdviceForm } from "@/features/legal-advice/finish_legal_advice_form/FinishLegalAdviceForm";
import { ForwardLegalAdviceForm } from "@/features/legal-advice/forward_legal_advice_form/ForwardLegalAdviceForm";
import { LegalAdviceLayout } from "@/features/legal-advice/layout/LegalAdviceLayout";
import LegalAdviceForm, { LegalAdviceFormRef } from "@/features/legal-advice/legal-advice-form/LegalAdviceForm";
import { LegalAdviceTableActions } from "@/features/legal-advice/legal-advice-table/legal_advice_table_actions/LegalAdviceTableActions";
import LegalAdviceTabs, { LegalAdviceTabsRef } from "@/features/legal-advice/legal-advice-tabs/LegalAdviceTabs";
import OverviewHeader from "@/features/legal-advice/overview_header/OverviewHeader";
import { RequestAdditionalForm } from "@/features/legal-advice/request_additional_information_form/RequestAdditionalForm";
import { RequestVendorForm } from "@/features/legal-advice/request_vendor_form/RequestVendorForm";
import SendMailForm from "@/features/legal-advice/send_mail_form/SendMailForm";
import { TimeExtensionAdviceForm } from "@/features/legal-advice/time_extension_Advice_form/TimeExtensionAdviceForm";
import useObserveElementSize from "@/hooks/useObserveElementSize";
import { FeedbackLegalAdviceFieldNames } from "@/models/legal-advice/FeedbackLegalAdvice";
import { FinishLegalAdviceFieldNames } from "@/models/legal-advice/FinishLegalAdvice";
import { LegalAdviceBodyReceive, LegalAdviceBodySend, LegalAdviceDetailFields } from "@/models/legal-advice/LegalAdviceDetail";
import { RequestVendorFieldNames } from "@/models/legal-advice/RequestVendor";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { Box, Stack, Tooltip, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

const LegalAdviceDetailPage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const routeAction = router.query.action;
  const appContext = useContext(AppContext);
  const [initialLegalAdvice, setInitialLegalAdvice] = useState<
    LegalAdviceBodyReceive | undefined
  >(undefined);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const { elementRef, size } = useObserveElementSize();
  const laFormRef = useRef<LegalAdviceFormRef>(null);

  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const tabRef = useRef<LegalAdviceTabsRef>(null);

  const scrollToTab = (tab: number) => {
    tabRef?.current?.scrollToTab(tab)
  }

  const getLegalAdviceQuery = useQuery({
    queryKey: ["get_initial_legal_advice"],
    queryFn: () =>
      getLegalAdviceById(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: false,
  });

  const updateLegalAdviceQuery = useMutation({
    mutationFn: updateLegalAdvice,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.legalAdvice"),
        })
      );
      router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const createLegalAdviceQuery = useMutation({
    mutationFn: createLegalAdvice,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.legalAdvice"),
        })
      );
      router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const { mutateAsync: recallLegalAdvice } = useRecallLegalAdvice({
    config: {
      onSuccess: () => {
        toast.success(
          t("legalAdvice.recallLegalAdvice.message.recall_success")
        );
        getLegalAdviceQuery.refetch().then((response) => {
          setInitialLegalAdvice(response.data);
        });
      },
    },
  });

  const { mutateAsync: confirmLegalAdvice } = useConfirmLegalAdvice({
    config: {
      onSuccess: () => {
        toast.success(
          t("legalAdvice.confirmLegalAdvice.message.confirm_success")
        );
        getLegalAdviceQuery.refetch().then((response) => {
          setInitialLegalAdvice(response.data);
        });
      },
    },
  });

  const handleClick = (type: any) => {
    if (type) {
      changePopupVisible(type, true)
      router.replace(`/${LEGAL_ADVICE_ROOT_PATH}/update/${id}?action=${type}`);
    }
  };

  const handleReloadLegalAdviceQuery = async () => {
    getLegalAdviceQuery.refetch().then((response) => {
      setInitialLegalAdvice(response.data);
    });
  }

  const changePopupVisible = (type: any, state: boolean = false, reload: boolean = false) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (reload) {
      getLegalAdviceQuery.refetch().then((response) => {
        setInitialLegalAdvice(response.data);
      });
    }
    if (!state) {
      router.replace(`/${LEGAL_ADVICE_ROOT_PATH}/update/${id}`);
      setPopupVisibleState({});
    }
  };

  useEffect(() => {
    if (routeAction) {
      changePopupVisible(routeAction, true);
    }
  }, [routeAction]);

  useEffect(() => {
    id &&
      getLegalAdviceQuery.refetch().then((response) => {
        setInitialLegalAdvice(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateBookMeetingMutation = useMutation({
    mutationFn: updateBookMeeting,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.legalAdvice"),
        })
      );
      getLegalAdviceQuery.refetch().then((response) => {
        setInitialLegalAdvice(response.data);
      });
    },
  });
  const cloneMutation = useMutation({
    mutationFn: cloneLegalAdvice,
    onSuccess: () => {
      toast.success(
        t(`legalAdvice.messages.recheckSuccess`)
      );
      router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const shareMutation = useMutation({
    mutationFn: shareLegalAdviceFn,
    onSuccess: () => {
      toast.success(
        t(`legalAdvice.messages.shareSuccess`)
      );
      // router.push(`/${LEGAL_ADVICE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const handleRecheck = () => {
    setConfirmPopupState({
      open: true,
      icon: <IconRecheck />,
      title: t(`legalAdvice.messages.confirmRecheck`),
      handleConfirm: () => {
        const requestAdviceStatus = getStatusListQuery?.data
          ?.find((ele: StatusDTO) => ele.name === LegalAdviceStatusContent.get(
            LegalAdviceStatusKey.REQUEST_ADVICE
          )!)

        initialLegalAdvice?.id && cloneMutation.mutate({
          id: initialLegalAdvice?.id as number,
          data: {
            childStatus: requestAdviceStatus?.id as number,
            status: initialLegalAdvice?.status?.id as number
          }
        })
      },
      handleCancel: () =>
        setConfirmPopupState(DefaultConfirmPopupState),
    })
  }

  const getStatusListQuery = useQuery({
    queryKey: ['legal-advice/get-status-list'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.ADVISE_NAME.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.NAME,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: true
  });

  const { mutateAsync: addInfoFn } = useMutation({
    mutationFn: updateLegalAdvice,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.infoAddedSuccess")
      );
      getLegalAdviceQuery.refetch().then((response) => {
        setInitialLegalAdvice(response.data);
      });
    },
  });

  return (
    <DashboardLayout hideHeader>
      {initialLegalAdvice && <LegalAdviceLayout
        handleUpdateBookMeeting={updateBookMeetingMutation.mutateAsync}
        isLoading={updateBookMeetingMutation.isPending
          || getLegalAdviceQuery.isFetching
        }
        initialValueReceive={initialLegalAdvice}>
        <Stack direction={'column'} sx={{ height: '100%', width: "100%" }}>
          <Breadcrumb />
          <Tooltip title={initialLegalAdvice?.legalAdviceName ?? ""} placement="top-start">
            <Typography variant="h1" sx={{
              fontSize: "24px", mb: 1,
              overflow: "hidden",
              textOverflow: "ellipsis",
              display: "-webkit-box",
              WebkitLineClamp: "1",
              WebkitBoxOrient: "vertical",
              wordBreak: 'break-word',
              width: "fit-content"
            }}>
              {initialLegalAdvice?.legalAdviceName}
            </Typography>
          </Tooltip>
          {initialLegalAdvice
            ? <StatusBadge label={initialLegalAdvice?.isDraft
              ? t('common.label.draft')
              : initialLegalAdvice?.status?.name as string} />
            : null}
          <Box height={12} />
          {(!initialLegalAdvice?.isDraft
            // &&
            // ((initialLegalAdvice?.status?.name !== LegalAdviceStatusContent.get(
            //   LegalAdviceStatusKey.DONE
            // )! && !ownRole.includes(1)) || ownRole.includes(1))
          )
            && <LegalAdviceTableActions
              params={{
                row: initialLegalAdvice,
              }}
              handleClickRecall={async () => await recallLegalAdvice(Number(id))}
              handleClickForWard={() =>
                handleClick(LegalAdviceActionsBtnKey.FORWARD)
              }
              handleClickFeedBack={() =>
                handleClick(LegalAdviceActionsBtnKey.FEEDBACK)
              }
              handleClickRequestMeeting={() => window.open(URL_OUTLOOK, "_blank")}
              handleClickSendMail={() =>
                handleClick(LegalAdviceActionsBtnKey.SEND_MAIL)
              }
              handleClickExtendTime={() =>
                handleClick(LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION)
              }
              handleClickConfirm={async () => await confirmLegalAdvice(Number(id))}
              handleClickAssignment={() =>
                handleClick(LegalAdviceActionsBtnKey.ASSIGNMENT)
              }
              handleClickRequestVendor={() =>
                handleClick(LegalAdviceActionsBtnKey.REQUEST_VENDOR)
              }
              handleClickFeedbackAdvise={() =>
                handleClick(LegalAdviceActionsBtnKey.FEEDBACK_ADVISE)
              }
              handleClickRequestAdditional={() =>
                handleClick(LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL)
              }
              handleClickAdvise={() => handleClick(LegalAdviceActionsBtnKey.ADVISE)}
              handleClickDone={() => handleClick(LegalAdviceActionsBtnKey.DONE)}
              handleClickShare={() => handleClick(LegalAdviceActionsBtnKey.SHARE)}
              handleClickRecheck={handleRecheck}
              handleClickAddInfo={() => {
                const params = laFormRef?.current?.getParams() as LegalAdviceBodySend;
                params.status = getStatusListQuery?.data?.find((ele: StatusDTO) => ele.name === LegalAdviceStatusContent.get(
                  LegalAdviceStatusKey.ADDITIONAL_INFORMATION
                ))?.id;
                initialLegalAdvice?.id && addInfoFn({
                  id: initialLegalAdvice?.id,
                  request: params
                })
              }}
              isActionDetail
            />}
          {/* {(initialLegalAdvice && !initialLegalAdvice.isDraft
            && initialLegalAdvice?.status?.name === LegalAdviceStatusContent.get(
              LegalAdviceStatusKey.DONE
            )!
            // && ownRole.includes(1)
          ) && <Button
            key={'recheck_lcs'}
            onClick={handleRecheck}
            sx={recheckBtnSx}
            variant='contained'
            className="confirm"
          >{t(`legalAdvice.actions.recheck`)}</Button>} */}
          <Box sx={{ flex: 1, overflowY: 'auto' }} ref={elementRef}>
            <OverviewHeader
              scrollToTab={scrollToTab}
              initialValueReceive={initialLegalAdvice}
              handleUpdateBookMeeting={updateBookMeetingMutation.mutateAsync}
              isLoading={updateBookMeetingMutation.isPending
                || getLegalAdviceQuery.isFetching
              }
            />
            <LegalAdviceForm
              ref={laFormRef}
              handleReloadLegalAdviceQuery={handleReloadLegalAdviceQuery}
              formMode="update"
              getStatusListQuery={getStatusListQuery}
              initialValueReceive={initialLegalAdvice}
              onCancel={() => router.back()}
              loading={
                createLegalAdviceQuery?.isPending ||
                updateLegalAdviceQuery?.isPending
              }
              onSubmitDraft={(data) => {
                if (id) {
                  updateLegalAdviceQuery.mutate({
                    request: data,
                    id: typeof id == "string" ? Number(id) : Number(id[0]),
                  });
                }
              }}
              onSubmit={(data) => {
                if (id && initialLegalAdvice?.isDraft) {
                  createLegalAdviceQuery.mutate({
                    ...data,
                    isDraft: false,
                    legalAdviceId: initialLegalAdvice.id,
                  });
                }
                if (id && !initialLegalAdvice?.isDraft) {
                  updateLegalAdviceQuery.mutate({
                    request: data,
                    id: typeof id == "string" ? Number(id) : Number(id[0]),
                  });
                }
              }}
            />
            {initialLegalAdvice?.id && (
              <>
                <Box height={16} />
                <LegalAdviceTabs
                  handleReloadLegalAdviceQuery={handleReloadLegalAdviceQuery}
                  containerHeight={size.height}
                  ref={tabRef}
                  legalAdviceId={initialLegalAdvice?.id}
                  legalAdvice={initialLegalAdvice}
                />
              </>
            )}
          </Box>
        </Stack>
      </LegalAdviceLayout>}

      <ConfirmPopup {...confirmPopupState} />
      {popupVisibleState?.[LegalAdviceActionsBtnKey.SHARE] && <SharePopup
        setIsOpen={(state, reload) =>
          changePopupVisible(LegalAdviceActionsBtnKey.SHARE, state, reload)
        }
        isOpen={true}
        owner={initialLegalAdvice?.pic}
        pics={initialLegalAdvice?.responsibleUsers}
        onSubmit={async (data: any) => {
          const params = {
            id: initialLegalAdvice?.id as number,
            data
          }
          await shareMutation.mutateAsync(params)
        }}
        initialValue={{
          legalAccessType: initialLegalAdvice?.legalAccessType,
          sharedDepartments: initialLegalAdvice?.sharedDepartments,
          sharedUsers: initialLegalAdvice?.sharedUsers
        }}
      />}

      {popupVisibleState?.[LegalAdviceActionsBtnKey.SEND_MAIL] && (
        <SendMailForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.SEND_MAIL, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.SEND_MAIL]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          legalAdvice={initialLegalAdvice}
          senderDocumentManagement={appContext?.me}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.FORWARD] && (
        <ForwardLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.FORWARD, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.FORWARD]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          responseDate={initialLegalAdvice?.responseDate}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.ASSIGNMENT] && (
        <AssignmentLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.ASSIGNMENT, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.ASSIGNMENT]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          pic={initialLegalAdvice?.pic}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_VENDOR] && (
        <RequestVendorForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.REQUEST_VENDOR, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_VENDOR]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            [RequestVendorFieldNames.USERS]: initialLegalAdvice?.pic ? [appContext?.me, initialLegalAdvice.pic] : [appContext?.me],
            [RequestVendorFieldNames.DEADLINE]: initialLegalAdvice?.[LegalAdviceDetailFields.VENDOR_RESPONSE_DATE] || undefined
          }}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION] && (
        <TimeExtensionAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION,
              state,
              reload
            )
          }
          isOpen={
            popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_TIME_EXTENSION]
          }
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialLegalAdvice?.pic],
          }}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.DONE] && (
        <FinishLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.DONE]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          advise={appContext?.me}
          initialValue={{
            [FinishLegalAdviceFieldNames.USER_IDS]: (initialLegalAdvice?.receiverUsers || [])?.concat(initialLegalAdvice?.assignmentUsers || [])
          }}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAdditionalForm
          setIsOpen={(state, reload) =>
            changePopupVisible(
              LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL,
              state,
              reload
            )
          }
          isOpen={
            popupVisibleState?.[LegalAdviceActionsBtnKey.REQUEST_ADDITIONAL]
          }
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialLegalAdvice?.pic],
          }}
          maxDate= {initialLegalAdvice?.responseDate}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.ADVISE] &&
        (!initialLegalAdvice?.superVisor ? (
          <AdvisorLegalAdviceForm
            legalAdviceId={initialLegalAdvice?.id}
            legalAdviceName={initialLegalAdvice?.legalAdviceName}
            isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.ADVISE]}
            adviseId={initialLegalAdvice?.adviseId}
            setIsOpen={(state, reload) =>
              changePopupVisible(LegalAdviceActionsBtnKey.ADVISE, state, reload)
            }
            senderDocumentManagement={appContext?.me}
            initialLegalAdvice={initialLegalAdvice}
          />
        ) : (
          <SupervisorAdviceForm
            legalAdviceId={initialLegalAdvice?.id}
            legalAdviceName={initialLegalAdvice?.legalAdviceName}
            isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.ADVISE]}
            adviseId={initialLegalAdvice?.adviseId}
            setIsOpen={(state, reload) =>
              changePopupVisible(LegalAdviceActionsBtnKey.ADVISE, state, reload)
            }
            senderDocumentManagement={appContext?.me}
            initialLegalAdvice={initialLegalAdvice}
          />
        ))}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE] && (
        <FeedbackAdviceForm
          legalAdviceId={initialLegalAdvice?.id}
          legalAdviceName={initialLegalAdvice?.legalAdviceName}
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.FEEDBACK_ADVISE, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK_ADVISE]}
          senderDocumentManagement={appContext?.me}
          responseDate={initialLegalAdvice?.responseDate}
        />
      )}
      {popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK] && (
        <FeedbackLegalAdviceForm
          setIsOpen={(state, reload) =>
            changePopupVisible(LegalAdviceActionsBtnKey.FEEDBACK, state, reload)
          }
          isOpen={popupVisibleState?.[LegalAdviceActionsBtnKey.FEEDBACK]}
          legalAdviceId={initialLegalAdvice?.id}
          name={initialLegalAdvice?.legalAdviceName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            [FeedbackLegalAdviceFieldNames.USERS]: initialLegalAdvice?.pic ? [initialLegalAdvice?.pic] : [],
            [FeedbackLegalAdviceFieldNames.DEADLINE]: initialLegalAdvice?.responseDate ? new Date(initialLegalAdvice?.responseDate) : new Date()
          }}
        />
      )}
    </DashboardLayout>
  );
};


export default LegalAdviceDetailPage;
