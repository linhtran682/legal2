import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { muiThemeOptions, MuiViVNLocaleSet } from "@/constants/theme";
import { createTheme, CssBaseline, ThemeProvider } from "@mui/material";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFnsV3";
import "../locales/config-translation/index";
import "react-toastify/dist/ReactToastify.css";
import { toast, ToastContainer } from "react-toastify";
import {
  DefaultError,
  MutationCache,
  QueryCache,
  QueryClient,
  QueryClientProvider,
} from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { LANGUAGES } from "../locales/config-translation/index";
import { useState } from "react";
import { AxiosError } from "axios";
import { AxiosInterceptor, ResponseWrapper } from "@/apis";
import { AppContext, useAppContext } from "@/context/AppContext";
import { AuthProvider } from "@/authAccess/hooks/auth-provider";
import { NextActionProvider } from "@/context/NextActionContext";
import { ErrorProvider } from "@/context/ErrorContext";
import { KNOWN_ERROR_CODES } from "@/constants/general";

export default function App({ Component, pageProps }: AppProps) {
  const { t, i18n } = useTranslation();
  const appContext = useAppContext();

  const handleError = (error: DefaultError) => {
    const errorBody = (error as AxiosError<ResponseWrapper<any>>)
      ?.response?.data?.error;
    const code = errorBody?.code;
    toast.error(
      KNOWN_ERROR_CODES?.includes(code as number)
        ? t(`common.error_code.${code}`)
        : errorBody?.message
      // t(
      //   `common.error_code.${(error as AxiosError<ResponseWrapper<any>>).response?.data?.error
      //     ?.code
      //   }`
      // )
    );
  };

  const [queryClient] = useState(
    () =>
      new QueryClient({
        queryCache: new QueryCache({ onError: handleError }),
        mutationCache: new MutationCache({
          onError: handleError,
        }),
        defaultOptions: {
          queries: {
            refetchOnWindowFocus: false,
          },
        },
      })
  );

  const theme =
    i18n.language == LANGUAGES.VIETNAMESE
      ? createTheme(muiThemeOptions, ...MuiViVNLocaleSet)
      : createTheme(muiThemeOptions);

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider theme={theme}>
          <ErrorProvider>
            <AxiosInterceptor>
              <AuthProvider>
                <AppContext.Provider value={appContext}>
                  <NextActionProvider>
                    <CssBaseline />
                    <ToastContainer />
                    <Component {...pageProps} />
                  </NextActionProvider>
                </AppContext.Provider>
              </AuthProvider>
            </AxiosInterceptor>
          </ErrorProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </LocalizationProvider>
  );
}
