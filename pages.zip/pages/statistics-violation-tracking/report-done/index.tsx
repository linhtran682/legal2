import DashboardLayout from '@/components/layouts'
import ViolationTrackingReportDone from '@/features/statistics-violation-tracking/report-done/ViolationTrackingReportDone'

const ViolationReportDonePage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <ViolationTrackingReportDone />
    </DashboardLayout>
  )
}

export default ViolationReportDonePage