import DashboardLayout from '@/components/layouts'
import ViolationTrackingReportFollowing from '@/features/statistics-violation-tracking/report-following/ViolationTrackingReportFollowing'

const ViolationReportFollowingPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <ViolationTrackingReportFollowing />
    </DashboardLayout>
  )
}

export default ViolationReportFollowingPage