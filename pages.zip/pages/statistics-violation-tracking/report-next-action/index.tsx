import DashboardLayout from '@/components/layouts'
import ViolationNextActionReport from '@/features/statistics-violation-tracking/report-next-action/ViolationNextActionReport'

const ViolationReportNextActionPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <ViolationNextActionReport />
    </DashboardLayout>
  )
}

export default ViolationReportNextActionPage