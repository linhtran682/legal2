import DashboardLayout from '@/components/layouts'
import ViolationTrackingReport from '@/features/statistics-violation-tracking/report/ViolationTrackingReport'
import React from 'react'

const ViolationTrackingReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <ViolationTrackingReport />
    </DashboardLayout>
  )
}

export default ViolationTrackingReportPage