import DashboardLayout from "@/components/layouts";
import ViolationTrackingOverview from "@/features/statistics-violation-tracking/overview/ViolationTrackingOverview";

export default function ViolationTrackingReport() {

  return (
    <DashboardLayout noFooterBtn>
      <ViolationTrackingOverview />
    </DashboardLayout>
  );
}
