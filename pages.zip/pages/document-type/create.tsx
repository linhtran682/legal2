import { createDocumentType } from "@/apis/service/document_type/DocumentType";
import DashboardLayout from "@/components/layouts";
import { DOCUMENT_TYPE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveDocumentTypeForm } from "@/features/document_type/save_document_type_form/SaveDocumentTypeForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateDocumentTypePage() {
  const [t] = useTranslation();
  const router = useRouter();

  const createDocumentTypeQuery = useMutation({
    mutationFn: createDocumentType,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.documentType"),
        })
      );
      router.push(`/${DOCUMENT_TYPE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveDocumentTypeForm
        formMode='create'
        onSubmit={createDocumentTypeQuery.mutate}
        onCancel={() => router.back()}
        loading={createDocumentTypeQuery.isPending}
      />
    </DashboardLayout>
  );
}
