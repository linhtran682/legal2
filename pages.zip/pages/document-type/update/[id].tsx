import {
  deleteDocumentTypes,
  getDocumentType,
  updateDocumentType,
} from "@/apis/service/document_type/DocumentType";
import DashboardLayout from "@/components/layouts";
import { DOCUMENT_TYPE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveDocumentTypeForm } from "@/features/document_type/save_document_type_form/SaveDocumentTypeForm";
import { DocumentTypeDTO } from "@/models/document_type/DocumentType";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateDocumentTypePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialDocumentType, setInitialDocumentType] = useState<
    DocumentTypeDTO | undefined
  >(undefined);

  const getDocumentTypeQuery = useQuery({
    queryKey: ["get_initial_DocumentType"],
    queryFn: () =>
      getDocumentType(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getDocumentTypeQuery
        .refetch()
        .then((response) => {
          setInitialDocumentType(response.data);
        })
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateDocumentTypeQuery = useMutation({
    mutationFn: updateDocumentType,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.documentType"),
        })
      );
      router.push(`/${DOCUMENT_TYPE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteDocumentTypesQuery = useMutation({
    mutationFn: deleteDocumentTypes,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.documentType"),
        })
      );
      router.push(`/${DOCUMENT_TYPE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveDocumentTypeForm
        formMode='update'
        initialValue={initialDocumentType}
        onSubmit={(data) =>
          id &&
          updateDocumentTypeQuery.mutate({
            request: data,
            id: typeof id == "string" ? Number(id) : Number(id[0]),
          })
        }
        onCancel={() => router.back()}
        onDelete={() =>
          id &&
          deleteDocumentTypesQuery.mutate(
            typeof id == "string" ? [Number(id)] : [Number(id[0])]
          )
        }
        loading={
          updateDocumentTypeQuery.isPending ||
          getDocumentTypeQuery.isFetching ||
          deleteDocumentTypesQuery.isPending
        }
      />
    </DashboardLayout>
  );
}
