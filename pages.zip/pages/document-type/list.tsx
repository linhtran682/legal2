import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { DOCUMENT_TYPE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { DocumentTypeTable } from "@/features/document_type/document_type_table/DocumentTypeTable";
import { useRouter } from "next/navigation";

export default function DocumentTypesPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <DocumentTypeTable />
      <StickyAddButton
        ariaLabel='add_document_type'
        onClick={() =>
          router.push(`/${DOCUMENT_TYPE_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
