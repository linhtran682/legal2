import DashboardLayout from '@/components/layouts'
import RelationshipMngReportDone from '@/features/statistics-relationship-dis/relationship-mng-report-done/RelationshipMngReportDone'

const LegalAdviceReportDonePage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <RelationshipMngReportDone />
    </DashboardLayout>
  )
}

export default LegalAdviceReportDonePage