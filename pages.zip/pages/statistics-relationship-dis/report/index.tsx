import DashboardLayout from '@/components/layouts'
import RelationshipMngReport from '@/features/statistics-relationship-dis/relationship-mng-report/RelationshipMngReport'
import React from 'react'

const ConflictReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <RelationshipMngReport/>
    </DashboardLayout>
  )
}

export default ConflictReportPage