import DashboardLayout from "@/components/layouts";
import RelationshipMngOverview from "@/features/statistics-relationship-dis/relationship-mng-overview/RelationshipMngOverview";

export default function ConflictMngReport() {

  return (
    <DashboardLayout noFooterBtn>
      <RelationshipMngOverview />
    </DashboardLayout>
  );
}
