import { FieldTable } from "@/features/field/field_table/FieldTable";
import DashboardLayout from "@/components/layouts";
import { FIELD_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useRouter } from "next/navigation";
import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";

export default function FieldsPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <FieldTable />
      <StickyAddButton
        ariaLabel='add_field'
        onClick={() => router.push(`/${FIELD_ROOT_PATH}/${UI_PATH.CREATE}`)}
      />
    </DashboardLayout>
  );
}
