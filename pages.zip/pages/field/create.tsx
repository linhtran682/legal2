import { createField } from "@/apis/service/field/Field";
import { SaveFieldForm } from "@/features/field/save_field_form/SaveFieldForm";
import DashboardLayout from "@/components/layouts";
import { FIELD_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateFieldPage() {
  const [t] = useTranslation();
  const router = useRouter();

  const createFieldQuery = useMutation({
    mutationFn: createField,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.field"),
        })
      );
      router.push(`/${FIELD_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveFieldForm
        formMode='create'
        onSubmit={createFieldQuery.mutate}
        onCancel={() => router.back()}
        loading={createFieldQuery.isPending}
      />
    </DashboardLayout>
  );
}
