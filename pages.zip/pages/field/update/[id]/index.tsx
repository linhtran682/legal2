import {
  deleteFields,
  getField,
  updateField,
} from "@/apis/service/field/Field";
import { SaveFieldForm } from "@/features/field/save_field_form/SaveFieldForm";
import DashboardLayout from "@/components/layouts";
import { FIELD_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { FieldDTO } from "@/models/field/Field";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateFieldPage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialField, setInitialField] = useState<FieldDTO | undefined>(
    undefined
  );

  const getFieldQuery = useQuery({
    queryKey: ["get_initial_field"],
    queryFn: () =>
      getField(typeof id == "string" ? Number(id) : Number((id || [])[0])),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getFieldQuery
        .refetch()
        .then((response) => {
          setInitialField(response.data);
        })
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateFieldQuery = useMutation({
    mutationFn: updateField,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.field"),
        })
      );
      router.push(`/${FIELD_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteFieldsQuery = useMutation({
    mutationFn: deleteFields,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.field"),
        })
      );
      router.push(`/${FIELD_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveFieldForm
        formMode='update'
        initialValue={initialField}
        onSubmit={(data) =>
          id &&
          updateFieldQuery.mutate({
            request: data,
            id: typeof id == "string" ? Number(id) : Number(id[0]),
          })
        }
        onDelete={() =>
          id &&
          deleteFieldsQuery.mutate(
            typeof id == "string" ? [Number(id)] : [Number(id[0])]
          )
        }
        onCancel={() => router.back()}
        loading={
          updateFieldQuery.isPending ||
          getFieldQuery.isFetching ||
          deleteFieldsQuery.isPending
        }
      />
    </DashboardLayout>
  );
}
