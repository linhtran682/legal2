import { createFollowViolation } from '@/apis/service/follow_violation/followViolationAPI';
import DashboardLayout from '@/components/layouts'
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH, UI_PATH } from '@/constants/paths';
import FollowViolationForm from '@/features/follow-violation/form/FollowViolationForm';
import { useMutation } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import React from 'react'
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';

const FollowViolationCreatePage = () => {

  const [t] = useTranslation();
  const router = useRouter();

  const createFollowViolationQuery = useMutation({
    mutationFn: createFollowViolation,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("followViolation.label.requestNameTitle"),
        })
      );

      setTimeout(() => {
        router.push(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.LIST}`);
      }, 1000);
    },
  });
  return (
    <DashboardLayout>
      <FollowViolationForm
        formMode='create'
        onSubmit={createFollowViolationQuery.mutate}
        onSubmitDraft={createFollowViolationQuery.mutate}
        onCancel={() => router.back()}
        loading={createFollowViolationQuery?.isPending}
      />
    </DashboardLayout>
  )
}

export default FollowViolationCreatePage