import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH, UI_PATH } from "@/constants/paths";
import FollowViolationTable from "@/features/follow-violation/FollowViolationTable";
import { useRouter } from "next/router";

export default function DocumentsManagementPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <FollowViolationTable />
      <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
