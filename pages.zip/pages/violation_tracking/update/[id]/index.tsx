import {
  createFollowViolation,
  deleteViolation,
  getNextActionByViolationId,
  getViolationById,
  shareFollowViolationFn,
  updateBookMeetingViolation,
  updateViolation,
} from "@/apis/service/follow_violation/followViolationAPI";
import { useRecallViolation } from "@/apis/service/follow_violation/recallViolation";
import { useConfirmFollowViolation } from "@/apis/service/follow_violation/confirmFollowViolation";
import DashboardLayout from "@/components/layouts";
import { URL_OUTLOOK } from "@/constants/constraint";
import {
  FollowViolationActionsBtnKey,
  FollowViolationUserRole,
  FollowViolationUserRoleKey,
  ViolationStatusCode,
} from "@/constants/followViolation";
import { LEGAL_VIOLATION_TRACKING_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import { AssignmentFollowViolationForm } from "@/features/follow-violation/components/assignment_follow_violation_form/AssignmentFollowViolationForm";
import { AdviceFinishedFollowViolationForm } from "@/features/follow-violation/components/advice_finished_follow_violation_form/AdviceFinishedFollowViolationForm";
import { AdviceFollowViolationForm } from "@/features/follow-violation/components/advice_follow_violation_form/AdviceFollowViolationForm";
import { FeedBackFollowViolationForm } from "@/features/follow-violation/components/feedback_follow_violation_form/FeedBackFollowViolationForm";
import { FeedBackLcFollowViolationForm } from "@/features/follow-violation/components/feedback_lc_follow_violation_form/FeedBackLcFollowViolationForm";
import { FeedBackNextActionFollowViolationForm } from "@/features/follow-violation/components/feedback_next_action_follow_violation_form/FeedBackNextActionFollowViolationForm";
import { FinishFollowViolationForm } from "@/features/follow-violation/components/finish_follow_violation_form/FinishFollowViolationForm";
import { ForwardFollowViolationForm } from "@/features/follow-violation/components/forward_follow_violation_form/ForwardFollowViolationForm";
import { RequestAddInfoFollowViolationForm } from "@/features/follow-violation/components/request_add_info_follow_violation_form/RequestAddInfoFollowViolationForm";
import { RequestVendorFollowViolationForm } from "@/features/follow-violation/components/request_vendor_follow_violation_form/RequestVendorFollowViolationForm";
import SendMailFollowViolationForm from "@/features/follow-violation/components/send_mail_follow_violation_form/SendMailFollowViolationForm";
import { TimeExtensionFollowViolationForm } from "@/features/follow-violation/components/time_extension_follow_violation_form/TimeExtensionFollowViolationForm";
import { TrackNextActionFollowViolationForm } from "@/features/follow-violation/components/track_next_action_follow_violation_form/TrackNextActionFollowViolationForm";
import { FollowViolationTableActions } from "@/features/follow-violation/FollowViolationTableActions";
import FollowViolationForm from "@/features/follow-violation/form/FollowViolationForm";
import { ViolationLayoutDetail } from "@/features/follow-violation/layout/ViolationLayoutDetail";
import ViolationDetailTabs from "@/features/follow-violation/tabs/ViolationDetailTabs";
import {
  FollowViolationDetail,
  ViolationTabsRef,
} from "@/models/follow_violation/FormType";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/router";
import {
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";
import { SearchPanelQueries } from "@/features/follow-violation/components/SearchPanel";
import { Stack, Tabs, Tab, Typography, Box } from "@mui/material";
import NextActionForm from "@/features/follow-violation/form/NextActionForm";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import ViolationInformation from "@/features/follow-violation/form/ViolationInformation";
import StatusButton from "@/components/commons/action_button/StatusButton";
import useObserveElementSize from "@/hooks/useObserveElementSize";
import { useAdditionalInformationFollowViolation } from "@/apis/service/follow_violation/additionalInformationFollowViolation";
import SharePopup from "@/components/commons/share_popup/SharePopup";

type TabItemType = {
  label: string;
  key: "violation-detail" | "next-action-tabs";
};

const TabItems: TabItemType[] = [
  {
    label: "followViolation.tabs.violation",
    key: "violation-detail",
  },
  {
    label: "followViolation.tabs.nextAction",
    key: "next-action-tabs",
  },
];

const FollowViolationDetailPage = () => {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const routeAction = router.query.action;
  const appContext = useContext(AppContext);
  const [activeTab, setActiveTab] = useState(0);
  const [currentId, setCurrentId] = useState("");
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const [initialViolation, setInitialViolation] = useState<
    FollowViolationDetail | undefined
  >(undefined);
  const tabRef = useRef<ViolationTabsRef>(null);
  const { elementRef, size } = useObserveElementSize();
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const queryClient = useQueryClient();
  const disableSpecialFields = useMemo(() => {
    return (
      !appContext.meCanWrite ||
      (!ownRole.length &&
        !ownRole.includes(1) &&
        !ownRole.includes(2) &&
        !ownRole.includes(3) &&
        !ownRole.includes(5) &&
        !ownRole.includes(6) &&
        !ownRole.includes(7))
    );
  }, [appContext.meCanWrite, ownRole]);

  const updateBookMeetingMutation = useMutation({
    mutationFn: updateBookMeetingViolation,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.violationTracking"),
        })
      );
      queryClient.invalidateQueries({
        queryKey: ["get_initial_violation_query"],
      });
    },
  });

  const getViolationQuery = useQuery({
    queryKey: [
      "get_initial_violation_query",
      SearchPanelQueries.GET_HIERARCHY,
      id,
    ],
    queryFn: () =>
      getViolationById(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: !!id,
  });

  const getViolationNextActionQuery = useQuery({
    queryKey: ["get_violation_next_action_query", id],
    queryFn: () =>
      getNextActionByViolationId(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: !!id,
  });

  const scrollToTab = (tab: number) => {
    tabRef?.current?.scrollToTab(tab);
  };

  const updateViolationQuery = useMutation({
    mutationFn: updateViolation,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.violationTracking"),
        })
      );
      router.push(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteViolationQuery = useMutation({
    mutationFn: deleteViolation,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.violationTracking"),
        })
      );
      router.push(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const createViolationQuery = useMutation({
    mutationFn: createFollowViolation,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.violationTracking"),
        })
      );
      router.push(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const { mutateAsync: recallViolation } = useRecallViolation({
    config: {
      onSuccess: () => {
        toast.success(
          t("followViolation.recallFollowViolation.message.recall_success")
        );
        getViolationQuery.refetch().then((response) => {
          setInitialViolation(response.data);
        });
      },
    },
  });

  const { mutateAsync: confirmFollowViolation } = useConfirmFollowViolation({
    config: {
      onSuccess: () => {
        toast.success(
          t("followViolation.confirmFollowViolation.message.confirm_success")
        );
        getViolationQuery.refetch().then((response) => {
          setInitialViolation(response.data);
        });
      },
    },
  });

  const { mutateAsync: additionalInformationFollowViolation } =
    useAdditionalInformationFollowViolation({
      config: {
        onSuccess: () => {
          toast.success(
            t(
              "followViolation.additionalInformationFollowViolation.message.additionalInformationSuccess"
            )
          );
          getViolationQuery.refetch().then((response) => {
            setInitialViolation(response.data);
          });
        },
      },
    });

  const shareMutation = useMutation({
    mutationFn: shareFollowViolationFn,
    onSuccess: () => {
      toast.success(t(`followViolation.messages.shareSuccess`));
    },
  });

  useEffect(() => {
    if (id) {
      if (id !== currentId) {
        setActiveTab(0);
      }

      setCurrentId(id as string);
    }
  }, [currentId, id]);

  useEffect(() => {
    if (
      initialViolation &&
      initialViolation?.lastActionAndRole?.userLastActionAndRoleList?.length
    ) {
      const {
        lastActionAndRole: { userLastActionAndRoleList },
      } = initialViolation;
      const roleList = userLastActionAndRoleList?.map((ele) => ele.role);
      setOwnRole(roleList);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialViolation]);

  const handleClick = (type: any) => {
    if (type) {
      const path = `/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/update/${id}?action=${type}`;
      // if ((type === FollowViolationActionsBtnKey.APPROVAL_DEPT_HEAD
      //   || type === FollowViolationActionsBtnKey.APPROVAL_GROUP_HEAD
      //   || type === FollowViolationActionsBtnKey.APPROVAL_TOP_HEAD) && list.length > 0) {
      //     path += `&list=${list.toString()}`
      // }
      router.replace(path);
    }
  };

  const changePopupVisible = useCallback(
    (type: any, state: boolean = false, reload: boolean = false) => {
      setPopupVisibleState((prev) => ({
        ...prev,
        [type]: state,
      }));

      if (!state) {
        router.replace(`/${LEGAL_VIOLATION_TRACKING_ROOT_PATH}/update/${id}`);
      }

      if (reload) {
        getViolationQuery.refetch().then((response) => {
          setInitialViolation(response.data);
        });
      }
    },
    [id, router]
  );

  useEffect(() => {
    if (routeAction && initialViolation?.id && !getViolationQuery.isFetching) {
      changePopupVisible(routeAction, true);
    } else {
      setPopupVisibleState({});
    }
  }, [
    initialViolation,
    routeAction,
    getViolationQuery.isFetching,
    changePopupVisible,
  ]);

  useEffect(() => {
    if (getViolationQuery?.data) {
      setInitialViolation(getViolationQuery.data);
    }
  }, [getViolationQuery?.data]);

  const handleDeleteViolation = () => {
    deleteViolationQuery.mutate(
      typeof id == "string" ? Number(id) : Number(id?.[0])
    );
  };

  const checkDisableTab = (tabItem: TabItemType) => {
    if (tabItem.key === "violation-detail") {
      return false;
    }

    if (tabItem.key === "next-action-tabs") {
      if (
        appContext?.me?.id === initialViolation?.createdBy?.id &&
        initialViolation?.status?.code === ViolationStatusCode.COMPLETE_ADVISE
      ) {
        return false;
      }

      if (!getViolationNextActionQuery.data?.name && !ownRole.includes(1)) {
        return true;
      }

      if (initialViolation?.status?.code === ViolationStatusCode.FINISH) {
        return true;
      }

      if (
        !getViolationNextActionQuery.data?.name &&
        ownRole.includes(1) &&
        initialViolation?.status?.code !== ViolationStatusCode.COMPLETE_ADVISE
      ) {
        return true;
      }
    }

    return false;
  };

  return (
    <DashboardLayout hideHeader>
      <ViolationLayoutDetail>
        <Stack direction={"column"} sx={{ height: "100%" }}>
          <Breadcrumb />
          <Typography
            variant="h1"
            sx={{
              fontSize: "24px",
              mb: 1,
              overflow: "hidden",
              whiteSpace: "nowrap",
              textOverflow: "ellipsis",
              width: "80%",
            }}
            component={"div"}
            title={initialViolation?.name}
          >
            {initialViolation?.name}
          </Typography>
          <Box sx={{ mb: 1, display: "flex", columnGap: 3 }}>
            {initialViolation?.status && (
              <StatusButton
                status={
                  initialViolation.isDraft
                    ? t("common.label.draft")
                    : initialViolation?.status?.name ??
                      t("visitation.label.requestAdviseStatus")
                }
              />
            )}
          </Box>
          <Tabs
            value={activeTab}
            onChange={(_, i) => setActiveTab(i)}
            // variant='scrollable'
          >
            {TabItems.map((tabItem: TabItemType) => (
              <Tab
                label={<Typography variant="h5">{t(tabItem.label)}</Typography>}
                key={tabItem.key}
                id={`tab-label-${tabItem.key}`}
                aria-controls={`tab-panel-${tabItem.key}`}
                sx={{
                  textTransform: "none",
                  // backgroundColor: 'white'
                }}
                disabled={checkDisableTab(tabItem)}
              />
            ))}
          </Tabs>
          <Box height={12} component={"div"}></Box>
          {!initialViolation?.isDraft && (
            <FollowViolationTableActions
              isActionDetail
              params={{
                row: initialViolation,
                nextAction: getViolationNextActionQuery?.data,
              }}
              activeTab={activeTab}
              isEditNextActionTab={!!getViolationNextActionQuery.data?.name}
              handleClickConfirm={async () =>
                await confirmFollowViolation(Number(id))
              }
              handleClickRecall={async () => await recallViolation(Number(id))}
              handleClickForWard={() =>
                handleClick(FollowViolationActionsBtnKey.FORWARD)
              }
              handleClickFeedBack={() =>
                handleClick(FollowViolationActionsBtnKey.FEEDBACK)
              }
              handleClickShare={() =>
                handleClick(FollowViolationActionsBtnKey.SHARE)
              }
              handleClickFeedBackLc={() =>
                handleClick(FollowViolationActionsBtnKey.FEEDBACK_LC)
              }
              handleClickRequestMeeting={() =>
                window.open(URL_OUTLOOK, "_blank")
              }
              handleClickSendMail={() =>
                handleClick(FollowViolationActionsBtnKey.SEND_MAIL)
              }
              handleClickExtendTime={() =>
                handleClick(FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST)
              }
              handleClickAssignment={() =>
                handleClick(FollowViolationActionsBtnKey.ASSIGNMENT)
              }
              handleClickRequestVendor={() =>
                handleClick(FollowViolationActionsBtnKey.REQUEST_VENDOR)
              }
              handleClickAdviseFinished={() =>
                handleClick(FollowViolationActionsBtnKey.ADVICE_FINISHED)
              }
              handleClickFeedbackAdvise={() =>
                handleClick(FollowViolationActionsBtnKey.FEEDBACK_ADVICE)
              }
              handleClickRequestAdditional={() =>
                handleClick(FollowViolationActionsBtnKey.REQUEST_ADDITIONAL)
              }
              handleClickAdditionalInformation={async () =>
                await additionalInformationFollowViolation(Number(id))
              }
              handleClickAdvise={() =>
                handleClick(FollowViolationActionsBtnKey.ADVICE)
              }
              handleClickFeedBackNextAction={() =>
                handleClick(FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION)
              }
              handleClickTrackNextAction={() =>
                handleClick(FollowViolationActionsBtnKey.TRACK_NEXT_ACTION)
              }
              handleClickFinish={() =>
                handleClick(FollowViolationActionsBtnKey.FINISH)
              }
            />
          )}
          <Box sx={{ flex: 1, overflowY: "auto" }} ref={elementRef}>
            <ViolationInformation
              scrollToTab={scrollToTab}
              isMeeting={!!initialViolation?.isBookMeeting}
              initialValueReceive={initialViolation}
              disabled={disableSpecialFields}
              handleUpdateBookMeeting={updateBookMeetingMutation.mutateAsync}
            />
            <Box sx={{ display: activeTab === 0 ? "block" : "none" }}>
              <FollowViolationForm
                formMode="update"
                initialValueReceive={initialViolation}
                nextActionData={getViolationNextActionQuery.data}
                ownRole={ownRole}
                onCancel={() => router.back()}
                onDelete={handleDeleteViolation}
                loading={
                  createViolationQuery?.isPending ||
                  updateViolationQuery?.isPending ||
                  deleteViolationQuery?.isPending
                }
                onSubmit={(data) => {
                  if (!id) {
                    createViolationQuery.mutate({
                      ...data,
                      isDraft: !!data?.isDraft,
                    });
                  }

                  updateViolationQuery.mutate({
                    request: {
                      ...data,
                      isDraft: !!data?.isDraft,
                    },
                    id: typeof id == "string" ? Number(id) : Number(id?.[0]),
                  });
                }}
              />
            </Box>

            <Box sx={{ display: activeTab === 1 ? "block" : "none" }}>
              <NextActionForm
                onCancel={() => router.back()}
                nextActionData={getViolationNextActionQuery.data}
                ownRole={ownRole}
              />
            </Box>
            {initialViolation?.id && (
              <ViolationDetailTabs
                ownRole={ownRole}
                ref={tabRef}
                containerHeight={size.height}
                violationId={initialViolation.id}
                violation={initialViolation}
              />
            )}
          </Box>
        </Stack>
      </ViolationLayoutDetail>

      {popupVisibleState?.[FollowViolationActionsBtnKey.SEND_MAIL] && (
        <SendMailFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.SEND_MAIL, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.SEND_MAIL]}
          followViolationId={initialViolation?.id}
          followViolation={initialViolation}
          name={initialViolation?.name}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FORWARD] && (
        <ForwardFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FORWARD, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FORWARD]}
          violationId={initialViolation?.id}
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
          answerDate={initialViolation?.answerDate}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK] && (
        <FeedBackFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FEEDBACK, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK]}
          violationId={initialViolation?.id}
          name={initialViolation?.name}
          sender={appContext?.me}
          answerDate={initialViolation?.answerDate}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.SHARE,
              state,
              reload
            )
          }
          isOpen={true}
          owner={initialViolation?.createdBy}
          pics={initialViolation?.responsibleUsers}
          initialValue={{
            legalAccessType: initialViolation?.legalAccessType,
            sharedDepartments: initialViolation?.sharedDepartments,
            sharedUsers: initialViolation?.sharedUsers,
          }}
          onSubmit={async (data: any) => {
            const params = {
              id: initialViolation?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL] && (
        <RequestAddInfoFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.REQUEST_ADDITIONAL,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_ADDITIONAL]
          }
          violationId={initialViolation?.id}
          name={initialViolation?.name}
          sender={appContext?.me}
          answerDate={initialViolation?.answerDate || ""}
          createBy={initialViolation?.createdBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ASSIGNMENT] && (
        <AssignmentFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.ASSIGNMENT, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.ASSIGNMENT]}
          violationId={initialViolation?.id}
          violation={initialViolation}
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_VENDOR] && (
        <RequestVendorFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.REQUEST_VENDOR,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.REQUEST_VENDOR]
          }
          violationId={initialViolation?.id}
          violation={initialViolation}
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
        />
      )}

      {popupVisibleState?.[
        FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST
      ] && (
        <TimeExtensionFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST,
              state
            )
          }
          violationId={initialViolation?.id}
          isOpen={
            popupVisibleState?.[
              FollowViolationActionsBtnKey.TIME_EXTENSION_REQUEST
            ]
          }
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_LC] && (
        <FeedBackLcFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FEEDBACK_LC, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_LC]}
          violationId={initialViolation?.id}
          name={initialViolation?.name}
          receiverUsers={initialViolation?.receiverUsers}
          sender={appContext?.me}
          initialValue={{}}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE_FINISHED] && (
        <AdviceFinishedFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.ADVICE_FINISHED,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE_FINISHED]
          }
          violationId={initialViolation?.id}
          name={initialViolation?.name}
          sender={appContext?.me}
          initialValue={{
            users: initialViolation?.receiverUsers,
          }}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE] && (
        <AdviceFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.ADVICE, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE]}
          violationId={initialViolation?.id}
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
          isAdvice
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE] &&
        Array.isArray(
          initialViolation?.lastActionAndRole?.userLastActionAndRoleList
        ) &&
        initialViolation?.lastActionAndRole?.userLastActionAndRoleList.some(
          (item: any) =>
            item?.role ===
            FollowViolationUserRole.get(FollowViolationUserRoleKey.SUPERVISOR)
        ) && (
          <AdviceFollowViolationForm
            setIsOpen={(state) =>
              changePopupVisible(FollowViolationActionsBtnKey.ADVICE, state)
            }
            isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.ADVICE]}
            violationId={initialViolation?.id}
            name={initialViolation?.name}
            sender={appContext?.me}
            createBy={initialViolation?.createdBy}
            isSuperviorAdvisor
          />
        )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_ADVICE] && (
        <AdviceFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.FEEDBACK_ADVICE,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.FEEDBACK_ADVICE]
          }
          violationId={initialViolation?.id}
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
          isFeedBackAdvice
        />
      )}

      {popupVisibleState?.[
        FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION
      ] && (
        <FeedBackNextActionFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION,
              state
            )
          }
          isOpen={
            popupVisibleState?.[
              FollowViolationActionsBtnKey.FEEDBACK_NEXT_ACTION
            ]
          }
          violationId={initialViolation?.id}
          initialValue={{}}
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION] && (
        <TrackNextActionFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(
              FollowViolationActionsBtnKey.TRACK_NEXT_ACTION,
              state
            )
          }
          isOpen={
            popupVisibleState?.[FollowViolationActionsBtnKey.TRACK_NEXT_ACTION]
          }
          violationId={initialViolation?.id}
          initialValue={{}}
          name={initialViolation?.name}
          sender={appContext?.me}
          createBy={initialViolation?.createdBy}
          receiverUsers={initialViolation?.receiverUsers}
        />
      )}

      {popupVisibleState?.[FollowViolationActionsBtnKey.FINISH] && (
        <FinishFollowViolationForm
          setIsOpen={(state) =>
            changePopupVisible(FollowViolationActionsBtnKey.FINISH, state)
          }
          isOpen={popupVisibleState?.[FollowViolationActionsBtnKey.FINISH]}
          violationId={initialViolation?.id}
          initialValue={{}}
          name={initialViolation?.name}
          sender={appContext?.me}
        />
      )}
    </DashboardLayout>
  );
};

export default FollowViolationDetailPage;
