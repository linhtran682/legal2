import { createUser } from "@/apis/service/user/User";
import DashboardLayout from "@/components/layouts";
import { UI_PATH, USER_ROOT_PATH } from "@/constants/paths";
import { SaveUserForm } from "@/features/user/save_user_form/SaveUserForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateAssignmentPage() {
  const router = useRouter();
  const [t] = useTranslation();

  const createUserQuery = useMutation({
    mutationFn: createUser,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.user"),
        })
      );
      router.push(`/${USER_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return <DashboardLayout>
    <SaveUserForm
      formMode='create'
      onSubmit={(data) =>
        createUserQuery.mutate(data)
      }
      onCancel={() => router.back()}
    />
  </DashboardLayout>
}