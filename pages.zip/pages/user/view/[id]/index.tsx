import { getUser } from "@/apis/service/user/User";
import DashboardLayout from "@/components/layouts";
import { UI_PATH, USER_ROOT_PATH } from "@/constants/paths";
import { ViewUserPanel } from "@/features/user/view_user_panel/ViewUserPanel";
import { UserProfileDTO } from "@/models/user/User";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

export default function UserView() {
  const router = useRouter();
  const id =
    typeof router.query.id == "string"
      ? router.query.id
      : (router.query.id || [])[0];

  const [user, setUser] = useState<UserProfileDTO | undefined>(undefined);

  const getStatusQuery = useQuery({
    queryKey: ["get_initial_status"],
    queryFn: () => getUser(id),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getStatusQuery.refetch().then((response) => {
        setUser(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  return (
    <DashboardLayout>
      <ViewUserPanel
        user={user}
        onUpdate={() =>
          router.push(`/${USER_ROOT_PATH}/${UI_PATH.UPDATE}/${id}`)
        }
        loading={false}
      />
    </DashboardLayout>
  );
}
