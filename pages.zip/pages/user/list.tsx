import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { UI_PATH, USER_ROOT_PATH } from "@/constants/paths";
import { useAppContext } from "@/context/AppContext";
import { UsersTable } from "@/features/user/users_table/UsersTable";
import { useRouter } from "next/navigation";

export default function UsersPage() {
  const router = useRouter();
  const appContext = useAppContext();
  return (
    <DashboardLayout>
      <UsersTable />
      {appContext.meCanWrite &&
        <StickyAddButton
          ariaLabel='add_document_type'
          onClick={() =>
            router.push(`/${USER_ROOT_PATH}/${UI_PATH.CREATE}`)
          }
        />
      }
    </DashboardLayout>
  );
}
