import { getUser, updateUser } from "@/apis/service/user/User";
import DashboardLayout from "@/components/layouts";
import { UI_PATH, USER_ROOT_PATH } from "@/constants/paths";
import { SaveUserForm } from "@/features/user/save_user_form/SaveUserForm";
import { UserProfileDTO } from "@/models/user/User";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function UpdateUserPage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id =
    typeof router.query.id == "string"
      ? router.query.id
      : (router.query.id || [])[0];

  const [initialUser, setInitialUser] = useState<UserProfileDTO | undefined>(
    undefined
  );

  const getUserProfileQuery = useQuery({
    queryKey: ["get_initial_status"],
    queryFn: () => getUser(id),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getUserProfileQuery.refetch().then((response) => {
        setInitialUser(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateUserQuery = useMutation({
    mutationFn: updateUser,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.user"),
        })
      );
      router.push(`/${USER_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveUserForm
        formMode='update'
        initialValue={initialUser}
        onSubmit={(data) =>
          id &&
          updateUserQuery.mutate({
            request: data,
            id: id,
          })
        }
        onCancel={() => router.back()}
        userId={id}
      />
    </DashboardLayout>
  );
}
