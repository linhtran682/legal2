import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { DOCUMENT_REVIEW_ROOT_PATH, UI_PATH } from "@/constants/paths";
import DocumentReviewTable from "@/features/document-review/document-review-table/DocumentReviewTable";
import { useRouter } from "next/router";

export default function DocumentReviewListPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <DocumentReviewTable />
      <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${DOCUMENT_REVIEW_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
