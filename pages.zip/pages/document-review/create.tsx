import { createDocumentReview } from '@/apis/service/document-review/documentReview';
import DashboardLayout from '@/components/layouts';
import { DOCUMENT_REVIEW_ROOT_PATH, UI_PATH } from '@/constants/paths';
import DocumentReviewForm from '@/features/document-review/document-review-form/DocumentReviewForm';
import { useMutation } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';

const DocumentReviewCreatePage = () => {

  const [t] = useTranslation();
  const router = useRouter();

  const createDocumentReviewQuery = useMutation({
    mutationFn: createDocumentReview,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.documentReviewRequest"),
        })
      );
      router.push(`/${DOCUMENT_REVIEW_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  return (
    <DashboardLayout>
      <DocumentReviewForm
        formMode='create'
        onSubmit={createDocumentReviewQuery.mutate}
        onSubmitDraft={createDocumentReviewQuery.mutate}
        onCancel={() => router.back()}
        loading={createDocumentReviewQuery?.isPending}
      />
    </DashboardLayout>
  )
}

export default DocumentReviewCreatePage