import { cloneDocumentReviewRequestFn, confirmDocumentReviewMutationFn, createDocumentReview, getDocumentReviewById, recallDocumentReviewFn, shareDocumentReviewFn, updateBookMeeting, updateDocumentReview } from '@/apis/service/document-review/documentReview';
import { callToEsign, cloneLcsFn, confirmLcs, createLcs, getLcsById, recallLcs, recallTobeSign, updateLcs, uploadCurrentFileToSharepoint } from '@/apis/service/document-review/legalCheckSheet';
import { getStatusList } from '@/apis/service/status/Status';
import IconRecheck from '@/assets/iconMenu/IconRecheck';
import { ConfirmPopup, ConfirmPopupProps, DefaultConfirmPopupState } from '@/components/commons/popups/confirm_popup/ConfirmPopup';
import SharePopup from '@/components/commons/share_popup/SharePopup';
import { StatusBadge } from '@/components/commons/status_badge/StatusBadge';
import DashboardLayout from '@/components/layouts';
import Breadcrumb from '@/components/layouts/BreadCrumbs';
import { URL_OUTLOOK } from '@/constants/constraint';
import { ModuleFields } from '@/constants/general';
import { DOCUMENT_REVIEW_ROOT_PATH, UI_PATH } from '@/constants/paths';
import { AppContext } from '@/context/AppContext';
import { INSPECTION_LIST_QUERY_KEY } from '@/features/document-review/document-review-form-list/ReviewList';
import DocumentReviewForm, { DocumentReviewFormRef } from '@/features/document-review/document-review-form/DocumentReviewForm';
import DocumentReviewTabs, { DocumentReviewTabsRef } from '@/features/document-review/document-review-tabs/DocumentReviewTabs';
import { DocumentReviewActions } from '@/features/document-review/document_review_actions/DocumentReviewActions';
import { AssignmentDocumentReviewForm } from '@/features/document-review/form_assignment/AssignmentDocumentReviewForm';
import { DocumentReviewConductionForm } from '@/features/document-review/form_document_review_conduction/DocumentReviewConductionForm';
import { DocumentReviewConductionFeedbackForm } from '@/features/document-review/form_document_review_conduction_feedback/DocumentReviewConductionFeedbackForm';
import { DocumentReviewConductionSupervisorForm } from '@/features/document-review/form_document_review_conduction_supervisor/DocumentReviewConductionSupervisorForm';
import EvaluateForm from '@/features/document-review/form_evaluate/EvaluateForm';
import EvaluateFeedbackForm from '@/features/document-review/form_evaluate_feedback/EvaluateFeedbackForm';
import { FeedbackGeneralForm } from '@/features/document-review/form_feedback/FeedbackGeneralForm';
import FeedbackLcForm from '@/features/document-review/form_feedback_lc/FeedbackLcForm';
import FinishForm from '@/features/document-review/form_finish/FinishForm';
import FinishReviewForm from '@/features/document-review/form_finish_review/FinishReviewForm';
import { ForwardDocumentReviewForm } from '@/features/document-review/form_forward_document_review/ForwardDocumentReviewForm';
import { RequestAdditionalForm } from '@/features/document-review/form_request_additional_information/RequestAdditionalForm';
import RequestEvaluateForm from '@/features/document-review/form_request_evaluate/RequestEvaluateForm';
import { RequestVendorReviewForm } from '@/features/document-review/form_request_vendor_review/RequestVendorReviewForm';
import SendMailForm from '@/features/document-review/form_send_mail/SendMailForm';
import SignApproveForm from '@/features/document-review/form_sign/SignApproveForm';
import RequestSignApproveFrom from '@/features/document-review/form_sign/SignForm';
import { TimeExtensionDocumentReviewForm } from '@/features/document-review/form_time_extension/TimeExtensionDocumentReviewForm';
import { DocumentReviewDetailLayout } from '@/features/document-review/layout/DocumentReviewDetailLayout';
import LegalCheckSheetForm from '@/features/document-review/legal-check-sheet-form/LegalCheckSheetForm';
import LcsActions from '@/features/document-review/legal_check_sheet_actions/LcsActions';
import OverviewHeader from '@/features/document-review/overview_header/OverviewHeader';
import { DocumentReviewBodyReceive, DocumentReviewBodySend, DocumentReviewStatusList, LcsStatusLabels } from '@/models/document-review/DocumentReviewDetail';
import { DocumentReviewActionBtnKey } from '@/models/document-review/DocumentReviewList';
import { StatusDTO, StatusFieldNames } from '@/models/status/Status';
import { BasedUser } from '@/models/user/User';
import { Box, CircularProgress, Stack, Tab, Tabs, Tooltip, Typography } from '@mui/material';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/router';
import { useContext, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';

type TabItemType = {
  label: string;
  key: 'document' | 'lcs'
}

const TabItems: TabItemType[] = [
  {
    label: "DOCUMENT_REVIEW.labels.documentInfo",
    key: 'document'
  },
  {
    label: "Legal check sheet",
    key: "lcs"
  }
]

// const recheckBtnSx = {
//   height: "36px",
//   padding: "4px 12px",
//   fontSize: '14px',
//   alignItems: 'center',
//   whiteSpace: 'nowrap',
//   width: "fit-content",
//   mr: 1,
//   mb: 1
// }

const DocumentReviewDetailPage = () => {

  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;
  const routeAction = router.query.action;
  const routeLcsAction = router.query.lcsAction;
  const [activeTab, setActiveTab] = useState(0);
  const appContext = useContext(AppContext);
  const [ownRole, setOwnRole] = useState<number[]>([]);
  const [initialDocumentReview, setInitialDocumentReview] = useState<
    DocumentReviewBodyReceive | undefined
  >(undefined);
  const queryClient = useQueryClient();
  const [confirmPopupState, setConfirmPopupState] = useState<ConfirmPopupProps>(
    () => DefaultConfirmPopupState
  );

  const drrFormRef = useRef<DocumentReviewFormRef>(null);
  // list of files to upload to sharepoint
  const [uploadIds, setUploadIds] = useState<number[]>([]);

  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const tabRef = useRef<DocumentReviewTabsRef>(null);

  const scrollToTab = (tab: number) => {
    tabRef?.current?.scrollToTab(tab)
  }


  const getDocumentReviewQuery = useQuery({
    queryKey: ["get_initial_document_review"],
    queryFn: () =>
      getDocumentReviewById(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: false,
  });
  const getLcsQuery = useQuery({
    queryKey: ["get_initial_lcs", initialDocumentReview?.lcsId],
    queryFn: () =>
      getLcsById(initialDocumentReview?.lcsId as number),
    enabled: initialDocumentReview?.lcsId !== undefined && initialDocumentReview?.lcsId !== null,
  });

  const createDocumentReviewQuery = useMutation({
    mutationFn: createDocumentReview,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.documentReviewRequest"),
        })
      );
      router.push(`/${DOCUMENT_REVIEW_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const createLcsQuery = useMutation({
    mutationFn: createLcs,
    onSuccess: async () => {
      // upload current
      // initialDocumentReview
      if (uploadIds?.length) {
        try {
          for (const uploadId of uploadIds) {
            await uploadCurrentFileToSharepoint({
              fileId: uploadId,
              lcsId: initialDocumentReview?.id as number
            });
          }
          setUploadIds([]);
        } catch (error) {
        }
      }
      toast.success(
        t("common.message.create_success", {
          recordName: t("Legal check sheet"),
        })
      );
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });
  const updateLcsQuery = useMutation({
    mutationFn: updateLcs,
    onSuccess: async () => {
      if (uploadIds?.length) {
        try {
          for (const uploadId of uploadIds) {
            await uploadCurrentFileToSharepoint({
              fileId: uploadId,
              lcsId: initialDocumentReview?.id as number
            });
          }
          setUploadIds([]);
        } catch (error) {
        }
      }
      toast.success(
        t("common.message.update_success", {
          recordName: t("Legal check sheet"),
        })
      );
      getLcsQuery.refetch();
    },
  });
  const updateLcsSilentQuery = useMutation({
    mutationFn: updateLcs,
    onSuccess: async () => {
      if (uploadIds?.length) {
        try {
          for (const uploadId of uploadIds) {
            await uploadCurrentFileToSharepoint({
              fileId: uploadId,
              lcsId: initialDocumentReview?.id as number
            });
          }
          setUploadIds([]);
        } catch (error) {
        }
      }
      getLcsQuery.refetch();
    },
  });
  const callToEsignMutation = useMutation({
    mutationFn: callToEsign,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.createEsignSuccess")
      );
      getLcsQuery.refetch();
    },
    // onError: (error) => {
    //   const errorBody = (error as AxiosError<ResponseWrapper<any>>)
    //     ?.response?.data?.error
    //   toast.error(
    //     t(
    //       // errorBody?.code === 40900200
    //       //   ? 
    //       (errorBody as any)?.message
    //       // : `common.error_code.${errorBody?.code}`
    //     )
    //   );
    // }
  });
  const recallTobeSignMutation = useMutation({
    mutationFn: recallTobeSign,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.recallLcsSuccess")
      );
      getLcsQuery.refetch();
    },
    // onError: (error) => {
    //   const errorBody = (error as AxiosError<ResponseWrapper<any>>)
    //     ?.response?.data?.error
    //   toast.error(
    //     t(
    //       // errorBody?.code === 40900200
    //       (errorBody as any)?.message
    //       // : `common.error_code.${errorBody?.code}`
    //     )
    //   );
    // }
  });

  const updateDocumentReviewQuery = useMutation({
    mutationFn: updateDocumentReview,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.documentReviewRequest"),
        })
      );
      router.push(`/${DOCUMENT_REVIEW_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });




  const handleClick = (type: any) => {
    if (type) {
      router.replace(`/${DOCUMENT_REVIEW_ROOT_PATH}/update/${id}?action=${type}`);
    }
  };
  const handleLcsClick = (type: any) => {
    if (type && initialDocumentReview?.lcsId) {
      router.replace(`/${DOCUMENT_REVIEW_ROOT_PATH}/update/${id}?lcsAction=${type}`);
    }
  };

  const changePopupVisible = (type: any, state: boolean = false, reload = false) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (!state) {
      router.replace(`/${DOCUMENT_REVIEW_ROOT_PATH}/update/${id}`);
    }
    if (reload) {
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
      queryClient.invalidateQueries({
        queryKey: [INSPECTION_LIST_QUERY_KEY]
      })
      initialDocumentReview?.lcsId && getLcsQuery.refetch();
    }
  };

  useEffect(() => {
    if (routeAction || routeLcsAction) {
      changePopupVisible(routeAction ?? routeLcsAction, true);
    } else {
      setPopupVisibleState({});
    }
  }, [routeAction, routeLcsAction]);
  useEffect(() => {
    if (initialDocumentReview?.userLastActionAndRoleResponse?.userLastActionAndRoleList?.length) {
      const { userLastActionAndRoleResponse: { userLastActionAndRoleList } } = initialDocumentReview;
      const roleList = userLastActionAndRoleList?.map((ele) => ele.role)
      setOwnRole(roleList);
    } else {
      setOwnRole([]);
    }
  }, [initialDocumentReview]);

  useEffect(() => {
    setActiveTab(0);
    if (!!id) {
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);

      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);


  const { mutateAsync: recallDrrAsync } = useMutation({
    mutationFn: recallDocumentReviewFn,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.recallDrrSuccess")
      );
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });

  const { mutateAsync: confirmDocumentReview } = useMutation({
    mutationFn: confirmDocumentReviewMutationFn,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.confirmSuccess")
      );
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });
  const { mutateAsync: confirmLcsAsync } = useMutation({
    mutationFn: confirmLcs,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.confirmLcsSuccess")
      );
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });
  const { mutateAsync: recallLcsAsync } = useMutation({
    mutationFn: recallLcs,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.recallLcsSuccess")
      );
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });

  const updateBookMeetingMutation = useMutation({
    mutationFn: updateBookMeeting,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.documentReviewRequest"),
        })
      );
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });

  const checkDisableTab = (tabItem: TabItemType) => {
    if (tabItem.key === 'document') {
      return false;
    }
    if (tabItem.key === 'lcs') {
      if (initialDocumentReview?.isDraft) {
        return true;
      }
      if (!ownRole?.includes(1) && !initialDocumentReview?.lcsId) {
        return true;
      }
      if (ownRole?.includes(1)
        && !initialDocumentReview?.lcsId
        && initialDocumentReview?.status?.name?.trim?.() !== 'Hoàn thành kiểm tra tài liệu') {
        return true;
      }
    }
    return false
  }

  const shareMutation = useMutation({
    mutationFn: shareDocumentReviewFn,
    onSuccess: () => {
      toast.success(
        t(`DOCUMENT_REVIEW.messages.shareSuccess`)
      );
    },
  });
  const cloneMutation = useMutation({
    mutationFn: cloneDocumentReviewRequestFn,
    onSuccess: () => {
      toast.success(
        t(`DOCUMENT_REVIEW.messages.recheckSuccess`)
      );
      setConfirmPopupState(DefaultConfirmPopupState);
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });
  const cloneLcsMutation = useMutation({
    mutationFn: cloneLcsFn,
    onSuccess: () => {
      toast.success(
        t(`DOCUMENT_REVIEW.messages.recheckLcsSuccess`)
      );
      setConfirmPopupState(DefaultConfirmPopupState);
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });

  const getStatusListQuery = useQuery({
    queryKey: ['document-review/get-status-list-all'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.DOCUMENT_REVIEW.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.NAME,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: true
  });

  const handleRecheck = (tab: 0 | 1) => {
    setConfirmPopupState({
      open: true,
      icon: <IconRecheck />,
      title: t(`DOCUMENT_REVIEW.messages.${tab === 0 ? 'confirmRecheck' : 'confirmReSign'}`),
      handleConfirm: () => {
        if (tab === 0) {
          const requestAdviceStatus = getStatusListQuery?.data
            ?.find((ele: StatusDTO) => ele.name === DocumentReviewStatusList.REQUEST_REVIEW
            )

          initialDocumentReview?.id && cloneMutation.mutate({
            id: initialDocumentReview?.id as number,
            data: {
              childStatus: requestAdviceStatus?.id as number,
              status: initialDocumentReview?.status?.id as number
            }
          })
        }
        if (tab === 1) {
          initialDocumentReview?.lcsId && cloneLcsMutation.mutate(initialDocumentReview?.lcsId)
        }
      },
      handleCancel: () =>
        setConfirmPopupState(DefaultConfirmPopupState),
    })
  }

  const { mutateAsync: addInfoFn } = useMutation({
    mutationFn: updateDocumentReview,
    onSuccess: () => {
      toast.success(
        t("DOCUMENT_REVIEW.messages.infoAddedSuccess")
      );
      getDocumentReviewQuery.refetch().then((response) => {
        setInitialDocumentReview(response.data);
      });
    },
  });

  const handleReloadDrrmQuery = async () => {
    getDocumentReviewQuery.refetch().then((response) => {
      setInitialDocumentReview(response.data);
    });
  }

  return (
    <>
      <DashboardLayout hideHeader>
        <DocumentReviewDetailLayout initialValueReceive={initialDocumentReview}>
          <Stack direction={'column'} sx={{ height: '100%' }}>
            <Breadcrumb />
            <Tooltip title={initialDocumentReview?.documentName ?? ""} placement="top-start">
              <Typography variant="h1" sx={{
                fontSize: "24px", mb: 1,
                overflow: "hidden",
                textOverflow: "ellipsis",
                display: "-webkit-box",
                WebkitLineClamp: "1",
                WebkitBoxOrient: "vertical",
                wordBreak: 'break-word',
                width: "fit-content"
              }}>
                {initialDocumentReview?.documentName}
              </Typography>
            </Tooltip>
            {initialDocumentReview
              ? <StatusBadge label={initialDocumentReview?.isDraft
                ? t('common.label.draft')
                : (initialDocumentReview?.lcsStatus
                  ? (LcsStatusLabels as any)?.[initialDocumentReview?.lcsStatus?.toString?.()]
                  : initialDocumentReview?.status?.name as string)} />
              : null}
            <Tabs
              value={activeTab}
              onChange={(_, i) => setActiveTab(i)}
            // variant='scrollable'
            >
              {TabItems.map((tabItem: TabItemType) => (
                <Tab
                  label={<Typography variant='h5'>{t(tabItem.label)}</Typography>}
                  key={tabItem.key}
                  id={`tab-label-${tabItem.key}`}
                  aria-controls={`tab-panel-${tabItem.key}`}
                  sx={{
                    textTransform: "none",
                    // backgroundColor: 'white'
                  }}
                  disabled={checkDisableTab(tabItem)}
                />
              ))}
            </Tabs>
            <Box height={12}></Box>
            {(activeTab === 0 && initialDocumentReview && !initialDocumentReview.isDraft
              // && initialDocumentReview?.status?.name !== DONE_STATUS
            )
              && <DocumentReviewActions
                params={{
                  row: initialDocumentReview,
                }}
                handleClickRecall={async () => initialDocumentReview?.id && await recallDrrAsync(initialDocumentReview?.id)}
                handleClickForWard={() =>
                  handleClick(DocumentReviewActionBtnKey.FORWARD)
                }
                handleClickFeedBack={() =>
                  handleClick(DocumentReviewActionBtnKey.FEEDBACK)
                }
                handleClickRequestMeeting={() => window.open(URL_OUTLOOK, "_blank")}
                handleClickSendMail={() =>
                  handleClick(DocumentReviewActionBtnKey.SEND_MAIL)
                }
                handleClickExtendTime={() => {
                  handleClick(DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST)
                }}
                handleClickConfirm={async () => await confirmDocumentReview(Number(id))}
                handleClickAssignment={() =>
                  handleClick(DocumentReviewActionBtnKey.ASSIGNMENT)
                }
                handleClickRequestVendor={() =>
                  handleClick(DocumentReviewActionBtnKey.REQUEST_VENDOR)
                }
                handleClickFeedbackAdvise={() =>
                  handleClick(DocumentReviewActionBtnKey.FEEDBACK_INSPECTION)
                }
                handleClickRequestAdditional={() =>
                  handleClick(DocumentReviewActionBtnKey.INFORMATION_REQUEST)
                }
                handleClickAdvise={() => handleClick(DocumentReviewActionBtnKey.INSPECTION)}
                handleClickDone={() => handleClick(DocumentReviewActionBtnKey.FINISH)}
                handleClickShare={() => handleClick(DocumentReviewActionBtnKey.SHARE)}
                handleClickRecheck={() => handleRecheck(0)}
                handleClickAddInfo={() => {
                  const params = drrFormRef?.current?.getParams() as DocumentReviewBodySend;
                  params.statusId = getStatusListQuery?.data?.find((ele: StatusDTO) => ele.name === DocumentReviewStatusList.INFORMATION_ADDED)?.id;
                  initialDocumentReview?.id && addInfoFn({
                    id: initialDocumentReview?.id,
                    request: params
                  })

                }}
                isActionDetail
              />}

            {/* {(activeTab === 0 && initialDocumentReview && !initialDocumentReview.isDraft
            && initialDocumentReview?.status?.name === DONE_STATUS
            && ownRole.includes(1)
          ) && <Button
            key={'recheck_lcs'}
            onClick={() => handleRecheck(0)}
            sx={recheckBtnSx}
            variant='contained'
            className="confirm"
          >{t(`DOCUMENT_REVIEW.button.recheckReview`)}</Button>} */}
            {
              (activeTab === 1
                && getLcsQuery?.data
                && initialDocumentReview
                && !initialDocumentReview.isDraft
                // && initialDocumentReview?.status?.name !== DONE_STATUS
              ) && <LcsActions
                drrmRoles={ownRole}
                documentReview={initialDocumentReview}
                legalCheckSheet={getLcsQuery?.data}
                handleClickAssignment={() => { handleLcsClick(DocumentReviewActionBtnKey.ASSIGNMENT) }}
                handleClickConfirm={async () => { initialDocumentReview?.lcsId && (await confirmLcsAsync(initialDocumentReview?.lcsId)) }}
                handleClickEvaluate={() => { handleLcsClick(DocumentReviewActionBtnKey.EVALUATE) }}
                handleClickFeedback={() => { handleLcsClick(DocumentReviewActionBtnKey.FEEDBACK) }}
                handleClickFeedbackEvaluate={() => { handleLcsClick(DocumentReviewActionBtnKey.FEEDBACK_EVALUATE) }}
                handleClickFeedbackLc={() => { handleLcsClick(DocumentReviewActionBtnKey.FEEDBACK_LC) }}
                handleClickFinish={() => { handleLcsClick(DocumentReviewActionBtnKey.FINISH) }}
                handleClickForward={() => { handleLcsClick(DocumentReviewActionBtnKey.FORWARD) }}
                handleClickInformationRequest={() => { handleLcsClick(DocumentReviewActionBtnKey.INFORMATION_REQUEST) }}
                handleClickRecall={async () => { initialDocumentReview?.lcsId && (await recallLcsAsync(initialDocumentReview?.lcsId)) }}
                handleClickRequestEvaluate={() => { handleLcsClick(DocumentReviewActionBtnKey.REQUEST_EVALUATE) }}
                handleClickRequestMeeting={() => { window.open(URL_OUTLOOK, "_blank") }}
                handleClickRequestSign={() => { handleLcsClick(DocumentReviewActionBtnKey.REQUEST_SIGN) }}
                handleClickSendMail={() => { handleLcsClick(DocumentReviewActionBtnKey.SEND_MAIL) }}
                handleClickSignApprove={() => { handleLcsClick(DocumentReviewActionBtnKey.SIGN_AND_APPROVE) }}
                handleClickTimeExtensionRequest={() => { handleLcsClick(DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST) }}
                handleClickRecheck={() => handleRecheck(1)}
                handleClickShare={() => handleClick(DocumentReviewActionBtnKey.SHARE)}
              />
            }

            {/* {(activeTab === 1
            && getLcsQuery?.data
            && initialDocumentReview
            && !initialDocumentReview.isDraft
            && initialDocumentReview?.status?.name === DONE_STATUS
            && ownRole.includes(1)
          ) && <Button
            key={'recheck_lcs'}
            onClick={() => handleRecheck(1)}
            sx={recheckBtnSx}
            variant='contained'
            className="confirm"
          >{t(`DOCUMENT_REVIEW.button.recheckLcs`)}</Button>} */}
            <Box sx={{ flex: 1, overflowY: 'auto' }}>
              <OverviewHeader
                scrollToTab={scrollToTab}
                initialValueReceive={initialDocumentReview}
                handleUpdateBookMeeting={updateBookMeetingMutation.mutateAsync}
                isLoading={updateBookMeetingMutation.isPending
                  || getDocumentReviewQuery.isFetching
                }
              />
              <Box sx={{ display: activeTab === 0 ? 'block' : 'none' }}>
                <DocumentReviewForm
                  ref={drrFormRef}
                  formMode="update"
                  initialValueReceive={initialDocumentReview}
                  onCancel={() => router.back()}
                  loading={createDocumentReviewQuery?.isPending || updateDocumentReviewQuery?.isPending}
                  onSubmitDraft={(data) => {
                    if (id) {
                      updateDocumentReviewQuery.mutate({
                        request: data,
                        id: typeof id == "string" ? Number(id) : Number(id[0]),
                      });
                    }
                  }}
                  onSubmit={(data) => {
                    if (id && initialDocumentReview?.isDraft) {
                      createDocumentReviewQuery.mutate({
                        ...data,
                        isDraft: false,
                        documentReviewId: initialDocumentReview.id,
                      });
                    }
                    if (id && !initialDocumentReview?.isDraft) {
                      updateDocumentReviewQuery.mutate({
                        request: data,
                        id: typeof id == "string" ? Number(id) : Number(id[0]),
                      });
                    }
                  }}
                />
              </Box>
              {activeTab === 1 ? <LegalCheckSheetForm
                canCreate={ownRole.includes(1)}
                drrmRoles={ownRole}
                formMode={initialDocumentReview?.lcsId ? 'update' : 'create'}
                initialValueReceive={initialDocumentReview}
                initialLcs={getLcsQuery?.data}
                onUpdate={updateLcsQuery.mutateAsync}
                onUpdateSilent={updateLcsSilentQuery.mutateAsync}
                onSubmit={createLcsQuery.mutate}
                onCancel={() => router.back()}
                loading={createLcsQuery?.isPending
                  || updateLcsQuery?.isPending
                  || getDocumentReviewQuery?.isFetching
                  || getLcsQuery?.isFetching}
                onCallToEsign={callToEsignMutation.mutateAsync}
                onRecallCheckSheet={recallTobeSignMutation.mutateAsync}
                setUploadIds={setUploadIds}
              /> : null}


              {(activeTab === 0 && initialDocumentReview?.id)
                || (activeTab === 1 && initialDocumentReview?.lcsId)
                ? <Box mt={2}>
                  <DocumentReviewTabs
                    ref={tabRef}
                    handleReloadDrrmQuery={handleReloadDrrmQuery}
                    documentReviewId={initialDocumentReview?.id}
                    documentReview={initialDocumentReview}
                    activeTab={activeTab}
                  />
                </Box>
                : null}
            </Box>
          </Stack>
        </DocumentReviewDetailLayout>

        <ConfirmPopup {...confirmPopupState} />

        {popupVisibleState?.[DocumentReviewActionBtnKey.SHARE] && <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialDocumentReview?.pic}
          // pics={initialDocumentReview?.responsibleUsers}
          pics={[]}
          onSubmit={async (data: any) => {
            const params = {
              id: initialDocumentReview?.id as number,
              data
            }
            await shareMutation.mutateAsync(params)
          }}
          initialValue={{
            legalAccessType: initialDocumentReview?.legalAccessType,
            sharedDepartments: initialDocumentReview?.sharedDepartments,
            sharedUsers: initialDocumentReview?.sharedUsers
          }}
        />}

        {/* Send mail - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.SEND_MAIL] && <SendMailForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.SEND_MAIL]}
          name={initialDocumentReview?.documentName}
          documentReviewId={initialDocumentReview?.id}
          lcsId={initialDocumentReview?.lcsId}
          isLcs={!!routeLcsAction}
          senderDocumentManagement={appContext?.me}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.SEND_MAIL, state, reload)
          }
        />}
        {/* Phân công - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.ASSIGNMENT] && <AssignmentDocumentReviewForm
          documentReviewId={initialDocumentReview?.id}
          senderDocumentManagement={appContext?.me}
          name={initialDocumentReview?.documentName}
          lcsId={initialDocumentReview?.lcsId}
          isLcs={!!routeLcsAction}
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.ASSIGNMENT]}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.ASSIGNMENT, state, reload)
          }
          documentReview={!!routeLcsAction ? undefined : initialDocumentReview}
        />}

        {/* Chuyển tiếp - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.FORWARD] && <ForwardDocumentReviewForm
          name={initialDocumentReview?.documentName}
          documentReviewId={initialDocumentReview?.id}
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FORWARD]}
          setIsOpen={(state) =>
            changePopupVisible(DocumentReviewActionBtnKey.FORWARD, state, false)
          }
          initialValue={{
            deadline: initialDocumentReview?.responseDate
          }}
          lcsId={initialDocumentReview?.lcsId}
          isLcs={!!routeLcsAction}
          senderDocumentManagement={appContext?.me}
        />}

        {/* Hoàn thành KTTL - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.FINISH] && (!!routeAction && !routeLcsAction) && <FinishReviewForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FINISH]}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.FINISH, state, reload)
          }
          documentReviewId={initialDocumentReview?.id}
          name={initialDocumentReview?.documentName}
          sender={appContext?.me}
          initialValues={{
            userIds: [
              ...(initialDocumentReview?.receiverUsers ?? [])
            ]
          }}
        />}

        {/* YC bổ sung thtin - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.INFORMATION_REQUEST] && <RequestAdditionalForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.INFORMATION_REQUEST]}
          documentReviewId={initialDocumentReview?.id}
          name={initialDocumentReview?.documentName}
          senderDocumentManagement={appContext?.me}
          lcsId={initialDocumentReview?.lcsId}
          isLcs={!!routeLcsAction}
          initialValue={{
            userIds: [initialDocumentReview?.pic]
          }}
          maxDate={initialDocumentReview?.responseDate}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.INFORMATION_REQUEST, state, reload)
          } />}

        {/* YC gia hạn thgian - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST] && <TimeExtensionDocumentReviewForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST]}
          documentReviewId={initialDocumentReview?.id}
          name={initialDocumentReview?.documentName}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            users: [initialDocumentReview?.pic],
          }}
          lcsId={initialDocumentReview?.lcsId}
          isLcs={!!routeLcsAction}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.TIME_EXTENSION_REQUEST, state, reload)
          } />}

        {/* Kiểm tra  - API done */}
        {(popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !initialDocumentReview?.isSupervisor) && <DocumentReviewConductionForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !initialDocumentReview?.isSupervisor}
          name={initialDocumentReview?.documentName}
          documentReviewId={initialDocumentReview?.id}
          senderDocumentManagement={appContext?.me}
          refetchQueryKeys={[INSPECTION_LIST_QUERY_KEY]}
          initialDocumentReview={initialDocumentReview}
          inspectionId={initialDocumentReview?.inspectionId}
          initialValue={{
            userIds: [initialDocumentReview?.pic]
          }}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.INSPECTION, state, reload)
          } />}
        {/* Phản hồi kiểm tra - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_INSPECTION] &&
          <DocumentReviewConductionFeedbackForm
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_INSPECTION]}
            isFeedBack
            documentReviewId={initialDocumentReview?.id}
            name={initialDocumentReview?.documentName}
            senderDocumentManagement={appContext?.me}
            initialValue={{
              deadlineNew: initialDocumentReview?.responseDate ?
                new Date(initialDocumentReview?.responseDate) : null
            }}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.FEEDBACK_INSPECTION, state, reload)
            } />}
        {/* Supervisor kiểm tra */}
        {(popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !!initialDocumentReview?.isSupervisor) && <DocumentReviewConductionSupervisorForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.INSPECTION] && !!initialDocumentReview?.isSupervisor}
          documentReviewId={initialDocumentReview?.id}
          name={initialDocumentReview?.documentName}
          senderDocumentManagement={appContext?.me}
          initialDocumentReview={initialDocumentReview}
          inspectionId={initialDocumentReview?.inspectionId}
          initialValue={{
            userIds: [initialDocumentReview?.pic]
          }}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.INSPECTION, state, reload)
          } />}

        {/* YC vendor kiểm tra - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.REQUEST_VENDOR] && <RequestVendorReviewForm
          isOpen
          name={initialDocumentReview?.documentName}
          documentReviewId={initialDocumentReview?.id}
          senderDocumentManagement={appContext?.me}
          initialValue={{
            userIds: [
              initialDocumentReview?.pic as BasedUser,
              appContext?.me as BasedUser,
            ]
          }}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.REQUEST_VENDOR, state, reload)
          } />}
        {/* Phản hồi văn bản - API 500 */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK] && <FeedbackGeneralForm
          isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK]}
          name={initialDocumentReview?.documentName}
          documentReviewId={initialDocumentReview?.id}
          senderDocumentManagement={appContext?.me}
          setIsOpen={(state, reload) =>
            changePopupVisible(DocumentReviewActionBtnKey.FEEDBACK, state, reload)
          }
          initialValue={{
            deadline: initialDocumentReview?.responseDate
          }}
          lcsId={initialDocumentReview?.id}
          isLcs={!!routeLcsAction}
        />}


        {/* Cụm popup của riêng LCS */}

        {/* Yêu cầu đánh giá - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.REQUEST_EVALUATE] && (
          <RequestEvaluateForm
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.REQUEST_EVALUATE]}
            documentReviewId={initialDocumentReview?.id}
            name={initialDocumentReview?.documentName}
            lcsId={initialDocumentReview?.lcsId}
            sender={appContext?.me}
            legalCheckSheet={getLcsQuery?.data}
            // documentReview={initialDocumentReview}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.REQUEST_EVALUATE, state, reload)
            }
          />)}
        {/* Đánh giá  - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.EVALUATE] &&
          <EvaluateForm
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.EVALUATE]}
            documentReviewId={initialDocumentReview?.id}
            name={initialDocumentReview?.documentName}
            lcsId={initialDocumentReview?.lcsId}
            sender={appContext?.me}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.EVALUATE, state, reload)
            }
            initialValues={{
              userIds: [initialDocumentReview?.pic]
            }}
          />}
        {/* Phản hồi đánh giá -  */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_EVALUATE] &&
          <EvaluateFeedbackForm
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_EVALUATE]}
            documentReviewId={initialDocumentReview?.id}
            name={initialDocumentReview?.documentName}
            lcsId={initialDocumentReview?.lcsId}
            sender={appContext?.me}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.FEEDBACK_EVALUATE, state, reload)
            }
            initialValues={{
              userIds: [initialDocumentReview?.pic]
            }}
          />
        }

        {/* Yêu cầu signer ký - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.REQUEST_SIGN] && (
          <RequestSignApproveFrom
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.REQUEST_SIGN]}
            documentReviewId={initialDocumentReview?.id}
            name={initialDocumentReview?.documentName}
            lcsId={initialDocumentReview?.lcsId}
            sender={appContext?.me}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.REQUEST_SIGN, state, reload)
            } />)}

        {/*  Ký duyệt - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.SIGN_AND_APPROVE] && (
          <SignApproveForm
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.SIGN_AND_APPROVE]}
            documentReviewId={initialDocumentReview?.id}
            name={initialDocumentReview?.documentName}
            lcsId={initialDocumentReview?.lcsId}
            sender={initialDocumentReview?.pic}
            initialValues={{
              userIds: [initialDocumentReview?.pic]
            }}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.SIGN_AND_APPROVE, state, reload)
            } />)}

        {/* Phản hồi L&C - API done */}
        {popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_LC] &&
          <FeedbackLcForm
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FEEDBACK_LC]}
            sender={appContext?.me}
            name={initialDocumentReview?.documentName}
            lcsId={initialDocumentReview?.lcsId}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.FEEDBACK_LC, state, reload)
            }
            initialValues={{
              userIds: [
                ...(getLcsQuery?.data?.evaluateUsers ?? []),
                ...(getLcsQuery?.data?.assignmentUsers ?? []),
              ]
            }}
          />}

        {/* Hoàn thành - API done */}
        {(popupVisibleState?.[DocumentReviewActionBtnKey.FINISH] && !!routeLcsAction && !routeAction)
          && <FinishForm
            isOpen={popupVisibleState?.[DocumentReviewActionBtnKey.FINISH]}
            lcsId={initialDocumentReview?.lcsId}
            sender={appContext?.me}
            name={initialDocumentReview?.documentName}
            documentReviewId={initialDocumentReview?.id}
            initialValues={{
              userIds: [...(getLcsQuery?.data?.evaluateUsers ?? []), ...(getLcsQuery?.data?.assignmentUsers ?? [])],

            }}
            setIsOpen={(state, reload) =>
              changePopupVisible(DocumentReviewActionBtnKey.FINISH, state, reload)
            }
          />}
      </DashboardLayout>
      {appContext?.isCallingEsign && activeTab === 1 ? <Box sx={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <CircularProgress />
      </Box> : null}
    </>
  )
}

export default DocumentReviewDetailPage