import DashboardLayout from '@/components/layouts'
import DocumentReviewReport from '@/features/statistics-document-review/document-review-report/DocumentReviewReport'

const DocumentReviewReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentReviewReport />
    </DashboardLayout>
  )
}

export default DocumentReviewReportPage