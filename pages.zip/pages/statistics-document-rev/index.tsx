import DashboardLayout from "@/components/layouts";
import DocumentReviewOverview from "@/features/statistics-document-review/document-review-overview/DocumentReviewOverview";
// import { useRouter } from "next/router";

export default function LegalAdviceReport() {
  // const router = useRouter();

  return (
    <DashboardLayout noFooterBtn>
      <DocumentReviewOverview />
    </DashboardLayout>
  );
}
