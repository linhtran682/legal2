import DashboardLayout from '@/components/layouts'
import DocumentReviewReportDone from '@/features/statistics-document-review/document-review-report-done/DocumentReviewReportDone'

const DocumentReviewReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentReviewReportDone />
    </DashboardLayout>
  )
}

export default DocumentReviewReportPage