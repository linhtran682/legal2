import DashboardLayout from '@/components/layouts'
import DocumentReviewReportBackdate from '@/features/statistics-document-review/document-review-report-backdate/DocumentReviewReportBackdate'

const DocumentReviewReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentReviewReportBackdate />
    </DashboardLayout>
  )
}

export default DocumentReviewReportPage