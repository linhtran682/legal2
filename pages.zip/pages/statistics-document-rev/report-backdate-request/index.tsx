import DashboardLayout from '@/components/layouts'
import DocumentReviewReportBackdateRequest from '@/features/statistics-document-review/document-review-report-backdate-request/DocumentReviewReportBackdateRequest'

const DocumentReviewReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentReviewReportBackdateRequest />
    </DashboardLayout>
  )
}

export default DocumentReviewReportPage