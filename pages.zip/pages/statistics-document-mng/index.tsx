import DashboardLayout from "@/components/layouts";
import DocumentManagementOverview from "@/features/statistics-document-mng/document-management-overview/DocumentManagementOverview";
export default function DocumentManagementReport() {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentManagementOverview />
    </DashboardLayout>
  );
}
