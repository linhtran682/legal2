import DashboardLayout from "@/components/layouts";
import DocumentManagementReportForget from "@/features/statistics-document-mng/document-management-report-forget/DocumentManagementReportForget";
import React from "react";

const DocumentManagementReportForgetPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentManagementReportForget />
    </DashboardLayout>
  );
};

export default DocumentManagementReportForgetPage;
