import DashboardLayout from "@/components/layouts";
import DocumentManagementReport from "@/features/statistics-document-mng/document-management-report/DocumentManagementReport";
import React from "react";

const DocumentManagementReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentManagementReport />
    </DashboardLayout>
  );
};

export default DocumentManagementReportPage;
