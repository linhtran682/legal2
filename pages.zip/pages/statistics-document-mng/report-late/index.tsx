import DashboardLayout from "@/components/layouts";
import DocumentManagementReportLate from "@/features/statistics-document-mng/document-management-report-late/DocumentManagementReportLate";
import React from "react";

const DocumentManagementReportLatePage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <DocumentManagementReportLate />
    </DashboardLayout>
  );
};

export default DocumentManagementReportLatePage;
