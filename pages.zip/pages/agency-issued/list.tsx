import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { AGENCY_ISSUED_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AgencyIssuedTable } from "@/features/agency_issued/agency_issued_table/AgencyIssuedTable";
import { useRouter } from "next/navigation";

export default function AgencyIssuedsPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <AgencyIssuedTable />
      <StickyAddButton
        ariaLabel='add_agency_issued'
        onClick={() =>
          router.push(`/${AGENCY_ISSUED_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
