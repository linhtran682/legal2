import { createAgencyIssued } from "@/apis/service/agency_issued/AgencyIssued";
import DashboardLayout from "@/components/layouts";
import { AGENCY_ISSUED_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveAgencyIssuedForm } from "@/features/agency_issued/save_agency_issued_form/SaveAgencyIssuedForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateAgencyIssuedPage() {
  const [t] = useTranslation();
  const router = useRouter();

  const createAgencyIssuedQuery = useMutation({
    mutationFn: createAgencyIssued,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.agencyIssued"),
        })
      );
      router.push(`/${AGENCY_ISSUED_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveAgencyIssuedForm
        formMode='create'
        onSubmit={createAgencyIssuedQuery.mutate}
        onCancel={() => router.back()}
        loading={createAgencyIssuedQuery.isPending}
      />
    </DashboardLayout>
  );
}
