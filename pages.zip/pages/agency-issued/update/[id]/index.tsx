import {
  deleteAgencyIssueds,
  getAgencyIssued,
  updateAgencyIssued,
} from "@/apis/service/agency_issued/AgencyIssued";
import DashboardLayout from "@/components/layouts";
import { AGENCY_ISSUED_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveAgencyIssuedForm } from "@/features/agency_issued/save_agency_issued_form/SaveAgencyIssuedForm";
import { AgencyIssuedDTO } from "@/models/agency_issued/AgencyIssued";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateAgencyIssuedPage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialAgencyIssued, setInitialAgencyIssued] = useState<
    AgencyIssuedDTO | undefined
  >(undefined);

  const getAgencyIssuedQuery = useQuery({
    queryKey: ["get_initial_AgencyIssued"],
    queryFn: () =>
      getAgencyIssued(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getAgencyIssuedQuery
        .refetch()
        .then((response) => {
          setInitialAgencyIssued(response.data);
        })
        .catch((e) => toast.error(JSON.stringify(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateAgencyIssuedQuery = useMutation({
    mutationFn: updateAgencyIssued,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.agencyIssued"),
        })
      );
      router.push(`/${AGENCY_ISSUED_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteAgencyIssuedsQuery = useMutation({
    mutationFn: deleteAgencyIssueds,
    onSuccess: () => {
      t("common.message.delete_success", {
        recordName: t("menu.agencyIssued"),
      });
      router.push(`/${AGENCY_ISSUED_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveAgencyIssuedForm
        formMode='update'
        initialValue={initialAgencyIssued}
        onSubmit={(data) =>
          id &&
          updateAgencyIssuedQuery.mutate({
            request: data,
            id: typeof id == "string" ? Number(id) : Number(id[0]),
          })
        }
        onDelete={() =>
          id &&
          deleteAgencyIssuedsQuery.mutate(
            typeof id == "string" ? [Number(id)] : [Number(id[0])]
          )
        }
        onCancel={() => router.back()}
        loading={
          updateAgencyIssuedQuery.isPending ||
          getAgencyIssuedQuery.isFetching ||
          deleteAgencyIssuedsQuery.isPending
        }
      />
    </DashboardLayout>
  );
}
