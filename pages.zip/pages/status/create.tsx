import { createStatus } from "@/apis/service/status/Status";
import DashboardLayout from "@/components/layouts";
import { STATUS_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveStatusForm } from "@/features/status/save_status_form/SaveStatusForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateStatusPage() {
  const [t] = useTranslation();
  const router = useRouter();

  const createStatusQuery = useMutation({
    mutationFn: createStatus,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.status"),
        })
      );
      router.push(`/${STATUS_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveStatusForm
        formMode='create'
        onSubmit={createStatusQuery.mutate}
        onCancel={() => router.back()}
        loading={createStatusQuery.isPending}
      />
    </DashboardLayout>
  );
}
