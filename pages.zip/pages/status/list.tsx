import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { STATUS_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { StatusTable } from "@/features/status/status_table/StatusTable";
import { useRouter } from "next/navigation";

export default function StatusListPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <StatusTable />
      <StickyAddButton
        ariaLabel='add_status'
        onClick={() => router.push(`/${STATUS_ROOT_PATH}/${UI_PATH.CREATE}`)}
      />
    </DashboardLayout>
  );
}
