import { ResponseWrapper } from "@/apis";
import {
  deleteStatusList,
  getStatus,
  updateStatus,
} from "@/apis/service/status/Status";
import DashboardLayout from "@/components/layouts";
import { STATUS_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveStatusForm } from "@/features/status/save_status_form/SaveStatusForm";
import { StatusDTO } from "@/models/status/Status";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateStatusPage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialStatus, setInitialStatus] = useState<StatusDTO | undefined>(
    undefined
  );

  const getStatusQuery = useQuery({
    queryKey: ["get_initial_status"],
    queryFn: () =>
      getStatus(typeof id == "string" ? Number(id) : Number((id || [])[0])),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getStatusQuery.refetch().then((response) => {
        setInitialStatus(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateStatusQuery = useMutation({
    mutationFn: updateStatus,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.status"),
        })
      );
      router.push(`/${STATUS_ROOT_PATH}/${UI_PATH.LIST}`);
    },
    onError: (error) => {
      const code = (error as AxiosError<ResponseWrapper<any>>)
        ?.response?.data?.error
        ?.code
      !!code && toast.error(
        t(
          `common.error_code.${code === 4010006 ? '4010006u' : code}`
        )
      );
    }
  });

  const deleteStatusListQuery = useMutation({
    mutationFn: deleteStatusList,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.status"),
        })
      );
      router.push(`/${STATUS_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveStatusForm
        formMode='update'
        initialValue={initialStatus}
        onSubmit={(data) =>
          id &&
          updateStatusQuery.mutate({
            request: data,
            id: typeof id == "string" ? Number(id) : Number(id[0]),
          })
        }
        onDelete={() =>
          id &&
          deleteStatusListQuery.mutate(
            typeof id == "string" ? [Number(id)] : [Number(id[0])]
          )
        }
        onCancel={() => router.back()}
        loading={
          updateStatusQuery.isPending ||
          getStatusQuery.isFetching ||
          deleteStatusListQuery.isPending
        }
      />
    </DashboardLayout>
  );
}
