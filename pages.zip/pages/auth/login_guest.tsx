import LoginGuestComponent from "@/features/auth/LoginGuestComponen";

const LoginGuest: React.FC = () => {
  return <LoginGuestComponent />;
};
export default LoginGuest;
