import LoginComponent from "@/features/auth/LoginComponent";

const Login: React.FC = () => {
  return <LoginComponent />;
};

export default Login;
