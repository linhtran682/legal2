import { createReminderTemplate } from "@/apis/service/reminder_template/ReminderTemplate";
import DashboardLayout from "@/components/layouts";
import { SaveReminderTemplateForm } from "@/features/reminder_template/save_reminder_template_form/SaveReminderTemplateForm";
import { REMINDER_TEMPLATE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateReminderTemplatePage() {
  const [t] = useTranslation();
  const router = useRouter();

  const createReminderTemplateQuery = useMutation({
    mutationFn: createReminderTemplate,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.reminder"),
        })
      );
      router.push(`/${REMINDER_TEMPLATE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveReminderTemplateForm
        formMode='create'
        onSubmit={createReminderTemplateQuery.mutate}
        onCancel={() => router.back()}
        loading={createReminderTemplateQuery.isPending}
      />
    </DashboardLayout>
  );
}
