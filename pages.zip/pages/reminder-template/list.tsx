import DashboardLayout from "@/components/layouts";
import { ReminderTemplateTable } from "@/features/reminder_template/reminder_template_table/ReminderTemplateTable";
import { REMINDER_TEMPLATE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { useRouter } from "next/navigation";
import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";

export default function ReminderTemplatesPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <ReminderTemplateTable />
      <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${REMINDER_TEMPLATE_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
