import {
  deleteReminderTemplates,
  getReminderTemplate,
  updateReminderTemplate,
} from "@/apis/service/reminder_template/ReminderTemplate";
import DashboardLayout from "@/components/layouts";
import { REMINDER_TEMPLATE_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { SaveReminderTemplateForm } from "@/features/reminder_template/save_reminder_template_form/SaveReminderTemplateForm";
import { GetReminderTemplateDTO } from "@/models/reminder_template/ReminderTemplateDTO";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateReminderTemplatePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const id = router.query.id;

  const [initialReminderTemplate, setInitialReminderTemplate] = useState<
    GetReminderTemplateDTO | undefined
  >(undefined);

  const getReminderTemplateQuery = useQuery({
    queryKey: ["get_initial_ReminderTemplate"],
    queryFn: () =>
      getReminderTemplate(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: false,
  });

  useEffect(() => {
    id &&
      getReminderTemplateQuery.refetch().then((response) => {
        setInitialReminderTemplate(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const updateReminderTemplateQuery = useMutation({
    mutationFn: updateReminderTemplate,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.reminder"),
        })
      );
      router.push(`/${REMINDER_TEMPLATE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const deleteReminderTemplatesQuery = useMutation({
    mutationFn: deleteReminderTemplates,
    onSuccess: () => {
      toast.success(
        t("common.message.delete_success", {
          recordName: t("menu.reminder"),
        })
      );
      router.push(`/${REMINDER_TEMPLATE_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <SaveReminderTemplateForm
        formMode='update'
        initialValue={initialReminderTemplate}
        onSubmit={(data) =>
          id &&
          updateReminderTemplateQuery.mutate({
            request: data,
            id: typeof id == "string" ? Number(id) : Number(id[0]),
          })
        }
        onDelete={() =>
          id &&
          deleteReminderTemplatesQuery.mutate(
            typeof id == "string" ? [Number(id)] : [Number(id[0])]
          )
        }
        onCancel={() => router.back()}
        loading={
          updateReminderTemplateQuery.isPending ||
          getReminderTemplateQuery.isFetching ||
          deleteReminderTemplatesQuery.isPending
        }
      />
    </DashboardLayout>
  );
}
