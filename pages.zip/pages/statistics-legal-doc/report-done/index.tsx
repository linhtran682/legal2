import DashboardLayout from "@/components/layouts";
import LegalDocumentReportDone from "@/features/statistics-legal-doc/legal-doc-report-done/LegalDocumentReportDone";
import React from "react";

const LegalDocumentDoneReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalDocumentReportDone />
    </DashboardLayout>
  );
};

export default LegalDocumentDoneReportPage;
