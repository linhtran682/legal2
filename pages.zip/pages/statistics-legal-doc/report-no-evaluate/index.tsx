import DashboardLayout from '@/components/layouts'
import LegalDocumentReportNotEvaluate from '@/features/statistics-legal-doc/legal-doc-report-not-evaluate/LegalDocumentReportNotEvaluate'
import React from 'react'

const LegalDocumentNoEvaluateReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalDocumentReportNotEvaluate />
    </DashboardLayout>
  )
}

export default LegalDocumentNoEvaluateReportPage