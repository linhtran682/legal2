import DashboardLayout from '@/components/layouts'
import LegalDocumentReportSlowEvaluate from '@/features/statistics-legal-doc/legal-doc-report-slow-evaluate/LegalDocumentReportSlowEvaluate'
import React from 'react'

const LegalDocumentSlowEvaluateReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalDocumentReportSlowEvaluate />
    </DashboardLayout>
  )
}

export default LegalDocumentSlowEvaluateReportPage