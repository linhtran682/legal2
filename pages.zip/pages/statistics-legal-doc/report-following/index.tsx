import DashboardLayout from '@/components/layouts'
import LegalDocumentReportFollowing from '@/features/statistics-legal-doc/legal-doc-report-following/LegalDocumentReportFollowing'
import React from 'react'

const LegalDocumentFollowingReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalDocumentReportFollowing />
    </DashboardLayout>
  )
}

export default LegalDocumentFollowingReportPage