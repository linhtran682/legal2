import DashboardLayout from "@/components/layouts";
import LegalDocumentOverview from "@/features/statistics-legal-doc/legal-doc-overview/LegalDocumentOverview";
export default function LegalDocumentReport() {
  return (
    <DashboardLayout noFooterBtn>
      <LegalDocumentOverview />
    </DashboardLayout>
  );
}
