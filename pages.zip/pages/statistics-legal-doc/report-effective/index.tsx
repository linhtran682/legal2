import DashboardLayout from "@/components/layouts";
import LegalDocumentReportEffective from "@/features/statistics-legal-doc/legal-doc-report-effective/LegalDocumentReportEffective";
import React from "react";

const LegalDocumentEffectiveReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalDocumentReportEffective />
    </DashboardLayout>
  );
};

export default LegalDocumentEffectiveReportPage;
