import DashboardLayout from '@/components/layouts'
import LegalDocumentReport from '@/features/statistics-legal-doc/legal-doc-report/LegalDocumentReport'
import React from 'react'

const LegalDocumentReportPage = () => {
  return (
    <DashboardLayout noFooterBtn>
      <LegalDocumentReport />
    </DashboardLayout>
  )
}

export default LegalDocumentReportPage