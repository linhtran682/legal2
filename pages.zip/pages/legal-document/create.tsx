import { UpdateLegalDocumentToSharepoint, uploadLegalDocumentToSharepoint } from "@/apis/service/files_upload/files";
import {
  createDrafLawDocument,
  createLawDocument,
} from "@/apis/service/law_document/law_document";
import DashboardLayout from "@/components/layouts";
import { LEGAL_DOCUMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { LegalDocumentForm } from "@/features/legal-document/form-legal-document/LegalDocumentForm";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function LawDocumentCreatePage() {
  const [t] = useTranslation();
  const router = useRouter();
  const [fileSharepoint, setFileSharePoint] = useState<any>([]);
  const createLawDocumentQuery = useMutation({
    mutationFn: createLawDocument,
    onSuccess: async (data) => {
      // if (fileSharepoint) {
      //   try {
      //     await uploadLegalDocumentToSharepoint({
      //       fileDetails: fileSharepoint,
      //       id: data?.result.legalDocumentId,
      //     });
      //   } catch (error) { }
      // }
      if (fileSharepoint?.length) {
        try {
          if (fileSharepoint[0].file) {
            data?.result.legalDocumentId &&
              (await uploadLegalDocumentToSharepoint({
                fileDetails: fileSharepoint,
                id: data?.result.legalDocumentId,
              }));
          } else {
            data?.result.legalDocumentId &&
              (await UpdateLegalDocumentToSharepoint({
                legal_document_id: data?.result.legalDocumentId,
                file_id: fileSharepoint[0].id,
              }));
          }
        } catch (error) { }
      }
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.legalDocument"),
        })
      );
      router.push(`/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const createLawDocumentDrafQuery = useMutation({
    mutationFn: createDrafLawDocument,
    onSuccess: async (data) => {
      // if (fileSharepoint) {
      //   try {
      //     await uploadLegalDocumentToSharepoint({
      //       fileDetails: fileSharepoint,
      //       id: data?.result.legalDocumentId,
      //     });
      //   } catch (error) { }
      // }
      if (fileSharepoint?.length) {
        try {
          if (fileSharepoint[0].file) {
            data?.result.legalDocumentId &&
              (await uploadLegalDocumentToSharepoint({
                fileDetails: fileSharepoint,
                id: data?.result.legalDocumentId,
              }));
          } else {
            data?.result.legalDocumentId &&
              (await UpdateLegalDocumentToSharepoint({
                legal_document_id: data?.result.legalDocumentId,
                file_id: fileSharepoint[0].id,
              }));
          }
        } catch (error) { }
      }
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.legalDocument"),
        })
      );
      router.push(`/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  return (
    <DashboardLayout>
      <LegalDocumentForm
        formMode="create"
        onSubmit={createLawDocumentQuery.mutate}
        onSubmitDraft={createLawDocumentDrafQuery.mutate}
        onCancel={() => router.back()}
        setFileSharePoint={setFileSharePoint}
        loading={createLawDocumentQuery?.isPending || createLawDocumentDrafQuery?.isPending}
      />
    </DashboardLayout>
  );
}
