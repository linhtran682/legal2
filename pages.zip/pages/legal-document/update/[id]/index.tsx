"use client";
import {
  UpdateLegalDocumentToSharepoint,
  uploadLegalDocumentToSharepoint,
} from "@/apis/service/files_upload/files";
import {
  cloneLegalDocumentFn,
  createLawDocument,
  getDepartmentStatus,
  getLawDocument,
  recallLegalDocument,
  shareLegalDocumentFn,
  updateBookMeeting,
  updateLawDocument
} from "@/apis/service/law_document/law_document";
import { getStatusList } from "@/apis/service/status/Status";
import SharePopup from "@/components/commons/share_popup/SharePopup";
import { StatusBadge } from "@/components/commons/status_badge/StatusBadge";
import DashboardLayout from "@/components/layouts";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import { URL_OUTLOOK } from "@/constants/constraint";
import { LegalDocumentStatusContent, LegalDocumentUserStatusKey, ModuleFields, StatusNextActions, StatusNextActionsKey } from "@/constants/general";
import { LEGAL_DOCUMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { AppContext } from "@/context/AppContext";
import { AssignmentForm } from "@/features/legal-document/assignment_form/AssignmentForm";
import { EvaluateLegalDocumentForm } from "@/features/legal-document/evaluate_legal_document_form/EvaluateLegalDocumentForm";
import DepartmentStatusTable from "@/features/legal-document/evaluate_table/DepartmentStatusTable";
import { FeedBackLcForm } from "@/features/legal-document/feedback_lc_form/FeedBackLcForm";
import { FeedbackLegalDocumentForm } from "@/features/legal-document/feedback_legal_document_form/FeedbackLegalDocumentForm";
import { FinishLegalDocumentForm } from "@/features/legal-document/finish_legal_document_form/FinishLegalDocumentForm";
import { LegalDocumentForm } from "@/features/legal-document/form-legal-document/LegalDocumentForm";
import { ForwardLegalDocumentForm } from "@/features/legal-document/forward_legal_document_form/ForwardLegalDocumentForm";
import { LegalDocumentLayout } from "@/features/legal-document/layout/LegalDocumentLayout";
import {
  ButtonAction,
  LegalDocumentTableActionsText,
} from "@/features/legal-document/legal_document_table/legal_document_table_actions/LegalDocumentTableActionsText";
import { LegalMetadataTabPanel } from "@/features/legal-document/legal_metadata_tab_panel/LegalMetadataTabPanel";
import { AssessmentFeedbackForm } from "@/features/legal-document/next_action_form/AssessmentFeedbackForm";
import { FinishEvaluateForm } from "@/features/legal-document/next_action_form/FinishEvaluateForm";
import OverviewHeader from "@/features/legal-document/overview_header/OverviewHeader";
import { ApprovalNextActionForm } from "@/features/legal-document/request_approval_form/ApprovalNextActionForm";
import { RequestApprovalForm } from "@/features/legal-document/request_approval_form/RequestApprovalForm";
import { RequestReviewLegalDocumentForm } from "@/features/legal-document/request_review_legal_document_form/RequestReviewLegalDocumentForm";
import { RequestVendorForm } from "@/features/legal-document/request_vendor_form/RequestVendorForm";
import { TimeExtensionForm } from "@/features/legal-document/time_extension_form/TimeExtensionForm";
import {
  StatusReviewApproval,
  StatusReviewApprovalKey,
} from "@/models/law_document/ApprovalNextAction";
import { AssignmentFieldNames } from "@/models/law_document/Assignment";
import { LawDocumentBodyReceive, SaveLawDocumentRequestFieldNames } from "@/models/law_document/LawDocument";
import { RequestVendorFieldNames } from "@/models/law_document/RequestVendor";
import { StatusDTO, StatusFieldNames } from "@/models/status/Status";
import { Box, Stack, Tooltip, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import moment from 'moment';
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "react-toastify";

export default function CreateStatusPage() {
  const [t] = useTranslation();
  const appContext = useContext(AppContext);
  const router = useRouter();
  const id = router.query.id;
  const routeAction = router.query.action;
  const [popupVisibleState, setPopupVisibleState] = useState<
    Record<string, boolean>
  >({});

  const [initialLawDocument, setInitialLawDocument] = useState<
    LawDocumentBodyReceive | undefined
  >(undefined);
  const [selectedRequestApproval, setSelectedRequestApproval] =
    useState<any>(null);
  const [fileSharepoint, setFileSharePoint] = useState<any>([]);

  const getLawDocumentQuery = useQuery({
    queryKey: ["get_initial_law"],
    queryFn: () =>
      getLawDocument(
        typeof id == "string" ? Number(id) : Number((id || [])[0])
      ),
    enabled: false,
  });
  const updateLawDocumentQuery = useMutation({
    mutationFn: updateLawDocument,
    onSuccess: async () => {
      if (fileSharepoint) {
        try {
          if (fileSharepoint[0].file) {
            id &&
              (await uploadLegalDocumentToSharepoint({
                fileDetails: fileSharepoint,
                id: +id,
              }));
          } else {
            id && (fileSharepoint[0].accessLink === "" || fileSharepoint[0].accessLink === undefined) &&
              (await UpdateLegalDocumentToSharepoint({
                legal_document_id: +id,
                file_id: fileSharepoint[0].id,
              }));
          }
        } catch (error) { }
      }
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.legalDocument"),
        })
      );
      getLawDocumentQuery.refetch().then((response) => {
        setInitialLawDocument(response.data);
      });
      router.push(`/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });
  const createLawDocumentQuery = useMutation({
    mutationFn: createLawDocument,
    onSuccess: () => {
      toast.success(
        t("common.message.create_success", {
          recordName: t("menu.legalDocument"),
        })
      );
      getLawDocumentQuery.refetch().then((response) => {
        setInitialLawDocument(response.data);
      });
      router.push(`/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.LIST}`);
    },
  });

  const getDepartmentStatusQuery = useQuery({
    queryKey: ["get-department-status", initialLawDocument?.id],
    queryFn: async () => {
      try {
        return await getDepartmentStatus(initialLawDocument?.id as number);
      } catch (error) {
        return { departmentStatusList: [] };
      }
    },
    enabled: !!initialLawDocument?.id,
  });

  const recallQuery = useMutation({
    mutationFn: recallLegalDocument,
    onSuccess: () => {
      toast.success(t("LEGISLATION.message.recall_success"));
      getLawDocumentQuery.refetch().then((response) => {
        setInitialLawDocument(response.data);
      });
    },
  });
  useEffect(() => {
    id &&
      getLawDocumentQuery.refetch().then((response) => {
        setInitialLawDocument(response.data);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    if (routeAction) {
      changePopupVisible(routeAction, true);
    }
  }, [routeAction]);

  const handleClick = (type: any) => {
    if (type) {
      changePopupVisible(type, true);
      router.replace(
        `/${LEGAL_DOCUMENT_ROOT_PATH}/update/${id}?action=${type}`
      );
    }
  };

  const changePopupVisible = (type: any, state: boolean = false, reload: boolean = false) => {
    setPopupVisibleState((prev) => ({
      ...prev,
      [type]: state,
    }));
    if (reload) {
      getDepartmentStatusQuery?.refetch()
      getLawDocumentQuery.refetch().then((response) => {
        setInitialLawDocument(response.data);
      });
    }
    if (!state) {
      router.replace(`/${LEGAL_DOCUMENT_ROOT_PATH}/update/${id}`);
      setSelectedRequestApproval(null);
      setPopupVisibleState({})
    }
  };

  const handleClickApprove = (request: any) => {
    setSelectedRequestApproval(request);
    handleClick(ButtonAction.REVIEW_APPROVAL);
  };

  const handleClickApproveNextAction = (request: any) => {
    setSelectedRequestApproval(request);
    handleClick(ButtonAction.APPROVAL_NEXT_ACTION);
  };

  const updateBookMeetingMutation = useMutation({
    mutationFn: updateBookMeeting,
    onSuccess: () => {
      toast.success(
        t("common.message.update_success", {
          recordName: t("menu.legalDocument"),
        }))
      getLawDocumentQuery.refetch().then((response) => {
        setInitialLawDocument(response.data);
      });
    },
  })

  const shareMutation = useMutation({
    mutationFn: shareLegalDocumentFn,
    onSuccess: () => {
      toast.success(
        t(`LEGISLATION.message.shareSuccess`)
      );
    },
  });
  const cloneMutation = useMutation({
    mutationFn: cloneLegalDocumentFn,
    onSuccess: () => {
      toast.success(
        t(`LEGISLATION.message.recheckSuccess`)
      );
    },
  });

  const getStatusListQuery = useQuery({
    queryKey: ['legal-document/get-status-list-all'],
    queryFn: async () => {
      const response = await getStatusList({
        modules: [ModuleFields.LEGISLATION_NAME.module],
        page: 0,
        size: 100,
        sortBy: StatusFieldNames.NAME,
        orderBy: "ASC",
        active: 1
      });
      return response?.statusResponses || [];
    },
    placeholderData: prev => prev,
    enabled: true
  });

  const handleRecheck = (document: any) => {
    const requestAdviceStatus = getStatusListQuery?.data
      ?.find((ele: StatusDTO) => ele.name === LegalDocumentStatusContent.get(
        LegalDocumentUserStatusKey.SENT
      )!)

    document?.id && cloneMutation.mutate({
      id: document?.id as number,
      data: {
        childStatus: requestAdviceStatus?.id as number,
        status: document?.status?.id as number
      }
    })
  }

  return (
    <DashboardLayout hideHeader>
      {initialLawDocument && (
        <LegalDocumentLayout documentName={initialLawDocument?.documentName}>
          <Stack direction={"column"} sx={{ height: "100%" }}>
            <Breadcrumb />
            <Tooltip
              title={initialLawDocument?.documentName ?? ""}
              placement="top-start"
            >
              <Typography
                variant="h1"
                sx={{
                  fontSize: "24px",
                  mb: 1,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  display: "-webkit-box",
                  WebkitLineClamp: "1",
                  WebkitBoxOrient: "vertical",
                  wordBreak: "break-word",
                  width: "fit-content",
                }}
              >
                {initialLawDocument?.documentName}
              </Typography>
            </Tooltip>
            {initialLawDocument ? (
              <StatusBadge
                label={
                  initialLawDocument?.isDraft
                    ? t("common.label.draft")
                    : (initialLawDocument?.status?.name as string)
                }
              />
            ) : null}
            <Box height={12} />
            {initialLawDocument && !initialLawDocument?.isDraft && (
              // && initialLawDocument?.status?.name !== LegalDocumentStatusContent.get(
              //   LegalDocumentUserStatusKey.DONE)
              <LegalDocumentTableActionsText
                isActionDetail
                params={{
                  row: initialLawDocument,
                }}
                activeAction={
                  getDepartmentStatusQuery?.data?.isCanFinish
                    ? [ButtonAction.DONE]
                    : []
                }
                handleClickRequestEvaluate={() =>
                  handleClick(ButtonAction.REQUEST_EVALUATE)
                }
                handleClickResponse={() => handleClick(ButtonAction.RESPONSE)}
                handleClickForWard={() => handleClick(ButtonAction.FORWARD)}
                handleClickSendReminders={() =>
                  handleClick(ButtonAction.EVALUATE)
                }
                handleClickExtendDeadline={() =>
                  handleClick(ButtonAction.EXTEND_DEADLINE)
                }
                handleClickRequestConfirm={() =>
                  handleClick(ButtonAction.REQUEST_CONFIRM)
                }
                handleClickAssignment={() =>
                  handleClick(ButtonAction.ASSIGNMENT)
                }
                handleClickRequestVendor={() =>
                  handleClick(ButtonAction.REQUEST_VENDOR)
                }
                handleClickFinish={() => handleClick(ButtonAction.DONE)}
                handleClickNext={() =>
                  window.open(
                    `/${LEGAL_DOCUMENT_ROOT_PATH}/${id}/${
                      getLawDocumentQuery.data?.nextActionId
                        ? "update-next-action"
                        : "request-next-action"
                    }/${
                      getLawDocumentQuery.data?.nextActionId ??
                      encodeURIComponent(
                        getLawDocumentQuery.data?.documentName ?? ""
                      )
                    }`,
                    "_blank"
                  )
                }
                handleClickRecall={() => {
                  recallQuery.mutate(Number(initialLawDocument.id));
                }}
                handleClickResponseLc={() =>
                  handleClick(ButtonAction.RESPONSE_LC)
                }
                handleClickRequestMeeting={() =>
                  window.open(URL_OUTLOOK, "_blank")
                }
                handleClickEvaluate={() => {
                  if (initialLawDocument) {
                    if (
                      initialLawDocument.attachmentsSharepoint?.length &&
                      initialLawDocument.attachmentsSharepoint?.length > 0
                    ) {
                      let accessLink = "";
                      initialLawDocument.attachmentsSharepoint.map((e) => {
                        if (e?.accessLink && e?.isEvaluateFile) {
                          accessLink = e.accessLink;
                        }
                      });
                      if (!accessLink) {
                        toast.warning(
                          t("LEGISLATION.message.noSharepointFile")
                        );
                        return;
                      }
                      window.open(accessLink);
                    } else {
                      toast.warning(t("LEGISLATION.message.noSharepointFile"));
                      return;
                    }
                  }
                }}
                handleClickRecheck={() => handleRecheck(initialLawDocument)}
                handleClickShare={() => handleClick(ButtonAction.SHARE)}
              />
            )}
            <Box sx={{ flex: 1, overflowY: "auto" }}>
              <OverviewHeader
                initialValueReceive={initialLawDocument}
                handleUpdateBookMeeting={updateBookMeetingMutation.mutateAsync}
                isLoading={
                  updateBookMeetingMutation.isPending ||
                  getLawDocumentQuery.isFetching
                }
              />
              <LegalDocumentForm
                formMode="update"
                onCancel={() => router.back()}
                initialValueReceive={initialLawDocument ?? initialLawDocument}
                onSubmit={(data) => {
                  id &&
                    updateLawDocumentQuery.mutate({
                      request: data,
                      id: typeof id == "string" ? Number(id) : Number(id[0]),
                    });
                  id &&
                    data.legalDocumentDraftId &&
                    createLawDocumentQuery.mutate(data);
                }}
                setFileSharePoint={setFileSharePoint}
                loading={
                  updateLawDocumentQuery?.isPending ||
                  createLawDocumentQuery?.isPending
                }
              >
                {initialLawDocument?.id && (
                  <DepartmentStatusTable
                    legalDocument={initialLawDocument}
                    getDepartmentStatusQuery={getDepartmentStatusQuery}
                    handleClickApprove={handleClickApprove}
                    handleClickApproveNextAction={handleClickApproveNextAction}
                    handleClickRequestApproval={() =>
                      handleClick(ButtonAction.REQUEST_CONFIRM)
                    }
                    handleClickFeedbackEvaluated={(request) => {
                      setSelectedRequestApproval(request);
                      handleClick(ButtonAction.FEEDBACK_EVALUATED);
                    }}
                    handleClickCompleteEvaluated={(request) => {
                      setSelectedRequestApproval(request);
                      handleClick(ButtonAction.COMPLETE_EVALUATED);
                    }}
                  />
                )}
              </LegalDocumentForm>
              {id && (
                <>
                  <Box height={16} />
                  <LegalMetadataTabPanel
                    documentId={
                      typeof id == "string" ? Number(id) : Number(id[0])
                    }
                    legalDocument={getLawDocumentQuery.data}
                    loading={getLawDocumentQuery.isLoading}
                  />
                </>
              )}
            </Box>
          </Stack>
        </LegalDocumentLayout>
      )}

      {popupVisibleState?.[ButtonAction.SHARE] && (
        <SharePopup
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.SHARE, state, reload)
          }
          isOpen={true}
          owner={initialLawDocument?.pic}
          pics={initialLawDocument?.users}
          onSubmit={async (data: any) => {
            const params = {
              id: initialLawDocument?.id as number,
              data,
            };
            await shareMutation.mutateAsync(params);
          }}
          initialValue={{
            legalAccessType: initialLawDocument?.legalAccessType,
            sharedDepartments: initialLawDocument?.sharedDepartments,
            sharedUsers: initialLawDocument?.sharedUsers,
          }}
        />
      )}
      <ForwardLegalDocumentForm
        setIsOpen={(state, reload) =>
          changePopupVisible(ButtonAction.FORWARD, state, reload)
        }
        legalDocumentId={initialLawDocument?.id}
        initialValues={initialLawDocument}
        isOpen={popupVisibleState?.[ButtonAction.FORWARD]}
        name={initialLawDocument?.documentName}
      />
      <FeedbackLegalDocumentForm
        setIsOpen={(state, reload) =>
          changePopupVisible(ButtonAction.RESPONSE, state, reload)
        }
        legalDocumentId={initialLawDocument?.id}
        initialValues={initialLawDocument}
        isOpen={popupVisibleState?.[ButtonAction.RESPONSE]}
        name={initialLawDocument?.documentName}
        sender={appContext.me}
      />
      {popupVisibleState?.[ButtonAction.REQUEST_EVALUATE] && (
        <RequestReviewLegalDocumentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.REQUEST_EVALUATE, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          isOpen={popupVisibleState?.[ButtonAction.REQUEST_EVALUATE]}
          name={initialLawDocument?.documentName}
        />
      )}
      {popupVisibleState?.[ButtonAction.EVALUATE] && (
        <EvaluateLegalDocumentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.EVALUATE, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValues={initialLawDocument}
          isOpen={popupVisibleState?.[ButtonAction.EVALUATE]}
          name={initialLawDocument?.documentName}
          requestEvaluateId={initialLawDocument?.requestEvaluateId}
          senderLegalDocument={appContext?.me}
        />
      )}
      {popupVisibleState?.[ButtonAction.EXTEND_DEADLINE] && (
        <TimeExtensionForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.EXTEND_DEADLINE, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValue={{}}
          isOpen={popupVisibleState?.[ButtonAction.EXTEND_DEADLINE]}
          extendDeadlineId={initialLawDocument?.extendDeadlineId}
          name={initialLawDocument?.documentName}
          maxDate={moment(initialLawDocument?.departmentResponseDate)
            .add(
              initialLawDocument?.extendDateAllowDeadline,
              !initialLawDocument?.extendDateAllowDeadlineNumberType
                ? "days"
                : "months"
            )
            .toISOString()}
        />
      )}
      {popupVisibleState?.[ButtonAction.REQUEST_CONFIRM] && (
        <RequestApprovalForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.REQUEST_CONFIRM, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          isOpen={popupVisibleState?.[ButtonAction.REQUEST_CONFIRM]}
          name={initialLawDocument?.documentName}
        />
      )}
      {popupVisibleState?.[ButtonAction.APPROVAL_NEXT_ACTION] && (
        <ApprovalNextActionForm
          name={initialLawDocument?.documentName ?? ""}
          legalDocumentId={initialLawDocument?.id}
          nextActionId={selectedRequestApproval?.nextActionId}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.APPROVAL_NEXT_ACTION, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonAction.APPROVAL_NEXT_ACTION]}
          initialValue={{
            status: StatusNextActions.get(
              StatusNextActionsKey.NEXT_ACTION_APPROVAL
            ),
          }}
          isDisabledStatus
        />
      )}
      {popupVisibleState?.[ButtonAction.REVIEW_APPROVAL] && (
        <ApprovalNextActionForm
          name={initialLawDocument?.documentName ?? ""}
          legalDocumentId={initialLawDocument?.id}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.REVIEW_APPROVAL, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonAction.REVIEW_APPROVAL]}
          isApproveReview
          requestApprovalId={selectedRequestApproval?.requestApprovalIds?.[0]}
          optionsStatus={[
            {
              label: t(
                `LEGISLATION.status.${StatusReviewApprovalKey.REVIEW_APPROVED}`
              ),
              value: StatusReviewApproval.get(
                StatusReviewApprovalKey.REVIEW_APPROVED
              ) as number,
            },
            {
              label: t(
                `LEGISLATION.status.${StatusReviewApprovalKey.REVIEW_REJECTED}`
              ),
              value: StatusReviewApproval.get(
                StatusReviewApprovalKey.REVIEW_REJECTED
              ) as number,
            },
          ]}
          initialValue={{
            status: StatusReviewApproval.get(
              StatusReviewApprovalKey.REVIEW_APPROVED
            ),
          }}
        />
      )}
      {popupVisibleState?.[ButtonAction.RESPONSE_LC] && (
        <FeedBackLcForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.RESPONSE_LC, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          initialValue={{}}
          isOpen={popupVisibleState?.[ButtonAction.RESPONSE_LC]}
          name={initialLawDocument?.documentName}
          senderLegalDocument={appContext?.me}
        />
      )}
      {popupVisibleState?.[ButtonAction.FEEDBACK_EVALUATED] && (
        <AssessmentFeedbackForm
          name={initialLawDocument?.documentName ?? ""}
          legalDocumentId={initialLawDocument?.id}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.FEEDBACK_EVALUATED, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonAction.FEEDBACK_EVALUATED]}
          requestSelectData={{
            evaluateDepartmentId: selectedRequestApproval?.department?.id,
            evaluateUserId: selectedRequestApproval?.users?.[0]?.id,
          }}
        />
      )}
      {popupVisibleState?.[ButtonAction.COMPLETE_EVALUATED] && (
        <FinishEvaluateForm
          name={initialLawDocument?.documentName ?? ""}
          legalDocumentId={initialLawDocument?.id}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.COMPLETE_EVALUATED, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonAction.COMPLETE_EVALUATED]}
          requestSelectData={{
            evaluateDepartmentId: selectedRequestApproval?.department?.id,
            evaluateUserId: selectedRequestApproval?.users?.[0]?.id,
          }}
        />
      )}
      {popupVisibleState?.[ButtonAction.DONE] && (
        <FinishLegalDocumentForm
          name={initialLawDocument?.documentName ?? ""}
          legalDocumentId={initialLawDocument?.id}
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.DONE, state, reload)
          }
          isOpen={popupVisibleState?.[ButtonAction.DONE]}
        />
      )}
      {popupVisibleState?.[ButtonAction.ASSIGNMENT] && (
        <AssignmentForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.ASSIGNMENT, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          isOpen={popupVisibleState?.[ButtonAction.ASSIGNMENT]}
          name={initialLawDocument?.documentName}
          senderLegalDocument={appContext?.me}
          initialValue={{
            [AssignmentFieldNames.USERS]: initialLawDocument?.users ?? [],
          }}
          initialLegalDocument={initialLawDocument}
        />
      )}
      {popupVisibleState?.[ButtonAction.REQUEST_VENDOR] && (
        <RequestVendorForm
          setIsOpen={(state, reload) =>
            changePopupVisible(ButtonAction.REQUEST_VENDOR, state, reload)
          }
          legalDocumentId={initialLawDocument?.id}
          isOpen={popupVisibleState?.[ButtonAction.REQUEST_VENDOR]}
          initialValue={{
            [RequestVendorFieldNames.USERS]: [initialLawDocument?.pic]?.concat(
              initialLawDocument?.assignmentUsers || []
            ),
            [RequestVendorFieldNames.TIME_VENDOR_RESPONSE]:
              initialLawDocument?.[
                SaveLawDocumentRequestFieldNames.VENDOR_RESPONSE_DATE
              ]
                ? new Date(
                    initialLawDocument?.[
                      SaveLawDocumentRequestFieldNames.VENDOR_RESPONSE_DATE
                    ]
                  )
                : null,
          }}
          name={initialLawDocument?.documentName}
          senderLegalDocument={appContext?.me}
        />
      )}
    </DashboardLayout>
  );
}
