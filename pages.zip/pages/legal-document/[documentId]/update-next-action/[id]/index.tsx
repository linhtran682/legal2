import { getLegalDocumentNextActionBaseId } from "@/apis/service/law_document/law_document";
import DashboardLayout from "@/components/layouts";
import Breadcrumb from "@/components/layouts/BreadCrumbs";
import { ModuleFields } from "@/constants/general";
import { AppContext } from "@/context/AppContext";
import { NextActionForm } from "@/features/legal-document/next_action_form/NextActionForm";
import { Stack, Typography } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";

export default function UpdateNextAction() {
  const router = useRouter();
  const appContext = useContext(AppContext);
  const documentId =
    typeof router.query.documentId == "string"
      ? Number(router.query.documentId)
      : Number((router.query.documentId || [])[0]);
  const documentName =
    typeof router.query.documentName == "string"
      ? router.query.documentName
      : (router.query.documentName || [])[0];
  const nextActionId =
    typeof router.query.id == "string"
      ? Number(router.query.id)
      : Number((router.query.id || [])[0]);

  const [nextActionDetail, setNextActionDetail] = useState<any>(undefined);

  const getNextActionQuery = useQuery({
    queryKey: ["get_initial_next_action"],
    queryFn: () =>
      getLegalDocumentNextActionBaseId({
        documentId: documentId,
        id: nextActionId,
      }),
    enabled: !!nextActionId,
  });
  useEffect(()=>{
    getNextActionQuery.refetch()
  }, [getNextActionQuery])
  useEffect(() => {
    getNextActionQuery.data && setNextActionDetail(getNextActionQuery.data);
  }, [getNextActionQuery.data, getNextActionQuery.isLoading]);

  return (
    <DashboardLayout hideHeader>
      <Stack direction={"column"} sx={{ height: "100%" }}>
        <Breadcrumb />
        <Typography variant="h1" sx={{ fontSize: "24px", mb: 2 }}>
          {nextActionDetail?.name && nextActionDetail?.name}
        </Typography>
        <NextActionForm
          module={ModuleFields.LEGISLATION_NAME.module}
          documentId={documentId}
          documentName={documentName}
          userId={appContext.me?.id}
          nextActionId={nextActionId}
          formMode={"update"}
        />
      </Stack>
    </DashboardLayout>
  );
}
