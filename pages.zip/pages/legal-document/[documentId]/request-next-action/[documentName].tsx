import DashboardLayout from "@/components/layouts";
import { ModuleFields } from "@/constants/general";
import { AppContext } from "@/context/AppContext";
import { NextActionForm } from "@/features/legal-document/next_action_form/NextActionForm";
import { useRouter } from "next/router";
import { useContext } from "react";

export default function RequestNextAction() {
  const router = useRouter();
  const appContext = useContext(AppContext);
  const documentId =
    typeof router.query.documentId == "string"
      ? Number(router.query.documentId)
      : Number((router.query.documentId || [])[0]);
  const documentName =
    typeof router.query.documentName == "string"
      ? router.query.documentName
      : (router.query.documentName || [])[0];

  return (
    <DashboardLayout> 
      <NextActionForm
        module ={ModuleFields.LEGISLATION_NAME.module}
        documentId={documentId}
        documentName={documentName}
        userId={appContext.me?.id}
        nextActionId={NaN}
        formMode={'create'}
      />
    </DashboardLayout>
  );
}
