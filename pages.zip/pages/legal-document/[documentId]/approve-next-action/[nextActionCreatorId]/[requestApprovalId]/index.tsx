import DashboardLayout from "@/components/layouts";
import { ApproveNextActionForm } from "@/features/legal-document/next_action_form/ApproveNextActionForm";
import { useRouter } from "next/router";

export default function RequestNextAction() {
  const router = useRouter();
  const documentId =
    typeof router.query.documentId == "string"
      ? Number(router.query.documentId)
      : Number((router.query.documentId || [])[0]);
  const nextActionCreatorId =
    typeof router.query.nextActionCreatorId == "string"
      ? router.query.nextActionCreatorId
      : (router.query.nextActionCreatorId || [])[0];
  const requestApprovalId =
    typeof router.query.requestApprovalId == "string"
      ? Number(router.query.requestApprovalId)
      : Number((router.query.requestApprovalId || [])[0]);

  return (
    <DashboardLayout>
      <ApproveNextActionForm
        documentId={documentId}
        nextActionCreatorId={nextActionCreatorId}
        requestApprovalId={requestApprovalId}
      />
    </DashboardLayout>
  );
}
