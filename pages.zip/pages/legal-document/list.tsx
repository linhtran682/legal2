import { StickyAddButton } from "@/components/commons/action_button/StickyAddButton";
import DashboardLayout from "@/components/layouts";
import { LEGAL_DOCUMENT_ROOT_PATH, UI_PATH } from "@/constants/paths";
import { LegalDocumentTable } from "@/features/legal-document/legal_document_table/LegalDocumentTable";
import { useRouter } from "next/router";

export default function LegalDocumentsPage() {
  const router = useRouter();

  return (
    <DashboardLayout>
      <LegalDocumentTable />
      <StickyAddButton
        ariaLabel='add_reminder_template'
        onClick={() =>
          router.push(`/${LEGAL_DOCUMENT_ROOT_PATH}/${UI_PATH.CREATE}`)
        }
      />
    </DashboardLayout>
  );
}
